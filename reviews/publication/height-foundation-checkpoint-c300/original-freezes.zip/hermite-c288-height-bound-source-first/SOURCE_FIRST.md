# C288: first-root, formal-definition-first height reconstruction

INTERNAL SOURCE-FIRST STATIC REVIEW, not a universal/publication decoder.
The source here is the released C269 mathematical definition, not a new paper
claim or producer implementation. No author proof or new runtime was read.

## Exact sealed target and independent derivation

C280 selects only `HermiteRationalHeight.heightBound : HeightBoundSpec` for
the first batch. Expanding the actual C269 body gives EXACTLY:

```text
forall q : Rat, forall B : Nat,
  max 1 (max (Nat.size q.num.natAbs) (Nat.size q.den)) <= B
  iff (1 <= B AND q.num.natAbs < 2^B AND q.den < 2^B).
```

`integerBits z = Nat.size z.natAbs`; q is the same canonical rational on both
sides, not an arbitrary witness pair or an existentially smaller numerator.
Set a=q.num.natAbs and b=q.den. The shortest mathematical derivation is:

```text
max 1 (max (size a) (size b)) <= B
iff 1<=B AND (size a<=B AND size b<=B)    [max_le_iff twice]
iff 1<=B AND (a<2^B AND b<2^B)           [Nat.size_le twice].
```

Raw Mathlib Nat.Size states `size m <= n iff m < 2^n`, for ALL naturals m,n.
Its proof handles zero and the n=0 binary-recursion branch, not just positive
arguments. Order.MinMax generates `max_le_iff` as the to_dual of le_min_iff;
its Nat specialization is `max x y<=B iff x<=B AND y<=B`.
No Rat-specific normalization, cancellation, denominator-positivity, magnitude
estimate, classical-choice premise or nonzero-q premise is needed for this
equivalence. In fact the max/size algebra works for arbitrary a,b:Nat.

## Zero, sign, strictness and binder boundaries

Canonical zero is num=0,den=1: size0=0,size1=1 and height0=1. For B=0 BOTH
sides are false, already because the outer clamp forces 1<=B. For B>=1,
zero satisfies both strict caps. B is universally quantified, not assumed
positive externally; `1<=B` is retained inside the equivalence.
An exact power 2^B has size B+1 (raw Nat.size_pow); equality with the cap
must FAIL. Replacing either strict `<` by `<=` would be a genuine off-by-one
error. For example q=2^B has canonical numerator on that boundary; for B>=1,
q=1/(2^B) has canonical denominator on the other boundary.
Negative numerators are covered by natAbs with no q>=0 restriction. These
are magnitude bits, not a two's-complement signed range; an encoded sign bit
is explicitly separate. No additional sign bit is silently charged here.
The canonical denominator is a natural field, not |den| or an arbitrary
supplied Q. Its positivity belongs to Rat's representation, but this first
root neither needs a positivity hypothesis nor proves that invariant afresh.
This is not a bound on |q| alone: a small rational can have a large denominator.

## Scope, exposures and handoff

No concrete mismatch was found between this first sealed proposition and the
actual max/size definitions. This is an independent static derivation, not a
Lean acceptance or source/own-binary association. No compiler, project script,
Python, Git, network, subagent, finite test or candidate proof search ran.
Only this new packet was written, using apply_patch; all old packets remain.
All released C269/sealed-definition bytes, including the other three Prop
bodies, were read; their mathematics is NOT reviewed or credited here.
C280's prior typing/output receipts were seen as seal metadata only. Actual
C282 proof/consumer/manifest and C285 runtime were NOT opened; nor were other
current numerical results or reviews. Exact read scopes/pins are in manifest.
Prior Hermite static/runtime slices and C206/C230/C276 author roles are not
erased: this is task-scoped formal-first review, not a fresh universal decoder.
The useful next consumer is a separately authorized exact heightBound proof
comparison after this freeze; no automatic author/runtime exposure follows.
No common-denominator/primitive-width, whole-producer/Sites height coverage,
native temporary/GCD/allocator/CPU, full-SPBE/ROOT/publication/PURIFIED credit.
qbe-substantive-worker keeps this dependency cut explicit. Failure class:
NONE FOUND mathematically; implementation unassessed. Freeze and STOP.
