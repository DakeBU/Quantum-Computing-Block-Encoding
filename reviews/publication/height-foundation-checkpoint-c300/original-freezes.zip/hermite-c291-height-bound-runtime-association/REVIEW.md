# C291: first height root, recorded-runtime association

INTERNAL RECORDED-RUNTIME ASSOCIATION after immutable C288/C290. No rerun,
new proof, clean-TCB, wholeproducer/native or publication/ROOT admission.
No concrete mismatch found in the released source/own-output/type/axiom/deps
records. This supports one focused heightBound gate, not other height roots.

## Exact source -> own output -> consumer

C285 proof source is403 bytes, SHA dbf510d7bbcc040dd8ea15187d5b87c9892952143ce7c079c023cec86d153c9f;
checks579 bytes, SHA b784c29a6498739b9dc73cec774d15096c4021327fc33e70c4ded8748b44fb34.
Both match C282 bytes independently reviewed/frozen in C290. Current proof
own output is22384 bytes, SHA bbc0940bcc0ee0adb3aa77edec406bbf8f5b6d5387f59e25f1fe3f5fc080be5b;
consumer own output10264 bytes, SHA2756df322784645556939c5e51d184538c81973f403e368575c06d5a8fc3aa85.
All match the result records. Olean hashing is not decompilation/kernel replay.

Actual consumer stdout prints heightBound:HeightBoundSpec and the full alias:
forall q:Rat,B:Nat, max1(max(size(num.natAbs),size den))<=B iff
1<=B AND num.natAbs<2^B AND den<2^B. ExactChecks source assigns precisely this
expanded type to the root, with no added premise, sign exclusion or weak cap.
Both actual quoted axiom rows name the expected declarations: heightBound
and C282ExactChecks.heightBoundExpandedCheck. EACH lists exactly propext,
Classical.choice,Quot.sound. Two rows are one root plus its exact assignment,
not two independent scientific roots. No unexpected/sorryAx row was seen.

The actual defProp warning at ExactChecks line5 is retained: the proposition
assignment uses def rather than theorem. The linter's suggested disable option
is only a diagnostic hint; no source/trust/linter change was made here.
Proof raw stdout/stderr are EMPTY; its one-byte feedback is the wrapper's
newline. ZERO source axiom rows mean no #print command, NOT an empty-axiom proof.
All ten private members were read/hash-checked in memory. Read-only path/CRLF
sanitation exactly reproduces both feedback files. No private archive/location,
raw search-path payload or credential was copied to public output.

## Selected imports, wrapper checks and provenance cut

Proof --deps has4 lines: two Init entries, C278 Definitions.olean, Mathlib
MinMax.olean. Consumer --deps has3: two Init and this C285 OWN proof output,
not an earlier proof cache. Current Definitions digest a0a6a6ab... matches
C280's preproof selected-output pin; its raw source matches C269/C280 SHA735fff52....
Actual MinMax digest is7ad73af2... and matches plan/result. The wrapper snapshots
that MinMax digest at start; this is NOT a fresh Mathlib source-to-binary audit.
Both Init entries have SHA26523a3a...; binary SHA dd86e9b2... matches the gate
pin. Full hashes/lengths and raw member IDs are in INPUT_MANIFEST.

The runner verifies freeze/seal/source/inherited inputs before stage creation,
before each module and after. Fresh stage uses exist_ok=False. It requires
--deps exit0 and EXACT LINE membership for expected direct outputs, then runs
proof followed by consumer under the same requested environment/root.
It checks expected inclusion, not exhaustive transitive loading; I inspected
the complete actual lines. Requested LEAN_PATH has30 entries, not an effective
loader trace. C278 compiled provenance and Mathlib/Lean libraries remain
inherited; no printed-definition audit or clean transitive rebuild occurred.

The strict parser/runner requires ordinary-only parsed rows; ExactChecks must
have exactly2 rows with exactly the root and expanded-assignment names. Missing
either, duplicate-only names, extra matched row, unknown axiom or parser error
would fail the focused gate. Source accepts zero ordinary rows vacuously;
the consumer closes that omission. Regex covers quoted axiom-list syntax, not
every arbitrary diagnostic/declaration; actual complete output was read too.

Result records assert exit0/no timeout,11.781/12.156 seconds and pre/post pin
stability. These are wrapper historical records, NOT reviewer-live exit/timing
observations. Current files/raw streams/wrapper agree, but do not attest race
freedom or constitute independent execution. Limits are explicit despite the
success status. Parameters -M3072,-j1,120s and5120MiB admission guard are gate
settings, not height/native/runtime complexity theorems.

## Handoff and stop

Only permitted C285 records/wrapper/parser/C278 source-output and direct
MinMax bytes were newly inspected; prohibited C282 DERIVATION/manifest and
other current proofs/reviews stayed unread. Earlier slice exposures retained;
not a universal decoder. C288/C290 all six original files remain unchanged.
Read-only PowerShell/.NET ZIP memory checks; apply_patch only NEW C291; no
compiler/lake/scripts/Python/Git/network/subagent/test. No tooling failure.
Skill qbe-substantive-worker preserves source/static/runtime/resource cuts.
Failure class NONE concrete association mismatch; TCB/attestation limits remain.
No other3 roots, actual producer/Sites/native GCD/allocator/CPU/fullSPBE credit.
Parent whole-read/hashcheck is next; no automatic new exposure. Freeze STOP.
