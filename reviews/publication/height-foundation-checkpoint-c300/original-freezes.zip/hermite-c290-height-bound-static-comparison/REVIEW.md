# C290: first height root, source-only proof comparison

INTERNAL STATIC COMPARISON after immutable C288 source-first reconstruction.
No compiler, actual success output, runtime/axiom association or publication
credit. Prior Hermite runtime and C206/C230/C276 author exposures remain;
this is task-scoped review, not a fresh universal decoder or external anchor.

## Exact proof and expanded consumer

C282 declares only `heightBound : HeightBoundSpec`. Its entire proof is:
unfold HeightBoundSpec; introduce q,B; simp only using height, integerBits,
max_le_iff and Nat.size_le. This is exactly C288's independent derivation:

```text
max 1 (max (size q.num.natAbs) (size q.den)) <= B
iff 1<=B AND size(q.num.natAbs)<=B AND size(q.den)<=B
iff 1<=B AND q.num.natAbs<2^B AND q.den<2^B.
```

The two max bounds yield the same right-associated conjunction as the sealed
target. Nat.size_le applies to BOTH natural fields and ALL B, including0.
No q positivity/nonzero, B>=1, denominator correctness or representation
witness premise is introduced. Canonical numerator/denominator are unchanged;
natAbs retains negative/zero numerators and the separate-sign-bit convention.
The `<` caps are strict in proof target AND consumer, not weakened to `<=`.
Zero and exact-power boundaries are exactly those frozen in C288.

ExactChecks defines `heightBoundExpandedCheck` by assigning the root to the
fully expanded forall q:Rat,B:Nat equivalence. There are no additional binders,
implications, witnesses, scalar-|q| substitutions or weaker conclusion. It is
an exact-type proof assignment, not a finite test or a new height algorithm.
Two #check and two #print axioms commands are source only; their results have
NOT been read, and no expected axiom set is inferred from the simp proof.

No private helper, executable producer, new axiom/sorry/admit/unsafe/native
evaluation, trust/linter/budget option or changed definition occurs in the
released proof/consumer. No concrete semantic/binder/strictness/sign mismatch
was found. This says nothing about whether Lean accepted the source.

## Import, seal and exposure boundary

Literal source graph: HeightBoundProof imports `Definitions` and
`Mathlib.Order.MinMax`; Definitions imports `Mathlib.Data.Nat.Size` and Rat APIs;
ExactChecks imports HeightBoundProof and assigns its named root. The allowed
raw max/size APIs support the proof. C269 equals C280 sealed-definitions by
length/hash, and author-freeze proof/consumer hashes match the inspected bytes.
This is SOURCE import topology, not an effective loader or own-output trace.
No selected Definitions/proof binary, --deps, compiled type or actual axiom
report was inspected. Those associations remain an explicit later gate.

Only released proof, consumer and AUTHOR_FREEZE were newly read. The freeze's
hashes for prohibited DERIVATION/manifest were visible as metadata, not files.
C280's earlier typing receipts remain metadata only. C282 DERIVATION/manifest,
C285 runtime/results and other current reviews/numerical outputs stayed unread.
The other three height targets, wholeproducer/Sites/native-temporary/GCD/
allocator/CPU complexity and full-SPBE/ROOT remain outside this review.

Actions: read-only scoped PowerShell source/hash checks; apply_patch only in
NEW C290. No compiler/lake/scripts/Python/Git/network/subagent/finite test.
C288 originals remain unchanged. Skill qbe-substantive-worker keeps the exact
predicate/import/resource cuts separate; no runtime or Exposition-Seal credit.
Failure class NONE FOUND statically; implementation unassessed. Independent
derivation and all boundaries retained; no target weakened or alternate route.
Next step: parent whole-read/hashcheck this separate packet, then separately
authorize runtime association if desired. Three public-allowlisted files only:
REVIEW.md, INPUT_MANIFEST.json, STATIC_REVIEW_SEAL.json. Freeze and STOP.
