# C188 same-returned-data construction: source-first internal review

Classification: INTERNAL_SOURCE_FIRST_SEMANTIC_REVIEW, for SP-HERMITE-POLY-002. This is an independent reconstruction of the original definitions and established prerequisite interfaces, frozen BEFORE exposure to any C177/C180/C181/C185/C186 same-chain author, failure, consumer or runtime packet. It is not acceptance of an unseen proof, an independent compiler rerun, a universal publication decoder, SourceAnchor, ProofSeal or scientific ROOT admission.

## Exposure and method

The same reviewer previously completed degree static/runtime (C151/C154), primitive static/runtime (C161/C164), setup static/runtime (C169/C173), and middle static/runtime (C178/C184) slices. Those distinct runtime exposures are acknowledged, not reset by this task. The C178 and C184 seals and all four payloads were rehashed unchanged. Their seals were read for preservation checks; their review prose was not used as a substitute for this reconstruction. Prior established setup/middle VALUE interfaces are deliberately available here. The full original C156 signatures, including their unrelated cost and same-run signatures, were already known and reread as interfaces only, not evidence of their realization.

The previously read qbe-substantive-worker skill and publication/digestion/evidence-memory protocols govern role separation, exact bindings and bounded credit. Only original C150 construction bodies, canonical C21/C22/provider semantics and prerequisite interfaces were used. No new author explanation, candidate proof, candidate consumer, runtime output, finite discriminator, other review, catalog or PR was opened. No compiler, lake, provided script, Git, network or subagent was run. No finite experiment was needed. Read-only PowerShell displayed source, searched definitions, computed hashes/lengths and checked prior seals. Two attempted original-source reads initially omitted the `precision` path component and failed; corrected paths were then read completely. An unnecessary first-100-line read of canonical StoredRectangularGivens was retained in the manifest, not silently omitted. No source or previous output was edited.

## Five right branches, derived from bodies

Write w=n+1, d=sourceDegree(delta), T=tailCutoff(delta), c=clippedValue(delta), t_j=1/(j!), and m_j=middleCoeffQ(k,delta,j). Set

`A(a)=acceptQ w (strictCut w R (-1)) a`,
`B(a)=acceptQ w (inclusiveCut w R 0) a`,
`C(a)=acceptQ w (inclusiveCut w R (-T)) a`,
`H(a)=acceptQ w (strictCut w R T) a`.

These are terminal automaton-label functions, not yet predicates on a grid point. Each component coordinate is `(a,(b,j))`; the nested sum order in FullIndex is essential. From Run.bind/pure/read values, rightProduct returns exactly `first*(second*coefficient)`, with no zero-mask short circuit. The actual generated setup supplies the four displayed cuts, the reciprocal-factorial vector and c. Its midpoint is the literal expMidpoint(delta); actual_cache_middle then supplies m from the actual generated C23 cache. Thus the five cases of rightEntry, in order, are:

| FullIndex summand | Exact returned right value | Polynomial coordinate |
|---|---|---|
| 1 | `A(a)*(C(b)*c)` | Fin 1 |
| 2 | `A(a)*((1-C(b))*t_j)` | Fin (d+1) |
| 3 | `(1-A(a))*(B(b)*m_j)` | Fin (2*k+2) |
| 4 | `(1-B(a))*((1-H(b))*c)` | Fin 1 |
| 5 | `(1-B(a))*(H(b)*t_j)` | Fin (d+1) |

Expanding BlockQ.prod and BlockQ.sum gives exactly these expressions for actualBlocksQ.right, in the same nested multiplication order. In particular summands 4/5 use the zero cut in the FIRST automaton, not the minus-one cut. Original D is strict(T) with flip=true; original Dc is strict(T) with flip=false. Both tails have the SAME reciprocal-factorial right coefficients. The fifth tail evaluates at the negated coordinate through origin R and step -gridStep, not through an extra sign in t_j. Inserting (-1)^j here would double-negate that convention. Constant coordinates are singleton indices, not source coefficients selected by their unused j.

The prerequisite acceptRun interface retains cut=0, cut=2^w and interior dispatch for both Bool values and every Fin 3 label; canonical cuts are capped internally. No positivity of R or delta, no T>=2, no cache oracle and no numerical sign assumption on the middle vector are needed for this coordinatewise equality. RightSetup's scalar R index does not itself certify its contents; arbitrary records of the same type need not agree. Therefore replacing actual generation by a universally arbitrary setup/middle without supplying their equalities would be an invalid generalization.

## Whole returned rational data, then the very same cast data

Let Qc=(produceCachedQData k n R delta).value and Qo=(produceQData k n R delta).value. The cached producer binds the actual source cache, setup and middle before constructing Qc; it does NOT call the old QData producer to supply Qc. For q:Fin(n+1), a:Fin D, j:Fin(2*D), D=assemblySize k delta, its table value is

`actualBlocksQ.kernel q.val (finProdFinEquiv.symm j).1 (e.symm a) (e.symm (finProdFinEquiv.symm j).2)`,

where e=fullEquiv k delta. This is the literal original table callback. The left coordinate is also the literal original callback. The five-case calculation above gives equality of every right coordinate with the original callback. collect projects the values of its actual callbacks. Repeated vector extensionality and record-field extensionality therefore give WHOLE `Qc = Qo`, not merely equal right entries or equal final contractions. This is equality of VALUE fields only: the two Run records have different computations/cost accounting, and no Run equality follows.

Run.bind passes precisely Qc to castData. castVector reads each supplied rational entry and returns its exact Rat-to-Real cast; castCore preserves row/column layout; castData reads and casts every core and both boundary vectors. Consequently the actual cached RealData value equals the original produceData value by congruence, or equivalently by entrywise casts of the just-established whole rational equality. No independent desired RealData witness is substituted. Casts preserve addition, subtraction and multiplication; there is no float rounding, normalization or sign/phase quotient here. Conversion/evaluation cost is a separate issue.

The core layout is D rows by 2*D columns. denoteCore decodes a column as `(bit,nextBond)`, using finProdFinEquiv; the producer uses its inverse with precisely that order. Reversing these factors, transposing old/new bonds, or applying fullEquiv rather than its inverse at a physical address would break the correspondence. FullIndex contains the five nested sums with polynomial sizes 1,d+1,2*k+2,1,d+1; e is the exact nested sum/product equivalence from those indices. There is no replacement by the old exact-real 2*k+6 bond. D is an assembly width, not a minimal rank or minimal polynomial degree.

## Window, stored refinement and literal source action

Window is an explicit equality of every supplied stored core with K(start+q), not a correctness property encoded merely by the vector type. Here K is `reindexKernel e (actualBlocks k n R delta).kernel`, start=0, and the actual casted table entry equals K(q.val) at `(bit,a,b)` by actualEntryQ_cast and the product-equivalence inverse identity. This supplies Window internally for the ACTUAL cached RealData. Window alone is insufficient: both actual left and actual right vectors must separately agree with the reindexed original boundaries. Whole-data equality plus the two original C22 boundary lemmas provides those obligations, with no caller premise.

produceCachedStored binds precisely that RealData and calls ofTable on its tables,left,right fields. ofTable reads stored tables, absorbs right into the final core, then left into the first core. Its generic ofTable_refines legitimately takes Window as a helper hypothesis. At a closed cached-producer root this hypothesis must be discharged from generated tables, not assumed. It yields denoteChain of the actual returned stored value equal to MatrixProductChain.ofKernel K with these very boundaries; substituting the two boundary equalities gives exact `actualChain k n R delta`. This is equality of dependent chains, stronger than equality of selected amplitudes, but it does not identify the stored syntax with an unstored function representation or certify operational pointer identity.

Physical width is n_p=n+1, not n. n=0 is one physical site: ofTable terminal absorption followed by initial absorption acts on the same single core, with scalar external bonds 1 and 1. There is no zero-site exception required. Word order is chronological core order; UniformComparison.wordValue is headBit+2*tailValue, so the first emitted bit is q0, the LSB. The table uses position q.val consistently with the translation factor 2^q and the comparison scan. No bit reversal, final phase correction or scalar rescaling is part of refinement.

Only the last source interpretation needs `0 < R`: strictCut/inclusiveCut then describe the increasing rational grid. Canonical cap bounds are supplied internally. The original actualChain_contract gives, for EVERY x:Word(n+1), the literal equality

`contract (denoteChain (produceCachedStored k n R delta).value) x 0 0 = (piecewiseValue k delta (rationalGrid n R (wordIndex n x)) : Real)`.

No epsilon, L, delta-positivity, normalized/nonzero vector, tolerance or correctness premise belongs in that value statement. Those would be separate later applications. The value/refinement construction is still defined for R=0 or negative R; this does not justify dropping positive R from the existing grid-source interpretation. This phase does not claim positivity is logically minimal for every isolated instance.

Original five_components dispatches first at p<-1, then p<=0, then the reflected tail. For T>=2, p=-T is clipped, p=-1 and p=0 are middle, p=T is clipped. For T=1 the coincident negative endpoint p=-T=-1 is MIDDLE by that first dispatch; for T=0 both tail thresholds coincide at zero but zero is still MIDDLE. The masks retain that precedence without a premise T>=2. Values at negative/zero delta remain the source's total rational definitions, not a newly promised approximation regime. No missing boundary assumption is needed in the data equality.

## Findings, hazards and limits

No mismatch was found in the ORIGINAL construction's value dataflow: the five derived branches reproduce the old right boundary, and the returned rational/casted/stored objects admit the explicit value-obligation chain above. This is an independently derived specification and proof route, NOT a verdict on any unseen same-chain proof or its compiler acceptance. A later comparison must check actual binders/definitions and all helper uses against these obligations, especially actual setup/cache substitution, Fin (2*k+1+1) versus Fin (2*k+2), FullIndex injection order, Window start=0, and BOTH boundaries. Whole-data equality should not be weakened to an unrelated oracle witness or replaced by a source-amplitude statement that hides a changed returned object.

One outer cache/setup/middle bind is visibly present in source; actual reads supply middle/tail coefficients. This supports semantic data dependency, NOT a native single-evaluation or zero-setup-work conclusion. actualBlocksQ is still captured for kernel and left callbacks; constructing/evaluating captured blocks, source expressions therein, natural floor/ceil/clog, index arithmetic, Rat casts, rational bitlength/GCD, runtime allocation and compiler sharing are not certified free by `pure`, comments, or syntactic lets. rightProduct retains its coefficient Run even under zero accepts. Source/value equality cannot transfer cost fields, establish the sealed same_run bound, or turn its partial ledger into full preprocessing/runtime.

The scalar degree, assembly width, local stored address count and eventual rank are different objects. No cost400, same-run resource bound, optimal-degree/rank, full-chain runtime, native/finite-bit, gates/synthesis/cleanup/export or end-to-end state-preparation result is established here. Existing original-state error budgets and all main/publication/scientific-ROOT gaps remain unchanged.

This packet freezes here. C177/C180/C181/C185/C186 and every new same-chain proof/failure/runtime/consumer remain withheld until separate parent authorization. Only SOURCE_FIRST.md, INPUT_MANIFEST.json and SOURCE_FIRST_SEAL.json are candidate outputs.
