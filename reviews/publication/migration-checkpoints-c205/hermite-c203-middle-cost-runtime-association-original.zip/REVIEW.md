# C203 actual runtime association: middle-cache cost

Verdict: the inspected C189 artifacts consistently associate the statically reviewed C183 source with its recorded OWN output and a successful exact-type/ordinary-axiom consumer. No association mismatch found. This is review of the existing run, **not an independent rerun**, clean rebuild, full-TCB certification, Proof Seal or scientific ROOT.

C194/C200 remain immutable. Prior target400/parent-gate exposure is disclosed; this is not a fresh universal decoder. The only mathematical conclusion associated here is the C156 root `middleFromCache_total_le ≤ 400*(k+1)^2`, not C194's source-derived exact counter formula.

## Source → OWN artifact → consumer

| Link | Inspected evidence |
| --- | --- |
| Reviewed C183 source → C189 source | Both SHA256 `ae139e0c0175f283e096f3803790c945f8cf23d339dead23a9cdf0f42fcc0b58`; original-author ZIP entry has the same bytes |
| Source → recorded OWN olean | Recorded exit0, 24.922s; current file hash `21569e2b203c086a2107de0337198ffca2ebc75b4d13ed100395fd153cf94c10` matches result |
| OWN olean → consumer | Raw consumer --deps names that exact stage's OWN CachedMiddleCostProof.olean; result's selected-provider hash equals the OWN hash |
| Consumer source → output | Source/archive entry hash `98edea18e9ca38de656c0e4804941ebb8fa1752e6276d9005d01de39f1fe12a3`; recorded exit0, 23.093s; consumer olean hash `1943973d2e00035862d6a14f4958c0d371bb035ff225b82973a2c2921331bd8b` |

Raw stdout/stderr/dependency entry hashes were recomputed directly inside the private ZIP and match the recorded values. Neither runner nor archive source was executed. The actual Lean binary file hash matches the recorded/sealed `dd86e9b24990b1da425ea4af910f016e4db8f9a25c9ddad27bc6bee3690e677f`. The selected primitive provider file matches `77547431cc9e4759adcd8c25f6a3e57622da492bdb31ac36f2061ab06e50d473`.

The proof-source raw stdout contains only three unnecessarySeqFocus linter warnings and **zero axiom rows**. The source contains no `#print axioms`; zero rows therefore are not evidence of an empty axiom set. The runner explicitly permits this source shape and requires the consumer's single root row.

The consumer raw source imports the new proof output, then `#check`s the root against the explicit sealed type: all k : Nat, e : Rat and a : Vector Rat (k+1), no additional premise, with eight-counter total ≤400*(k+1)^2. Raw stdout prints that exact proposition and one axiom row for `HermiteCachedPiecewiseStored.middleFromCache_total_le`: **propext, Classical.choice, Quot.sound**. This root report traverses its actual declaration dependencies in the loaded environment; it is meaningful coverage of the named root, unlike the source's zero rows. It is not an audit of every declaration in every imported module or of external source semantics.

## Runner, selection and historical boundaries

The inspected C189 runner constructs an isolated stage, binds original source ZIP entries, pre/post checks its pinned source/definition/binary context, selects the actual Lean binary and runs proof then consumer sequentially. Its recorded command uses 2048MiB, j1 and 180s per module; reserve is 2048MiB and admission threshold4096MiB. Both --deps probes select the intended immediate provider. Recorded proof-result and all raw outputs are mutually consistent with that procedure.

Important limits:

- Inherited C155/C159 and C23/C22/C21/project/Mathlib oleans remain part of the context. This reviewer did not rebuild them or independently rerun the runner's full pre/post pin assertions.
- --deps supplies direct dependency resolution evidence, **not a transitive runtime loader trace**. Requested LEAN_PATH plus --deps does not certify every actually loaded transitive binary or all source-to-binary relationships.
- Private prefix/package output includes a **dirty Verso repository warning**. The report is not a pristine-environment or whole-clean-TCB result.
- The consumer prints the root type and axioms, not elaborated proof bodies or actual loaded definition bodies. Raw source/static comparison is not a substitute for a missing printed-body audit.
- The runner derivation records changed author/stage bindings and a 3072→2048MiB cap / 5120→4096MiB admission threshold. Earlier failed stages and source versions remain historical, not retrospectively accepted. C182's optional failure packet was not needed or opened here; its exact failure/repair history is not newly audited by this association.

No independent compiler, lake, provided script, Git, network or subagent call was made. No older frozen packet or runtime record was edited. C183's author manifest is referred to by the inspected runner/result but was not separately opened or promoted as mathematical authority.

## Scope of acceptance and stop

This supports the recorded focused **one-root** compile/type/ordinary-axiom association under its inherited pinned context. It does not establish complete returned-chain value+cost integration, full producer cost, native integers/conversions/index control, Rat bitlength/GCD, allocation/runtime, physical sharing, captured actualBlocksQ setup, kernel/left scalar work, angles/gates/ancillas, uniform executable error, source-publication admission or scientific ROOT.

C194's (35K^2+44K-4) exact formula remains a source-level reconstruction, **not Lean-certified by C189**. C200's static 384K²≤400K² analysis remains a separate evidence phase. No additional mathematics is silently credited to the runtime record.

Freeze REVIEW.md, INPUT_MANIFEST.json and RUNTIME_ASSOCIATION_SEAL.json; stop. Further independent mathematics or gates require separate parent authorization. This seal binds this bounded review, not an independent rerun or a universal independence/Proof Seal claim.
