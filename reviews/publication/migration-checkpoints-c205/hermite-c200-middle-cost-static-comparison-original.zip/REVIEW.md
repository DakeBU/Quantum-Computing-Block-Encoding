# C200 static comparison: actual middle-cache cost

Verdict: **no mathematical accounting discrepancy found in the authorized C183 proof source** against the previously frozen C194 source reconstruction. This is a static source/proof comparison only; compilation, kernel validation, loaded-provider/type/axiom inspection and runtime evidence are outside this verdict.

C194's three originals remain unchanged. The opened proof is solely `hermite-c183-middle-cost-repair/CachedMiddleCostProof.lean`, SHA256 `ae139e0c0175f283e096f3803790c945f8cf23d339dead23a9cdf0f42fcc0b58`. No C183 audit/manifest/consumer, C176/C182/C189 runtime/failure/result packet, C192 public metadata, or other review was opened. The C183 source header's references to earlier failures are not a review of those artifacts.

Exposure: numerical target 400 and parent-reported gate statuses were already known. This reviewer is not a fresh universal decoder. C194 was frozen before C183 was opened, and the current comparison does not revise that reconstruction to match the proof.

## Claim and binders

The public root is exactly `HermiteCachedPiecewiseStored.middleFromCache_total_le`: all natural k, all rational e, all `Vector ℚ (k+1)` a, with conclusion `total (middleFromCache k e a).cost ≤ 400*(k+1)^2`. The source signature matches the C156 seal after whitespace-only normalization. There is no positivity, cache correctness, nonzero denominator, normalized source, callback-cost promise, or other public premise.

## Accounting comparison

Write (K=k+1\ge1).

| Obligation | Actual C183 proof mechanism | Static result |
| --- | --- | --- |
| Eight-counter total | `c176_factorials_total` instantiates `factorials_cost_le` separately at field/sqrt/angle/trig/compare/read/write/emit, then sums | Correct factor 80, not 10; at n=2k+1 this is 320K² |
| Both weighted vectors | `c176_weighted_total` counts sigma power once, first collect's read+two muls, second collect's read+pow+mul | Bound 14K² valid uniformly over signed e,a |
| Guard branches | First/second helpers case-split on the original two-conjunct dependent guards and use dif_pos/dif_neg | Both original guards and index proofs retained; false cost2, true cost9 |
| Actual choose quotient | Uses original `chooseFrom_cost`: three reads + two fields | No free binomial callback or coefficient-correctness assumption |
| Sum's zero suffix | `c176_sum_total` induction adds n to the sum of entry totals | Counts n additions, including final add-to-zero, not n-1 |
| Collect traffic | `c176_collect_total` expands canonical total and collect_cost | Exactly 4n extra: two reads and two writes per element |
| Outer table | Two K-term sums bounded by 10K each, then one qAdd; outer collect length2K | 40K²+10K ≤50K² |
| Actual returned data | Root instantiates table helper on `(factorials (2*k+1)).value.values` and `(weightedSources k e a).value` | Actual F and actual weights are used, not a substituted oracle |

Details important for the weighted phase: the local `first` captures `(powQ (-1) (k+1)).value`, exactly the scalar supplied by the original sigma bind. Its cost is three ticks per entry, not another sigma power per entry; sigma's K fields are separately included in `hcost`. `second` has entry total (i+2\le k+2). With canonical collect traffic, the displayed helper estimates give

\[
K+7K+K(K+5)=K^2+13K\le14K^2.
\]

This concerns the literal Run.cost annotation. It does not establish physical evaluation sharing or absence of extra eager work.

For each term, the original `2 • tick .compare` survives on both guard outcomes. An active branch adds one weight read, the three-read/two-field chooseFrom, and one multiply: seven more ticks, giving nine. Both generic guard helpers discharge this estimate for every actual F/u/v; no caller bound is inserted into the public root.

`c176_table_total` applies the two sum helpers to precisely `middleFirstTerm k F weights.first j` and `middleSecondTerm k F weights.second j`. Root `ht` then supplies the actual returned table and weights. `simp only [bind, Run.bind] at ht` and matching normalization in the root expose the same nested callback Run expressions; the normalization does not alter the callback or the charged operations.

The final root unfolds the original `middleFromCache` binds, uses total additivity, and combines

\[
80(2k+2)^2+14K^2+50K^2=384K^2\le400K^2.
\]

This matches C194's independent coarse derivation. Every correctness/cost premise of the generic collect/sum helpers is supplied by an internal term/entry proof at the use-site; none is an extra root premise. The reasoning includes k=0 and arbitrary zero/negative rational values, because branch selection is index-dependent and the rational primitives/power recurrence have value-independent annotations.

## What the comparison does not establish

C194's stronger source-derived exact identity (35K^2+44K-4) and its individual counter formulas are **not** asserted or proved by C183. C183 deliberately proves a coarser sufficient bound. They must not be advertised as Lean-certified exact counts on the strength of this comparison.

No compiler, lake, scripts, Git, network, subagents, consumer or runtime gate was run or read here. This review does not establish successful elaboration, ordinary-axiom closure, actual loaded provider equality, or semantic/compiler sharing. The selected provider context remains subject to the parent's separately authorized gates.

The bound counts the middle process on an already supplied a; constructing a via produceSourceCache is a separate outer cost. Its own factorial pass is included. Native index/guard arithmetic, conversions, Rat bitlength/GCD, allocation/runtime, captured actualBlocksQ setup, kernel/left scalar work, rotations/physical gates/ancillas, exported-state error, source-publication admission and scientific ROOT receive no credit.

## Handoff and stop

Failure class for this static comparison: none found. No source amendment, new hypothesis, target weakening, or proof repair is recommended on mathematical accounting grounds. Remaining uncertainty is precisely the separate actual compiler/own-output/provider/axiom gate and any later scope-appropriate review.

The retained `qbe-substantive-worker` protocol is used for evidence separation and boundary-preserving handoff, not as mathematical authority. Freeze REVIEW.md, INPUT_MANIFEST.json and STATIC_SEAL.json, then stop. Runtime inspection remains forbidden unless separately authorized by the parent. This static seal is neither a Proof Seal nor a universal independence/scientific acceptance verdict.
