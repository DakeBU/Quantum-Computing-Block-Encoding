# C194 source-first middle-cache counter reconstruction

Status: frozen source-only mathematical derivation, not a Lean theorem, proof comparison, or scientific acceptance. The exact operation counters below are reconstructed from the original definitions. No C176/C183/C182/C189 author, proof, feedback, result, or consumer was opened; no C192 public-cost package was opened. Static proof comparison requires separate parent authorization.

Exposure: this reviewer already knew the numerical target 400 from the C156 statement and parent-reported gate statuses. This is therefore not a fresh universal source-blind decoder. The derivation below did not use the forbidden cost-proof packages or their verdicts.

## Scope and primitive accounting

Write (K=k+1\ge1). The middle output has length (2K), its supplied coefficient cache has length (K), and its own generated factorial table is `factorials (2*K-1)`. The target concerns `middleFromCache k e a` for every signed rational `e` and every rational vector `a`, without correctness, positivity, nonzero-denominator, callback, or cost assumptions.

The eight counters, in the actual `Op` order, are field, sqrt, angle, trig, compare, read, write, emit. `StoredRectangularGivens.total` sums all eight once. `Run.bind` adds the first run's cost to the continuation cost at the first run's actual returned value. `pure` is zero-cost; `charge` adds exactly its tick.

- Each rational qAdd/qMul/qDiv has one field tick.
- `read` has one read tick.
- `collect` adds the costs of its actual entries, plus **two read and two write ticks per output cell**. It is not one aggregate operation or just an output write.
- `powQ x m` uses exactly (m) field ticks, including signed/zero x, by its fixed multiplication recurrence and the allowed C159 `powQ_cost` interface.
- Actual C23 `chooseFrom` performs three reads, one multiplication and one division: total 5, independent of F values and the numerical answer.
- Actual C23 `sumEntries` on length (m) performs (m) field additions **including the final addition to the zero empty suffix**. Its exact vector cost is the sum of all actual entry costs plus (m) field ticks, not (m-1).

Only field, compare, read and write occur in this process; the other four counters are exactly zero. The natural guards and factorial/choose index arithmetic have only the annotations literally present in this ledger; no native complexity is inferred.

## Guard-term reconstruction

Each first or second term reserves two compare ticks unconditionally, even on a false/short-circuit guard. A false guard returns pure zero: total 2. A true guard executes one weight read, actual chooseFrom and one rational multiply: another (1+5+1=7). Thus an active term has (field, compare, read, write) = (3,2,4,0), total 9; an inactive term has (0,2,0,0), total 2.

The guards, rewritten without changing their domains, are

\[
G_1(j,i): K\le j\ \land\ j-K\le i,
\qquad G_2(j,i): i\le j\ \land\ j-i\le K,
\]

with (0\le j<2K) and (0\le i<K). These guards depend on indices, not on signs or values of e,a,F. No source-coefficient correctness premise is needed to count them.

For the first guard put (r=j-K\in[0,K-1]). There are (K-r) accepted i, so the first active-pair count is (K(K+1)/2). For the second guard fix i: (j\in[i,i+K]), all inside ([0,2K-1]), giving (K+1) accepted j and (K(K+1)) active pairs. The total active-pair count across both sums is

\[
A=\frac{3K(K+1)}2.
\]

The fractions in this note denote exact integers where appropriate; parity follows from consecutive products, not truncated rational estimates.

## Factorial pass: exact counts and eight-counter conversion

The factorial base n=0 collects one pure cell, costing (field,compare,read,write) = (0,0,2,2). Extending from n to n+1 separately performs: one last-value read, two field operations, and `extend` of length n+2. The latter has n+2 reserved comparisons, n+1 old-value reads, and collect traffic (2(n+2)) reads and writes. Therefore the factorial-step increment is

\[
(2,\ n+2,\ 3n+6,\ 2n+4),\qquad\text{total }6n+14.
\]

Summing from the actual base gives, for `factorials N`,

\[
f=2N,\quad c=\frac{N^2+3N}2,\quad
r=\frac{3N^2+9N+4}2,\quad w=N^2+3N+2,
\]

and total (3N^2+11N+4). At (N=2K-1) this is (12K^2+10K-4).

Separately, the original C23 theorem `factorials_cost_le N op` is a **per-counter** upper bound (10(N+1)^2). Converting it through the eight-counter `total` gives (80(N+1)^2), hence **(320K^2)** here. Using (10(N+1)^2) as the total would omit seven counters. The exact reconstruction is stronger but is not needed to validate 400.

## Weighted vectors and outer table

The sigma power costs K fields. The first K-cell vector has K reads and 2K field operations, plus its collect traffic. The second has K reads and \(\sum_{i=0}^{K-1}(i+1)=K(K+1)/2\) fields, plus its separate collect traffic. These are two genuinely separate rational vectors; neither one scalar word nor one collect pass substitutes for both.

For every output j, the two K-term sumEntries each add K fields, and the final qAdd adds one more. Across 2K output cells this contributes (4K^2+2K) fields in addition to the active-term fields. Both guard families reserve (8K^2) comparisons in total. All active terms contribute (3A) fields and (4A) reads. The final outer collect adds 4K reads and 4K writes.

The exact four nonzero counters are consequently:

| Actual phase | field | compare | read | write |
| --- | ---: | ---: | ---: | ---: |
| Returned factorial table, N=2K-1 | 4K-2 | 2K²+K-1 | 6K²+3K-1 | 4K²+2K |
| Returned two weighted vectors | (K²+7K)/2 | 0 | 6K | 4K |
| Actual outer table, including both sums | (17K²+13K)/2 | 8K² | 6K²+10K | 4K |
| Entire `middleFromCache` | 9K²+14K-2 | 10K²+K-1 | 12K²+19K-1 | 4K²+10K |

The sqrt/angle/trig/emit columns omitted from the table are identically zero. Adding **all eight** counters gives the source-derived exact candidate identity

\[
\operatorname{total}(\operatorname{middleFromCache}(k,e,a).cost)
=35K^2+44K-4.
\]

At k=0, K=1 the algebra gives 75: factorial 18, weights 14, table 43. This is a boundary substitution in the symbolic derivation, not a run or finite simulator certificate.

## Independent coarse check of the frozen 400 bound

A second, deliberately coarser algebraic route does not require exact active-pair counting:

1. Actual factorial pass total ≤ (320K^2), using the correct eight-counter conversion above.
2. Exact weighted total is ((K^2+27K)/2\le14K^2), since K≥1 implies K≤K².
3. Every term total ≤9. Each of the two K-term sums therefore costs ≤10K after its K final-suffix additions. One output costs ≤20K+1; the 2K-cell outer collect adds 8K traffic. Its total is ≤ (40K^2+10K\le50K^2).

The actual bind composition is exactly factorials → weightedSources → outer collect, evaluated on the returned F and weights. All these bounds are uniform over those returned values, not assumed callback bounds. Thus

\[
\operatorname{total}(\operatorname{middleFromCache}(k,e,a).cost)
\le(320+14+50)K^2=384K^2\le400K^2.
\]

Source-level conclusion: the frozen 400 bound holds in the literal eight-counter scalar/word ledger for every k and all signed e,a. No positivity/correctness restriction or changed definition is needed. This independently derived statement is **not yet a checked comparison with a Lean implementation proof**.

## Input and acceptance boundaries

Raw inputs: C150 CachedMiddle; canonical StoredGivens and StoredRectangularGivens.total; actual C23 ChargedSourceCache factorials/extend/chooseFrom/sumEntries; allowed C159 powQ_cost. Exact hashes and the C156 signature context are in INPUT_MANIFEST.json. The complete retained repository skill/protocol intake is unchanged; `qbe-substantive-worker` governs the compact handoff, not the arithmetic conclusion.

The supplied vector a is already an input to middleFromCache. Producing it via produceSourceCache is a separate outer cost, not hidden in this bound and not free in a whole-producer claim. Conversely this middle process explicitly produces its own factorial table; it does not assume frozen C23 returned its private factorials.

This source-first packet certifies no compiled theorem, ordinary-axiom gate, cache value correctness, physical sharing, compiler evaluation strategy, native index/ceil/floor/clog work, Rat bitlength/GCD, full producer runtime, angle synthesis, physical gates/ancillas, uniform exported-state error, source publication, or full scientific ROOT. Captured actualBlocksQ setup and kernel/left scalar work remain unaccounted elsewhere. No compiler/lake/scripts/Git/network/subagents were invoked, no older packet was modified, and no forbidden proof package was opened.

Freeze boundary: stop after SOURCE_FIRST.md, INPUT_MANIFEST.json and SOURCE_FIRST_SEAL.json. Parent must separately authorize any static comparison. This seal binds a source-only derivation, **not** a Proof Seal, independence verdict, or accepted cost theorem.
