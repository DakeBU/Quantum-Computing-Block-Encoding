# Separate degree-provider runtime-association review

Classification: `INTERNAL_RUNTIME_ASSOCIATION_REVIEW`.

## Conclusion and limits

The inspected raw records support association of the exact sealed C147 provider
source with the recorded successful C149 local Lean compilation, its own
hash-pinned staged output, and the subsequent recorded definition/type/axiom
audit selecting that output. The actual printed six definitions and four
theorem types match the arithmetic objects and binders independently reviewed
in C151. No contrary evidence was found in this association slice.

This is a review of existing runtime evidence, not a new compiler run or a clean
rebuild. The association remains conditional on the recorded inherited binary
environment and the ordinary integrity of those records. It is not an end-to-end
source-to-binary certificate for all transitive dependencies, an effective
transitive module-loader trace, a Proof Seal, public-source review, or scientific
ROOT. No gate/rank/producer/finite-bit complexity or final state preparation is
certified by these records.

## Exposure chronology and independence

1. C151 completed the raw-definition-first static mathematical/binder review
   and froze six files before any author explanation, actual compiler output,
   axiom output or other review was received. Its seal is
   `f2ba65a06427e5cda134cd418c5bab22fd1778d107759cffd7c7228ab1664286`.
2. The parent reported reading that complete packet and explicitly authorized
   this separate runtime-association stage. All six C151 hashes were checked
   unchanged at this stage's start; their bindings are retained separately.
3. Only then were the named C149 records, runner/audit/parser sources and raw
   private archive entries inspected. This report is therefore runtime-exposed;
   it must not be relabeled as the earlier blind static review.
4. No C147 author DERIVATION or AUTHOR_MANIFEST contents, other review/catalog/PR,
   or C148 probe contents were read. The compile script itself refers to an
   author-manifest digest; reading that code does not verify the manifest's
   contents independently. The parent-supplied role permits internal review,
   not impersonation of a decoder or source-publication reviewer.
5. This packet freezes separately. C151, C147 sources/seals, C149 runtime records
   and all production/frozen source remain untouched.

## Exact source -> own output -> audit association

The actual staged `AllocatedDegreeBudget.lean` hashes to
`26768957c06cbdf32810c9ea8202404b615caaf51539dea9d64984f4539951cd`, exactly the
C151/C147 source binding. The actual staged `RootAudit.lean` hashes to
`cb40c47289755cacb3ff1732c89534d44cf0f89eb8168c3ba44d9b17a155465b`, also exact.
The two entries in `author-sources-original.zip` have those same byte lengths
and hashes; no author-manifest file was extracted or read by this reviewer.

The compile runner's inspected code checks the author manifest/context, copies
these two byte strings into a previously nonexistent exclusive stage through
a source ZIP, and invokes the pinned direct Lean executable with
`--root` set to that stage, `-o` set to its own output, memory limit 3072,
one thread and a 180-second subprocess timeout. Its version/prefix and package
path queries are distinct preliminary subprocesses. This reviewer executed none
of those commands or scripts.

`compile-result.json` records exit code 0, no timeout, 31.844 seconds, Lean
4.33.0 (recorded commit d8b18978322de05a8f3dba51ef03cf5461676c17), and executable
SHA256 `dd86e9b24990b1da425ea4af910f016e4db8f9a25c9ddad27bc6bee3690e677f`.
The presently addressed executable's bytes still match that hash, a read-only
current check, not independent reproduction of its past process execution.

The actual staged `AllocatedDegreeBudget.olean` is 158608 bytes and hashes to
`f1a5bac5c55cbcad7d6fb251d6a296a639cb925179e5fad9f2645eccc7512eda`, matching
the recorded compile output and audit import. The direct compile `--deps`
raw output has SHA256
`fbfe897174f2db5f3c3dbcd67775555511a6435241ed76503874f9779879c2cd`.
It names the inherited `piecewise-source-budget/.cache/PiecewiseSourceBudget.olean`
and two toolchain Init entries, not a prior AllocatedDegreeBudget binary.

The audit scripts independently require stage source/output hashes to match
the compile record, pin the same executable, put the own stage first in the
requested path, and query direct dependencies for the exact staged RootAudit.
Actual audit `--deps` output hashes to
`9396fee8f36581c997e7550e236b27a1a849ef8056e2da892369dc676609973a` and names the
own staged `AllocatedDegreeBudget.olean` plus two Init entries. This is stronger
than assuming that an arbitrary import named AllocatedDegreeBudget selected
the newly produced binary. It is still a dependency-resolution query in a
separate invocation, not an atomic loader trace of every module during the
subsequent audit invocation.

The v2 audit record reports exit code 0 and 23.328 seconds. Raw audit stdout
has SHA256 `b0460309650165ebf550c561b0ac55e86c4a8049e4e03c581ee4d696a1120b2d`;
raw stderr is empty. The public original and v2 definition/type/axiom files are
byte-identical to each other and have the same raw stdout hash. The four archive
entries stdout/deps/stderr were independently hashed in both private audit ZIPs.
Both archives carry the same stdout, dependency text and empty stderr despite
different ZIP container hashes. This supplies an exact output association, not
merely reliance on the success JSON's boolean fields.

The public compiler-feedback text was also independently reconstructed from
the raw compile stdout by the runner's stated path substitutions and newline
normalization; it equals the supplied public feedback exactly. No private path
text was copied to this packet.

## Actual definitions and theorem types

The six actual printed definition bodies are present at raw-output lines 2-57:

- `tailCutoff epsilon = Nat.clog 2 (max 1 (Nat.ceil (1/epsilon)))`, with rational
  division and natural-valued ceil/clog.
- `sourceDegree epsilon = degree (tailCutoff epsilon) (tailCutoff epsilon)`.
- `degree T b = 2*halfDegree T b-1`, with natural subtraction.
- `halfDegree T b = 2*T^2+b+1`.
- `sourceDelta k n epsilon = epsilon/(4*2^(n+1)*amplificationQ k)`, where the
  power base is rational and the exponent natural.
- `amplificationQ k = ((k : Rat)+1)^2 * (2 : Rat)^(2*k)`.

The explicit output therefore addresses the major inherited-provider semantic
risk for the objects actually used in this scalar estimate: the loaded
definitions are the literal objects reviewed in C151, not a desired-degree
replacement or a different allocation. This is not whole-module source/binary
equivalence for the provider modules.

Actual `#check` and `#print` types appear at lines 133-150, 1503-1541,
2650-2689 and 2966-3062. In ordinary mathematical notation they are exactly:

    t(e/2^m) <= m+t(e)                           (e>0)
    delta(k,n,epsilon) = [epsilon/(4*(k+1)^2)]/2^(n+1+2*k)
    t(delta(k,n,epsilon)) <= n+1+2*k+t(epsilon/(4*(k+1)^2)) (epsilon>0)
    sourceDegree(delta(k,n,epsilon)) <= 4*M^2+2*M+1         (epsilon>0),
    M=n+1+2*k+t(epsilon/(4*(k+1)^2)).

The natural k,n and rational epsilon binders remain as sealed. No additional
normalization, stored-rank, cutoff-bound, oracle or resource premise appears.
The exact root type retains sourceDegree/sourceDelta, n+1, 2*k and the cast of
the natural k+1 before rational squaring. Mathlib's actual printed ceil/clog
types and the actual degree_formula type are also present at lines 58-132.

The output prints theorem bodies, but includes `⋯` printer elisions even with
pp.proofs=true. This review inspected relevant type/body boundary regions and
cross-reference signals, not every elided proof term or a separately kernel-
rechecked serialized environment. In particular, the presence of `#print`
output is not a lossless proof-term export. The exact raw source proofs were
already fully statically reviewed in C151, before runtime exposure.

## Axiom output and the original parser failure

There are exactly five actual axiom-report rows: degree_formula plus the four
new declarations. Actual degree_formula reports `[propext, Quot.sound.{u}]`.
Each new declaration reports precisely

    [propext, Classical.choice.{u}, Quot.sound.{u}].

Universe suffixes instantiate the named ordinary axioms; they are not additional
axioms named u. These reports contain no sorryAx, Lean.ofReduceBool,
Lean.trustCompiler or other added axiom name. A full-text lexical scan of this
dump found no listed unauthorized marker. This is a review of the recorded
actual `#print axioms` results, not a fresh axiom computation, nor a claim that
the result is constructive or axiom-free.

The original wrapper uses `re.findall('[A-Za-z_][\\w.]*', axioms)`.
Independently applying that same token pattern to the actual raw four lists
produces `propext`, `Classical.choice.`, `u`, `Quot.sound.`, `u`. Its allowlist
assertion therefore must reject these lists. The code writes its private raw
ZIP and public text before that assertion, explaining why those outputs exist
while `audit-result.json` does not. The original wrapper's full process-failure
trace/exit record is not supplied here; its code and retained raw outputs
independently demonstrate the false-rejection mechanism. The successor record's
historical narrative is not substituted for an absent original process trace.

All six documented textual replacements in `c149-audit-parser-successor.json`
exactly reconstruct the actual v2 wrapper bytes from the original wrapper's
text. The edits add the parser import, use distinct v2 result/raw/public-output
names, call the universe-aware parser instead of loose token extraction, and
require the precise set of four expected theorem names rather than only length
four. No Lean source, executable hash expectation, dependency path construction,
axiom-name allowlist or production trust checker is changed by these edits.

The inspected parser accepts a complete dotted identifier followed by an
optional universe suffix, consumes separators and fails on malformed or
unconsumed suffixes. It does not drop an unknown axiom identifier: ordinary_only
still restricts names to the same three-name set, and the wrapper applies that
allowlist directly. The tests include plain/universe forms, an unknown dotted
name, sorryAx/ofReduceBool/trustCompiler examples, and malformed/trailing suffix
cases. The reviewer read those tests but did not run them and does not assert
an independently executed test pass.

Limits of this diagnostic parser: it is not a Lean grammar/parser or proof
checker. The row extractor is a regex over a trusted-format compiler transcript.
The v2 set equality does not by itself forbid duplicate expected-name rows;
the actual inspected transcript has exactly one row for each of the four names,
so there is no concrete duplicate-row issue in this artifact. The number six
for printed definitions is hardcoded in audit JSON, not dynamically checked by
the wrapper; actual inspection and a separate read-only count confirm all six.
The parser's empty-list support does not fabricate a missing theorem row since
the wrapper separately requires the expected-name set. No production trust
relaxation or new mathematical proof follows from fixing this diagnostic.

## Inherited binaries, dirty dependency, and path limits

The requested path order in both inspected runners is:

    own exclusive stage
    current project build/lib/lean
    inherited piecewise-source-budget cache
    package path returned by lake env

The raw package-path stdout was inspected in memory. It contains the expected
package build directories, including mathlib, a later duplicate project build
directory and the toolchain library directory. The actual prefix/version
queries and direct dependencies are retained privately. The compiler itself
is invoked directly, not through `lake env lean`; thus the requested path is
the explicitly constructed environment from the inspected code. No general
claim that Lake's effective environment governed that invocation is warranted.

The raw prefix/package stderr warns that the `verso` package repository has
local changes. This warning belongs to the preliminary Lake queries; actual
direct compile/audit stderr is empty. It is real dirty-dependency evidence and
must not be hidden behind a claim of a clean TCB. It is not itself evidence
that the scalar theorem is false or that verso was used in its proof term.

The runner pins 13 inherited cache binaries and four selected current-project
binaries, and records pre/post checks. This reviewer independently checked
that all 17 current file hashes still match that exact recorded map. The map
includes both current-project and legacy-cache variants of several
QuantumBlockEncoding modules with different hashes. Their simultaneous
presence is not evidence that both variants were loaded. Path ordering and
module namespace resolution matter; only the direct imported module selections
are explicitly evidenced by these `--deps` outputs.

The four sealed scalar-provider source files and toolchain/lake manifests were
pinned during the recorded compile, but those source hashes do not establish
that inherited olean files were freshly compiled from them. Actual six loaded
definition bodies and degree_formula's actual type/axioms provide relevant
semantic checks, not whole-transitive source provenance. In particular the
record does not pin every mathlib/package/toolchain library binary, every
transitive project binary, imported plugins/native support, or the complete
effective loader state. This reviewer has not inspected every inherited
module's declaration/axiom closure and has not rebuilt the dirty package.

The recorded pre/post input checks and our present-byte checks support stability
at those checkpoints. They do not provide an atomic immutable filesystem,
signed process attestation, continuous file-change monitoring or an absence-of-
race theorem. The compile wrapper does not dynamically prove every source,
binary and staged file remained unchanged throughout a subprocess. No evidence
of actual replacement was found; this limitation is not an invented mismatch.

The runtime JSON records do not themselves embed hashes of the runner/auditor
code. This packet binds the actual supplied script bytes inspected now; it
cannot attest independently that those exact wrapper bytes were the historical
process entrypoint. The imported private transport helper was not reviewed.
Current output hashes, archive-member identities and exact feedback/type data
are checked directly rather than treating an unexamined write helper as a
proof of provenance. Recorded exit codes remain record evidence, not signed
operating-system process attestations.

The C148 resolver-repair narrative in compile JSON was not independently
replayed or read in this stage. Current actual dependency records are sufficient
for the narrow association above; they do not retroactively turn a prior failed
probe into a proof or a clean source-rebuild gate.

## Warnings, unchanged scalar boundary, and appropriate consumers

Actual compile stdout retains unused/unreachable `ring` and `exact h` warnings
at the submitted proof's lines 30 and 77. The compile exit is recorded as zero;
the warnings do not indicate a missing goal proof, nor were they silently
removed by changing the frozen source. Cleanup, if wanted, needs a successor
source digest and new bindings rather than editing this sealed artifact.

The C151 interpretation survives actual type/definition exposure: D is a
chosen Taylor truncation index and the sum has D+1 terms. Its bound is not an
optimal/minimal degree theorem or a theorem giving the degree of the complete
piecewise source; the separate middle polynomial has degree bound 2k+1.
At fixed k,epsilon the scalar cap is quadratic in the existing n_p=n+1
parameter. No runtime association turns that fact into stored-chain rank or
addresses, C22/C23 producer cost, rational bitlength/GCD bounds, physical gates,
synthesis, cleanup, saved-export error, or original-root closure. The historical
exact-real 2k+6 bond remains unusable as an automatic certificate for the
precision-dependent source. The existing source/radius epsilon allocations and
scientific state/error contract are unchanged.

Appropriate use: cite the C151 independent mathematical derivation together
with these separately bound recorded local compilation/type/axiom checks when
describing this internal scalar parameter provider. Preserve inherited-binary
and dirty-dependency qualifications. A consumer requiring fresh source-built
TCB, production admission, source-publication independence or downstream cost
must supply its own missing evidence. This packet does not confer those labels.

## Required substantive-worker handoff

Objective/frontier: separately associate exact internal scalar-provider bytes
with actual recorded compile, own-output import and definition/type/axiom data.
Mathematical delta: no new theorem; strengthened runtime evidence association
for the previously independently reviewed arithmetic provider, with explicit
inherited/dirty/path/parser limitations.
Effect on root: local internal evidence only, no scientific ROOT closure.
Named evidence: INPUT_MANIFEST.json, ASSOCIATION_CHECKS.json, C151 static seal,
C149 recorded artifact and exact private-member hash bindings; no new Lean run.
Assumptions/conventions: ordinary integrity of recorded subprocess data;
existing natural/rational scalar domain and n_p=n+1, not new physical theorem.
Files changed: only new files in this isolated C154 output directory.
Reusable insight: distinguish source-byte pin, own binary hash, direct selected
import, loaded definition/type semantics and transitive source provenance;
none automatically implies all others.
Failure class: NONE for discovered semantic association mismatch. Original
wrapper's parsing is an IMPLEMENTATION_FAILED diagnostic false rejection,
not mathematical REFUTED or SOURCE_INVALID evidence.
Salvage: retain original failed wrapper/output and additive successor; no
cleanup or mathematical memory promotion performed.
Process-memory IDs consulted: none; required worker/role protocols were fully
read during C151 and retained in this same worker context.
Direction fingerprint: independent exact-byte runtime association after
pre-runtime static freeze; no script/compiler execution.
Expected information gain: detect stale-output import, source/own-binary/type
drift, fake axiom success, parser trust relaxation or inherited TCB overclaim.
Parallel admission: parent-authorized complementary worker role; no subagents
spawned and no other review used. No cross-route common-blind-spot certification.
Default verified route/comparator: none selected; single recorded provider.
Purification/Exposition Seal: not issued; proof warnings and downstream boundary
remain visible. No public-source/decoder/final-source-review credit.
Source/Lean expansion: C147 exact source/audit and C149 actual selected artifact,
six printed definitions/four types/five axiom rows; not every imported source.
Typed obstruction: clean transitive TCB/source-built association, full effective
loader trace and all downstream gates remain unsupported, not disproved.
Residual risk/confidence: strong consistency of supplied exact local evidence;
no independent subprocess reproduction, full transitive rebuild or attestation.
Recommended next step: consume only this narrow evidence class, or authorize a
separate clean rebuild/production admission process if that stronger assurance
is required. Stop here without expanding scope.
Context digest: C151 seal f2ba65a06427e5cda134cd418c5bab22fd1778d107759cffd7c7228ab1664286;
source 26768957c06cbdf32810c9ea8202404b615caaf51539dea9d64984f4539951cd;
own output f1a5bac5c55cbcad7d6fb251d6a296a639cb925179e5fad9f2645eccc7512eda;
actual audit stdout b0460309650165ebf550c561b0ac55e86c4a8049e4e03c581ee4d696a1120b2d.

Actual actions: read-only PowerShell file retrieval, line-region reads, regex
scans, byte/hash comparisons, in-memory ZIP entry inspection (no extraction),
textual successor reconstruction, current-byte checks and parent messages;
apply_patch only for new C154 outputs. No compiler, lake, provided Python
scripts/tests, Git, fetch, network, source editing or raw ZIP copying occurred.
No tooling failure occurred in this stage. Private ZIP entry paths were
examined but not copied into public candidate files; only logical relative
names and hashes appear here. Earlier C151 tooling incidents remain in C151.
