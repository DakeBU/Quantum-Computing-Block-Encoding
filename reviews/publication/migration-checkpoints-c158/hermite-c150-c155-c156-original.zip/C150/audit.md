# C150 executable-definition freeze and substantive-worker handoff

Status: EXECUTABLE_SOURCE_AUTHORED / NOT_TYPECHECKED / STATEMENT_SEAL_PENDING.
This packet contains three actual definition modules and one proposition probe.
No compiler, lake, mathematical theorem proof, provided script, network, Git,
subagent, production edit or C145 frozen-file edit was used. Candidate bounds
400 and 11 are not accepted. The parent, not this packet, performs the type
probe, exact-body review and StatementSeal before final proof search.

## Objective and implemented delta

Direction: `C145_ACTUAL_C23_CACHE_CONSUMPTION_IN_C22_SAME_CHAIN`;
implementation successor packet: C150. Original objective
`SP-HERMITE-POLY-002` remains the original normalized little-endian state.
Exact-real circuit closure is an inherited parent frontier, not a C150 result.
Full classical/finite-bit/executable/scientific ROOT is OPEN.

All three approved definition bodies are present, not only generic middle glue:

1. `CachedMiddle.lean`: charged powers, the literal specification `middleExpr`,
   two stored signed-weight vectors, guarded factorial-quotient binomial terms,
   and the actual full middle vector producer.
2. `CachedRightSetup.lean`: actual reciprocal/cutoff, step, four cuts, factorial
   table, tail coefficient vector, clipped value and rational midpoint, followed
   by charged threshold acceptance and all five actual right-boundary branches.
3. `CachedStoredProducer.lean`: one C23 source-cache bind, one concrete setup,
   one middle vector, actual QData table/boundary collections, existing castData
   and actual canonical ofTable on the returned data.
4. `PropositionChecks.lean`: seventeen candidate proposition-formation #checks.
   These are not theorem declarations or proof terms. The file has not run.

The old `actualBlocksQ.right` is never called by executable production. Its
only new executable-source textual mention is an explanatory comment; its
actual value use is confined to the proposition probe. `produceQData` likewise
is only the old output specification in that probe, not the new supplier.
`middleExpr` is a genuine literal specification, never used as a desired-output
implementation. Nat.choose occurs only in that specification, not in the
production path. No executable production calls the old `middleCoeffQ`.

## Exact same-returned-object reachability

`produceCachedStored` binds `produceCachedData`; that binds
`produceCachedQData`; that binds exactly one
`HermiteChargedSourceCache.produceSourceCache k`. The actual returned cache
value is passed as `a` to `middleFromCache k setup.midpoint cache`.

`middleFromCache` passes that a to `weightedSources`. Both weighted vectors
read a through the existing charged StoredGivens.read. The producer builds its
own counted factorial table for binomials, but does not rerun C23.sources or
produce source coefficients a second time. Each new j entry consumes these
weighted vectors through charged reads and the two explicit guarded sums.

`produceCachedQData` passes the actual returned middle vector to `rightEntry`
for every reindexed right-boundary address. Its third sum branch reads that
vector using the original polynomial index. Other right branches read the
actual returned setup.tailCoeffs or use its fixed clipped record scalar.

The exact returned QData is passed to the unchanged `HermitePiecewiseStored.castData`.
The exact returned RealData tables and both boundaries are then passed to
`QuantumBlockEncoding.StoredMatrixProductChain.ofTable`. No dummy cost object,
old data rerun, alternate desired state or arbitrary callback supplies this
composition. This is source-facing dataflow inspection, not a compiled
operational/semantic proof.

The new kernel/left collections still call the original captured block's
`.kernel` and `.left`, with identical fullEquiv and finProdFinEquiv indices.
Their scalar computation remains explicitly UNACCOUNTED. Capturing that record
does not execute its right function. We do not claim that syntactic reasoning
certifies a compiler's physical call count or counter-evaluation runtime.

## Actual operation audit: middle candidate 400

Set W=k+1 >=1 and S=sum i=0..W-1 i. Each power recurrence step is one charged
qMul; initialization is a literal one. Existing collect charges two reads and
two writes per entry. Existing C23 sumEntries charges its addition even when
adding the last term to zero.

Weighted vector counts, directly from this body's primitives:

| Stage | Field | Read | Write | Compare |
| --- | ---: | ---: | ---: | ---: |
| common sigma=(-1)^W | W | 0 | 0 | 0 |
| first vector | 2W | 3W | 2W | 0 |
| second vector | S+W | 3W | 2W | 0 |
| combined | S+4W | 6W | 4W | 0 |

Thus weightedSources total is S+14W at the source-annotation level, and is
at most W^2+13W <=14W^2 using S<=W*(W-1). There is no rational sign/power or
source read outside the charged primitives.

The generated factorial pass is `factorials (2*k+1)`, including persistent
copying. The existing bound is <=10*(2W)^2 per category; summing the eight
categories gives <=320W^2. This does not reuse an unreturned private factorial
table, assume an arbitrary table correct, or call a second source producer.

For one active first/second term, source annotation is exactly:
two comparison ticks, one weight read, three factorial reads, two binomial
field operations and one final multiplication. That is 4 reads +3 fields
+2 comparisons =9 total. The accompanying sumEntries addition makes at most
10 per i. A zero branch still reserves both comparisons and its sum addition,
so no skipped guard is silently free. The two sums at each j therefore cost
<=20W, their final addition costs one, and collecting all 2W middle entries
adds four storage ticks per j. This gives <=40W^2+10W <=50W^2.

Combining <=320W^2+14W^2+50W^2 gives <=384W^2; proposed 400W^2 still has
slack. This is a manual annotation audit, not an established parametric Lean
inequality. If the parent changes these bodies, the audit must be rerun before
sealing; no extra cost premise may repair a failed inequality.

Zero-binomial guards are substantive. The first term requires both W<=j and
j-W<=i before chooseFrom; the second requires i<=j and j-i<=W. Otherwise it
returns literal zero. The factorial quotient is never used outside its range.
The full j=0,...,2k+1 range and k=0 remain. The finite index proofs in those
calls supply only the upper factorial-table dimension.

## Actual operation audit: right candidate 11 and concrete setup

`acceptRun` performs one comparison for cut=0, possibly a second for cut=cap,
and possibly a third for a=0. A flipped acceptor performs one qSub. Thus its
candidate total bound is four. A right product consumes two acceptors, at
most one stored coefficient read, and two multiplications: <=4+4+1+2=11.
The fixed record fields are inherited fixed-size projections, not callbacks.
No accept factor, right product or coefficient array access is hidden in pure.

Actual setup annotation, with w=n+1, T=cutoffQ.value and d=degree T T:

- cutoffQ: one rational division; ceil, max and clog remain native-cost gaps.
- gridStepRun: w multiplications for 2^w, one numerator multiplication and
  one division. Natural cap computation is an explicit integer-cost gap.
- each of four cut helpers: one rational addition and one division; the two
  strict cuts charge one min comparison each, inclusive cuts also charge the
  negative-quotient comparison. Floor/ceil itself is not native-costed.
- minusT: one qSub. Natural-to-rational conversion is outside the ledger.
- generated factorial table through d: the actual C23 factorials run/cost.
- tail coefficient materialization: d+1 reads, d+1 divisions, and a full
  collect. Its annotation total is 6*(d+1).
- clippedRun: T power multiplications and two divisions.
- midpointFrom: one comparison. For T<=1 it returns the already computed
  clipped scalar. Otherwise it sums d+1 signed reciprocal-factorial terms:
  i power multiplications, one stored read and one division per i, plus one
  sum addition per i, including the last addition to zero.

For this exact body the manual total identity is

```
total setup.cost = total (C23.factorials d).cost
                 + w + T + 6*d + 27
                 + (if T<=1 then 0 else sum i=0..d i + 3*(d+1)).
```

This identity is only an audit of the annotations, not a checked theorem or a
new frozen proof target. The final candidate bound keeps the exact concrete
`total (rightSetup n R delta).cost`; it does not replace it by this identity,
zero, an assumed polynomial, or a caller cost hypothesis.

All scalar arithmetic in these setup/middle/right bodies uses charged
primitives. No transcendental exp call is introduced: midpoint is the exact
finite rational source. No arbitrary native-cost model for ceil/floor/clog,
casts, arbitrary-precision arithmetic or gcd has been defined.

## Binder and definition audit

Every new definition is literal deterministic rational/integer data and a
concrete Run; none uses classical choice, a quotient, an axiom, a proof-hole,
an arbitrary source-correctness/cost assumption, or a desired-output stub.

New structures expand completely as follows:

- WeightedSources k has exactly two Vector Rat (k+1) data fields.
- RightSetup n R delta has four Nat cuts, one Vector Rat (sourceDegree delta+1)
  tail-coefficient field, and two Rat fields clipped/midpoint. It has no
  correctness Prop, proof field, callback, normalization or resource promise.
- Imported Run alpha is value:alpha plus cost:Op->Nat. Imported RationalData,
  RealData and StoredChain have the existing stored arrays/chain constructors,
  with no source correctness assumptions hidden inside.
- Window is the existing finite-window universal entry equality, not an oracle
  or cost record. It occurs only as a proposed conclusion in the probe.

Public candidate binders k,n,R,delta and finite words/indices are TYPING/
construction data. hR:0<R is SOURCE only for the unchanged physical-grid
amplitude interpretation. No delta>0, R!=0, k>0, coefficient positivity,
denominator nonzero, cache-correctness, Window premise, cost bound or
normalization fact has been added. Those would be EXCESS at the Anchor.
Generic e,a,F,cut,width helper inputs are internal TYPING data, not assumptions
of the actual same-run source conclusion. Generated factorial correctness is
an eventual dependency, not an extra public theorem binder.

Only three proof-bearing syntax sites exist in the executable modules:
two factorial-table range proofs using omega, and `hd` using rfl for index
transport. `hd` says degree of the literal returned cutoff equals the existing
sourceDegree expression, definitionally. It permits returning the tail vector
at the required dependent dimension. It is not a proof of any requested final
value/cost statement. Proofs do not occur in PropositionChecks; #check terms
only elaborate propositions when the parent runs them.

The generic value target includes R=0 and all rational delta. The cutoff and
grid-step routines preserve Lean's literal division-by-zero convention, not a
new error/fallback behavior. For delta<=0 the reciprocal/ceil/clog still follows
the exact original formula. The midpoint T=0/T=1 branch is essential: these
cases must not silently use the active finite polynomial. All four cut rules,
strict/inclusive convention and zero/full cut cases are retained.

The exact five-constructor transcript is:

| Constructor branch | First acceptor | Second acceptor | Scalar |
| --- | --- | --- | --- |
| inl | strict(-1), unflipped | inclusive(-T), unflipped | clipped |
| inr/inl | strict(-1), unflipped | inclusive(-T), flipped | read tail[j] |
| inr/inr/inl | strict(-1), flipped | inclusive(0), unflipped | read middle[j] |
| inr/inr/inr/inl | inclusive(0), flipped | strict(T), flipped | clipped |
| inr/inr/inr/inr | inclusive(0), flipped | strict(T), unflipped | read tail[j] |

Signed powers and negative middle coefficients remain; Bernstein positivity
is not substituted. Source function, degree, radius, grid, basis/bit ordering,
normalizer and downstream quantum contracts are unchanged.

## Provider and gate plan

See providers.json for exact repository-relative provider paths/hashes and
new local imports. All 32 pinned input hashes from C145 were compared with
current source bytes and matched. The Lean toolchain and dependency manifest
remain exact input pins, not evidence a compiler ran. Parent-provided branch
commit values are inherited metadata; no current Git resolution was attempted.

The parent must supply fresh private outputs for these new modules, exclude
stale same-named olean providers, and inspect actual dependency selections.
Compile/type-probe order: CachedMiddle, CachedRightSetup, CachedStoredProducer,
PropositionChecks. The first three contain no final theorem proofs. Ordinary
production StoredGivens/StoredMatrixProductChain and C21/C22/C23 sources must
resolve to their bound providers. Review IndependentConsumer is not imported.
All C23 arithmetic/sums/factorials/reads are explicitly qualified to avoid the
real StoredHermiteCoefficients/StoredTensorTrain alternatives.

No typecheck success, axiom cleanliness result, semantic validation, theorem
closure, publication acceptance, source-blind reconstruction or site gate is
asserted. After the parent probe/body audit, bind exact files and propositions
in a versioned StatementSeal; mathematical proof search starts only then.
Subsequent focused proofs/tests and full lake/Tests/publication/site gates
remain parent serialized. Preserve all failed source versions/logs. A failed
elaboration is API/implementation evidence, not negative mathematics.

## Source graph, Lean graph and unchanged boundary

The source construction remains finite-exp/source coefficients -> actual
signed middle -> the five mask/polynomial blocks -> physical-grid chain ->
normalized original target. C150 changes the classical supplier of this same
object; it adds no quantum representation. Its proposed Lean path is actual
C23 cache -> weighted/middle arrays -> right table -> same QData -> castData
-> ofTable. Counter edges compose separately through Run.bind and collect.
These are source-level call/dataflow edges, not a newly checked theorem graph
or elaborated proof-term graph.

The unchanged kernel and left scalar work, all native integer/conversion
costs, rational bitlength/GCD, allocator and compiler/evaluator execution,
finite-bit error control, complete extraction complexity and executable
scientific ROOT remain open. The joined candidate partial bound is precisely

```
816*(k+1)^2 + total (rightSetup n R delta).cost
+ 11*D + 9*passContainers n D
+ 20*D^2 + 30*D + 5*n^2 + 7*n + 31.
```

It charges actual source/middle/right/array/cast/canonical assembly work, but
does not certify the omitted work or the cost of evaluating its own counters.

## Required worker handoff and stop

Objective/frontier: actual C23 cache consumption throughout the C22
source-dependent slice. Mathematical delta this phase: executable same-chain
construction and explicit operation/interface audit. No accepted theorem delta.

Named evidence: the four Lean-text files plus this audit, providers.json and
manifest.json. C145 exact source anchors and interface inventory are reused;
all input bytes matched before phase-2 freeze. No finite computation was run.

Files changed: only new C150 directory. The four C145 files remain byte-bound
and unchanged. No existing artifact or historical failure was edited.

Reusable insight: charged cache reads must feed the real signed middle and
right arrays; replacing only a source formula or binding an unused cache cannot
certify integration. A counted second factorial pass is necessary under the
frozen C23 output API and does not duplicate its source producer.

Failure class: NONE for this uncompiled authoring phase. Type/API and
mathematical correctness uncertainties remain pending, not refuted. No new
failed compiler run exists. Prior C145 metadata/retrieval failures remain
preserved in its unchanged handoff; no cleanup was performed.

Salvage: three complete executable-definition candidates are retained even if
the parent later finds an index/elaboration prerequisite. Do not re-label
generic middle-only success as C22 integration. If an implementation bridge
fails, preserve the exact packet and diagnose it before changing the target.

Process-memory IDs: QBE-PM-LOW-TOKEN-CONTROL-PLANE and
QBE-PM-VERIFIER-SEMANTIC-LEVEL from the already-read protocol pack. No control
plane decision supplies mathematical authority. Method was raw-source-first
analysis followed by concrete definitions and manual operation audit.

Parallel/common-blind-spot status: parent-authorized distinct integration
uncertainty, no child agents. Independent C150 arithmetic/value review,
cross-route audit if needed, and source-blind admission remain pending.

Default verified route/comparator: unchanged original C22 is the inherited
baseline. This source candidate is not a verified default. No speedup claim.

Purification/Exposition Seal: NOT_STARTED; genuine-consumer, duplicate API,
canonical primitive, import, source/Lean topology and reader audits remain
after compilation/proof. All original boundary conventions are explicitly
preserved in proposed goals, not asserted certified by this text.

Residual risk: uncompiled Lean parser/elaborator compatibility, dependent
index transport in rightSetup, natural-sum/zero-binomial proof APIs, and
independent auditing of the annotation arithmetic. Confidence is high in
same-returned-object source reachability, moderate in unprobed elaboration.

Recommended next action: parent inspects exact executable files, runs only
the approved type/proposition probe, records fresh provider selections and
hash-bound diagnostics, then issues or declines the StatementSeal. Worker
stops now before mathematical proof search.
