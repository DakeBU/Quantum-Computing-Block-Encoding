"""Own finite arithmetic diagnostics; not Lean execution or a proof gate."""
from fractions import Fraction


def nat_ceil(x):
    return max(0, -(-x.numerator // x.denominator))


def cutoff(e):
    # Lean's field division by zero is total; positive tests do not use this case.
    inv = Fraction(0) if e == 0 else 1 / e
    z = max(1, nat_ceil(inv))
    return (z - 1).bit_length()


def degree(t):
    return 2 * (2 * t * t + t + 1) - 1


eps = sorted({Fraction(p, q) for p in range(1, 41) for q in range(1, 41)}
             | {Fraction(1, 2**j) for j in range(0, 81)}
             | {Fraction(2**j) for j in range(0, 81)}
             | {Fraction(2**j + s, 2**j) for j in range(1, 17) for s in [-1, 1]})
dyadic = allocation = 0
for e in eps:
    t = cutoff(e)
    assert Fraction(1, 2**t) <= e
    for m in range(25):
        scaled = e / 2**m
        assert cutoff(scaled) <= m + t
        dyadic += 1
    for k in range(13):
        amp = Fraction((k + 1)**2 * 2**(2*k))
        e0 = e / (4 * (k + 1)**2)
        for n in range(17):
            delta = e / (4 * 2**(n + 1) * amp)
            m = n + 1 + 2*k
            assert delta == e0 / 2**m and delta > 0
            cap = m + cutoff(e0)
            assert cutoff(delta) <= cap
            assert degree(cutoff(delta)) <= 4*cap*cap + 2*cap + 1
            allocation += 1

factor_all_signs = 0
for e in map(Fraction, [-3, -1, 0, 1, 3]):
    for k in range(13):
        for n in range(17):
            assert e / (4 * 2**(n+1) * ((k+1)**2 * 2**(2*k))) == (
                e / (4 * (k+1)**2)) / 2**(n+1+2*k)
            factor_all_signs += 1

print("classification=FINITE_EXACT_ARITHMETIC_DIAGNOSTIC_ONLY")
print("distinct_positive_epsilon=" + str(len(eps)))
print("dyadic_cases=" + str(dyadic))
print("allocation_cases=" + str(allocation))
print("all_sign_factorization_cases=" + str(factor_all_signs))
for label, e, k, n in [
    ("smallest_grid", Fraction(1), 0, 0),
    ("unscaled_boundary", Fraction(4), 0, 0),
    ("allocated_boundary", Fraction(8), 0, 0),
    ("middle_degree_separation", Fraction(2**40), 5, 0),
    ("tiny_epsilon", Fraction(1, 2**80), 12, 16),
]:
    delta = e / (4*2**(n+1)*(k+1)**2*2**(2*k))
    cap = n+1+2*k+cutoff(e/(4*(k+1)**2))
    print(label + ": " + str({"k": k, "n": n, "epsilon": str(e),
          "cutoff": cutoff(delta), "cap": cap, "degree_index": degree(cutoff(delta)),
          "bound": 4*cap*cap+2*cap+1}))
print("zero_tolerance_diagnostic_cutoff=" + str(cutoff(Fraction(0))))
print("status=ALL_ASSERTIONS_PASSED_IN_FINITE_DOMAIN")
