# Independent allocated Hermite scalar-degree review

Classification: `INTERNAL_STATIC_REVIEW`. Frozen before any author explanation,
actual compilation output, axiom output, or runtime association. This is not a
Source Anchor, source-blind decoder, final source-publication review, Proof Seal,
scientific ROOT, or executable/cost acceptance.

## Outcome and exact scope

No mathematical mismatch was found in the four submitted declarations under
their stated binders. The sealed root is a true scalar parameter bound by the
independent derivation below. Static source inspection does not establish that
Lean elaborated these bytes. No compilation was attempted and no compilation or
axiom verdict was consulted. The root uses precisely the existing literal
`HermiteFiniteExpDegree.sourceDegree (HermitePiecewiseSourceBudget.sourceDelta
k n epsilon)`; it does not redefine either object or assume its desired bound.

The important semantic boundary is that `sourceDegree` is a chosen Taylor
truncation index D. The defining Taylor sum runs over `range (D+1)`, so it has
D+1 summands, not D summands. D bounds a Taylor polynomial's degree; it is not a
claim of minimal or optimal approximation degree. Actual active `poly q D` can
have degree D as a polynomial in q, but selected tail branches return a
constant pair, and intermediate coefficient cancellations or specialized
evaluations can lower actual degree. The middle supplier has a different
polynomial construction: `endpointPolynomialQ` has degree at most 2k+1 and
`middlePolynomialQ` consequently degree at most 2k+1. This root is not a theorem
identifying the degree of a single polynomial representing the entire
piecewise source, nor a claim that its middle piece has degree at most D.
For large epsilon, D=1 can coexist with a larger middle-degree bound.

It is also not a stored TT-chain rank/address bound, a producer operation count,
a bitlength/GCD bound, an angle-synthesis or physical gate bound, an ancilla or
cleanup theorem, an executable uniform-error certificate, or root closure.
The original state/error budget is unchanged.

## Independent reconstruction from literal definitions

All arithmetic in this section is exact. Let k,n be natural, epsilon a positive
rational, and write n_p=n+1 (the parameter convention of the existing physical
grid). Define

    A = (k+1)^2 * 2^(2k),
    delta = epsilon / (4 * 2^(n+1) * A),
    e0 = epsilon / (4*(k+1)^2),
    m = n+1+2k,
    t(e) = clog_2(max(1, ceil_N(1/e))),
    d(T,b) = 2*T^2+b+1,
    D(T,b) = 2*d(T,b)-1,
    sourceDegree(e) = D(t(e),t(e)).

Here ceil_N is the least natural upper bound, not integer floor or rounding to
nearest; `clog_2(z)` is the least natural j with z<=2^j. Since 2>1 this
characterization holds also for z=0 or z=1. The max ensures z>=1. For positive e,
1/e>0 and ceil_N(1/e)>=1 already, but retaining the max makes the literal object
and saturation cases explicit. No real logarithm or floating-point conversion
is used in the proof.

### Why the original constants are compatible with the error allocation

The actual middle-coefficient formula is

    c(k,i) = sum_{a=0}^i choose(k+i-a,k)/a!,  0<=i<=k.

Each binomial is nonnegative and at most 2^(k+i-a)<=2^(2k), and 1/a!<=1.
There are i+1<=k+1 terms, so c(k,i)<=(k+1)2^(2k). On 0<=t<=1, t^i<=1,
and summing k+1 coefficients bounds the coefficient polynomial by
(k+1)^2*2^(2k)=A. Multiplication by (1-t)^(k+1) does not increase this bound.
This independently explains the two factors k+1 in the literal amplification;
the scalar accounting need not assume its correctness as a new root premise.
The raw module's `coefficientPolynomial_bound` uses the imported
`sourceCoefficient_upper` for the same coefficient estimate; this report does
not claim to have audited that imported theorem's complete dependency tree.

The exponential enclosure has width <=delta, and its midpoint error is
<=delta/2. Middle amplification therefore gives pointwise error <=delta*A/2;
the tails obey the same upper bound because A>=1. For N=2^(n+1), the raw module
derives Euclidean error <=sqrt(N)*delta*A/2. Its central grid entry is exactly 1,
giving a norm floor >=1. Normalization stability supplies a factor at most 2,
which cancels the midpoint half. Using sqrt(N)<=N for N>=1 gives normalized
source error <=N*delta*A=epsilon/4. This is why the actual allocation denominator
contains 4*N*A. Radius error remains a separate epsilon/4 contribution, and the
raw existing normalized-original theorem has epsilon/2, not a newly expanded or
reallocated budget. The degree theorem requires neither R nor L nor a vector
normalization hypothesis because it is an arithmetic bound on delta and D,
not a new proof of that normalized-state theorem.

### Why the chosen Taylor truncation formula has its displayed constants

For T,b natural, d=2T^2+b+1>=1, so natural subtraction is nontruncating:
D+1=2d and D=4T^2+2b+1. The product of the last d factors in (2d)! is at least
d^d, so d^d<=(2d)!. If |q|<=T, then

    |q|^(2d)*2^d = (2|q|^2)^d <= (2T^2)^d <= d^d <= (2d)!.

The Taylor radius is therefore <=2^(-d)<=2^(-(b+1)). The active interval width
is twice this radius, hence <=2^(-b). With b=T=t(e), the clog/ceil choice ensures
2^(-T)<=e. A tail branch already has width 2^(-T). This reconstructs why the
existing `degree_formula` gives 4T^2+2b+1 rather than an unmotivated desired
degree. This accounting does not assert the chosen degree is sharp: even the
module's uniform radius estimate is deliberately conservative.

### Dyadic cutoff bound

Take e>0 and arbitrary natural m. Put T=t(e), C=max(1,ceil_N(1/e)). The natural
ceil upper-bound property and clog property give, after exact natural-to-rational
casts,

    1/e <= C <= 2^T.

The positive power 2^m preserves order. Since e is nonzero,

    1/(e/2^m) = 2^m*(1/e) <= 2^m*2^T = 2^(m+T).

The right side is an exact natural cast. The ceil adjunction gives
ceil_N(1/(e/2^m))<=2^(m+T). Also 1<=2^(m+T), so taking max with 1 preserves the
bound. Applying `clog_2(x)<=j iff x<=2^j` yields

    t(e/2^m) <= m+t(e).

No asserted identity between ceilings and scaled ceilings is needed, and no
unsupported equality between logs is used. Positivity e>0 is sufficient. It
justifies the reciprocal identity with nonzero denominator; positivity of the
base/power justifies multiplication. A normalization or e<=1 condition is not
missing.

### Allocation and final bound

Literal multiplication and the power-addition identity give

    4*2^(n+1)*A = 4*(k+1)^2*2^(n+1+2k),
    delta = e0/2^m.

This factorization holds for every rational epsilon, including zero and
negative epsilon, because its denominators are positive and nonzero. For the
root's epsilon>0, k+1>=1 gives e0>0 and delta>0. The dyadic lemma therefore
applies internally, without a cutoff bound or tolerance-positivity oracle as a
new premise. Define M=n+1+2k+t(e0). Then

    t(delta) <= M,
    sourceDegree(delta) = 4*t(delta)^2+2*t(delta)+1
                        <= 4*M^2+2*M+1.

The last comparison is monotonicity on naturals. All powers in this step are
natural powers; all preceding rational powers have natural exponents. No
negative exponents are passed to a natural-power operation.

For fixed k and epsilon>0, C=2k+t(e0) is independent of n_p. The exact displayed
bound becomes

    4*n_p^2 + (8*C+2)*n_p + 4*C^2+2*C+1.

Thus the bound really exposes quadratic growth in the existing n_p parameter,
for fixed k and epsilon. It is not merely a size/bitlength bound with the
exponential N still hidden inside an unexpanded cutoff. Variation in k or
epsilon remains visible in C; it is not legitimate to treat C as universal
when those parameters vary. As an informal interpretation only,
t(e0)=max(0,ceil(log_2(4(k+1)^2/epsilon))). The actual formal route uses natural
ceil/clog and does not depend on this real-log identity.

## All four declarations: binder, definition, and call audit

1. `tailCutoff_div_pow_two_le (e : Rat) (m : Nat) (he : 0<e)`.
   e,m are parameters; he is the only logical premise. The proof computes
   C<=2^t using actual `Nat.le_pow_clog`, transports through casts, rescales a
   reciprocal, invokes actual `Nat.ceil_le`, includes the max-1 branch with
   `one_le_pow`, and applies actual `Nat.clog_le_iff_le_pow`. This is a general
   arithmetic helper, not a source state theorem. Every internal hceil/hpow/
   hinv/hscaled/hceil_scaled is produced inside the proof.
2. `sourceDelta_factorization (k n : Nat) (epsilon : Rat)`.
   No logical premises. Unfolding only the literal sourceDelta/amplificationQ,
   applying cast addition/one, div_div and pow_add, then congruence/ring proves
   the factorization. `((k+1 : Nat) : Rat)` equals `(k : Rat)+1`; there is no
   replacement by k and no discarded n+1. The exponent is the natural
   n+1+2*k, never a rational exponent. No choice, quotient, target definition,
   oracle, or hidden stored-data structure is introduced.
3. `allocated_tailCutoff_le (k n : Nat) (epsilon : Rat) (hepsilon : 0<epsilon)`.
   Natural parameters and one logical positivity input. It rewrites delta by
   (2), calls (1), and proves e0>0 by positivity. The denominator is
   4*(k+1)^2>0 even at k=0. It does not accept the bound as a hypothesis.
4. `allocated_sourceDegree_le` has the exact sealed parameters and expression.
   It unfolds existing sourceDegree, rewrites actual degree_formula, obtains
   (3), and applies natural monotonicity via gcongr. No norm floor, error
   lemma, runtime estimate, rank certificate, or old bond bound is supplied as
   a binder. Textual inspection shows no sorry/admit/new axiom declaration in
   this file; this is not a compiler-backed axiom audit.

For the internal binder classification, k,n (and m in helper 1) are TYPING
natural data, epsilon/e are rational data with a specified positive locus,
and positivity is the explicit arithmetic domain condition. Relative to the
seal, no EXCESS binder was discovered. The SOURCE labels in the provided seal
are not promoted here into an independent external-source fidelity verdict.

The provider's lexical call topology is

    literal cutoff + Mathlib ceil/clog -> dyadic lemma
    literal allocation + amplification -> factorization
    dyadic lemma AND factorization AND e0 positivity -> allocated cutoff
    allocated cutoff AND literal sourceDegree AND degree_formula -> root.

All AND tails are necessary for the indicated route. `import PiecewiseSourceBudget`
is a broad module-level import, not evidence that the new scalar root uses
every state-error theorem in that module. This topology is a static reference
audit, not an elaborated proof-term graph and not a source construction graph.
`RootAudit.lean` is only command text requesting future checks/prints. Reading
it supplies no actual theorem type, elaborated proof, or accepted axiom list.

## Mathlib and casting checks

The actual inspected Mathlib `Nat.clog` implementation returns 0 if its argument
is <=1, and for base>1 has the full Galois connection stated above. Actual
`Nat.le_pow_clog` is the forward consequence at reflexive cutoff bound.
`Nat.ceil` is the natural-valued lower adjoint of the natural cast;
`Nat.ceil_le : ceil a<=n iff a<=n` and `Nat.le_ceil : a<=ceil a` require no extra
nonnegative-a assumption. The rational specialization has the required ordered
semiring/floor structure. `Nat.ceil_pos` says 0<ceil a iff 0<a, explaining why
max1 is redundant on the positive domain but still literally retained.

The two `exact_mod_cast` passages in helper 1 cast inequalities between natural
C,2^T into rational inequalities and cast a rational inequality against a
natural 2^(m+T) back for `Nat.ceil_le`. Natural casts preserve order and commute
with powers/addition here. No floor is used in the provider, no natural
division approximates a rational denominator, and the -1 in degree has been
checked against d>=1. Static reasoning supports these moves but does not claim
the tactics elaborated successfully in the frozen environment.

## Boundaries, finite diagnostics, and concrete observations

- k=0 is valid: A=1 and e0=epsilon/4. n=0 is valid: n_p=1, not zero physical
  width, and the allocation includes 2^(n+1)=2.
- At e=1, ceil(1/e)=1 and t(e)=0. For e>1 the same t(e)=0 holds. Scaling can
  leave t=0; the dyadic inequality is an upper bound, not a universal equality.
  For k=n=0 and epsilon=8, delta=1 gives D=1 while M=1 and bound=7.
- At very small positive epsilon, reciprocals can be enormous natural values;
  the mathematical cutoff still changes only logarithmically. No unit-cost or
  finite-bit implementation follows from this fact.
- Epsilon=0 is excluded. Lean's total reciprocal convention makes t(0)=0,
  but that does not provide a zero-error exponential enclosure. Negative
  tolerance is likewise outside the root domain. The factorization alone is
  valid at both; it does not license removing positivity in consumers.
- The independent `finite_checks.py` uses only Python standard-library
  `Fraction`, integer arithmetic and integer bit lengths. It checks 28,775
  dyadic cases, 254,371 allocated-bound cases over 1,151 positive epsilons,
  k=0..12 and n=0..16, plus 1,105 all-sign factorization cases. All assertions
  passed. Exact output is retained separately. These finite checks are not a
  parametric theorem, Lean acceptance, a target-state replay, or complexity
  evidence.

## Consumers, non-consumers, and remaining graph boundary

Suggested scalar consumer: use this root instead of a bound that merely
mentions `Nat.size(max1(ceil(1/sourceDelta)))` when displaying n_p dependence.
A future operation-count supplier may substitute this bound into an independently
proved polynomial-in-D count, provided its costs include all real inputs,
storage/addressing, copying and coefficient evaluation. This report has not
read or accepted a particular producer implementation or its old reviews.

A future piecewise rank theorem must separately account for tail polynomials,
the middle polynomial's k-degree, interval masks, grid/radius dependence,
representation and physical bit order. Scalar polynomial degree alone does
not identify actual stored ranks or addresses. The historical exact-real
2k+6 bond cannot be silently reused for this precision-dependent source.
Any degree-to-rank bridge must be stated and checked for the actual chosen
source, not assumed as an input to this scalar theorem.

Still open here: stored-chain correctness/size, actual deterministic producer
costs and field-operation model, numerator/denominator growth and GCD costs,
finite-bit control, rotations/angles and synthesis, physical gates/depth,
ancilla and cleanup, exact root association, saved executable uniform error,
repository/Tests/site gates, independent source-publication decoder/reviewer,
purification and scientific root closure. No failure of these layers is
asserted; they are simply outside this evidence class.

## Independence, actions, and handoff

Objective/frontier: internal static semantic and parameter-accounting review
for original `SP-HERMITE-POLY-002`, not a replacement root.
Mathematical delta: independent full reconstruction of the literal cutoff and
degree bound, explicit fixed-parameter n_p polynomial, and semantic boundary
between truncation index, full piecewise degree and later cost layers.
Effect on root: supports one candidate internal parameter provider only; no
scientific, Lean, publication or runtime frontier is marked closed.
Named evidence: exact input hashes in INPUT_MANIFEST.json, four raw provider
declarations, actual four definition modules, raw Mathlib ceil/clog regions,
own finite arithmetic source and its retained output.
Assumptions/conventions: k,n natural; epsilon positive rational; n_p=n+1;
natural ceil and clog base2; exact arithmetic; old state-error budget unchanged.
Files changed: only new files in this review's isolated output directory.
Reusable cross-layer insight: expand allocation before taking the cutoff;
logarithmic cutoff turns explicit 2^(n_p+2k) amplification into additive
n_p+2k, but this is not a stored/costed implementation bridge.
Failure class: NONE for mathematical review. Tooling incident: an exploratory
rg call included a nonexistent Mathlib Algebra/GroupPower directory and printed
an OS path error; no mathematical conclusion was drawn. The initial combined
instruction reads were display-truncated; full AGENTS content and full worker
skill were subsequently delivered, and HARNESS was independently reread in a
nontruncated call before substantive target review. Both incidents are retained
here rather than silently recast as successful evidence.
Salvage: no failed mathematical route; own derivation is an uncompiled review
artifact, not promoted library memory.
Process-memory IDs consulted: none. Parent C148/C149 results, statuses/logs,
catalogs, PR content, author DERIVATION and AUTHOR_MANIFEST were not read.
The C147 directory filename listing revealed those filenames only, not contents.
Direction fingerprint: fresh raw-definition-first exact rational/natural
parameter, binder, boundary and cost-tier audit.
Expected information gain: detect cutoff/cast/factorization premise errors or
an exponential n_p term hidden by a size bound; distinguish scalar closure from
actual chain/gate/resource claims.
Parallel admission: parent delegated this complementary independent role;
this worker spawned no subagents. No claim about multi-agent efficiency.
Common-blind-spot review: no comparison with other reviews in this phase;
parent must reconcile independently after freezing.
Default verified route/comparator: none selected; only one arithmetic route
reviewed, with no compile acceptance.
Purification/Exposition Seal: not issued. This report preserves the scalar
spine and boundaries; it does not certify public-source or human-complete state.
Source/Lean expansion: raw provider and four supplied modules, with Mathlib
ceil/clog regions. Imported coefficient/radius/normalization dependencies were
not recursively reviewed; no whole-library audit is claimed.
Typed obstruction: no semantic obstruction discovered. Runtime association and
compilation gates intentionally not entered, not mathematical refutation.
Residual risk/confidence: high confidence in elementary mathematics on the
stated scalar domain; elaboration, exact compiler type/axioms, imported proof
acceptance and all downstream resources unassessed.
Recommended next step: preserve this static freeze, then separately authorize
association to exact actual compilation/type/axiom output if desired. Do not
retroactively rewrite this record after exposure. Publication/root admission
requires its own missing gates.
Context digest: seal 2c889ac8aff71c338437caefaa034f8641ecc880ed0f76629ca24c1ed029c4d3;
signature e520f2d1a2a8dbbf8e6aee5fac90f00984a8eec86f1f1e533ac8f96b88f0f938;
provider 26768957c06cbdf32810c9ea8202404b615caaf51539dea9d64984f4539951cd.
All task actions were read-only PowerShell retrieval/hash/search, the allowed
new-file apply_patch writes, execution of this worker's own bounded Fraction
diagnostic, and parent coordination messages. No Git/fetch/network, compiler,
lake, RootAudit execution, supplied script execution, production edit, frozen
source edit, or outside-output-directory write occurred.
