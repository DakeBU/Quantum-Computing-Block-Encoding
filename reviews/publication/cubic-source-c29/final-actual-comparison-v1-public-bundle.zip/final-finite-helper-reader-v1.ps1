param([Parameter(Mandatory=$true)][string]$GeneratedRecordPath)
# Read-only finite-expression semantic check for the 64+8+8 delta dot-product helpers.
# Does not run Lean. Explicit known typeclass arguments are erased, not kernel-replayed.
$records=Get-Content -LiteralPath $GeneratedRecordPath -Raw | ConvertFrom-Json -Depth 100
function Node {
  $t=$script:tokens[$script:pos];$script:pos++
  if($t -eq ')'){throw 'unbalanced closing parenthesis'}
  if($t -ne '('){return $t}
  $xs=[Collections.Generic.List[object]]::new()
  while($script:tokens[$script:pos] -ne ')'){$xs.Add((Node))}
  $script:pos++;[pscustomobject]@{items=$xs.ToArray()}
}
function S($n) {
  if($n -is [string]) { if($n -match '^\d+$'){return $n};throw ('unknown atom '+$n) }
  $a=$n.items;$h=[string]$a[0]
  switch -Exact ($h) {
    'nat_lit' {if($a.Count -ne 2 -or $a[1] -notmatch '^\d+$'){throw 'bad literal'};return [string]$a[1]}
    '@OfNat.ofNat' {if($a.Count -ne 4){throw 'bad literal arity'};return S $a[2]}
    '@Eq' {if($a.Count -ne 4){throw 'bad equality'};return 'eq('+(S $a[2])+','+(S $a[3])+')'}
    '@ite' {
      if($a.Count -ne 6 -or $a[1] -ne 'Rat'){throw 'bad conditional'}
      $c=S $a[2];$yes=S $a[4];$no=S $a[5]
      if($c -notmatch '^eq\((\d+),(\d+)\)$'){throw 'not a closed equality'}
      $l=[int]$Matches[1];$r=[int]$Matches[2]
      if($l -gt 7 -or $r -gt 7){throw 'test outside Fin8'}
      $script:closed++
      if($l -eq $r){return $yes}else{return $no}
    }
    '@HAdd.hAdd' {
      if($a.Count -ne 7 -or ($a[1..3] -join ',') -ne 'Rat,Rat,Rat'){throw 'bad addition'}
      $x=S $a[5];$y=S $a[6]
      if($x -eq '0'){return $y};if($y -eq '0'){return $x}
      if($x -match '^\d+$' -and $y -match '^\d+$'){return [string]([int]$x+[int]$y)}
      return 'add('+$x+','+$y+')'
    }
    '@HMul.hMul' {
      if($a.Count -ne 7 -or ($a[1..3] -join ',') -ne 'Rat,Rat,Rat'){throw 'bad multiplication'}
      $x=S $a[5];$y=S $a[6]
      if($x -eq '0' -or $y -eq '0'){return '0'};if($x -eq '1'){return $y};if($y -eq '1'){return $x}
      if($x -match '^\d+$' -and $y -match '^\d+$'){return [string]([int]$x*[int]$y)}
      return 'mul('+$x+','+$y+')'
    }
    'u' {if($a.Count -ne 2){throw 'bad function application'};return 'u['+(S $a[1])+']'}
    'w' {if($a.Count -ne 2){throw 'bad function application'};return 'w['+(S $a[1])+']'}
    default {throw ('unknown semantic head '+$h)}
  }
}
$out=for($i=0;$i -lt $records.Count;$i++) {
  $r=$records[$i]
  if($r.actualName -notmatch '\.dot8_delta_(delta|left|right)\._proof_1_\d+$'){continue}
  $text=$r.typePrettyExplicit
  if($text.Contains([char]0x22ef) -or $text.Contains([char]0x2026)){throw 'omitted type'}
  $text=[regex]::Replace($text,'\.\{[^}]*\}','')
  $binder=''
  if($text.StartsWith('∀')) {
    $found=$false
    foreach($v in @('u','w')) {
      $prefix="∀ ($v : Fin (@OfNat.ofNat Nat (nat_lit 8) (instOfNatNat (nat_lit 8))) → Rat),"
      if($text.StartsWith($prefix)){$binder=$v+':Fin8->Rat';$text=$text.Substring($prefix.Length);$found=$true;break}
    }
    if(-not $found){throw 'unexpected function binder'}
  }
  $script:tokens=@([regex]::Matches($text,'\(|\)|[^\s()]+')|ForEach-Object{$_.Value});$script:pos=0;$script:closed=0
  $xs=[Collections.Generic.List[object]]::new();while($script:pos -lt $script:tokens.Count){$xs.Add((Node))}
  $a=$xs.ToArray()
  if($a.Count -ne 4 -or $a[0] -ne '@Eq' -or $a[1] -ne 'Rat'){throw 'not a rational equality'}
  $left=S $a[2];$right=S $a[3]
  [pscustomobject]@{ordinal=$i+1;actualName=$r.actualName;binder=$binder;left=$left;right=$right;equal=($left -ceq $right);closedConditionalCount=$script:closed;unknownSemanticHeads=0}
}
@{schema='C29_REVIEWER_DELTA_HELPERS_SEMANTIC_READING_V1';records=$out;count=@($out).Count;failures=@($out|Where-Object{-not $_.equal});scope='All mathematical branches traversed, known literal/instance arguments erased; no Lean or kernel replay.'}|ConvertTo-Json -Depth 10 -Compress
