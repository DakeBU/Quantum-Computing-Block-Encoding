param([Parameter(Mandatory=$true)][string]$TypeRecordPath)
# Read-only restricted parser of the two actual pp.explicit types, not a Lean evaluator.
# It rejects unrecognized mathematical expression heads. Explicit universes and
# typeclass/proof arguments are not semantic-expression tokens in this reading aid.
$records=Get-Content -LiteralPath $TypeRecordPath -Raw | ConvertFrom-Json -Depth 100
function ReadNode {
  if($script:pos -ge $script:tokens.Count){throw 'unexpected EOF'}
  $token=$script:tokens[$script:pos];$script:pos++
  if($token -eq ')'){throw 'unexpected closing parenthesis'}
  if($token -ne '('){return $token}
  $items=[Collections.Generic.List[object]]::new()
  while($script:tokens[$script:pos] -ne ')'){$items.Add((ReadNode))}
  $script:pos++
  [pscustomobject]@{items=$items.ToArray()}
}
function Sem($node) {
  if($node -is [string]) {
    if($node -in @('a','b','c','d','j','n') -or $node -match '^\d+$'){return $node}
    throw ('unexpected semantic atom: '+$node)
  }
  $a=$node.items;$h=[string]$a[0]
  switch -Exact ($h) {
    'nat_lit' { if($a.Count -ne 2 -or $a[1] -notmatch '^\d+$'){throw 'bad literal'};return [string]$a[1] }
    'QuantumBlockEncoding.gridSize' { if($a.Count -ne 2 -or $a[1] -ne 'n'){throw 'bad grid size'};return 'N' }
    '@Fin.val' { if($a.Count -ne 3 -or (Sem $a[1]) -ne 'N' -or $a[2] -ne 'j'){throw 'bad finite index'};return 'J' }
    '@OfNat.ofNat' { if($a.Count -ne 4){throw 'bad OfNat arity'};return Sem $a[2] }
    '@Nat.cast' { if($a.Count -ne 4 -or $a[1] -ne 'Rat' -or $a[2] -ne 'Rat.instNatCast'){throw 'bad cast'};return Sem $a[3] }
    '@NatCast.natCast' { if($a.Count -ne 4 -or $a[1] -ne 'Rat' -or $a[2] -ne 'Rat.instNatCast'){throw 'bad cast'};return Sem $a[3] }
    '@HAdd.hAdd' { if($a.Count -ne 7 -or ($a[1..3] -join ',') -ne 'Rat,Rat,Rat'){throw 'bad addition'};return 'add('+(Sem $a[5])+','+(Sem $a[6])+')' }
    '@HMul.hMul' { if($a.Count -ne 7 -or ($a[1..3] -join ',') -ne 'Rat,Rat,Rat'){throw 'bad multiplication'};return 'mul('+(Sem $a[5])+','+(Sem $a[6])+')' }
    '@HDiv.hDiv' { if($a.Count -ne 7 -or ($a[1..3] -join ',') -ne 'Rat,Rat,Rat'){throw 'bad division'};return 'div('+(Sem $a[5])+','+(Sem $a[6])+')' }
    '@HPow.hPow' { if($a.Count -ne 7 -or ($a[1..3] -join ',') -ne 'Rat,Nat,Rat'){throw 'bad power'};return 'pow('+(Sem $a[5])+','+(Sem $a[6])+')' }
    '@Eq' { if($a.Count -ne 4){throw 'bad equality'};return 'eq('+(Sem $a[2])+','+(Sem $a[3])+')' }
    '@Ne' { if($a.Count -ne 4 -or $a[1] -ne 'Rat'){throw 'bad disequality'};return 'ne('+(Sem $a[2])+','+(Sem $a[3])+')' }
    '@ite' {
      if($a.Count -ne 6 -or $a[1] -ne 'Rat'){throw 'bad conditional'}
      $cond=Sem $a[2];$yes=Sem $a[4];$no=Sem $a[5]
      if($cond -notmatch '^eq((\()\d+,\d+(\)))$'){throw ('not closed finite conditional: '+$cond)}
      $numbers=[regex]::Matches($cond,'\d+')|ForEach-Object{[int]$_.Value}
      if($numbers[0] -gt 7 -or $numbers[1] -gt 4){throw 'unexpected Fin8 test range'}
      $script:conditions.Add(@{condition=$cond;selected=($numbers[0] -eq $numbers[1])})
      if($numbers[0] -eq $numbers[1]){return $yes}else{return $no}
    }
    default {throw ('unrecognized mathematical expression head: '+$h)}
  }
}
$result=foreach($r in $records) {
  $text=$r.typePrettyExplicit
  if($text.Contains([char]0x22ef) -or $text.Contains([char]0x2026)){throw 'omitted input'}
  $prefix='∀ (n : Nat) (j : Fin (QuantumBlockEncoding.gridSize n)) (a b c d : Nat),'
  if(-not $text.StartsWith($prefix)){throw 'unexpected binders'}
  $body=[regex]::Replace($text.Substring($prefix.Length),'\.\{[^}]*\}','')
  $script:tokens=@([regex]::Matches($body,'\(|\)|[^\s()]+')|ForEach-Object{$_.Value})
  $script:pos=0;$script:conditions=[Collections.Generic.List[object]]::new()
  $segments=[Collections.Generic.List[object]]::new();$current=[Collections.Generic.List[object]]::new()
  while($script:pos -lt $script:tokens.Count) {
    $next=ReadNode
    if($next -is [string] -and $next -eq '→'){$segments.Add([pscustomobject]@{items=$current.ToArray()});$current.Clear()}else{$current.Add($next)}
  }
  $segments.Add([pscustomobject]@{items=$current.ToArray()})
  if($segments.Count -ne 3){throw 'expected exactly two hypotheses and one conclusion'}
  $semantic=@($segments|ForEach-Object{Sem $_})
  [pscustomobject]@{actualName=$r.actualName;binders='n:Nat,j:Fin(N),a,b,c,d:Nat';semanticPropositions=$semantic;closedConditionalCount=$script:conditions.Count;allClosedConditionalTests=$script:conditions.ToArray();unknownSemanticHeads=0;omissionGlyphCount=0;tokenCount=$script:tokens.Count;universeParameters=$r.universeParameters;axioms=$r.axioms;valuesPrinted=$r.valuesPrinted;readingScope='Every mathematical branch is traversed; explicit typeclass/instance proof arguments and universes erased for this restricted semantic reading, not a kernel replay.'}
}
$result | ConvertTo-Json -Depth 12 -Compress
