param(
  [Parameter(Mandatory=$true)][string]$DecoderRoot,
  [Parameter(Mandatory=$true)][string]$CapturePublicRoot,
  [ValidateSet('Verify','Roots','Generated','Supplement','Native')][string]$Mode='Verify',
  [int]$Start=1,
  [int]$Count=50
)
# Read-only, ordinary JSON/text audit. Does not execute Lean, Git, or any captured argv.
# Rendering below is a labelled lossy reading aid, never an Expr serialization.
function ReadJson([string]$p) { Get-Content -LiteralPath $p -Raw | ConvertFrom-Json -Depth 100 }
function TextHash([string]$s) { [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($s))).ToLower() }
function Norm([string]$s) { [regex]::Replace($s,'\s+',' ').Trim() }
function Compact([string]$s) {
  $s=$s.Replace('_private.QuantumBlockEncoding.CubicStatePreparation.0.','priv.')
  $s=$s.Replace('QuantumBlockEncoding.CubicDiagonalOracle.','Q.').Replace('QuantumBlockEncoding.CubicStatePreparation.','S.').Replace('QuantumBlockEncoding.','B.')
  $s=[regex]::Replace($s,'\.\{[^}]*\}','')
  $s=[regex]::Replace($s,'@OfNat.ofNat Rat \(nat_lit (\d+)\) \(@Rat.instOfNat \(nat_lit \1\)\)','Rat[$1]')
  $s=[regex]::Replace($s,'@OfNat.ofNat Nat \(nat_lit (\d+)\) \(instOfNatNat \(nat_lit \1\)\)','Nat[$1]')
  foreach($t in @('Rat','Nat','Int')) {
    foreach($a in @(@('HAdd.hAdd','Add','add'),@('HSub.hSub','Sub','sub'),@('HMul.hMul','Mul','mul'),@('HDiv.hDiv','Div','div'))) {
      $s=$s.Replace(('@'+$a[0]+' '+$t+' '+$t+' '+$t+' (@instH'+$a[1]+' '+$t+' '+$t+'.inst'+$a[1]+')'),($a[2]+$t))
    }
    $s=$s.Replace(('@LE.le '+$t+' '+$t+'.instLE'),('le'+$t)).Replace(('@LT.lt '+$t+' '+$t+'.instLT'),('lt'+$t))
  }
  Norm $s
}
$ci=Join-Path $DecoderRoot 'runtime-ci3-successor/publicsafe'
$roots=@(ReadJson (Join-Path $ci 'actual-319-explicit.json'))
$generated=@(ReadJson (Join-Path $ci 'actual-450-generated-full-fields.json'))
$generatedOrdinals=@{}; for($i=0;$i -lt $generated.Count;$i++){ $generatedOrdinals[$generated[$i].actualName]=$i+1 }
if($Mode -eq 'Roots') {
  $roots | Select-Object -Skip ($Start-1) -First $Count | ForEach-Object {
    '{0}|{1}|{2}|private={3}|{4}' -f $_.ordinal,$_.sourceUserName,$_.actualKind,$_.actualPrivate,(Compact $_.typePrettyExplicit)
  }; exit
}
if($Mode -eq 'Generated') {
  $generated | Select-Object -Skip ($Start-1) -First $Count | ForEach-Object {
    '{0}|{1}|{2}|private={3}|{4}' -f $generatedOrdinals[$_.actualName],$_.actualName,$_.actualKind,$_.actualPrivate,(Compact $_.typePrettyExplicit)
  }; exit
}
if($Mode -eq 'Native') {
  $generated | Where-Object actualKind -eq 'axiomInfo' | ForEach-Object {
    $name=$_.actualName
    [pscustomobject]@{name=$name;proposition=Compact $_.typePrettyExplicit;explicitConsumers=@($roots|Where-Object{$_.axioms -contains $name}|Select-Object ordinal,sourceUserName);generatedConsumers=@($generated|Where-Object{$_.actualName -ne $name -and $_.axioms -contains $name}|ForEach-Object{@{ordinal=$generatedOrdinals[$_.actualName];actualName=$_.actualName}})}
  } | ConvertTo-Json -Depth 12; exit
}
$two=ReadJson (Join-Path $DecoderRoot 'runtime-two-signatures-successor/publicsafe/actual-two-type-records.json')
if($Mode -eq 'Supplement') {
  $two | ConvertTo-Json -Depth 3; exit
}
$probe=Get-Content -LiteralPath (Join-Path $CapturePublicRoot '06-probe-v5.stdout.raw.sanitized.txt')
$rawRoots=@($probe|Where-Object{ $_.StartsWith('C29_ROOT_JSON ') }|ForEach-Object{ $_.Substring(14)|ConvertFrom-Json -Depth 100 })
$rawGen=@($probe|Where-Object{ $_.StartsWith('C29_GENERATED_JSON ') }|ForEach-Object{ $_.Substring(19)|ConvertFrom-Json -Depth 100 })
$rawHeader=$probe|Where-Object{ $_.StartsWith('C29_BINDING_JSON ') }|ForEach-Object{ $_.Substring(17)|ConvertFrom-Json -Depth 100 }
$rawSummary=$probe|Where-Object{ $_.StartsWith('C29_SUMMARY_JSON ') }|ForEach-Object{ $_.Substring(17)|ConvertFrom-Json -Depth 100 }
$mismatches=@()
foreach($pair in @(@('root',$roots,$rawRoots),@('generated',$generated,$rawGen))) {
  $a=$pair[1];$b=$pair[2]
  if($a.Count -ne $b.Count){$mismatches+=$pair[0]+':count'}
  for($i=0;$i -lt [Math]::Min($a.Count,$b.Count);$i++) {
    foreach($property in $a[$i].PSObject.Properties) {
      $x=$property.Value|ConvertTo-Json -Depth 100 -Compress
      $y=$b[$i].($property.Name)|ConvertTo-Json -Depth 100 -Compress
      if($x -cne $y){$mismatches+=($pair[0]+':'+($i+1)+':'+$property.Name)}
    }
  }
}
$index=ReadJson (Join-Path $ci 'type-factor-index.json')
$defs=@{}; foreach($p in $index.definitions.PSObject.Properties){$defs[$p.Name]=$p.Value}
$factorFailures=@();$factorHashFailures=@()
foreach($row in $index.rows) {
  $expanded=$row.normalizedTypeFactorText
  for($i=0;$i -lt 1000 -and $expanded -match '\[F\d+\]';$i++) {
    $expanded=[regex]::Replace($expanded,'\[(F\d+)\]',{param($m) $defs[$m.Groups[1].Value]})
  }
  $record=$generated[[int]$row.ordinal-1]
  if($expanded -cne (Norm $record.typePrettyExplicit)){$factorFailures+=$row.ordinal}
  if((TextHash $record.typePrettyExplicit) -cne $row.typeRawTextSHA256){$factorHashFailures+=$row.ordinal}
}
$ellipsis=[string][char]0x22ef
$typeHoles=@($generated|Where-Object{$_.typePrettyExplicit.Contains($ellipsis)}|ForEach-Object{@{ordinal=$generatedOrdinals[$_.actualName];actualName=$_.actualName}})
$valueHoles=@($generated|Where-Object{$null -ne $_.valuePrettyExplicitAllowOpaque -and $_.valuePrettyExplicitAllowOpaque.Contains($ellipsis)}|ForEach-Object{@{ordinal=$generatedOrdinals[$_.actualName];actualName=$_.actualName}})
$native=@($generated|Where-Object actualKind -eq 'axiomInfo'|ForEach-Object{
  $name=$_.actualName
  @{name=$name;explicitConsumers=@($roots|Where-Object{$_.axioms -contains $name}|ForEach-Object{$_.ordinal});generatedConsumers=@($generated|Where-Object{$_.actualName -ne $name -and $_.axioms -contains $name}|ForEach-Object{$generatedOrdinals[$_.actualName]})}
})
$suppLines=Get-Content -LiteralPath (Join-Path $CapturePublicRoot '07-supplemental-two-types-v1.stdout.raw.sanitized.txt')
$rawTwo=@($suppLines|Where-Object{$_.StartsWith('C29_TWO_TYPE_JSON ')}|ForEach-Object{$_.Substring(18)|ConvertFrom-Json -Depth 100})
$twoMismatches=@();$twoFileMatches=@()
for($i=0;$i -lt $two.Count;$i++) {
  foreach($p in $two[$i].PSObject.Properties) {
    if(($p.Value|ConvertTo-Json -Depth 100 -Compress) -cne ($rawTwo[$i].($p.Name)|ConvertTo-Json -Depth 100 -Compress)){$twoMismatches+=@{row=$i+1;field=$p.Name}}
  }
  $textFile=Join-Path $DecoderRoot ('runtime-two-signatures-successor/publicsafe/actual-type-'+($i+1)+'.txt')
  $twoFileMatches+=([IO.File]::ReadAllText($textFile) -ceq $two[$i].typePrettyExplicit)
}
$table=ReadJson (Join-Path $DecoderRoot 'runtime-ci3-omission-correction1/publicsafe/all-generated-audit-table-reviewed.json')
$tableFailures=@()
for($i=0;$i -lt $generated.Count;$i++) {
  $a=$generated[$i];$r=$table[$i];$t=$a.typePrettyExplicit;$v=$a.valuePrettyExplicitAllowOpaque
  if($r.actualName -cne $a.actualName -or $r.typeTextSHA256 -cne (TextHash $t) -or $r.typeChars -ne $t.Length -or $r.actualTypePrettyOmissionGlyph -ne $t.Contains($ellipsis)){$tableFailures+=($i+1)}
  if($null -ne $v -and ($r.valueTextSHA256 -cne (TextHash $v) -or $r.valueChars -ne $v.Length -or $r.actualValuePrettyOmissionGlyph -ne $v.Contains($ellipsis))){$tableFailures+=($i+1)}
}
@{
 schema='C29_REVIEWER_READ_ONLY_ACTUAL_AUDIT_V1';rawRootCount=$rawRoots.Count;rawGeneratedCount=$rawGen.Count;
 allFieldMismatches=$mismatches;rawBinding=$rawHeader;rawSummary=$rawSummary;
 factorRows=@($index.rows).Count;factorDefinitions=$defs.Count;factorRoundTripFailures=$factorFailures;factorTextHashFailures=$factorHashFailures;
 correctedTableFailures=@($tableFailures|Sort-Object -Unique);rawTwoCount=$rawTwo.Count;rawTwoAllFieldMismatches=$twoMismatches;twoTypeTextFileMatches=$twoFileMatches;
 explicitTypeOmissionCount=@($roots|Where-Object{$_.typePrettyExplicit.Contains($ellipsis)}).Count;
 originalGeneratedTypeChars=($generated|ForEach-Object{$_.typePrettyExplicit.Length}|Measure-Object -Sum).Sum;
 originalGeneratedValueChars=($generated|ForEach-Object{$_.valuePrettyExplicitAllowOpaque.Length}|Measure-Object -Sum).Sum;
 originalValueOmissionGlyphCount=($generated|ForEach-Object{([regex]::Matches([string]$_.valuePrettyExplicitAllowOpaque,$ellipsis)).Count}|Measure-Object -Sum).Sum;
 typeHoles=$typeHoles;valueHoleCount=$valueHoles.Count;valueHoles=$valueHoles;
 explicitKinds=@($roots|Group-Object actualKind|Select-Object Name,Count);generatedKinds=@($generated|Group-Object actualKind|Select-Object Name,Count);
 explicitPrivateCount=@($roots|Where-Object actualPrivate).Count;generatedPrivateCount=@($generated|Where-Object actualPrivate).Count;
 unsafeCount=@(@($roots)+@($generated)|Where-Object isUnsafe).Count;kernelMissingCount=@(@($roots)+@($generated)|Where-Object{-not $_.kernelRootPresent}).Count;
 axiomUnion=@(@($roots)+@($generated)|ForEach-Object{$_.axioms}|Sort-Object -Unique);nativeConsumers=$native;
 sourceAgreement=$null;nativeAccepted=$false;policySufficiency=$null
} | ConvertTo-Json -Depth 100 -Compress
