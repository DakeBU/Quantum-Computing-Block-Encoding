# C29 independent source / actual-formal / runtime comparison v1

Status: SCOPED_SOURCE_AGREEMENT_WITH_NATIVE_TRUST_ADMISSION_BLOCKER. This is a new immutable successor, not an edit of phase 1, STATIC, or STATIC v2. It is not native acceptance, a local Lean run, canonical admission, purification, main completion, scientific ROOT closure, novelty, or a paper pre-proof seal.

The same reviewer first independently derived the complete natural source before seeing implementation, then performed the separately authorized static stages, and only now compared permitted actual formal/runtime records. Historical formalizer remains UNKNOWN. Author metadata v2 was written after authorized access to my STATIC feedback; it is not blind independent corroboration.

## 1. Separate conclusions

| Question | Independent result and limit |
| --- | --- |
| Natural mathematics / named source semantics | The phase-1 algebra and conditional claims agree with the inspected complete module and all 319 compact actual named types, including 50 private roots, seven opaque declarations, and all 11 structure constructor / 79 field-projection types. No source-internal counterexample, lost guard, extra scientific premise, or unconditional fake closure was found at this scope. Source agreement is scoped to these actual statements, literal definitions, chosen witnesses, and expressly open boundaries. |
| Actual observation integrity | The current target, nine project/config inputs, author embedded whole-module bytes, final 319 inventories, the 319+450 actual observations, corrected omission table, and the two supplementary types agree under the independently checked hashes and field comparisons. All 45 official sanitized ZIP members match the authorized expanded public directory. Historical provisional count/hash discrepancies are retained below, not silently repaired. |
| Type text completeness | The original generated type holes at rows 67 and 120 are closed by the exact actual supplement. Both new types were independently parsed through every mathematical branch. The original 96 generated value-text omissions (1004 U+22EF glyphs) remain; the supplement prints no values. No lossless Expr export or all-proof-token reading is claimed. |
| Actual axioms / trust | Nine generated `native_decide` axioms really occur. Their propositions, nine source callsites, recursive consumers, exact Lean 4.33 native implementation, and existing proof-trust scanner were checked. `isUnsafe=false`, kernel-presence records, and successful process exits do not make them axiom-free. The inspected policy/checker provides no positive authorization or generated-axiom gate for this native TCB. Native admission is blocked until that policy obligation is met or these sites are replaced by kernel-only proofs and fresh evidence. |
| Full generated cognitive scope | All 450 records were mechanically traversed, exact PP hashes/factors/axiom metadata checked, and every name/kind/universe inventoried. Detailed independent semantic reading covers the 80 finite delta helpers, two supplementary types, nine native propositions, all 11 constructors/79 projections, and generated row 233 including its value. The other 268 expanded generated PP type/value strings were not all manually read token by token; their exact per-entry scope is recorded, not inflated to full cognitive review. This is not a claim that ordinary Lean proofs require all PP proof tokens to be reread. |
| Broader publication / execution | The prospective binding `7f5ab60beda2037a81cf51fa12abb9d3325006bb810844ecd19b2d60e2dc6809` was compared across the authorized author and late decoder records, but the 202 ambient files were not independently replayed. No physical circuit, normalized state preparation, QSVT synthesis, implementation cost, or executable scientific acceptance follows. G01–G14 remain OPEN. |

No single combined pass flag can replace these six different answers. In particular, scoped source agreement does not turn the trust-policy result into true. The inspected source-level checker condition and generated-native policy sufficiency are different predicates.

## 2. Exact evidence and continuity

Logical roots `$PROJECT`, `$AUTHOR`, `$REVIEWER`, `$DECODER`, `$CAPTURE_PUBLIC`, and `$TOOLCHAIN_SOURCE` identify only the explicitly authorized roots. They deliberately expose no local host path. The input manifest binds 143 individually hashed allowed files, including the old reviewer artifacts, with per-file bytes. Hashing a referenced private artifact was not performed merely because a public JSON names its digest.

Core bindings:

- Natural source, original and metadata-v2 copy: `e3e594b40b44bd474a4c98cf61c052b5f2a42ec8082de8d6164bd4f1e1df3dc7`, 26715 bytes. Original source-freeze: `d47efeee0d299663d95ea35accb9bacd38db280f78445ae0893368c688aca388`.
- Whole target source: `d125f8c239bca1c15e6e4fa6e788df6dd8984394630cb2dcc9be8946c4cbcb55`, 166483 bytes. Author formal-context base64 independently reconstructs exactly these bytes; formal-context SHA is `22532e18fbf15d43d842b4c9e755d486046a36b505e50d235f66df6f1171b951`.
- Author metadata-v2 manifest: `5e00c0cb2e0bb2faa74fdf9ae0d609db4fa67da1e1a479439fa2bd4f238de44d`. Author packet: `84fbb4cdc064b5130a00bdeb61b3360d4f387b7f96289f0175c664fc33bd9a2a`. These are inputs, not independent acceptance labels.
- Final initial decoder seal: `c4d9fda6c04f66dbd2b5c2e355a561e309246910587c640cc182b27269fef4fe`; declaration reconstruction: `b7991c8b9afd286825e12b692788d23d106784937fda17f46c0f7e29ec532d0d`; prose reconstruction: `3e28048c4490516c819b0c1b12313aaa66ecf9667b236e6a73a65ce416af3c99`.
- CI3 successor seal: `c16a18a1266dc5e601be42485b330349c9d464e0f7d0b081cbe5764919ebea09`; omission correction seal: `a4d51e947c8837623e5fbf696ed986a088d77edf6e87f50e9bdeb8f21e5db13d`; two-type successor seal: `d68f3a41ff8c9b6a68d9e686e0cbfe090194613309dc5c7d33c03e0d1a089a3f`.
- Late packet: `ffe5d76e418e90c2572b39aa7c49dfa1ca4e80fc79ba3b06f9f4fd93f61fc5a2`; late seal: `edce7e29f8aea4c0b012e20e4cfb085e35350e7b6b19591def615c15ff1b32e5`.
- Official sanitized actual ZIP: `16b9eea539d58f5f097832de577f23d48ce96a3e52f099ca9a847d0b83c06a39`, exactly 45 members, every member matching its authorized public file. Ninety selected allowlist/derivation-receipt checks match; this checks public export consistency, not unread raw-log truth.

The final initial seal and final reconstruction count 319/269/50 including seven opaque roots. Earlier `input-binding.json` says 312/262, and `context-binding.json` plus the CI3 source-blind whitelist carry an old declaration digest `6343236f83a73c241041798a55f52ed7ea646bf343d6efd5bc5bea20dc995813` rather than the actual final `b799...` digest. The old closure digest is likewise provisional, not the final `40bb8fb99d84a5fa4eae86d214fea48214fbfe240c99deb33474915ad70247e1`. These old records cannot be used as if they were a complete final input seal. The late continuity packet explicitly distinguishes provisional telemetry from the final seal. Current independently checked final inventories and actual observations agree; history/timing of blinded cognition cannot be independently proven from these JSONs or from unavailable Git history.

The late decoder receipt hashes the author's context/packet and separately records the bridge-proposal digest `dd0dbde74165d072b195db93dd6751216d32474349c7c501b84cb1a31a63e31c`. It does not derive the author's broad publication binding or read author semantics. I now independently perform the scoped source comparison; I do not attribute this work to that receipt.

The captured newer target/probe/supplement processes have PIDs 9854/9878/9887, recorded exit codes 0, and durations approximately 43.493/46.504/4.327 seconds. The earlier CI3 target/probe were different processes (5652/5668). I did not run any of them. The newer target writes the fresh target olean with SHA `bf072be3d4df8ed32049b7f67db6e0223ebb7f48dd84035715683b983f18cf45`; the probe and supplement name that fresh path. The observed newer main stream reproduces every field of the older CI3 319/450 exported records; the supplement's two raw records reproduce every field of its decoder records and both standalone type files exactly.

This is captured runtime evidence, not my own compilation. Five local provider oleans were copied from an inherited build into the fresh prefix. The provider inventory explicitly is not a clean transitive build or complete load trace; native libraries outside its roots remain untraced. The captured actual Lean executable digest is `e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550`. Local 4.33 source hashes for Native/Decide/CollectAxioms match the permitted runtime provider anchors. No unsupported identity between the local Windows executable and the captured executable is inferred.

## 3. Whole named API, recursive binders, definitions

The target's 319 explicit roots are 117 `defnInfo`, 184 `thmInfo`, 11 `inductInfo`, and seven `opaqueInfo`; 269 are public and 50 private. All source-name, kind, private flag, and inventory-line comparisons between author formal inventory, final decoder reconstruction, and actual root records agree. Actual types were read in three compact batches; the truncated 158–167 region was separately reread. Compact rendering erases printed universe decorations and known redundant notation/instance prefixes and is labelled a reading aid, not a serialization or theorem-equivalence test. Full source and necessary providers were read in my earlier stages under unchanged hashes.

The recursively relevant project-owned source field audit from STATIC v2 covered 21 structures / 130 fields across target and providers. Actual target evidence supplies 11 structures / 79 field projections and all 11 constructors; I compared these actual dependent binders, not merely structure names. Proof fields are `thmInfo` even when their field text lacks an explicit `Proof` suffix. In particular actual generated row 132, `ExpandedControlledRyWorkspaceReadonlyWitness.angleConvention`, is a theorem returning the transparent angle proposition, not TYPING data. V2's correction of this classification survives the actual comparison.

Important exact distinctions survive elaboration:

- `LinearDiagonalInputBEContract` has a matrix, an embedding function, rational orthogonality, clean equality to X, a scale proof, and arbitrary inhabited cleanup/resource propositions. No injective/tensor embedding, actual ancilla reset, or link between its resource data and matrix follows just from these types.
- `ExactCleanBlock` is a weak stored clean-equality payload, not an orthogonality/executable certificate. `CubicDiagonalExactBEContract` separately adds orthogonality, but its generic `exactPayload.A` is not forced to D merely by the structure name or scale proof. The chosen Householder instance really assigns D, and its particular equality theorems supply that target fact.
- The chosen cleanup proposition is the already established clean-block equality, and its chosen resource proposition is one oracle-label resource equality. These literal choices are weaker than physical cleanup and gate synthesis. They are not secretly strengthened by a `complete` theorem name or the legacy comment calling this a root certificate.
- `CubicQSVTLocalSideConditions` stores degree 3, a Boolean true parity marker, and grid boundedness. `CubicQSVTExternalSemantics.mk` actually requires the certified input, an output exact payload, output orthogonality, output target X-cubed, and proofs of arbitrary supplied global-admissibility, cleanup, and resource propositions. The latter are not automatically the standard analytic notions. The consumer transports these data; there is no unconditional phase-list producer.
- The abstract norm bridge's predicate is arbitrary; the concrete `ratEuclideanDiagonalOperatorNormBridge` instead instantiates the genuinely non-vacuous, all-rational-vector squared Euclidean predicate. Its actual proof depends on one native axiom described below.
- `StandardRyCleanEntryScalarTier` has an arbitrary `Scalar : Type`, arbitrary maps, and a supplied range law. Formula strings do not impose real arccos/cos, injectivity, or linear rotation semantics. Actual universe `Type 1` on the backend/readonly structures correctly reflects their type-valued workspace fields; it is not a finite-qubit cardinality theorem.
- Arithmetic backend `compute` is only clean-correct by its literal contract. The symbolic workspace is Rat and the finite fixed-denominator overwrite backend is not asserted reversible. The separate modular add/sub compute steps agree with overwrite only on zero workspace, and their all-dirty left inverse is a genuine stronger transparent cleanup witness.
- Both generic cleanup records require one-sided uncompute-after-compute, not the opposite inverse. Readonly rotation preserves index/workspace on basis functions and does not assert signal action, superposition linearity, orthogonality, or resource semantics.
- `expandedAmplitudeOracleCleanBlockContract` is exactly the five-conjunct AND: transparent arithmetic computation, universal supplied-tier transparent angle law, **opaque** route cleanup, opaque extraction of this block, and the literal diagonal target equation. Readonly and transparent cleanup are not substitutes for the third conjunct; unitarity is not among the five. Its projections do not prove any missing conjunct.
- All seven source opaques are actually `opaqueInfo`, have `hasValue(allowOpaque=true)=true`, and have empty recorded axiom lists. They are not seven asserted kernel axioms. Their actual value expressions are not exported in the 319-root records, so I do not invent their body/default interpretation. Conditional APIs remain conditional regardless of those hidden values, and opaque names/empty axiom lists do not supply physical meaning.

Literal / characterized / choice / quotient classification is unchanged. Grid, matrix, folds, Householder formula, finite index decoding, error predicate, modular arithmetic and circuit lists are literal. Contracts are characterized predicates, not automatically inhabited implementations. Four-square family selection and the chosen matrix certificates use noncomputable choice; different representatives may change the off-clean matrix while preserving the proved clean target. No quotient construction is supplied that identifies all these matrices; there is no unique or canonical full dilation. Presence of ordinary `Quot.sound` in axiom dependencies is not evidence that such a quotient API exists.

## 4. Independent source construction graph versus actual uses

The node IDs and source regions below are my sealed phase-1 graph, not retrofitted author graph IDs. Ordinals refer to the actual explicit-root array unless marked generated. Nodes asserting boundaries are not mathematical successes. All formatting/headings inherit the next substantive region. Source 1–8 remains EXCLUDED(PROVENANCE); C50/source 493–502 remains EXCLUDED(PROCESS_METADATA); C51/source 504–507 remains EXCLUDED(PROCESS_NOT_CLOSURE). This exhausts the 507-line source together with the following 49 nodes.

| Node / source lines | Actual correspondence and independent result |
| --- | --- |
| C01 / 10–25 | Grid and rational carriers: 3, 54, 66–71 and Core/Matrix definitions; n is Nat, including zero. |
| C02 / 26–36 | 4–8, 55–56: O is rank-one first-column cubic amplitude, not normalized state preparation; n=0 gives zero. |
| C03 / 38–46 | 91–98: X and D are diagonal and distinct from O. |
| C04 / 47–50 | 2, 7, 15, 24, 36, 92: literal chosen epsilon/scales, not a synthesis accuracy proof. |
| C05 / 52–62 | 76–86, 214, 244–245: range, sixth powers and conservative norm bounds; no n>0 hypothesis smuggled in. |
| C06 / 63–68 | 87–89: exact small norm values; three native axioms, not general evidence or physical success. |
| C07 / 70–79 | 72–75, 269: initial-segment count and strict payload capacity. k<=m is retained for count; strict bound is retained for storage. |
| C08 / 80–85 | 68–71, 75, 270: rational exponent/ratio identities and count; not Hadamard phase/denotation. |
| C09 / 87–99 | 57–62: two-part supplied clean contract gives alpha B=O, conditional throughout. |
| C10 / 101–109 | 11–20: seven-label arithmetic transcript/layout and exact syntax resource count only. |
| C11 / 111–116 | 21–30: ten-label wrapper and 4n+p+4 auxiliary metadata; n=2,p=40 tuple verified arithmetically, native-dependent actual proof. |
| C12 / 118–129 | 31–42: eight counting labels with reject repair, retained row output, 8n+5 auxiliary metadata; tuple native-dependent. |
| C13 / 131–137 | No actual unconditional rank-one circuit theorem; G01–G05 still form the complete semantic tail. |
| C14 / 139–150 | 104–107: total literal rational reflection formula; unit norm and v0!=1 are theorem guards, not definition-domain restrictions. |
| C15 / 151–154 | 108–110: d=2(1-v0), nonzero and clean entry under the stated guards. |
| C16 / 155–162 | 117–122, including private column/row calculations: both rational orthogonality directions, not a single column alone. |
| C17 / 163–171 | 111–116 and generated finite helpers: dot/fold algebra; my parser checks all 64+8+8 actual specialized delta types. |
| C18 / 173–181 | 123–133: ancilla-major dimension 8N, remainder/quotient inverse and clean embedding; not the one-signal layout. |
| C19 / 183–192 | 126, 137–144: controlled direct sum and system-branch support. |
| C20 / 193–200 | 136–162: unique-term/nodup/filter/permutation/fiber reindexing and both direct-sum inner products. |
| C21 / 202–208 | 134–135, 207: clean diag(q) requires unit branches, nontrivial coordinates, and coordinate equations; X specialization proves its guard. |
| C22 / 210–213 | Direct pinned `Nat.sum_four_squares`; an existing external theorem, not a supplied algorithm/cost result. |
| C23 / 214–223 | 163–170 and generated 67 supplement: natural linear residual witnesses cast to Rat, unit branch and coordinate. |
| C24 / 224–231 | 208–215 and generated 120 supplement: cubic residual and N-cubed denominator; natural subtraction guard and actual Rat helper distinguished. |
| C25 / 233–239 | 168–170, 213–215: choice-based 8N orthogonal existence and clean target, not full-matrix uniqueness or gate production. |
| C26 / 241–246 | 101–103, 216 and actual constructors/projections: strong-to-weak forgetting only; generic target freedom retained. |
| C27 / 248–258 | 171–176, 217–219: chosen certificates really target X/D and scale 1, but weak cleanup/resource meanings stay weak. |
| C28 / 260–267 | 220–223: exact diagonal matrix multiplication gives X^3=D. |
| C29 / 268–275 | 224–226 and provider product certificate: product of extracted clean matrices, not clean block of the cube of one dilation. |
| C30 / 277–281 | 227–230 and actual local-condition fields: cubic polynomial / grid bound / degree and Boolean labels only. |
| C31 / 283–292 | 231–233 and full external constructor: target substitution needs the complete output supplier AND tail. |
| C32 / 294–308 | 177–183, 200: literal abs/diagonal/error predicate, epsilon>=0 and all rational test vectors. |
| C33 / 310–321 | 184–197, generated 233: diagonal action, square bound, finite sum and concrete non-vacuity; generic bridge is conditional; native dependency retained. |
| C34 / 323–333 | 198–207: supplied entry errors imply entrywise and concrete E bounds with no N factor; circle realization is an independent guarded tail. |
| C35 / 335–346 | 246–252, 314–318: opaque unitarity AND extracted block/target premises; verified candidate is only a function of a supplied contract. |
| C36 / 348–355 | 234–240: one-signal one-label tuple, no matrix/label denotation supplied. |
| C37 / 357–371 | 256–258, 277–281: arbitrary scalar tier law specialized to grid range; workspace parameter unused in this scalar interface. |
| C38 / 373–383 | 260–268: arbitrary workspace backend and symbolic Rat overwrite, no finiteness/inverse claim. |
| C39 / 385–390 | 269–275: finite Fin(N^3) overwrite and exact fixed-denominator readout, not reversible overwrite. |
| C40 / 392–400 | 264–268, 275, 279–281: known-premise implications/iff expose opaque obligation, not manufacture it. |
| C41 / 402–413 | Private 288: genuine two-case modular cancellation with workspace,payload<modulus. |
| C42 / 415–422 | 289–294, 297–307: actual modular cubic/linear clean agreement and all-dirty left inverse, also at n=0. |
| C43 / 424–431 | 285–287, 295–301 plus dependent constructors: generic one-sided inverse only. |
| C44 / 433–439 | 282–283 and actual angle/readonly projections: proof-valued angle, basis index/workspace preservation, not Ry semantics. |
| C45 / 441–450 | 308–313: literal five-input AND and its projections, with opaque cleanup/extraction still required. |
| C46 / 452–458 | 273–287, 312: first-two transparent suppliers exist; cleanup transparency is separate; no route-unitarity theorem added. |
| C47 / 460–472 | Author graph v2 typed partitions and sufficient-construction alternatives agree with source only under their declared heads; no route winner or missing tail inferred. |
| C48 / 474–481 | All stronger-consumer gaps below remain open; actual types/axioms do not add physical suppliers. |
| C49 / 483–491 | Circuit/Resources/BlockEncoding provider grammar and actual resource equalities: exact syntax counts and score fields, not hardware/asymptotic implementation costs. |

All substantive phase-1 deductions are retained. Examples that prevent over-reading still apply: (i) the zero endpoint forbids claiming a normalized nonzero prepared state for every n; (ii) for the rational reflection [[3/5,4/5],[4/5,-3/5]], its cube has clean entry 3/5 whereas the cube of the clean entry is 27/125; (iii) an arbitrary supplied scalar tier may use identity maps, so formula strings do not impose cosine; (iv) symbolic/finite overwrite loses dirty input, whereas the separate modular add/sub map really cancels on all dirty inputs; (v) in dimension zero the concrete error predicate still retains epsilon>=0, and in dimension one I versus zero at epsilon zero falsifies it. These are boundary/obstruction examples, not false assertions attributed to this source.

### AND / typed case partition / guarded OR audit

Actual uses preserve the full tails, not merely the author graph's edge labels:

1. Unit branch AND v0!=1 AND literal Householder formula AND finite-sum algebra imply reflection entry and orthogonality. Direct-sum orthogonality additionally needs the flattening/fiber correspondence for every branch. Clean diag(q) additionally needs every coordinate equation. Neither coordinate equality alone nor a circle label is sufficient.
2. Linear/cubic residual bounds AND four-square witnesses AND the corresponding literal rational vector give branch data. AND unit/guard/embedding/direct-sum proof then gives the chosen 8N matrix existence. The producer, realization, and cost tails are not included in this mathematical head.
3. The actual circle vector producer gives coordinate q unconditionally; `q^2+r^2=1` produces unit norm; the separate q!=1 guard is still required. To claim both matrix realization and approximation one also needs the independent supplied |q-a|<=epsilon error tail and epsilon>=0. Circle realization is not an OR alternative to the error proof.
4. The prospective rank-one arithmetic-wrapper OR counting alternatives each need their own complete semantic tail: interpreted denotation, unitarity, nonzero-column rejection, workspace/flag cleanup, and clean-block equality. Arithmetic also needs rotation/compute/inverse composition; counting also needs coherent counting/Hadamard phases/normalization. Neither is now supplied. They are not an AND requiring both circuits.
5. Direct cubic Householder existence, the clean-matrix product certificate, and a fully supplied QSVT output do not have identical theorem types. They can agree on the target-matrix equality head after the necessary forgetting/substitution; they are not unguarded alternatives to a common dimension/embedding/unitarity/resource theorem. The actual matrix product certificate does not compose dilations.
6. Branch/system equality versus inequality, finite-index exhaustion, natural modular subtraction cases, and diagonal equality/inequality are proof CASE_SPLIT / BOUNDARY_PARTITION, not SUFFICIENT_CONSTRUCTION_OR. The v2 classification refinement is substantively correct; matching mechanical tables is not a reason to relabel these cases.
7. Primitive candidate projections retain opaque unitarity AND existence of a block satisfying extraction AND target equality. Expanded projections retain all five literal conjuncts. Existing concrete arithmetic and modular cleanup witnesses do not prove the opaque cleanup/extraction predicates. No bridge iff supplies its right-hand opaque proposition from nothing.

### Seven quantum semantic slots

| Slot | Checked literal/conditional content; remaining scope |
| --- | --- |
| target | O=|a><0|, X=diag(j/N), D=diag((j/N)^3) are distinct. Only the chosen cubic matrix fixes its generic payload target to D. No normalized-SP theorem follows. |
| normalization | Rank-one selected alpha=N and counting ratio j^3/N^4 are distinct from diagonal scale 1; cubic norm bounds do not supply success probability/amplification. n=0 retained. |
| registers | Householder matrix uses ancilla-major 8N (three mathematical ancilla bits). Primitive labels use one signal. Declared workspace counts do not bound an arbitrary Workspace type. Fin(N^3)/Fin(N) arithmetic is finite, but no bit-gate synthesis is claimed. |
| oracles | Gate.oracleCall names have grammar/resource meanings only. Primitive opaque extraction/unitarity and expanded route predicates are still supplied obligations, not interpreted gates. |
| ancillas_phases | Actual modular dirty cancellation is proved as a basis function. Weak chosen cleanup is clean equality; counting rejection/Hadamard phases, common-backend signal action and physical ancilla reset remain open. |
| error_success | Concrete all-rational-vector squared Euclidean error is non-vacuous and follows from diagonal abs error with no N factor and epsilon>=0. No approximation producer, accepted-branch success rate, or finite-precision rotation is produced. |
| resources | Counts 7/10/8/1, depths and layouts are literal metadata, including native-checked diagnostic tuples. Classical four-square computation, uniform controlled matrix synthesis, hardware depth and gate costs are not supplied. |

G01 interpreted arithmetic/wrapper; G02 interpreted counting; G03 rejection/cleanup for all nonzero columns; G04 phases/accepted-path normalization; G05 normalized-SP success/amplification; G06 efficient four-square producer; G07 uniform controlled-matrix/gate realization; G08 physical product isolation/composition; G09 full QSVT phase/global/circuit supplier; G10 approximation producer and optional certified dilation; G11 actual coherent rotation/common-backend semantics; G12 transparent-to-opaque bridges; G13 physical expanded extraction/unitarity; G14 finite-bit resource/executable correspondence: all remain OPEN, not refuted source theorems. No actual captured type closes one merely through a suggestive name.

## 5. Generated types, omission correction, actual supplement

The probe stream has one binding record, 319 explicit-root records, 450 generated records and one summary record. There are 769 target-owned observed constants under the probe's ownership criterion. Generated kinds are 151 definitions, 268 theorems, 11 constructors, 11 recursors and nine axioms; 107 generated names are private. All recorded roots are kernel-present, all `isUnsafe` values false. All 450 generated records, including original PP text, match the official main stream field for field. The 2397-factor index reversibly reconstructs normalized-whitespace type text for every row, and all original type text hashes match. The 668 lossy family templates are not a lossless replacement or an independent mathematical proof.

Generated names include equation/matcher infrastructure under provider-related names such as `Gate.resource`, `Resource.ofCountsWithDepth`, `cleanBlockBy`, and `Fin.succ`. I retain the actual ownership inventory rather than assuming every target-owned name has a Cubic prefix. These infrastructure entries do not add a new scientific theorem or physical resource interpretation. The actual dependent constructor/field types preserve proof bundles; injectivity/noConfusion/recursor metadata are not new supplied quantum semantics.

Original generated type text totals 3075459 characters and generated value text 9891081 characters. There are 419 non-null values and 31 nulls (nine axioms plus constructors/recursors). The old omission Boolean missed U+22EF by checking another glyph; the reviewed correction table agrees independently with every current type/value hash, character count and U+22EF flag. The original 450-record export is preserved. Its two type holes occur only at generated 67/120. Its 96 value holes contain 1004 U+22EF glyphs and remain real printing omissions. I do not treat false old omission Booleans, non-null values, successful exit codes, or pretty-printer text as lossless Expr evidence.

The actual supplement is an additional observation, not a proof repair. It imports the same fresh target and records `pp.deepTerms=true`, `pp.maxSteps=2000000`, `maxRecDepth=10000`. Both actual helper types are `thmInfo`, have no universe parameters, are recorded kernel-present/unsafe-false/self-axiom-false, and have only `propext`, `Classical.choice`, `Quot.sound` dependencies. They print no values. Their text-file hashes are:

- Linear: `26aeb73e322a14e85f08704e63cf2035bbd8b33747e93ad45142c914eabd716e` (163920 characters, 163926 bytes).
- Cubic: `e5e14e533bc8093c80f58ca862700e8dd37d3207e69487808b6d0b993b52c278` (189640 characters, 189646 bytes).

My independent restricted reader checks the exact binders n:Nat, j:Fin(N), a,b,c,d:Nat; every recognized mathematical application head; every branch of each of the 80 closed Fin8 conditionals per type; and absence of U+22EF/U+2026. It erases explicit known instance/proof arguments and universe notation for semantic reading, not kernel validation. Its resulting actual propositions, with N,J,a,b,c,d cast to Rat, are exactly:

1. `N^2=J^2+a^2+b^2+c^2+d^2 -> N!=0 -> sumSquares[J/N,a/N,b/N,c/N,d/N,0,0,0]=1`.
2. `N^6=J^6+a^2+b^2+c^2+d^2 -> N!=0 -> sumSquares[J^3/N^3,a/N^3,b/N^3,c/N^3,d/N^3,0,0,0]=1`.

These are the expected intermediate **rational** equalities after casting the original natural square equations; they are not a new natural witness assumption or an n>0 guard. Clearing the nonzero denominator proves each by its premise; N^6=(N^3)^2. There is no hidden unitary, resource, circuit, external QSVT or positive-square-witness premise. This closes the two actual type-text holes at their precise scope. It does not close any of the 96 value holes.

My separate finite-helper reader traverses every mathematical branch in all 64 delta/delta and 8+8 left/right specialized generated types. The closed Fin8 conditionals reduce all 64 equalities to 0=0 or 1=1 and the other 16 to the appropriate u[k]=u[k] or w[k]=w[k]. This verifies the expanded finite algebra underlying the already read source helper statements, without pretending to be a Lean replay. The full per-entry reading receipt explicitly distinguishes these readings from the 268 residual infrastructure/type-family entries handled by machine integrity and ordinary proof-context reasoning.

Ordinary kernel proofs need not have every pretty-printed proof token manually read in order to use them under an accepted ordinary Lean TCB. Thus the 96 value printing omissions and the bounded cognitive reading of generated infrastructure are disclosed textual/provenance limits, not evidence that the corresponding ordinary proofs are false or automatic requests to reprint 9.9 million characters. They also cannot be invoked to hide the genuinely extended native TCB.

## 6. Nine actual native axioms: propositions, callsites, consumers

Every listed generated axiom is actually `axiomInfo`, has no value or universe parameters, is safe-flagged, occurs in its own recursive axiom list, and has type `Eq Bool (Decidable.decide P instance) true`. The table states the exact mathematical P; the complete printed proposition and independently recomputed consumer indices are bound by the actual record and mechanical audit.

| Source callsite | P and independent mathematical check | Actual explicit recursive consumers; generated non-self consumers |
| --- | --- | --- |
| 252 | Arithmetic rank-one tuple at n=2,p=40 equals (10,10,52,10); literal label/layout arithmetic agrees. | 29; none |
| 372 | Counting tuple at n=2 equals (8,8,21,8); literal eight labels and 8n+5 agree. | 41; none |
| 437 | All three stored schedules and level-cycle-budget lists have length 4; list literals agree. | 51; none |
| 441 | Stored lower schedule `getLast? = some 6`; literal list agrees. | 52; none |
| 771 | Cubic norm n=1 equals 1/64; direct sum of j^6/2^6 agrees. | 87; none |
| 775 | Cubic norm n=2 equals 397/2048; finite sixth-power sum agrees. | 88; none |
| 779 | Cubic norm n=3 equals 46205/65536; finite sixth-power sum agrees. | 89; none |
| 2465 | `(0:Rat)-0=0`; ordinary rational group arithmetic proves it independently. | 189 `ratMatrixErrorAction_eq_diagonal`, 196 `ratEuclideanDiagonalOperatorNormBridge`, 203 `approxDiagonalOperator_operatorNorm_error`; generated 233 `ratEuclideanDiagonalOperatorNormBridge._proof_1` |
| 2535 | For dimension 1, A=I, B=0 and v identically 1, it is NOT the case that `sqNorm((A-B)v)<=sqNorm(0*v)`; this is 1<=0, hence false. | 197 `ratEuclideanOperatorNormErrorAtMost_not_vacuous`; none |

Actual union: the ordinary three (`propext`, `Classical.choice`, `Quot.sound`) plus exactly these nine generated native axiom names. No `sorryAx`, source-authored `axiomInfo`, or extra foreign axiom name occurs in the observed 769-record union. The seven source opaques add none. This is a statement about the permitted captured axiom metadata and its consistency with all nine source callsites, not a universal unobserved-provider or kernel-replay claim.

The `hzero` axiom is not merely an isolated diagnostic. Its actual consumers include the concrete generic norm bridge and approximation norm theorem. I read generated row 233's type and full available ordinary proof value: it forms the epsilon conjunction, applies the private monotone finite fold, rewrites through `ratMatrixErrorAction_eq_diagonal`, then applies the scalar square bound. This confirms the mathematical path of that native dependence. The other eight native sites are restricted diagnostics/process metadata as tabulated; the underlying mathematics being elementary does not erase the recorded axioms from the actual environment.

### Exact native implementation and policy boundary

I read the complete pinned local `$TOOLCHAIN_SOURCE/Lean/Meta/Native.lean` (SHA `e1d0c6b5be42f492810a12281fc0d8ff4c981e421397c3ec00e165a255ed09c1`) and `Lean/Elab/Tactic/Decide.lean` (SHA `99e84ce67778157e77d7261aa25b64ed72da16e9d1f60031cf2aa26f5ea6ee68`). The former explicitly implements native proof checking by asserting an axiom that the evaluated Boolean is true.

Precisely: it instantiates metavariables and rejects free/metavariable-containing Bool expressions; makes a closed temporary safe definition; compiles/evaluates it inside `withoutModifyingEnv` with async/postponed compilation disabled; when evaluation returns true, adds a persistent `.axiomDecl` of Boolean equality with `isUnsafe=false`. The tactic obtains the decision expression and passes the resulting axiom through `of_decide_eq_true`. The temporary compiled helper is not the persistent axiom and its actual emitted machine code/value is not in these records. Closedness and safe flags prevent certain malformed uses; they do not turn native evaluation into a kernel reduction proof. Compiler, evaluator/runtime, decision procedures/loaded artifacts and relevant native libraries lie on this extended TCB path.

I also read all of `Lean/Util/CollectAxioms.lean`: for current constants it traverses kernel-environment types and values (including opaque values); for imported constants it may use the persistent exported axiom extension. Hence an axiom list is transitive dependency metadata, not a full provider load trace or independent recompilation of every imported proof. PP delaborator omission excerpts confirm that deep terms / omitted proofs / max steps can emit U+22EF. The observed omission is text loss, not a new axiom by itself.

The existing `$PROJECT/tools/proof_trust.py`, `check_proof_trust.py`, and `test_proof_trust.py` were read completely, not executed. The scanner strips comments/strings and matches source tokens `sorry|admit|axiom`; `APPROVED_SORRIES` is empty and explicit source axioms are never approved. There is no generated-native-axiom enumeration, native TCB acceptance rule, or check of `collectAxioms` results. Searches limited to the seven previously authorized governance documents and these three scripts found general requirements of no hidden axiom drift / no unauthorized axioms, but no native-specific authorization. This is not a claim that no policy could exist anywhere outside the permitted read scope.

Therefore the existing source-level scanner is not evidence that these nine native axioms are authorized, and no fabricated whitelist or `axiomPolicyPass=true` is supplied here. The native pipeline is recognizable and the nine mathematical propositions are true under the reviewed definitions; neither fact alone establishes repository admission policy. My result is **policy sufficiency NOT ESTABLISHED from inspected existing policy**, with native admission blocked. It is not a claim that all uses of standard Lean native_decide are illicit or that the source mathematics is false.

Minimal alternatives to discharge this blocker, requiring subsequent authority/evidence rather than changes by this reviewer:

1. An applicable existing maintainer-authorized trust policy explicitly accepting this exact 4.33 native evaluation TCB and the nine bounded propositions/dependency chains, together with the required compiler/provider provenance for that policy; then an admission decision can honestly be conditional on that TCB. An approval must not be invented by this reviewer or merely rename a safe flag as axiom-free.
2. Or replace exactly these nine native callsites by kernel-only proofs, retaining their meanings, and obtain fresh actual type/axiom/runtime bindings for the changed module. The hzero consumer chain must then actually lose that axiom; removing only the eight diagnostics is not enough for an axiom-clean norm bridge.

If a stricter independent extractor-verification claim is required, the minimal extra read inputs are the exact captured active `Probe-v5.lean` (SHA `c0c2a5ddc9eb5924c687803379a322dd14f7830d5bec576be6a002331cada46a`) and supplemental driver (bound by `supplemental-two-types-input.json`), plus any exact source needed to check their ownership/kernel/type/axiom API extraction. Their hashes are recorded, but those driver source bytes are not among the permitted 45 public files and were not opened by me. This is a narrow provenance request, not a demand for the whole repository, all ordinary proof PP tokens, or private job logs. Current raw-stream equality is established without claiming this additional independent API implementation audit.

## 7. Read scope, residuals, and stop boundary

The accompanying readscope and 769-entry receipt are integral to this report. In particular:

- Earlier full reads of natural source, complete target, five providers, direct four-square theorem source, governance and publication checker are reused only after exact current hash checks. Large repeated author JSON/base64 is parsed selectively and byte-reconstructed; I do not claim human reading of every duplicate byte.
- This stage directly reads authorized reconstruction/packets/seals/allowlists, raw sanitized runtime streams, actual records and needed runtime metadata. All 450 PP fields are machine-traversed; mathematical/recursive reads and residual infrastructure scope are specifically separated. A tool output truncated during reading is not silently counted as full text; critical missed regions were reread or checked through explicit restricted parsers.
- No private job.raw.log, credential/raw job/artifact metadata, private manifest, CI2/candidate output, unrelated author/decoder/review, registry, historical task data, parent desired verdict, PR count, or other current CI result was used as mathematical evidence. Public provenance references to them remain references, not read receipts.
- No Lean/lake, Git, network, simulator, publication checker, trust scanner, or captured command was executed. Only ordinary read-only text/hash/JSON/ZIP and reviewer semantic-parser checks ran. No production/canonical file or prior sealed output was changed. The three new scripts themselves only read inputs and print; artifact files were created with apply_patch.
- No fresh transitive provider build/load trace, whole-202 ambient binding replay, kernel replay, native compiler proof, all generated-value cognitive review, physical circuit semantics, executable output/cost/success proof, historical pre-proof attribution, or publication admission is claimed.

The source-first natural notes, original phase-1 seal, both STATIC reports/seals and existing sanitized exports retain their original bytes. The sanitized phase-1 seal remains only a path-redacted derivative, never a rewrite of the original seal. The new report is publicsafe by logical-path construction. New public selection is governed only by the new allowlist, not by this report granting write authority.

Final disposition: scoped source agreement supported; current selected observation consistency supported; two missing actual type texts resolved; ordinary proof-value printing omissions disclosed; nine-native TCB policy/admission blocker retained; all quantum stronger-consumer gaps open. STOP after sealing these new files. No accepted/ROOT/main/canonical flag is promoted.
