# C45 diagnosis: C29 unchanged-native production versus kernel candidate

Outcome: **SCOPED SOURCE/FORMAL ALIGNMENT RETAINED; ORIGINAL NATIVE TCB AUTHORIZATION AND PRODUCTION ADMISSION NOT ESTABLISHED.** The demonstrated unchanged-policy migration mechanism is the exact nine-site proof-only kernel replacement, followed by genuine current input/gate/publication evidence. This is diagnosis, not an accepted reviewer record or authorization to mutate production.

I am the original independent source-first reviewer. My natural derivation, STATIC v1/v2, final actual review, extractor addendum, kernel-candidate comparison and same-fresh type2 review remain unchanged. All39 earlier reviewer files were independently rehashed against their sealed hashes; all match. No older bundle or seal was rewritten.

## 1. The two cohorts must not be conflated

| Cohort | Exact source SHA256 | Previously reviewed actual scope |
| --- | --- | --- |
| Current production | `d125f8c239bca1c15e6e4fa6e788df6dd8984394630cb2dcc9be8946c4cbcb55` | 319 explicit /269 public /50 private;450 generated;769 owned constants;9 generated native axioms |
| Isolated kernel candidate | `6ee53311b5d6e18c46afb3e068341689acb86f1bdbc425e774705e81c9142f44` | Same319 explicit signatures;449 generated=450-9+8;768 owned constants;no target-owned native axiomInfo;8 new ordinary theorem auxiliaries |

I independently hashed the **current** production source. It is exactly the authorized runtime ZIP's original source, not the candidate. All five current local provider source files, lean-toolchain and lake-manifest.json also match my old pins byte-for-byte. Thus no new mathematical source/provider drift was found in the allowed current source context.

The runtime ZIP SHA is dd55fbd7a9e9ad8dd9168109271433c71ec4c26687a196e42584e3aceeb5d54e. I opened only its allowed original/candidate CubicStatePreparation.lean entries. Replacing production tokens at lines252,372,437,441,771,775,779,2535 by decide +kernel and the hzero token at2465 by exact Rat.sub_self reconstructs candidate6ee... exactly, preserving every other byte. Nine native_decide tokens become zero. Both files retain4148 lines. This changes proof computation, not definitions, interfaces, circuit algorithm, source contract, resources, oracle semantics or quantum slots.

The prior actual comparisons really inspected319 signatures, the441 surviving generated signatures/values, all eight new complete ordinary proof auxiliaries and the hzero consumer chain. Candidate fresh recorda5701442... and same-fresh type2 archivec1ed298a... are previously sealed evidence, not a claim about a newly built current production artifact. Candidate R1 type-text completeness is resolved by my type2-v2 review. Its two complete types match my earlier complete semantic readings exactly;96 value omissions/1004 glyphs remain. None of these old observations silently changes the current production file.

## 2. Exact obstruction for unchanged production

All nine old actual native declarations are axiomInfo with no value, safe flags, and self-membership in recursive axioms. Their actual types are Boolean decision equalities:

`Eq Bool (Decidable.decide P instance) true`.

They are not merely theorem names or source token counts. The reviewed Lean4.33 native implementation obtains these equalities by native compilation/evaluation and persistent asserted axioms, then uses of_decide_eq_true. Native compiler/evaluator/runtime/artifact dependencies therefore extend the ordinary kernel-reduction proof path.

The nine mathematical propositions remain true under the reviewed literal definitions:

| Current line | P |
| --- | --- |
| 252 | Arithmetic n2/defaultp40 resource tuple=(10,10,52,10) |
| 372 | Counting n2 tuple=(8,8,21,8) |
| 437 | All four stored schedule/budget lists have length4 |
| 441 | Lower stored schedule has getLast?=some6 |
| 771,775,779 | Cubic norm diagnostics1/64,397/2048,46205/65536 |
| 2465 | (0:Rat)-0=0 |
| 2535 | Dimension1 identity-minus-zero on ones violates the zero-error squared-norm bound, i.e. not(1<=0) |

The hzero axiom is not harmlessly isolated bookkeeping: it reaches explicit189 ratMatrixErrorAction_eq_diagonal, explicit196 ratEuclideanDiagonalOperatorNormBridge, explicit203 approxDiagonalOperator_operatorNorm_error, and old generated233 ratEuclideanDiagonalOperatorNormBridge._proof_1. Removing only eight diagnostic sites cannot establish whole-module native-axiom elimination.

For the unchanged native cohort, the outstanding issue is **not** a counterexample to P, wrong type, hidden binder or source mismatch. It is that the inspected current policy/evidence does not establish authorization of this exact extra native TCB and its nine actual Boolean-equality axioms/dependency chains. The original final review's policy-sufficiency blocker remains applicable to originald125...; candidate6ee... evidence eliminates those dependencies for its own cohort, not for the unmodified production module.

Independent kernel proofs of P, exact type/definition comparisons, and elementary truth checks are substantive evidence of mathematical correctness. An exact derivation of each Boolean equality could also support a meta-level conservativity argument. But true propositions alone neither remove original axiomInfo nodes from the production environment nor instantiate a repository-supported authorization mechanism. No such native certificate-substitution/authorization mechanism was identified in the inspected current gates. I do not turn the prior proof work into invented maintainer/user TCB approval.

## 3. What the existing policy actually says

This classification is deliberately narrower than claiming an undocumented blanket prohibition.

| Layer | Current evidence | Conclusion |
| --- | --- | --- |
| General normative requirement | proof-digestion-protocol.md:235 requires unauthorized axioms/placeholders/fake closures absent; HARNESS also requires no hidden axiom drift | An admission obligation exists; disclosure or compilation alone does not discharge authorization |
| Native-specific rule | No native_decide-specific ban or positive authorization was found in the seven allowed governance files and inspected trust/publication code | Neither “all native_decide forbidden” nor “native9 approved” is established from this scope |
| Source trust scanner | proof_trust.py:12 matches only source tokens sorry/admit/axiom after comment/string stripping; check_proof_trust.py:15 has empty APPROVED_SORRIES and approves only matching sorry findings | It can reject source holes/axioms; it cannot inspect compiler-generated native axioms or decide their TCB authorization |
| Publication checker | Checks exact content/identity/role/packet/artifact/declaration/semantic-slot fields; explicitly not a natural-language equivalence prover | It neither proves source fidelity nor supplies a native TCB authorization by itself |

Current trust scanner hashes are cd0b3a3b... (CLI) and c0a27208... (implementation); the original publication checker is f8f6d723.... Full hashes and readscope are pinned separately. I read these files, but did not execute them.

Accordingly the precise finding is **native-policy sufficiency NOT ESTABLISHED from inspected current policy**, not “source scanner explicitly forbids native,” not “native axioms are axiom-free because isUnsafe=false,” and not “a new policy approval has been given.” Some policy could exist outside the permitted scope; I do not claim otherwise. No missing approval is invented, and this diagnosis does not propose relaxing verifier, scoring, target or trust policy.

## 4. Source/formal alignment is already a distinct positive result

Yes: my original49 mathematical-node source/formal comparison supports the **scoped literal source alignment** of originald125..., including actual319 types, private/bundle/definition audits and all seven quantum semantic slots. Current target/provider/toolchain/manifest hash equality preserves that bounded interpretation. My source-first derivation was not retroactively inferred from Lean.

That result retains its precise conditional limits: rank-one versus diagonal targets; scale/success distinctions; mathematical8N dilation versus executable gates; noncomputable choice versus unique/canonical matrices; source-typed case splits versus true OR suppliers; complete AND tails; Prop-valued angleConvention; transparent-to-opaque bridges; QSVT external suppliers; literal resource metadata versus compiled gate costs. AllG01-G14 remain OPEN. C50/C51 process regions are not mathematical closure credit.

This is not a demand to reprove the source because the current proof uses native_decide. Conversely source alignment does not decide the proof-trust/admission question. A matching formal proposition may still rely on a TCB outside the established repository authorization.

No accepted reviewer JSON is emitted. In particular, a checker requiring verdict=accepted and seven compared-slot flags is not a license to set such fields just because this report supports bounded semantic alignment. There is no new exact binding release in this task, no global ambient replay, and no manufactured decoder/reviewer identity or packet.

## 5. Minimal sound route under the unchanged policy

### Recommended route: exact proof-only kernel migration

The already demonstrated mechanism is to install exactly the verified nine proof replacements in a separately authorized implementation step, obtaining source6ee... and leaving all statement/definition/algorithm/resource contracts unchanged. No target weakening, verifier/scoring change, new whitelist or trust-policy relaxation is needed.

The prior kernel cohort proves this is more than a proposed tactic edit: actual eight ordinary theorem auxiliaries have full read proof values; every original explicit/surviving-generated recursive axiom set becomes exactly its old set minus the native9; the hzero189/196/203/old233 chain loses the native dependency; all319 signatures match; the two omitted type texts were supplied on the same candidate fresh target. Remaining axioms are the ordinary Standard3 (Classical.choice/propext/Quot.sound), so even this route is not “axiom-free.”

Those earlier nine truth/type/definition/proof comparisons are adequate to justify the narrow **mathematical migration decision**. They do not alone establish that current production was replaced, that current inherited binaries match the old cohort, that the full repository/tests/site gates are current, or that publication roles bind a new exact context.

### What must be current, and what need not be repeated

The five current provider sources and current toolchain/manifest have now been compared and are unchanged. There is no mathematical reason to require a new full semantic rereading of those identical providers, redo the whole49-node natural derivation, or demand a clean transitive rebuild simply because proof tactics changed.

However source equality is not itself equality of all compiled artifacts or execution inputs. The prior nine project/config pins also included lakefile.lean; that file was outside this task's newly specified current toolchain/manifest read scope and has not been rehashed here. Current toolchain executable, actual provider/package binaries/search roots, broader proof-input equality mechanism and current full build state were not inspected. Their provenance/equality must be established before reusing an old compiled gate as a current production gate.

The existing publication protocol permits inheritance only through the repository's **current proof-input equality check** (line289). Therefore the minimal execution obligation is either a genuinely applicable equality-backed inheritance for the precise gate, or a focused/current integrated compile and required tests, with actual target/consumer/type/axiom bindings. The default repository lake build && lake build Tests and reader-facing scripts/build-all.sh/publication/site gates remain applicable at integration. This reviewer has run none of them, and a parent aggregate count of green CIs is not substituted for their exact input scope.

A clean transitive provider rebuild is not universally required by the inspected policy; trusted inherited provider artifacts may be used with the applicable evidence. Equally, unchanged provider source hashes cannot be called a current provider-binary rebuild. Do not overstate either direction.

Candidate R1 is genuinely resolved, not reopened merely because the task name changes. Its evidence can be reused when a legitimate exact cohort/input equality binding warrants reuse; otherwise the required new observation must be honest about the current artifact. The96 proof-value omissions limit complete PP/Expr archival, not ordinary kernel theorem use. No universal all-proof-token printing admission standard is introduced.

### Other route

An actually applicable **existing authorized** native4.33 TCB policy covering these exact Boolean equalities, consumers and provenance could support an appropriately conditional unchanged-native admission. No such mechanism/authorization was observed in the permitted current inputs. Inventing a new policy or user approval is outside the requested unchanged-policy route. Merely retaining native_decide while attaching the true-P table, green builds, safe flags, or candidate observations is not an already demonstrated native admission mechanism.

Thus proof-only replacement is the minimal currently evidenced path to remove this particular blocker; actual implementation/integration/binding obligations still remain. This report performs none of those mutations.

## 6. The global ambient binding and matching roles

The original publication checker was read in full. Its binding_digest (lines47-67) includes:

- record metadata, module and lesson bytes;
- lean-toolchain and lake-manifest.json bytes;
- **every** sorted .lean path and raw file bytes under QuantumBlockEncoding and ABEISTests;
- the selected source registry row.

Hence changing even these nine proof tokens changes the ambient contribution to every record's expected digest that uses this function (under the normal cryptographic binding assumption). There is not one shared universal digest: each record also has its own module/lesson/source/metadata payload.

For any record being released/rebound as **current**, validate_record (lines108-138) requires the record and both decoder/reviewer evidence files to bind the newly computed expected digest. Each role's current packet/artifact hash must match; identities must be genuinely distinct; the reviewer must bind the exact decoder evidence file SHA. Editing a decoder JSON binding changes that file hash, so the reviewer decoder_evidence_sha256 must also be honestly reissued. An old accepted flag cannot simply be copied or globally string-replaced.

This does not imply a new mathematical derivation or fresh cognitive reading of all unchanged modules is logically necessary. Versioned input-equality/delta/carry-forward evidence can reuse valid prior results if the roles genuinely assess and bind the new context with honest provenance. The mechanical checker cannot manufacture those judgments. Old evidence remains valid historical evidence at its old binding; it is not automatically current.

There is an important implementation boundary: check() (lines147-168) validates **only modules changed relative to its chosen Git base**, not every registry row on every invocation. Thus:

| Claim | Correct answer |
| --- | --- |
| Does the ambient byte change affect all these expected binding computations? | Yes |
| Does one ordinary changed-module checker invocation automatically force/review every old registry record? | No; it iterates changed_modules only |
| Can unchanged records consequently be called newly fresh? | No; their global-context digests are not refreshed by that omission |
| If the release elects to replace all ambient-context bindings, do all reissued records need matching current roles? | Yes, for every reissued/current-claimed record, including exact reviewer-to-decoder binding |
| Does historical “202 ambient files” mean202 publications or202 new proofs? | No; that count was not freshly inventoried here and is not a record count |

I did not read current registry/source rows, declaration inventory or all202 ambient sources, and did not compute any new publication digest. Thus I cannot enumerate exactly which current canonical records a proposed release includes, nor endorse a new full global binding. Preserve historical versions; use the unmodified checker and policy for the explicitly intended new release set. Do not drop an ambient file, weaken the digest algorithm, change the base to hide an intended production edit, fabricate roles, or equate passing the changed-only loop with full-registry freshness.

## 7. Typed obstruction and handoff

Objective/frontier: identify the sound next step for C29 production trust/admission without changing source contract or policy.

Substantive delta: current8 source/config equality matches plus exact nine-token reconstruction show a proof-only migration remains available; source alignment and native trust are separate; source-only scanner limits and global-binding/changed-only validation behavior are now explicit.

Failure class: NONE for the completed diagnosis; no failed mathematical route is being declared REFUTED/SOURCE_INVALID. Admission obstruction types are ORIGINAL_NATIVE_TCB_AUTHORIZATION_UNESTABLISHED, PRODUCTION_CANDIDATE_COHORT_DISTINCT, and CURRENT_INTEGRATION_AND_EXACT_ROLE_BINDINGS_NOT_ESTABLISHED. The last is a scope/evidence finding, not an assertion about unread registry contents.

Salvage: preserve all prior mathematical/type/source/proof evidence, the kernel candidate, R1 resolution and historical original native records. Do not erase D1. Do not promote process diagnostics or gate counters to scientific closure.

Default route/comparator: select the exact nine-site ordinary-proof replacement as the demonstrated way to avoid extending native authorization; not a new quantum algorithm or scientific improvement claim. No parallel work/children were admitted or used. No new process-memory records were read outside scope. Direction fingerprint: current-native-production-versus-kernel-cohort-policy-and-global-binding; expected information gain: choose migration rather than relax trust policy.

Purification/Exposition/ROOT: no new completion status; all quantum remaining boundaries survive. Formalizer historical identity remains UNKNOWN and this is retrospective local exposition, not a new paper-preproof/novelty claim.

Files: only fresh logical-path readscope/inputpins/staticcomparison/typedobstruction/nextnecessaryevidence/seal under the authorized new diagnosis root. Existing39 reviewer files remain unchanged; no production/registry/Git/network/compiler/native/tests/children action occurred.

Confidence: high on exact allowed-source equality, nine-token delta and inspected checker control flow; bounded on current binary/build/whole-ambient/registry/policy outside the allowed scope. Next steps and minimal missing inputs are structured in nextnecessaryevidence.json.

STOP. No accepted role artifact, production replacement, new binding release or policy approval is issued.

