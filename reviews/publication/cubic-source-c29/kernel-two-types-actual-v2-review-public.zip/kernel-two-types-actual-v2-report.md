# C29 same-fresh kernel two-type actual supplement: independent review v2

Status: **R1_CURRENT_CANDIDATE_ACTUAL_TYPE_TEXT_COMPLETENESS_RESOLVED_NOT_ADMISSION**.

I am the same original independent source-first reviewer. This is a bounded continuation, not a new blind identity or a replacement of any prior review. All36 old reviewer files were independently rehashed and remain byte-identical. The earlier kernel-successor-actual-v1 report correctly said that no new-fresh type2 supplement existed then; this new version records subsequent evidence without rewriting that historical statement.

## 1. Outcome and exact scope

The newly supplied actual two-type observation closes R1 for candidate source SHA `6ee53311b5d6e18c46afb3e068341689acb86f1bdbc425e774705e81c9142f44` and recorded fresh target SHA `a570144205d89df5604c2f0096df773c8a9174a01d42043bc73a40dd420adb71`.

Both complete actual type strings are omission-free and **byte-for-byte equal** to the complete types I previously personally read and mathematically analyzed. The new full319+449 main stream is itself byte-for-byte equal to the main candidate stream already independently reviewed. Thus the earlier source/type/binder/definition/AND-OR comparisons and native9-elimination finding carry forward to this new observed cohort, now with complete text for its two previously omitted types.

This closes the precise current-cohort actual-type-text gap, not a proof-value gap, a lossless Expr claim, independent compilation/kernel replay, clean transitive rebuild, publication/author/global23 binding, production replacement, physical implementation, or scientific ROOT. Global sourceAgreement/publicationBinding/authorBinding/axiomPolicyPass remain null; nativeAccepted and scientific_ROOT remain false.

The96 ordinary proof-value omission rows /1004 U+22EF glyphs are unchanged. I do not invent a requirement that every ordinary proof must be printed losslessly before ordinary kernel proofs can be used.

## 2. Actual bytes and bindings

The expanded public directory was empty locally, so I read only the authorized public ZIP streams. I did not open root job.raw/artifacts.raw or any other private metadata.

| Evidence | Independently checked SHA256 |
| --- | --- |
| New actual39-member ZIP, 2649869 bytes | `c1ed298ad9736c4ec3b4ab71b4324fa407a1415d7cf1c45350e0b12ef74f149d` |
| Previous kernel candidate30-member ZIP, used for main-stream equality | `4bed87b7fea42fd88cebc3aace0aac0a0ffc11d4b4b4548da626ff3c3c9d43ba` |
| Original complete-two-type45-member ZIP, used only for earlier type-text comparison | `16b9eea539d58f5f097832de577f23d48ce96a3e52f099ca9a847d0b83c06a39` |
| New and previous kernel main stream, 13917223 sanitized bytes | `163315a15c20cbc7cdefdba05e5f9f1a87a5befb6705e21eddaeed13b81ba103` |
| New two-type sanitized raw stream, 359126 bytes | `ef6ed9b794494d9b12446dd45588f4a25fbe0ff28bf4faf31341ce40eaed86ed` |
| New stored two-type observation JSON | `380ff71c3c42e7f74e3c64fa96ef905c13ae6c9300393566e16210927bc69a03` |

The39 members are the preceding30-member candidate/Python public capture plus nine new supplement members. I hashed all39 streams, recomputed all36 public derivation receipts (28 main +8 supplement), and matched all five subprocess result raw stdout/stderr hashes to their receipts. The new stored JSON signatures reproduce every field of the raw two-type records. No mismatch was found.

The new full probe emits the same319 explicit /449 generated /768 target-owned snapshot as before, with the same319 signatures and441 surviving generated entries, eight new ordinary proof auxiliaries and no native axiom declarations. Its entire sanitized stream is identical, not just a count or selected signature hash. I reuse my earlier complete baseline/axiom/consumer comparison on that exact stream rather than pretending to newly read every unchanged proof token.

The parent reported job117261859449 / run38987368610 SUCCESS. That is workflow provenance supplied by the parent, not a field I extracted from private job metadata or independently verified with network/Git. The public record's own independentReview=PENDING is left untouched; this reviewer version is a separate subsequent judgment.

## 3. Exact two types and mathematical comparison

| Actual name | Characters / UTF8 bytes | SHA256 of exact type UTF8 text |
| --- | ---: | --- |
| QuantumBlockEncoding.CubicDiagonalOracle.linearDiagonalFourSquareBranchVector_unit._proof_1_1 | 163920 /163926 | `26aeb73e322a14e85f08704e63cf2035bbd8b33747e93ad45142c914eabd716e` |
| QuantumBlockEncoding.CubicDiagonalOracle.cubicDiagonalFourSquareBranchVector_unit._proof_1_1 | 189640 /189646 | `e5e14e533bc8093c80f58ca862700e8dd37d3207e69487808b6d0b993b52c278` |

For each, new text equals the prior complete actual text exactly; there is no whitespace normalization, name substitution, family template or desired-statement reconstruction in this comparison. Neither contains U+22EF, U+2026 or ASCII ellipsis. Both records are thmInfo, kernel-present, universe-parameter-free, unsafe-false and self-axiom-false. Their actual recursive axioms are exactly propext, Classical.choice and Quot.sound. valuesPrinted=false and no valuePrettyExplicitAllowOpaque field is present.

My prior complete reading checked n:Nat, j:Fin(N), a,b,c,d:Nat; all mathematical application heads; every branch of the80 closed Fin8 conditionals per type; and the nonzero denominator guards. I reuse that personal reading through exact byte equality, not by claiming a fresh cognitive rendering of353560 characters. With N,J,a,b,c,d cast to Rat, the types retain precisely:

1. N^2=J^2+a^2+b^2+c^2+d^2 -> N!=0 -> sumSquares[J/N,a/N,b/N,c/N,d/N,0,0,0]=1.
2. N^6=J^6+a^2+b^2+c^2+d^2 -> N!=0 -> sumSquares[J^3/N^3,a/N^3,b/N^3,c/N^3,d/N^3,0,0,0]=1.

Clearing the nonzero denominator proves each from its rational equality premise; (N^3)^2=N^6. These are intermediate rational norm identities, not new natural witness producers, an n>0 hypothesis, unique full dilations, unitary circuits, resource certificates or QSVT suppliers. The original square-equation and binder interpretation is unchanged; no new mathematical obstruction or hidden premise was found.

The wire tag/schema C29_TWO_SIGNATURES_V1 is reused as a format only. This is a new actual execution on the candidate fresh target, not the original bf072be3... run relabeled. Collector namespace CubicKernelTwoSignatureSupplementV2 is distinct. Exact target-owned names, not a guessed prefix or namespace change, select the two observations.

## 4. Collector and wrapper source inspection

I fully read all seven newly authorized technical files; their exact hashes/byte and line counts are recorded in the seal:

- KernelTwoTypes.lean:95 lines, SHA4f8aaefd....
- run.py:125 lines, SHA27ded5fe....
- validate_two_types.py:116 lines, SHA037eb291....
- test_types.py:48 lines, SHAb576e5c3....
- README.md:22 lines, SHAc000366e....
- profile.json:24 lines, SHA35d5fbad....
- package-bindings.json:10 lines, SHA5ef1f0a9....

The collector imports the target and Lean, requires QBE_EXPECT_FRESH_OLEAN and matching real paths, uses exporting=false, gets the imported target module index, and filters actual env.constants by that ownership. Each exact name must have exactly one owned match, checked-kernel presence, kernel thmInfo and elaboration thmInfo. It pretty-prints **kernelInfo.type**, reads kernelInfo.levelParams/isUnsafe, and collects actual recursive axioms. Its own driver namespace is not a target-owned supplied theorem. It emits one binding, exactly two type records in fixed order, and one summary; no values.

The printer options are pp.universes/fullNames/privateNames/explicit/proofs/funBinderTypes/piBinderTypes=true, pp.notation=false, pp.deepTerms=true, pp.maxSteps=2000000, maxRecDepth=10000. The actual binding records the latter three options and exact two names. They match the source and the previous complete reader's interpretation.

The new entry binds its executing source, manifest/profile, prior launcher hash, prepared runtime package, vendor, validator, collector source **and copied destination**, candidate source and fresh artifact. It calls the preceding launcher, requires the successful candidate diagnostic status, obtains that run's exact fresh artifact/environment, checks Lean binary digest, and performs one additional thread1 /3072MiB /300-second type-only call. It rechecks source/package/runtime pins, fresh target, binary, inherited inventory, provider source/copies and absent search roots after the call. The new source/destination equality and actual fields remedy the requested present supplement copy binding; they do not erase historical predecessor D1.

The validator's pure validate_supplement function is unchanged SHA037eb291... from the earlier audited type2 validator. The old run_supplemental function in that file has historical d125... pins, but the new entry **does not call it**. It calls the pure validator through checked_stream, which additionally rejects unknown C29 tags and unsafe/self-axiom results. Thus an unused historical routine is not being mistaken for a new candidate binding.

The validator checks exact1/2/1 record counts, schema/module/fresh path, names/order, option values, thmInfo/kernel presence, unique string arrays, no omission glyphs, no value field, terminal completion, and non-acceptance flags. My own PowerShell/.NET parsing/hash/field comparisons independently checked the actual data; I did not execute Python, the validator, synthetic tests or Lean.

test_types.py is synthetic guard-test source, not an actual mathematical certificate. The31-test Python receipt in the supplied main capture still states LeanCalls0. No test result is promoted to a proof.

I did not newly read the preceding CI1 launcher/integration source outside this seven-file permission. Its pinned digest11eb213c... is checked against profile/actual input-bindings, not presented as a new source audit. Previously inspected kernel adapter/vendor/Probe/Lean4.33 APIs are reused at their existing exact bindings; the new full-stream equality and present records support this bounded comparison under ordinary faithful-runtime assumptions.

## 5. Same-fresh / process / raw-public chain

The new input-bindings report:

- entry27ded5fe065647a80e716f88d45a7172fc1b8dab4be222a08617314cd0c50ab5;
- collector source=destination4f8aaefd28f8eed57fc6b4594058f6da6591b3c425ff8f3ac7493a81135bf81c;
- vendor26805891fbc00840ba64e0566d29049f4a381d622215432f5a98ebf1ce033d81;
- validator037eb291dc76b78c19c38db35de3068c855351dd8f20c79b5678adb6666c98db;
- manifest5ef1f0a96a26e635156778e3c5ca9bb714de081c31ebf69bea936dbdecec8f1d.

All agree with independently hashed allowed source files / previously audited vendor bytes. The manifest's six file entries agree with the seven-file package (manifest excludes its own hash); its own digest is explicitly captured. Profile entry/candidate/prior-launcher bindings also agree.

The capture records new candidate compile PID13403 exit0, full probe PID13422 exit0, and two-type PID13435 exit0, all not timed out. The type call starts2026-10-17T00:43:09.548426Z and ends00:43:13.121630Z, about3.573 seconds, wrapperPID13387, driver cwd in the separate kernel-types-v2 directory. Started/result PID and stored nativePID/nativeExitCode agree.

The type setup and preceding full-probe setup have identical LEAN_PATH. QBE_EXPECT_FRESH_OLEAN, main actualResolvedOleanPath, two-type actualResolvedOleanPath and fresh artifact path all agree on:

`$PROJECT/_out/cubic-c29-kernel-only-v1/fresh/QuantumBlockEncoding/CubicStatePreparation.olean`.

Input-bindings, new stored observation, new result and main fresh-artifact record all give candidate6ee... / fresha570.... These are records of a newly compiled same-cohort artifact with the same content hashes as the prior kernel capture; I am not equating a stable logical path with process identity across different runs.

The new raw stdout digest is6f40d6f88e32dbb72a1f38252e4c2906c8d1d6937dd01e5032b621ac75e8bcd8, whereas its sanitized public digest isef6ed9b7.... Both are separately bound by the receipt. Empty stderr has the standard empty SHA. All36 public receipt hashes match actual ZIP member bytes; raw stdout/stderr digest references match all five process results. The raw private bytes were not read, and redaction receipts are not misrepresented as an independent rerun.

The main fresh record givesa570... /3626144 bytes and source6ee.... Main provider inventory, copied-five record, input pins/delta, relational result and final result match the previously reviewed bytes exactly where their ZIP hashes agree. Inherited binaries/ordinary compiler/import/collector/faithful wrapper execution remain trust inputs; this is not a clean transitive rebuild or global actual loader trace. The fresh olean binary is not supplied as a ZIP member, so I verified its recorded hash chain rather than pretending to hash the actual runner binary locally.

## 6. Readscope, residuals and historical preservation

Current manual reads: the complete seven technical files; substantive new input-bindings/setup/started/result/raw-receipt metadata; new candidate/probe result metadata; my own prior exact two-type semantic record. All39 public members were hashed;36 receipt rows, all process records, actual main/type records and stored-type fields were machine-parsed/compared. New full-type text was compared byte-for-byte with the previously personally read complete text. Repeated unchanged main/type text was not cognitively reread token by token.

Mechanical work was read-only PowerShell/.NET hashing, ZIP/JSON parsing and exact comparisons. One initial flat-ZIP suffix lookup and a PowerShell H alias attempt failed before the corrected comparison; neither was treated as successful evidence, and neither wrote an artifact or altered an input. No Lean/lake/Git/network/Python/driver/validator/simulator/subagent call occurred.

No new author, other worker/review, C31/C32 mathematics, private job/artifacts/raw-credential metadata, current production/canonical state or broader binding context was read. Parent replay counts or desired outcomes were not premises for this judgment.

R1 is now closed **only** as complete actual type-text supplementation for these two current candidate names, together with the unchanged captured319+449 type inventory. R2's96 value omissions/1004 glyphs remain. Type-only capture cannot close them or provide a lossless proof/value archive; ordinary kernel theorem use does not universally require printing all proof tokens. R3 ordinary TCB/inherited-provider/loader/provenance limits and R4 publication/production/scientific-supplier limits remain as in the kernel successor report. AllG01–G14 remain OPEN. Original native policy limitations and historical D1 are not retroactively rewritten.

Only this new version's report/seal/public allowlist are written. The seal records structured readscope, all seven sources,39 ZIP members, three archive hashes and36 preserved old reviewer hashes; the allowlist binds the report and seal without a circular self-hash. No global acceptance flag is changed.

STOP after this bounded supplement review.

