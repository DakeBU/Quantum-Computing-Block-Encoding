# C29 kernel-only successor: independent actual comparison v1

Status: **SCOPED_SOURCE_AGREEMENT_PRESERVED_OBSERVED_NATIVE_AXIOMS_ELIMINATED_NOT_ADMISSION**.

This is a continuation by the same original source-first reviewer, not a new blind reviewer. The independent natural derivation, STATIC v1/v2, final actual comparison, and extractor-source addendum remain immutable. I rehashed all 28 predecessor reviewer files against their earlier bindings; every hash matches. No earlier verdict or acceptance field is changed.

## 1. Separate conclusions

| Question | Independent conclusion and limit |
| --- | --- |
| Natural-source mathematics | The original 49 mathematical-node comparisons, necessary guards, definition/binder classifications and source construction graph judgments carry forward to this exact proof-only successor. No mathematical statement, definition, resource declaration or supplied semantic premise changed. This is scoped source agreement, not an admission flag. |
| Candidate source / actual observation consistency | The exact nine substitutions reconstruct candidate SHA `6ee53311b5d6e18c46afb3e068341689acb86f1bdbc425e774705e81c9142f44`. Actual319 explicit signatures and all441 surviving generated signatures/identities agree with the independently reconstructed old baseline. All441 surviving generated PP value strings, including nulls and omissions, are unchanged. |
| Nine original native dependencies | All nine old target-owned native axiom declarations disappear from the observed candidate environment and from every recorded recursive axiom set. There are eight new ordinary theorem auxiliaries, whose complete actual types, values and axioms I personally read. The hzero consumer chain is included, not excluded as a diagnostic. |
| Runtime claim | The supplied sanitized capture records exit 0 for isolated candidate compilation and the full actual-environment probe. I checked the records, exact source/package bindings and relevant extractor implementation; I did not compile, execute the driver, independently replay the kernel, or inspect the fresh binary bytes. |
| Trust / policy | The observed candidate eliminates the original nine native dependencies; it does not authorize the predecessor native TCB or repair its historical provenance. Remaining recursive axioms are exactly `Classical.choice`, `propext`, `Quot.sound`. Ordinary Lean/import/collector/faithful-wrapper trust remains. This is not axiom-free and not a new policy whitelist. |
| Current text completeness | The new main stream still has two PP type omissions and 96 PP value omissions / 1004 ellipsis glyphs. The previous complete two-type supplement belongs to the original fresh module, not this candidate. No fresh-candidate complete type2 observation is supplied here. |
| Production, binding, admission, scientific ROOT | Not adjudicated. This review changes neither production nor canonical material. Original prospective publication/author binding is not automatically rebound from d125... to 6ee.... No normalized state preparation, physical circuit, QSVT synthesis, executable cost, novelty or scientific ROOT closure is certified. |

Global `sourceAgreement`, `publicationBinding`, `authorBinding`, and `axiomPolicyPass` remain null; `nativeAccepted=false` and `scientific_ROOT=false`. The positive scoped statements above must not be flattened into a total accepted flag.

## 2. Exact inputs and provenance

I used only the newly allowed ten-file runtime package, its public allowlist, the authorized public artifact ZIP, the two separately authorized old actual319/450 files, and my own frozen prior evidence. No other author, decoder, worker/review, C31/C32, private job or credential-bearing metadata was read.

| Input | SHA256 |
| --- | --- |
| Original whole module, 166483 bytes | `d125f8c239bca1c15e6e4fa6e788df6dd8984394630cb2dcc9be8946c4cbcb55` |
| Candidate whole module, 166496 bytes | `6ee53311b5d6e18c46afb3e068341689acb86f1bdbc425e774705e81c9142f44` |
| Kernel adapter, 19058 bytes | `10e6836c53afa28524e0d5577c5d09916359548a185660392b43bbde0cd8a917` |
| Exact vendor runner, 24689 bytes | `26805891fbc00840ba64e0566d29049f4a381d622215432f5a98ebf1ce033d81` |
| Probe-v5, 56859 bytes | `c0c2a5ddc9eb5924c687803379a322dd14f7830d5bec576be6a002331cada46a` |
| Local proposal pins and captured input-pins, identical bytes | `63fc379d1d38be34f3e6f441b99a63b0043ad13b8c8316b39c1dfe32f1ae7597` |
| Runtime public allowlist | `c921e50a1bbfe3caa7fed08beab7c895994a9f135dd9195b5692fc8452ac92ab` |
| Official sanitized public artifact ZIP, 2630195 bytes | `4bed87b7fea42fd88cebc3aace0aac0a0ffc11d4b4b4548da626ff3c3c9d43ba` |
| Old actual319 | `c41fa5e8887bdc48c6e4b4d4d278c8235e2d42374aae427f8f8a65490adef0fc` |
| Old actual450 | `adc03d513d46b789c4d9fec18a9352592327b88d4b1900fa081b3a8e5a2cca62` |

The expanded capture public directory was empty; I read the authorized ZIP streams directly, without opening the capture root private metadata. All30 members were hashed. All28 derivation-receipt public hashes match their members. For all four subprocesses, the receipt's raw stdout/stderr digests match the corresponding result records. A sanitized stream digest is not silently equated to its private raw digest.

The parent supplied job 117254781213 / run 38985152606 / head prefix d69623e / success only as workflow provenance. Those are not fields I extracted from the artifact and are not independently network/Git-verified by me. The runtime archive dd55fbd7... is a pointer in allowed public records, not an archive I opened.

The input manifest binds 42 filesystem/artifact inputs, including the 28 predecessor reviewer files, plus 30 ZIP members. It uses logical paths only. The natural source SHA e3e594b4... and its independent mathematical conclusions are reused from my immutable phase1; I did not read a new author's successor explanation or present this as a new blind derivation. Formalizer historical identity remains UNKNOWN; this is retrospective local exposition, not a paper preproof or novelty claim.

## 3. The exact nine-token delta

I independently reconstructed the candidate from the original text, requiring the nine old token locations and preserving every other byte. Expected and actual candidate SHA agree. Both files have 4148 lines. The changed neighborhoods were personally reread.

| Original line / byte offset | Proposition or role | Replacement |
| --- | --- | --- |
| 252 / 10104 | Arithmetic n=2, default precision40 tuple (10,10,52,10) | `decide +kernel` |
| 372 / 15057 | Counting n=2 tuple (8,8,21,8) | `decide +kernel` |
| 437 / 17577 | Complete conjunction of four schedule lengths=4 | `decide +kernel` |
| 441 / 17692 | Lower schedule getLast?=some6 | `decide +kernel` |
| 771 / 30238 | cubicNormSq1=1/64 | `decide +kernel` |
| 775 / 30325 | cubicNormSq2=397/2048 | `decide +kernel` |
| 779 / 30415 | cubicNormSq3=46205/65536 | `decide +kernel` |
| 2465 / 97716 | Local hzero : (0:Rat)-0=0 in off-diagonal action proof | `exact Rat.sub_self` |
| 2535 / 100389 | Dimension1 identity-vs-zero Euclidean norm counterexample, ultimately not(1<=0) | `decide +kernel` |

Thus the source change is not an assumed proposition change, erased hypothesis, name relabel or weakened conclusion. The local hzero declaration and its rewrite consumer remain in place. The four schedule conjuncts remain a complete AND; their validity is process metadata, not proof of a scientific scheduler claim.

The exact original full module was read earlier. This continuation hashes and compares its current allowed package copy, reuses the earlier full mathematical reading, and reads all nine successor neighborhoods; it does not falsely claim a new cognitive reading of every unchanged source line.

## 4. Independent actual partition / baseline recomputation

The main raw public stream has one binding, 319 explicit records, 449 generated records, and one terminal summary. The target-owned checked snapshot has 768 constants. The actual ownership criterion is the target's imported module index, not a namespace-prefix guess; all target-owned constants minus the resolved explicit set form the generated partition. My preceding extractor addendum verified the exact unchanged Probe/API implementation and its snapshot limit.

The explicit319 contain the same 269 public / 50 private roots, 117 definitions, 184 theorems, 11 inductive structures and seven opaque constants as before. I independently checked exact actual names, source names/kinds/private flags/ordinals, ordered universe parameters, PP type hashes, actual ConstantInfo kinds, safety flags and value availability. There is no unresolved or duplicate explicit name.

The seven actual opaque constants retain `opaqueInfo`, `hasValueAllowOpaque=true`, empty recursive axiom sets, and the original opaque classification. They are not seven newly asserted axioms. Their bodies are not exported by the319 root records; neither empty axioms nor this review is being used to invent the missing transparent-to-opaque semantic bridges.

The old baseline package was not trusted merely because its filename says baseline. From the exact previously reviewed old319/450 bytes I recomputed every old319 signature/axiom entry, every441 old non-native generated signature/axiom entry, the nine removed native names, the complete old recursive axiom union, and all nine old native consumer maps. All match. Baseline cardinalities are exactly319 and441.

The new generated count is **449 = 450 - 9 + 8**:

| Generated kind | Old | Candidate |
| --- | ---: | ---: |
| defnInfo | 151 | 151 |
| thmInfo | 268 | 276 |
| ctorInfo | 11 | 11 |
| recInfo | 11 | 11 |
| axiomInfo | 9 | 0 |

All441 old non-native generated entries survive with exact actual identities, ordered universes, kinds, privacy, type PP hashes, safety and value availability. Their PP value strings are identical to the old strings; this includes the previous omissions and null value fields, not a claim that such values are complete.

For **each** old explicit or surviving generated record, the new recursive axiom set is exactly the old set minus the nine native names. This is stronger than comparing just a union or checking a broad allowed set. All768 actual records are kernel-present, unsafe-false and self-axiom-false. There is no target-owned axiomInfo, old native name, new foreign axiom or sorry dependency. The new union is exactly Classical.choice / propext / Quot.sound. This is an observed recursive-dependency fact under the checked collector API, not independent proof that every dependency binary was rebuilt from source.

The 11 actual structure constructors and79 projections survive through the same exact generated-type equality. The earlier recursive provider/target binder and Prop-bundle review is therefore retained, not replaced by a structure-count assertion.

## 5. All eight new proof auxiliaries and hzero chain

Every new helper is `thmInfo`, universe-parameter-free, kernel-present, safe, self-axiom-false. I read its entire actual printed type and proof value, not a template or a predicted source theorem. None has a type/value ellipsis.

Names below omit only the common QuantumBlockEncoding prefix.

| New actual helper | Actual type proposition | Type/value characters | Recursive axioms |
| --- | --- | ---: | --- |
| CubicDiagonalOracle.ratEuclideanOperatorNormErrorAtMost_not_vacuous._proof_1_1 | The closed dimension1 squared-norm inequality is false; identity-minus-zero on ones gives1, zero comparison gives0 | 1482 / 9667 | Standard3 |
| CubicStatePreparation.arithmeticRankOneCubicResourceTuple_n2_default._proof_1_1 | Exact n2/default40 tuple equality (10,10,52,10) | 705 / 3783 | None |
| CubicStatePreparation.cubicNormSq_n1._proof_1_1 | 1/64 equality | 339 / 1643 | Standard3 |
| CubicStatePreparation.cubicNormSq_n2._proof_1_1 | 397/2048 equality | 347 / 1675 | Standard3 |
| CubicStatePreparation.cubicNormSq_n3._proof_1_1 | 46205/65536 equality | 353 / 1699 | Standard3 |
| CubicStatePreparation.hadamardCountingCubicResourceTuple_n2._proof_1_1 | Exact tuple (8,8,21,8) | 619 / 3419 | None |
| CubicStatePreparation.hardModeLowerAgentSchedule_final._proof_1_1 | getLast?=some6 | 206 / 1081 | None |
| CubicStatePreparation.hardModeSchedules_have_four_levels._proof_1_1 | All four length=4 conjuncts | 740 / 7035 | None |

Standard3 means propext, Classical.choice and Quot.sound, not native axioms. The actual proof values have the ordinary form `of_decide_eq_true P instance (id (Eq.refl Bool.true))`, with the printed P and decidable instance included. Conversion of the decision to true is the relevant ordinary kernel computation; these are not axiom constants with safe-looking names, and they do not hide omitted premise bundles.

There is no ninth new helper for hzero because its source now invokes the ordinary Rat.sub_self theorem directly. I explicitly compared these four old-native consumers:

- Explicit189: CubicDiagonalOracle.ratMatrixErrorAction_eq_diagonal.
- Explicit196: CubicDiagonalOracle.ratEuclideanDiagonalOperatorNormBridge.
- Explicit203: CubicDiagonalOracle.approxDiagonalOperator_operatorNorm_error.
- Old generated233: CubicDiagonalOracle.ratEuclideanDiagonalOperatorNormBridge._proof_1.

Their signatures are unchanged. Every recursive set loses exactly the hzero native axiom and retains only Standard3. The surviving generated233 PP value is exactly the old value, whose consumer structure I had personally read previously. Thus the important error/operator-norm bridge is covered; this is not a claim limited to eight harmless diagnostics.

No fake closure or new hidden axiom drift was found in the new-helper/consumer/whole-snapshot comparison. This means the stated bounded comparison found none, not that this artifact proves all future compiler states, every transitive module or source-level quantum implementation complete.

## 6. Adapter / fresh artifact / provider chain

I read the entire328-line exact kernel adapter and entire456-line exact vendor runner. The unchanged Probe and validator sources were verified in my predecessor extractor addendum and rehashed here. I did not execute any of them.

The adapter requires explicit execution authorization; its default path is static-only. Its changed-source validator uses the original319 validator and the generated validator's field checks. It passes measured generated identities into those field checks; that step is **not an independent expected-449 identity oracle**. Generated completeness comes instead from the actual Probe's full target-owned snapshot partition, the emitted count/summary, and my independent old441/new8/nine-removed comparison. The expected-generated count is intentionally null in the input pins, not guessed450.

The wrapper verifies package and original project pins, checks the exact proof-only delta, creates an exclusive output directory/cohort, removes the original project build directory from the effective target compile/probe LEAN_PATH, copies five inherited local provider oleans, and rejects any target olean on effective input roots. It copies and hash-checks the candidate into the isolated cohort, compiles to an absent fresh output, records the new target digest, then sets QBE_EXPECT_FRESH_OLEAN for the probe. It checks source/package/provider/copy/fresh hashes again afterward. The old vendor top-level run() is not called.

The exact current vendor runner26805891... and adapter10e6836c... are packageFiles pins, and the captured input-pins matches the allowed local pins byte-for-byte. This supplies a present-capture binding under faithful-wrapper assumptions. It does **not** retroactively erase the predecessor D1 finding: historical supplemental-pins named runner268... while the then-inspected current runner source was61733..., that historical field was unenforced, and the old capture did not bind a runner digest. The new helper-byte binding is new evidence about this successor only.

Actual records:

- Candidate compile PID14448, wrapperPID14438, 00:13:05.765445–00:13:31.938179 UTC on2026-10-17, exit0, not timed out, about26.173 seconds.
- Full probe PID14468, wrapperPID14438, 00:13:31.943866–00:14:04.379133 UTC, exit0, not timed out, about32.435 seconds.
- The compile uses the isolated cohort source path and fresh output, --threads=1 / --memory=3072. Compile/probe LEAN_PATH agree and contain fresh plus the inventoried package/toolchain roots, not the original project build root.
- The binding's actualResolvedOleanPath, probe expectation and fresh artifact record agree on `$PROJECT/_out/cubic-c29-kernel-only-v1/fresh/QuantumBlockEncoding/CubicStatePreparation.olean`.
- The actual fresh artifact record gives SHA `a570144205d89df5604c2f0096df773c8a9174a01d42043bc73a40dd420adb71`, 3626144 bytes, candidate source6ee53311.... It differs from old original fresh SHA bf072be3.... I verified the supplied record/path/source consistency; the fresh binary itself is not among the supplied ZIP bytes and was not independently hashed by me.
- The provider inventory has44759 file records. All five copied provider source paths/hashes/sizes occur exactly in that inventory, and their destinations are in fresh. Their digests agree with the earlier inherited provider observations. The inventory includes the original provider root for copy provenance, which is not the effective target compile/probe root.
- The recorded Lean binary digest is e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550. Actual help reports Lean4.33.0, commit d8b18978322de05a8f3dba51ef03cf5461676c17. This does not independently reproduce the binary from the API source.
- Resource gate values satisfy its declared4GiB physical /6GiB virtual /8GiB output-space minima. This is host admission metadata, not a bound on quantum gate cost.
- The separate31-test Python record explicitly has LeanCalls0. It is synthetic fixture/validator evidence, not the candidate compilation certificate. I did not run those tests.

The exact unchanged Probe queries a checked imported environment with exporting disabled, resolves private names through the actual API, checks kernel presence/ConstantInfo metadata, enumerates target-owned constants by module index, reads actual types/value availability/PP values and collectAxioms results, and enumerates actual structure fields. Its resolved fresh path is search re-resolution, not a global dynamic loader event trace. Scope is the snapshot observed at that query, not every future on-demand realization.

Inherited provider binaries, package/toolchain binaries and faithful wrapper/copy execution remain trust inputs. The driver copy destination lacks a separate published destination-source hash observation; the package source is pinned pre/post and ordinary faithful copy is assumed. Nothing here is a clean transitive rebuild, lossless Expr archive, independent runtime/kernel replay, or complete dynamic-library loader trace.

## 7. Source graph, literal guards and seven quantum slots

The candidate changes proof computation only. My source-first C01–C49 mathematical nodes retain their original comparisons; C50/C51 process regions remain excluded from mathematical coverage. I do not invent a new source or require a stronger downstream implementation to call the source internally false.

The prior substantive distinctions remain:

- angleConvention is a Prop/theorem field, not typing data. Arbitrary supplied Prop fields need their actual proofs; concrete producers and consumers are distinct.
- Disjoint arithmetic/index/zero cases are typed case partitions, not alternative sufficient theorem suppliers. True OR alternatives retain their complete guarded AND tails.
- The rational circle/four-square producer retains its literal arithmetic/range/norm guards. Existential and chosen orthogonal matrices are not uniform gate producers, and noncomputable choice is not a unique full dilation or a supplied quotient identification.
- Rank-one arithmetic-wrapper OR counting routes each still need their own entire denotation/unitarity/rejection/cleanup/clean-block tail. No conjunction projection supplies a missing premise.
- The expanded clean-block contract retains all five conjuncts: transparent arithmetic, universal supplied-tier angle law, opaque cleanup, opaque extraction and literal target equality. Transparent readonly/cleanup witnesses do not prove opaque bridges or unitarity.
- QSVT local degree/parity/grid facts do not supply an external output/phase-list/global-admissibility/cleanup/resource package. Product target equality is not composition of physical dilations.

| Quantum slot | Unchanged scoped meaning / boundary |
| --- | --- |
| target | Rank-one O=\|a><0\|, X=diag(j/N), D=diag((j/N)^3) are distinct. The chosen cubic certificate fixes D; a generic exact payload does not do so by name. |
| normalization | Rank-one chosen alpha=N and counting j^3/N^4 differ from diagonal scale1. Norm bounds do not supply normalized-SP success or amplification; n=0 guards remain. |
| registers | Householder existence is ancilla-major8N, mathematically three ancilla bits. Declared workspace counts do not bound arbitrary Workspace types; finite index arithmetic is not gate synthesis. |
| oracles | Oracle-call labels carry grammar/resource metadata; opaque unitary/extraction semantics and expanded contracts remain supplied obligations. |
| ancillas_phases | Modular dirty cancellation is a basis-function fact. Weak chosen cleanup is clean equality; physical reset, counting/Hadamard phases and common-backend signal semantics remain open. |
| error_success | The actual rational-vector Euclidean error predicate and non-vacuity are retained, now without the hzero native dependency. No approximation producer, success rate or finite-precision rotation follows. |
| resources | Literal tuple/count/depth/layout data are unchanged; replacing native diagnostics with ordinary proofs does not certify gate synthesis, efficient four-square computation or physical hardware costs. |

G01 interpreted arithmetic/wrapper; G02 interpreted counting; G03 nonzero-column rejection/cleanup; G04 phases/accepted-path normalization; G05 normalized-SP success/amplification; G06 efficient four-square producer; G07 uniform controlled-matrix/gate realization; G08 physical product isolation/composition; G09 complete QSVT supplier; G10 approximation producer/certified dilation; G11 coherent rotation/common-backend semantics; G12 transparent-to-opaque bridges; G13 physical expanded extraction/unitarity; G14 finite-bit resource/executable correspondence: **all remain OPEN**, not newly refuted source theorems and not closed by kernel-only proof substitutions.

The original prospective author/publication binding is not replayed or renewed for this changed source hash. No broad202 ambient input closure, current repository/canonical state or subsequent author intent is inferred.

## 8. Precise remaining evidence and which claim it limits

### R1: new-fresh two-type text completion

The current candidate main capture still prints ellipses in exactly:

1. `QuantumBlockEncoding.CubicDiagonalOracle.linearDiagonalFourSquareBranchVector_unit._proof_1_1`
2. `QuantumBlockEncoding.CubicDiagonalOracle.cubicDiagonalFourSquareBranchVector_unit._proof_1_1`

The old complete type-only supplement was on original fresh target SHA bf072be3..., under pp.deepTerms=true, pp.maxSteps=2000000, maxRecDepth=10000. It printed no values. My old semantic reading of its two complete types remains valid predecessor evidence; unchanged source/PP signatures allow bounded reuse of the interpretation. It is **not** a complete actual-type observation from new fresh target a5701442....

Minimal follow-up for a claim of complete current-cohort actual type text: a separate versioned two-name actual-type supplement importing the same isolated candidate fresh module, requiring exact target ownership/unique actual names/thmInfo/kernel presence, recording the above printer options, checking both returned texts contain no omission, and binding driver source, executable/search roots, candidate source/fresh artifact pre/post hashes, actual process exit and raw/public digests. Preserve current runtime files and old seals. This report does not authorize its execution.

Without that supplement, I do not certify whole-module **current actual-type text completeness**. The gap does not reverse the exact source delta/signature comparison, the observed elimination of native9, or the ordinary kernel trust model. It should not be silently promoted to a repaired current type observation.

### R2: 96 ordinary proof-value omissions

The449 records still have96 values containing1004 U+22EF glyphs, exactly the old surviving PP value strings. These are not fixed by a type-only supplement. Explicit319 proof bodies are also not a root-export field.

This prevents a claim of complete lossless expression/proof-value archival or personal reading of all underlying PP proof tokens. It does **not by itself** invalidate an ordinary Lean proof or require every ordinary proof value to be printed before one can use kernel checking. If the admission policy specifically demands a full lossless value archive, the necessary follow-up is a separately pinned appropriate Expr/value export with completeness checks, not relabeling96 values as supplied. I am not imposing that stronger archive requirement as an invented universal rule for ordinary theorem use.

### R3: ordinary trust / inherited providers / execution provenance

The capture and inspected code support an observed compiled candidate under ordinary toolchain, imported binary, collector and faithful-wrapper assumptions. They do not provide clean transitive source reconstruction or global load-event attestation. Any stronger whole-target trust/admission claim must state an existing applicable policy and evidence for the trust boundary it actually requires, rather than using safe flags or exit0 as proof of axiom-freedom. No new whitelist is created here.

The original native-TCB-policy blocker remains a correct historical conclusion for original d125... observations. For candidate6ee... the nine dependencies are eliminated, so that specific native9 authorization issue is not still an observed candidate dependency. Standard axioms/ordinary TCB and the above evidence limits remain separate. Historical D1 also remains historical; it is not the current exact vendor pin.

### R4: publication / scientific implementation / production

No prospective binding replay, canonical admission, current production replacement or G01–G14 scientific supplier is established. These are genuinely outside this narrow comparison, not repaired by printing two types or by another successful compile. A future admission decision must remain explicit about its actual scope.

## 9. Work performed, files and stop

The accompanying readscope records exact manual reads, reused prior source/API readings, mechanical parsing, and unread residuals. The checks JSON includes my independent baseline/partition/signature/axiom/source-delta/omission audit, all eight new actual helper records and the provider/fresh/pin/receipt consistency checks. The two reviewer scripts perform only read-only PowerShell/.NET hashing and parsing.

I ran no Lean/lake/Git/network/Python/driver/validator/simulator, spawned no subagents, and wrote only new kernel-successor-actual-v1 files in my exclusive reviewer directory. Earlier28 bytes are preserved. The public allowlist exposes only this new sanitized version; the seal binds its payload hashes without rewriting old seals or pretending a self-hash cycle.

This closes the authorized independent comparison at its stated evidence scope. STOP; no admission flag is changed.

