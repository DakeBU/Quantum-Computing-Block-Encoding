# C29 extractor-source addendum v1

Status: EXTRACTOR_IMPLEMENTATION_SCOPE_SUPPORTED_WITH_WRAPPER_PROVENANCE_LIMITS. This is a narrow, independent, static technical addendum. It does not revise the immutable final comparison (`f704af05c77a7417de28f9b4919cb3993a1e2042329968c38dcdedc85dee6932`, seal `167c822867163fc7f5679a6ee712f68afb9089072274788761c35eb81b9bcc11`), rerun mathematics, or authorize native acceptance.

The exact newly permitted Lean extractors and supplemental Python implementation were read under the requested hashes. Their implementation supports the existing observations as **actual imported-kernel-environment metadata and actual pretty-printed expression text**, with the boundaries below. No hardcoded mathematical signatures, fabricated empty axiom arrays, guessed numeric private names, or expected-list filtering of the generated partition was found. The previous request to inspect these extractor source bytes is resolved at this implementation-review scope. Compiler/runtime correctness, historical wrapper byte identity, provider load tracing, native TCB policy, source agreement, physical semantics, and cost are separate questions and are not promoted.

## 1. Exact new inputs and unchanged predecessors

Logical paths have the same meanings as in the final report; no concrete host paths occur in this export.

| Diagnostic input under `$PROJECT/tools/cubic_c29_diagnostic/` | SHA256 |
| --- | --- |
| Probe-v5.lean | `c0c2a5ddc9eb5924c687803379a322dd14f7830d5bec576be6a002331cada46a` |
| SupplementalTypes-v1.lean | `afcd52fb5d679fb1181859c0c4306efa71496aa82df25278b866f9b1acef0234` |
| supplemental_types_v1.py | `037eb291dc76b78c19c38db35de3068c855351dd8f20c79b5678adb6666c98db` |
| pins.json | `4e6b0e4cc0a56c4123949d8fd7542172bca5aca5afe2fc3cb0f0960db63c8a17` |
| supplemental-pins-v1.json | `dd86929102fcfc543d04fcb0c32f0a73b733afb037ead20221ef37b6e76eb6c0` |
| expected-roots.json | `987df13d65fcc2789870d20cfd84a0c39b6b797647eba651856a89d3a0d3fafb` |
| expected-generated-ci2.json | `b7914acfc9b3b1594b4483e4d1937a79b3f0849354a67e29a91d23c45c94a9ef` |
| validate-output.py | `204e5939b7e55f63816385a1c29753eec87cdeca49316140c905d983b5b068a2` |
| validate-output-v2.py | `b1a687f2f5e42f759f7ed958fa1c52e2979b53af7e42312dd7a9978ffff6291c` |
| runner.py | `61733fc92f5e99672e0ce0260ff397e07c94a349e98e12c48dd6a3171d5a75d9` |

Seven selected source/list/validator file hashes and bytes match the already sealed official capture's input records. The three specifically required hashes match exactly. All 45 permitted public capture files remain identical to my final input manifest. All 22 earlier reviewer files remain byte-identical to the old seals/allowlist (the original ten plus the final ten artifacts, final seal and final allowlist). No old file was rewritten.

The new input manifest binds 88 files: ten diagnostic inputs, eleven narrowly required local Lean 4.33 API files, 45 unchanged public capture files, and 22 preserved reviewer files. The readscope distinguishes complete functional reads, necessary API excerpts, repetitive specification-array machine comparisons, and hash-only reuse. The name `expected-generated-ci2.json` is an authorized identity/kind manifest; its referenced actual CI2 archive was not opened.

## 2. Actual environment and private roots

`Probe-v5.lean` imports the target module and Lean, sets explicit/universe/full-name/private-name/proof/binder pretty options, and runs its query at lines 381–558. It does not parse target source signatures to fabricate compiler types. `expectedRoots` is only a vector of user names, source kinds and private flags.

At lines 392–397, the driver takes `(getEnv).setExporting false`, obtains the imported target's module index using `getModuleIdx?`, and filters `env.constants.toList` by `getModuleIdxFor? name == some targetIdx`. The checked local 4.33 implementation matters:

- `Environment.constants` at lines 733–735 is `env.toKernelEnv.constants`; `toKernelEnv` at lines 649–650 is `env.checked.get`. Thus the `ci` values in the enumerated list already come from the checked kernel-environment snapshot, not from a hand-built lexical or unjoined elaborator registry. The additional lookup verifies presence and kind in that kernel environment; it is not a fresh independent kernel replay of imported declarations.
- `getModuleIdxFor?` consults the actual constant-to-imported-module map, and `getModuleIdx?` the imported module-name map. Ownership is not guessed from a `Cubic` namespace prefix. This explains why target-owned equation/matcher infrastructure can have provider-related names. Current driver declarations have no imported target ownership and are excluded.
- Non-exporting visibility exposes the private imported view. For private specs the resolver requires `isPrivateName name` and `privateToUserName? name == some userName`; for public specs it requires a non-private exact name. Exact Lean private-name implementation was read in full. The collector does not construct `_private.<module>.0` or guess a private numeric component.
- Every source user name and actual resolved name must be unique, and exactly one owned candidate must match; missing, duplicated, ambiguous or kernel-absent roots fail before a root-completion claim.

All 319 literal RootSpecs were independently parsed and compared, in order, to `expected-roots.json` and the existing captured actual-root records. Names, kinds and private flags agree at every position; 50 are private. The extractor also guards seven source opaques and eleven source structures. Actual values remain 269 public plus 50 private, not 319 plus an extra 50.

This supports **the complete target-owned checked snapshot observed by this query**. It does not enumerate every future on-demand realization that another command might materialize, every transient compiler helper, every transitive provider constant, or all possible source-language declarations in another environment. The snapshot's explicit/generated partition is exact at its stated time, not a universal future-environment closure.

## 3. Types, values, opaques, structures and axioms

The main emitted fields have the following actual sources:

| Field family | Implementation and precise meaning |
| --- | --- |
| name/kind/private | Real `Name`, a complete match over the eight `ConstantInfo` variants, and `isPrivateName`. Source-kind labels remain supplied inventory labels, not an independent theorem that the source label must elaborate to a particular kind. |
| type/universes | `ci.type` through `Meta.ppExpr`, and `ci.levelParams`. `ConstantInfo.type`/`levelParams` access `toConstantVal`; no expected type string is substituted. `Meta.ppExpr` uses a PPContext containing the current environment, metavariable/local context and options, then normal delaboration/formatting. |
| generated value | `ci.value? (allowOpaque := true)` and `Meta.ppExpr`; absent values become JSON null. This includes theorem and opaque values by the actual API, not only transparent definitions. It is not compiler IR, executable machine code, or a lossless Expr serialization. Explicit-root values, including the seven opaques' values, are not exported by this driver. |
| hasValue/safety | `ci.hasValue (allowOpaque := true)` and `ci.isUnsafe`. `hasValue` is kind-based API availability (definitions/theorems/opaques), not an independent evaluation or proof-body audit. `isUnsafe` is the API's safety indicator; it is not an axiom-free test, and the declaration API separately distinguishes partial definitions. |
| axioms/self | `Lean.collectAxioms actualName`, sorted without deletion, and membership of the actual name in that result. The driver has no replacement empty list, generated-axiom whitelist, or equation reducing these observations to a policy pass. |
| opaque classification | Source opaque labels are distinguished from actual `axiomInfo`, `opaqueInfo`, or other actual kinds. Lexical `opaque` is never taken as sufficient reason to invent an empty axiom array. |
| structures | Actual `getStructureInfo?`, actual `inductInfo` constructors, and each actual projection's info/module ownership. These are direct fields, including any subobject projections; the API itself is not a recursive expansion of every provider field type. The final mathematical review performed its separate nested-binder audit. |

The main code invokes `collectAxioms` for all explicit and generated names, not only nine suspect sites. The previously fully read exact 4.33 `CollectAxioms` source was hash-revalidated: current declarations use kernel type/value traversal, including opaque values; imported constants may use serialized axiom-extension entries. This is genuine recursive dependency metadata under ordinary import/TCB assumptions, not a fresh rebuild, a native compiler proof, a complete load trace, or policy authorization.

The observed seven source opaques therefore really being `opaqueInfo` with empty recorded axiom lists is supported by the API pipeline, not by treating them as seven axioms or assuming them axiom-free from their source spelling. Their actual value interpretations remain unprinted. The nine generated native axioms remain visible as `axiomInfo`; the implementation neither suppresses them nor changes the final report's native TCB discussion.

## 4. Complete generated partition and output schema

The driver first resolves all explicit roots into `seenActual`. It then loops over **all** owned constants and emits every name not in that set. Constructors, field projections and recursors get structural classifications; everything else is still emitted with full actual fields under `OTHER_TARGET_OWNED_GENERATED_RESIDUAL`. There is no whitelist suppressing residual or unexpected names. A final summary records the independently counted explicit/generated/owned totals.

`expected-generated-ci2.json` is not read by the Lean extractor. Its 450 rows contain only `actualName` and `actualKind`, not desired type text or accepted axiom lists. The Python v2 validator compares the complete generated identity set and kinds to that manifest and rejects extra, missing, duplicate or changed entries with RESEAL. Thus it is a post-extraction change detector, not the source of the observed generated expressions. No actual CI2 mathematical output was needed for this review.

Independent static/record checks found:

- Embedded source vector / expected-root manifest / captured actual roots: 319/319/319, zero name/private/kind/order discrepancies.
- Expected generated / captured actual generated: 450/450, exact name-kind agreement, no explicit/generated intersection.
- Field-key sets extracted from each Lean emission block versus every corresponding captured JSON row: zero mismatches for all 319 roots, all 450 generated records, and both supplementary records.
- The official captured active-driver and selected manifest/validator bindings match all seven selected local files as noted above.

The original validator demands one binding, one terminal summary, all 319 ordinals, uniqueness, private flags, fresh-path Boolean, eleven structures, and the exact partition count. The v2 layer adds actual generated kinds, booleans, string arrays, nonempty type/value text when applicable, value-null/kind consistency, self-axiom membership consistency, and the declared PP-text scope. Diagnostic `sourceAgreement/publicationBinding/axiomPolicyPass` must remain null and `nativeAccepted` false; forbidden extra acceptance flags are rejected.

These are consistency guards, not a hostile-proof transcript verifier. For example, the original validator does not itself compare a root's actual type with a source theorem or fully audit every explicit safety/self field; its opaque prefix check is less precise than the actual producer's classification. Some structure metadata validation is count-based. Those limitations do not fabricate the actual driver fields or invalidate the final independent comparisons, but validator success alone must not be described as mathematical equivalence, axiom policy, or kernel replay. I read, but did not execute, either validator or any captured command.

## 5. Pretty omissions and two-type same-fresh binding

The main driver explicitly enables proof printing but does **not** enable `pp.deepTerms` or raise `pp.maxSteps`. The exact PP APIs/default omission implementation support the final report's interpretation: even actual `pp.explicit` strings can contain U+22EF. The main v2 validator permits such nonempty strings and correctly labels them PP text, not lossless Expr. It cannot certify text completeness merely from a non-null value.

The supplementary Lean driver has exactly the two previously observed generated names. It independently obtains the same imported target ownership snapshot, demands a unique exact-name owned match and `thmInfo` in both enumerated/kernel views, and pretty-prints the actual `info.type`. It sets `pp.deepTerms=true`, `pp.maxSteps=2000000`, `maxRecDepth=10000`. Its records have `valuesPrinted=false` and no value text field. These are actual types with a less omissive printer, not a reconstructed desired theorem or proof repair.

The complete supplemental Python code demands one binding/two type rows/one terminal summary, exact names/order/options, same normalized fresh path, actual kind/kernel membership flags, arrays and self-axiom consistency, no value field, no acceptance, and no `⋯`, `…`, or ASCII `...` in either type. It rejects a nonzero subprocess exit. This gives the narrow observed complete-type-text scope already independently semantically parsed in the final review. It does not touch the 96 generated value omissions, remove the nine native axioms, or prove a serialization roundtrip.

The runner's intended fresh chain is coherent under faithful execution:

1. Make an exclusive output directory; verify project/package/driver/list/validator pins; check active driver's imports and runtime target.
2. Record the resolved executable and potential providers; copy five local inherited provider oleans/available sidecars; prepend the fresh prefix to `LEAN_PATH`; compile the target to an absent fresh output.
3. Recheck the nine project pins, hash the fresh target outputs, set `QBE_EXPECT_FRESH_OLEAN`, run the main probe, and validate its captured stdout using the real recorded subprocess exit.
4. Pass the same environment, executable, driver directory and fresh output to the supplement. Check before/after fresh olean hashes, copy and hash the supplementary Lean source, validate the two-type stream, and finally recheck project/provider/fresh hashes.

`native_call` uses actual `Popen` PID/exit/wait result and byte stdout/stderr files, not a success inference from a printed sentinel. Failure/timeout does not become complete data. Public export derives sanitized streams/JSON and per-file raw/public digest receipts. This code review is not a replay or authenticity proof of the host transport; private raw logs were not opened.

## 6. Discrepancy and residual provenance boundaries

### D1: predecessor runner digest is not a current enforced execution binding

`supplemental-pins-v1.json.baseRunnerSHA256` is `26805891fbc00840ba64e0566d29049f4a381d622215432f5a98ebf1ce033d81`, different from the newly read current runner's `61733fc92f5e99672e0ce0260ff397e07c94a349e98e12c48dd6a3171d5a75d9`. Neither `run_supplemental` nor `runner.run` enforces that `baseRunnerSHA256` field. The official public input records inspected here bind the active Lean driver, supplementary sources, manifests/validators and nine project inputs, but do not provide an exact executed-runner hash.

This is a real non-equality and an unenforced provenance field, not a demonstrated failure of the extractor's kernel/type/axiom API calls. The field is named *base* and may refer to a predecessor, but I do not invent a verified historical lineage or claim that current runner bytes were exactly executed in the old capture. The static code and captured streams are compatible; exact historical wrapper-byte provenance remains NOT ESTABLISHED here. Static metadata such as `actualSupplementalNativeRun=false` or WIP status is frozen pre-run planning, not substituted for the separately sealed actual runtime result.

Minimal extra evidence for an exact-wrapper-execution claim would be an authorized publicsafe capture binding the actually executed runner digest (and its matching source bytes), rather than relabeling the non-enforced predecessor digest as a current pin. No parent proposal, new author explanation, other review or private job log was read to resolve this.

### Bounded guarantees, not mismatches concealed as successes

- `findOLean` re-resolves the module using the current search path; the driver compares real paths to the requested fresh path. The exact API searches the first qualifying package root and is not an import-loader event log. The inspected driver does not change search paths before this query, and the wrapper sets the intended prefix before import. Nevertheless `actualResolvedOleanPath` means this bounded re-resolution/equality check, not independent proof of every imported provider or a cryptographic historical load attestation.
- The wrapper hashes known sources/providers before/after and records inherited provider inventory, but this is not a clean transitive build. It inventories potential artifacts in configured roots; it expressly leaves native libraries outside those roots untraced. Nine project/config pins are not the author's 202 ambient publication binding.
- Ordinary faithful file copying and execution are assumed. The main Probe copy into the driver directory is not separately rehashed there as the supplemental Lean copy is. Rechecked package pins, normal copy semantics and matching output are useful consistency evidence, but no hostile-TOCTOU-proof guarantee is supplied. The process inherits environment state beyond the two selected variables recorded in setup metadata.
- The collector's API support depends on the trusted running Lean implementation and imported artifacts. Reading the matching local 4.33 source excerpts does not independently prove that the captured executable is a faithful compilation of those sources or that compiled native evaluation is correct.
- `kernelRootPresent`, `isUnsafe=false`, available value text and an actual axiom list have their precise API meanings. None is a native TCB authorization flag or an axiom-free theorem. Ordinary kernel use still does not require manually reading every PP proof token.

No further name/kind/schema/pin mismatch was found in the selected seven captured file bindings or the 319/450/two-type comparisons. D1 is retained distinctly rather than turned into either a fabricated end-to-end pass or an unsupported accusation of a false capture.

## 7. Disposition and stop

The exact source implementation now supports the previously asserted **bounded extractor scope**: actual imported target-owned checked-snapshot identities/private resolution, `ConstantInfo` kinds/types/universes/value availability/PP values, actual recursive axiom metadata, direct structure fields, full snapshot explicit/generated partition, and two actual type-only PP supplements under the intended same-fresh wrapper chain. This resolves the final report's source-unread technical request without changing its immutable wording or verdict.

The addendum does not independently verify historical executed runner bytes, actual loader events, compiler/runtime/native correctness, transitive provider provenance, source mathematics anew, physical costs, or any native policy authorization. Nine native axioms and the final policy/admission blocker remain exactly as before; `sourceAgreement` and `axiomPolicyPass` are not newly promoted, `nativeAccepted=false`, `scientific_ROOT=false`, and canonical/main admission is not performed.

Only new `extractor-source-addendum-v1-*` files were written with apply_patch in the original exclusive reviewer directory. No Lean/lake/Git/network/install/simulator/driver/validator execution, subagent, production/canonical mutation or old reviewer mutation occurred. The addendum has its own readscope, 88-file input manifest, static checks, immutable seal and publicsafe allowlist. STOP after sealing.
