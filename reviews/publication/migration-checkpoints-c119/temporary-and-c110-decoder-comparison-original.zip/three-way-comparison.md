# C110 actual-decoder three-way comparison

State: THREE_WAY_TEXT_ONLY. This compares the reviewer's independently frozen source mathematics, the reviewer's subsequently frozen own-formal interpretation, and the actual C107 decoder's complete five-file packet. It is not a new circuit implementation, an approval of source topology, a compiler gate, or final admission.

Primary source: [arXiv:2610.22367v1, physical page 9, Methods, Eqs. (11)-(13)](https://arxiv.org/pdf/2610.22367v1#page=9), SHA-256 `3607f457c3349db74e10b131abadef23a4a2dea0fefa0cf6ac6d0ed9f37fdfd9`.

Prior source seal: `dddfc589403e962639008468f253c39dfb5cc5a7bf49b5a2d6c74dda13b28e47`. Prior own-formal seal: `4863c52f5269105e5506a9fcab4628dbd1f6f9ee7b571a8d9795eaa17de108f4`. Actual decoder manifest: `ab809a89c325745a9d0c46674932adb30c4d73e322734ce12814b2980561ea77`; decoder content seal: `dedb6b35cee998fd8e10529acdd47efcd0b745a3fb68e76d32c97f141be08957`. The two prior reviewer packets and decoder packet are not rewritten.

## 1. Comparison method and exact coverage

The reviewer read the actual reconstruction.md, declaration-inventory.md, evidence.json, manifest.json and content-seal.json in full, not merely their handoffs. All three decoder payload hashes/lengths and the manifest-to-seal binding were recomputed. Decoder input pins match the exact target/providers/context previously read before this exposure.

The comparison covers all eleven target declarations, their public and body-local binders, result expressions and proof meaning; all seven provider declarations in five regions; target/provider ambient context; all final commands; every substantive decoder reconstruction section; and the decoder's evidence/provenance/limitations. The target comparison is declaration-by-declaration in target-declaration-crosswalk.json. Providers and ambient claims are compared in provider-ambient-crosswalk.md. coverage.json disposes every page-9 source inventory ID and each decoder file/section. Mechanical inventory checks are not mathematical coverage approval.

## 2. Core three-way meaning

Let c=sqrt(2)/2 and q(a,b)=a AND b. The source-first derivation fixed the graph input sum_(a,b) ket(a,b) ket(q(a,b)) ket(eta_ab), with arbitrary complex/reference-correlated eta_ab. Destructive X outcome o gives D_AND^o psi/sqrt(2), and conditional CZ^o cancels the phase. A reset-output branch is J0 psi/sqrt(2); each branch has half the input mass. Source Eq. (12)'s displayed state arrows are interpreted as normalized conditional-state bookkeeping together with the explicit fair-outcome statement, not as a Kraus vector with its scale silently removed.

The own-formal interpretation identified the defined table

    F_m(alpha)(r,a,b,t)
      = delta_(t,0) * conditionalCZSign(m,a,b) * H[m,q(a,b)] * alpha(r,a,b),

and proved by independent hand reading that it simplifies to c delta_(t,0) alpha(r,a,b), with the stated finite-sum mass consequences. This retained the exact factor, phase convention and both outcomes. It also distinguished the specified coefficient table from any real operation sequence.

The actual decoder reconstructs that same piecewise formula and exact simplification. Its theorem sections explicitly state both-outcome parametricity, exact complex equality, arbitrary alpha/r, the one-half norm factor, legitimate normalization premise only in the normalized mass theorem, and total mass across the two separately indexed branches. Its interpretation/boundary section explicitly notes that the initial AND graph vector is not defined and operated on by the target, zero support is built into the definition, and physical measurement/reset/feedforward/resource closure is not established.

Therefore no material semantic discrepancy was found at this literal ideal-helper layer. This is a scoped comparison result, not an equivalence verdict between the source's entire circuit construction and an actual program.

## 3. Labels, amplitude domains and tensor/reference interpretation

The decoder's m is a branch label and its r is an arbitrary R index, as in the target. Mapping to the source requires formal m = source Eq. (12)'s new outcome r; formal r is a reference index, not source r; source Eq. (13)'s earlier-history m is absent. The decoder did not perform this source-relative map while blind and did not claim to. The reviewer supplies the map here from the independently frozen source reading; this is additional comparison information, not a correction to a wrong decoder label.

Both formal readings allow arbitrary R pointwise, adding Fintype R only for masses. Neither assumes real, positive, normalized, factorizable amplitudes. Empty R is allowed; its zero mass cannot satisfy the normalized theorem's h. Both recognize finite-reference correlations in alpha without claiming an infinite-reference Hilbert norm for arbitrary functions. The source-first result has an explicit arbitrary-reference operator/density interpretation; the target and decoder have no declared channel/tensor adapter. The stronger source-side result does not become a compiled theorem through this comparison.

The curried formal output indices are r,a,b,t. The source-first output convention is a,b,target,reference. The decoder treats the former as amplitude labels, not as a certified physical tensor order. An actual implementation still needs the order adapter; no false agreement about already-fixed physical wire order is inferred.

## 4. Phase and mass conventions

All three readings agree that the raw minus outcome contributes the AND-dependent sign and that CZ on the same controls cancels it. The exact H provider includes i Ry(pi/2) Rz(pi), yielding c times ((1,1),(1,-1)), not merely that matrix up to a global phase. The decoder explicitly keeps that phase factor, as the own-formal interpretation did.

Both formal reconstructions retain c rather than normalize each branch to unit scale. branchScale_normSq, per-coefficient t summation, the finite mass theorem and the final sum establish the right mass of the specified tables. Source conditional states and formal unnormalized tables are compatible after the explicit mass/normalization adapter; they are not identical syntactic state conventions. The decoder expressly distinguishes squared coefficient mass from a probability-space/measurement-instrument theorem. No Born-rule supplier is created by the name outcomeMass_of_normalized.

Both m=0 and m=1 are required cases, and both t labels are covered. Source-first direct-Toffoli and MBU are OR alternatives for cleanup. The target/decoder cover an MBU ideal branch helper only; they need not implement the direct route to make that narrower helper true. Neither formal reconstruction supplies a comparison of actual route resource costs.

## 5. Reset and actual operation/composition frontier

The source releases the measured ancilla and allows its restoration; the source-first derivation distinguishes discarded and reset output codomains. The target chooses a reset-shaped table by construction: t=0 has the coefficient, t=1 has zero. The actual decoder explicitly identifies that convention and does not infer an independently defined reset operation. It therefore agrees with the own-formal reset boundary rather than silently treating a discarded wire as a retained zero qubit.

Likewise, the supplied Hadamard entry is concrete mathematical content, not an opaque favorable premise, but no destructive-X instrument is defined. conditionalCZSign is a literal diagonal multiplier, not an actual controlled-Z program placement. andBit is a truth function, not a Toffoli execution. The own-formal interpretation and actual decoder both state these limitations.

The common unresolved bridge remains: actual ordered Toffoli and concrete use preserve the graph invariant; actual destructive-X branch/Born semantics matches the H row; actual outcome-controlled CZ acts on the same retained controls/reference order; actual reset or separately typed discard is supplied; actual adaptive program composition denotes the coefficient table; state/mass/channel and tensor-order adapters are proved; and actual resource counts are supplied if claimed. This comparison supplies none of these operations.

## 6. Differences of exposition or scope, not concealed disagreements

The decoder inventory is more explicit than the reviewer's own interface inventory about local h, per's local binders, internal sum indices, the result let scale in hadamardMatrix_apply, and parentheses that are result syntax rather than public binders. Those distinctions agree with the actual target/provider text and with the reviewer's public-binder lists and proof explanations. They do not reveal an additional public hypothesis or change a theorem's meaning.

The decoder explicitly says realOrthogonalRotation(cosine,sine) has no cosine^2+sine^2=1 premise and the name alone does not certify orthogonality for arbitrary arguments. This is a useful clarification of the same literal matrix already independently reconstructed by the reviewer. Neither prior reviewer packet claimed arbitrary-argument unitarity. Similarly phaseMatrix's usual diagonal simplification is explanatory, is not a supplied theorem, and is unused by the target in both readings.

The source-first packet includes mixed-state and classical-record conclusions derived from ideal operators, and discusses generic-f Eq. (13). The decoder properly does not assert those as target declarations. Its statement that it cannot decide source fidelity while the source was withheld remains appropriate to its frozen blind phase. This later source-informed comparison is not a retroactive source verdict by that decoder.

No material correction to the displayed formulas, public binders, result types, matrix phase, mass factor, both-outcome scope or reset/operation boundary was required. No real difference was erased by averaging; no artificial disagreement was invented to make the comparison look substantive.

## 7. Evidence and trust limits

Decoder evidence and inventory agree on 6 target definitions, 5 target theorems, 6 provider definitions and 1 provider theorem, with 5 provider regions, 1 target import, 1 namespace pair, 2 #check commands and 3 #print axioms commands. Input pins match the own-formal phase. Both readings treat the raw-provider/module hashes, region offsets and toolchain as supplied metadata rather than checked raw-provider execution. The supplied formal_text digests were independently checked in both the reviewer and decoder records, not upgraded into whole-module/mask/TCB correctness.

The decoder records source-blind chronology and exclusions. This reviewer verified the frozen textual records and byte bindings; no excluded tool log or private conversation was inspected to prove real-world independence beyond those records and the staged authorization. Source commands asking for type/axiom information are still not outputs. No new compiler, simulation, Git, network or child agent was used here.

## Frozen scoped conclusion

The actual decoder is textually and mathematically consistent with the reviewer's independently frozen formal interpretation and with the ideal local AND-branch meaning derived source-first, within the exact bounded inputs. The unprovided actual-operation/composition frontier persists unchanged. This three-way text comparison is complete at that scope; source-circuit final admission, source-topology approval, actual program realization, resource closure and compiler acceptance are not granted.
