# Three-way comparison public-safe allowlist

State: THREE_WAY_TEXT_ONLY. Privacy/content eligibility is not correctness or publication approval.

Candidate filenames: three-way-comparison.md, target-declaration-crosswalk.json, provider-ambient-crosswalk.md, findings-and-scope.md, coverage.json, input-chronology.md, public-safe-allowlist.md, handoff.md, structural-checks.json, manifest.json, THREE_WAY_TEXT_ONLY.seal.json. Use only artifact-relative identifiers and stable [primary-source anchors](https://arxiv.org/pdf/2610.22367v1#page=9), not host absolute paths.

Do not copy or publish the original private source render. No author packet, raw provider, compiler/test/axiom output, private decoder log or other review is included. Actual decoder content is described only with its exact frozen textual scope and byte pins; its source-blindness/execution records are not presented as independently inspected hidden logs.

Any public conclusion must retain: ideal-helper agreement only; explicit conditional/Kraus, phase, mass, reference-order and reset conventions; actual-operation/composition/resource suppliers still unprovided in the bounded material; no compiler result or whole-TCB audit; no source-topology self-approval, Proof Seal, PURIFIED state or source-circuit final admission. Both prior reviewer freezes and the actual decoder remain unchanged.
