# Actual comparison findings and non-admission boundary

State: THREE_WAY_TEXT_ONLY. Findings below result from full reading of the actual decoder packet after two independently frozen reviewer phases, not from a parent verdict or summary-only comparison.

## C1. Literal target reconstruction agrees across all eleven declarations

Every target declaration's leading binders, body/result, both-outcome scope, finite-reference conditions and proof meaning agree. The decoder also accurately separates local h, local per parameters, finite-sum indices, conclusion let scale and result parentheses from public theorem inputs. Those details are more explicit than some reviewer prose but do not add a hypothesis or alter the conclusion.

No material discrepancy was found in c=sqrt(2)/2, the AND bit, conditional sign, H's row/column order, exceptional negative entry, exact complex equality, t=0 support, half-mass, normalized-mass premise or sum of both masses. The three-way comparison is favorable at this ideal coefficient-helper layer only.

## C2. All seven provider declarations and ambient limits agree

The decoder reconstructs the concrete H matrix with its required i prefactor, the four underlying rotation definitions, the unused phaseMatrix, and the H entry proof without treating a matrix name as an operational certificate. Its explicit observation that arbitrary realOrthogonalRotation arguments do not come with an orthogonality condition is correct and does not contradict the reviewer's literal formula. No target proof uses phaseMatrix.

Both preserve bounded formal-region rather than raw-provider/TCB scope. All input and embedded-formal-region pins align. Final #check/#print axioms source lines are not result files. No compiler or imported-axiom verdict is available.

## C3. The source-to-formal convention map is explicit, not silent

Source conditional state arrows do not display the Kraus scale; the source-first derivation supplies it and the formal helper/decoder retain it. Their branch masses therefore match the source's fair outcomes without treating normalized states as unnormalized vectors. Formal m is the new source outcome r, formal r is the reference index, and source earlier-history m is absent. The source-informed label map was not available to the frozen blind decoder and is added here, not retroactively attributed to it.

The source's released target plus possible restoration and the formal zero-output sector are compatible only through an explicit reset/discard convention. Both formal readings acknowledge that the zero sector is defined, not physically realized by a theorem. Reference-index functions allow arbitrary complex correlations, but actual tensor-order/Hilbert/density adapters remain beyond the declared target.

## C4. Shared operation/composition gaps remain open

Agreement of the decoder and reviewer does not supply any actual operation. The bounded target/providers still do not furnish the actual ordered AND computation and maintained use invariant, destructive-X instrument/Born law, actual conditional CZ placement/control, reset/reallocation or separately typed discard endpoint, actual adaptive-program composition, tensor/state/mass adapters, or claimed resource counts. Their availability elsewhere was not investigated. The source-first generic-f correction supplier also remains beyond this narrower AND helper and is not a target conclusion.

The source direct-Toffoli route is an alternative construction, not a required dependency of a local MBU coefficient helper. Lack of that route in this target is a scope limitation, not an erroneous helper statement. Likewise a blind decoder's lack of source-relative verdict is correct for its phase, not a negative source verdict.

## C5. There is no observed material disagreement to resolve, but there are representation differences

Observed differences are: source versus unnormalized-formal branch representation; source versus formal variable names and tensor-index organization; source-side stronger ideal reference/density/history analysis versus the narrower declared formal helper; and decoder's more detailed local-binder/naming caveats. They have been mapped explicitly and do not contradict the formulas or supplier frontier. No correction to either prior frozen reviewer packet or the actual decoder is proposed on this evidence.

This does not assert absolute equivalence of every uninspected implementation, source root or future artifact. It says no material semantic discrepancy was found after full comparison of these exact bounded texts and their declared scope. The actual decoder's source-blindness is recorded and staged before this comparison; the reviewer verified record consistency and exact bytes, not excluded private histories or execution logs.

## Allowed conclusion and forbidden promotion

Allowed: the actual frozen decoder faithfully reconstructs the eleven displayed target declarations and seven supplied provider declarations, and this reconstructed literal helper meaning is consistent with the independently derived ideal local source mathematics after the stated convention adapters.

Not established: actual source-circuit or program implementation, physical reset/measurement realization, generic-f cleanup, whole-program resource correctness, successful Lean compilation, actual axiom output, full-provider/mask/TCB audit, independently accepted source topology, Proof Seal, PURIFIED state or final admission. No mathematical/source-graph self-approval is issued.

Failure classification: NONE for this bounded text comparison. Unprovided operations and execution evidence remain OPEN/NOT_INSPECTED; no source-invalid, refuted, API-blocked or implementation-failed label is inferred. Neither agreement nor a file/hash count closes the source-circuit root.
