# Actual decoder comparison chronology

State: THREE_WAY_TEXT_ONLY. Reviewer role: temporary_and_source_first_c110. Direction fingerprint: C110-actual-decoder-full-three-way-helper-operation-frontier.

## Immutable earlier phases

Phase S independently derived the primary source before formal exposure and froze source-only seal `dddfc589403e962639008468f253c39dfb5cc5a7bf49b5a2d6c74dda13b28e47`. Phase F then read only the authorized formal target/providers/context, independently reconstructed the complete formal meaning and froze own-formal seal `4863c52f5269105e5506a9fcab4628dbd1f6f9ee7b571a8d9795eaa17de108f4` before actual decoder exposure. These packets are not rewritten. This comparison is source-informed and decoder-informed, not itself source-blind.

## Newly authorized inputs and actual order

1. Parent separately authorized actual-decoder comparison after reporting the prior own-formal byte-binding checks. The allowed new input was exactly five actual decoder files, and a new output packet. The parent supplied manifest/seal pins, not a comparison verdict.
2. Checked the five authorized filenames/lengths and the supplied manifest/seal digests. Read complete manifest.json and content-seal.json, including their input pins, output allowlist, binding order and freeze limits.
3. Read all reconstruction.md, including every definition, provider description, five theorem/proof reconstructions, dependency sketch, operational boundaries, chronology, allowlist and handoff.
4. Read all declaration-inventory.md, including the ambient commands, T1-T11 public/body/conclusion binder distinctions and proofs, all P1-P5 seven provider declarations and metadata caveats.
5. Read complete evidence.json, including every input/governance/provider/inventory/blindness/execution/scope/allowlist/binding field. Recomputed all three payload hashes/lengths, verified the exact decoder manifest-to-seal binding, and compared the recorded formal input/region pins with the already independently read formal inputs. No sibling file was opened.
6. Performed the actual full three-way text comparison recorded here, retaining both agreement and all representation/coverage differences and actual-operation suppliers. No predetermined no-difference conclusion was assumed. Authored only new comparison files through apply_patch.
7. Packet-local inventory/coverage/hash/privacy checks preceded manifest and acyclic content seal. These are mechanical text checks, not compiler or mathematical approval gates.

## Actual decoder input pins

reconstruction.md: `3e97ea0fcbadf399fcc315c8c40524ee3dd0be38a162ed0fb3df459184f856f5`.

declaration-inventory.md: `519f2d45b0d4e09dc7ccb1f8a7e0bdbb707fcdf3031ee98153a05819a9295f7e`.

evidence.json: `f86a0840c7a6a35e49141d8075f57d75d78a047c0cb1fa7cfcf6a1dc0e3f5b5a`.

manifest.json: `ab809a89c325745a9d0c46674932adb30c4d73e322734ce12814b2980561ea77`.

content-seal.json: `dedb6b35cee998fd8e10529acdd47efcd0b745a3fb68e76d32c97f141be08957`.

## Still excluded

No C105 author source/Statement Seal, compilation/test/result artifact, production raw provider, other review, private decoder log/history, Git, network, compiler, simulation or child agent was read/run. The only new external input files were the five authorized actual decoder files. The prior source PDF was not re-ingested, and the source/own-formal freezes were not changed. The actual decoder's own chronology was read as frozen record, not independently reenacted.

## Freeze scope

The conclusion is a bounded three-way text comparison, not a missing-operation supplier, source-circuit final admission or source-topology self-approval. Subsequent new evidence requires a separately authorized and bound successor; no earlier frozen payload may be silently rewritten.
