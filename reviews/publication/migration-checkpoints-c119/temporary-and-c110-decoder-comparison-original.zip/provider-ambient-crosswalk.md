# Seven provider declarations and ambient comparison

State: THREE_WAY_TEXT_ONLY. All entries compare the exact provider regions previously read independently with the actual decoder's reconstruction and exhaustive inventory. No raw provider module was newly read.

## Provider declarations, exhaustive

| Declaration and decoder location | Own-formal meaning | Actual decoder meaning | Comparison and source relevance |
| --- | --- | --- | --- |
| realOrthogonalRotation; inventory P4 | Literal matrix ((cosine,-sine),(sine,cosine)); two real leading arguments, body row/column indices. | Same formula and binders; explicitly no cosine^2+sine^2=1 premise and no arbitrary-argument orthogonality theorem. | Agree. Decoder adds useful naming caution, not a new hypothesis or contradiction. The name alone is not a source-operation supplier. |
| realRotation; inventory P5 | realOrthogonalRotation(cos(angle),sin(angle)); one angle parameter. | Same definition, no body binder, dependence on P4. | Agree. No separately supplied unitarity theorem or actual compiled rotation is inferred. |
| standardRyMatrix; inventory P2 | realRotation(theta/2), hence the half-angle real rotation matrix. | Same one real parameter and ComplexLCU namespace/open context. | Agree. Part of concrete H definition, not an additional kickmix gate assumption. |
| standardRzMatrix; inventory P3 | Diagonal cos(theta/2) minus/plus i sin(theta/2), with zero off-diagonal entries. | Same half-angle signs, theta leading, row/column body lambdas, equality tests as conditions rather than hypotheses. | Agree. Exact signs feed the H phase calculation. |
| hadamardMatrix; inventory P1 item1 | i scalar-times Ry(pi/2) Rz(pi), exactly c((1,1),(1,-1)). | Same multiplication order, scalar action and exact global phase. No leading arguments; Matrix type indices are not value binders. | Agree. Concrete matrix content is stronger than an opaque desired sign, but not a destructive-X instrument declaration. |
| phaseMatrix; inventory P1 item2 | exp(i theta/2) Rz(theta), diagonal; usual exp/trig identity gives 1 and exp(i theta). Unused in target. | Same formula, binder and unused status; no supplied simplification theorem needed by target. | Agree. No inferred generic-f correction oracle, target dependency, resource claim or source gate implementation. |
| hadamardMatrix_apply; inventory P1 item3 | H's three positive c entries and one negative c entry, proved by bit cases, exact trig, matrix expansion, i^2 and ring arithmetic. | Same theorem, row/column leading; scale is a conclusion-local let; half is a body-local proved arithmetic fact; internal matrix sum is not a public binder. | Agree. Decoder local-binder precision elaborates the same proof. This is not an X-instrument/Born/tensor semantics theorem. |

The complete five regions have the same formal_text digests in the reviewer's independently checked provider packet and decoder evidence P1-P5. Region/module raw hashes and offsets remain metadata only. The decoder uses [start,end) as a display convention and explicitly declines to audit original indexing/raw boundaries; the own-formal record likewise calls its ranges reported metadata. Neither supports an independently verified raw-provider claim.

## Target ambient and terminal commands

The target has exactly one import, QuantumBlockEncoding.PrimitiveMacros; namespace ASPBE.Uncompute.MBU and its end; no target section-variable, local notation, open, universe declaration, structure, class, inductive, opaque, axiom or other declaration. Both reconstructions describe the complete target syntax rather than importing a project contract bundle into theorem binders. Type* allows a universe-polymorphic R; standard Lean/Mathlib number, finite-sum, matrix and norm infrastructure is not reaudited here.

Both record #check on correctedTemporaryAndBranch_eq and correctedTemporaryAndBranch_mass, and #print axioms on those two plus sum_branchMass. These five terminal commands are source text, not outputs. No elaboration success, actual axiom inventory or imported-TCB closure is implied.

Provider P1 includes actual import/open/namespace text: ReversibleClassical, Mathlib.Tactic and open QuantumBlockEncoding.Robin.ComplexLCU under QuantumBlockEncoding. Provider P2-P5 scope is accompanied by supplied namespace/open metadata rather than full module headers. Both reconstructions preserve this difference. No claim about hidden surrounding declarations or transitive name visibility is upgraded to a checked compiler fact.

## Dependencies and AND-tail interpretation

The decoder's dependency reconstruction names definition references and proof ingredients, with braces explicitly conjunctive. It does not claim independently sufficient arrows for each ingredient or an elaborated proof-term graph. The reviewer independently reconstructed the same spine: rotation definitions supply H's entry theorem; the literal branch definitions plus that entry theorem supply cancellation; cancellation plus scalar norm-square and finite-sum identities supply half-mass; the normalized and total-mass corollaries use half-mass. phaseMatrix is not on the target spine.

This agrees with the reviewer's full-tail/source-topology discipline. It does not make the decoder's formal dependency sketch identical to the source construction graph: the source has direct-Toffoli versus MBU OR routes and actual measurement/correction/reset construction obligations, whereas the target sketch has coefficient helpers and arithmetic dependencies.

## Evidence/ambient trust comparison

The decoder's three input hashes equal the previously authorized target/providers/context pins. Its inventory totals match the exact syntax inventory. Its six governance hashes match the corresponding previously read governance versions; this is process provenance, not new mathematical evidence. The decoder's reported toolchain, raw module hashes and raw-region hashes remain metadata. Its recorded source blindness and no-execution chronology are consistent across reconstruction, evidence, manifest and seal; this comparison verifies those records, not unseen execution logs or world-level independence.

No ambient, result-type, matrix-sign, normalization, reset or operational supplier discrepancy was found within this bounded comparison. Shared absence of actual operation semantics is explicitly retained rather than hidden behind agreement.
