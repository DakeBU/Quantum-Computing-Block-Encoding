# C104 independent whole-formal-first reconstruction

Status: OWN_WHOLE_FORMAL_INTERPRETATION_FROZEN, before independent-decoder release. This is an independent source-relative mathematical reconstruction of the authorized comment-masked snapshots, not compiler evidence, publication approval, source self-approval or formal admission. No claim is based on the parent’s other-track progress.

## Scope and what was actually read

I read the complete target snapshot, lines 1–26985, including all 677 explicit declarations, all 114 private helpers, all 69 structures and their 1950 lexical fields, the actual proof/definition bodies and all 11 ambient regions. The 12 read-batch files contain my separate interpretation of every CF0001–CF0677. The 14 exact-interface fragments retain complete displayed signatures and each field’s exact decoded type/default, individual typed disposition and owner interpretation. This is not a claim of semantic coverage from a mechanical inventory.

The target SHA256 is 17735bc5f3a1d42fa16d9cf55d33237af432178b19c6946cc2294d7d41e61de8. Its formal-input manifest is 1e9753617607d960798a6161dcb5b3f0d338524fae3885d1a22d6200b8b7dbf5. All seven supporting Lean snapshots were also read completely, including GHL2025 lines 1–8474; the three configuration files were read as context only. Exact provider extent is in provider-read-ledger.json and the meaningful consumer/provider spine is in provider-spine.json. Mathlib proof bodies, external papers, generated exports, compiler/CI and the actual independent decoder were not read.

The earlier three source/review freezes remain unchanged. They precede this formal read. The parent-authored C111 successor remains retrospective implementation-informed local mathematics, not independently approved paper text. Historical formalizer identity remains UNKNOWN. The production raw subject was not read or changed. The comment-mask relation itself is bounded preprocessing provenance, not a lexer/Lean-preservation proof.

## Independent outcome

The literal local mathematical content of successor W0–W8 is supported by the actual displayed formal types and definitions, subject to its stated scope and the qualifications below. The two previously frozen corrections remain necessary and correct: W7 now acknowledges forced positivity of interpreted kappa and its inverse; the stored normalized scalar factor is explicitly different from the actual cosine entry. I found no reason to remove either qualification.

This is not acceptance of a physical Robin block encoding, full normalized block equality, a publication-facing generated interface or correctness of elaborated proof terms. The actual final local result is a conditional identity for one selected compressed prepared entry. The old unrestricted raw active-entry fold is explicitly refuted, not merely unproved. Open corrected physical-operator questions concern a different, incompletely specified layer.

## Carriers, target and honest certificate meanings

Coeff is free syntax with rational literals, String symbols, add, mul and neg. Its evaluator has environment String → Rat. In particular A1*dx is one String symbol, not multiplication of two symbols. Matrix multiplication is the literal zero-seeded fold over finite middle labels. Circuit evaluation starts at literal identity and left-multiplies successive supplied matrices. Rational associativity/distributivity used after evaluation do not give raw AST reassociation.

Stencil lookup uses signed integer equality, no modular wrap, and a nonempty matched-entry fold. Boundary row selection is left-first, then right, then bulk with total small-n fallback. Ak is row-scaled by f(n,i). At n3, Ak00 is raw f_3_0 times d, where d=-5/2+(7/3)*symbol(A1*dx), by CF0206 and the actual global slot2 provider. The function called matrixOneNorm is a maximum absolute ROW sum, not the usual column-sum 1-norm. Resource and layout numbers are stored formulas; neither these nor error0 data prove extraction, consistency or physical workspace return.

All 1950 fields have individual dispositions in the interface fragments. There are 27 genuine target-structure equality certificates: matrix coherence and exact parameter/cache/wiring/scope/status equalities. They prove exactly their displayed relations, including several relations to false Boolean values. They are not block-correctness fields. There are 40 Prop-valued data fields and 2 predicate-valued data fields. Storing such a proposition is not proving it. The 829 Bool fields and 219 semantic-status records likewise do not prove their names. The remaining 366 Strings, 196 Nat fields, 114 Coeff fields, 5 direct Matrix fields, 42 finite index/list/function fields and 110 nested typed-data fields retain their displayed meanings. Nested generic semantics does carry its own pointwise evaluation/cache certificates, but not an automatic physical unitary theorem.

No ambient variable command introduces a hidden hypothesis. The namespace/open/import commands and the local maxRecDepth option are explicitly retained. Auto-implicit elaboration, generated recursors/projections/deriving exports and actual public declaration expansion remain separate unassessed gates.

## Actual gate and restricted-cleanup providers

The active list is exactly U,T,R,B,F,S,Bt (CF0677 and GHL5706–5715), with five semantic-status unitary flags false and only U/S flags true. I read the U and S self-inverse/bijection/permutation provider proofs as actual mathematical facts, not just their flags.

T is identity for indicator0; otherwise its ancilla pair is (c,-s;s,c) with nonancilla-bit preservation. R is identity for indicator1 and otherwise its corresponding signed pair. F has a specified normalized clean branch and literal zeros at other clean output rows; its orthogonal/dirty entries are free symbols, not silently zero, identity or system-preserving.

B replaces the address block by the global offset-plus-row modulo N while preserving low/high blocks. Its offsets are N-2,N-1,0,1,2,N-3,3, fallback0. Bt is the transposed image indicator. Active source means clean padding AND decoded slot<kappa. The encoded eighth slot is not included when parameter kappa=7. The active-domain inverse-slot table is 4,3,2,1,0,6,5; fallback2.

For n>=3, parameter kappa7, explicit bits3 and an active source, the provider supplies finite post/pre labels, clean/range/image certificates and the unique active preimage; the dagger-column indicator is universally quantified only over active other rows. Uniqueness needs the other preimage to be active too. The provider also proves a weaker candidate-existence route for a broader clean source. That broader existence must not be read as broad uniqueness or full-column cleanup. False historical cleanup flags do not erase the genuine restricted theorem, and the theorem does not change those flags.

A further independently derived check sharpens this boundary. At the fixed p3, source labels32 and112 decode to row0, slots2 and7, respectively; padding is clean in both. Both offsets are0, both low prefixes/high tails are0, hence Bimage(32)=Bimage(112)=0. Thus their complete raw B columns coincide: both are the indicator of output row0. After the faithful rational 0/1 interpretation, B sends the nonzero vector e32-e112 to0 and cannot be an injective/unitary full-space operator. This is a mathematical deduction from the displayed definitions, not a newly compiled Lean theorem or a simulation. It reinforces the necessity of the active restriction; a separately specified extension may modify excluded/dirty columns while agreeing on active inputs. It does not rule out that different extension.

## Complete selected and zero support, not path sampling

Write P=B*(R*(T*U)), Q=Bt*(S*F), M=Q*P. At n3 the selected source/target is32 and its companion33.

For the selected column, all intermediate-label cases confine evaluated Pcol32 to0/1. Qrow32 is evaluated0 at1. CF0152 kills every q!=0 product, then CF0153–CF0159 reduce the unique q0 path and give, for EVERY environment,
eval M32,32 = (f*u)*c,
where f=e(f_3_0), u=e(N_f_inv), c=e(boundary_cos_half_0_2). No inverse or trigonometric law is needed.

For col0, evaluated P is supported only96/97. Btrow0 permits96, Srow96 permits12, and F12,96=F12,97 are literal0. CF0184 therefore gives eval M00=0. CF0185 separately propagates the actual identity seed and every gate-fold support step; CF0187 gives eval A00=0 for EVERY environment for the actual active chronological matrix. Its bridge to M00 is evaluated equality because both are0, not raw reassociation.

Historical finite path probes and the bulk90→218→218→218→170→170→212→228 path were also read in full. Comparing that bulk path with a clean boundary endpoint84 is the source’s correctly qualified boundary/bulk mismatch, not a universal unwanted indicator-reset theorem.

For s:Fin7 let b(s)=16s and C(s)=M[b(s),b(s)]*(a*a), a=symbol(sqrt_kappa_inv). The nonselected prefix pairs are (112,113),(16,17),(32,33),(80,81),(48,49) for slots1,3,4,5,6; corresponding SWAP row preimages are14,2,4,10,6. Every one of these pairs has both suffix entries killed by exact F zeros and complete Bt/S row support. Slot0 uses the grouped00 theorem. All six evaluations vanish without normalization laws. CF0445 requires ALL six vanish premises and CF0446 supplies them to show eval L(C)=eval C2 for every environment. It does not prove raw L(C)=C2.

## Stored scalar versus actual cosine, and the full normalization tail

CF0211 literally defines the stored factor
Bnorm=(f_symbol*N_f_inv)*(Dslot2*N_D_inv).
Consequently CF0216 needs exactly hND:p*x=1 AND hNF:u*y=1 to prove eval Bnorm*(x*y)=f*d. Here p=e(N_D_inv),x=e(N_D),y=e(N_f). It has no HENTRY premise because the factor already contains normalized D syntax. This is the formal verification of the T02 distinction, not a repair of the formal text.

By contrast CF0204/CF0205 and CF0308 retain the actual-cosine identification
HENTRY: c=e(Dslot2*N_D_inv)=d*p.
A corrected 2arccos formula stored as a String does not change c or prove this equation.

The strongest final prepared scalar head (CF0651 and its CF0662–CF0669 wrappers) is
eval P(H) * eval((N_D*N_f)*kappa) = eval Ak3[0,0].
Its complete sufficient AND tail is: arbitrary H:Matrix8 8 Coeff and environment; all seven raw Uniform(H) equalities H[s,0]=a; HENTRY; hND; hNF; hkappa:q*z=1; hSquare:a_value*a_value=q, with q=e(kappa_inv),z=e(kappa). Its provider tail also includes the complete selected-entry/support theorem, all six zero feeders and fold collapse, literal-transpose specialization, evaluated singleton identity, target slot2 equality and exact normalizer/cache definitions. No tail is replaced by OR. The detailed graph and exact displayed interfaces retain these dependencies.

The scalar derivation is f*u*c*a_value²*(x*y*z)=f*u*(d*p)*q*x*y*z=f*d using precisely those supplied laws. Parameter kappa7 is not the assertion z=7. The theorem’s status/cache conjuncts keep the unchanged active finite contract’s normalized/projection/extraction/unitary/resource claims false as stored data.

The F01 correction is mathematically forced: q=a_value² and q*z=1 imply a_value!=0, q>0,z>0 over Rat. hND/hNF give nonzero p,x,u,y but not their positive signs. HENTRY need not give a trigonometric value/bound. The final scalar law is jointly consistent as rational algebra: for example choose d=1 via e(A1*dx)=3/2, and f,u,c,a_value,p,x,y,q,z all1. Choose H[s,0]=symbol a for s0..6 to satisfy Uniform syntactically; this is not a normalized/unitary H witness.

An additional assumption z=7 would force 7*a_value²=1. Writing a_value=m/n in lowest terms implies 7m²=n²; prime7 divides n, then m, contradiction. This is a rational-carrier obstruction only, not a real/complex preparation impossibility. It is not an actual theorem premise added to the source.

## What the prepared matrix is, and which raw route is refuted

Uniform(H) is precisely seven RAW entry equations, leaving row7 and every other column unconstrained. Hdagger is literal transpose in this route, with no conjugation or inverse proof.

K(H)[r,c] is the single sevenfold of M[b(s),b(s)]*(H[s,c]*transposeH[r,s]). This is diagonal compression. A physical lifted Hdagger*M*H would generally involve two independent branch indices, offdiagonals and excluded sectors. No such reduction is supplied by defining K.

K00=Ksum(H) definitionally. Uniform implies raw Ksum(H)=L(C). A singleton labelled composite gate is assigned K as its matrix with unitary statusfalse; label match produces a genuine generic CircuitMatrixSemantics object. Because of the literal identity seed, its clean entry P(H) equals K00 after rational evaluation. Thus Uniform gives eval P(H)=eval L(C)=eval C2. It does not identify the active seven-gate A00 with this different object.

The exact raw backend predicate has only two conjuncts: selected C2 equality AND raw signalBlockEntry=L(C). It has no extra formal provenance conjunct. Cache/cast equivalences transport that same raw equation. Their conditional wrappers are not completed alternative proofs.

For fixed e, Fold(e) means eval A00=eval L(C). CF0598 gives exactly Fold(e) iff eval C2=0. Under HENTRY and all four scalar laws, the nonzero normalizer lets me further derive Fold(e) iff eval target=0 iff f=0 OR d=0. This last OR is ordinary zero-product factorization over a field, not competing preparation routes. No Uniform is needed for this Fold characterization.

At e* mapping f,u,c,a_value to1 and all other symbols0, C2 evaluates1 while A00 evaluates0. Any raw equality would survive this interpretation, contradiction. CF0612,CF0613 and CF0676 explicitly refute raw backend expansion, raw projection summation and A00=L(C). e* violates inverse laws, but the refuted raw target has no such hypotheses. A fixed environment with C2eval0 may still satisfy Fold; failure for every environment is not proved.

Under Uniform, raw A00=K00 would imply the refuted raw A00=L(C), so that exact proposed supplier is refuted, not merely open. Conditional theorems using raw backendExpansion (including CF0670) remain well-typed implications with an already refuted premise; they provide no viable positive route. Clean-column congruence only transports an already supplied equality.

## Remaining limits and findings

The actual correctedFiniteBlockProjectionEquality field is a SemanticObligation, not even a typed equality specifying a corrected physical operator. A substantive next mathematical statement would need a separately specified full-space prepared operator/register lift, its offdiagonal/unused-sector reduction to K if true, actual preparation/unpreparation and adjoint semantics, coherent indicator/garbage treatment, analytic amplitude/bounds/normalizers, a full normalized block and extraction theorem, and declared query/logical/physical/finite-bit resource models. I do not invent such an operator, add a final hypothesis or repair production code.

The theorem-facing ten labels, active seven labels and compressed singleton label remain different circuits. The two printed SWAP labels are swap0,0 while supplied S swaps n-bit blocks; generic matching of labels does not synthesize that matrix. Strings claiming “full prepared sandwich” in historical packet anchors are retained but must be interpreted against the actual diagonal-only K definition, as successor W6/W7 explicitly does. No positive full-sandwich claim is accepted from those Strings.

Source-relative mathematical reconstruction is complete at the explicit target/body/field level. The following remain unassessed: faithful comment masking versus production raw code; external-paper/source attribution; historical formalizer identity; all generated/elaborated public exports; Mathlib transitive proof/kernel dependencies; compilation/TCB; independent-decoder comparison; and publication admission. All old/source/negative artifacts and production bytes remain untouched. Freeze here and wait for a distinct authorization before reading any actual independent decoder.

