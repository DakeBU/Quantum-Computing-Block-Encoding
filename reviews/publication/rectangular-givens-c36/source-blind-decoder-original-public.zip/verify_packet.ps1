$ErrorActionPreference = 'Stop'
$packetRoot = Join-Path (Split-Path -Parent $PSScriptRoot) 'rectangular-givens-c36/formal-only'
$sealDigest = 'e539fa2f2fd0cf48937e218096d01d05d5c446286fc9d33c4bf4edc62490dc60'
function Digest-File([string] $Path) {
  (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLower()
}
if ((Digest-File (Join-Path $packetRoot 'seal.json')) -ne $sealDigest) {
  throw 'Pinned seal mismatch'
}
$packetSeal = Get-Content -Raw -LiteralPath (Join-Path $packetRoot 'seal.json') | ConvertFrom-Json
$binding = Get-Content -Raw -LiteralPath (Join-Path $packetRoot 'bindings.json') | ConvertFrom-Json
if ((Digest-File (Join-Path $packetRoot 'bindings.json')) -ne $packetSeal.bindings_sha256) {
  throw 'Binding digest mismatch'
}
$payloadChecks = @()
foreach ($entry in $packetSeal.files.PSObject.Properties) {
  $actual = Digest-File (Join-Path $packetRoot $entry.Name)
  if ($actual -ne $entry.Value -or $binding.files.($entry.Name) -ne $actual) {
    throw "Payload mismatch: $($entry.Name)"
  }
  $payloadChecks += [PSCustomObject]@{ file = $entry.Name; sha256 = $actual; matches = $true }
}
$formalText = Get-Content -Raw -LiteralPath (Join-Path $packetRoot 'Module0.formal.lean')
$starts = [regex]::Matches($formalText, '(?m)^(?:noncomputable )?(def|theorem) (\w+)')
$ledger = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'declarations.json') | ConvertFrom-Json
function Check-Ledger($candidate) {
  if ($starts.Count -ne 19 -or @($candidate.declarations).Count -ne 19) {
    throw 'Explicit source declaration coverage mismatch'
  }
  if (@($candidate.declarations.name | Select-Object -Unique).Count -ne 19) {
    throw 'Duplicate declaration'
  }
  for ($idx = 0; $idx -lt $starts.Count; $idx++) {
    $match = $starts[$idx]
    $entry = $candidate.declarations[$idx]
    $stop = if ($idx + 1 -lt $starts.Count) { $starts[$idx + 1].Index } else {
      $formalText.IndexOf('end QuantumBlockEncoding.RectangularGivens', $match.Index)
    }
    $block = $formalText.Substring($match.Index, $stop - $match.Index).TrimEnd()
    $separator = $block.IndexOf(':=')
    $equations = $block.IndexOf("`n  |")
    $isEquations = $equations -ge 0 -and ($separator -lt 0 -or $equations -lt $separator)
    if ($isEquations) { $separator = $equations }
    if ($separator -lt 0) { throw 'Unrecognized source declaration delimiter' }
    $signature = $block.Substring(0, $separator).TrimEnd()
    if ($entry.name -ne $match.Groups[2].Value -or $entry.kind -ne $match.Groups[1].Value -or
        $entry.signature -cne $signature) { throw 'Signature mismatch' }
    if ($entry.kind -eq 'def') {
      $bodyStart = if ($isEquations) { $separator } else { $separator + 2 }
      if ($entry.definition_body -cne $block.Substring($bodyStart).Trim()) { throw 'Body mismatch' }
    } elseif ($null -ne $entry.definition_body) { throw 'Theorem proof mislabeled as definition' }
  }
}
Check-Ledger $ledger

# Integrity-only adversarial checks. These are not Lean or mathematical verification.
$testBytes = [System.IO.File]::ReadAllBytes((Join-Path $packetRoot 'Module0.formal.lean'))
$testBytes[$testBytes.Length - 1] = $testBytes[$testBytes.Length - 1] -bxor 1
$testHash = [System.Security.Cryptography.SHA256]::HashData($testBytes)
$mutatedDigest = [System.Convert]::ToHexString($testHash).ToLower()
if ($mutatedDigest -eq $packetSeal.files.'Module0.formal.lean') { throw 'Mutation detection failed' }
$missing = $ledger | ConvertTo-Json -Depth 20 | ConvertFrom-Json
$missing.declarations = @($missing.declarations | Select-Object -SkipLast 1)
$missingRejected = $false
try { Check-Ledger $missing } catch { $missingRejected = $true }
if (-not $missingRejected) { throw 'Missing declaration negative test failed' }
$duplicate = $ledger | ConvertTo-Json -Depth 20 | ConvertFrom-Json
$duplicate.declarations[1].name = $duplicate.declarations[0].name
$duplicateRejected = $false
try { Check-Ledger $duplicate } catch { $duplicateRejected = $true }
if (-not $duplicateRejected) { throw 'Duplicate declaration negative test failed' }
[PSCustomObject]@{
  verification_layer = 'source integrity and lexical completeness only; no Lean'
  seal_sha256 = $sealDigest
  payload = $payloadChecks
  explicit_declarations = $starts.Count
  definitions = @($ledger.declarations | Where-Object kind -eq 'def').Count
  theorems = @($ledger.declarations | Where-Object kind -eq 'theorem').Count
  signatures_match = $true
  definition_bodies_match = $true
  byte_mutation_detected = $true
  missing_declaration_rejected = $missingRejected
  duplicate_declaration_rejected = $duplicateRejected
  local_Lean_calls = 0
} | ConvertTo-Json -Depth 10
