# Whole-module formal reconstruction

Decoder identity: `/root/rectangular_formal_decoder_c36`. This is a source-blind reconstruction of `QuantumBlockEncoding.RectangularGivens` from the sealed, comment-masked formal packet. It is not a comparison with a natural source, an acceptance verdict, a fresh Lean build, or an elaborated declaration census. The accompanying `declarations.json` retains all 19 explicit source declaration signatures and all six definition bodies without theorem proof duplication. The substantive-worker skill governs the whole-module handoff; the source-dependency-audit skill enforces separation of dependencies, hypotheses, and genuine missing evidence, with its natural-source-reading workflow intentionally unavailable to this blind role.

## Mathematical setting and result

Let N and M be arbitrary natural numbers, including zero. A is an arbitrary real matrix whose rows are indexed by Fin N and columns by Fin M; indices start at zero. There is no assumption of squareness, full rank, orthogonality, positive entries, a nonzero pivot, or N ≥ M.

The module defines a specific total, noncomputable sequence S(A) of adjacent-row real plane rotations. Executing those rotations on A produces a matrix R(A), and their accumulated N-by-N matrix is T(A). The formal statements give

\[
T(A)A=R(A),\qquad R(A)_{ij}=0\quad(j<i),
\]
\[
T(A)^\mathsf{T}T(A)=I_N,\qquad\det T(A)=1,
\qquad T(A)^\mathsf{T}R(A)=A,
\]
\[
|S(A)|\le NM.
\]

Thus this is a real rectangular upper-trapezoidal reduction by an orientation-preserving orthogonal left transform. If one writes a conventional factorization A = QR, the Q in that notation would be T(A)ᵀ, not the formal definition named `transform`. R is not asserted to be diagonal, unique, an isometry, or to have all diagonal entries nonnegative. The list length counts abstract adjacent-row rotation records, not elementary quantum gates or arithmetic instructions.

## The rotation convention, including all singular branches

For distinct row indices i and j, a plane rotation with parameter θ leaves other rows unchanged and replaces the selected rows, simultaneously, by

\[
\begin{pmatrix}A'_{i,:}\\A'_{j,:}\end{pmatrix}
=\begin{pmatrix}\cos(\theta/2)&-\sin(\theta/2)\\
\sin(\theta/2)&\cos(\theta/2)\end{pmatrix}
\begin{pmatrix}A_{i,:}\\A_{j,:}\end{pmatrix}.
\]

The half-angle is essential. `planeMatrix i j theta` is this row operation applied to I_N, and its multiplication on the left agrees with `rotateRows`. Its transpose is the same plane rotation at −θ, it satisfies PᵀP = I_N, and its determinant is one. The providers prove these facts for distinct i,j. The Step type supplies distinctness through adjacency.

For a pair x,y in the currently selected column, put

\[
r=\operatorname{pairNorm}(x,y)=\sqrt{x^2+y^2}.
\]

The exact formal definition is `eliminationAngle x y = -(splitAngle x y).eval`. Expanding the necessary angle providers gives:

- If r = 0, `splitAngle` is the rational-zero angle and the elimination parameter is zero. Over the reals r = 0 if and only if x = y = 0.
- Otherwise, put α = −arccos(x/r) when y < 0, and α = arccos(x/r) when y ≥ 0. The split parameter is 2α and the elimination parameter is θ = −2α.

The provider's reconstruction identities are cos(α)r = x and sin(α)r = y. Consequently the elimination operation has selected-column output

\[
\cos(\theta/2)x-\sin(\theta/2)y=r,\qquad
\sin(\theta/2)x+\cos(\theta/2)y=0.
\]

These are not hypotheses on A. They are dependency results used by the construction. In particular, the algorithm never divides by a zero norm in the active nonzero branch. When both selected entries are zero, the operation is the identity on the entire matrix, but its zero-angle record is still emitted. When y = 0 and x < 0, the selected branch gives θ = −2π: this is not the identity plane matrix, and it may change other columns. No generic rule skips an operation merely because the lower entry is already zero.

The angle syntax admits an exact-real constructor and its evaluation is noncomputable. No finite-bit representation, approximation guarantee, or computable numerical extraction is provided by this target.

## Lists, chronology, and the one-column provider

A `Step N` has fields `first : Fin N`, `second : Fin N`, a proof `first.val + 1 = second.val`, and `angle : ℝ`. Its matrix is the plane matrix just defined. For a list [s₁,…,sₗ], `applySteps` applies s₁ first, then s₂, and so on. Accordingly,

\[
\operatorname{stepsMatrix}([s_1,\ldots,s_\ell])
=P_{s_\ell}\cdots P_{s_1},
\qquad \operatorname{stepsMatrix}([])=I_N.
\]

Concatenating two lists executes the left list before the right list. For every rectangular A, `applySteps steps A = stepsMatrix steps * A`.

The imported `columnSweep A col lo count bound` requires `lo + count < N`. Its zero-count case returns A. In a successor case `count = t+1`, it first eliminates the entry in row lo+t+1 using the adjacent upper row lo+t, with the angle computed from the current A and selected column. It then recursively sweeps the updated matrix with count t. Thus the full execution order is

\[
(lo+count-1,lo+count),\ (lo+count-2,lo+count-1),\ldots,(lo,lo+1).
\]

Angles later in this sequence are computed from updated matrices, not from the initial input. `columnSweepSteps` records exactly this chronology, has length exactly count, and has the same action as `columnSweep`.

Two specific provider invariants justify the target's induction:

1. For every row with lo < row.val ≤ lo+count, the selected-column output is zero.
2. If an old column is zero in every row r with lo ≤ r.val ≤ lo+count, the entire old column is unchanged by the sweep, for every row including those outside that interval.

The provider also states that rows outside [lo,lo+count] are unchanged. The target does not need or assume square-orthogonal input. Square-SO decomposition machinery elsewhere in the supplied provider is not the rectangular algorithm being reconstructed here.

## The partial rectangular sweep

The mutually corresponding constructions here are `sweep A k remaining columns` and `sweepSteps A k remaining columns`, with the sole range proof `columns : k + remaining ≤ M`. They are separate recursive definitions, not mutually recursive functions.

For remaining = 0, the first returns A and the second returns the empty list. For remaining = t+1:

- If k < N, use column k (which exists because k < k+t+1 ≤ M), lo = k, and count = N−1−k. Sweep the current matrix bottom-up over row pairs (N−2,N−1) down through (k,k+1). Continue with the resulting matrix at k+1 and remaining t. The trace is the current column's records followed by the recursively generated records for that resulting matrix.
- If k ≥ N, leave A unchanged, emit no current-column record, and continue at k+1 and remaining t.

All subtraction is natural-number truncated subtraction. In the active branch k < N ensures k+(N−1−k) < N, so the column-sweep bound is valid. If k = N−1, the active column sweep has count zero. If k ≥ N there cannot be a row strictly below column k; no operation is necessary. This skip is not a rank or data-dependent pivot choice.

The intermediate invariant is

\[
\operatorname{UpperPrefix}(A,k)\iff
\forall c\in\operatorname{Fin}M,\ c.val<k\Rightarrow
\forall r\in\operatorname{Fin}N,\ c.val<r.val\Rightarrow A_{rc}=0.
\]

This places no constraint above or on a diagonal position, or on any column with index ≥ k. It does not mean the first k columns equal identity columns.

For a valid column c with c.val < N, `columnSweep_upperPrefix` turns `UpperPrefix A c.val` into `UpperPrefix B (c.val+1)` using precisely the full sweep starting at row c.val. The new column is zero below the diagonal by the first provider invariant. In an earlier column old < c, all rows touched by this sweep have row ≥ c > old, so the initial prefix hypothesis makes those entries zero; the second provider invariant preserves that entire old column. No orthogonality or determinant premise is used.

`sweep_upperPrefix` propagates this by induction on remaining, yielding the prefix index k+remaining. In a skipped column k ≥ N, the additional below-diagonal conditions are vacuous: any row below a new column would contradict row.val < N ≤ k. This supplies the next prefix without modifying A.

`sweepSteps_action` proves equality of trace execution and the separately defined matrix sweep by induction on remaining. The nontrivial branch uses execution of concatenated lists and the one-column action theorem. `sweepSteps_length_le` uses one-column length N−1−k ≤ N, the inductive bound N·remaining, and the skipped-branch monotonicity, giving length ≤ N·remaining. This is the actual stated coarse bound; no sharper count or runtime theorem is a target declaration.

## All remaining target declarations and their proofs

For every list of `Step N`, independently of any matrix A, `stepsMatrix_orthogonal` proves PᵀP = I_N. For a head step followed by rest, P = P_rest P_head, so PᵀP = P_headᵀ(P_restᵀP_rest)P_head = I_N. `stepsMatrix_det` proves det P = 1 by determinant multiplicativity and the one-plane determinant result. Adjacency proves the rows are distinct. These are conclusions for arbitrary such lists, not assumptions needed on the input to `decompose`.

The three final definitions specialize the partial sweep to the whole column range:

\[
\operatorname{decompose}(A)=\operatorname{sweepSteps}(A,0,M),\quad
\operatorname{reduced}(A)=\operatorname{sweep}(A,0,M),\quad
\operatorname{transform}(A)=\operatorname{stepsMatrix}(\operatorname{decompose}(A)).
\]

The dimension proof in each specialization is 0+M ≤ M. The seven final theorem declarations have the following mathematical content and derivation:

- `decompose_action`: executing the computed list on A is R(A), by the partial action theorem.
- `transform_mul`: T(A)A = R(A), by that action theorem and the provider's matrix interpretation of list execution.
- `reduced_zero_below`: for every row : Fin N and col : Fin M with col.val < row.val, R(A) row col = 0. The initial prefix at zero is vacuous, the partial prefix theorem gives prefix M, and every valid column has value < M.
- `decompose_length_le`: the list length is at most N·M, by the partial bound.
- `transform_orthogonal`: T(A)ᵀT(A) = I_N, by the arbitrary-list orthogonality theorem.
- `transform_det`: det T(A) = 1, by the arbitrary-list determinant theorem.
- `exact_recovery`: T(A)ᵀR(A) = A, by substituting R(A) = T(A)A, reassociating, and using T(A)ᵀT(A) = I_N. This proof needs only that explicitly stated one-sided orthogonality identity, not a separately imported inverse or nonzero determinant theorem.

The intermediate declarations preceding the three final definitions are exactly `sweep`, `sweepSteps`, `sweepSteps_action`, `UpperPrefix`, `columnSweep_upperPrefix`, `sweep_upperPrefix`, `sweepSteps_length_le`, `stepsMatrix_orthogonal`, and `stepsMatrix_det`. Together with the three final definitions and seven final theorems this covers all 19 explicit source declarations. The exact source-signature ledger supplies their full binders and result expressions rather than compressing them into this prose.

## Assumptions and edge cases

Every target declaration uses concrete natural dimensions and real scalars. Finite index types provide range bounds. The only extra logical premises in the partial interfaces are the column-range proof, the old upper-prefix invariant, the selected-column-in-row-range proof where required, and the below-diagonal comparison in `reduced_zero_below`. There is no project-owned Prop bundle or typeclass hiding a normalization, state preparation, rank, or circuit hypothesis. Without a natural source I do not assign SOURCE/STANDING/RULED/EXCESS labels or claim agreement with source assumptions.

- N = 0: no row index exists; all columns are skipped, no Step is emitted, and the transform is the empty identity matrix. Zero-below claims have no row instances. The stated determinant is the empty-matrix determinant one under the matrix convention used in the formal theorem.
- M = 0: the sweep is immediately finished, the trace is empty, R(A) = A, and T(A) = I_N.
- N = 1: every active sweep has zero count and later columns are skipped; R(A) = A and T(A) = I₁. In particular, a one-by-one negative entry is not made positive.
- N < M: columns with index at least N impose no below-diagonal zeros and are not selected for elimination, although earlier row rotations act on all columns of A.
- N > M: all M columns can be processed, with all rows below their respective diagonal entries zeroed. No extra zero columns or row normalization is added.
- Zero/rank-deficient matrices, repeated/dependent columns, and zero pairs are valid inputs. Zero-angle records remain in the fixed structural schedule; no division-by-rank or nonzero-pivot premise is present.
- An unpaired last diagonal entry can remain negative. The construction cannot generally enforce all diagonal signs positive while also keeping determinant T = 1; no such sign theorem appears.

There is no qubit register order, tensor-factor identification, ancilla, measurement, accepted branch, oracle access, approximation tolerance, or success-probability theorem in this target. Adjacency refers to consecutive numerical row indices, not a claimed physical-wire or basis-state compiler mapping. The auxiliary providers contain quantum circuit definitions, but this target does not assert a primitive-circuit implementation or its resources.

## Evidence boundary

The packet seal and all its payload/binding hashes were checked before decoding. Formal code was read from Module0, Module1, Module2, Module3, and Module5 in full; Module4 was hash-checked but its code was not needed or read. The full context index was read, including hash-only ambient file metadata. No listed ambient module was thereby inspected or certified.

There is no fresh Lean invocation, elaboration output, `#check`/`#print`, equation-compiler output, proof-term dependency export, axiom closure report, focused build, repository build, Tests build, or website build in this decoder run. The supplied toolchain and manifest are digests only, not their actual files or a build certificate. The 19-signature ledger is a source extraction checked for coverage, not actual elaborated types or a kernel census; generated equation declarations, private auxiliaries, implicit compiler-generated declarations and any exact elaborator decisions remain outside observed evidence. The target has no explicit private or universe declaration in the provided source, but that does not establish that the elaborated environment has no generated/private declarations.

After the formal decoding was under way, the parent supplied technical-only build context: GitHub job 117276254466 in run 38992000018 reportedly completed `lake build` (3399 jobs) and `lake build Tests` (3460 jobs) using Lean 4.33, at checkout 21276ccb2c6d5573b534ae5bd5c97b28ede0e13b. The parent reports tree 56a3d9fed9382f4dbd405e10f9fe2c7920910a0c and unchanged production source bytes, including target raw digest aa4b908e26c0e0b0bccc05034b839f170fb4a2641d96b713ff8d3fac731bcb52. This run reportedly replayed the target from cache. These are attributed parent reports, not logs or API results independently inspected by this decoder, and do not supply fresh per-declaration elaborated types or a kernel census. They are retained as inherited technical context, not treated as a new missing prerequisite for a source-signature reconstruction.

The formal proofs read coherently as the argument reconstructed above. Whether those exact proof terms elaborate in the recorded context and whether a pinned natural source has this same contract remain separate questions for the build owner and a distinct source-first reviewer. I have neither guessed a prospective publication binding nor asserted an accepted review. There is no new theorem, production modification, network access, or Git write in this reconstruction.
