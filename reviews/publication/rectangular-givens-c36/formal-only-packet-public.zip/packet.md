# Formal reconstruction packet

Reconstruct the whole target Module0 from its formal code and the supplied
necessary formal provider code. Comments have been whitespace-masked; no natural
source, intended conclusion, author classification or previous verdict is given.
The exact source visibility, all definitions and theorem hypotheses, chronology,
edge cases, and the limits of any resource statement matter. Use the formal
names/types rather than guessing a source theorem. The source inventory is not
a kernel census. Ask for additional strictly formal providers if indispensable.
The full current target has already existing proof code; do not edit it. Do not
read sibling natural-source files, registry, prior reviews, goals or papers.
