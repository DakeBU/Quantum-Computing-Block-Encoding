"""C123 proposal: exact historical bytes + separate unchanged ci5 Python tests.
Default: prepare only. --run-reviewed-old-tests requires separate human authority.
No Lean, native diagnostic, clone, worktree, source mutation, or current admission.
"""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import time
import zipfile

DESCRIPTOR_SHA = "5a557cb729fee91e798c7de66a937d72a280bc486321d06fabe5314c252512df"
GATE_SHA = "be7c63f837b1621d166d0c1a4c1e57706a5468effd887097a564ee5cbd03d1bc"
MAX_FILE = 2 * 1024**2
MAX_TOTAL = 64 * 1024**2


def sha(data):
    return hashlib.sha256(data).hexdigest()


def relative(value):
    if not isinstance(value, str) or not value or "\\" in value or ":" in value:
        raise ValueError("nonportable relative path")
    parts = value.split("/")
    reserved = {"CON", "PRN", "AUX", "NUL"} | {"COM"+str(i) for i in range(1,10)} | {
        "LPT"+str(i) for i in range(1,10)}
    if any(not re.fullmatch(r"[A-Za-z0-9_.-]+", p) or p in (".", "..") or
           p.endswith((".", " ")) or p.split(".")[0].upper() in reserved for p in parts):
        raise ValueError("unsafe path segment")
    return value


def no_links(path):
    path = Path(path).absolute()
    for part in [path] + list(path.parents):
        if part.is_symlink() or getattr(os.path, "isjunction", lambda p: False)(part):
            raise ValueError("symlink/junction path forbidden")
        try:
            attributes = getattr(part.lstat(), "st_file_attributes", 0)
        except FileNotFoundError:
            attributes = 0
        # Python3.11 has no os.path.isjunction; reject Windows reparse points too.
        if attributes & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400):
            raise ValueError("Windows reparse point forbidden")
    return path


def child(root, name):
    return no_links(Path(root) / relative(name))


def rows_by_path(rows):
    result, folded = {}, set()
    for row in rows:
        path = relative(row["path"])
        if path.casefold() in folded:
            raise ValueError("duplicate/case-colliding path")
        if (not re.fullmatch("[a-f0-9]{64}", row["sha256"]) or
                type(row["bytes"]) is not int or not 0 <= row["bytes"] <= MAX_FILE):
            raise ValueError("invalid hash/length")
        folded.add(path.casefold()); result[path] = row
    return result


def check(data, row):
    if type(data) is not bytes or len(data) != row["bytes"] or sha(data) != row["sha256"]:
        raise ValueError("byte pin mismatch: " + row["path"])
    return data


def load_descriptor(path):
    raw = no_links(path).read_bytes()
    if sha(raw) != DESCRIPTOR_SHA:
        raise ValueError("proposal descriptor drift")
    descriptor = json.loads(raw)
    if (descriptor["source_count"], descriptor["config_count"], descriptor["member_count"],
            descriptor["expected_tests"]) != (220, 3, 31, 35):
        raise ValueError("frozen scope changed")
    return descriptor, raw


def archive_payload(data, descriptor):
    check(data, descriptor["archive"])
    expected = rows_by_path(descriptor["archive"]["members"])
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        infos = archive.infolist()
        if len(infos) != len(expected) or {i.filename for i in infos} != set(expected):
            raise ValueError("archive member set/duplicate mismatch")
        payload = {}
        for info in infos:
            relative(info.filename)
            mode = info.external_attr >> 16
            if (info.is_dir() or info.flag_bits & 1 or
                    stat.S_IFMT(mode) not in (0, stat.S_IFREG) or
                    info.file_size != expected[info.filename]["bytes"]):
                raise ValueError("archive nonregular/encrypted/size mismatch")
            payload[info.filename] = check(archive.read(info), expected[info.filename])
    if sha(payload["packet-seal.json"]) != descriptor["archive"]["seal_sha256"]:
        raise ValueError("external archive seal mismatch")
    sealed = rows_by_path(json.loads(payload["packet-seal.json"])["files"])
    if set(sealed) != set(expected) - {"packet-seal.json"}:
        raise ValueError("seal member coverage mismatch")
    for name, row in sealed.items():
        check(payload[name], row)
    manifest = json.loads(payload["package-bindings.json"])["files"]
    for name, digest in manifest.items():
        if name not in payload or sha(payload[name]) != digest:
            raise ValueError("inner code manifest mismatch")
    return payload


def put(root, name, data):
    path = child(root, name)
    path.parent.mkdir(parents=True, exist_ok=True)
    no_links(path.parent)
    with path.open("xb") as stream:
        stream.write(data)
    if path.read_bytes() != data:
        raise ValueError("copy changed")


def inventory(root):
    rows = []
    for path in sorted(root.rglob("*")):
        no_links(path)
        if path.is_file():
            data = path.read_bytes()
            rows.append(dict(path=path.relative_to(root).as_posix(), bytes=len(data), sha256=sha(data)))
    return rows


def materialize(descriptor, descriptor_raw, blob_provider, archive, helper, output,
                gate_data):
    """Injectable blob provider for new synthetic tests; CLI pins descriptor separately.
    Never imports archive code. All pins checked in memory BEFORE exclusive mkdir.
    """
    sources = rows_by_path(descriptor["sources"] + descriptor["configs"])
    if (len(descriptor["sources"]) != descriptor["source_count"] or
            len(descriptor["configs"]) != descriptor["config_count"]):
        raise ValueError("source/config count mismatch")
    if not re.fullmatch("[a-f0-9]{40}", descriptor["source_commit"]):
        raise ValueError("nonliteral commit")
    shared_row = descriptor["shared_instrumentation"]
    rows_by_path(list(sources.values()) + [shared_row])
    check(helper, shared_row)
    payload = archive_payload(archive, descriptor)
    if len(payload) != descriptor["member_count"]:
        raise ValueError("archive count")
    candidate = json.loads(payload["candidate-sources.json"])["files"]
    actual_candidate = [dict(path=r["relativePath"], bytes=r["bytes"], sha256=r["sha256"])
                        for r in candidate]
    if actual_candidate != descriptor["sources"]:
        raise ValueError("candidate/source ordered vector mismatch")
    profile = json.loads(payload["profile.json"])
    if profile["sharedInstrumentation"] != {k: shared_row[k] for k in ("path","sha256")}:
        raise ValueError("shared helper profile mismatch")
    for name, digest in profile["projectInputs"].items():
        if name not in sources or sources[name]["sha256"] != digest:
            raise ValueError("profile input outside source/config vector")
    blobs = {name: check(blob_provider(descriptor["source_commit"], name), row)
             for name, row in sources.items()}
    if sum(map(len, blobs.values())) + sum(map(len, payload.values())) > MAX_TOTAL:
        raise ValueError("bounded memory envelope exceeded")
    output = no_links(output)
    if not output.parent.is_dir() or output.exists():
        raise FileExistsError("output parent absent or exclusive output exists")
    output.mkdir(mode=0o700)
    for name in ("project", "runtime", "control", "PRIVATE", "public"):
        child(output, name).mkdir(mode=0o700)
    for name, data in blobs.items():
        put(output / "project", name, data)
    put(output / "project", shared_row["path"], helper)
    for name, data in payload.items():
        put(output / "runtime", name, data)
    put(output / "control", "descriptor.json", descriptor_raw)
    put(output / "control", "python_test_gate.py", gate_data)
    receipt = dict(schema="C123_HISTORICAL_MATERIALIZATION", sourceCommit=descriptor["source_commit"],
        historicalSourceRows=len(blobs), separatelyPinnedTechnicalHelper=shared_row,
        historicalInventory=inventory(output / "project"), runtimeInventory=inventory(output / "runtime"),
        archiveSHA256=sha(archive), descriptorSHA256=sha(descriptor_raw), gateSHA256=sha(gate_data),
        inheritedCacheCopied=False, oldTestsExecuted=False, nativeExecuted=False,
        currentHEADAcceptance=False, scientificAcceptance=False)
    put(output, "materialization.json", (json.dumps(receipt, indent=2)+"\n").encode())
    return receipt


def sanitize(text, roots):
    # Public derivatives are intentionally lossy. Raw bytes always remain PRIVATE.
    for actual, logical in sorted(roots.items(), key=lambda x: len(x[0]), reverse=True):
        for variant in (actual, actual.replace("\\", "/"), actual.replace("\\", "\\\\")):
            text = text.replace(variant, logical)
    text = re.sub(r"(?i)(?:Bearer\s+\S+|(?:ghp_|github_pat_|sk-)[A-Za-z0-9_-]+|"
                  r"(?:TOKEN|PASSWORD|SECRET|API_KEY)\s*=\s*\S+)", "[REDACTED]", text)
    text = re.sub(r"(?<![\w$])(?:[A-Za-z]:[\\/][^\s\"'<>]*|/(?:[^\s\"'<>]+))",
                  "$ABSOLUTE_PATH_REDACTED", text)
    return text


def run_old_tests(output, receipt, timeout=180):
    """Future explicit authorization only. No existing prepared output can be resumed."""
    before = (inventory(output / "project"), inventory(output / "runtime"))
    if before != (receipt["historicalInventory"], receipt["runtimeInventory"]):
        raise ValueError("prelaunch inventory drift")
    for name, expected in (("descriptor.json", DESCRIPTOR_SHA), ("python_test_gate.py", GATE_SHA)):
        if sha(child(output / "control", name).read_bytes()) != expected:
            raise ValueError("prelaunch control identity drift")
    env = {k: os.environ[k] for k in ("SystemRoot","WINDIR","COMSPEC","LANG","LC_ALL")
           if k in os.environ}
    env.update(C34_TEST_PROJECT=str(output / "project"), PYTHONDONTWRITEBYTECODE="1",
               TEMP=str(output / "PRIVATE"), TMP=str(output / "PRIVATE"),
               TMPDIR=str(output / "PRIVATE"))
    argv = [sys.executable, "-I", "-S", "-B", str(output / "control/python_test_gate.py"),
            "--workspace", str(output)]
    record = dict(argv=argv, cwd=str(output / "runtime"), python=sys.version,
                  executableSHA256=sha(Path(sys.executable).read_bytes()),
                  PID=None, exitCode=None, timedOut=False, timeoutSeconds=timeout)
    start = time.monotonic()
    with (output / "PRIVATE/stdout.raw").open("xb") as stdout, (
            output / "PRIVATE/stderr.raw").open("xb") as stderr:
        process = subprocess.Popen(argv, cwd=output / "runtime", env=env,
                                   stdout=stdout, stderr=stderr)
        record["PID"] = process.pid
        try:
            record["exitCode"] = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            record["timedOut"] = True
            process.kill()
            record["exitCode"] = process.wait()
    record["wallSeconds"] = time.monotonic() - start
    try:
        lines = (output / "PRIVATE/stdout.raw").read_text(encoding="utf-8").splitlines()
        summary = json.loads(next(line for line in lines if line.strip()))
        record["completeHistoricalPython35"] = (len([x for x in lines if x.strip()]) == 1 and
            summary.get("status") == "HISTORICAL_PYTHON_REPLAY_ONLY" and
            summary.get("testsRun") == 35 and summary.get("complete35Passed") is True and
            all(summary.get(k) == 0 for k in ("failures", "errors", "skipped", "expectedFailures")) and
            all(summary.get(k) is False for k in ("nativeExecuted", "currentHEADAcceptance",
                                                   "scientificAcceptance")))
    except (ValueError, StopIteration, UnicodeError):
        record["completeHistoricalPython35"] = False
    record["afterInventoriesEqual"] = before == (
        inventory(output / "project"), inventory(output / "runtime"))
    record["afterControlPinsEqual"] = all(sha(child(output / "control", name).read_bytes()) == expected
        for name, expected in (("descriptor.json", DESCRIPTOR_SHA), ("python_test_gate.py", GATE_SHA)))
    record.update(nativeExecutionAuthorized=False, currentHEADAcceptance=False,
                  scientificAcceptance=False, sourceCommit=receipt["sourceCommit"])
    derivations = []
    roots = {str(output):"$OUTPUT", str(Path(sys.base_prefix)):"$PYTHON",
             str(Path(sys.executable)):"$PYTHON_EXECUTABLE"}
    for name in ("stdout", "stderr"):
        raw = (output / ("PRIVATE/"+name+".raw")).read_bytes()
        public = sanitize(raw.decode("utf-8", errors="replace"), roots).encode("utf-8")
        put(output / "public", name+".sanitized.txt", public)
        record[name+"SHA256"] = sha(raw)
        derivations.append(dict(raw="PRIVATE/"+name+".raw", rawSHA256=sha(raw),
                                public=name+".sanitized.txt", publicSHA256=sha(public)))
    put(output, "PRIVATE/execution.json", (json.dumps(record, indent=2)+"\n").encode())
    public_record = json.loads(sanitize(json.dumps(record), roots))
    public_record["derivations"] = derivations
    put(output, "public/execution.json", (json.dumps(public_record, indent=2)+"\n").encode())
    return 0 if (record["exitCode"] == 0 and not record["timedOut"] and record["completeHistoricalPython35"] and
                 record["afterInventoriesEqual"] and record["afterControlPinsEqual"]) else 1


def validate_roots(repo, output):
    if not Path(repo).is_absolute() or not Path(output).is_absolute():
        raise ValueError("explicit absolute repo/output arguments required")
    repo, output = no_links(repo).resolve(), no_links(output).absolute()
    if not repo.is_dir() or output.is_relative_to(repo) or repo.is_relative_to(output):
        raise ValueError("invalid/overlapping repo and output roots")
    if output.exists() or not output.parent.is_dir():
        raise FileExistsError("output must be a new direct child of an existing parent")
    return repo, output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-reviewed-old-tests", action="store_true",
                        help="separate authorization required; NOT authorized by this proposal")
    args = parser.parse_args()
    repo, output = validate_roots(args.repo, args.output)
    here = no_links(Path(__file__).parent)
    descriptor, descriptor_raw = load_descriptor(here / "descriptor.json")
    gate = no_links(here / "python_test_gate.py").read_bytes()
    if sha(gate) != GATE_SHA:
        raise ValueError("Python-only gate drift")
    git = shutil.which("git")
    if not git:
        raise FileNotFoundError("Git absent")
    git = no_links(git).resolve()
    git_env = {k:v for k,v in os.environ.items() if not k.startswith("GIT_")}
    git_env.update(GIT_OPTIONAL_LOCKS="0", GIT_NO_REPLACE_OBJECTS="1",
                   GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL=os.devnull,
                   GIT_NO_LAZY_FETCH="1", GIT_TERMINAL_PROMPT="0", GIT_ALLOW_PROTOCOL="")
    commands = []

    def provider(commit, name):
        argv = [str(git), "--no-pager", "-c", "core.fsmonitor=false", "-c", "protocol.allow=never", "-C", str(repo),
                "show", commit+":"+relative(name)]
        result = subprocess.run(argv, env=git_env, capture_output=True, timeout=30, check=False)
        commands.append(dict(argv=argv, exitCode=result.returncode,
            stdoutSHA256=sha(result.stdout), stderrSHA256=sha(result.stderr)))
        if result.returncode != 0:
            raise RuntimeError("historical Git blob unavailable")
        return result.stdout
    archive_path = child(repo, descriptor["archive"]["path"])
    helper_path = child(repo, descriptor["shared_instrumentation"]["path"])
    archive, helper = archive_path.read_bytes(), helper_path.read_bytes()
    receipt = materialize(descriptor, descriptor_raw, provider, archive, helper, output, gate)
    if archive_path.read_bytes() != archive or helper_path.read_bytes() != helper:
        raise ValueError("technical input changed during materialization")
    provenance = dict(gitExecutable=str(git), gitExecutableSHA256=sha(git.read_bytes()),
        repo=str(repo), output=str(output), commands=commands, currentTechnicalArchive=str(archive_path),
        currentTechnicalHelper=str(helper_path), sourceCommit=descriptor["source_commit"])
    put(output, "PRIVATE/git-provenance.json", (json.dumps(provenance, indent=2)+"\n").encode())
    if args.run_reviewed_old_tests:
        return run_old_tests(output, receipt)
    print(json.dumps(dict(status="PREPARED_ONLY_NO_OLD_TEST_EXECUTION",
                          sourceCommit=descriptor["source_commit"], currentHEADAcceptance=False)))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(json.dumps(dict(status="REPLAY_REFUSED_NOT_MATHEMATICAL_REFUTATION",
                              failureType=type(error).__name__, nativeExecuted=False,
                              scientificAcceptance=False)), file=sys.stderr)
        raise SystemExit(1)

