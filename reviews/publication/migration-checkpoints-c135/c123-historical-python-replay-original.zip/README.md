# C123 historical Python replay — proposal only

Status: PROPOSAL_FROZEN_PENDING_INDEPENDENT_REVIEW. No actual historical materialization, old35 test, Lean/native diagnostic, selector change or successor admission has occurred.

This is a small additive byte-transport/test harness for only the unchanged C34ci5 Python35. It does not make active current-HEAD CI green. It preserves original profile/tests/validator/fixture/archive bytes and every NO_ACCEPT boundary.

## Exact two origins

Historical source: commit `1a4d0522f1f76ba26bd7a1fa20b9fb2bb4cf6fe4`, exactly220 original LF candidate Git blobs and3 config blobs from descriptor.json. The parent's C122 preflight is reported by the parent as matching all223; I have not read or re-executed that new preflight here. Future replay independently verifies all223 returned Git blobs again.

Technical runtime: current technical release's original31-member ci5 ZIP `97bfea091bf49cc17790aa52a3dab0f5e1d8316f2cef129e1989e5159ec35578`, seal `27e4809bb7ec98fe0d3872ae314353f11e6dc1f75dda4f6a4d9d4b460edc8e24`, plus exact shared helper `61733fc92f5e99672e0ce0260ff397e07c94a349e98e12c48dd6a3171d5a75d9`. These tools are NOT asserted to have existed in that historical source commit. No other C29/C31 package/context is replayed. ci1 CRLF history is outside this LF-only scope.

## Commands after separate review and authorization

New synthetic tests only (already run here):

```text
python -B -m unittest -v test_replay
```

Future preparation only, with explicit actual paths supplied by the operator:

```text
python -B replay.py --repo REPO_ABSOLUTE_PATH --output NEW_ABSOLUTE_OUTPUT
```

Future unchanged35 execution requires distinct authorization and a DIFFERENT new exclusive output:

```text
python -B replay.py --repo REPO_ABSOLUTE_PATH --output NEW_ABSOLUTE_OUTPUT --run-reviewed-old-tests
```

Do not execute that last command under this proposal alone. There is no resume/overwrite mode. --output must have an existing real parent, be absent and non-overlapping with --repo. Neither code nor descriptor embeds host paths.

## Layout and guarantees

New output contains project/ (exact223 historical blobs + separately bound shared helper), runtime/ (exact31 archive files), control/ (pinned descriptor and Python-only gate), PRIVATE/ (raw streams/commands) and public/ (sanitized derivatives). No .git, .lake or inherited binary cache is copied. Synthetic old tests may create their OWN fake toolchain/olean/controller receipts below runtime temporary subdirectories; these are explicitly not Lean observations.

All source/technical bytes are validated in memory before exclusive output creation and any archive import. Read-only Git show is the sole external executable needed to obtain historical blobs; it has no lazy fetch/protocol and no worktree/clone/branch mutation. After all pins, the optional child uses isolated Python `-I -S -B`, sanitized environment, C34_TEST_PROJECT=that historical project, and all35 exact discovered identities with no filtering/skipping/fixture rewrite.

Public success requires actual exit0, no timeout, exact complete35 summary and unchanged project/runtime/control pins. Parent keeps raw stdout/stderr, PID, actual Python digest, elapsed time and post-inventory. Sanitized files have separate hashes; never treat them as raw equality.

Read inspection.md / old-test-inspection.json and test-results.json. The audit hook is defense in depth over reviewed pinned Python, not an OS security sandbox. This code, especially filesystem race/OS capability and child isolation behavior, still needs independent review. No run result is predicted.

Rollback: do not select/run this proposal, or remove only its later additive routing. Keep old packages, source, observations and failures untouched. Exclusive failed replay directories are retained for diagnosis, not silently removed/reused.

