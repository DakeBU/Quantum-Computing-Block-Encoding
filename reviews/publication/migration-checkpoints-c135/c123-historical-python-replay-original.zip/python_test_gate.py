"""Future reviewed Python-only gate. Never a native or current-head acceptance gate."""
import argparse
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import unittest

DESCRIPTOR_SHA = "5a557cb729fee91e798c7de66a937d72a280bc486321d06fabe5314c252512df"


def policy(workspace, read_roots):
    """Defense in depth over reviewed pinned Python, not an OS/malware sandbox."""
    workspace = Path(workspace).resolve()
    read_roots = [workspace] + [Path(p).resolve() for p in read_roots]

    def within(value, roots, dir_fd=-1):
        # Python's fd-safe TemporaryDirectory cleanup uses directory descriptors.
        # Only actual descriptors inside this workspace may name mutation paths.
        if isinstance(value, int):
            if os.name != 'posix':
                raise PermissionError('unresolvable descriptor path')
            value = os.readlink('/proc/self/fd/' + str(value))
        elif dir_fd not in (-1, None):
            if os.name != 'posix':
                raise PermissionError('unresolvable directory descriptor')
            base = Path(os.readlink('/proc/self/fd/' + str(dir_fd)))
            if not base.resolve().is_relative_to(workspace):
                raise PermissionError('external directory descriptor')
            value = base / os.fsdecode(value)
        if not isinstance(value, (str, bytes, os.PathLike)):
            raise PermissionError("non-path filesystem access denied")
        path = Path(os.fsdecode(value)).absolute().resolve()
        if not any(path.is_relative_to(r) for r in roots):
            raise PermissionError("filesystem access outside permitted roots")
        return path

    def hook(event, args):
        if (event.startswith(("subprocess.", "socket.", "ctypes.", "winreg."))
                or event in ("os.system", "os.fork", "os.forkpty", "os.posix_spawn",
                             "os.exec", "os.spawn", "pty.spawn", "os.startfile")):
            raise PermissionError("process/network/native-FFI operation denied")
        if event == "open":
            path, mode, flags = args
            writing = (isinstance(mode, str) and any(c in mode for c in "wax+")) or (
                isinstance(flags, int) and bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC)))
            within(path, [workspace] if writing else read_roots)
        elif event in ("os.listdir", "os.scandir"):
            within(args[0], read_roots)
        elif event in ("os.remove", "os.rmdir", "os.mkdir", "os.chmod", "os.utime"):
            fd = args[-1] if len(args) > 1 and isinstance(args[-1], int) else -1
            within(args[0], [workspace], fd)
        elif event in ("os.rename", "os.replace"):
            within(args[0], [workspace]); within(args[1], [workspace])
            if any(isinstance(a, int) and a != -1 for a in args[2:]):
                raise PermissionError("dir_fd rename denied")
        elif event in ("os.symlink", "os.link"):
            raise PermissionError("link creation denied")
        elif event == "os.chdir":
            within(args[0], [workspace])
    return hook


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", required=True, type=Path)
    args = parser.parse_args()
    root = args.workspace.resolve()
    descriptor_bytes = (root / "control/descriptor.json").read_bytes()
    if hashlib.sha256(descriptor_bytes).hexdigest() != DESCRIPTOR_SHA:
        raise ValueError("descriptor changed")
    descriptor = json.loads(descriptor_bytes)
    project, package = root / "project", root / "runtime"
    os.environ["C34_TEST_PROJECT"] = str(project)
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(package))
    sys.addaudithook(policy(root, [sys.base_prefix, sys.exec_prefix]))
    # Discover every old test. No name selection, monkeypatch, skip or fixture rewrite.
    suite = unittest.defaultTestLoader.discover(str(package), pattern="test_*.py",
                                               top_level_dir=str(package))

    def flatten(value):
        if isinstance(value, unittest.TestSuite):
            return [t for part in value for t in flatten(part)]
        return [value]
    expected = sorted(t["file"][:-3] + "." + t["class"] + "." + t["method"]
                      for t in descriptor["tests"])
    actual = sorted(t.id() for t in flatten(suite))
    if actual != expected or len(actual) != descriptor["expected_tests"]:
        raise ValueError("unchanged complete35 discovery identity mismatch")
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    # A skipped, expected-failure or unexpected-success test does not discharge replay.
    passed = (result.wasSuccessful() and result.testsRun == 35 and
              not result.skipped and not result.expectedFailures and not result.unexpectedSuccesses)
    print(json.dumps(dict(status="HISTORICAL_PYTHON_REPLAY_ONLY", testsRun=result.testsRun,
        failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
        expectedFailures=len(result.expectedFailures), complete35Passed=passed,
        nativeExecuted=False, currentHEADAcceptance=False, scientificAcceptance=False)))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())

