# Static inspection and scope

I used qbe-substantive-worker governance for the exact frontier and handoff boundary. This is authorized instrumentation/testing, not a new mathematical target or source proof; no source-facing theorem claim or statement seal is created. Source-dependency audit discipline keeps compiler/runtime outcomes distinct from source mathematics.

## The35 and their direct dependencies

All four original test files and all nine direct Python implementation/resource dependencies were read completely, plus the complete pinned external shared helper. old-test-inspection.json enumerates every exact method identity and actual import/call route. C118's unchanged prior full reads remain evidence; no archived code was imported/executed. JSON/Lean/doc payloads are pin/read context, not executed.

test_adapter: validator tests build only synthetic streams and mutate fields. Binding tests read exact source anchors/configs, load exact modules, copy/mutate synthetic driver bytes, and check path/fallback/envelope errors. Shared helper import has no process side effect; native_call is only tested as callable. The native runner test uses ci=False and fails before native setup, on every host.

test_discovery: validates all220 historical candidate bytes and real directory membership, then uses synthetic import rows to exercise graph/flag/binding/negative checks. setup_pipeline copies the three project source inputs and configs into a temporary synthetic project, creates a fake provider/olean/toolchain, imports exact helper utilities, and supplies SyntheticAPI.native_call. That callback writes synthetic receipts/fake output bytes only, never subprocess. shutil.which is mocked for exercised preparation; resource callbacks receive synthetic fixture samplers before calls.

test_resource_gate: exact vendored algorithms are imported but real /proc/cgroup capacity sampling is replaced with resource_fixtures. Negative unknown/insufficient/namespace/profile/guard cases start zero synthetic calls; one unknown-postflight test records a synthetic call then rejects success. None are actual memory-capacity or Linux evidence.

test_serial_policy: retains its hardcoded original ab18 candidate/de5a profile, parser/collector/validator/discovery hashes. Full synthetic flow checks target-only Elab.async flag and argv budgets. No constant, assertion or skip behavior changes.

## Effects and backstops

The35 are not side-effect-free: they create/copy/read/mutate/remove temporary synthetic files below their extracted package and dynamically import exact helper copies. An original test creates and imports trivial synthetic unit.py. They read host Python identity/digest and os.environ for provenance. These are acceptable only within the explicit new output plus Python installation read scope; no R path is passed to the child.

The added gate is outside original files. It discovers all old test_*.py and compares all35 identities, refuses skip/expectedFailure/unexpectedSuccess as completion, and rejects process/network/native-FFI audit events. It restricts writes/links/renames/enumeration and read roots; POSIX fd-safe cleanup can resolve only own directory descriptors via /proc/self/fd readlink. That helper readlink is descriptor isolation, NOT OS resource-capacity evidence. Where a platform cannot resolve an fd safely the gate refuses; no permissive fallback is installed.

These checks are not a full OS sandbox or proof against malicious native extensions/races. Byte pins, trusted interpreter/stdlib, independent code review and exclusive operator-controlled directories remain assumptions. The Python prefix is read-only but not transitive-TCB-audited. Windows symlink/junction checks and before/after pins do not prove immunity to concurrent hostile filesystem mutation; a separately controlled new directory is required.

The parent specifically asked whether ctypes.* denial would break Windows imports. None of the exact nine old implementation/resource modules or pinned helper has a top-level ctypes import. A new actual isolated Python3.11.9 Windows smoke loads only our gate, installs its unchanged hook, then imports the complete standard-library dependency set including unittest.mock and its transitive asyncio imports. It passed; an explicit synthetic ctypes.dlopen audit event remained denied. No ctypes preimport exemption, process/network weakening, old-code import or actual DLL-load request was added. This is actual environment compatibility evidence for those stdlib imports, not old35 or all Python/OS versions. The final28 new tests include this smoke.

## Boundary

C122 preflight success is parent-attributed, not my own new Git observation. I have not materialized historical blobs here. The new synthetic tests use a fixture blob provider, no real Git/Lean/old code. Their fake subprocess tests use an in-memory FakeProcess, not an external process or historical35.

No existing source, config, old fixture/test/profile/verifier/score/archive/workflow or publication record was edited. The historical220 LF vector is distinct from ci1's10-CRLF raw history. This instrument does not solve active current CI, create a current successor, or revise any accepted Cubic/HBI scope.

## Independent next gate / rollback

Parent must review descriptor/byte provenance, executable/entry pin chain, all path/output ownership checks, Python prefix and audit-hook event coverage, full old35 identities and no native dispatch. Then explicitly authorize a finite actual historical Python run in a NEW output; inspect real exit, all35 count, raw streams, inventories and any resource/environment blockage. Keep any failure as failure and retain its exclusive directory.

No branch/worktree, cache, source or workflow mutation is needed. Do not weaken fixtures to make this instrument pass. Rolling back means leaving this additive proposal unselected; after a later selection, remove only the added routing and retain historical observations. No current source proof or science claim follows even from35passed.

