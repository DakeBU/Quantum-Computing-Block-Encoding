# C123 handoff

Objective/frontier: proposal for exact historical C34ci5 Python35 replay, not a current-source/native diagnostic or acceptance repair.

Delta: additive pinned descriptor, exclusive byte materializer, Python-only future entry and28 new synthetic tests. No mathematical theorem/assumption/scoring/verifier change. Root frontier effect is pending instrumentation only.

Evidence: descriptor220+3 historical pins, original31 archive members/seal, separate helper61733; complete static old35/direct-dependency reading; actual new28 exit0, no skips; real isolated gate+stdlib import smoke passes Windows Python3.11.9 without ctypes exemption. test-results.json retains two earlier new-fixture errors and subsequent passes. Exact final raw process bytes/provenance are private and hash-bound via private-evidence.json.

Origins/assumptions: historical sourcecommit1a4d052 versus later immutable technical runtime are separate. Parent C122 reports all223 blob equality; no new real materialization/Git query/old35 execution here. Trusted Python/stdlib and exclusive operator-controlled nonhostile output, not full TCB or OS-sandbox proof. ci1 CRLF context excluded.

Changed files: only this NEW W/c123-historical-python-replay packet. No old packet, R/source/config/fixture/profile/verifier/archive/score/workflow/publication edit. No network, subagents, Lean/native/simulation. New synthetic Python child processes are explicitly distinguished from forbidden old-code/native execution.

Failure class: NONE for final new synthetic gate; actual historical replay remains NOT_RUN. Earlier two synthetic fixture bugs are IMPLEMENTATION_FAILED development observations, not mathematical evidence.

Salvage: source/technical pins, pure byte materialization and no-native test guards promoted as a proposal for review; actual historical/current/runtime claims pending. No process-memory entries or new source proof graph required for this narrow instrumentation.

Comparator rationale: exact original220 source universe,3 configs,31 payloads and every35 discovered method; no normalization, oldhash replacement, filtering, skip or profile rewrite. Future pass needs true exit0/no timeout/exact35 terminal summary plus before/after source/runtime/control identities. Original compiled/kernel/native diagnostic comparators are not executed or altered.

Parallel/common-blind-spot audit: no subagents. Parent ctypes question triggered actual new isolated stdlib import smoke, not deference or old-code execution. No exemption added. Remaining independent review must inspect filesystem races/reparse handling, fd cleanup audit behavior, interpreter isolation and all future invocation/provenance boundaries.

Rollback: leave additive proposal unselected; if later routed, remove only new routing. Do not restore old proofs, rewrite frozen artifacts or delete diagnostic failures. Failed exclusive outputs are not resumed or overwritten.

Purification/Exposition: not applicable to theorem publication; no ROOT/PURIFIED/main/full-integration/current acceptance asserted.

Next step: independent code/data review, then separate explicit authority for ONE finite old35 Python replay into a new output and actual result review. No Lean/native permission is implied. This proposal seal is not admission.

