# C123 v3 — exact interpreter read-only pin, proposal

Original v2 is preserved byte-identical. The authorized actual run2 remains FAILED:35 ran,34 passed,1 error,0 failures/skips. runner.bootstrap could not hash the virtual-environment interpreter outside Python base/exec prefixes. Test runner21.784s, child wall22.016s, outer40.375s are distinct. This is bounded instrumentation failure, not mathematics or a35pass.

V3 adds ONLY exact resolved Path(sys.executable) FILE read permission to the gate. It does not add the interpreter's parent, repository, extra directory prefix, writes or execution permission. Process/network/FFI guards remain. replay.py changes only its required GATE_SHA. Descriptor, original220+3/31/35/runtime/profile/validator/scoring/caps unchanged.

29 new synthetic tests passed with owned TEMP/TMP. The new regression permits exact external interpreter read but denies its write/delete, neighbor read/write and parent enumeration. Actual isolated own-gate+stdlib smoke now hashes sys.executable under the gate and keeps ctypes denial. No oldcode import/run here; actual parent venv run3 remains unobserved.

Read delta.json for exact4authorized C129 input hashes and real failed outcome; test-results.json for this producer's actual new29. All earlier C123/v2 isolation/TCB/concurrency/origin scopes remain unchanged. No actual historical materialization/Git/old35/Lean/native/current CI/source/production change by this producer.

Future commands require separate review/authority and an absent exclusive output, exactly as v2. New synthetic tests require TEMP/TMP set to the owned PRIVATE/unit-temp directory. An actual old35 run would use:

```text
python -B replay.py --repo REPO_ABSOLUTE_PATH --output NEW_ABSOLUTE_OUTPUT --run-reviewed-old-tests
```

Do NOT run it under this proposal alone. It does not authorize native execution or currentHEAD acceptance. Preserve all failed outputs; no resume/overwrite/old fixture change. Rollback leaves this additive v3 unselected, not a fabricated green result.

