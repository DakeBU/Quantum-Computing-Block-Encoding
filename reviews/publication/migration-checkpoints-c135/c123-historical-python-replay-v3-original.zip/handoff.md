# Handoff

Objective: exact interpreter byte-read repair after actual retained34pass1error historical35 failure. Delta: gate exact-file read allowlist and necessary runner GATE_SHA only; no broad directory, write, process/network/FFI relaxation. Original descriptor/caps/science/runtime/oldtests unchanged.

Evidence: complete authorized run2 public execution/stdout/stderr/outer read with exact pins; new29synthetics exit0 PID22148 wall2.391s with owned TEMP; actual isolated stdlib+sys.executable hash smoke. New external-file/neighbor/write/delete/parent negatives retained. No actualold35rerun or oldcode import by this producer. Parent run2 remains FAILED, not downgraded to success.

Limits: public derivatives are not raw logs/full materialization rereview; actual parent venv is not this producer's Python3.11.9. Exact-file permission is bounded instrumentation, not source correctness/TCB/admission. OS filesystem-race/interpreter-trust limits remain.

Next: independent v3 code/data review then explicit separate run3 authority with fresh output and true35/exit/inventory review. No Lean/native/source/validator/scoring/workflow/production change. Rollback unselects v3 while preserving earlier failure evidence. No ROOT/PURIFIED/current acceptance.

