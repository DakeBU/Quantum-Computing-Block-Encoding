"""New synthetic instrumentation tests only. Never imports/executes the old archive."""
from copy import deepcopy
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import replay as r
import python_test_gate as gate


def raw_json(value):
    return (json.dumps(value, indent=2)+"\n").encode()


def row(path, data):
    return dict(path=path, bytes=len(data), sha256=r.sha(data))


def fixture(change=None, zip_change=None):
    source = {"QuantumBlockEncoding/A.lean":b"-- SYNTHETIC source\n",
              "lean-toolchain":b"SYNTHETIC config\n"}
    helper = b"# SYNTHETIC helper; must never execute\n"
    source_rows = [row("QuantumBlockEncoding/A.lean", source["QuantumBlockEncoding/A.lean"])]
    config_rows = [row("lean-toolchain", source["lean-toolchain"])]
    shared = row("tools/cubic_c29_diagnostic/runner.py", helper)
    payload = {
        "candidate-sources.json":raw_json(dict(files=[
            dict(relativePath=x["path"], bytes=x["bytes"], sha256=x["sha256"])
            for x in source_rows])),
        "profile.json":raw_json(dict(sharedInstrumentation={k:shared[k] for k in ("path","sha256")},
                                     projectInputs={x["path"]:x["sha256"] for x in source_rows+config_rows})),
        "sentinel.py":b"raise AssertionError('MUST NEVER EXECUTE SYNTHETIC ARCHIVE')\n"}
    if change:
        change(payload)
    payload["package-bindings.json"] = raw_json(dict(files={
        p:r.sha(d) for p,d in payload.items()}))
    payload["packet-seal.json"] = raw_json(dict(files=[row(p,d) for p,d in payload.items()]))
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w") as z:
        for p,d in payload.items():
            info = zipfile.ZipInfo(p)
            info.external_attr = (stat.S_IFREG | 0o600) << 16
            if zip_change:
                zip_change(info)
            z.writestr(info,d)
    data = buffer.getvalue()
    desc = dict(source_commit="a"*40, sources=source_rows, configs=config_rows,
        source_count=1, config_count=1, member_count=len(payload), expected_tests=0,
        shared_instrumentation=shared, archive=dict(row("fixture.zip",data),
            seal_sha256=r.sha(payload["packet-seal.json"]),
            members=[row(p,d) for p,d in payload.items()]))
    return desc, data, helper, source


class MaterializationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="c123-SYNTHETIC-")
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.out = self.root / "exclusive"

    def run_fixture(self, desc=None, archive=None, helper=None, source=None):
        d,z,h,s = fixture()
        d = d if desc is None else desc
        z = z if archive is None else archive
        h = h if helper is None else helper
        s = s if source is None else source
        def provider(commit,path):
            self.assertEqual(commit,"a"*40)
            return s[path]
        with patch.object(r.subprocess,"Popen",side_effect=AssertionError("NO PROCESS")):
            return r.materialize(d,raw_json(d),provider,z,h,self.out,b"# OWN synthetic gate\n")

    def test_exact_copy_and_no_cache_or_old_code_execution(self):
        d,z,h,s = fixture()
        receipt = self.run_fixture()
        self.assertEqual(receipt["historicalSourceRows"],2)
        for p,b in s.items():
            self.assertEqual((self.out/"project"/p).read_bytes(),b)
        self.assertEqual(len(receipt["runtimeInventory"]),5)
        self.assertFalse((self.out/"project/.git").exists())
        self.assertFalse((self.out/"project/.lake").exists())
        self.assertFalse(receipt["oldTestsExecuted"])
        self.assertFalse(receipt["currentHEADAcceptance"])

    def test_duplicate_and_case_collision_fail_before_creation(self):
        for name in ("QuantumBlockEncoding/A.lean","quantumblockencoding/a.lean"):
            d,z,h,s=fixture(); d["sources"].append(dict(d["sources"][0],path=name))
            d["source_count"] += 1
            with self.assertRaises(ValueError): self.run_fixture(desc=d)
            self.assertFalse(self.out.exists())

    def test_unsafe_relative_paths_and_reserved_names(self):
        for name in ("../x","/x","a//b","a/./b","a\\b","disk:x","a/CON.txt","a/trailing.",""):
            with self.subTest(path=name), self.assertRaises(ValueError):
                r.relative(name)

    def test_boolean_size_or_bad_digest_refused(self):
        for key,value in (("bytes",True),("sha256","0"*63),("bytes",r.MAX_FILE+1)):
            d,z,h,s=fixture(); d["sources"][0][key]=value
            with self.assertRaises(ValueError): self.run_fixture(desc=d)
            self.assertFalse(self.out.exists())

    def test_wrong_source_and_missing_blob_leave_no_output(self):
        d,z,h,s=fixture(); s["QuantumBlockEncoding/A.lean"]=b"DRIFT"
        with self.assertRaises(ValueError): self.run_fixture(source=s)
        del s["QuantumBlockEncoding/A.lean"]
        with self.assertRaises(KeyError): self.run_fixture(source=s)
        self.assertFalse(self.out.exists())

    def test_wrong_helper_or_archive_pin_never_reads_blobs(self):
        d,z,h,s=fixture()
        provider=lambda *a: self.fail("blob read before technical validation")
        for archive,helper in ((z+b"changed",h),(z,b"changed")):
            with self.assertRaises(ValueError):
                r.materialize(d,raw_json(d),provider,archive,helper,self.out,b"gate")
            self.assertFalse(self.out.exists())

    def test_nonliteral_commit_rejected(self):
        d,z,h,s=fixture(); d["source_commit"]="HEAD"
        with self.assertRaises(ValueError): self.run_fixture(desc=d)

    def test_source_scope_count_mismatch(self):
        d,z,h,s=fixture(); d["source_count"]=220
        with self.assertRaises(ValueError): self.run_fixture(desc=d)

    def test_existing_output_never_overwritten(self):
        self.out.mkdir(); (self.out/"sentinel").write_bytes(b"KEEP")
        with self.assertRaises(FileExistsError): self.run_fixture()
        self.assertEqual((self.out/"sentinel").read_bytes(),b"KEEP")

    def test_absent_parent_refused_not_created(self):
        self.out = self.root/"absent"/"child"
        with self.assertRaises(FileExistsError): self.run_fixture()
        self.assertFalse(self.out.parent.exists())

    def test_repo_output_overlap_and_existing_root_rejected(self):
        repo=self.root/"repo";repo.mkdir()
        for out in (repo,repo/"inside",self.root):
            with self.assertRaises(ValueError):r.validate_roots(repo,out)
        with self.assertRaises(FileExistsError):r.validate_roots(repo,self.root/"absent"/"child")
        existing=self.root/"existing";existing.mkdir()
        with self.assertRaises(FileExistsError):r.validate_roots(repo,existing)
        self.assertEqual(r.validate_roots(repo,self.out),(repo.resolve(),self.out.absolute()))
        with self.assertRaises(ValueError):r.validate_roots(repo,Path("relative-output"))

    def test_source_destination_symlink_or_junction_refused(self):
        with patch.object(Path,"is_symlink",return_value=True):
            with self.assertRaises(ValueError): r.no_links(self.out)
        with patch.object(os.path,"isjunction",return_value=True,create=True):
            with self.assertRaises(ValueError): r.no_links(self.out)
        from types import SimpleNamespace
        real_lstat=Path.lstat
        target=self.out
        def reparse(path,*args,**kwargs):
            return SimpleNamespace(st_file_attributes=0x400) if path==target else real_lstat(path,*args,**kwargs)
        with patch.object(Path,"is_symlink",return_value=False),patch.object(Path,"lstat",reparse):
            with self.assertRaises(ValueError):r.no_links(self.out)

    def test_exclusive_put_collision(self):
        self.out.mkdir()
        r.put(self.out,"keep",b"KEEP")
        with self.assertRaises(FileExistsError): r.put(self.out,"keep",b"CHANGE")
        self.assertEqual((self.out/"keep").read_bytes(),b"KEEP")

    def test_archive_membership_extra_missing_and_duplicate(self):
        d,z,h,s=fixture()
        for operation in ("extra","missing","duplicate"):
            buffer=io.BytesIO()
            with zipfile.ZipFile(io.BytesIO(z)) as old, zipfile.ZipFile(buffer,"w") as new:
                for info in old.infolist():
                    if operation=="missing" and info.filename=="sentinel.py": continue
                    new.writestr(info,old.read(info))
                if operation=="extra": new.writestr("extra.py",b"# noexecute")
                if operation=="duplicate":
                    import warnings
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore")
                        new.writestr("sentinel.py",b"# duplicate")
            changed=buffer.getvalue(); desc=deepcopy(d)
            desc["archive"].update(row("fixture.zip",changed))
            with self.assertRaises(ValueError): r.archive_payload(changed,desc)

    def test_archive_symlink_and_nonregular_refused(self):
        for mode in (stat.S_IFLNK,stat.S_IFDIR):
            d,z,h,s=fixture(zip_change=lambda i:setattr(i,"external_attr",(mode|0o600)<<16))
            with self.assertRaises(ValueError): r.archive_payload(z,d)

    def test_seal_pin_or_member_byte_drift(self):
        d,z,h,s=fixture()
        d["archive"]["seal_sha256"]="0"*64
        with self.assertRaises(ValueError): r.archive_payload(z,d)
        d,z,h,s=fixture(); d["archive"]["members"][0]["sha256"]="0"*64
        with self.assertRaises(ValueError): r.archive_payload(z,d)

    def test_candidate_or_profile_external_reference_refused(self):
        for changed in ("candidate","profile"):
            def mutate(payload):
                if changed=="candidate":
                    q=json.loads(payload["candidate-sources.json"]);q["files"][0]["bytes"]+=1
                    payload["candidate-sources.json"]=raw_json(q)
                else:
                    q=json.loads(payload["profile.json"]);q["projectInputs"]["unlisted.lean"]="0"*64
                    payload["profile.json"]=raw_json(q)
            d,z,h,s=fixture(change=mutate)
            with self.assertRaises(ValueError):
                r.materialize(d,raw_json(d),lambda c,p:s[p],z,h,self.out,b"gate")
            self.assertFalse(self.out.exists())

    def test_changed_descriptor_pin_refused_without_import(self):
        p=self.root/"descriptor.json";p.write_bytes(b"{}")
        with self.assertRaises(ValueError):r.load_descriptor(p)

    def test_frozen_actual_descriptor_is_data_only_and_exact(self):
        d,raw=r.load_descriptor(Path(__file__).parent/"descriptor.json")
        self.assertEqual((len(d["sources"]),len(d["configs"]),len(d["archive"]["members"]),
                          len(d["tests"])),(220,3,31,35))
        self.assertEqual(len(r.rows_by_path(d["sources"] + d["configs"])), 223)
        self.assertEqual(len(r.rows_by_path(d["archive"]["members"])), 31)
        largest=max(d["sources"],key=lambda item:item["bytes"])
        self.assertEqual(largest["path"],"ABEISBlueprint/Catalog/PaperAndExamples.lean")
        self.assertEqual(largest["bytes"],2353153)
        self.assertGreater(largest["bytes"],2*1024**2)
        self.assertLessEqual(largest["bytes"],r.MAX_FILE)
        self.assertEqual(r.MAX_FILE,4*1024**2)
        too_large=dict(largest,bytes=r.MAX_FILE+1)
        with self.assertRaises(ValueError):r.rows_by_path([too_large])
        self.assertFalse(d["old_test_execution_authorized_by_this_proposal"])
        self.assertEqual(r.sha((Path(__file__).parent/"python_test_gate.py").read_bytes()),r.GATE_SHA)

    def test_prelaunch_inventory_drift_never_spawns(self):
        receipt=self.run_fixture()
        (self.out/"project/lean-toolchain").write_bytes(b"DRIFT")
        with patch.object(r.subprocess,"Popen",side_effect=AssertionError("NO PROCESS")):
            with self.assertRaises(ValueError):r.run_old_tests(self.out,receipt)

    def test_control_mutation_never_spawns(self):
        receipt=self.run_fixture()
        (self.out/"control/python_test_gate.py").write_bytes(b"DRIFT")
        with patch.object(r.subprocess,"Popen",side_effect=AssertionError("NO PROCESS")):
            with self.assertRaises(ValueError):r.run_old_tests(self.out,receipt)

    def test_fake_process_exit_timeout_raw_receipts_and_incomplete_summary(self):
        # No process is started. This tests only our own orchestration/derivation code.
        import subprocess
        for kind in ("success","exit1","timeout","partial","drift"):
            with self.subTest(kind=kind):
                self.out=self.root/kind
                receipt=self.run_fixture()
                descriptor_sha=r.sha((self.out/"control/descriptor.json").read_bytes())
                gate_sha=r.sha((self.out/"control/python_test_gate.py").read_bytes())
                marker=dict(status="HISTORICAL_PYTHON_REPLAY_ONLY",testsRun=35,
                    complete35Passed=True,failures=0,errors=0,skipped=0,expectedFailures=0,
                    nativeExecuted=False,currentHEADAcceptance=False,scientificAcceptance=False)
                if kind=="partial":marker["testsRun"]=34
                marker_bytes=(json.dumps(marker)+"\n").encode()
                owner=self
                class FakeProcess:
                    pid=123456
                    def __init__(self,argv,**kwargs):
                        self.waits=0
                        owner.assertEqual(argv[1:4],["-I","-S","-B"])
                        owner.assertNotIn("LEAN_PATH",kwargs["env"])
                        kwargs["stdout"].write(marker_bytes)
                        kwargs["stderr"].write(b"SYNTHETIC ONLY\n")
                        if kind=="drift":(owner.out/"runtime/sentinel.py").write_bytes(b"DRIFT")
                    def wait(self,timeout=None):
                        self.waits+=1
                        if kind=="timeout" and self.waits==1:
                            raise subprocess.TimeoutExpired("SYNTHETIC",timeout)
                        return 1 if kind=="exit1" else (-9 if kind=="timeout" else 0)
                    def kill(self):pass
                with patch.object(r,"DESCRIPTOR_SHA",descriptor_sha),patch.object(r,"GATE_SHA",gate_sha),\
                     patch.object(r.subprocess,"Popen",FakeProcess):
                    code=r.run_old_tests(self.out,receipt)
                self.assertEqual(code,0 if kind=="success" else 1)
                value=json.loads((self.out/"PRIVATE/execution.json").read_bytes())
                self.assertEqual(value["PID"],123456)
                self.assertEqual(value["timedOut"],kind=="timeout")
                self.assertEqual(value["stdoutSHA256"],r.sha(marker_bytes))
                public=(self.out/"public/execution.json").read_text()
                self.assertNotIn(str(self.out),public)


class PolicyTests(unittest.TestCase):
    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory(prefix="c123-policy-SYNTHETIC-")
        self.addCleanup(self.temporary.cleanup)
        self.root=Path(self.temporary.name).resolve()
        self.hook=gate.policy(self.root,[Path(__file__).parent])

    def test_all_process_network_ffi_families_denied(self):
        for event in ("subprocess.Popen","os.system","os.fork","os.exec","os.spawn",
                      "os.posix_spawn","socket.connect","socket.__new__","ctypes.dlopen",
                      "winreg.OpenKey","os.startfile"):
            with self.subTest(event=event),self.assertRaises(PermissionError):
                self.hook(event,())

    def test_actual_isolated_gate_all_stdlib_imports_without_any_old_code(self):
        import subprocess
        import sys
        script = '''import importlib.util,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location("c123_gate_only",sys.argv[1])
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
sys.addaudithook(module.policy(Path(sys.argv[2]),[sys.base_prefix,sys.exec_prefix],[Path(sys.executable)]))
import argparse,base64,contextlib,copy,datetime,hashlib,importlib.util,io,json,math
import os,pathlib,re,shutil,subprocess,tempfile,threading,time,types,unittest,unittest.mock,uuid
with Path(sys.executable).open('rb') as executable:
    assert len(hashlib.file_digest(executable,'sha256').hexdigest()) == 64
try:
    sys.audit("ctypes.dlopen","SYNTHETIC_NOT_AN_ACTUAL_DLL_LOAD")
except PermissionError:
    pass
else:
    raise AssertionError("FFI protection weakened")
print("ONLY_OWN_GATE_AND_STDLIB_IMPORTED_PROCESS_NETWORK_FFI_GUARDS_RETAINED")
'''
        result=subprocess.run([sys.executable,"-I","-S","-B","-c",script,
            str(Path(__file__).parent/"python_test_gate.py"),str(self.root)],
            cwd=self.root,capture_output=True,timeout=30,check=False)
        self.assertEqual(result.returncode,0,result.stderr.decode(errors="replace"))
        self.assertEqual(result.stdout.strip(),
            b"ONLY_OWN_GATE_AND_STDLIB_IMPORTED_PROCESS_NETWORK_FFI_GUARDS_RETAINED")

    def test_external_write_read_enumeration_and_links_denied(self):
        other=Path(self.root.anchor)/"C123_NOT_PERMITTED_SYNTHETIC_PATH"
        for event,args in (("open",(str(other),"wb",os.O_WRONLY)),
                           ("open",(str(other),"r",0)),("os.scandir",(str(other),)),
                           ("os.mkdir",(str(other),0o700,-1)),
                           ("os.remove",(str(other),-1)),
                           ("os.rename",(str(self.root/"a"),str(other),-1,-1)),
                           ("os.symlink",("a","b",-1)),("os.link",("a","b"))):
            with self.subTest(event=event),self.assertRaises(PermissionError):
                self.hook(event,args)

    def test_exact_external_interpreter_file_read_only_not_parent_or_neighbors(self):
        with tempfile.TemporaryDirectory(prefix="c123-external-SYNTHETIC-") as directory:
            executable=Path(directory)/"python.exe"
            executable.write_bytes(b"SYNTHETIC_NOT_EXECUTABLE")
            neighbor=executable.with_name("neighbor.txt")
            neighbor.write_bytes(b"NEIGHBOR_NOT_APPROVED")
            hook=gate.policy(self.root,[],[executable])
            hook("open",(str(executable),"rb",0))
            for event,args in (("open",(str(neighbor),"rb",0)),
                ("open",(str(executable),"wb",os.O_WRONLY)),
                ("open",(str(neighbor),"wb",os.O_WRONLY)),
                ("os.scandir",(str(executable.parent),)),
                ("os.remove",(str(executable),-1))):
                with self.subTest(event=event,args=args),self.assertRaises(PermissionError):
                    hook(event,args)

    def test_local_io_permitted_and_stdlib_source_read_only(self):
        self.hook("open",(str(self.root/"a"),"wb",os.O_WRONLY))
        own=Path(__file__)
        self.hook("open",(str(own),"r",0))
        with self.assertRaises(PermissionError):self.hook("open",(str(own),"wb",os.O_WRONLY))

    def test_fd_safe_cleanup_mapping_without_os_resource_sampling(self):
        with patch.object(gate,"Path",type(self.root)),patch.object(os,"name","posix"),\
             patch.object(os,"readlink",return_value=str(self.root)):
            self.hook("os.scandir",(123,))
            self.hook("os.remove",("temporary.txt",123))
        with patch.object(gate,"Path",type(self.root)),patch.object(os,"name","posix"),\
             patch.object(os,"readlink",return_value=str(self.root.parent)):
            with self.assertRaises(PermissionError):self.hook("os.remove",("temporary.txt",123))

    def test_sanitized_public_derivative_is_not_raw_binding(self):
        secret_root=str(self.root)
        raw=secret_root+"/log TOKEN=synthetic"
        clean=r.sanitize(raw,{secret_root:"$OUTPUT"})
        self.assertNotIn(secret_root,clean)
        self.assertNotIn("TOKEN=synthetic",clean)
        self.assertNotEqual(r.sha(raw.encode()),r.sha(clean.encode()))


if __name__=="__main__":
    unittest.main(verbosity=2)

