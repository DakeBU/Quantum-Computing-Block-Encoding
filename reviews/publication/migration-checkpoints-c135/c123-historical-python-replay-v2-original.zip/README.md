# C123 v2 — bounded transport correction, not an accepted replay

Original C12314public+2private remain byte-identical. Parent's real frontpreflight found a valid pinned2,353,153-byte source beyond the2MiB transport cap, before creating output or executing old code. The old synthetic regression missed full descriptor row validation. This was an implementation cap defect, not mathematics.

The ONLY replay.py byte change is MAX_FILE2MiB ->4MiB; MAX_TOTAL stays64MiB. Every220historical source/3config pin,31-member archive and old35 test/profile/algorithm remains unchanged. descriptor.json and python_test_gate.py are byte-identical predecessor copies, verified directly.

New test regression validates all223+31 metadata rows, names/asserts the actual largest pinned file and its2,353,153 bytes, and rejects4MiB+1. All28 new synthetic tests passed with TEMP/TMP pointing PRIVATE/unit-temp in this new workspace. The forbidden-path fixture retains all assertions but now chooses a genuinely external synthetic coordinate; nesting TEMP below the allowed proposal readroot had invalidated its old assumption.

See delta.json/test-results.json/handoff.md. Prior C123 README/inspection and exact old35 static audit remain referenced by immutable original seal; no old runtime code is copied into this proposal for execution.

## Future commands — separate authority still required

For new synthetic tests, set TEMP and TMP to an existing owned directory below this NEW packet, then run:

```text
python -B -m unittest -v test_replay
```

Preparation only, after review:

```text
python -B replay.py --repo REPO_ABSOLUTE_PATH --output NEW_ABSOLUTE_OUTPUT
```

Actual old35 still requires separate explicit authorization:

```text
python -B replay.py --repo REPO_ABSOLUTE_PATH --output DIFFERENT_NEW_ABSOLUTE_OUTPUT --run-reviewed-old-tests
```

This packet does not authorize either actual historical run. No historical materialization, old35/oldcode import, Lean/native diagnostic, workflow selection or current acceptance has happened here. Parent Python3.12.14 default-temp ACL errors are parent-attributed ENV observations; my actual new tests used Python3.11.9 Windows and owned TEMP. No claim those are equivalent environment results.

Rollback: leave v2 unselected; retain original cap-failure record and every old frozen artifact. Do not overwrite/reuse output or restore old source proofs. A later old35 success would only mean historical Python fixture replay, never currentHEAD/native/science acceptance. All prior interpreter/OS race/TCB limits remain.

