"""C127 read-only runtime association audit. No Lean, workflow, trust or decoder execution.
Git access is only exact show <authorized-commit>:<authorized-path>.
The two publication/source JSON blobs are hashed only; never decoded or emitted.
The separately authorized catalog blob is also SHA256/length only, not JSON-parsed.
"""
import argparse,hashlib,io,json,pathlib,subprocess,zipfile
REL_SHA="24acad206e8fbe8aa563c7a55a308a3a1aa44d5820eb46d6bbb981cea6e5b5da"
ZIP_SHA="df6cfbf250153851522bbc0924f7017ccadaf863732954878ba924131dda3d18"
OLD="80b61870405bab7e9ef5004a6f11fc020267b2ab"
NEW="5cb853ea129615b4f11d630964503f89a6f6ccd3"
EXTRA=(".github/workflows/installed-lean433-full.yml","tools/check_proof_trust.py","web/library/declarations.json")
CONTROL=EXTRA[:2]+("tools/proof_trust.py",)
PLAIN=("release.json","historical-installed-build-original.zip","current-input-association.json","actual-job-metadata.json","historical-workflow.yml.txt")
def sha(b):return hashlib.sha256(b).hexdigest()
def exact_zip(data,expected):
    with zipfile.ZipFile(io.BytesIO(data),"r") as z:
        infos=z.infolist()
        if len(infos)!=len(expected) or len({i.filename.casefold() for i in infos})!=len(infos) or {i.filename for i in infos}!=set(expected):raise ValueError("ZIP exact membership")
        out={}
        for i in infos:
            if i.is_dir() or i.flag_bits&1 or i.file_size!=len(expected[i.filename]):raise ValueError("ZIP unexpected entry/size")
            b=z.read(i)
            if b!=expected[i.filename]:raise ValueError("ZIP member bytes")
            out[i.filename]={"bytes":len(b),"sha256":sha(b)}
        return out
def main():
    p=argparse.ArgumentParser();p.add_argument("--input-root",required=True);p.add_argument("--archive",required=True);p.add_argument("--repo",required=True);p.add_argument("--control-texts",action="store_true");p.add_argument("--catalog-only",action="store_true")
    a=p.parse_args();root=pathlib.Path(a.input_root)
    data={n:(root/n).read_bytes() for n in PLAIN}
    if sha(data["release.json"])!=REL_SHA:raise ValueError("release pin")
    rel=json.loads(data["release.json"])
    for n,v in rel["files"].items():
        if n not in data or len(data[n])!=v["bytes"] or sha(data[n])!=v["sha256"]:raise ValueError("released member pin")
    outer=pathlib.Path(a.archive).read_bytes()
    if sha(outer)!=ZIP_SHA:raise ValueError("outer ZIP pin")
    outer_members=exact_zip(outer,data)
    with zipfile.ZipFile(io.BytesIO(data["historical-installed-build-original.zip"]),"r") as z:
        if {i.filename for i in z.infolist()}!={"result.json","snapshot.json"} or len(z.infolist())!=2:raise ValueError("historical ZIP member set")
        nested={n:z.read(n) for n in ("result.json","snapshot.json")}
    result,snapshot=(json.loads(nested[n]) for n in ("result.json","snapshot.json"))
    assoc=json.loads(data["current-input-association.json"]);job=json.loads(data["actual-job-metadata.json"])
    if result["commit"]!=OLD or snapshot["commit"]!=OLD or assoc["current_commit"]!=NEW or job["head_sha"]!=OLD:raise ValueError("commit association")
    if snapshot["inputs"]!=result["inputs"]:raise ValueError("snapshot/result input difference")
    rows=assoc["all_input_associations"];paths=[r["path"] for r in rows]
    if len(paths)!=211 or len(set(paths))!=211 or set(paths)!=set(result["inputs"]):raise ValueError("211 input membership")
    for path in paths+list(EXTRA):
        q=pathlib.PurePosixPath(path)
        if q.is_absolute() or ".." in q.parts or ":" in path or "\\" in path:raise ValueError("unsafe member path")
    outputs=[];control={}
    for path in (["web/library/declarations.json"] if a.catalog_only else paths+list(EXTRA)):
        record={"path":path,"original211_input":path in paths,"semantic_read":"CONTROL_CODE_ONLY" if path in CONTROL else "HASH_ONLY"}
        for label,commit in (("prior",OLD),("current",NEW)):
            proc=subprocess.run(["git","-C",a.repo,"show",commit+":"+path],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
            b=proc.stdout;record[label]={"commit":commit,"bytes":len(b),"sha256":sha(b)}
            if a.control_texts and path in CONTROL:
                control[commit+":"+path]=b.decode("utf-8",errors="strict")
        record["prior_current_equal"]=record["prior"]["sha256"]==record["current"]["sha256"]
        if path in paths:
            r=next(x for x in rows if x["path"]==path)
            record["proof_input_derived"]=path.endswith(".lean") or path in ("lean-toolchain","lake-manifest.json")
            if record["prior"]["sha256"]!=result["inputs"][path] or record["prior"]["sha256"]!=r["prior_sha256"] or record["current"]["sha256"]!=r["current_committed_sha256"] or r["matches"]!=record["prior_current_equal"] or r["proof_input"]!=record["proof_input_derived"]:raise ValueError("actual Git blob association mismatch "+path)
        outputs.append(record)
    if a.catalog_only:
        print(json.dumps({"schema":"C127_ADDITIONAL_CATALOG_HASH_ONLY_NO_JSON_PARSE","records":outputs,"catalog_JSON_parsed":False,"catalog_content_emitted":False}));return
    workflow=next(x for x in outputs if x["path"]==EXTRA[0])
    if workflow["prior"]["sha256"]!=sha(data["historical-workflow.yml.txt"]):raise ValueError("released workflow mismatch")
    proof=[x for x in outputs if x.get("proof_input_derived")]
    out={"schema":"C127_ACTUAL_READ_ONLY_GIT_AND_ARCHIVE_ASSOCIATION","outer_zip":{"sha256":sha(outer),"bytes":len(outer),"members":outer_members},"historical_zip":{"sha256":sha(data["historical-installed-build-original.zip"]),"members":{n:{"bytes":len(b),"sha256":sha(b)} for n,b in nested.items()}},"original211_records":outputs[:211],"additional_control_records":outputs[211:],"original211_unchanged":sum(x["prior_current_equal"] for x in outputs[:211]),"proof_inputs":len(proof),"proof_inputs_unchanged":sum(x["prior_current_equal"] for x in proof),"read_only_git_blob_bindings":len(outputs)*2,"control_texts":control,"no_compiler_workflow_or_trust_script_execution":True,"publication_source_JSON_semantic_read":False}
    print(json.dumps(out,ensure_ascii=False))
if __name__=="__main__":main()
