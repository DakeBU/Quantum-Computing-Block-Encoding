# C315: two chain carrier failures, forensic diagnosis only

INTERNAL_FAILURE_INTERFACE_FORENSICS, not repair or publication review.
Prior Hermite/value/cost, height and runtime exposures plus C206/C230/C276 author
roles are disclosed. C304's permitted manifest exposes prior packet IDs/hashes
and historical metadata, not fresh evidence for those packets. No C311/C310 or
other review/output contents read. C299/C302/C308 and older freezes unchanged.

## Evidence and failure boundary

C304 and actual C313 chain bytes match (169b3f27...); C304 checks are the
unchanged intended consumer, not evidence it ran. WHOLE private stdout:
10687 bytes, sha256 656e5a4b4df133075ace02e5aea1bbcefbea14b3f937da1384f3e4edc141d6cf.
The 6115-byte feedback was NOT used/read. Six archive members hashed in memory;
only stdout text and prefix for private-path redaction decoded. No extraction.
Exit 1 / 57.734s is parent-supplied historical metadata, not a rerun or an
independently consumed exit-status sidecar. Actual stdout has errors at 63:4
and 142:2, plus the retained unused Sum.elim warning at 46:45.

Nine printed private helper axiom rows include five ordinary-only rows and
four sorryAx-contaminated rows: kernelEntry, prepared, data and stored.
Those are rejected error-recovery declarations, NOT accepted theorems. No
scientific consumer execution or accepted chain own output follows from them.
The actualRight branch no longer has a diagnostic; prepared still inherits
kernelEntry contamination. This is not a separate accepted right-only gate.

## 1. Column decode: equal sizes, different hidden elaborated carriers

Write d=sourceDegree delta, m=2*k+1, N=fiveSize d m, A=assemblySize k delta.
Raw ordinary def bodies give N=A DEFINITIONALLY, with exactly the same
right-associated five-term componentSize sum; no arithmetic premise is needed.
FiveIndex d m and FullIndex k delta also expand to the same nested sum.

C248 kernelEntry elaborates its local out at Fin 2 × Fin N, via
@finProdFinEquiv 2 N, while the C304 binder j has type Fin (2*A).
The helper RHS elaborates @finProdFinEquiv 2 A. The initial declaration can
use ordinary definitional conversion; dsimp only [kernelEntry] exposes the
N-specialized application to j without changing j's A-specialized binder.

The row rewrite succeeds. The explicit column pattern then uses the A decoder,
where the exposed target contains the N decoder. Both print as
(finProdFinEquiv.symm j).2 because implicit size arguments are hidden.
The COMPLETE diagnostic explicitly says the target is not type-correct at
implicit transparency: j:Fin(2*A) is expected at Fin(2*N).
This is a restricted-transparency/matching boundary after unfolding ordinary
semireducible definitions, not unequal dimensions, wrong product order,
off-by-one, invalid kernel term or a Lean/runtime bug.
Mathlib's actual finProdFinEquiv is a def with inverse (divNat,modNat);
its hidden second factor controls the projection carrier and modulus.

Minimal SAME-PROPOSITION probe to authorize separately (NOT implemented):
retain the exact existing c252_kernelEntry_value statement and all binders.
First choose ONE explicit local pair, e.g.
  let A := assemblySize k delta
  let out : Fin 2 × Fin A :=
    (finProdFinEquiv (m := 2) (n := A)).symm j
Then checkpoint a whole-target change to the literal kernelAt/actualEntryQ
equation using this SAME out.1/out.2 on BOTH sides, with the row/column decodes
also at this carrier; use only definitional conversion of fiveSize/assemblySize.
Do not execute rw until this unchanged-proposition checkpoint typechecks.
Only thereafter instantiate decode_value at a and out.2. Success is NOT
predicted here. Stop at the first exact type mismatch if conversion fails;
do not widen transparency globally or add a dimensional hypothesis/model.

## 2. QData: normalize the whole dependent return carrier first

Let tau=(cutoffQ delta).value, T=tailCutoff delta, dTau=degree tau tau,
d0=sourceDegree delta=degree T T. C150 cutoff's Run value is literally the
clog/max/ceil expression defining T, and actual C159 cutoffQ_value is proved rfl.
Thus tau=T and dTau=d0 are definitional, for ALL Rat delta including zero or
negative; no epsilon/R positivity or error/cost correctness premise is missing.

C248 computes L=dTau+2*k+1, materializes RationalData n (fiveSize dTau m),
and transports the WHOLE returned record with hsize to RationalData n A.
Its d equality also appears in rightEntry's FullIndex transport; L governs
factorials, Fin indices and inequality-proof arguments. Proof witnesses are
not additional semantic data, but dependent expression typing must stay aligned.

At 142:2 the simplified using-term has equality carrier
RationalData n (fiveSize (degree T T) m), while the expected target has
RationalData n A and still displays materializePrepared at degree tau tau.
The actual message does NOT show a false cutoff equality. It shows two
normal forms/carrier instantiations not synchronized by this simpa only list.
Listing cutoffQ_value plus unfolding sourceDegree on the using-term is not
evidence of normalization of the whole target's dependent arguments/carrier.
The exact internal simplifier reconstruction step is not traced, so do not
attribute it to an unobserved specific implementation bug. No cast remains
printed in this expected term; do not invent an irreducible leftover Eq.mp.

Minimal SAME-PROPOSITION probe to authorize separately (NOT implemented):
retain produceExplicitQData_value exactly. Fix A,T,d0,L once; checkpoint the
definition-only dTau=d0 and fiveSize d0 m=A conversions. Express BOTH the
runtime materialized record and c252_prepared_value at RationalData n A.
If explicit transport is needed, its ONLY map is
  Eq.mp (congrArg (fun D => RationalData n D) hsize)
applied to the WHOLE record, not a callback/field replacement. Check the exact
original equality against that fully typed target BEFORE any simpa using.
No unfolding of factorials, finite-exp arithmetic or table evaluation is
needed for the carrier test. A later gate may discover an additional proof
witness/congruence detail; this report does not certify probe elaboration.

## Handoff and limits

Next useful information: one isolated exact carrier/type checkpoint per
failure, then parent actual gate only after separate authorization. No repair
packet, theorem proof, widened premise, option/linter/cap change or new model.
No cost/width/bits/native GCD/allocation/sharing/circuit/error/full ROOT credit.
qbe-substantive-worker keeps math equality distinct from tactic/API acceptance.
Read-only PowerShell/.NET; no compiler/scripts/Python/lake/Git/network/subagents.
Two filename-discovery failures retained in manifest; no failed command writes.
Only NEW C315 report/manifest/seal via apply_patch. Freeze and STOP.
