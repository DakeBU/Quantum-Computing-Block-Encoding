"""Read-only scientific binding and evidence association checks; no Git/Lean/build."""
import argparse
import csv
import hashlib
import importlib.util
import json
import zipfile
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--work", required=True)
    parser.add_argument("--checker", required=True)
    parser.add_argument("--archive", required=True)
    parser.add_argument("--part", choices=["integrity", "declarations"], default="integrity")
    args = parser.parse_args()
    work, checker = Path(args.work), Path(args.checker)
    proposal = work / "hbi-c112-publication-proposal"
    root = proposal / "staged-root"
    pinned = {
        "selected-eleven-fields.json": "1be30104c559296fde54d35e774726a22d972c8f12517bb940ed6c86a4fcdef3",
        "selected-source-row.json": "0608cbd38703c36ff229ecbe0647cd0684c968c61338a6054c67c04733e74fbf",
        "binding-context.json": "c57f4cbc40a861518547c2e35b0217f2dbaebb2e5a07e22b51e128005da8c42b",
    }
    for name, digest in pinned.items():
        assert sha(proposal / name) == digest, name
    context = read(proposal / "binding-context.json")
    record = read(proposal / "selected-eleven-fields.json")
    source = read(proposal / "selected-source-row.json")
    assert sha(checker) == context["checker_sha256"]
    vector = context["raw_inputs"]
    assert len(vector) == 204 == len({row["path"] for row in vector})
    expected = {row["path"] for row in vector}
    discovered = {p.relative_to(root).as_posix()
                  for directory in ("QuantumBlockEncoding", "ABEISTests")
                  for p in (root / directory).rglob("*.lean")}
    assert discovered | {"lean-toolchain", "lake-manifest.json"} == expected
    assert "lakefile.lean" not in expected
    rows = []
    for row in vector:
        p = root / row["path"]
        assert sha(p) == row["sha256"] and p.stat().st_size == row["bytes"], row["path"]
        rows.append(dict(row, checked=True))
    assert read(root / "website/research/sources.json") == {"sources": [source]}
    lesson = root / record["lesson_path"]
    assert sha(lesson) == context["lesson_sha256"] == sha(work / "hermite-boundary-c56-author/natural-source.md")
    spec = importlib.util.spec_from_file_location("unchanged_publication_checker", checker)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    binding = module.binding_digest(root, record)
    assert binding == context["binding_sha256"] == "428cdd15e5bc4a59eb5c6ffc31312115d2b094e1d4ea001691e480ec0ebc2759"
    own = read(work / "hbi-c100-own-formal-first/exact-interfaces.json")
    public = [d for d in own["declarations"] if d["visibility"] != "private" and d["kind"] != "instance"]
    prefix = "QuantumBlockEncoding.HermiteBoundaryInjection."
    assert len(public) == 121
    names = {prefix + d["name"] for d in public}
    assert names == set(record["declarations"]) and len(record["declarations"]) == len(names)
    mapped = [n for item in record["obligation_map"] for n in item["declarations"]]
    assert set(mapped) == names and len(mapped) == 121
    assert set(record["graph_contribution"]["node_ids"]) == {"declaration:" + n for n in names}
    crosswalk = list(csv.DictReader((work / "hbi-c100-own-formal-first/declaration-crosswalk.tsv").read_text(encoding="utf-8-sig").splitlines(), delimiter="\t"))
    cross = {d["name"]: d for d in crosswalk}
    obligations = {item["declarations"][0]: item for item in record["obligation_map"]}
    declaration_rows = []
    for d in public:
        name = prefix + d["name"]
        item = obligations[name]
        expected_kind = "proof-edge" if d["kind"] == "theorem" else "prerequisite"
        assert item["kind"] == expected_kind, name
        declaration_rows.append({"id": d["id"], "name": name, "kind": d["kind"], "source_header": d["exact_source_header"],
                                 "proposed_obligation": item, "own_frozen_crosswalk": cross[d["name"]],
                                 "kind_matches": True})
    inv = read(work / "hbi-c67-formal-input/formal-inputs.json")
    by_path = {r["path"]: r for r in vector}
    overlap, extra = [], []
    current_raw = []
    for row in inv["inputs"]:
        actual = sha(work / "hbi-c67-formal-input" / row["path"])
        assert actual == row["formal_snapshot_sha256"]
        raw_actual = sha(checker.resolve().parents[2] / row["path"])
        assert raw_actual == row["production_raw_sha256"], "Current raw drift: " + row["path"]
        current_raw.append({"path": "R/" + row["path"], "sha256": raw_actual, "unchanged": True})
        if row["path"] in by_path:
            assert by_path[row["path"]]["sha256"] == row["production_raw_sha256"]
            overlap.append(row["path"])
        else:
            extra.append(row["path"])
    assert len(overlap) == 32 and extra == ["lakefile.lean"]
    supplement_path = work / "hbi-c114-hash-only-context-supplement.json"
    assert sha(supplement_path) == "38135c579d9eaa7d7de517cb027b4e762428db18e7503b755658ebf61e4d38fe"
    supplement = read(supplement_path)
    assert supplement["binding_context_sha256"] == pinned["binding-context.json"]
    assert supplement["opaque_scientific_binding_sha256"] == binding
    lake = next(row for row in inv["inputs"] if row["path"] == "lakefile.lean")
    assert supplement["additional_context"]["current_raw_sha256"] == lake["production_raw_sha256"]
    assert supplement["additional_context"]["original_formal_snapshot_sha256"] == lake["formal_snapshot_sha256"]
    final = work / "hbi-c97-final-binding-association"
    final_names = ["README.md", "decoder-role-evidence.json", "verification.json", "verify-association.ps1",
                   "publicsafe-allowlist.json", "manifest.sha256", "seal.json"]
    assert sha(final / "seal.json") == "06d6068cc144263f483769c235505febbfaa50f4d24e095f5668941f1679e7a5"
    assert sha(final / "manifest.sha256") == "6b91dca0c259ba64daeadd84461aad6fe73b1551011c37c432353834b24984fb"
    for line in (final / "manifest.sha256").read_text().splitlines():
        if line:
            digest, name = line.split("  ", 1)
            assert name.startswith("OUTPUT/") and name[7:] in final_names
            assert sha(final / name[7:]) == digest
    decoder = read(final / "decoder-role-evidence.json")
    envelope_path = work / "hbi-c115-decoder-transport-envelope.json"
    assert sha(envelope_path) == "6ad164aef84301c745a28715dc5d3a9d5524cfa36f23cc4b89edf46f50f606b7"
    envelope = read(envelope_path)
    assert all(envelope[k] == v for k, v in decoder.items()), "Original decoder field changed"
    added = sorted(set(envelope) - set(decoder))
    assert added == sorted(["packet_path", "packet_sha256", "artifact_path", "artifact_sha256",
                             "original_role_association_path", "original_role_association_sha256", "envelope_transport"])
    assert envelope["binding_sha256"] == binding
    assert envelope["original_role_association_sha256"] == sha(final / "decoder-role-evidence.json")
    assert envelope["packet_sha256"] == decoder["original_packet"]["sha256"]
    assert envelope["artifact_sha256"] == decoder["reconstruction"]["sha256"]
    assert sha(work / "hbi-c97-whole-formal-decoder/reconstruction.md") == envelope["artifact_sha256"]
    verification = read(final / "verification.json")
    assert verification["counts"]["context_overlap"] == 32
    assert verification["missing_context_paths"] == ["INPUT/lakefile.lean"]
    final_hashes = [{"path": "INPUT/C97-final/" + n, "sha256": sha(final / n)} for n in final_names]
    result = {
        "schema": "C100_FINAL_BINDING_AND_SCOPE_CHECKS_V1",
        "binding_sha256": binding, "unchanged_checker_sha256": sha(checker),
        "checker_function_only": "binding_digest", "git_or_compiler_called": False,
        "proposal_file_pins": pinned, "raw_input_vector": rows,
        "hash_only_global_entries": 204, "production_and_test_Lean_entries": len(discovered),
        "independent_global_semantic_coverage_claim": False,
        "source_row_projection_equal": True, "staged_lesson_equals_frozen_source": True,
        "named_public_declarations": 121, "whole_own_declarations": 125,
        "excluded_from_named_public_inventory": [d for d in own["declarations"] if d not in public],
        "declaration_associations": declaration_rows, "formal_intersection_paths": overlap,
        "previously_authorized_current_raw33_rehashed": current_raw,
        "formal_not_in_scientific_digest": extra, "supplement_sha256": sha(supplement_path),
        "supplement_adds_to_scientific_digest": False, "future_lakefile_stale_detection": False,
        "decoder_final_pins": final_hashes, "decoder_envelope_sha256": sha(envelope_path),
        "decoder_original_fields_preserved": True, "decoder_envelope_added_fields": added,
        "decoder_zip_transport_byte_check_provenance": "Actual C97 and parent reports; ZIP was not separately released/read by this reviewer",
        "source_blind_original_reconstruction_hash_rechecked": True,
        "full_publication_validator_executed": False, "registry_or_production_changed": False,
    }
    archive = Path(args.archive)
    assert sha(archive) == "c56439681ef7dca983e83c2a0b25d59103f3fd98199499fafe0f955e40fe1fb9"
    phase4 = work / "hbi-c100-raw-runtime-association"
    allowed = [n for n in (phase4 / "publicsafe-allowlist.txt").read_text().splitlines() if n]
    archive_rows = []
    with zipfile.ZipFile(archive) as zipped:
        assert len(zipped.namelist()) == len(set(zipped.namelist())) == 15
        assert set(zipped.namelist()) == set(allowed)
        for name in zipped.namelist():
            data = zipped.read(name)
            assert data == (phase4 / name).read_bytes()
            archive_rows.append({"member": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "equals_own_original": True})
    result["own_phase4_original_archive"] = {"path": "R/reviews/publication/migration-checkpoints-c113/hbi-c100-raw-runtime-association-original.zip", "sha256": sha(archive), "members": archive_rows, "reviewer_checked_in_memory_no_extract_or_execute": True}
    if args.part == "declarations":
        result = {"binding_sha256": binding, "declaration_associations": declaration_rows}
    else:
        del result["declaration_associations"]
    print(json.dumps(result, ensure_ascii=False, separators=(",", ":")))


if __name__ == "__main__":
    main()

