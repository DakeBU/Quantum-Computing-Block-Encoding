# Decoder role: exact opaque-binding association only

State: SCOPED_DECODER_OPAQUE_ASSOCIATION_CONFIRMED. The original 12-file decoder packet remains FROZEN_BEFORE_SOURCE_RELEASE and was not edited. This continuation did not solve or reconstruct the mathematics again.

I am the original source-blind decoder hbi_fresh_whole_decoder_c97, now recording run hbi-c97-final-binding-association. My independent reconstruction still concerns the exact original formal target SHA256 cf4fcd8e410b4c103e8e45a569e878404de64e1f2d3775dad0a99004990627f1, under original input inventory SHA256 faf40d53126c173a94965a5499589104d6648766918d75abdf2561cbc9393de8.

I rehashed all original twelve files, checked the ten payload hashes against the original manifest, checked the manifest against its original frozen digest, and checked the original seal bytes and its manifest reference. The authorized original ZIP contains exactly those twelve names once each; each member's uncompressed bytes equal the corresponding original file. The ZIP is only a transport of existing evidence, not a new review.

Original manifest SHA256: 7566b132df2982bd28fd48bafa39ad05837afebfb7ca01bb94ce89c72da4e308.

Original seal.json SHA256: af0922d26e6f9fe1b403e32143320ea369a17fd42abd446cebb98840ff07e455.

Original ZIP SHA256: 066631cbb4ecac843ef0403334d9f4bbc19cef2f4dbfeb43b3baebfd45cb782d.

The only new metadata read was the separately authorized INPUT/binding-context.json, INPUT/current-formal-bindings.json and later INPUT/hbi-c114-hash-only-context-supplement.json. The first two raw SHA256 values are respectively c57f4cbc40a861518547c2e35b0217f2dbaebb2e5a07e22b51e128005da8c42b and c9cc912895e3c41ac4e55ef4b219a89e2f6ff81f10f8d8bf4486e683af630c93. No neighboring proposal, source, lesson, staged-root, reviewer, compile evidence or natural/raw-comment text was read. The map is explicitly parent-supplied bounded-mask association evidence; I did not independently rerun that transformation.

The supplied proposed opaque scientific-binding identifier is 428cdd15e5bc4a59eb5c6ffc31312115d2b094e1d4ea001691e480ec0ebc2759. I checked that exact identifier and associated my original evidence with it only in the limited sense recorded in OUTPUT/decoder-role-evidence.json. I did not read the referenced scientific metadata, inspect the checker implementation or independently recompute that identifier. Its supplied status is PROPOSED_NOT_ACCEPTED, which this packet does not change.

## What the vectors establish

All 33 authorized original formal inputs were rehashed and remain equal to the pinned inventory. All 33 declared formal/raw pairs in the new mapping equal the original inventory's pairs. The proposed context has 204 unique raw/config path entries, as declared. Of the 33 original input paths, 32 occur in that vector and each corresponding raw digest agrees. These are comparisons of declared digests, not independent reads of current production raw bytes.

The missing path is INPUT/lakefile.lean. Its parent-supplied mapping and original inventory both state raw SHA256 f6637c3a2467fdeee6b2de72505d0581c4a49793388197bd8e9e7df3f5817fc1 and formal SHA256 c8b6e3f46a451e8f71501b5ef57072ee683c54636e69ee3769bda63f0a284d4e. The proposed 204-entry context contains no lakefile entry. No equality for a missing entry is inferred.

I requested a narrowly scoped hash-only supplement pinned to the above context digest to clarify that missing configuration path. The authorized response is INPUT/hbi-c114-hash-only-context-supplement.json, whose actual raw SHA256 is 38135c579d9eaa7d7de517cb027b4e762428db18e7503b755658ebf61e4d38fe. It binds the exact context, map, inventory and opaque scientific-binding identifiers, states the same lakefile raw/formal pair, and explicitly says lakefile is additional syntax/config context rather than a direct scientific-digest input. I checked those exact relationships. Its claim that the current raw hash was separately observed belongs to the parent; I did not read current raw bytes or the cited independent review.

That supplement answers the requested provenance clarification and permits the scoped decoder association recorded here. It does not turn 32/33 scientific-vector coverage into 33/33, validate configuration semantics or the mask, or establish automatic stale detection for future lakefile changes. Scientific metadata adequacy and the checker implementation remain unreviewed. Any changed context, map, supplement or scientific identifier requires a newly pinned association; no automatic enforcement is inferred.

## Honest reuse boundary

The reusable role evidence is the unchanged whole-formal-module reconstruction, identified by its exact artifact SHA256 ca708d34e5bcd6ef42ffce3e7914a3b93ff744d3e6a103c5184bda7937a5fec9, together with the original packet pins and this qualified opaque association. A consumer must preserve these limitations; it may not relabel this as accepted source review, semantic approval of metadata, review of every global source, independent raw-to-formal proof, compiler acceptance or production admission. Those are different evidence objects and, where required, belong to a distinct reviewer.

No compiler, Git, network or child agents were used. Only this new association directory was written, through apply_patch. The original mathematical packet's content and frozen state are unchanged. Public paths use logical INPUT/ and OUTPUT/ roots only.

OUTPUT/verification.json records the exact twelve original hashes, ZIP member checks and full 33-entry comparison. OUTPUT/verify-association.ps1 reproduces only these bounded byte/hash comparisons when given the authorized paths. OUTPUT/manifest.sha256 hashes all non-integrity output files; OUTPUT/seal.json binds the manifest without a self-hash or circular dependency.
