param(
 [Parameter(Mandatory=$true)][string]$OriginalRoot,
 [Parameter(Mandatory=$true)][string]$InputRoot,
 [Parameter(Mandatory=$true)][string]$ContextPath,
 [Parameter(Mandatory=$true)][string]$MapPath,
 [Parameter(Mandatory=$true)][string]$ZipPath,
 [Parameter(Mandatory=$true)][string]$SupplementPath
)
$ErrorActionPreference='Stop'
function Sha([byte[]]$b){[Convert]::ToHexString([System.Security.Cryptography.SHA256]::HashData($b)).ToLower()}
function FileSha([string]$p){Sha ([System.IO.File]::ReadAllBytes($p))}
$ctx=Get-Content -Raw -LiteralPath $ContextPath | ConvertFrom-Json
$map=Get-Content -Raw -LiteralPath $MapPath | ConvertFrom-Json
$inventoryPath=Join-Path $InputRoot 'formal-inputs.json'
if((FileSha $inventoryPath) -ne 'faf40d53126c173a94965a5499589104d6648766918d75abdf2561cbc9393de8'){throw 'Original input inventory drift'}
$inv=Get-Content -Raw -LiteralPath $inventoryPath | ConvertFrom-Json
$manifestPath=Join-Path $OriginalRoot 'manifest.sha256'
$manifest=Get-Content -Raw -LiteralPath $manifestPath
if((FileSha $manifestPath) -ne '7566b132df2982bd28fd48bafa39ad05837afebfb7ca01bb94ce89c72da4e308'){throw 'Original manifest drift'}
$originalSealPath=Join-Path $OriginalRoot 'seal.json'
if((FileSha $originalSealPath) -ne 'af0922d26e6f9fe1b403e32143320ea369a17fd42abd446cebb98840ff07e455'){throw 'Original seal drift'}
$originalSeal=Get-Content -Raw -LiteralPath $originalSealPath | ConvertFrom-Json
if($originalSeal.manifest_sha256 -ne (FileSha $manifestPath) -or $originalSeal.state -ne 'FROZEN_BEFORE_SOURCE_RELEASE'){throw 'Original freeze changed'}
$manifestRows=@($manifest.TrimEnd().Split("`n") | ForEach-Object {if($_ -notmatch '^([a-f0-9]{64})  OUTPUT/(.+)$'){throw 'Manifest shape'};[pscustomobject]@{name=$Matches[2];expected=$Matches[1]}})
$origFiles=@(Get-ChildItem -File -LiteralPath $OriginalRoot)
$allow=Get-Content -Raw -LiteralPath (Join-Path $OriginalRoot 'publicsafe-allowlist.json') | ConvertFrom-Json
if($origFiles.Count -ne 12 -or @(Compare-Object @($allow.files | ForEach-Object {$_.Substring(7)} | Sort-Object) @($origFiles | ForEach-Object Name | Sort-Object)).Count -ne 0){throw 'Original allowlist mismatch'}
$origHashes=@($origFiles | ForEach-Object {$f=$_;$actual=FileSha $f.FullName;$bound=@($manifestRows | Where-Object name -eq $f.Name);if($bound.Count -eq 1 -and $actual -ne $bound[0].expected){throw 'Original payload mutation'};[pscustomobject]@{path=('INPUT/original-decoder/'+$f.Name);sha256=$actual;bytes=$f.Length;manifest_bound=($bound.Count -eq 1)}})
if(@($map.files).Count -ne 33 -or @($inv.inputs).Count -ne 33 -or $map.formal_inventory_sha256 -ne (FileSha $inventoryPath)){throw 'Formal map inventory mismatch'}
if(@($map.files | Group-Object path | Where-Object Count -ne 1).Count -ne 0){throw 'Duplicate formal-map path'}
if(@($ctx.raw_inputs).Count -ne $ctx.raw_input_count -or @($ctx.raw_inputs | Group-Object path | Where-Object Count -ne 1).Count -ne 0){throw 'Context vector count or uniqueness mismatch'}
$vector=@($inv.inputs | ForEach-Object {
 $f=$_;$p=Join-Path $InputRoot $f.path;$actual=FileSha $p
 if($actual -ne $f.formal_snapshot_sha256 -or (Get-Item -LiteralPath $p).Length -ne $f.bytes){throw 'Original formal input drift'}
 $m=@($map.files | Where-Object path -eq $f.path)
 $c=@($ctx.raw_inputs | Where-Object path -eq $f.path)
 $mapMatches=($m.Count -eq 1 -and $m[0].formal_snapshot_sha256 -eq $actual -and $m[0].production_raw_sha256 -eq $f.production_raw_sha256)
 if(-not $mapMatches){throw 'Formal/raw map changed from original inventory'}
 if($c.Count -gt 1 -or ($c.Count -eq 1 -and $c[0].sha256 -ne $m[0].production_raw_sha256)){throw 'Context/map raw digest mismatch'}
 [ordered]@{path=('INPUT/'+$f.path);original_formal_sha256=$actual;original_formal_bytes=$f.bytes;original_declared_raw_sha256=$f.production_raw_sha256;current_map_formal_sha256=$m[0].formal_snapshot_sha256;current_map_raw_sha256=$m[0].production_raw_sha256;map_matches_original=$mapMatches;context_raw_count=$c.Count;context_raw_sha256=$(if($c.Count -eq 1){$c[0].sha256}else{$null});context_matches_map=($c.Count -eq 1)}
})
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=[System.IO.Compression.ZipFile]::OpenRead($ZipPath)
try{
 if($zip.Entries.Count -ne 12){throw 'ZIP entry count'}
 if(@($zip.Entries | Group-Object FullName | Where-Object Count -ne 1).Count -ne 0){throw 'ZIP duplicate entries'}
 $zipRows=@($zip.Entries | ForEach-Object {
  $entry=$_;$stream=$entry.Open();$memory=[System.IO.MemoryStream]::new()
  try{$stream.CopyTo($memory);$b=$memory.ToArray()}finally{$stream.Dispose();$memory.Dispose()}
  $h=Sha $b;$local=@($origHashes | Where-Object path -eq ('INPUT/original-decoder/'+$entry.FullName))
  if($local.Count -ne 1 -or $local[0].sha256 -ne $h -or $local[0].bytes -ne $b.Length){throw 'ZIP/original mismatch'}
  [ordered]@{member=$entry.FullName;sha256=$h;bytes=$b.Length;matches_original=$true}
 })
}finally{$zip.Dispose()}
$miss=@($vector | Where-Object context_raw_count -eq 0 | ForEach-Object path)
$supplementHash=FileSha $SupplementPath
if($supplementHash -ne '38135c579d9eaa7d7de517cb027b4e762428db18e7503b755658ebf61e4d38fe'){throw 'Supplement changed'}
$supp=Get-Content -Raw -LiteralPath $SupplementPath | ConvertFrom-Json
if($supp.binding_context_sha256 -ne (FileSha $ContextPath) -or $supp.current_formal_bindings_sha256 -ne (FileSha $MapPath) -or $supp.original_formal_inventory_sha256 -ne (FileSha $inventoryPath) -or $supp.opaque_scientific_binding_sha256 -ne $ctx.binding_sha256){throw 'Supplement association mismatch'}
$lake=@($vector | Where-Object path -eq 'INPUT/lakefile.lean')
if($lake.Count -ne 1 -or $supp.additional_context.path -ne 'lakefile.lean' -or $supp.additional_context.current_raw_sha256 -ne $lake[0].current_map_raw_sha256 -or $supp.additional_context.original_formal_snapshot_sha256 -ne $lake[0].original_formal_sha256 -or $supp.additional_context.direct_input_to_existing_scientific_binding_digest -ne $false -or $supp.additional_context.included_in_C112_204_raw_context_vector -ne $false){throw 'Additional config pin mismatch'}
[ordered]@{
 kind='SOURCE_BLIND_OPAQUE_ASSOCIATION_BYTE_CHECKS_ONLY'
 original_state=$originalSeal.state
 original_packet_hashes=$origHashes
 original_manifest_sha256=(FileSha $manifestPath)
 original_seal_sha256=(FileSha $originalSealPath)
 original_inventory_sha256=(FileSha $inventoryPath)
 original_target_formal_sha256='cf4fcd8e410b4c103e8e45a569e878404de64e1f2d3775dad0a99004990627f1'
 original_zip_path='INPUT/hbi-c97-whole-formal-decoder-original.zip'
 original_zip_sha256=(FileSha $ZipPath)
 zip_members=$zipRows
 binding_context_path='INPUT/binding-context.json'
 binding_context_sha256=(FileSha $ContextPath)
 binding_context_status=$ctx.status
 opaque_binding_sha256=$ctx.binding_sha256
 declared_opaque_artifact_hashes=[ordered]@{selected_record_sha256=$ctx.selected_record_sha256;selected_source_row_sha256=$ctx.selected_source_row_sha256;lesson_sha256=$ctx.lesson_sha256;checker_sha256=$ctx.checker_sha256;independently_recomputed=$false}
 current_formal_bindings_path='INPUT/current-formal-bindings.json'
 current_formal_bindings_sha256=(FileSha $MapPath)
 vector=$vector
 counts=[ordered]@{original_packet_files=12;zip_members=12;original_formal_inputs_rehashed=33;map_matches_original=33;context_rows=@($ctx.raw_inputs).Count;context_overlap=33-$miss.Count;context_missing=@($miss).Count}
 missing_context_paths=$miss
 additional_config_supplement=[ordered]@{path='INPUT/hbi-c114-hash-only-context-supplement.json';sha256=$supplementHash;status=$supp.status;bound_context_digests_verified=$true;path_pinned='INPUT/lakefile.lean';raw_sha256=$supp.additional_context.current_raw_sha256;formal_sha256=$supp.additional_context.original_formal_snapshot_sha256;scientific_digest_direct_input=$false;scientific_vector_contains_path=$false;parent_observation_claim=$supp.additional_context.current_raw_hash_separately_observed_by_parent;current_raw_independently_read_by_decoder=$false;future_automatic_stale_detection_established=$false}
 independently_read_current_raw_files=$false
 independently_reran_mask=$false
 independently_recomputed_scientific_binding=$false
 scientific_metadata_semantics_reviewed=$false
 global_raw_source_semantics_reviewed=$false
 source_fidelity_reviewed=$false
 no_compiler_git_network_children=$true
 original_files_modified=$false
} | ConvertTo-Json -Depth 20
