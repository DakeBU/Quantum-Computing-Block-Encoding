# C245: literal five-block kernel and left-boundary reconstruction

Classification: INTERNAL SOURCE-FIRST SEMANTIC RECONSTRUCTION. This freezes an original-source comparison baseline before release of the new producer. It does not review C243, accept new compiled output, prove a new theorem, or grant SourceAnchor/ROOT/PURIFIED credit.

## 1. Exposure and source boundary

I read the original C20 comparison/translation/threshold modules, C21 assembly/indexed-kernel/actual-coefficient modules, C22 rational blocks and stored producer, C23 charged source cache, supporting canonical chain/storage bodies, and the old C150 middle/right-setup definitions. Exact raw bindings and extents are in `RAW_PINS.json`. Imports were not recursively opened as a trust audit. Old source `#print axioms` commands are source text only, not executed axiom evidence.

C237 proposal/signatures/author prose, C243 definitions, new actual compiled outputs, new parent cost analysis/verdicts and other new reviews were not read. An initial filename-only search listed some old review/log filenames; none of their contents was opened. I retain substantial prior Hermite source and runtime exposure (C147/C157/setup/middle/same-chain slices and their separately authorized association stages), and the prior C188/C196/C201 same-chain work. I also authored the separate Gaussian C206/C230 work and reviewed C224 governance. This is independent reconstruction for this new comparison phase, not a fresh universal or source-publication decoder.

Current AGENTS/HARNESS and the linked async policy are bound. The retained three required protocols have unchanged hashes; the worker skill was reread completely. No compiler, Python, scripts, lake, Git, network, finite diagnostic, subagent, or new theorem proof search was used. Only read-only source/API inspection and raw hashing preceded writing this new packet with `apply_patch`.

## 2. Physical word, stage and comparison conventions

Let `W=n+1`, `N=2^W`, `sigma=gridStepQ W R=2*R/2^W`, `T=tailCutoff delta`, `d=sourceDegree delta`, and `m=2*k+1`. The source grid is

```text
p(x) = -R + sigma*wordValue(x),
wordValue(bit::tail) = bit.val + 2*wordValue(tail).
```

The first emitted bit is q0, the least significant bit. A kernel stage is `q` (starting at 0), not the remaining-word length; its translation increment is `sigma*2^q*bit.val`. `ireadout` and canonical `readout` consume the first bit at stage `start`, then recurse at `start+1`.

Comparator states are 0=less, 1=equal, 2=greater. Define the exact source transition

```text
finish(a,x,y) = 0 if x<y; 2 if y<x; otherwise a.
C(c,q,b,a,a') = [finish(a,b.val,(c/2^q)%2) = a'].
```

Square brackets denote rational 0/1, not a new implementation definition. Equal higher bits retain the existing low-bit relation; an unequal higher bit overwrites it. This is why scanning LSB-first is correct, rather than an MSB-first lexicographic automaton. The row index is the old state and the column index is the next state. Swapping them transposes the literal kernel.

The comparator left boundary is `E(a)=[a=1]`. The exact right boundary is

```text
Q(W,c,a) = 0               if c=0
           1               else if c=2^W
           [a=0]           otherwise.
Qflip(W,c,a,false)=Q(W,c,a)
Qflip(W,c,a,true)=1-Q(W,c,a).
```

Empty/full dispatch must come before the ordinary accepted-state test. In particular, for a full cut the W low cut digits are all zero and the terminal state alone is not a valid mask. Flipping the mask changes ONLY this right boundary. It does not change `C` or `E`.

The four raw cuts are

```text
cA = min N (Nat.ceil ((-1+R)/sigma))
cB = min N (if (0+R)/sigma < 0 then 0 else Nat.floor ((0+R)/sigma)+1)
cC = min N (if (-T+R)/sigma < 0 then 0 else Nat.floor ((-T+R)/sigma)+1)
cT = min N (Nat.ceil ((T+R)/sigma)).
```

All casts of `T` here are Nat-to-Rat. Strict cut uses natural ceiling; inclusive cut preserves the negative quotient branch and floor-plus-one. All cuts are bounded by N by construction for arbitrary rational R/delta. With `R>0`, these implement respectively `p<-1`, `p<=0`, `p<=-T`, `p<T`. Continuous-grid interpretation needs `R>0`; the raw kernel formulas do not. At `R=0`, rational division by zero is the source's total division: strict cuts are 0 and inclusive cuts are 1 (W>=1), not arbitrary replacements by the intended continuous indicator. Negative R likewise cannot silently inherit the positive-step mask theorem.

## 3. Exact nested index and flattening

Write `H_h = Fin 3 × (Fin 3 × Fin (h+1))`. The literal type and constructors are

```text
FullIndex = H_0 ⊕ (H_d ⊕ (H_m ⊕ (H_0 ⊕ H_d)))
branch 1: inl z
branch 2: inr (inl z)
branch 3: inr (inr (inl z))
branch 4: inr (inr (inr (inl z)))
branch 5: inr (inr (inr (inr z))).
```

Within a component, `z=(a,(b,j))`; it is not `(a,b),j` or a differently associated product. The actual Mathlib `finProdFinEquiv` maps `(u,v)` to `v + size(v)*u`, with inverse quotient/remainder. Thus `componentEquiv h` maps to

```text
j + (h+1)*b + 3*(h+1)*a,
size H_h = 9*(h+1).
```

The actual `finSumFinEquiv` maps the left injection without offset and the right injection with the full left size added. Consequently `fullEquiv` concatenates branches in exactly the order 1,2,3,4,5, with sizes

```text
L1=9, L2=9*(d+1), L3=9*(2*k+2), L4=9, L5=9*(d+1),
offsets = 0, L1, L1+L2, L1+L2+L3, L1+L2+L3+L4.
```

`assemblySize = L1+(L2+(L3+(L4+L5))) = 18*(d+1)+9*(2*k+2)+18`. This is a cardinality identity, not an algorithm-runtime theorem. A flattened source address `u : Fin assemblySize` is decoded by the SAME `fullEquiv.symm` for left boundary, right boundary, and both kernel indices. Re-association casts and component-dependent Fin types must preserve the actual numerical address, not merely supply another bijection.

For stored core columns, the independent physical-bit/right-bond flattening is `finProdFinEquiv (bit,v) = v + assemblySize*bit.val`. Hence the first D columns are bit 0 and the next D are bit 1. Confusing that with interleaved `2*v+bit` or with component flattening is a separate error.

## 4. Polynomial kernel, left features and all five branches

For source monomial index j and destination monomial index ell, the literal translation entry is

```text
P_h(w,j,ell) = (Nat.choose ell j : Rat)*w^(ell-j).
```

The subtraction is natural truncated subtraction. If `ell<j`, the binomial is zero even though the exponent is 0; deleting the binomial/zero guard in that branch would incorrectly produce 1. When w=0, diagonal entries are 1 (including `0^0=1`) and all off-diagonal entries vanish: this is the identity, not the zero matrix. This includes bit 0, step zero and h=0. Row features are `origin^j`, including the degree-zero feature 1.

For a pair in the same branch, source `(a,(b,j))` and destination `(a',(b',ell))`, let `U` and `V` be the two cuts from the following table. Then the EXACT rational block kernel and left boundary are

```text
K(q,bit,z,z') = C(U,q,bit,a,a') * (C(V,q,bit,b,b') * P_h(step*2^q*bit.val,j,ell)),
left(z)      = E(a) * (E(b) * origin^j).
```

The multiplication parentheses follow the original nested product. For a pair in DIFFERENT branches, K is exactly 0, for all 20 directed cross-branch cases; no comparator/polynomial term connects summands. The right boundary in a branch is exactly `Qflip(W,U,a,flipA) * (Qflip(W,V,b,flipB) * coefficient[j])`.

| branch | original product | h | origin | step | U, V | flipA, flipB | coefficient[j] |
|---|---|---|---|---|---|---|---|
| 1 | A * (C * constant) | 0 | 0 | 0 | cA, cC | false, false | clippedValue delta |
| 2 | A * (Cc * tail) | d | -R | sigma | cA, cC | false, true | 1/j! |
| 3 | Ac * (B * middle) | m | -R | sigma | cA, cB | true, false | middleCoeffQ k delta j |
| 4 | Bc * (D * constant) | 0 | 0 | 0 | cB, cT | true, true | clippedValue delta |
| 5 | Bc * (Dc * reflected tail) | d | R | -sigma | cB, cT | true, false | 1/j! |

Here A=[p<-1], B=[p<=0], C=[p<=-T], while D denotes [T<=p], the complement of the STRICT cut cT. `Dc` is [p<T]. Thus equality at -1 and 0 belongs to the middle, equality at -T belongs to the clipped negative branch when the outer A mask permits it, and equality at +T belongs to the clipped positive branch when Bc permits it. There is no requirement that T>1 to define the product. Overlapping threshold locations at T=0 or 1 are handled by the two masks, not by changing the branch layout.

All left values are zero if `a!=1` or `b!=1`. Within branches 2/3 they are `(-R)^j`; within branch 5 they are `R^j`; within branches 1/4 the only monomial index is 0 and the feature is 1. At R=0, j=0 still has feature 1 while positive j features vanish. Left is not an all-ones vector or a right-boundary acceptance vector.

All same-branch kernel zeros also follow explicitly: a mismatched comparator destination gives zero; `ell<j` gives zero; w=0 gives only monomial diagonal entries. Otherwise negative rational w is permitted and its power sign is retained. The reflected tail carries its signs through origin R and negative step; its right coefficients are NOT alternated. Moving signs to a different boundary may preserve some full amplitudes but is not the literal entry/left refinement required here.

### Coefficients and source function, without an evaluation oracle

The original formulas are

```text
a_i = sum_(r=0..i) choose(k+i-r,k)/r!   (0<=i<=k),
e = expMidpoint delta,
middleCoeff(j) = sum_(i=0..k) [k+1<=j] e*a_i*(-1)^(k+1)*choose(i,j-(k+1))
               + sum_(i=0..k) [i<=j] a_i*(-1)^i*choose(k+1,j-i).
```

The two PRIMARY guards are necessary before natural subtraction; out-of-range binomial-zero checks are SECONDARY. At k=0, the source cache is `(1)` and the middle monomial vector is `(1,1-e)`, a useful symbolic orientation/sign check, not an executed test.

From `FiniteExp`, T=`Nat.clog 2 (max 1 (Nat.ceil (1/delta)))`, d=`4*T^2+2*T+1`, clipped=`1/2^T/2`, and `e=(bounds(-1,T,d).1+bounds(-1,T,d).2)/2`. Thus e is clipped when T<=1, otherwise it is the exact finite polynomial at -1 after the symmetric radius terms cancel. These are finite rational definitions even for nonpositive delta; no approximation interpretation is obtained for those inputs. At T=0, d=1, clipped=e=1/2; the summands and all cuts remain present.

For R>0, the full amplitude is the original five-mask expression

```text
A*C*clipped + A*(1-C)*poly(p,d) + (1-A)*B*middleValue(p)
  + (1-B)*D*clipped + (1-B)*(1-D)*poly(-p,d).
```

This is the literal piecewise source: p<-1 uses the negative midpoint; otherwise p<=0 uses the middle; otherwise the negative midpoint at -p. Source equality needs R>0, but entrywise rational-to-real cast, table-window refinement and same-returned-data assembly need no such positivity premise. Approximation/error-budget hypotheses remain separate; none is supplied by this reconstruction.

## 5. A legitimate explicit generation route

This is a source-derived route/interface list, NOT a review of an unreleased implementation or a proof/cost certificate.

1. Compute and store the four exact cuts and scalar/coefficient setup once. The old `rightSetup` exposes those cuts, tail coefficient vector, clipped and midpoint values. Its exact returned setup fields, including dependent degree transport, are the correct interface to reuse; capturing an `actualBlocksQ` object is not an algorithm for its fields.
2. Generate factorial values with the actual C23 `factorials`, using a bound covering the needed polynomial degrees. `chooseFrom F ell j` is legitimate only with `j<=ell`, `ell<=Nfact`, and factorial correctness supplied INTERNALLY by the returned factorial table. Its three actual reads, multiply and divide cannot be replaced by an uncharged `Nat.choose` callback. When ell<j, return zero under an explicit branch instead of using invalid factorial indices. A cache need not be regenerated per entry; actual storage/read sharing must be evident in the producer.
3. At each actual q, form/store rational stage weights and powers with a multiplication recurrence (`powQ` is an available old primitive). Generate both positive and reflected translations, or derive their entries with the exact negative weight. A direct literal polynomial formula hidden inside `pure` would leave scalar evaluation unaccounted. An iterative doubling schedule is a possible explicit route, not a claim that a new producer uses it or has any numerical budget.
4. Generate comparison entries from the literal finish tests, optionally materializing the four 3x3 local matrices per stage/bit and reading them thereafter. Old `generatedEntry` demonstrates charged tests and separately records natural quotient/remainder calls; it does not make these native operations constant-time. `acceptRun` is the old right-boundary endpoint/flip primitive; it is not a replacement for kernel generation.
5. Generate left powers at the actual origins (0/-R/R), with exponent-zero case 1, and multiply by the two equal-state indicators. Generate five same-branch kernels with the nested products above; explicitly branch to zero across summands. Reuse of stored primitives is legitimate only when their actual reads, arithmetic and output materialization remain in the run being certified.
6. Generate right entries from the same returned setup/middle data. Old `produceSourceCache` internally generates factorial correctness and returns actual source coefficients. Old `middleFromCache` consumes that actual cache, builds the two signed weighted vectors, preserves primary and secondary guards, and returns the full `2*k+2` vector. Old `rightEntry` already matches the five right branches, using actual reads for tail/middle and pure clipped projections. These are meaningful reusable interfaces, not a license to assume an arbitrary coefficient/cost oracle.
7. Collect the complete rational tables and both boundaries using the SAME `fullEquiv`. The source C22 shape is `Vector (Vector (Vector Rat (2*D)) D) (n+1)`, plus two `Vector Rat D` boundaries. Cast those same returned tables/boundaries and call stored `ofTable` on those same values. The kernel callback belongs in the finite-window SPECIFICATION, not in a second producer called only to establish the desired theorem.

The needed downstream obligations are: all kernel entries equal `actualEntryQ`; all left and right entries equal the original boundaries under the same decoder; cast entries preserve them; the actual returned tables satisfy `Window ... K 0`; then canonical `ofTable_refines` applies to the SAME stored data. An amplitude-only equivalence is weaker than these entry/left obligations and does not by itself certify the actual returned core tables. No fresh correctness premise should be added publicly when the data producer can establish it internally.

## 6. Endpoint n=0 and cost boundary

`n=0` means W=1, two physical words with p=-R and p=0; there is one table at stage q=0. Canonical `tailChain` first contracts that sole kernel with right, then `closeLeft` contracts the same terminal core with left. The scalar amplitude for emitted bit b is `sum_a left[a]*(sum_v K(0,b,a,v)*right[v])`. Both boundary absorptions are necessary on that one core; there is no empty-chain shortcut and no phantom stage 1. The stored implementation likewise performs terminal then initial on the sole returned table. This endpoint is not evidence of the cost for positive n, nor is the staged D-by-2D table identical in size to the final 1-by-2 closed core.

Original C22 `produceQData` explicitly puts scalar callback evaluation inside `pure`: its ledger counts container materialization, NOT the source scalar work. Capturing the block once does not cure that omission. `Run.pure` assigns zero cost to any supplied value; it is not an O(1) evaluation theorem. `Run.bind` adds costs of the actual selected continuation; `charge` contributes its named tick; `read` reads stored words; `collect` materializes counted results and records its read/write passes. Costs do not certify uncounted arithmetic merely because values are well-defined.

C23 factorial/choose and old C150 arithmetic make useful rational-field/read/write refinements, with explicit omissions. Natural powers/division/remainders, floor/ceil/clog, conversions, dependent-index proofs, branch/address arithmetic, metadata, bitlength, rational normalization/GCD, native allocation/sharing and actual evaluator work remain separate. Stored canonical assembly counts its selected exact-real operations and table/reference traffic; that is not a finite-bit or physical gate budget. A generic scalar-address envelope such as `2*(n+1)*D^2` is a storage bound, not the scalar producer's runtime. No parent budget, claimed new constant, compiler success, or measured efficiency is adopted as truth here.

## 7. Frozen comparison checklist and handoff

The most plausible hazards are: wrong nested injection order; using the wrong full decoder for one boundary; interleaving bit columns; reversed comparator row/column or MSB staging; treating a flipped mask as a changed kernel; dropping empty/full dispatch; confusing strict and inclusive cuts at -1/0/±T; replacing a natural-subtraction guard by only a choose-zero guard; transposing choose(ell,j); making 0^0 zero; deleting origin powers; moving reflected signs to right coefficients; losing a costed cache read; charging materialization while hiding field evaluation in `pure`; and failing to absorb both boundaries at n=0. These are testable comparison obligations, not asserted defects in unseen C243.

Objective/frontier delta: a raw-source-derived, index-explicit semantic baseline and legitimate generation interface for the upcoming producer comparison. Named evidence: bound original definition bodies only; no new Lean or test receipt. Assumptions: Nat parameters, Rat R/delta; R>0 only for the source-grid mask interpretation; no new model/cost oracle. Files changed: only the three files in this new packet. Reusable insight: branch flips live in right boundaries, while reflected polynomial signs live in kernel/left, so checking amplitude alone can miss literal producer mismatches. Failure class: NONE identified in the scoped original algebra; unreleased producer not assessed. Salvage: no rejected mathematical route, one corrected source-path lookup retained in pins. Process memory: retained required protocols; no new review/catalog retrieval. Direction fingerprint: original-source entrywise construction before candidate exposure. Parallel audit: no subagents; prior exposure disclosed rather than universal-decoder credit. Default route: exact table/window/cast/same-data assembly, with no arbitrary semantic callback. Purification: not integrated, not PURIFIED, no Exposition Seal. Residual risks: no fresh compilation, no complete trust/import audit, original-byte provenance is current raw snapshot not Git-history attestation, no native/finite-bit/quantum-resource certificate. Next action: parent whole-read/hash-check this immutable packet, then separately authorize comparison with the candidate. STOP before C243 release.
