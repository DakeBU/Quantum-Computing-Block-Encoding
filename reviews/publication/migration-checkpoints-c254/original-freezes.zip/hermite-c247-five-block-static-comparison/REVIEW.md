# C247: static comparison with the frozen C245 source baseline

Classification: INTERNAL STATIC SEMANTIC / SELECTED-LEDGER REVIEW. I found no concrete literal kernel/left/right/layout mismatch in the inspected C243 bodies. This is a bounded static finding, not Lean acceptance, a full budget proof, runtime association, clean-TCB certification, SourceAnchor, scientific ROOT or PURIFIED admission.

## 1. Exact release and evidence boundary

C245 was frozen first at seal `65b222b7f2ae4d437a4a13619a79ff7fc530023abebfdfe8809cab60b2d1f9f2`. Its two payloads and all 31 original raw inputs were independently rehashed unchanged in C247. I then read exactly the released C243 `ExplicitFiveBlockDefinitions.lean` (243 lines, SHA256 `f046398535745a6db50b5202b421bed5c9f3b2a600c9cabc875855ee1f1f08f3`), `IntendedRootTypeChecks.lean`, `input-manifest.json` and `DEFINITIONS_FREEZE_SEAL.json` (SHA256 `db28021bf8d7ff8b326decc411a6720b28f078cb1d2474872006826c94ebe2a1`). All three permitted C243 payload hashes agree with that seal. Its `BODY_AND_FRONTIER.md` binding was observed only as a hash; that file was not opened.

The permitted metadata contains author explanations, a proposed budget and C237 lineage/hashes. Those were exposed as metadata, not accepted as evidence. C237 files themselves, parent numerical verdicts, actual new compiler/runtime outputs and other reviews were not opened. C243's author claim of an old pin typo and a parent Git comparison was not independently verified against C237/Git. The actual original UniformTranslation raw hash remains bound by the independently retained C245 input record.

I retain the prior Hermite static/runtime exposure, same-chain reviews and separate Gaussian author/governance work disclosed in C245. This is not fresh universal decoder independence. No earlier frozen packet was edited. The repository worker skill's source/binder/evidence-layer discipline governs this review; no new proof search or compilation was performed. Full input hashes/read extents and exposure chronology are in `INPUT_MANIFEST.json`.

## 2. Carrier, address decoder and transport

`FiveIndex d m` and `fiveSize d m` (lines 31-38) reproduce the same right-associated five-sum structure as C245, with widths `0,d,m,0,d`. Specializing `d=sourceDegree delta`, `m=2*k+1` gives the original FullIndex and assemblySize without a new cardinality/model convention.

`splitIndex` (41-43) tests the exact left size, preserving an inl address and subtracting that size on inr. Its four nested uses (54-70) therefore recover the same branch offsets `0,L1,L1+L2,L1+L2+L3,L1+L2+L3+L4` derived before exposure. No branch is permuted or reassociated numerically. `unpackComponent` first decodes the outer product with second size `3*(r+1)`, then the inner product with second size `r+1`. It therefore recovers `(a,(b,j))` from `j+(r+1)*b+3*(r+1)*a`, exactly the inverse componentEquiv order confirmed from actual Mathlib bodies. Denominators are positive for every Nat r.

`kernelEntry` (128-139) separately decodes its stored column as `Fin 2 × Fin D`: physical bit is the quotient block and right-bond address the remainder, i.e. column `v+D*bit`. It decodes source and destination with the same degree-parameterized decoder, passes `q.val` unchanged, and never reverses row/column or substitutes a remaining-length stage. `leftEntry` and new `rightEntry` use that same decoder.

The top-level degree is obtained from an actual SECOND `cutoffQ delta` result, not by executing sourceDegree inside each decoder. `hd`, the two L bounds, and `hsize` are index/carrier proofs. The right helper transports its decoded FiveIndex using hd; the final rational record is transported using hsize. These transports must preserve coordinates in the eventual Lean proof, but do not introduce a new mathematical oracle or permutation. At the root, L=`d+2*k+1` covers the two varying component degrees and degree 0. There are six local typing-proof sites, not value/cost theorem declarations.

## 3. Comparison, translation, signs and all component cases

`comparisonQ` (73-79) is the literal old finish algorithm: digit `(cut/2^q)%2`, less test, greater test, old-state retention on equality, then destination equality. Its value is rational 0/1 with the original source/destination orientation. Both comparisons are evaluated and charged, as in the original generated-entry body. No complementary-mask operation is inserted into the kernel.

`translationQ` (83-96) guards `i<=j` BEFORE factorial access. In the legal branch, the actual three factorial reads compute `choose(j,i)`; the actual powQ calls give `2^q` and then `w^(j-i)` with `w=(step*2^q)*bitValue`. For `bit : Fin 2`, the charged selection `if bit=1 then 1 else 0` equals its natural value cast to Rat, without an uncharged general Nat-to-Rat scalar conversion. The three rational multiplications and the choose quotient are all retained. In the illegal branch the result is exactly zero; no invalid factorial index is formed. This matches the source's binomial-zero case despite truncated subtraction. If w=0, the exponent-zero recurrence returns 1; diagonal entries are not lost, including degree 0 and bit 0.

An important scope qualification: for ARBITRARY input F, this helper does not assert or guarantee a binomial value. Symbolically, `L=r=q=0`, F=(0), i=j=0 gives 0 rather than the literal translation entry 1, because source rational `0/0=0`. This is not a counterexample to a stated C243 root: its intended translation proposition supplies `(factorials L).value.values`, and the actual top-level producer generates F itself. Factorial correctness is a required internal dependency, not a new public assumption. Likewise arbitrary minusR/minusStep/setup/middle helper parameters do not guarantee literal source values until their actual top-level construction is used.

`componentKernel` (98-106) computes the two comparisons and translation, then multiplies `first*(second*scalar)` in the original nested product order. It does not short-circuit scalar generation when a comparator value is zero; that actual work remains charged. The five `kernelAt` branches and `leftAt` origins compare as follows:

| branch | degree | cut pair | kernel step | left origin | result against C245 |
|---|---|---|---|---|---|
| 1 | 0 | minusOne, minusT | 0 | 0 | same constant component |
| 2 | d | minusOne, minusT | step | minusR | same negative tail |
| 3 | m | minusOne, zero | step | minusR | same middle |
| 4 | 0 | zero, T | 0 | 0 | same constant component |
| 5 | d | zero, T | minusStep | R | same reflected tail |

All 20 directed different-tag cases use the wildcard zero branch. Same-tag comparator destination mismatch or monomial i>j still gives zero. `componentLeft` (141-146) computes exactly `[a=1]*([b=1]*origin^j)` with both equal-state comparisons and actual powQ. Thus unequal comparator states give zero; origin=0 keeps j=0 equal to 1. The reflected signs remain in origin R and negative step, not in right coefficients or changed comparator kernels.

The new right helper (166-173) calls the ACTUAL old C150 `rightEntry`, not an old semantic callback. The decoded index is transported to the original FullIndex. Consequently the original five right products, endpoint dispatch, flips `(false,false),(false,true),(true,false),(true,true),(true,false)`, actual tail/middle reads and pure clipped projections remain the same. Empty/full/interior cuts, strict/inclusive boundary conventions, and T=0/1 are inherited from the same actual setup/right bodies, rather than reinterpreted in C243. No additional R/delta positivity assumption is needed for literal data equality.

## 4. Actual returned data and charged prefix

The top level (198-220) really uses C23 cache -> C150 setup -> middleFromCache on that returned midpoint/cache. Unlike the old CachedStoredProducer, it does not capture actualBlocksQ to evaluate its kernel or left boundary in pure. A source scan confirms no actualBlocksQ/actualEntryQ/actualLeftQ/actualRightQ or Nat.choose call in the C243 definitions body. The original callbacks appear only in external specification objects, not this numerical production.

The regeneration is visible and costed: another cutoffQ, another gridStepRun, qSub(0,R), qSub(0,step), and another factorial table of size L. This is not a claim that previous private setup/factorial work was reusable for free. C23 cache, C150 setup and middle costs are explicitly added, as is the second cutoff cost and the whole subsequent result cost. The four factorial passes are those inside source cache, right setup, middleFromCache, and new factorials L; none is silently deleted by a cost-free assumption.

`indexedBind` (24-29) passes the selected run's actual value to its continuation and adds the two returned scalar ledgers and selected counters. `materializePrepared` (177-194) actually materializes every table entry, left value and right value using canonical collectIndexed. Its sum of stored run costs and counters is the same record construction that supplies the returned tables/boundaries; a second specification producer does not supply the result. collectIndexed's actual body is one Vector.ofFn of IndexedRun records, followed by value and metadata projection. This establishes the declared abstract record-level dataflow, not native allocation/evaluator sharing or a measured single evaluation of captured host computations.

The comparison target is WHOLE RationalData VALUE equality with the old `produceCachedQData`. That is a meaningful strong value target: tables, left and right must all match. It does not claim old/new Run cost equality (the old kernel/left costs were deliberately incomplete), nor does it make the old producer execute inside the new one.

`produceExplicitData` passes that exact returned rational data to the original castData; `produceExplicitStored` passes that exact returned RealData to canonical ofTable (222-230). No alternative tables or boundary callbacks are used for the stored output. Given the entry/left/right equality proofs still to be supplied, the C245 finite Window and same-data refinement route is the appropriate one.

At n=0 the materializer has one q=0 table and two stored physical-bit column blocks. These are still passed to the unchanged stored terminal-then-initial closure, so both boundaries are absorbed into the sole physical core. There is no empty-chain shortcut, no extra q=1 table and no special endpoint source redefinition. At R=0 or negative R the exact rational data remains defined just as in C245; only the physical source-grid interpretation retains the original `R>0` premise.

## 5. Independent local ledger reconstruction and limits

These are static arithmetic deductions from the actual bodies, NOT executed Lean cost receipts or acceptance of frontierBudget. Write e=`j-i` for a legal monomial pair. For helpers before outer collect materialization, all unlisted operation channels are zero:

| local operation | field ticks | compare ticks | read ticks | selected quotient and remainder, each |
|---|---|---|---|---|
| decode | 0 | 4 | 0 | 2 |
| comparisonQ | 0 | 3 | 0 | 1 |
| translationQ, i<=j | q+e+5 | 2 | 3 | 0 |
| translationQ, i>j | 0 | 1 | 0 | 0 |
| full kernelEntry, same component and i<=j | q+e+7 | 24 | 3 | 7 |
| full kernelEntry, same component and i>j | 2 | 23 | 0 | 7 |
| full kernelEntry, different component | 0 | 16 | 0 | 5 |
| full leftEntry, monomial j | j+2 | 10 | 0 | 2 |

For example, the legal translation uses chooseFrom's 3 reads and 2 fields, q dyadic multiplications, 2 fields for stage scaling, e power multiplications, and 1 final multiply: q+e+5 fields. Full kernelEntry adds two nested field multiplications, both decoders, two comparison producers and the reserved paired tag dispatch. Degree-zero components still execute their legal translation work, including the dyadic recurrence, even though the resulting polynomial scalar is 1. RightEntry retains its exact old Run cost, plus 8 compare ticks from decode and reserved dispatch, and two selected quotients/remainders; it does not erase arbitrary coefficient-read cost.

The legal kernel local total is q+e+34, hence the proposed per-entry shape n+L+34 is consistent with these new local bodies since q<=n and e<=L. Seven selected calls per kernel entry and two per boundary entry likewise explain the proposed selected-counter shape. This is LOCAL support only: the complete frontierBudget still requires exact prefix/setup/middle/factorial/container/cast/ofTable composition proofs. No coefficient such as 816/81/80, no complete polynomial B, and no accepted cost theorem is certified by this review. The numbers were present in released metadata/source as proposals, not parent evidence.

The four/ eight dispatch ticks are conservative abstract reservations, not a compiler-instruction count. Selected quotient/remainder counters cover product decoding and literal comparison digit extraction; they do NOT cover every division inside natural ceil/floor/clog, Rat normalization, hidden library arithmetic or all runtime control. liftRun zeroes ONLY those selected counters, not the inherited Run cost; thus rational setup and canonical assembly costs remain in the scalar ledger while their native internals are not suddenly certified.

Remaining omitted or inherited boundaries: natural index arithmetic/powers/degree construction and proofs, casts of T to Rat in old setup, ceil/floor/clog/conversions, rational numerator/denominator growth and GCD, proof checking/metadata, physical allocation/copy/sharing and evaluator behavior, rational-to-real realization, exact-real-to-finite-bit refinement, gates/synthesis/phase/cleanup, normalization/postselection/amplification, export and full SP/BE ROOT. No source/compiled-sharing observation is available here, and even one would not certify zero captured/setup work.

## 6. Intended propositions and remaining obligations

The released checks request eight Prop formations: exact specialized decoder; comparison value; translation value with ACTUAL generated factorials; whole QData value equality; Window; same stored-chain refinement; physical source action with original R>0 only; and same-result scalar/counter bounds. They do not prove any of them, and merely finding eight #check expressions is not actual type formation. There are no added public cost/correctness/cache/oracle premises in those proposed roots. Internal Fin/degree bounds and hd are type-index obligations, not scientific assumptions.

No concrete mismatch was identified to force a target/model change. The next exact obligations are nevertheless real: establish decoder equality including Fin transports; factorial-based translation equality on all triangular/zero cases; all five kernel and left/right entries; Vector-extensional whole-data equality through final hsize transport; then actual Window/refines/source composition; separately prove the full same-run ledger/counter theorem. Actual Lean formation, imported definitions/output binding and axiom audit remain future gates. A definitions freeze is not a StatementSeal or a proof result, and an implementation failure would require a separate preserved successor, not an edit to C243 or C245.

## 7. Skill handoff and stop

Objective/frontier: compare one explicit kernel/left scalar supplier to the independent C245 source baseline. Mathematical delta: exact body-level semantic alignment and branch-sensitive local ledger derivation; no fresh theorem/compile receipt. Root effect: supports pursuing the intended literal producer proof while keeping full resource/scientific tails open. Assumptions: unchanged Nat/Rat construction; generated factorial correctness internally required; R>0 only for original physical source action. Files changed: new C247 REVIEW, input manifest and static seal only. Reusable insight: generic F/minusStep/setup helpers are not unconditional source objects; actual root generation closes those dependencies without adding public oracles. Failure class: NONE concrete in this static comparison; formal and runtime gates PENDING. Salvage: all prior freezes and candidate bytes preserved, no rejected source route. Process memory: retained required protocols/own C245 only; no new review/catalog retrieval. Direction fingerprint: frozen-original entrywise comparison, not author-rationale or runtime-success reconstruction. Parallel/common-blind-spot audit: no delegation; prior context disclosed. Default route: exact same returned data -> cast -> Window -> ofTable, with independent same-run ledger proof. Purification/Exposition: not integrated or admitted. Residual confidence: body algebra and index orientation appear aligned; Lean typing/transport/proof and whole-budget composition remain untested. Recommended action: parent whole-read/hash check, then separately authorize its desired next gate; do not infer runtime acceptance from this packet. STOP before runtime association.
