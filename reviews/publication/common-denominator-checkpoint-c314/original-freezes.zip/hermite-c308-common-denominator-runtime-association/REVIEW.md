# C308: recorded CommonDenominator runtime association

INTERNAL_RECORDED_RUNTIME_ASSOCIATION, after immutable C299 and C302.
This is record inspection, NOT an independent compiler rerun, universal decoder,
clean TCB, SourceAnchor, publication/ProofSeal or scientific ROOT review.
Prior distinct Hermite/height static/runtime and C206/C230/C276 author roles
remain disclosed. C293 DERIVATION/manifest and other current workers stay unread.

## Exact source, output and consumer association

The actual C296 proof (2372 bytes, f8a7af...) and checks (829 bytes, c3fde8...)
equal C293 author files and C302 pins. C293 freeze/C280 seal bindings match.
Current proof own output is 60944 bytes, 15c8671c...; consumer own output is
14792 bytes, 3d2c280f.... Both equal actual result-record hashes.
Complete raw consumer --deps lists Init twice, then this C296 proof output;
it does not select an older CommonDenominatorProof. No concrete source,
own-output, expanded-type or ordinary-axiom mismatch was found.

Raw consumer stdout prints the sealed CommonDenominatorSpec root and the
expanded forall q:Rat,Q M:Nat: Q>0 -> den|Q -> |q|<=M -> the SAME four
clauses (Q>0, SAME signed common-witness value=q, raw natAbs<=M*Q, canonical
height<=max1(max(size(M*Q),size Q))). C302's signed/zero/local-premise and
strictness comparison therefore matches the recorded expanded consumer.
This is a typed expanded consumer, NOT a printed-body/definition audit.

Exactly two raw axiom rows name commonDenominator and its expanded consumer;
both list propext, Classical.choice, Quot.sound only. No sorryAx/custom axiom
is present in those actual rows. Source-module stdout/stderr are empty and
its feedback is one newline: zero SOURCE axiom rows are not an empty-axiom
proof. Consumer prints provide the relevant root evidence. Its defProp warning
is retained; the suggested linter-disable text is diagnostic, not applied.

## Complete direct dependencies and inherited providers

Proof --deps has five lines: Init twice; C285 HeightBoundProof; Mathlib
Nat.Cast.Order.Ring; GroupWithZero.Basic. Consumer has three lines as above.
All eight ordered lines, sizes and current hashes are bound in the manifest.
HeightBound output bbc094... and Definitions output a0a6a6... match the plan;
current C278 Definitions source equals sealed C269 source. Definitions is
INHERITED through HeightBound, not a direct C296 --deps line or newly printed body.
C285 source and current MinMax source/output are hash-bound only here; prior
height association is inherited, not reconstructed as a fresh proof/TCB.
The two direct Mathlib pins were sampled at wrapper start, not clean-build seals.

Important lexical-path limit: all four printed Init lines are outside the
recorded prefix.stdout root. Their current 5784-byte hash 26523a3a... equals
prefix-relative Init. No alias/identity mechanism or historical loader trace
was established. Executable hash dd86e9... matches the plan; this alone does
not establish all Init/Lean/native/Mathlib binaries' clean source provenance.
Requested LEAN_PATH contains duplicate/inherited cache and build directories.
The recorded direct lists narrow selection, not the effective transitive loader.

## Wrapper and raw-record limits

All ten private ZIP members were read WHOLE in memory, not extracted/copied.
Raw stream hashes match result records; exact sanitized feedback reconstruction
matches both feedback files, including the final newline and warning.
Wrapper pins sources/seals/providers before/after and requests own-output paths.
It requires expected --deps MEMBERSHIP, not exact-set equality/loader closure.
Its consumer gate requires exactly the two named ordinary axiom rows. The parser
normalizes optional universes and rejects malformed lists; ordinary_only rejects
unknown names. Neither is executed here.
Source's vacuous all(rows) is complemented by the nonempty consumer gate.

Reported exits 0/0, no timeouts, 13.172/12.188 seconds and memory readings are
HISTORICAL wrapper records, not independently observed process status/timing.
No raw exit-status sidecar, atomic race-proof trace or output authentication
exists beyond these retained associations. Wrapper also reads forbidden author
manifest/prose pins and an inherited transport helper; their contents/implementation
were not independently inspected here. Success JSON does not certify itself.
Legacy “first height” schema/docstring labels do not alter actual root/type.

## Freeze and residual scope

Only NEW C308 files written via apply_patch; read-only PowerShell/.NET hash/ZIP.
One hash-command syntax failure and two unmapped-Init diagnostic failures are
preserved in the manifest/tool history; no files changed in those attempts.
No compiler/lake/Python/project script/Git/network/subagents/new proof search.
C299/C302 originals unchanged. qbe-substantive-worker evidence separation applies.
This is only the local representation bridge, not an actual producer supplying
polynomial-sized Q/M, canonical/unreduced family bit bounds, native GCD/allocation/
CPU, quantum/phase/error/full SPBE/ROOT/PURIFIED or source-publication credit.
Parent whole-read/hashcheck next. Frozen; STOP, no new exposure self-release.
