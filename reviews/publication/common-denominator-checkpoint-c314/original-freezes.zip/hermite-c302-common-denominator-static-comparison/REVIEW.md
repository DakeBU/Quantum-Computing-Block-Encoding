# C302: CommonDenominator, independent static author comparison

INTERNAL STATIC COMPARISON after immutable C299 source-first baseline.
Only C293 proof, ExactChecks and AUTHOR_FREEZE were newly released. No C293
DERIVATION/manifest or C296 runtime/result/feedback/archive was opened. Earlier
height/Hermite runtime and C206/C230/C276 author exposures remain disclosed;
not a universal decoder, clean-TCB/source-publication or wholeproducer review.

## Contract and actual proof dataflow

C293 declares exactly `commonDenominator : CommonDenominatorSpec`. After
unfolding, its binders are q:Rat,Q M:Nat,hQ:0<Q,hdiv:q.den|Q,hmag:|q|<=M.
These are EXACT C299's three local conditions; no sign/q!=0/M>0, reduced-witness,
height-correctness or new producer premise is added. There is one public root,
no private top-level helper, producer replacement, new axiom or sorry/admit.

`hdQ` derives den<=Q using positive Q and divisibility. `hquot` retains actual
NAT division: (Q/den)*den=Q. `hdRat/hQRat` cast existing positive denominators,
not new assumptions. `habs/hnRat/hn` use Rat.abs_def and positive-denominator
cross multiplication, then reflect the rational inequality to Nat:
num.natAbs<=M*den. `hnQ` composes den<=Q to num.natAbs<=M*Q.

`hcross` proves the actual SIGNED raw numerator, cast to Rat, equals q*Q.
Rat.mul_den_eq_num rewrites num=q*den; associativity, commutation, faithful
Nat/Int/Rat casts and hquot give the equation without cancelling q or num.
`hvalue` divides only by Q, justified by hQRat.ne'. This is a valid equivalent
route to C299's nonzero-t cancellation, including q=0 and negative q.
`hraw` uses natAbs of the SAME Int product, casts its nonnegative quotient to
Nat magnitude, multiplies hn by Q/den and rewrites hquot. It bounds the actual
unreduced numerator, not the smaller canonical result of witnessValue.

`hh` uses existing heightBound with B=max1(max(size(M*Q),size Q)). Its first
condition is 1<=B; the other two come from size monotonicity on hnQ and hdQ,
then Nat.size_le.mp. Strict power caps remain strict before heightBound.mpr
returns the original NONSTRICT height bound. M=0 and q=0 are not dropped;
the proof never divides by M or assumes a sign for q.num.

C299's direct max-monotonicity conclusion did not REQUIRE heightBound; C293
chooses that additional theorem dependency. It is a closed theorem-interface
supplier, not a new public assumption or a primitive-normalization oracle.
It does not change the original commonWitness, Q, cap, quantifiers or target.
The final four-tuple is hQ,hvalue,hraw,hh, covering all four sealed conclusions.

## Expanded consumer, APIs and imports

ExactChecks assigns the root to a closed fully expanded forall q,Q,M with
the SAME three implications. Its positive denominator is Q, value numerator
is exactly q.num*((Q/q.den:Nat):Int), its raw natAbs bound is <=M*Q, and
canonical height is the same outer-max1 expression. No existential replacement,
weakening, extra binder or sign/zero exclusion appears. Two #check/two #print
commands are source only; no actual output or axiom set is inferred here.

Literal import graph: CommonDenominatorProof imports HeightBoundProof,
Mathlib.Data.Nat.Cast.Order.Ring and Mathlib.Algebra.Order.GroupWithZero.Basic;
ExactChecks imports CommonDenominatorProof. Raw primary sources confirm the
needed Rat.mul_den_eq_num, Nat.cast_pos/cast_le and div_le_iff₀ signatures and
relevant proofs, in addition to C299's raw abs/size APIs. These support the
mathematical argument, NOT a claim that all tactics/typeclasses elaborate.
Actual Definitions/HeightBoundProof/other olean selection, current own-output
consumption, --deps and compiled types/axioms remain uninspected for C296.

No concrete mathematical, binder, sign, zero or strictness mismatch was found.
No trust/linter/budget option, unsafe/native evaluation or new model occurs
in the released proof/consumer. API/compile status remains UNASSESSED; a later
implementation failure would not itself refute this fixed mathematical target.
Author freeze hashes match the two actual source files; its DERIVATION/manifest
hashes and zero-compilation fields were seen only as metadata/author assertions.

## Handoff and evidence cut

Only NEW C302 report/manifest/seal written via apply_patch; scoped read-only
PowerShell/rg/hash checks. No compiler/lake/scripts/Python/Git/network/subagents,
finite test, other new root/worker packet or runtime. No tooling failure.
C299 originals remain unchanged. Skill qbe-substantive-worker keeps theorem
dependencies distinct from public premises and scientific/native resources.
No Q/M actual-family polynomial bound, cache/suffix/Sites coverage, GCD/allocator/
CPU, wholeproducer/fullSPBE/ROOT/publication/PURIFIED credit follows. Failure
class NONE concrete static mismatch; runtime/import-TCB association pending.
Next: parent whole-read/hashcheck, then separately release actual runtime if
authorized. No self-release. Three-file allowlist in manifest. Freeze and STOP.
