# C299: CommonDenominatorSpec, independent source-first baseline

INTERNAL FOUNDATION-SPECIFIC SOURCE-FIRST STATIC REVIEW. Current author C293
proof/consumer/prose/manifest and C296 runtime were not opened. Earlier height
root and Hermite runtime exposures remain disclosed; not a universal decoder,
clean-TCB/source-publication, wholeproducer/native or scientific ROOT review.

## Literal contract and quantifiers

The C269 body listed by C280 is `commonDenominator : CommonDenominatorSpec`.
Its exact expansion, abbreviating a=q.num:Int and d=q.den:Nat, is:

```text
forall q:Rat, Q M:Nat,
  0<Q -> d divides Q -> |q| <= (M:Rat) ->
  let u:Int := a * ((Q/d : Nat):Int)
  0<Q AND (u:Rat)/(Q:Rat)=q AND u.natAbs<=M*Q AND
  max 1 (max (Nat.size a.natAbs) (Nat.size d)) <=
    max 1 (max (Nat.size (M*Q)) (Nat.size Q)).
```

This is the SPECIFIC returned commonWitness pair, not an existentially better
representation. The quotient Q/d is natural division before casting to Int;
it is not rational division or a silently exact integer cast without the dvd
condition. All conclusions use that SAME pair (u,Q) and original canonical q.
Q,M are universally quantified local mathematical witness parameters, not
chosen algorithm constants or added hypotheses of an existing producer root.

## Independent mathematical derivation

1. Canonical rational fields have d>0 and q=(a:Rat)/(d:Rat). With d|Q, let
   t=Q/d:Nat. Exact divisibility gives Q=d*t. Since Q>0 and d>0, t>0, hence
   t>=1 and d<=Q. No q sign/nonzero or M positivity is used here.
2. commonWitness is exactly (a*(t:Int),Q); its denominator is Q>0. Casting
   Q=d*t consistently to Rat and cancelling NONZERO t yields
   (a*t)/(Q)=a*t/(d*t)=a/d=q. Cancellation by zero would be invalid; Q>0
   supplies the needed t>0 rather than an extra hypothesis.
3. Since d>0, |q|=a.natAbs/d. Thus |q|<=M implies a.natAbs<=M*d as a NAT
   inequality, by positive-denominator cross multiplication and faithful
   Nat/Int/Rat casts. Signed a is handled by abs/natAbs, not by a>=0.
4. natAbs(a*(t:Int))=a.natAbs*t. Multiply the preceding bound by t>=0:
   u.natAbs<=M*d*t=M*Q. This bounds the actual UNREDUCED witness numerator,
   including a negative numerator; no gcd/normalization of (u,Q) is invoked.
5. Independently, d<=Q and a.natAbs<=M*d<=M*Q give size(d)<=size(Q) and
   size(a.natAbs)<=size(M*Q) using Nat.size_le_size. Two max monotonicity
   steps, with the unchanged outer1, yield exactly the canonical height cap.

The height step need not invoke primitiveRepresentation, a normalization-width
oracle, commonWitness being reduced, or even the previously reviewed heightBound
root. It follows directly from actual canonical fields and size monotonicity.
The four conclusion clauses are thus accounted for; no extra premise is needed.

## Boundary and premise discriminators

Zero q has a=0,d=1, so t=Q, witness=(0,Q), value0 and numerator cap0<=M*Q.
Its canonical height is1 and RHS>=1. M=0 forces q=0 from |q|<=0, so that
endpoint is included; the derivation never divides by M or assumes M>0.
Q=1 with d|Q forces d=1 and t=1; the same argument handles signed integers.
General negative q keeps the sign of a*t since t>0; bit heights count magnitude,
not an encoded sign bit or a two's-complement range. Q need not be minimal.

The local conditions are meaningful, not free correctness oracles. Without
divisibility, q=1/2,Q=3,M=1 gives witness=(1,3), NOT q. Without Q>0, q=1,
Q=0,M=1 satisfies d|Q but witness=(0,0), failing both positivity and value.
Without the magnitude bound, q=2,Q=1,M=1 violates numerator cap. These are
hand algebraic discriminators of weakened variants, not counterexamples to
the ACTUAL target and not executed finite tests. No mismatch found in target.

## Raw library support and precise evidence cut

Read raw Rat.pos/den_ne_zero and num_zero/den_zero/negation facts in Rat.Defs;
Rat.num_div_den in Algebra.Ring.Rat; Rat.abs_def and divInt_le_divInt in the
unbundled Rat order source; Rat.natCast_div in Rat.Lemmas (dvd premise explicit).
Int.abs_eq_natAbs/natCast_natAbs, Int.cast_abs/cast_le and Nat.size_le_size
support the cast/absolute-value/height steps. Full selected sources or bounded
complete relevant declarations were read; exact extents and hashes are in
INPUT_MANIFEST. Incidental neighboring declarations/search-only hits are not
promoted to audits. C280 prior type receipts were visible as metadata only.

The statement is a mathematical common-denominator/magnitude BRIDGE, not proof
that any actual cache/suffix has such Q or that Q,M have polynomial bit sizes.
Future producer consumers must establish dvd, Q positivity and magnitude from
their actual generated data; this theorem does not supply Sites coverage.
It does not count computation of Q/d or a*t, gcd/normalization temporaries,
allocator/native CPU, producer/physical sharing, or full finite-SPBE resources.
Other foundation predicates, scientific error/success/circuit/ROOT/publication
and PURIFIED status remain outside this baseline.

## Actions and handoff

Read-only scoped PowerShell/rg/source/hash checks; apply_patch only NEW C299.
No compiler/lake/Python/project script/Git/network/subagent/finite diagnostic.
Two guessed library paths did not exist; corrected permitted Int source was
read, and the natural quotient step was derived directly from divisibility.
One additional cast search had no matches; all failures/extents are retained.
Prior C288/C290/C291 reviews and C206/C230/C276 author roles are not erased.
Skill qbe-substantive-worker preserves local premise/dependency/evidence cuts.
Failure class NONE mathematical mismatch found; implementation unassessed.
Next: parent whole-read/hashcheck, then separately authorize author comparison.
No automatic C293/C296 exposure. Only this report, INPUT_MANIFEST and source-first
seal are public-allowlisted. Freeze and STOP with old packets unchanged.
