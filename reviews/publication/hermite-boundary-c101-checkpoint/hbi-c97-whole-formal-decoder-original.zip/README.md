# Fresh whole-module formal decoder

FROZEN_BEFORE_SOURCE_RELEASE

Decoder identity: hbi_fresh_whole_decoder_c97. Role: independent source-blind decoder, not formalizer or later source-first reviewer. Historical formalizer identity is unknown. No previous decoder, reviewer, natural-source packet, author audit or parent verdict was read.

The mathematical target is INPUT/QuantumBlockEncoding/HermiteBoundaryInjection.lean, formal snapshot SHA256 `cf4fcd8e410b4c103e8e45a569e878404de64e1f2d3775dad0a99004990627f1`, 55086 bytes. The inventory that authorizes inputs is INPUT/formal-inputs.json, SHA256 `faf40d53126c173a94965a5499589104d6648766918d75abdf2561cbc9393de8`. All 33 enumerated file hashes and byte counts were checked against their formal_snapshot_sha256 values. The target's production/raw hash refers to a different, unread object and is not substituted for this snapshot binding.

Read OUTPUT/reconstruction.md for the mathematical account of the entire module, OUTPUT/binders-and-context.md for assumptions and context, OUTPUT/declarations.json for the exact ordered source inventory, and OUTPUT/providers.json for the bounded imported semantic suppliers. OUTPUT/input-pins.json and OUTPUT/read-coverage.json record pins and chronology. Every public path uses INPUT/, OUTPUT/ or GOVERNANCE/ logical roots; no physical host mapping is published.

The declaration inventory partitions the complete target into prefix, ordered exact header/body pairs and suffix. Recomposition is byte-checked against the bound input, not merely counted by a declaration grep. Leading binder groups are parsed before the result colon; quantified subexpressions and conditional membership tests inside result types are not mislabeled as premises. Exact source text is retained for all target declarations, including the private helper and anonymous instances.

The only role of the governance material was process discipline. The substantive-worker skill required a bounded, explicit handoff and traceable assumptions; it did not supply mathematics. Instructions for production builds, repository synchronization, source comparison or publication were inapplicable to this decoder-only task, whose explicit boundary forbids compilation, Git, network and source release. No production files, inputs or existing evidence packets were changed.

This packet is not an accepted-review wrapper, a compiler certificate, a source-equivalence judgement, production admission or a final root-closure claim. Its mathematical assertions are readings of the formal text; compiler acceptance and imported axioms are not checked. Imported standard mathematical operations remain library boundaries. There is no genuinely missing project-owned semantic definition requiring a supplement for this reconstruction.

## Handoff

Objective: reconstruct the complete bound formal module before source release.

Mathematical delta: readable whole-module semantics, explicit local supplier roles, all 125 exact declaration regions, recursive expansion of the project-owned logical inputs, and exact formal-input binding.

Failure class: NONE for the decoding task, not a claim about correctness or source fidelity of the module. No route was refuted or retired. Salvage not applicable. No process-memory evidence or prior reviews were consulted. No subagents were spawned. Direction fingerprint: fresh-whole-module-formal-only-c97. Expected information gain: an independently reconstructed meaning and exact binder/context boundaries available for later anti-anchored comparison. Parallel-route comparator and common-blind-spot audit are outside this decoder's remit. Purification and Exposition-Seal admission are not claimed.

Residual risk: this is a lexical/manual source reconstruction, not an elaborated Lean environment audit. The snapshot transport is comment-masked and LF-normalized, not the raw production text. Genuine equation-compiler auxiliary declarations and universe generalization are not available from this text-only process. These boundaries are retained rather than filled with invented names or compiler facts.

Next permitted handoff: retain this immutable packet, then give it with the separately pinned natural source and formal context to a distinct source-first reviewer. This decoder stops before any such release or comparison.

## Integrity

OUTPUT/publicsafe-allowlist.json is the exact file allowlist. OUTPUT/manifest.sha256 lists every payload file except itself and OUTPUT/seal.json. OUTPUT/seal.json binds the exact manifest bytes by SHA256 and the frozen state. Thus neither manifest nor seal is hashed into itself, and the seal has no circular dependency. Scripts are reproducibility tools for text processing only; all created files were written with apply_patch. Re-running them is not a Lean execution or proof check.
