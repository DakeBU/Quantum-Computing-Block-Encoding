param([Parameter(Mandatory=$true)][string]$InputRoot,[switch]$EmitSealPatch)
$ErrorActionPreference='Stop'
$utf8=[System.Text.UTF8Encoding]::new($false)
function Sha([byte[]]$b){[Convert]::ToHexString([System.Security.Cryptography.SHA256]::HashData($b)).ToLower()}
function TextSha([string]$s){Sha $utf8.GetBytes($s)}
$outRoot=$PSScriptRoot
$read={param($n) [System.IO.File]::ReadAllText((Join-Path $outRoot $n))}
$allow=(& $read 'publicsafe-allowlist.json') | ConvertFrom-Json
$expected=@($allow.files | ForEach-Object {$_.Substring(7)} | Sort-Object)
$actual=@(Get-ChildItem -File -LiteralPath $outRoot | ForEach-Object Name | Sort-Object)
$expectedPresent=if($EmitSealPatch){@($expected | Where-Object {$_ -notin @('manifest.sha256','seal.json')})}else{$expected}
if(@(Compare-Object $expectedPresent $actual).Count -ne 0){throw 'Output file allowlist mismatch'}
foreach($n in $actual){
 $content=& $read $n
 $bad='(?i)[a-z]:[\\/](?![a-z]+\{)'+'|/'+'Users/'+'|/'+'home/'+'|file'+'://'
 if($content -match $bad){throw ('Host-path leakage in OUTPUT/'+$n)}
}
$invText=[System.IO.File]::ReadAllText((Join-Path $InputRoot 'formal-inputs.json'))
if((TextSha $invText) -ne 'faf40d53126c173a94965a5499589104d6648766918d75abdf2561cbc9393de8'){throw 'Inventory drift'}
$inv=$invText | ConvertFrom-Json
foreach($f in $inv.inputs){$b=[System.IO.File]::ReadAllBytes((Join-Path $InputRoot $f.path));if((Sha $b) -ne $f.formal_snapshot_sha256 -or $b.Length -ne $f.bytes){throw ('Input drift: INPUT/'+$f.path)}}
$d=(& $read 'declarations.json') | ConvertFrom-Json
$target=[System.IO.File]::ReadAllText((Join-Path $InputRoot 'QuantumBlockEncoding/HermiteBoundaryInjection.lean'))
$whole=[System.Text.StringBuilder]::new($d.prefix)
$position=$d.prefix.Length
$individual=0
foreach($r in $d.declarations){
 if($r.utf16_start -ne $position){throw 'Declaration gap'}
 $region=$r.header+$r.body
 if((TextSha $region) -ne $r.source_sha256){throw 'Declaration source digest mismatch'}
 if($target.Substring($r.utf16_start,$r.utf16_end_exclusive-$r.utf16_start) -cne $region){throw 'Exact source region mismatch'}
 if($utf8.GetByteCount($target.Substring(0,$r.utf16_start)) -ne $r.utf8_start){throw 'Byte start mismatch'}
 if($utf8.GetByteCount($target.Substring(0,$r.utf16_end_exclusive)) -ne $r.utf8_end_exclusive){throw 'Byte end mismatch'}
 if($region.Substring($r.body_relative_utf16) -cne $r.body){throw 'Body boundary mismatch'}
 foreach($g in $r.leading_binder_groups){if($r.header.Substring($g.relative_utf16_start,$g.relative_utf16_end_exclusive-$g.relative_utf16_start) -cne $g.source){throw 'Binder slice mismatch'};$individual+=@($g.names).Count}
 [void]$whole.Append($region)
 $position=$r.utf16_end_exclusive
}
[void]$whole.Append($d.suffix)
if($whole.ToString() -cne $target -or (TextSha $whole.ToString()) -ne $d.formal_sha256){throw 'Whole-module recompose mismatch'}
if($d.count -ne 125 -or @($d.declarations).Count -ne 125){throw 'Declaration count mismatch'}
foreach($c in $d.counts_by_kind){$n=@($d.declarations | Where-Object kind -eq $c.kind).Count;if($n -ne $c.count){throw 'Kind count mismatch'}}
$ps=((& $read 'providers.json') | ConvertFrom-Json).records
foreach($p in $ps){$t=[System.IO.File]::ReadAllText((Join-Path $InputRoot $p.input.Substring(6)));$b=$utf8.GetBytes($t);$slice=[byte[]]$b[$p.utf8_start..($p.utf8_end_exclusive-1)];if((Sha $slice) -ne $p.sha256 -or $utf8.GetString($slice) -cne $p.source){throw 'Provider region mismatch'}}
$payload=@($expected | Where-Object {$_ -notin @('manifest.sha256','seal.json')})
$manifest=(@($payload | ForEach-Object {$b=[System.IO.File]::ReadAllBytes((Join-Path $outRoot $_));(Sha $b)+'  OUTPUT/'+$_}) -join "`n")+"`n"
$seal=[ordered]@{
 kind='NONCIRCULAR_FORMAL_DECODER_FREEZE_SEAL'
 state='FROZEN_BEFORE_SOURCE_RELEASE'
 decoder_identity='hbi_fresh_whole_decoder_c97'
 target='INPUT/QuantumBlockEncoding/HermiteBoundaryInjection.lean'
 target_formal_sha256=$d.formal_sha256
 input_inventory_sha256=(TextSha $invText)
 manifest='OUTPUT/manifest.sha256'
 manifest_sha256=(TextSha $manifest)
 seal_algorithm='SHA256 of exact UTF8 LF manifest bytes; manifest hashes the exact ten payload files but excludes manifest and seal; seal is terminal, not self-hashed'
 payload_files=@($payload | ForEach-Object {'OUTPUT/'+$_})
 verification=[ordered]@{all_authorized_input_files=33;input_hashes_verified=$true;input_byte_counts_verified=$true;whole_target_recomposition_verified=$true;declaration_regions=125;header_body_pairs_verified=125;leading_named_binders=$individual;provider_regions_verified=@($ps).Count;allowlist_verified=$true;host_path_check_passed=$true;compiler_executed=$false;source_released=$false;source_compared=$false;publication_admitted=$false}
}
if($EmitSealPatch){
 $sealText=($seal | ConvertTo-Json -Depth 20) -replace "`r`n","`n"
 $patch=[System.Text.StringBuilder]::new("*** Begin Patch`n")
 foreach($entry in @(@{name='manifest.sha256';content=$manifest},@{name='seal.json';content=$sealText})){
  [void]$patch.Append('*** Add File: '+$entry.name+"`n")
  foreach($line in $entry.content.TrimEnd("`n").Split("`n")){[void]$patch.Append('+'+$line+"`n")}
 }
 [void]$patch.Append("*** End Patch`n")
 $patch.ToString()
}else{
 if((& $read 'manifest.sha256') -cne $manifest){throw 'Payload manifest mismatch'}
 $existing=(& $read 'seal.json') | ConvertFrom-Json
 if($existing.manifest_sha256 -ne (TextSha $manifest) -or $existing.target_formal_sha256 -ne $d.formal_sha256 -or $existing.state -ne $seal.state){throw 'Seal mismatch'}
 [ordered]@{state=$existing.state;seal=$existing.manifest_sha256;payload_count=$payload.Count;declarations=$d.count;providers=@($ps).Count;all_input_hashes_verified=$true;recomposition_verified=$true} | ConvertTo-Json
}
