# Binder and ambient-context audit

This audit is source-blind. Its classes are DATA/TYPING, TYPING-INSTANCE and LOGICAL-INPUT. None of these classes is a judgement of whether a premise belongs to a withheld source. No SOURCE/EXCESS or acceptance judgement is made.

## Literal interface records

OUTPUT/declarations.json contains all 125 top-level declarations in order. For each, `header` is the exact text preceding its body introducer; `body` includes that introducer and trailing formal-mask/trivia through the next declaration. `header + body` is exactly the recorded declaration region. The prefix and suffix retain the rest of the file. UTF-8 and UTF-16 half-open offsets and one-based line spans identify the regions. The result-type field is literal text after the first top-level result colon and before the body; every leading binder group has its original source, names, common declared type and offsets. A group `(k n : ℕ)` represents two consecutive binders of the displayed common type, not one pair-valued parameter.

For the six unannotated abbreviations the written result annotation is absent (`result_type: null`): InjectionBond, ScalarBond, Kernel, HermiteFiniteBond, HermiteCoreAddress and MiddleBond. This is not an absent semantic carrier. Their bodies determine the carriers described in the reconstruction. The `result_colon_relative_utf16` field is also null for these abbreviations; no written colon is claimed there.

This is a textual, manually checked binder inventory, not an elaborated environment dump. Universe variables implicit in Type* and generated equation/recursor/instance declaration names are not claimed extracted. The anonymous instances are individually inventoried by ordinal and exact header, without inventing compiler-generated names.

## Actual ambient context

The target imports exactly QuantumBlockEncoding.HermiteBernstein and QuantumBlockEncoding.HermiteSampleStructure. It then enters an unnamed noncomputable section, namespace QuantumBlockEncoding.HermiteBoundaryInjection, and opens HermiteBernstein. No `variable`, `include`, `omit`, local notation, local attribute, scoped option or nested namespace command occurs in this target. There is no ambient hL, normalized-state assumption, access oracle, schedule validity, circuit certificate or positive step. Every written premise is in its own declaration header. The final named `end` closes the namespace; the section is module-level noncomputable context.

The three decidability instances are actual declarations at ordinals 6,7,9, not ambient hypotheses. They take four natural parameters and return Decidable for Full, Outside and Partial using arithmetic/conjunction/disjunction decidability. There is one private theorem, sampledAmplitude_word (#76); the remaining 68 theorem declarations are non-private. There are 47 definitions, six abbreviations, 69 theorems total and three anonymous instances, giving 125 declarations. Six ambient/import commands (two imports, noncomputable section, namespace, open, and end) are separately literal-recorded in ambient_commands.

## Classification of genuine leading inputs

All natural dimension/index/bound parameters, all real origin/step/L parameters, Boolean bits/lists, finite indices, schedules, target functions, inject/free functions, arbitrary kernels and left/right vectors are data or carrier-formation inputs. The generic implicit carriers B,C and Fintype enumerations in #95–100 are typing inputs. A real-valued function is not a logical correctness assumption merely because it appears as a parameter.

The following names are logical-input binders wherever they occur; exact instantiations and order are in the inventory:

- hM: positive natural block width M.
- hp,hx,hy: Partial-block propositions, recursively expanded below.
- hl: either lower≤2^n (#41) or lower<2^n (#42), as literally written.
- hfirst: affinePoint origin step first≠0 (#17,#27).
- hvalid: every j inside [lower,upper) has nonzero affinePoint (#29).
- hnext: ScheduleValid lower upper schedule bits.length (#37,#52).
- hinject: the universally quantified injection/free-product compatibility equation (#51).
- hs: step≥0 (#58,#86) or size>0 (#71); these are not the same premise.
- hL: L>0 in each theorem that literally binds it.
- hcut: cutIndex n L=2^n (#74).
- hbits: bits.length=n+1, also used as dependent index-formation evidence in wordSampleIndex.
- hf: Full-block containment (#71,#83).
- hlen: bits.length≤n (#89).

The leading name `hp` has different specialized arguments in different declarations; the inventory retains those exact arguments. The reconstruction never replaces them by an unqualified 'validity' premise.

## Recursive project-owned logical bundle expansion

For ℓ,u,a,s∈ℕ, write F(ℓ,u,a,s)=(ℓ≤a ∧ a+s≤u), O(ℓ,u,a,s)=(a+s≤ℓ ∨ u≤a). Then Full is F, Outside is O, and Partial is ¬F ∧ ¬O. Thus every Partial input expands to two negative arithmetic conditions, not a four-field record with hidden data. Every Full input expands to the two inequalities in F.

For a schedule σ and r, child(σ,r,b)=σ(r+1)+(if b then 2^r else 0). ScheduleValid(ℓ,u,σ,w) expands to

\[
\forall r\in\mathbb N,\ r<w\to\forall b:\mathrm{Bool},
\bigl(\neg(\ell\le a\land a+2^r\le u)\land
\neg(a+2^r\le\ell\lor u\le a)\bigr)\to \sigma(r)=a,
\quad a=\operatorname{child}(\sigma,r,b).
\]

This fully expands the only project-owned logical predicates appearing in leading theorem inputs. There are no project-owned contract structures or typeclasses in those leading inputs. Kernel, InjectionBond, ScalarBond, HermiteFiniteBond, MiddleBond and HermiteCoreAddress are type/data aliases and expand to the literal function, Option, Sum and product carriers in the reconstruction. SampledAmplitude expands through gridPoint to smoothInitial, sourceInterpolant, endpointFactor, coefficientPolynomial and coefficientSeries as detailed there and in OUTPUT/providers.json.

`hvalid`'s bound quantifiers are inside its leading binder type. `hinject`'s ∀first bits is likewise inside its binder type, and its free product is exactly the recursion in scalarFreeContract. Neither is an unrecorded ambient premise. The locally introduced hs/hp'/hn/hpc/hm in proof bodies are proof steps, not public binders.

## Conclusion subexpressions are not leading binders

Examples requiring care:

- `ScheduleValid ...` is the conclusion of #40 and #44. Its internally quantified r,bit are not additional leading inputs of these theorems.
- The conditions inside the `if` expressions of #29,#51,#73,#77,#80,#82,#84,#91,#92 are conclusion subexpressions; they are not assumed membership of the queried sample.
- Full/Partial inequalities in the conclusions of #12,#14,#42,#71 are asserted formulas, not extra premises. In #42, only the written hl is the leading arithmetic premise.
- The real bounds 0≤factor∧factor≤1 in #58,#83,#86 are conclusions; positivity/nonnegativity of step or L is the written premise, not both conclusions assumed.
- `StrictMono (gridPointNat n L)` in #64 is a conclusion. Its unfolded universally quantified i,j and implication are not extra leading binders.
- In `wordValue : List Bool → ℕ`, and similarly in recursive contracts' function-valued result types, result arrows are part of the declared result type, not syntactic leading binder groups. The equations supply pattern arguments after that boundary.
- In #118 the explicit hbits proof appears inside the returned sampled index; it is genuinely leading. By contrast the finite-index proof created in the body of wordSampleIndex is an implementation term, not a new leading premise.

## Suppliers rather than retained hypotheses

The generic #37 and #52 accept schedule validity and a Partial root. Their specialized consumers construct these facts using #40/#44, #41 and #42 or direct arithmetic. The generic #51 accepts injection correctness; #56 supplies it for the exponential branch. #29 accepts hvalid; #65 supplies negative, hence nonzero, middle coordinates. #17/#27 accept hfirst because the literal restriction uses division by 1-u. These roles are visible in proof bodies, and none of these generic supplier conditions has been silently added to #118.

The kernel data itself is not assumed normalized or efficiently computable. No output cardinality theorem supplies a runtime contract. An imported state-preparation module is reachable by imports, but its circuit results are not invoked to assert the local kernel equality. Import reachability, textual references and elaborated proof dependencies are distinct evidence layers; this packet claims only the first two where recorded, never compiler-confirmed dependency edges.
