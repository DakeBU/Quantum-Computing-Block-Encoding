param([Parameter(Mandatory=$true)][string]$InputRoot)
$ErrorActionPreference = 'Stop'
$targetName = 'QuantumBlockEncoding/HermiteBoundaryInjection.lean'
$utf8 = [System.Text.UTF8Encoding]::new($false)
function HashText([string]$s) { [Convert]::ToHexString([System.Security.Cryptography.SHA256]::HashData($utf8.GetBytes($s))).ToLower() }
function LineAt([string]$s,[int]$p) { 1 + ([regex]::Matches($s.Substring(0,$p), "`n")).Count }
function ByteAt([string]$s,[int]$p) { $utf8.GetByteCount($s.Substring(0,$p)) }
function SplitHeader([string]$chunk) {
  $depth=0; $colon=-1; $body=-1; $equation=$false
  for($j=0;$j -lt $chunk.Length;$j++) {
    $c=$chunk[$j]
    if($depth -eq 0 -and $c -eq ':' -and ($j+1 -ge $chunk.Length -or $chunk[$j+1] -ne '=')) { if($colon -lt 0){$colon=$j} }
    if($depth -eq 0 -and $j+1 -lt $chunk.Length -and $chunk.Substring($j,2) -eq ':='){$body=$j;break}
    if($depth -eq 0 -and $c -eq '|' -and $colon -ge 0){$body=$j;$equation=$true;break}
    if($c -eq '(' -or $c -eq '[' -or $c -eq '{'){$depth++}
    if($c -eq ')' -or $c -eq ']' -or $c -eq '}'){$depth--}
  }
  if($colon -lt 0 -and $body -ge 0){$colon=$body}
  if($body -lt 0){throw 'Unrecognized declaration body'}
  $header=$chunk.Substring(0,$body)
  $prefix=$chunk.Substring(0,$colon)
  $binders=[System.Collections.Generic.List[object]]::new()
  $depth=0; $start=-1
  for($j=0;$j -lt $prefix.Length;$j++){
    $c=$prefix[$j]
    if($c -eq '(' -or $c -eq '[' -or $c -eq '{'){if($depth -eq 0){$start=$j};$depth++}
    if($c -eq ')' -or $c -eq ']' -or $c -eq '}'){$depth--;if($depth -eq 0){$lit=$prefix.Substring($start,$j-$start+1);$class=if($lit -match '^\['){'typing-instance'}elseif($lit -match '^\{'){ 'implicit-typing-carrier' }elseif($lit -match '^\((hM|hp|hx|hy|hl|hfirst|hvalid|hnext|hinject|hs|hL|hcut|hbits|hf|hlen)\s*:'){'logical-input'}else{'data-or-typing'};$inside=$lit.Substring(1,$lit.Length-2);$nc=$inside.IndexOf(':');$names=if($nc -ge 0){@($inside.Substring(0,$nc).Trim() -split '\s+')}else{@()};$bt=if($nc -ge 0){$inside.Substring($nc+1).Trim()}else{$inside};$binders.Add([ordered]@{source=$lit;names=@($names | Where-Object {$null -ne $_});declared_type=$bt;classification=$class;relative_utf16_start=$start;relative_utf16_end_exclusive=$j+1})}}
  }
  $result=if($colon -eq $body){$null}else{$chunk.Substring($colon+1,$body-$colon-1)}
  [ordered]@{header=$header;body=$chunk.Substring($body);result_type=$result;result_colon_relative_utf16=$(if($colon -eq $body){$null}else{$colon});body_relative_utf16=$body;body_style=$(if($equation){'equations'}else{'assignment'});leading_binder_groups=$binders.ToArray()}
}
$invText=[System.IO.File]::ReadAllText((Join-Path $InputRoot 'formal-inputs.json'))
$inv=$invText | ConvertFrom-Json
$pins=@($inv.inputs | ForEach-Object {
 $f=Join-Path $InputRoot $_.path
 $b=[System.IO.File]::ReadAllBytes($f)
 $h=[Convert]::ToHexString([System.Security.Cryptography.SHA256]::HashData($b)).ToLower()
 if($h -ne $_.formal_snapshot_sha256 -or $b.Length -ne $_.bytes){throw 'Input binding mismatch'}
 [ordered]@{path=('INPUT/'+$_.path);sha256=$h;bytes=$b.Length;expected_formal_sha256=$_.formal_snapshot_sha256;matched=$true;scope=$_.scope}
})
$s=[System.IO.File]::ReadAllText((Join-Path $InputRoot $targetName))
if($s.Contains("`r")){throw 'Expected LF snapshot'}
$starts=@([regex]::Matches($s,'(?m)^(?:(?:private|noncomputable) )?(?:def|abbrev|theorem|lemma|instance)\b'))
$all=[System.Collections.Generic.List[object]]::new()
$recomposed=[System.Text.StringBuilder]::new()
$prefix=$s.Substring(0,$starts[0].Index)
[void]$recomposed.Append($prefix)
for($i=0;$i -lt $starts.Count;$i++){
 $a=$starts[$i].Index
 $z=if($i+1 -lt $starts.Count){$starts[$i+1].Index}else{[regex]::Match($s,'(?m)^end QuantumBlockEncoding.HermiteBoundaryInjection\s*$').Index}
 $chunk=$s.Substring($a,$z-$a)
 $parsed=SplitHeader $chunk
 $nameMatch=[regex]::Match($chunk,'^(?<vis>private )?(?<kind>def|abbrev|theorem|lemma|instance)\s*(?<name>[^\s(:{\[]*)')
 $kind=$nameMatch.Groups['kind'].Value
 $name=$nameMatch.Groups['name'].Value
 if($kind -eq 'instance'){$name='anonymous-instance-'+(1+@($all | Where-Object kind -eq 'instance').Count)}
 $b=$a+$parsed.body_relative_utf16
 $record=[ordered]@{ordinal=$i+1;name=$name;kind=$kind;visibility=$(if($nameMatch.Groups['vis'].Success){'private'}else{'public-or-instance'});line_start=(LineAt $s $a);line_end_inclusive=(LineAt $s ($z-1));utf16_start=$a;utf16_end_exclusive=$z;utf8_start=(ByteAt $s $a);utf8_end_exclusive=(ByteAt $s $z);body_utf8_start=(ByteAt $s $b);body_line_start=(LineAt $s $b);ambient='noncomputable section; namespace QuantumBlockEncoding.HermiteBoundaryInjection; open HermiteBernstein; no section variables, local notation, scoped options or local instances beyond the three recorded global decidability instances';header=$parsed.header;body=$parsed.body;result_type=$parsed.result_type;result_colon_relative_utf16=$parsed.result_colon_relative_utf16;body_relative_utf16=$parsed.body_relative_utf16;body_style=$parsed.body_style;leading_binder_groups=$parsed.leading_binder_groups;source_sha256=(HashText $chunk)}
 $all.Add($record)
 if(($parsed.header+$parsed.body) -cne $chunk){throw 'Header/body reconstruction mismatch'}
 [void]$recomposed.Append($parsed.header+$parsed.body)
}
$end=$s.Substring($all[$all.Count-1].utf16_end_exclusive)
[void]$recomposed.Append($end)
if($recomposed.ToString() -cne $s){throw 'Whole partition mismatch'}
$commands=@([regex]::Matches($s,'(?m)^(import|noncomputable section|namespace|open|end)\b[^\n]*') | ForEach-Object {[ordered]@{line=(LineAt $s $_.Index);utf8_start=(ByteAt $s $_.Index);source=$_.Value}})
$counts=@('def','abbrev','theorem','instance' | ForEach-Object {$wanted=$_;$n=0;foreach($r in $all){if($r['kind'] -eq $wanted){$n++}};[ordered]@{kind=$wanted;count=$n}})
$inventory=[ordered]@{kind='SOURCE_BLIND_LITERAL_WHOLE_MODULE_INVENTORY';input=('INPUT/'+$targetName);formal_sha256=(HashText $s);bytes=$utf8.GetByteCount($s);offset_convention='zero-based half-open UTF8 byte and UTF16 code-unit offsets; one-based inclusive lines; declaration regions include following masked/trivia lines up to next declaration; header + body is exact region; null result_type means no written result annotation (inferred abbrev type), not an empty proposition';count=$all.Count;counts_by_kind=$counts;method='Complete line-by-line read of 1180 lines; manual grammar-family review (definitions, equations, theorem proofs, anonymous instances, ambient commands); lexical starts partition checked by exact header/body recomposition and whole-byte digest. Not an elaborated Lean environment inventory.';ambient_commands=$commands;prefix=$prefix;declarations=$all.ToArray();suffix=$end;recomposition_verified=$true}
$providerRanges=@(
 @{p='QuantumBlockEncoding/HermiteBernstein.lean';a=1;z=479;role='Complete bounded Bernstein supplier; all definitions and proof bodies read'},
 @{p='QuantumBlockEncoding/HermitePolynomial.lean';a=1;z=25;role='Imported-definition ambient boundary: Mathlib imports, noncomputable section, Polynomial open and namespace'},
 @{p='QuantumBlockEncoding/HermitePolynomial.lean';a=169;z=196;role='Coefficient-series, truncation, endpoint-factor and explicit interpolant definitions; coefficient identity'},
 @{p='QuantumBlockEncoding/HermitePolynomial.lean';a=246;z=253;role='Endpoint jet used by strict endpoint adapter'},
 @{p='QuantumBlockEncoding/HermitePolynomial.lean';a=289;z=309;role='Finite polynomial and interpolant evaluation conventions'},
 @{p='QuantumBlockEncoding/HermitePolynomial.lean';a=357;z=371;role='Piecewise target definition and branch adapters'},
 @{p='QuantumBlockEncoding/HermiteCutRank.lean';a=1;z=21;role='Imported-definition ambient boundary including unused carrier variables; relevant declarations do not use those variables'},
 @{p='QuantumBlockEncoding/HermiteCutRank.lean';a=199;z=220;role='Affine ceiling threshold and strict target-branch adapter'},
 @{p='QuantumBlockEncoding/HermiteStatePreparation.lean';a=1;z=26;role='Ambient imports and gridPoint definition'},
 @{p='QuantumBlockEncoding/HermiteStatePreparation.lean';a=27;z=28;role='Sampled-amplitude definition'},
 @{p='QuantumBlockEncoding/Core.lean';a=44;z=44;role='Power-of-two grid cardinality'}
)
$providers=@($providerRanges | ForEach-Object {
 $t=[System.IO.File]::ReadAllText((Join-Path $InputRoot $_.p));$ls=$t.Split("`n");$a=$_.a;$z=$_.z;$off=0;for($j=0;$j -lt $a-1;$j++){$off+=$ls[$j].Length+1};$text=($ls[($a-1)..($z-1)] -join "`n")+"`n"
 [ordered]@{input=('INPUT/'+$_.p);line_start=$a;line_end_inclusive=$z;utf8_start=(ByteAt $t $off);utf8_end_exclusive=(ByteAt $t ($off+$text.Length));sha256=(HashText $text);role=$_.role;source=$text}
})
$files=[ordered]@{
 'declarations.json'=($inventory | ConvertTo-Json -Depth 30)
 'providers.json'=([ordered]@{scope='Bounded formal definitions and semantic adapters only; provider modules not independently source-admitted';records=$providers} | ConvertTo-Json -Depth 20)
 'input-pins.json'=([ordered]@{inventory_path='INPUT/formal-inputs.json';inventory_sha256=(HashText $invText);all_input_hashes_verified=$true;files=$pins} | ConvertTo-Json -Depth 10)
}
$patch=[System.Text.StringBuilder]::new("*** Begin Patch`n")
foreach($entry in $files.GetEnumerator()){
 [void]$patch.Append('*** Add File: '+$entry.Key+"`n")
 foreach($line in ($entry.Value -replace "`r`n","`n").TrimEnd("`n").Split("`n")){[void]$patch.Append('+'+$line+"`n")}
}
[void]$patch.Append("*** End Patch`n")
$patch.ToString()
