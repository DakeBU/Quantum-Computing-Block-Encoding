# Independent four-view conceptual review

Verdict: ACCEPT_BOUNDED_CONCEPTUAL_CONTENT. No blocking mathematical mismatch was found with the allowed natural contract. This is not acceptance of an implementation Lean graph, declaration ownership, lossless inventory expansion, purification, historical novelty, or functor laws.

This is a separately authorized follow-up by `sp_extended_topology_independent_c44`. The earlier topology packet is unchanged. Its ACCEPT is not being reused to approve the four views wholesale. The new proposal, original mathematical contract, and original proposed natural topology were each read completely; before/after hashes agree. Implementation, inventories, author audit guides, decoder material, and other reviews were not inspected.

## Four views

The proposed source-construction view is consistent as a retrospective LOCAL mathematical proposal. Common substrate S1-S7 and the Bell/dense/sparse tails retain LE order, exact RY signs and half angles, full non-target context, all used rows/columns, concrete normalizations, chronological composition, and literal cost semantics. The sparse (6,4) zero remains an RY(0) entry, not a context mismatch. Generic CX is not justified circularly by Bell entries. Generic zero-UCRY uses full operator semantics; repeated controls are allowed when each differs from target, and no target exists at zero wire count. These domains are inherited from the raw contract, not inferred from compiler execution.

The Lean-view distinction is sound as a disclaimer: mathematical proposals and lexical signals are not elaborated proof dependencies. However, the purported exact import table, source ownership, private identifiers, full theorem bodies, 140-declaration/1,186-line coverage, and upstream-use assertions are NOT ASSESSED. Natural text asserting them is not verification of them. No lexical-reference scan or elaborated exporter was run by this reviewer.

The compressed-spine families are reasonable proposed presentation groupings, not new theorems. Algorithmic OR between sparse witnesses remains distinct from the dense-tree proof's AND reuse of pruned preparation and identity padding. Neither wrapper compression nor a common target identifies different unitary completions. Exact leaf expansion, all carrier adapters/hypotheses in inventories, canonicality, dead-code cleanup and import minimality are NOT ASSESSED. The claimed lossless implementation expansion is therefore not certified here. PENDING purification must remain PENDING.

The Functor Hypergraph is acceptable only as conditional mathematical transport proposals. H1-H4 do not define categories, object/morphism maps, identities or composition laws. This review grants no categorical or Lean implication certificate and makes no historical novelty determination. No SP-to-arbitrary-BE, BE-to-SP or SELECT access appears.

## H1-H4

H1 is substitution: on the same carrier, LE basis and exact phase convention, U=V AND V|0>=psi gives U|0>=psi. The reverse fails even for unitaries: I and diag(1,-1) both prepare e0 but are different operators. Matching measurement distributions is still weaker; e0 and -e0 already have identical distributions without the contract's exact vector equality.

H2 is full coordinate linearity on the input support: the literal input expansion AND every required support-column/output-row entry AND complex linearity AND output identification jointly give the fixed-input action. It does not give an arbitrary-input operator theorem. Coefficients, zero rows, and phases may not be dropped. This matches the Bell four-row, dense four-row and sparse eight-row families in the raw contract.

H3 preserves chronological direction U(A++B)=U(B)U(A). Full U(B)=I gives operator equality; A's exact action and concrete normalization then give the same normalized target. Its comparison head is explicitly conditional on the lexicographic premises. A separately computed pair of resources does not alone order them, and semantic identity does not imply zero instruction cost. Thus the cost head must retain its stated condition; it is not an unconditional consequence of the displayed resource-computation tail. For the actual fixed lists, (0,5,4,0) versus (0,15,13,0) and 5<15 supply the first branch. This reads the proposal's existing qualification, not a new proof premise imposed on the finite root.

H4 correctly combines an actual typed list, exact state action in the same convention, a literal target with its expanded norm-square predicate, its proof, and list resources. Generic unitarity is a derived supplier, not a freely chosen record field or extra public finite-root assumption. A generic Prop called normalization, a circuit label, or an unrelated completion is insufficient. The result is a fixed normalized primitive route at the ideal exact-real logical tier, not a finite-bit implementation or uniform algorithm.

All mathematical supplier and code-linked names remain author/source assertions unless independently checked elsewhere. Source gaps for unread papers, general complex-vector/phase loading, arbitrary support algorithms and stronger resources remain explicit. This follow-up accepts conceptual consistency only and cannot be cited as production admission, Proof Seal or Exposition Seal.

Failure class: NONE for bounded conceptual consistency. Direction: conceptual-four-view-source-review-no-implementation. Gain: prevent source-coverage acceptance from being promoted into Lean/functor implication approval. No rejected implementation fragments were promoted; no children, compilation, native UI, network, Git, registry or production actions occurred. Only the new follow-up output directory was written.
