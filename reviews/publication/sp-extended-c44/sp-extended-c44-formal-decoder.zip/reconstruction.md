# Independent whole-target formal reconstruction

Status: independent formal-text reconstruction, sealed before opaque binding or source comparison. This is not publication/schema acceptance, a source-fidelity verdict, or a compilation certificate.

Direction fingerprint: `formal-SP-whole-module-semantic-reconstruction`.
Expected information gain: independently resolve actual theorem semantics before source comparison.

## 1. Reading boundary and evidence level

Logical root `formal-track` denotes the supplied `sp-extended-routes-c43-publicsafe` packet. Logical root `governance` denotes only the six specifically authorized governance files. Logical root `decoder-output` denotes this new output directory. All input references below are relative to these logical roots.

I read all three complete target files through EOF, including all private helpers, proof bodies, local simplification attributes, namespace/open/import commands, and route fields. I also read all fourteen supplied provider files through EOF, all fourteen extent records, and `pins/formal-track-manifest.json`. Provider files are whitespace-masked, bounded excerpts; reading them through EOF does not reconstruct their omitted original modules. Extent `raw_sha256` values describe uninspected originals and are not substituted for hashes of the supplied excerpts.

The independent target inventory contains 37, 18, and 85 explicit declarations respectively (140 total), plus 27 ambient commands. It is recorded, with per-command excerpt hashes and semantic dispositions, in `independent-declaration-coverage.json`. This inventory was made from the actual target text, not a public-declaration list or a supplied verdict. Supplied provider material was used to drill down the carriers and operations, not as an independent source comparison.

Input hashes were taken before reading mathematical content and again after the complete reading. All 32 files (31 formal files plus the manifest itself) were unchanged; the manifest's 31 content pins match the observed bytes. Inputs remain read-only. No compiler, native proof evaluation, mathematical executable diagnostic, network, Git, source paper, sibling natural/README/author track, other pin file, production source, review, prior verdict, CI/trust/catalog/registry, other worker, or parent history was consulted. `native_decide` occurs inside inspected proof scripts; I did not run it. Imports were recorded but not followed beyond the supplied providers. In particular, the toolchain version and transitive proof environment were not independently checked.

The statements below mean “the supplied Lean text states this proposition and presents the described argument.” They do not mean that this run elaborated or kernel-checked those arguments. Names containing `Verified`, `Paper`, `Dense`, or `Pruned`, and provenance strings, do not determine theorem strength.

## 2. Carrier drill-down and semantic conventions

### 2.1 Vectors, matrices, zero input, and normalization

`QuantumBlockEncoding.gridSize n = 2 ^ n`, for natural `n`, includes `gridSize 0 = 1`. `QuantumBlockEncoding.Matrix rows cols α` is a function `Fin rows → Fin cols → α`. `ConcreteSemantics.FiniteMatrix rows cols α` is Mathlib's matrix on those finite index types; `StateVector dimension α = Fin dimension → α` is an unrestricted function type, not a subtype of normalized states. `basisKet dimension index = Pi.single index 1`, so its row is 1 exactly when `index = row`, otherwise 0. `zeroBasisIndex n` is the valid finite index 0; positivity of `2 ^ n` supplies its bound. `zeroKet n` is that basis vector. `applyVec operator state` is `operator.mulVec state`, with rows as output and columns as input. The supplied generic linearity lemmas identify action on a basis ket with the corresponding column, and action on `a e_left + b e_right` with `a col_left + b col_right`; they do not require distinct indices. The pointwise version is `a * U(row,left) + b * U(row,right)`.

`StatePreparationTarget α qubits` has exactly:

- `amplitudes : Fin (2 ^ qubits) → α`;
- `normalization : Prop` (arbitrary proposition, not intrinsically the squared-norm condition);
- `source : String := ""` (data, not a theorem or assumption).

`ExactPrimitiveStatePreparationRoute qubits` contains a target, a primitive circuit on exactly those qubits, a proof of that target's chosen normalization proposition, and the exact equality

\[
  \operatorname{applyVec}(\operatorname{evalPrimitiveCircuitLE}(c),\operatorname{zeroKet}(q))
  = \operatorname{target.amplitudes}.
\]

There is no acceptance branch, postselection, success-probability parameter, tolerance, quotient by phase, or hidden input state in this record. The generic record alone does not force its arbitrary `normalization` field to be an actual norm equation. Here each of the three concrete targets explicitly chooses `∑ index, Complex.normSq (state index) = 1`, and the supplied normalization proofs evaluate that finite sum. Unitarity follows independently for every primitive circuit via `evalPrimitiveCircuitLE_unitary`, and is exposed by the route's `unitary` theorem, not assumed as a free logical field. `ComplexUnitaryGate` is another supplied carrier: a `2 ^ q` square complex matrix and membership in the corresponding matrix unitary group; it is not the record used to build these routes.

### 2.2 Basis order and omitted-wire contexts

`PrimitiveBasis q = Fin q → Fin 2`; each wire has a bit in `{0,1}`. `primitiveBasisLEEquiv` is an explicit recursive equivalence to `Fin (2 ^ q)`. Its successor value theorem is

\[
  \operatorname{index}(b)=b_0+2\operatorname{index}(b_1,b_2,\ldots),
\]

so wire 0 is least significant. For two and three wires the supplied inverse theorems give bit `w` as `⌊index / 2 ^ w⌋ mod 2`, including explicit finite-index cases. Thus `1` means `(b0,b1)=(1,0)`, `2` means `(0,1)`, and on three wires `4` means `(0,0,1)`. If written as a conventional ket with the most significant digit leftmost, these are `|01⟩`, `|10⟩`, and `|100⟩` respectively.

`OtherPrimitiveWires target = {wire : Fin q // wire ≠ target}`. `splitPrimitiveWire target` is an equivalence from a full bit assignment to `(target bit, all other wire bits)`, with an explicit inverse restoring either the target bit or the corresponding other bit. Equality of its second components means *every* non-target wire agrees, not merely the chosen controls. For two-wire indices the retained context code is `index / 2` when target is 0 and `index % 2` otherwise. For three wires it is `index / 2` for target 0, `index % 2 + 2 * (index / 4)` for target 1, and `index % 4` for target 2. The supplied `Without` and `GridWithout` theorems equate these numerical tests with actual omitted-wire context equality. The catch-all patterns are exhaustive on their finite carriers, not unspecified behavior outside those carriers.

`evalPrimitiveCircuitLE` simultaneously reindexes the row and column of `evalPrimitiveCircuit` by that equivalence. This is a basis change of the full operator, with unitarity preserved, not a change of the desired state or a dropped wire.

### 2.3 Angles, gate matrices, and sequencing

`ExactAngle` is an expression type with rational, rational multiple of π, twice-arccos-of-rational, twice-arccos-of-square-root-of-rational, arbitrary real, addition, negation, and rational scaling constructors. The arccos-rational constructor carries `|(value : Real)| ≤ 1`; the square-root variant carries `0 ≤ value ∧ value ≤ 1`. Arbitrary `real value` has no boundedness guard. Evaluation gives those exact real expressions. `sub`, `halfAdd`, and `halfSub` evaluate to subtraction, `(left + right)/2`, and `(left - right)/2`. Evaluation is noncomputable; syntax construction and finite gate counting are distinct from numerical evaluation or finite-bit synthesis. The private representation function deliberately renders the arbitrary-real constructor as `"<exact real angle; numerical export required>"`; this label does not certify an exporter.

`realOrthogonalRotation c s` is the complex matrix `[[c,-s],[s,c]]` with real entries coerced to ℂ. Its unitarity lemma requires `c*c+s*s=1`. `realRotation θ` uses `c=cos θ`, `s=sin θ`; `amplitudeRotation c` uses `realRotation (arccos c)`. The latter is unitary for every real `c`, but its `(0,0)` entry equals `c` only with `-1 ≤ c ≤ 1`. `amplitudeRotation_eq_pythagorean` additionally requires nonnegative supplied sine and a circle identity to identify that sine with `sin(arccos c)`. Those conditions matter for the sign, not just normalization.

`standardRyMatrix θ = realRotation (θ/2)` therefore equals

\[
 R_y(\theta)=\begin{pmatrix}\cos(\theta/2)&-\sin(\theta/2)\\
 \sin(\theta/2)&\cos(\theta/2)\end{pmatrix}.
\]

The supplied algebra proves zero angle is identity, addition corresponds to matrix composition, negation to conjugate transpose, unitarity, and `X Ry(θ) X = Ry(-θ)`. The theorem equating `standardRyMatrix (2*arccos c)` with `amplitudeRotation c` has lower/upper bound binders although its proof is simply cancellation of the factor two; the bounds are used in the downstream coefficient characterization, not needed for that syntactic identity itself. Real-valued complex sine/cosine conjugation helpers handle stars and division by two. `standardRzMatrix θ` is diagonal with entries `cos(θ/2) ∓ i sin(θ/2)` and has unitary/negative-angle-adjoint proofs. `xMatrix` has zero diagonal and unit off-diagonal.

`PrimitiveGate q` is one of X, Ry, Rz, or CNOT. Each target/control is in `Fin q`; CNOT also requires control ≠ target. `xBasisAction` flips its target with `flipBit`, which sends 0 to 1 and 1 to 0. `cxBasisAction` leaves the full state unchanged if its control is 0 and otherwise flips its target. The distinctness guard ensures this is involutive and preserves its control. `equivPermutationMatrix e` has entry 1 iff `row = e column`, otherwise 0. One-qubit lifting is `gate ⊗ I_other`, reindexed through `splitPrimitiveWire`, so entries vanish on different non-target contexts. These constructions and their unitary proofs cover the whole finite carrier.

`PrimitiveCircuit q` is a gate list. Its evaluator is identity for `[]` and `eval rest * eval gate` for `gate :: rest`: the list is executed left to right on column vectors. In particular `eval(left ++ right) = eval(right) * eval(left)`, and the same holds after LE reindexing. The evaluator's unitary theorem inducts over the list. Gate dagger preserves X/CNOT and negates Ry/Rz angles; its supplied matrix theorem is conjugate transpose. A separate `PrimitiveProgram` record has `circuit` and an `ExactAngle globalPhase` field, but none of these target routes use a `PrimitiveProgram` or quotient away that phase. All target equalities fix the actual amplitudes and relative phases.

## 3. Generic uniformly controlled Ry mechanism

This supplied mechanism is genuinely parameterized, distinct from the fixed examples below. Parameters are naturals `qubits`, `controls`, a function `wires : Fin controls → Fin qubits`, `target : Fin qubits`, a guard `∀ control, wires control ≠ target`, and *any* angle table `PrimitiveBasis controls → ExactAngle`. The wires function is **not required to be injective**. Repeated controls are allowed; the semantics samples the table only on assignments induced by the physical context, so inconsistent duplicated-control assignments need not be realized. At zero controls the empty assignment is unique. A target in `Fin 0` cannot be supplied, so apparent statements with zero qubits and a target have no instances.

`primitiveControlAssignment` reads each selected wire from the complete non-target context. `controlledRyBlockMatrix` is a block-diagonal operator, one Ry block for every full non-target context. Its entry is zero if those contexts differ; otherwise it is the selected Ry entry on the target bits. It preserves all controls and all non-control spectators exactly.

The compiler is a recursive *literal* gate-list construction. At zero controls it returns one Ry. At a successor, let `head = wires 0`, use successor wires as the tail, and define for each tail assignment `t`

\[
 A(t)=(\theta(0,t)+\theta(1,t))/2,\qquad
 B(t)=(\theta(0,t)-\theta(1,t))/2.
\]

It emits `compile tail A ; CX(head,target) ; compile tail B ; CX(head,target)`. `uniformlyControlledRyMatrix` separately mirrors this product in reverse multiplication order. `compileUniformlyControlledRy_eval` proves agreement with that recursive matrix. The stronger `compileUniformlyControlledRy_eval_controlledRyBlockMatrix` proves agreement with the direct contextwise block diagonal, by induction: a control-zero block combines `Ry(B) Ry(A)` to `Ry(A+B)=Ry(θ0)`; a control-one block combines `X Ry(B) X Ry(A)` to `Ry(A-B)=Ry(θ1)`. The proof explicitly establishes CNOT's block representation and equality of full contexts. It does not use an assumed desired final action as an extra premise.

The supplied count theorems state exactly `ryCount = 2 ^ controls` and `cxCount = 2 * (2 ^ controls - 1)`, with natural-number subtraction, proved by induction. Zero angles are not removed by the compiler. These counts are for this recursive emitter, not an optimality theorem. No generic depth, arbitrary-input state-preparation algorithm, input-table access complexity, or finite-bit angle error theorem is supplied here.

## 4. Fixed Bell route: whole-module mathematical reconstruction

`bellAmplitude = TextbookStatePreparation.invSqrtTwo = (sqrt 2 / 2 : Real)` coerced to ℂ, with square `1/2`. `bellState` is this value at finite indices 0 and 3 and zero at 1 and 2. `bellTarget` uses that state, the actual squared-norm equation, and the unchanged String data `"Bell-state textbook benchmark"`.

`bellRyAngle = ExactAngle.piRational (1/2)`, with evaluation π/2 proved by rational casting and arithmetic. The matrix is `warmRobinUniformBitPrepare = realOrthogonalRotation (sqrt 2/2) (sqrt 2/2)`. This is *not* the full Hadamard matrix: its top-right entry is negative, though its action on `|0⟩` has the desired equal positive amplitudes.

`bellControl = 0`, `bellTargetWire = 1`, and the inequality proof discharges CNOT's wire guard. `bellRyCircuit = [ry 0 bellRyAngle]`, `bellCxCircuit = [cx 0 1 distinct]`, and `bellPrimitiveCircuit` is their concatenation. The exact state transcript is

\[
 e_0 \xrightarrow{R_y(\pi/2)\text{ on }0}
 a e_0+a e_1
 \xrightarrow{\mathrm{CX}(0,1)}a e_0+a e_3,
 \qquad a=\sqrt2/2.
\]

Private `bellAfterRy_0..3` evaluate the intermediate vector as `(a,a,0,0)`. Private `bellRy_entry_00`, `_10`, `_20`, `_30` give column zero `(a,a,0,0)` by the singleton-Ry entry formula, equality/inequality of other-wire contexts, and the exact rotation matrix. `bellRy_col_zero` assembles the four coordinates; `bellRy_prepares` applies the generic zero-column lemma.

The module's public `evalPrimitiveCircuitLE_singleton_cx_apply` is a generic CNOT entry characterization for arbitrary valid wire pair and arbitrary LE row/column, not only the Bell circuit. Private `bellCx_entry_00`, `_10`, `_20`, `_30` show column zero `(1,0,0,0)`; `_01`, `_11`, `_21`, `_31` show column one `(0,0,0,1)`. Private `bellCx_output_0..3` combine those two columns to `(a,0,0,a)`. `bellCx_on_afterRy` uses action on a two-basis superposition and all four coordinate helpers. `bellPrimitive_prepares_target` uses append composition, matrix-vector associativity, and the two stage theorems; it asserts exact preparation of the target, not merely equal measurement distribution.

`bellPrimitiveRoute` supplies all four record fields explicitly: the concrete target, literal circuit, supplied target normalization, and the just-derived preparation equality. `bellVerified_cost` states `(auxiliaryQubits,gateCount,depth,oracleCalls)=(0,2,2,0)`. There is no additional state-preparation hypothesis, no oracle, no extra register, and no arbitrary-dimension Bell-family theorem in this target module.

## 5. Entry-certificate target: exact controlled blocks, not whole state preparation

This target namespace is `QuantumBlockEncoding.StatePreparationPaperEntryCertificates`. Private `standardRyMatrix_ryAngle35_explicit` and `_ryAngle513_explicit` remove rational-to-real presentation differences and identify the matrices with `[[3/5,-4/5],[4/5,3/5]]` and `[[5/13,-12/13],[12/13,5/13]]`. Their bodies check all four matrix entries after invoking the supplied angle theorems. Here

\[
 \alpha=\operatorname{eval}(\texttt{ryAngle35})=2\arccos(3/5),\quad
 \beta=\operatorname{eval}(\texttt{ryAngle513})=2\arccos(5/13),
\]

and `ryAngleZero` is the literal rational zero angle.

The dense angle table returns `ryAngle35` when its sole control bit is 0 and `ryAngle513` otherwise; on `Fin 2` the otherwise branch means 1. Its compiled UCRy uses wire 1 as control and target 0. For complete row/column contexts differing outside target 0 the module proves entry zero. It also proves the four concrete entries `(0,0)=3/5`, `(1,0)=4/5`, `(2,2)=5/13`, `(3,2)=12/13`, using the supplied general block formula and exact finite context tests.

The sparse control function sends the sole control to wire 2, with an explicit proof that this differs from target wire 1. The sparse table returns `ryAngle35` at control bit 0 and literal `ryAngleZero` otherwise. The compiled operator rotates wire 1 by α only when wire 2 is zero and is identity when wire 2 is one, while also preserving wire 0. The context-mismatch theorem now compares *both* non-target bits. The four positive entries are `(0,0)=3/5`, `(2,0)=4/5`, `(4,4)=1`, `(6,4)=0`.

These eighteen declarations supply exact matrix definitions, guards, a general off-context vanishing rule for each chosen operator, and eight selected entry values. The target contains no route record, no final-state theorem, no resource theorem, and no general sparse-state algorithm. The direct block formula in the supplied provider determines the remaining entries mathematically; selected-entry certificates alone should not be described as a complete operator equality proved *in this target*.

## 6. Compact route target: dense, sparse, and identity-extended circuits

This target returns to namespace `QuantumBlockEncoding.StatePreparationBenchmarks`. Its `mottonenConditionalAngles`, `mottonenDenseUcryCircuit`, `sparseControlWire`, `sparseConditionalAngles`, and `sparsePrunedUcryCircuit` are literal aliases of the entry-certificate namespace objects; the two namespaces are not independent implementations. Its private explicit-β matrix helper again proves equality by checking the four entries.

### 6.1 Dense two-qubit route

`mottonenDensePrimitiveCircuit` is root `ry 1 ryAngle513` followed by the dense UCRy of Section 5. `mottonenRootState = (5/13)e0+(12/13)e2`, whose four private coordinate lemmas are `(5/13,0,12/13,0)`. `mottonenRootRy_col_zero` checks every row via LE singleton-Ry semantics, including the two zero-context cases. `mottonenRootRy_prepares` uses the zero-column lemma.

Private entry aliases import the four entry certificates; `mottonenZeroEntry` transports their context-mismatch rule. Helpers `_entry_02`, `_12`, `_20`, `_30` derive the cross-block zeros. Private `mottonenDenseUcry_scalar_0..3` evaluate

\[
 (5/13)U_{r,0}+(12/13)U_{r,2}
 = (39,52,60,144)_r/169.
\]

`mottonenDenseUcry_on_root` uses all four scalar equalities and the generic two-column superposition action. The positive transcript is

\[
 e_0 \longmapsto (5/13)e_0+(12/13)e_2
 \longmapsto (39e_0+52e_1+60e_2+144e_3)/169.
\]

The target state uses pattern matching on `index.val` with cases 0,1,2 and otherwise 144/169; because its carrier is `Fin 4`, that otherwise branch is exactly index 3, not an off-source arbitrary extension. `mottonenDenseTarget` chooses its squared-norm equation and unchanged String `"Möttönen-style dense two-qubit nested-Pythagorean benchmark"`. Its normalization identity is `(39²+52²+60²+144²)/169²=1`.

`mottonenDensePrimitive_prepares_target` composes the two actual circuit stages, and `mottonenDensePrimitiveRoute` fills the concrete target/circuit/normalization/preparation fields. `mottonenDenseVerified_cost` is `(0,5,4,0)`. More explicitly the five gates are, in execution order, root `Ry_1(β)`, `Ry_0((α+β)/2)`, `CX(1,0)`, `Ry_0((α-β)/2)`, `CX(1,0)`. The exact-angle syntax carries half sums/differences; a negative difference is allowed. The initial rotations on disjoint wires both receive depth layer 1 in the supplied resource model, so five gates have depth four.

### 6.2 General zero-angle identity, including its guards

`zeroAngleCompiledUcry_eval_eq_one` quantifies over arbitrary natural qubit/control counts, arbitrary wires mapping, target, and the target-distinctness guard; it sets *every* table entry to `ryAngleZero`. It asserts equality of the entire basis-indexed matrix with identity. Its proof uses the compiler-to-direct-block theorem and `standardRyMatrix_ryAngleZero`. If non-target contexts agree, equality of full basis rows is equivalent to equality of target bits by injectivity of the split equivalence; thus the block equals the identity entry. If contexts disagree, the basis rows are unequal and both the compiled entry and identity entry are zero. No injectivity among controls and no nonempty control set is assumed. No state or normalization premise is needed. This is an exact all-input operator statement, not a statement restricted to zero input.

### 6.3 Sparse three-qubit route

`sparsePrunedCircuit` is root `ry 2 ryAngle513` followed by the sparse UCRy of Section 5. `sparseRootState = (5/13)e0+(12/13)e4`. Its eight private coordinate lemmas give `(5/13,0,0,0,12/13,0,0,0)`. `sparseRootRy_col_zero` checks all eight rows under LE semantics, and `sparseRootRy_prepares` is its zero-input action.

The four private entry aliases use the entry-certificate theorem values. `sparseZeroEntry` is the arbitrary row/column context-mismatch adapter. Twelve concrete zero helpers cover rows `{1,3,4,5,6,7}` in column 0 and rows `{0,1,2,3,5,7}` in column 4. Together with `(0,0)=3/5`, `(2,0)=4/5`, `(4,4)=1`, and `(6,4)=0`, these determine the two columns actually used. Private `sparsePrunedUcry_scalar_0..7` compute

\[
 (5/13)U_{r,0}+(12/13)U_{r,4}
 = (3,0,4,0,12,0,0,0)_r/13.
\]

`sparsePrunedUcry_on_root` checks all eight output coordinates, and `sparsePruned_prepares_target` composes both stages. The positive transcript is

\[
 e_0\longmapsto (5/13)e_0+(12/13)e_4
 \longmapsto (3e_0+4e_2+12e_4)/13.
\]

Wire 0 is untouched and remains zero on this particular input, wire 2 selects the branch and is preserved by UCRy, and wire 1 receives the selected rotation. There is no discarded garbage branch. `sparseThreeState` explicitly returns 3/13 at 0, 4/13 at 2, 12/13 at 4, and zero at every other valid index. `sparseThreeTarget` uses the norm equation `(3²+4²+12²)/13²=1` and unchanged String `"Li--Luo sparse-state finite witness of Eq. (2), n=3 and d=3"`; that String is data, not evidence about a paper. `sparsePrunedRoute` supplies all concrete fields. Its list is `Ry_2(β); Ry_1(α/2); CX(2,1); Ry_1(α/2); CX(2,1)`, and `sparsePrunedVerified_cost` gives `(0,5,4,0)`.

### 6.4 Literal identity extension and the cost comparison

`sparseDenseControlWires : Fin 2 → Fin 3` sends control 0 to wire 1 and the other valid control (1) to wire 2; both differ from target 0, with a supplied finite proof. `sparseZeroFillCircuit` is the two-control UCRy compiler on target 0 with all angle-table entries zero. `sparseDenseTreeCircuit = sparsePrunedCircuit ++ sparseZeroFillCircuit`. This is an explicitly chosen extension by a compiled identity, regardless of the English name.

`sparseZeroFill_eval_eq_one` instantiates the general zero-angle theorem on the entire operator; `sparseZeroFill_evalLE_eq_one` reindexes this identity. `sparseDenseTree_evalLE_eq_pruned` uses append composition and identity multiplication to prove equality of the whole extended and pruned operators, not only agreement on zero input. Its final preparation theorem then reuses the pruned theorem. `sparseDenseTreeRoute` supplies the same concrete target and normalization with the extended circuit and its preparation proof.

The zero-fill compiler still emits four Ry gates with zero evaluated angles and six CNOTs. The full list of the extra stage is

`Ry_0(0); CX(2,0); Ry_0(0); CX(2,0); CX(1,0); Ry_0(0); CX(2,0); Ry_0(0); CX(2,0); CX(1,0)`.

Its exact-angle expression trees need not literally be the `ryAngleZero` constructor after recursive half sums/differences, but they all evaluate to zero. The extra list has ten entries; none are pruned by the compiler. `sparseDenseTreeVerified_cost` states `(0,15,13,0)`. Relative to final wire depths `(0,4,4)` of the pruned list, the zero-fill gate layers are `1,5,6,7,8,9,10,11,12,13`; this explains the final depth 13 without charging a purely serial depth of 15.

`sparsePruned_betterThan_denseTree` unfolds only the two concrete cost equalities and chooses the first disjunct of `betterThan`, namely `5 < 15`. It is a comparison of exactly these literal lists. It is not an optimality claim, a universal sparse-versus-dense separation, or a proof that all dense preparation algorithms contain this identity padding.

## 7. Resource-carrier expansion and all omitted cost obligations

`Resource` has Nat fields `oneQubit`, `cnot`, `oracleCalls`, `pureAncilla`, and `depth`, each defaulting to 0. `gates = oneQubit + cnot + oracleCalls`. `add` sums all five fields; `parallel` sums the first three and takes maxima for pure ancillas/depth; `scale` multiplies every field. The zero instance uses all defaults; HAdd is `add`. `ofCounts` explicitly sets its first two counts and pure ancillas, sets depth to their sum, and leaves oracleCalls at default zero; `ofCountsWithDepth` explicitly supplies all fields. These are bookkeeping definitions, not correctness theorems for arbitrary resource annotations.

Primitive per-gate one-qubit count is 1 for X/Ry/Rz and 0 for CNOT; two-qubit count is 1 for CNOT and 0 otherwise. The circuit counts sum those values, and `gateCount` separately means list length. Ry/CX count append/singleton lemmas justify compiler recurrences. `touched` is a singleton for a one-qubit gate and `{control,target}` for CNOT. From current wire depths, `nextWireDepth` takes the maximum over touched wires and assigns one greater to each touched wire, leaving other depths unchanged. `wireDepths` folds this from all zero; circuit depth is the maximum over all wires. This is an abstract all-to-all, unit-duration, dependency-layer model, not a hardware scheduling/synthesis theorem. It can assign an earlier layer to a later-listed gate on disjoint wires. It does not optimize away zero rotations or algebraically cancelling CNOTs.

`PrimitiveCircuit.resource` uses its one-/two-qubit counts, zero oracleCalls, zero pureAncilla, and this depth. Route `cost` constructs `BlockEncodingCost` with `auxiliaryQubits := 0`, gates from that resource, depth from that resource, and oracleCalls from that resource. The zero auxiliary count is explicit bookkeeping for a list on the stated data wires, not a generic theorem about allocation/cleanup of an unmodeled compiler workspace.

`BlockEncodingCost` is four natural fields with no defaults: auxiliaryQubits, gateCount, depth, oracleCalls. Its `betterThan x y` is strict lexicographic order on gateCount first, then depth, then auxiliaryQubits, then oracleCalls. Thus a smaller gate count suffices even if other fields were worse; it is not a componentwise/Pareto order. In the concrete comparison the other listed fields are also no larger, but that is not what the proof needs. All four cost equalities have `by decide` proof bodies in the supplied text; no decision procedure was executed by this decoder.

There is no charge here for computing angle tables, arccos/trigonometric evaluation, arbitrary-real representation, parameter bit lengths, numerical export, gate-set approximation, Clifford+T/T count, geometry/routing, circuit serialization, classical preprocessing, loading arbitrary state descriptions, measurement/readout, postselection, or amplification. No approximate error parameter is hidden in these exact statements. Zero oracle calls is a property of the modeled primitive list, not a claim that every classical construction ingredient is free in a separate oracle model.

## 8. Declaration/body and ambient-command coverage interpretation

The independent coverage file assigns each of the 140 target declarations a precise semantic description and body disposition. Private coordinate, entry, zero-context, and scalar helpers are individually inventoried; they are not skipped because the final root is short. Their proof roles are stated above and individually specialized in that record. Imports are recorded as boundaries. All namespace and open commands determine the identifier environment; all local simp attributes were read and included: Bell has no extra local simp commands, EntryCertificates adds bit/context simplifiers, and Compact additionally adds `Pi.single_apply`. No section variable, extra hypothesis, local axiom, option change, macro, or unrecorded target command appears in the read targets. The target route `where` fields have no omitted defaults: each sets target, circuit, normalizationProof, preparationProof explicitly. Provider structure defaults are expanded in Sections 2 and 7; all angle constructor guards and CNOT/control guards are expanded in Sections 2 and 3.

The exact namespaces remain distinct, and original Lean spellings are preserved. Private identifiers in the coverage file are their source spellings within the namespace; generated private elaborator names were not claimed. References from proof text establish the described implementation proof topology by reading, not an elaborated proof-term dependency graph. There is no purported source proof graph because no source was supplied to this decoder.

All visible definitions are literal formulas, finite-function pattern matches, expression syntax, explicit gate lists, records, or explicit equivalences. No choice/uniqueness-based definition or quotient representative is used by these target constructions. The state/matrix equalities are phase-sensitive, and no uniqueness of a quantum representative is asserted. The source strings remain unchanged data, not assumptions or independent provenance evidence.

## 9. Positive scope and remaining boundary at the stop point

Completed formal-text reconstruction:

- exact preparation of the three specified normalized vectors by the four specified routes (Bell, dense, sparse pruned, sparse identity-extended);
- a generic LE CNOT entry formula and the two chosen UCRy context/entry interfaces;
- a generic all-control-count zero-angle compiled-UCRy identity;
- supplied universal primitive unitarity, LE basis bridge, and UCRy compiler/block semantics with exact Ry/CNOT counts;
- the four fixed ideal-resource tuples and one strict lexicographic cost comparison;
- full private-helper, route-field, default, guard, and ambient-command reading within the supplied boundary.

Remaining, deliberately not performed or inferred:

- compilation/elaboration/kernel acceptance under any Lean/Mathlib version, transitive axiom audit, and repository integration;
- equivalence to any external source theorem, paper algorithm, equation, circuit diagram, assumption classification, or source resource bound;
- opaque-binding, independent source comparison, correction necessity/minimality, publication/schema acceptance, CI/registry/catalog updates, and final reader/purification admission;
- generic arbitrary-state, arbitrary-size dense/sparse state-preparation algorithm correctness and resource complexity, optimality/lower bounds, and any block-encoding consequence requiring additional SELECT/inverse/operator hypotheses;
- numerical/finite-bit implementation and uniform approximation/synthesis errors, classical construction costs, and physical hardware resources.

No mathematical route is retired, no acceptance verdict is issued, and no alternative construction is selected as a default verified route. The completed delta is a sealed, independent reconstruction of what the supplied formal text actually says. The next authorized stage would have to be assigned separately after this seal.
