# sp-extended-routes-c42-author — frozen AUTHOR/WIP packet

Scope: whole `StatePreparationBellRoute.lean` (305 lines, 37 explicit declarations),
`StatePreparationPaperEntryCertificates.lean` (185,18), and
`StatePreparationPaperRoutesCompact.lean` (696,85). Total 140 explicit declarations;
73 are private source declarations. Every explicit header and body is retained
and boundary-crosschecked. Compiler-generated projections/private mangled names
are not presented as an elaborated declaration inventory.

The source checkout is read-only. Its head was supplied by the parent as
`30fe1d77735221cb86fdfc39102c151c9527dc37` (Lean 4.33); this worker did not
run Git, network, Lean, Lake, native evaluation, kernel probes, registry,
catalog or production writes. All output is confined to this directory and
installed through apply_patch. Historical formalizer UNKNOWN; current author
role is implementation-informed retrospective contract extraction.

## Split tracks for fresh readers

- `formal-only/targets/`: all three complete comment-masked modules, with
  original identifiers, imports, strings and all proof/definition bodies.
- `formal-only/providers/`: narrow comment-masked exact-source context.
  Omitted provider source is replaced by position-preserving whitespace.
  `formal-only/extents/` gives exact selected source ranges, whole-source
  raw-byte hashes and retained explicit declarations. Original scope/import
  commands are retained in addition to ranges. This is not a self-contained
  compiling replacement project; imports still refer to the pinned substrate.
- `natural/`: author contract/proof, binder-definition classification,
  implementation-source coverage, full header/body inventory and four-view
  graph proposals. Do not supply this track to a source-blind decoder.
- `pins/`: 207 raw-byte proof input pins before/after, target bindings,
  equality checks and final export seal. The proof input set is 142 production
  Lean files + 60 ABEISTests Lean files + QuantumBlockEncoding.lean, Tests.lean,
  lakefile.lean, lean-toolchain and lake-manifest.json. This custom raw pin set
  is distinct from any repository publication `binding_digest` formula.

Use only `formal-only/` plus `pins/formal-track-manifest.json` for the fresh
decoder. Exact original identifiers and target `source : String` data can
contain historical names; these are retained formal data, not supplementary
source titles, desired conclusions, author classifications or review verdicts.
The packet is therefore formal-only with unavoidable in-code labels, not a
claim that all lexical cues have been anonymized. Do not rename or strip them.
The source reviewer should receive the pinned source and separately frozen
natural contract/reconstruction, without any previous verdict. No decoder,
reviewer, source acceptance, Proof Seal or Exposition Seal is fabricated here.

`build_packet.py` reads only the explicit target/provider allowlist, emits
JSON text, and performs no file writes. It contains two independent boundary
algorithms and synthetic tests for record-valued conclusions, structure/record
`where`, nested binders, and pattern definitions. It is source-text machinery,
not an elaborator. All prior intermediate failures were extractor issues
repaired before the final static report; they are not mathematical refutations.
