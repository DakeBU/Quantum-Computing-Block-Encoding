"""Read-only public-safe successor exporter/checker; emits JSON, writes nothing.

Supply original author root and successor root as command-line arguments.
The arguments are operational inputs only and are never emitted in artifacts.
No original script is executed. No source project, network, Lean or Git is used.
"""
from pathlib import Path
import hashlib
import json
import re
import sys

ORIGINAL_SEAL_SHA256 = '7c0575f82976ecfe5ff5d119071bd08d9d613a9909764c7753e3d3918e1ac940'
SOURCE_ROOT_LOGICAL = 'logical-root-v1://aspbe-pinned-source'
AUTHOR_ROOT_LOGICAL = 'logical-root-v1://sp-extended-routes-c42-author'
SUCCESSOR_ROOT_LOGICAL = 'logical-root-v1://sp-extended-routes-c43-publicsafe'
CONTROL_REPLACEMENTS = {
    'build_packet.py': 'runtime source-root configuration replaces a host-specific root; logical-root-v1 identifies the source role',
    'pins/proof-inputs-before.json': 'root metadata replaced by logical-root-v1 source identifier; all file pins unchanged',
    'pins/proof-inputs-after.json': 'root metadata replaced by logical-root-v1 source identifier; all file pins unchanged',
    'pins/export-seal.json': 'historical author output-root metadata replaced by logical-root-v1 author identifier; historical file table unchanged',
}

def sha(data): return hashlib.sha256(data).hexdigest()
def canonical(obj): return json.dumps(obj,ensure_ascii=True,sort_keys=True,separators=(',',':')).encode('utf-8')
def as_text(data):
    text = data.decode('utf-8')
    assert text.encode('utf-8') == data
    return text

def text_views(text):
    """Inspect raw, recursively JSON-decoded strings, slash escapes and Unicode escapes."""
    views = [text]
    try:
        obj = json.loads(text)
        def walk(x):
            if isinstance(x,str): views.append(x)
            elif isinstance(x,dict):
                for k,v in x.items(): walk(k); walk(v)
            elif isinstance(x,list):
                for v in x: walk(v)
        walk(obj)
    except (ValueError,TypeError): pass
    for t in list(views):
        for _ in range(4):
            normalized = re.sub(r'\\u([0-9a-fA-F]{4})',lambda m:chr(int(m.group(1),16)),t)
            normalized = normalized.replace('\\\\','\\').replace('\\/','/')
            if normalized==t: break
            views.append(normalized); t=normalized
    return views

def scan_text(text):
    # Report rule IDs/counts only; never echo a candidate credential/path value.
    rules = {
      'drive_user_root':re.compile(r'(?i)\b[A-Z]:[\\/]+(?:Users|Documents and Settings)[\\/]+'),
      'drive_absolute_root':re.compile(r'(?i)\b[CD]:[\\/]'),
      'hosted_runner_home':re.compile('/home/'+'runner'+r'(?:/|\b)'),
      'private_key_material':re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----'),
      'openai_secret_format':re.compile(r'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{16,}'),
      'github_secret_format':re.compile(r'\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})'),
      'aws_access_id_format':re.compile(r'\b(?:AKIA|ASIA)[0-9A-Z]{16}\b'),
      'google_api_key_format':re.compile(r'\bAIza[0-9A-Za-z_-]{30,}'),
      'slack_secret_format':re.compile(r'\bxox[baprs]-[0-9A-Za-z-]{20,}'),
      'jwt_token_format':re.compile(r'\beyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}'),
      'bearer_literal':re.compile(r'(?i)\bBearer\s+[A-Za-z0-9_\-.]{20,}'),
      'credential_assignment_literal':re.compile(r'''(?i)(?:api[_-]?key|access[_-]?token|auth[_-]?token|password|secret)\s*[:=]\s*["'][A-Za-z0-9_+/.=-]{20,}["']'''),
    }
    found = {}
    for name,pattern in rules.items():
        hits = {m.group() for view in text_views(text) for m in pattern.finditer(view)}
        if hits: found[name] = len(hits)
    return found

def originals(root):
    seal_path = root/'pins/export-seal.json'
    seal_bytes = seal_path.read_bytes()
    assert sha(seal_bytes)==ORIGINAL_SEAL_SHA256, 'original seal changed'
    seal = json.loads(seal_bytes)
    names = set(seal['allowed_paths']) | {'pins/export-seal.json'}
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    assert names == actual and len(names)==56, 'original allowlist changed'
    records = {r['path']:r for r in seal['files']}
    for name in sorted(names):
        data = (root/name).read_bytes()
        if name in records:
            assert sha(data)==records[name]['sha256'] and len(data)==records[name]['bytes'], ('original member changed',name)
        yield name,data

def transform(name,data):
    text = as_text(data)
    findings = scan_text(text)
    if not findings:
        assert name not in CONTROL_REPLACEMENTS, ('expected control root not found',name)
        return data,'byte-identical',findings
    if name not in CONTROL_REPLACEMENTS:
        # In particular, never rewrite Lean strings/identifiers/snapshots.
        return None,'QUARANTINED_NO_PUBLIC_MEMBER',findings
    assert set(findings) <= {'drive_user_root','drive_absolute_root'}, ('unexpected secret control finding',name)
    if name=='build_packet.py':
        text,count = re.subn(r"(?m)^ROOT = Path\('[^'\n]+'\)$",
          "ROOT = Path(__import__('os').environ['ASPBE_SOURCE_ROOT'])  # "+SOURCE_ROOT_LOGICAL,text)
        assert count==1
    else:
        field = 'output_root' if name=='pins/export-seal.json' else 'root'
        logical = AUTHOR_ROOT_LOGICAL if field=='output_root' else SOURCE_ROOT_LOGICAL
        pattern = r'(?m)^(  "'+field+r'": )"[^\n]*"(,?)$'
        text,count = re.subn(pattern,lambda m:m.group(1)+json.dumps(logical)+m.group(2),text)
        assert count==1
    assert not scan_text(text), ('replacement still unsafe',name)
    return text.encode('utf-8'),'versioned-logical-root-control-successor',findings

def mapping(original_root,successor_root):
    records=[]
    for name,data in originals(original_root):
        public,disposition,findings=transform(name,data)
        if public is not None:
            assert (successor_root/name).read_bytes()==public, ('successor bytes differ',name)
        records.append({'path':name,'original_sha256':sha(data),'original_bytes':len(data),
          'public_sha256':sha(public) if public is not None else None,
          'public_bytes':len(public) if public is not None else None,
          'disposition':disposition,'original_findings_rule_counts':findings,
          'change_reason':CONTROL_REPLACEMENTS.get(name) if disposition!='byte-identical' else None})
    return {'status':'PUBLIC_SAFE_CONTROL_SUCCESSOR_AUTHOR_WIP_NOT_ADMISSION',
      'schema':'logical-root-replacement-v1','original_seal_sha256':ORIGINAL_SEAL_SHA256,
      'original_root':AUTHOR_ROOT_LOGICAL,'successor_root':SUCCESSOR_ROOT_LOGICAL,
      'source_root':SOURCE_ROOT_LOGICAL,'original_members_verified_immutable':56,
      'byte_identical_members':sum(r['disposition']=='byte-identical' for r in records),
      'changed_control_members':sum(r['disposition']=='versioned-logical-root-control-successor' for r in records),
      'quarantined_members':[r['path'] for r in records if r['disposition']=='QUARANTINED_NO_PUBLIC_MEMBER'],
      'formal_identifiers_strings_and_snapshot_data_edited':False,'records':records}

def scan_members(root):
    rows=[]
    for p in sorted(root.rglob('*')):
        if p.is_file():
            name=p.relative_to(root).as_posix()
            findings=scan_text(as_text(p.read_bytes()))
            rows.append({'path':name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'findings_rule_counts':findings})
    assert all(not r['findings_rule_counts'] for r in rows), 'public member scan found a path/credential candidate'
    return rows

if __name__=='__main__':
    mode=sys.argv[1]; original_root=Path(sys.argv[2]); successor_root=Path(sys.argv[3])
    if mode=='inventory':
        rows=[]
        for n,d in originals(original_root):
            public,disposition,findings=transform(n,d)
            rows.append({'path':n,'original_sha256':sha(d),'disposition':disposition,'findings_rule_counts':findings})
        print(json.dumps(rows,ensure_ascii=False))
    elif mode=='member':
        name=sys.argv[4]
        data=dict(originals(original_root))[name]
        public,disposition,findings=transform(name,data)
        print(json.dumps({'path':name,'disposition':disposition,'content':as_text(public) if public is not None else None},ensure_ascii=False))
    elif mode=='map':
        print(json.dumps(mapping(original_root,successor_root),ensure_ascii=False,indent=2))
    elif mode=='scan':
        rows=scan_members(successor_root)
        print(json.dumps({'status':'STATIC_PUBLIC_MEMBER_SCAN_NOT_SEMANTIC_REVIEW','members_scanned':len(rows),
          'scan_views':['raw text','recursive decoded JSON keys and string values','repeated slash and Unicode escape normalization'],
          'rules':['drive user roots','absolute selected drive roots','hosted runner home root','private keys','recognizable API/GitHub/AWS/Google/Slack/JWT/Bearer credential patterns','literal credential assignments'],
          'all_file_types_scanned':True,'formal_source_strings_scanned_without_rewriting':True,
          'candidate_values_not_recorded':True,'findings':[],'members':rows},ensure_ascii=False,indent=2))
    elif mode=='final-check':
        provenance=mapping(original_root,successor_root)
        rows=scan_members(successor_root)
        seal_path=successor_root/'pins/publicsafe-export-seal.json'
        seal=json.loads(seal_path.read_bytes())
        actual={r['path']:r for r in rows if r['path']!='pins/publicsafe-export-seal.json'}
        assert set(actual)==set(seal['allowed_paths']) and len(actual)==seal['sealed_file_count']
        for r in seal['files']:
            assert actual[r['path']]['sha256']==r['sha256'] and actual[r['path']]['bytes']==r['bytes']
        assert sha(canonical(seal['files']))==seal['sha256_table_digest']
        print(json.dumps({'status':'FROZEN_PUBLICSAFE_STATIC_FINAL_CHECK_PASSED_NOT_ADMISSION',
          'original_artifacts_plus_original_seal_verified_unchanged':56,
          'original_members_byte_identical':provenance['byte_identical_members'],
          'changed_controls':provenance['changed_control_members'],
          'formal_data_quarantined':provenance['quarantined_members'],
          'public_members_scanned_including_new_seal':len(rows),'public_scan_findings':[],
          'current_seal_members_verified':len(actual),'new_seal_sha256':sha(seal_path.read_bytes()),
          'new_seal_table_digest':seal['sha256_table_digest'],
          'no_lean_native_kernel_execution':True,'no_admission_or_review_verdict':True},indent=2))
    elif mode=='seal':
        provenance=mapping(original_root,successor_root)
        assert not provenance['quarantined_members']
        rows=scan_members(successor_root)
        rows=[{k:v for k,v in r.items() if k!='findings_rule_counts'} for r in rows if r['path']!='pins/publicsafe-export-seal.json']
        expected={r['path'] for r in provenance['records']}|{'PUBLICSAFE-README.md','publicsafe_export.py','pins/publicsafe-provenance.json','pins/publicsafe-scan-report.json'}
        assert {r['path'] for r in rows}==expected, 'unexpected/missing public member'
        print(json.dumps({'status':'FROZEN_PUBLICSAFE_AUTHOR_WIP_NOT_ACCEPTED',
          'schema':'publicsafe-export-seal-v1','output_root':SUCCESSOR_ROOT_LOGICAL,
          'source_author_seal_sha256':ORIGINAL_SEAL_SHA256,'source_author_artifacts_unchanged':True,
          'logical_root_policy':'logical-root-replacement-v1','sealed_file_count':len(rows),
          'allowed_paths':[r['path'] for r in rows],'files':rows,
          'sha256_table_digest':sha(canonical(rows)),'seal_excludes_only_itself':True,
          'formal_and_natural_tracks_separate':True,'no_admission_or_review_verdict':True,
          'no_lean_native_kernel_execution':True,'all_preseal_members_scanned':True,
          'final_instruction':'scan every member including this new seal after installation; do not mutate frozen artifacts'},ensure_ascii=False,indent=2))
