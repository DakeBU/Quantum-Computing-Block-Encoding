# c43 public-safe control successor — AUTHOR/WIP

This is a separate successor to the frozen c42 author package. The original
55 artifacts and their original seal were read-only and were verified against
the original seal hashes. This successor preserves 52 original members
byte-for-byte. All formal target/provider snapshots, Lean identifiers, Lean
String data, natural contracts, exact declaration inventories and the original
formal-track manifest are unchanged. The formal-only and natural tracks remain
separate. There are no quarantined members: no formal-data path leak was found.

Only four original control members changed:

| control member | exact control change |
|---|---|
| `build_packet.py` | Replace the host-specific source-root assignment by explicit runtime `ASPBE_SOURCE_ROOT` configuration, annotated with `logical-root-v1://aspbe-pinned-source`. No extraction logic changes. |
| `pins/proof-inputs-before.json` | Replace only root metadata by that versioned logical source-root identifier; all 207 raw file pins remain unchanged. |
| `pins/proof-inputs-after.json` | Same root-metadata-only replacement; all 207 raw file pins remain unchanged. |
| `pins/export-seal.json` | Replace only the historical author output-root metadata by `logical-root-v1://sp-extended-routes-c42-author`; keep its historical 55-file table unchanged. |

`pins/publicsafe-provenance.json` gives original/public SHA256 and disposition
for every original member, including the old seal itself. Historical digest
references in byte-identical original reports and in the old seal still name
the original author bytes. They are not current c43 member hashes. Use the
provenance map for those correspondences and `pins/publicsafe-export-seal.json`
as the current successor seal. The unchanged `verify_packet.py` is a historical
author-checker, not the successor's seal validator; its old 55-member allowlist
does not authorize the successor's extra public-safe control records.

New control-only files are this guide, `publicsafe_export.py`, the provenance
map, the static public-member scan report and the new seal. The read-only
exporter receives original/successor roots at runtime and never emits those
operational argument values. It verifies the original seal and every original
member, derives only the four allowlisted replacements, compares all copied
bytes, scans every file type and constructs the new seal. It never executes
the original scripts or invokes Lean, Git, network, production or registry tools.

The scan checks raw text, recursively decoded JSON keys/String values, repeated
slash escapes and Unicode escapes, including scripts and Lean source strings.
It checks actual user/drive roots, hosted-runner home roots and recognizable
private-key/API/GitHub/AWS/Google/Slack/JWT/Bearer or literal-assignment credential
patterns. Bare programming identifiers such as `token` in the declaration
scanner are not credential values. Findings are reported only by rule/count,
never by echoing a candidate secret or local path. Pattern-based scanning is
not a guarantee against every imaginable unknown credential encoding.

The stored scan report is the pre-seal scan snapshot and explicitly precedes
its own installation and the new seal. A final read-only scan also covers
those two installed members; the delivered handoff reports that result. The
new seal excludes only itself to avoid a recursive content hash. Its logical
output root is `logical-root-v1://sp-extended-routes-c43-publicsafe`.

All mathematical/source/independence limitations of the author package remain.
This is a path-safe control export, not admission, a source-review verdict,
independent decoding evidence, or a new Lean/native/kernel claim. Any later
regeneration from runtime host roots must be scanned again before publication.
