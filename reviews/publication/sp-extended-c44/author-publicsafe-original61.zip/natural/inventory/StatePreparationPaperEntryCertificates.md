# Exact source-text declaration inventory: StatePreparationPaperEntryCertificates

AUTHOR/WIP. Explicit names are source identifiers, not compiler-resolved private names. Headers and bodies are separately preserved in the adjacent JSON. No elaboration was run.

## standardRyMatrix_ryAngle35_explicit

Source lines 23–31; private theorem.

```lean
private theorem standardRyMatrix_ryAngle35_explicit :
    standardRyMatrix ryAngle35.eval =
      realOrthogonalRotation ((3 : Real) / 5) ((4 : Real) / 5)
```

## standardRyMatrix_ryAngle513_explicit

Source lines 33–41; private theorem.

```lean
private theorem standardRyMatrix_ryAngle513_explicit :
    standardRyMatrix ryAngle513.eval =
      realOrthogonalRotation ((5 : Real) / 13) ((12 : Real) / 13)
```

## mottonenConditionalAngles

Source lines 43–44; public def.

```lean
noncomputable def mottonenConditionalAngles (bits : PrimitiveBasis 1) : ExactAngle
```

## mottonenDenseUcryCircuit

Source lines 46–48; public def.

```lean
noncomputable def mottonenDenseUcryCircuit : PrimitiveCircuit 2
```

## mottonenDenseUcry_entry_zero_of_context_ne

Source lines 50–58; public theorem.

```lean
theorem mottonenDenseUcry_entry_zero_of_context_ne
    (row column : Fin (gridSize 2))
    (contextNe :
      (splitPrimitiveWire (0 : Fin 2) (primitiveLEBits 2 row)).2 ≠
        (splitPrimitiveWire (0 : Fin 2) (primitiveLEBits 2 column)).2) :
    evalPrimitiveCircuitLE mottonenDenseUcryCircuit row column = 0
```

## mottonenDenseUcry_entry_00

Source lines 60–71; public theorem.

```lean
theorem mottonenDenseUcry_entry_00 :
    evalPrimitiveCircuitLE mottonenDenseUcryCircuit (0 : Fin 4) (0 : Fin 4) =
      (3 : ℂ) / 5
```

## mottonenDenseUcry_entry_10

Source lines 73–84; public theorem.

```lean
theorem mottonenDenseUcry_entry_10 :
    evalPrimitiveCircuitLE mottonenDenseUcryCircuit (1 : Fin 4) (0 : Fin 4) =
      (4 : ℂ) / 5
```

## mottonenDenseUcry_entry_22

Source lines 86–97; public theorem.

```lean
theorem mottonenDenseUcry_entry_22 :
    evalPrimitiveCircuitLE mottonenDenseUcryCircuit (2 : Fin 4) (2 : Fin 4) =
      (5 : ℂ) / 13
```

## mottonenDenseUcry_entry_32

Source lines 99–110; public theorem.

```lean
theorem mottonenDenseUcry_entry_32 :
    evalPrimitiveCircuitLE mottonenDenseUcryCircuit (3 : Fin 4) (2 : Fin 4) =
      (12 : ℂ) / 13
```

## sparseControlWire

Source lines 112–112; public def.

```lean
def sparseControlWire : Fin 1 → Fin 3
```

## sparseControlWire_ne_target

Source lines 114–118; public theorem.

```lean
theorem sparseControlWire_ne_target :
    ∀ control, sparseControlWire control ≠ (1 : Fin 3)
```

## sparseConditionalAngles

Source lines 120–121; public def.

```lean
noncomputable def sparseConditionalAngles (bits : PrimitiveBasis 1) : ExactAngle
```

## sparsePrunedUcryCircuit

Source lines 123–125; public def.

```lean
noncomputable def sparsePrunedUcryCircuit : PrimitiveCircuit 3
```

## sparsePrunedUcry_entry_zero_of_context_ne

Source lines 127–135; public theorem.

```lean
theorem sparsePrunedUcry_entry_zero_of_context_ne
    (row column : Fin (gridSize 3))
    (contextNe :
      (splitPrimitiveWire (1 : Fin 3) (primitiveLEBits 3 row)).2 ≠
        (splitPrimitiveWire (1 : Fin 3) (primitiveLEBits 3 column)).2) :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit row column = 0
```

## sparsePrunedUcry_entry_00

Source lines 137–148; public theorem.

```lean
theorem sparsePrunedUcry_entry_00 :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit (0 : Fin 8) (0 : Fin 8) =
      (3 : ℂ) / 5
```

## sparsePrunedUcry_entry_20

Source lines 150–161; public theorem.

```lean
theorem sparsePrunedUcry_entry_20 :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit (2 : Fin 8) (0 : Fin 8) =
      (4 : ℂ) / 5
```

## sparsePrunedUcry_entry_44

Source lines 163–172; public theorem.

```lean
theorem sparsePrunedUcry_entry_44 :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit (4 : Fin 8) (4 : Fin 8) = 1
```

## sparsePrunedUcry_entry_64

Source lines 174–183; public theorem.

```lean
theorem sparsePrunedUcry_entry_64 :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit (6 : Fin 8) (4 : Fin 8) = 0
```

