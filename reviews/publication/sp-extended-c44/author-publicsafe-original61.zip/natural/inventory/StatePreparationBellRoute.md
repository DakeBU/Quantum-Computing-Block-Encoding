# Exact source-text declaration inventory: StatePreparationBellRoute

AUTHOR/WIP. Explicit names are source identifiers, not compiler-resolved private names. Headers and bodies are separately preserved in the adjacent JSON. No elaboration was run.

## bellRyAngle

Source lines 18–19; public def.

```lean
noncomputable def bellRyAngle : ExactAngle
```

## bellRyAngle_eval

Source lines 21–24; public theorem.

```lean
theorem bellRyAngle_eval : bellRyAngle.eval = Real.pi / 2
```

## standardRyMatrix_bellRyAngle

Source lines 26–29; public theorem.

```lean
theorem standardRyMatrix_bellRyAngle :
    standardRyMatrix bellRyAngle.eval = Robin.warmRobinUniformBitPrepare
```

## bellControl

Source lines 31–31; public def.

```lean
def bellControl : Fin 2
```

## bellTargetWire

Source lines 33–33; public def.

```lean
def bellTargetWire : Fin 2
```

## bellControl_ne_target

Source lines 35–36; public theorem.

```lean
theorem bellControl_ne_target : bellControl ≠ bellTargetWire
```

## bellRyCircuit

Source lines 38–39; public def.

```lean
noncomputable def bellRyCircuit : PrimitiveCircuit 2
```

## bellCxCircuit

Source lines 41–42; public def.

```lean
noncomputable def bellCxCircuit : PrimitiveCircuit 2
```

## bellPrimitiveCircuit

Source lines 44–45; public def.

```lean
noncomputable def bellPrimitiveCircuit : PrimitiveCircuit 2
```

## bellAfterRy

Source lines 47–49; public def.

```lean
noncomputable def bellAfterRy : StateVector 4 ℂ
```

## evalPrimitiveCircuitLE_singleton_cx_apply

Source lines 51–60; public theorem.

```lean
@[simp] theorem evalPrimitiveCircuitLE_singleton_cx_apply
    {qubits : Nat} (control target : Fin qubits) (distinct : control ≠ target)
    (row column : Fin (gridSize qubits)) :
    evalPrimitiveCircuitLE ([PrimitiveGate.cx control target distinct]) row column =
      if primitiveLEBits qubits row =
          cxBasisEquiv control target distinct (primitiveLEBits qubits column)
      then 1 else 0
```

## bellAfterRy_0

Source lines 62–64; private theorem.

```lean
private theorem bellAfterRy_0 :
    bellAfterRy (0 : Fin 4) = bellAmplitude
```

## bellAfterRy_1

Source lines 66–68; private theorem.

```lean
private theorem bellAfterRy_1 :
    bellAfterRy (1 : Fin 4) = bellAmplitude
```

## bellAfterRy_2

Source lines 70–74; private theorem.

```lean
private theorem bellAfterRy_2 :
    bellAfterRy (2 : Fin 4) = 0
```

## bellAfterRy_3

Source lines 76–80; private theorem.

```lean
private theorem bellAfterRy_3 :
    bellAfterRy (3 : Fin 4) = 0
```

## bellRy_entry_00

Source lines 82–94; private theorem.

```lean
private theorem bellRy_entry_00 :
    evalPrimitiveCircuitLE bellRyCircuit (0 : Fin 4) (0 : Fin 4) =
      bellAmplitude
```

## bellRy_entry_10

Source lines 96–108; private theorem.

```lean
private theorem bellRy_entry_10 :
    evalPrimitiveCircuitLE bellRyCircuit (1 : Fin 4) (0 : Fin 4) =
      bellAmplitude
```

## bellRy_entry_20

Source lines 110–117; private theorem.

```lean
private theorem bellRy_entry_20 :
    evalPrimitiveCircuitLE bellRyCircuit (2 : Fin 4) (0 : Fin 4) = 0
```

## bellRy_entry_30

Source lines 119–126; private theorem.

```lean
private theorem bellRy_entry_30 :
    evalPrimitiveCircuitLE bellRyCircuit (3 : Fin 4) (0 : Fin 4) = 0
```

## bellRy_col_zero

Source lines 128–143; public theorem.

```lean
theorem bellRy_col_zero :
    (evalPrimitiveCircuitLE bellRyCircuit).col (0 : Fin 4) = bellAfterRy
```

## bellRy_prepares

Source lines 145–148; public theorem.

```lean
theorem bellRy_prepares :
    applyVec (evalPrimitiveCircuitLE bellRyCircuit) (zeroKet 2) = bellAfterRy
```

## bellCx_entry_00

Source lines 150–157; private theorem.

```lean
private theorem bellCx_entry_00 :
    evalPrimitiveCircuitLE bellCxCircuit (0 : Fin 4) (0 : Fin 4) = 1
```

## bellCx_entry_10

Source lines 159–166; private theorem.

```lean
private theorem bellCx_entry_10 :
    evalPrimitiveCircuitLE bellCxCircuit (1 : Fin 4) (0 : Fin 4) = 0
```

## bellCx_entry_20

Source lines 168–175; private theorem.

```lean
private theorem bellCx_entry_20 :
    evalPrimitiveCircuitLE bellCxCircuit (2 : Fin 4) (0 : Fin 4) = 0
```

## bellCx_entry_30

Source lines 177–184; private theorem.

```lean
private theorem bellCx_entry_30 :
    evalPrimitiveCircuitLE bellCxCircuit (3 : Fin 4) (0 : Fin 4) = 0
```

## bellCx_entry_01

Source lines 186–193; private theorem.

```lean
private theorem bellCx_entry_01 :
    evalPrimitiveCircuitLE bellCxCircuit (0 : Fin 4) (1 : Fin 4) = 0
```

## bellCx_entry_11

Source lines 195–202; private theorem.

```lean
private theorem bellCx_entry_11 :
    evalPrimitiveCircuitLE bellCxCircuit (1 : Fin 4) (1 : Fin 4) = 0
```

## bellCx_entry_21

Source lines 204–211; private theorem.

```lean
private theorem bellCx_entry_21 :
    evalPrimitiveCircuitLE bellCxCircuit (2 : Fin 4) (1 : Fin 4) = 0
```

## bellCx_entry_31

Source lines 213–220; private theorem.

```lean
private theorem bellCx_entry_31 :
    evalPrimitiveCircuitLE bellCxCircuit (3 : Fin 4) (1 : Fin 4) = 1
```

## bellCx_output_0

Source lines 222–231; private theorem.

```lean
private theorem bellCx_output_0 :
    (bellAmplitude • (evalPrimitiveCircuitLE bellCxCircuit).col (0 : Fin 4) +
      bellAmplitude • (evalPrimitiveCircuitLE bellCxCircuit).col (1 : Fin 4))
        (0 : Fin 4) = bellState (0 : Fin 4)
```

## bellCx_output_1

Source lines 233–242; private theorem.

```lean
private theorem bellCx_output_1 :
    (bellAmplitude • (evalPrimitiveCircuitLE bellCxCircuit).col (0 : Fin 4) +
      bellAmplitude • (evalPrimitiveCircuitLE bellCxCircuit).col (1 : Fin 4))
        (1 : Fin 4) = bellState (1 : Fin 4)
```

## bellCx_output_2

Source lines 244–253; private theorem.

```lean
private theorem bellCx_output_2 :
    (bellAmplitude • (evalPrimitiveCircuitLE bellCxCircuit).col (0 : Fin 4) +
      bellAmplitude • (evalPrimitiveCircuitLE bellCxCircuit).col (1 : Fin 4))
        (2 : Fin 4) = bellState (2 : Fin 4)
```

## bellCx_output_3

Source lines 255–264; private theorem.

```lean
private theorem bellCx_output_3 :
    (bellAmplitude • (evalPrimitiveCircuitLE bellCxCircuit).col (0 : Fin 4) +
      bellAmplitude • (evalPrimitiveCircuitLE bellCxCircuit).col (1 : Fin 4))
        (3 : Fin 4) = bellState (3 : Fin 4)
```

## bellCx_on_afterRy

Source lines 266–279; public theorem.

```lean
theorem bellCx_on_afterRy :
    applyVec (evalPrimitiveCircuitLE bellCxCircuit) bellAfterRy = bellState
```

## bellPrimitive_prepares_target

Source lines 281–292; public theorem.

```lean
theorem bellPrimitive_prepares_target :
    applyVec (evalPrimitiveCircuitLE bellPrimitiveCircuit) (zeroKet 2) =
      bellTarget.amplitudes
```

## bellPrimitiveRoute

Source lines 294–298; public def.

```lean
noncomputable def bellPrimitiveRoute : ExactPrimitiveStatePreparationRoute 2
```

## bellVerified_cost

Source lines 300–303; public theorem.

```lean
theorem bellVerified_cost :
    bellPrimitiveRoute.cost =
      { auxiliaryQubits := 0, gateCount := 2, depth := 2, oracleCalls := 0 }
```

