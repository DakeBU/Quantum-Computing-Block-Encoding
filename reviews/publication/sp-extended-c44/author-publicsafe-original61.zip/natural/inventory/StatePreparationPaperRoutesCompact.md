# Exact source-text declaration inventory: StatePreparationPaperRoutesCompact

AUTHOR/WIP. Explicit names are source identifiers, not compiler-resolved private names. Headers and bodies are separately preserved in the adjacent JSON. No elaboration was run.

## standardRyMatrix_ryAngle513_explicit_paper

Source lines 25–33; private theorem.

```lean
private theorem standardRyMatrix_ryAngle513_explicit_paper :
    standardRyMatrix ryAngle513.eval =
      realOrthogonalRotation ((5 : Real) / 13) ((12 : Real) / 13)
```

## mottonenConditionalAngles

Source lines 37–38; public def.

```lean
noncomputable def mottonenConditionalAngles : PrimitiveBasis 1 → ExactAngle
```

## mottonenDenseUcryCircuit

Source lines 40–41; public def.

```lean
noncomputable def mottonenDenseUcryCircuit : PrimitiveCircuit 2
```

## mottonenDensePrimitiveCircuit

Source lines 43–44; public def.

```lean
noncomputable def mottonenDensePrimitiveCircuit : PrimitiveCircuit 2
```

## mottonenRootState

Source lines 46–48; public def.

```lean
noncomputable def mottonenRootState : StateVector 4 ℂ
```

## mottonenRootState_0

Source lines 50–52; private theorem.

```lean
private theorem mottonenRootState_0 :
    mottonenRootState (0 : Fin 4) = (5 : ℂ) / 13
```

## mottonenRootState_1

Source lines 54–56; private theorem.

```lean
private theorem mottonenRootState_1 :
    mottonenRootState (1 : Fin 4) = 0
```

## mottonenRootState_2

Source lines 58–60; private theorem.

```lean
private theorem mottonenRootState_2 :
    mottonenRootState (2 : Fin 4) = (12 : ℂ) / 13
```

## mottonenRootState_3

Source lines 62–64; private theorem.

```lean
private theorem mottonenRootState_3 :
    mottonenRootState (3 : Fin 4) = 0
```

## mottonenRootRy_col_zero

Source lines 66–106; public theorem.

```lean
theorem mottonenRootRy_col_zero :
    (evalPrimitiveCircuitLE [PrimitiveGate.ry (1 : Fin 2) ryAngle513]).col
        (0 : Fin 4) = mottonenRootState
```

## mottonenRootRy_prepares

Source lines 108–113; public theorem.

```lean
theorem mottonenRootRy_prepares :
    applyVec
        (evalPrimitiveCircuitLE [PrimitiveGate.ry (1 : Fin 2) ryAngle513])
        (zeroKet 2) = mottonenRootState
```

## mottonenDenseUcry_entry_00

Source lines 115–119; private theorem.

```lean
private theorem mottonenDenseUcry_entry_00 :
    evalPrimitiveCircuitLE mottonenDenseUcryCircuit (0 : Fin 4) (0 : Fin 4) =
      (3 : ℂ) / 5
```

## mottonenDenseUcry_entry_10

Source lines 121–125; private theorem.

```lean
private theorem mottonenDenseUcry_entry_10 :
    evalPrimitiveCircuitLE mottonenDenseUcryCircuit (1 : Fin 4) (0 : Fin 4) =
      (4 : ℂ) / 5
```

## mottonenDenseUcry_entry_22

Source lines 127–131; private theorem.

```lean
private theorem mottonenDenseUcry_entry_22 :
    evalPrimitiveCircuitLE mottonenDenseUcryCircuit (2 : Fin 4) (2 : Fin 4) =
      (5 : ℂ) / 13
```

## mottonenDenseUcry_entry_32

Source lines 133–137; private theorem.

```lean
private theorem mottonenDenseUcry_entry_32 :
    evalPrimitiveCircuitLE mottonenDenseUcryCircuit (3 : Fin 4) (2 : Fin 4) =
      (12 : ℂ) / 13
```

## mottonenZeroEntry

Source lines 139–146; private theorem.

```lean
private theorem mottonenZeroEntry (row column : Fin 4)
    (h :
      (splitPrimitiveWire (0 : Fin 2) (primitiveLEBits 2 row)).2 ≠
        (splitPrimitiveWire (0 : Fin 2) (primitiveLEBits 2 column)).2) :
    evalPrimitiveCircuitLE mottonenDenseUcryCircuit row column = 0
```

## mottonenDenseUcry_entry_02

Source lines 148–150; private theorem.

```lean
private theorem mottonenDenseUcry_entry_02 :
    evalPrimitiveCircuitLE mottonenDenseUcryCircuit (0 : Fin 4) (2 : Fin 4) = 0
```

## mottonenDenseUcry_entry_12

Source lines 152–154; private theorem.

```lean
private theorem mottonenDenseUcry_entry_12 :
    evalPrimitiveCircuitLE mottonenDenseUcryCircuit (1 : Fin 4) (2 : Fin 4) = 0
```

## mottonenDenseUcry_entry_20

Source lines 156–158; private theorem.

```lean
private theorem mottonenDenseUcry_entry_20 :
    evalPrimitiveCircuitLE mottonenDenseUcryCircuit (2 : Fin 4) (0 : Fin 4) = 0
```

## mottonenDenseUcry_entry_30

Source lines 160–162; private theorem.

```lean
private theorem mottonenDenseUcry_entry_30 :
    evalPrimitiveCircuitLE mottonenDenseUcryCircuit (3 : Fin 4) (0 : Fin 4) = 0
```

## mottonenDenseUcry_scalar_0

Source lines 164–169; private theorem.

```lean
private theorem mottonenDenseUcry_scalar_0 :
    (5 / 13 : ℂ) * evalPrimitiveCircuitLE mottonenDenseUcryCircuit (0 : Fin 4) (0 : Fin 4) +
      (12 / 13 : ℂ) * evalPrimitiveCircuitLE mottonenDenseUcryCircuit (0 : Fin 4) (2 : Fin 4) =
      (39 : ℂ) / 169
```

## mottonenDenseUcry_scalar_1

Source lines 171–176; private theorem.

```lean
private theorem mottonenDenseUcry_scalar_1 :
    (5 / 13 : ℂ) * evalPrimitiveCircuitLE mottonenDenseUcryCircuit (1 : Fin 4) (0 : Fin 4) +
      (12 / 13 : ℂ) * evalPrimitiveCircuitLE mottonenDenseUcryCircuit (1 : Fin 4) (2 : Fin 4) =
      (52 : ℂ) / 169
```

## mottonenDenseUcry_scalar_2

Source lines 178–183; private theorem.

```lean
private theorem mottonenDenseUcry_scalar_2 :
    (5 / 13 : ℂ) * evalPrimitiveCircuitLE mottonenDenseUcryCircuit (2 : Fin 4) (0 : Fin 4) +
      (12 / 13 : ℂ) * evalPrimitiveCircuitLE mottonenDenseUcryCircuit (2 : Fin 4) (2 : Fin 4) =
      (60 : ℂ) / 169
```

## mottonenDenseUcry_scalar_3

Source lines 185–190; private theorem.

```lean
private theorem mottonenDenseUcry_scalar_3 :
    (5 / 13 : ℂ) * evalPrimitiveCircuitLE mottonenDenseUcryCircuit (3 : Fin 4) (0 : Fin 4) +
      (12 / 13 : ℂ) * evalPrimitiveCircuitLE mottonenDenseUcryCircuit (3 : Fin 4) (2 : Fin 4) =
      (144 : ℂ) / 169
```

## mottonenDenseUcry_on_root

Source lines 192–236; public theorem.

```lean
theorem mottonenDenseUcry_on_root :
    applyVec (evalPrimitiveCircuitLE mottonenDenseUcryCircuit) mottonenRootState =
      mottonenDenseState
```

## mottonenDensePrimitive_prepares_target

Source lines 238–251; public theorem.

```lean
theorem mottonenDensePrimitive_prepares_target :
    applyVec (evalPrimitiveCircuitLE mottonenDensePrimitiveCircuit) (zeroKet 2) =
      mottonenDenseTarget.amplitudes
```

## mottonenDensePrimitiveRoute

Source lines 253–258; public def.

```lean
noncomputable def mottonenDensePrimitiveRoute :
    ExactPrimitiveStatePreparationRoute 2
```

## mottonenDenseVerified_cost

Source lines 260–263; public theorem.

```lean
theorem mottonenDenseVerified_cost :
    mottonenDensePrimitiveRoute.cost =
      { auxiliaryQubits := 0, gateCount := 5, depth := 4, oracleCalls := 0 }
```

## zeroAngleCompiledUcry_eval_eq_one

Source lines 267–295; public theorem.

```lean
theorem zeroAngleCompiledUcry_eval_eq_one
    {qubits controls : Nat}
    (wires : Fin controls → Fin qubits) (target : Fin qubits)
    (distinct : ∀ control, wires control ≠ target) :
    evalPrimitiveCircuit
        (compileUniformlyControlledRy controls wires target distinct
          (fun _ => ryAngleZero)) = 1
```

## sparseControlWire

Source lines 299–300; public def.

```lean
def sparseControlWire : Fin 1 → Fin 3
```

## sparseControlWire_ne_target

Source lines 302–305; public theorem.

```lean
theorem sparseControlWire_ne_target :
    ∀ control, sparseControlWire control ≠ (1 : Fin 3)
```

## sparseConditionalAngles

Source lines 307–308; public def.

```lean
noncomputable def sparseConditionalAngles : PrimitiveBasis 1 → ExactAngle
```

## sparsePrunedUcryCircuit

Source lines 310–311; public def.

```lean
noncomputable def sparsePrunedUcryCircuit : PrimitiveCircuit 3
```

## sparsePrunedCircuit

Source lines 313–314; public def.

```lean
noncomputable def sparsePrunedCircuit : PrimitiveCircuit 3
```

## sparseRootState

Source lines 316–318; public def.

```lean
noncomputable def sparseRootState : StateVector 8 ℂ
```

## sparseRootState_0

Source lines 320–321; private theorem.

```lean
private theorem sparseRootState_0 : sparseRootState (0 : Fin 8) = (5 : ℂ) / 13
```

## sparseRootState_1

Source lines 322–323; private theorem.

```lean
private theorem sparseRootState_1 : sparseRootState (1 : Fin 8) = 0
```

## sparseRootState_2

Source lines 324–325; private theorem.

```lean
private theorem sparseRootState_2 : sparseRootState (2 : Fin 8) = 0
```

## sparseRootState_3

Source lines 326–327; private theorem.

```lean
private theorem sparseRootState_3 : sparseRootState (3 : Fin 8) = 0
```

## sparseRootState_4

Source lines 328–329; private theorem.

```lean
private theorem sparseRootState_4 : sparseRootState (4 : Fin 8) = (12 : ℂ) / 13
```

## sparseRootState_5

Source lines 330–331; private theorem.

```lean
private theorem sparseRootState_5 : sparseRootState (5 : Fin 8) = 0
```

## sparseRootState_6

Source lines 332–333; private theorem.

```lean
private theorem sparseRootState_6 : sparseRootState (6 : Fin 8) = 0
```

## sparseRootState_7

Source lines 334–335; private theorem.

```lean
private theorem sparseRootState_7 : sparseRootState (7 : Fin 8) = 0
```

## sparseRootRy_col_zero

Source lines 337–405; public theorem.

```lean
theorem sparseRootRy_col_zero :
    (evalPrimitiveCircuitLE [PrimitiveGate.ry (2 : Fin 3) ryAngle513]).col
        (0 : Fin 8) = sparseRootState
```

## sparseRootRy_prepares

Source lines 407–412; public theorem.

```lean
theorem sparseRootRy_prepares :
    applyVec
        (evalPrimitiveCircuitLE [PrimitiveGate.ry (2 : Fin 3) ryAngle513])
        (zeroKet 3) = sparseRootState
```

## sparsePrunedUcry_entry_00

Source lines 414–418; private theorem.

```lean
private theorem sparsePrunedUcry_entry_00 :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit (0 : Fin 8) (0 : Fin 8) =
      (3 : ℂ) / 5
```

## sparsePrunedUcry_entry_20

Source lines 420–424; private theorem.

```lean
private theorem sparsePrunedUcry_entry_20 :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit (2 : Fin 8) (0 : Fin 8) =
      (4 : ℂ) / 5
```

## sparsePrunedUcry_entry_44

Source lines 426–429; private theorem.

```lean
private theorem sparsePrunedUcry_entry_44 :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit (4 : Fin 8) (4 : Fin 8) = 1
```

## sparsePrunedUcry_entry_64

Source lines 431–434; private theorem.

```lean
private theorem sparsePrunedUcry_entry_64 :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit (6 : Fin 8) (4 : Fin 8) = 0
```

## sparseZeroEntry

Source lines 436–443; private theorem.

```lean
private theorem sparseZeroEntry (row column : Fin 8)
    (h :
      (splitPrimitiveWire (1 : Fin 3) (primitiveLEBits 3 row)).2 ≠
        (splitPrimitiveWire (1 : Fin 3) (primitiveLEBits 3 column)).2) :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit row column = 0
```

## sparsePrunedUcry_entry_10

Source lines 445–447; private theorem.

```lean
private theorem sparsePrunedUcry_entry_10 :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit (1 : Fin 8) (0 : Fin 8) = 0
```

## sparsePrunedUcry_entry_30

Source lines 448–450; private theorem.

```lean
private theorem sparsePrunedUcry_entry_30 :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit (3 : Fin 8) (0 : Fin 8) = 0
```

## sparsePrunedUcry_entry_40

Source lines 451–453; private theorem.

```lean
private theorem sparsePrunedUcry_entry_40 :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit (4 : Fin 8) (0 : Fin 8) = 0
```

## sparsePrunedUcry_entry_50

Source lines 454–456; private theorem.

```lean
private theorem sparsePrunedUcry_entry_50 :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit (5 : Fin 8) (0 : Fin 8) = 0
```

## sparsePrunedUcry_entry_60

Source lines 457–459; private theorem.

```lean
private theorem sparsePrunedUcry_entry_60 :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit (6 : Fin 8) (0 : Fin 8) = 0
```

## sparsePrunedUcry_entry_70

Source lines 460–462; private theorem.

```lean
private theorem sparsePrunedUcry_entry_70 :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit (7 : Fin 8) (0 : Fin 8) = 0
```

## sparsePrunedUcry_entry_04

Source lines 463–465; private theorem.

```lean
private theorem sparsePrunedUcry_entry_04 :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit (0 : Fin 8) (4 : Fin 8) = 0
```

## sparsePrunedUcry_entry_14

Source lines 466–468; private theorem.

```lean
private theorem sparsePrunedUcry_entry_14 :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit (1 : Fin 8) (4 : Fin 8) = 0
```

## sparsePrunedUcry_entry_24

Source lines 469–471; private theorem.

```lean
private theorem sparsePrunedUcry_entry_24 :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit (2 : Fin 8) (4 : Fin 8) = 0
```

## sparsePrunedUcry_entry_34

Source lines 472–474; private theorem.

```lean
private theorem sparsePrunedUcry_entry_34 :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit (3 : Fin 8) (4 : Fin 8) = 0
```

## sparsePrunedUcry_entry_54

Source lines 475–477; private theorem.

```lean
private theorem sparsePrunedUcry_entry_54 :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit (5 : Fin 8) (4 : Fin 8) = 0
```

## sparsePrunedUcry_entry_74

Source lines 478–480; private theorem.

```lean
private theorem sparsePrunedUcry_entry_74 :
    evalPrimitiveCircuitLE sparsePrunedUcryCircuit (7 : Fin 8) (4 : Fin 8) = 0
```

## sparsePrunedUcry_scalar_0

Source lines 482–487; private theorem.

```lean
private theorem sparsePrunedUcry_scalar_0 :
    (5 / 13 : ℂ) * evalPrimitiveCircuitLE sparsePrunedUcryCircuit (0 : Fin 8) (0 : Fin 8) +
      (12 / 13 : ℂ) * evalPrimitiveCircuitLE sparsePrunedUcryCircuit (0 : Fin 8) (4 : Fin 8) =
      (3 : ℂ) / 13
```

## sparsePrunedUcry_scalar_1

Source lines 489–493; private theorem.

```lean
private theorem sparsePrunedUcry_scalar_1 :
    (5 / 13 : ℂ) * evalPrimitiveCircuitLE sparsePrunedUcryCircuit (1 : Fin 8) (0 : Fin 8) +
      (12 / 13 : ℂ) * evalPrimitiveCircuitLE sparsePrunedUcryCircuit (1 : Fin 8) (4 : Fin 8) = 0
```

## sparsePrunedUcry_scalar_2

Source lines 495–500; private theorem.

```lean
private theorem sparsePrunedUcry_scalar_2 :
    (5 / 13 : ℂ) * evalPrimitiveCircuitLE sparsePrunedUcryCircuit (2 : Fin 8) (0 : Fin 8) +
      (12 / 13 : ℂ) * evalPrimitiveCircuitLE sparsePrunedUcryCircuit (2 : Fin 8) (4 : Fin 8) =
      (4 : ℂ) / 13
```

## sparsePrunedUcry_scalar_3

Source lines 502–506; private theorem.

```lean
private theorem sparsePrunedUcry_scalar_3 :
    (5 / 13 : ℂ) * evalPrimitiveCircuitLE sparsePrunedUcryCircuit (3 : Fin 8) (0 : Fin 8) +
      (12 / 13 : ℂ) * evalPrimitiveCircuitLE sparsePrunedUcryCircuit (3 : Fin 8) (4 : Fin 8) = 0
```

## sparsePrunedUcry_scalar_4

Source lines 508–513; private theorem.

```lean
private theorem sparsePrunedUcry_scalar_4 :
    (5 / 13 : ℂ) * evalPrimitiveCircuitLE sparsePrunedUcryCircuit (4 : Fin 8) (0 : Fin 8) +
      (12 / 13 : ℂ) * evalPrimitiveCircuitLE sparsePrunedUcryCircuit (4 : Fin 8) (4 : Fin 8) =
      (12 : ℂ) / 13
```

## sparsePrunedUcry_scalar_5

Source lines 515–519; private theorem.

```lean
private theorem sparsePrunedUcry_scalar_5 :
    (5 / 13 : ℂ) * evalPrimitiveCircuitLE sparsePrunedUcryCircuit (5 : Fin 8) (0 : Fin 8) +
      (12 / 13 : ℂ) * evalPrimitiveCircuitLE sparsePrunedUcryCircuit (5 : Fin 8) (4 : Fin 8) = 0
```

## sparsePrunedUcry_scalar_6

Source lines 521–525; private theorem.

```lean
private theorem sparsePrunedUcry_scalar_6 :
    (5 / 13 : ℂ) * evalPrimitiveCircuitLE sparsePrunedUcryCircuit (6 : Fin 8) (0 : Fin 8) +
      (12 / 13 : ℂ) * evalPrimitiveCircuitLE sparsePrunedUcryCircuit (6 : Fin 8) (4 : Fin 8) = 0
```

## sparsePrunedUcry_scalar_7

Source lines 527–531; private theorem.

```lean
private theorem sparsePrunedUcry_scalar_7 :
    (5 / 13 : ℂ) * evalPrimitiveCircuitLE sparsePrunedUcryCircuit (7 : Fin 8) (0 : Fin 8) +
      (12 / 13 : ℂ) * evalPrimitiveCircuitLE sparsePrunedUcryCircuit (7 : Fin 8) (4 : Fin 8) = 0
```

## sparsePrunedUcry_on_root

Source lines 533–611; public theorem.

```lean
theorem sparsePrunedUcry_on_root :
    applyVec (evalPrimitiveCircuitLE sparsePrunedUcryCircuit) sparseRootState = sparseThreeState
```

## sparsePruned_prepares_target

Source lines 613–626; public theorem.

```lean
theorem sparsePruned_prepares_target :
    applyVec (evalPrimitiveCircuitLE sparsePrunedCircuit) (zeroKet 3) =
      sparseThreeTarget.amplitudes
```

## sparsePrunedRoute

Source lines 628–632; public def.

```lean
noncomputable def sparsePrunedRoute : ExactPrimitiveStatePreparationRoute 3
```

## sparseDenseControlWires

Source lines 634–636; public def.

```lean
def sparseDenseControlWires : Fin 2 → Fin 3
```

## sparseDenseControlWires_ne_target

Source lines 638–641; public theorem.

```lean
theorem sparseDenseControlWires_ne_target :
    ∀ control, sparseDenseControlWires control ≠ (0 : Fin 3)
```

## sparseZeroFillCircuit

Source lines 643–645; public def.

```lean
noncomputable def sparseZeroFillCircuit : PrimitiveCircuit 3
```

## sparseDenseTreeCircuit

Source lines 647–648; public def.

```lean
noncomputable def sparseDenseTreeCircuit : PrimitiveCircuit 3
```

## sparseZeroFill_eval_eq_one

Source lines 650–654; public theorem.

```lean
theorem sparseZeroFill_eval_eq_one :
    evalPrimitiveCircuit sparseZeroFillCircuit = 1
```

## sparseZeroFill_evalLE_eq_one

Source lines 656–660; public theorem.

```lean
theorem sparseZeroFill_evalLE_eq_one :
    evalPrimitiveCircuitLE sparseZeroFillCircuit = 1
```

## sparseDenseTree_evalLE_eq_pruned

Source lines 662–667; public theorem.

```lean
theorem sparseDenseTree_evalLE_eq_pruned :
    evalPrimitiveCircuitLE sparseDenseTreeCircuit =
      evalPrimitiveCircuitLE sparsePrunedCircuit
```

## sparseDenseTree_prepares_target

Source lines 669–673; public theorem.

```lean
theorem sparseDenseTree_prepares_target :
    applyVec (evalPrimitiveCircuitLE sparseDenseTreeCircuit) (zeroKet 3) =
      sparseThreeTarget.amplitudes
```

## sparseDenseTreeRoute

Source lines 675–679; public def.

```lean
noncomputable def sparseDenseTreeRoute : ExactPrimitiveStatePreparationRoute 3
```

## sparsePrunedVerified_cost

Source lines 681–684; public theorem.

```lean
theorem sparsePrunedVerified_cost :
    sparsePrunedRoute.cost =
      { auxiliaryQubits := 0, gateCount := 5, depth := 4, oracleCalls := 0 }
```

## sparseDenseTreeVerified_cost

Source lines 686–689; public theorem.

```lean
theorem sparseDenseTreeVerified_cost :
    sparseDenseTreeRoute.cost =
      { auxiliaryQubits := 0, gateCount := 15, depth := 13, oracleCalls := 0 }
```

## sparsePruned_betterThan_denseTree

Source lines 691–694; public theorem.

```lean
theorem sparsePruned_betterThan_denseTree :
    sparsePrunedRoute.cost.betterThan sparseDenseTreeRoute.cost
```

