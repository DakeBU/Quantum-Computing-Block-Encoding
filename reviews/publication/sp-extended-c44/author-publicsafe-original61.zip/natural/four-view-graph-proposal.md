# Four distinct views — AUTHOR_PROPOSED, not accepted graph evidence

This is a retrospective graph of the fixed local constructions. It must not
be re-labelled an independently reconstructed proof graph of Möttönen or
Li--Luo. The source nodes below expand losslessly to all 140 declarations
in `inventory/*.json`, and all 1,186 source lines are disposed by
`coverage/*.json`. Source imports/scope/attributes and prose have separate
envelope nodes; blank lines alone are EXCLUDED. A line-complete partition
does not prove semantic completeness. A fresh reviewer must check it.

## 1. Implementation Source Proof / Construction Graph

Notation `{A,B,C} ⇒ D` is one AND hyperedge: every tail is required.
`RouteA OR RouteB ⇒ Goal` gives alternative sufficient constructions, not
independent sufficiency of each AND ingredient inside a route. Names in
backticks are exact source identifiers (namespaces are in the inventories).
Each finite coordinate family includes every listed coordinate, not only a
representative row. The following complete prerequisite sets are conceptual
mathematical proposals; actual Lean proof-term dependencies are not inferred.

### Common substrate S

S1 = complex matrix/vector finite-sum action and delta basis kets.
S2 = LE equivalence (q0 least significant), its finite 2/3-wire reductions,
splitPrimitiveWire equivalence and complete non-target-context equality.
S3 = exact RY half-angle/sign convention and exact α,β,γ,0 evaluations.
S4 = CX bit permutation with distinct wires, primitive list append semantics,
generic primitive unitarity and reindexing preservation of unitarity.
S5 = recursive UCRY compiler's full block specification including half-sum /
half-difference arithmetic and fixed non-target context.
S6 = typed circuit list resource counts, wire-depth scheduler, route cost
projection and complete lexicographic cost definition.
S7 = literal target vectors and their actual ΣnormSq=1 predicates/proofs.

These are reused, not reimplemented. Their narrow code extents and original
imports are in the formal track. Only the generic singleton CX formula and
constant-zero UCRY identity are additional generic results in the targets.

### Bell AND tails

- `{S3, bellRyAngle=piRational(1/2)}` ⇒ `bellRyAngle_eval` ⇒ exact γ matrix.
- `{S1,S2,S3, bellRyCircuit, all four bellRy_entry_00/10/20/30,
  all four bellAfterRy_0/1/2/3}` ⇒ `bellRy_col_zero`.
- `{bellRy_col_zero, S1's zero-input/column identity}` ⇒ `bellRy_prepares`.
- `{S2,S4, bellControl=0, bellTargetWire=1, bellControl_ne_target}` ⇒
  `evalPrimitiveCircuitLE_singleton_cx_apply` specialized to these wires and
  all eight `bellCx_entry_00/10/20/30/01/11/21/31`.
- `{those eight entries, bellState's literal coordinates, S1 arithmetic}` ⇒
  all four `bellCx_output_0/1/2/3`.
- `{those four outputs, bellAfterRy's literal two-term vector, S1 linearity}`
  ⇒ `bellCx_on_afterRy`.
- `{bellPrimitiveCircuit=bellRyCircuit++bellCxCircuit, S4 append semantics,
  S1 composition, bellRy_prepares, bellCx_on_afterRy}` ⇒
  `bellPrimitive_prepares_target`.
- `{that action, S7 Bell normalization, literal typed list/target}` ⇒
  `bellPrimitiveRoute`; `{that list,S6}` ⇒ `bellVerified_cost`.

The generic singleton CX theorem itself depends on the generic bit-permutation
semantics, not on a specific Bell root, and is not circularly justified by
Bell's finite entries. Its generic statement is separate from specialization.

### EntryCertificates: full scalar layer

- `{S3 α/β identities, exact rational-to-real coercions}` ⇒ the two private
  `standardRyMatrix_ryAngle35_explicit` / `_ryAngle513_explicit`.
- `{literal branch α/β function, control q1 distinct from target q0, S2,S5}`
  ⇒ the M full-context-mismatch zero theorem; with S3/coercions and fixed
  row/column reductions ⇒ all entries 00,10,22,32.
- `{literal sparse control q2 distinct from target q1, literal α/0 branch
  function, S2,S5}` ⇒ the S full-context-mismatch zero theorem; with S3 and
  fixed row/column reductions ⇒ entries 00,20,44,64.

Those are exact symbolic finite equalities, not simulation observations.
Context mismatch is an explicit conditional premise of the zero-entry
providers; every finite use supplies the mismatch witness inside its proof.

### Dense M fixed route AND tails

- `{S2,S3 β identity, root RY_q1, literal root vector, its four coordinates}`
  ⇒ `mottonenRootRy_col_zero`; together with S1 ⇒
  `mottonenRootRy_prepares`.
- `{four EntryCertificates entries, literal alias equality}` ⇒ Compact
  private entries 00,10,22,32.
- `{EntryCertificates mismatch theorem, literal alias equality}` ⇒
  `mottonenZeroEntry`; with four actual context mismatches ⇒ entries
  02,12,20,30.
- For every r=0,1,2,3, `{U[r,0],U[r,2], rational arithmetic}` ⇒
  `mottonenDenseUcry_scalar_r` with exactly (39,52,60,144)/169.
- `{all four scalar lemmas, literal χ_M and ψ_M, S1 coordinate linearity}`
  ⇒ `mottonenDenseUcry_on_root`.
- `{root preparation, UCRY-on-root action, exact concatenated list,
  S4 append and S1 composition}` ⇒ `mottonenDensePrimitive_prepares_target`.
- `{exact action,S7 norm-square proof,literal target/list}` ⇒ route record;
  `{literal list,S6}` ⇒ `mottonenDenseVerified_cost`.

The private `_explicit_paper` β matrix lemma is reused by the finite root
RY proofs. It is not an extra mathematical angle model and has no paper
novelty claim. None of these edges goes through the separate quaternion
unitary completion except that the target definition/normalization are shared.

### Sparse AND tails and preserved actual OR routes

- `{S2,S3 β identity, root RY_q2, literal χ_S, all eight coordinates}` ⇒
  `sparseRootRy_col_zero`; with S1 ⇒ `sparseRootRy_prepares`.
- `{four EntryCertificates entries, literal aliases}` ⇒ Compact private
  entries 00,20,44,64.
- `{EntryCertificates full mismatch theorem,literal alias}` ⇒
  `sparseZeroEntry`; with each actual mismatch ⇒ all twelve private
  entries 10,30,40,50,60,70,04,14,24,34,54,74.
- For every r=0,…,7, `{U[r,0],U[r,4],rational arithmetic}` ⇒ scalar_r;
  `{all eight scalars,literal χ_S and ψ_S,S1 linearity}` ⇒
  `sparsePrunedUcry_on_root`.
- `{root preparation,UCRY-on-root,exact concatenated list,S4 append,
  S1 composition}` ⇒ `sparsePruned_prepares_target`.
- `{that action,S7 norm-square proof,literal target/list}` ⇒
  `sparsePrunedRoute`; `{list,S6}` ⇒ `sparsePrunedVerified_cost`.
- `{S5 full compiler specification,S3 RY(0)=I,S2 split equivalence,
  both equal-context and unequal-context cases}` ⇒
  `zeroAngleCompiledUcry_eval_eq_one` for arbitrary typed wires/controls.
- `{generic identity,ordered control tuple(q1,q2),target q0,both proved
  wire inequalities,literal constant-zero angle table}` ⇒
  `sparseZeroFill_eval_eq_one`; `{this,S2 reindex I=I}` ⇒
  `sparseZeroFill_evalLE_eq_one`.
- `{that full identity,exact dense-tree concatenation,S4 append}` ⇒
  `sparseDenseTree_evalLE_eq_pruned` (complete operator equality).
- `{that equality,sparsePruned_prepares_target}` ⇒
  `sparseDenseTree_prepares_target`; `{action,S7,literal list}` ⇒
  `sparseDenseTreeRoute`; `{dense-tree list,S6}` ⇒
  `sparseDenseTreeVerified_cost`.
- `{both exact tuples,complete betterThan definition,5<15}` ⇒
  `sparsePruned_betterThan_denseTree` via the first disjunct.

Algorithmic sufficiency: `pruned construction OR dense-tree construction`
prepares ψ_S. The current proof of dense-tree correctness uses the pruned
construction plus an operator identity (AND). This difference between proof
reuse and alternative circuit witnesses must survive graph compression.
Also the full lexicographic resource predicate is an OR of matched AND-tail
branches; lower gate count is the chosen branch here, not the definition.

### Explicit source gaps / exclusions

- External-paper theorem, equation, circuit, proof paragraph, citation and
  general resource coverage: SOURCE_GAP, not inventoried from unread papers.
- General arbitrary complex-vector preparation, phase-loading construction,
  arbitrary sparse support compiler and arbitrary-width state-preparation
  resource families: SOURCE_GAP for any such proposed advertisement.
- Equality of the primitive full operator with Bell/quaternion/sparse matrix
  completions: not asserted by these targets. No edge is drawn.
- Clifford+T/finite-bit angle compilation, arithmetic/runtime/preprocessing,
  connectivity, oracle generation and readout: not supplied; SOURCE_GAP if
  a wider cost claim is requested, outside this finite logical gate contract.
- Blank source lines: EXCLUDED(no mathematical content). No helper, `where`
  record body, local binding, actual OR proof, or operator-to-state bridge is
  excluded merely because it is private or convenient to omit.

## 2. Lean Dependency Graph: exact imports vs unproved finer edges

Exact direct target imports:

| module | local module imports | upstream |
|---|---|---|
| BellRoute | StatePreparationPrimitiveRoutes | Mathlib.Tactic |
| PaperEntryCertificates | StatePreparationPrimitiveRoutes | Mathlib.Tactic |
| PaperRoutesCompact | StatePreparationPrimitiveRoutes; PaperEntryCertificates | Mathlib.Tactic |

Module ownership is exact source inventory ownership. Private names in this
packet are original source identifiers, not Lean's generated private names.
Each complete theorem body and proof-local binding remains available in the
inventory/formal sources. No elaborated dependency exporter was run, so every
proposed declaration-level edge above is a mathematical author proposal or
lexical reference signal, not a new compiler-certified dependency edge.
Mathlib matrix multiplication, block/reindex identities, unitary group facts,
trigonometric identities and finite-coordinate arithmetic are upstream library
uses; paper labels are not local theorem dependencies. The imported primitive
substrate is reused without reading other workers' review material.

## 3. Compressed Quantum Spine with lossless expansion

`concept:sp-c42-le-register-semantics` expands to S1,S2 plus all per-coordinate
root-state helpers. `concept:sp-c42-exact-pythagorean-rotations` expands to
S3 and both explicit-coercion helper families. `concept:sp-c42-ucry-context`
expands to S5, both entry modules' mismatch/entry families, and all their
Compact aliases. `concept:sp-c42-sparse-linearity-composition` expands to
every scalar lemma, two-basis linearity, append semantics and all preparation
roots. `concept:sp-c42-identity-padding-alternative` expands to the generic
identity, its two reindex specializations, full operator equality and the
dense-tree state-action bridge. `concept:sp-c42-logical-resource-order`
expands to S6, all four tuple theorems and the complete betterThan proof.

None is yet a reviewed compressed node. These fold implementation bookkeeping
for presentation only; the original leaves, hypotheses and carrier/basis
adapters remain in the inventories. Existing substrate comprises almost all
matrix/circuit foundations. Bookkeeping comprises finite coordinates, coercions,
alias wrappers, record assembly and resource arithmetic. Candidate reusable
nodes are the generic singleton-CX LE entry formula and zero-angle compiled
UCRY full identity. New local topology is fixed RY+UCRY preparation and
identity-padding comparison, not a claim of mathematical historical novelty.

Purification PENDING: the Compact aliases and repeated β coercion helper are
review candidates for exposition compression, not permission to delete them
from whole-module evidence or silently change production. No dead-code,
import-minimality or elapsed elaboration-cost claim is made without its gate.

## 4. Functor Hypergraph: conditional transports, never formal category claims

H1 (operator→state): AND tails = {same carrier, same LE basis/phase convention,
full operator equality U=V, actual proof V|0⟩=ψ}. Head = U|0⟩=ψ. Formula
is substitution into matrix action. Actual local candidate substrate is
`sparseDenseTree_evalLE_eq_pruned` + `sparsePruned_prepares_target` →
`sparseDenseTree_prepares_target`. Failure boundary: a single matching
distribution, target label, or different global/relative phase is insufficient.
Review: PENDING. No claim that equal prepared states imply equal operators.

H2 (finite entries→fixed state): AND tails = {literal sparse input Σ_j a_j|j⟩,
exact required matrix entries on every input-support column and every output
row, complex matrix-vector linearity, literal output target identification}.
Head = exact action on this input. Formula `(Uχ)_r=Σ_j a_j U[r,j]`.
Hypothesis map retains all support coefficients/columns and all output rows;
conclusion map is fixed-state action only. Failure boundary: omitting zero
rows, wrong LE order, phase loss, or promising arbitrary-input operator
equality from just selected columns. Candidate substrates are the four Bell,
four M and eight S output families. Review: PENDING.

H3 (semantic identity padding): AND tails = {actual typed lists A,B on same
wires, chronological append denotation, full U(B)=I, A's exact action and
normalization, separately computed resources for A and A++B}. Heads = same
target state, full U(A++B)=U(A), and a matched-cost comparison when its
lexicographic premises hold. Failure boundary: semantic identity does not
give zero instruction cost; zero angles/canceling gates remain counted.
Substrate = generic zero UCRY + sparseZeroFill + dense-tree equality/costs.
Review: PENDING. No claim of categorical functor laws.

H4 (state action→proof-bearing route): AND tails = {literal target with
expanded real norm-square predicate, proof of this predicate, actual typed
circuit, exact action under same convention, generic circuit unitarity,
literal list resource interpretation}. Head = finite normalized primitive
route with its exact ideal logical cost. Failure boundary: an arbitrary Prop
named normalization, a circuit label without semantics, an independently
chosen matrix completion, or finite-bit costs not supplied by these tails.
Substrates = all four exact route records and the single shared provider API.
Review: PENDING. No SP→arbitrary-BE edge, BE→SP edge or SELECT access is
invented; their additional assumptions/costs are outside this dependency group.
