# Complete declaration/binder/definition audit guide — AUTHOR/WIP

Read the three `audit/*.json` records together with the identically named
`inventory/*.json` and `inventory/*.md`. There is one audit row for each of
the 37 + 18 + 85 = 140 explicit target declarations, including all 73 private
declarations. Every row preserves the complete source header and its digest,
full definition/proof body binding, exact source extent, logical inputs,
definition kind if applicable, local let/have names and the natural proof
expansion section. The JSON inventory contains full bodies, not tactic-name
summaries. There are no target-level structures/inductives, section variables,
notation definitions or typeclass instances to omit; the record-valued route
definitions still contain their complete `where` bodies. Necessary provider
structures, inductive exact angles/gates and their original field types remain
in the formal excerpts.

The names in `local_let_have_names` are diagnostic lists, not substitutes for
the complete bodies: anonymous `have`, case witnesses, local functions and
dependent proof terms remain in full body text even if a simple named-local
regex does not separately name them. There is no claim of elaborated closure
or compiler-generated declaration discovery. Both body boundary algorithms
were tested over every explicit target declaration and against hand-fixed
source-order expected-name lists. The header is not split on a nested `:=`
inside record-valued conclusions. A definition stops its header before its
top-level `where`, `:=`, or first equation-pattern `|`; its full body stays
separate. Cost theorems therefore retain their entire record literal in the
conclusion.

## Logical input disposition

These classifications are relative to the explicitly fixed original finite
or generic local construction contract, not unread external papers:

| family | logical inputs | disposition |
|---|---|---|
| every fixed preparation root and cost theorem | none outside the fixed closed construction | no producer theorem moved into a binder |
| generic singleton CX entry formula | control≠target | SOURCE, wire separation in its original local statement |
| generic constant-zero UCRY identity | ∀control,wires control≠target | SOURCE, same primitive typing/semantic constraint, no hidden injectivity |
| M/S context-mismatch zero-entry suppliers and private wrappers | exact full splitPrimitiveWire context inequality | SOURCE for this conditional provider statement; discharged at every finite use |
| dimensions, Fin wire indices, row/column indices, angle and tuple carriers | mathematical carrier data | TYPING |
| `∀ control` in wire-distinctness conclusions | output quantifier, not assumed theorem | retained complete, no SOURCE input invented |

No human-approved correction/RULED input, extra theorem premise/EXCESS input,
or separately asserted source-wide STANDING convention is introduced. This
is not an independent verdict that any paper theorem's hypotheses are matched:
the external-paper correspondence field is explicitly UNREVIEWED in every
audit row. A future paper Anchor must reconstruct/compare its actual statement
before retaining the SOURCE label in that different source scope.

## Provider bundle expansion

`StatePreparationTarget` contains an amplitude function, a normalization Prop,
and a source string. Its general type does not force that Prop to mean unit
norm. The three literal targets in scope instantiate it with the actual
Σ normSq = 1 formula, and their supplied normalization proofs are dependencies.
`ExactPrimitiveStatePreparationRoute` adds the actual typed list, proof of
that concrete normalization and exact U_LE(list)|0^n⟩=target.amplitudes.
Its generic unitarity theorem follows from every typed gate's unitary matrix.
Its cost uses the actual list resource, not a presentation-only circuit.

`PrimitiveBasis`, `splitPrimitiveWire`, `primitiveBasisLEEquiv` and the typed
Fin carriers fix register interpretation; no silently chosen tensor order or
change-of-basis representative is left free. `ExactAngle` syntax has exact
real evaluation; the rational arccos constructors include actual boundedness
proofs. α,β use nonnegative sine derived from arccos and the Pythagorean
normalization, not a free sign choice. `BlockEncodingCost.betterThan` retains
its full gate/depth/auxiliary/oracle lexicographic disjunction.

## Definition disposition

All introduced target definitions are LITERAL relative to this retrospectively
sealed finite contract, including aliases to provider definitions. The finite
carrier makes `if`/`match` branches exhaustive on valid indices: the final
M coordinate branch refers to index 3 only, and sparse zero branches are
intentional absent-support amplitudes. There is no off-valid-locus extension
used to invent paper semantics. Proof-bearing route records are literal
assemblies, not classical-choice definitions. No characterized unique object
or quotient/representative is introduced. Nonunique unitary completions in the
existing benchmark provider are not identified with primitive circuit operators
just because their first columns agree.

## Source coverage and purification boundary

Every source line is assigned NODE or EXCLUDED(blank). Declaration nodes include
every actual theorem/definition body. Nondeclaration import/scope/attribute
lines are envelope NODEs. Authored module/section comments are NODEs to be
checked against the finite scope, not external-paper proof evidence. All
substantive formulas and transformations are expanded by the math contract
and four-view graph. There are no omitted local citations to promote here;
paper names and the source-string Eq. (2) label remain unverified metadata.

This is proposed implementation-source coverage only. Independent source
topology, independent source-blind reconstruction, independent comparison,
post-merge purification and Exposition Seal are PENDING. Wrapper-only aliases
and duplicate explicit-coercion helpers are possible reader-compression
candidates; they were not deleted, merged, compiled or declared dead by this
worker. Preserve generic CX and zero-UCRY lemmas and the full operator→state
bridge during any later cleanup.
