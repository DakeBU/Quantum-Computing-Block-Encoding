"""Read-only extraction; emits JSON patches as data, never writes files or runs Lean.

This is a bounded source-text inventory, not an elaborator or proof-term exporter.
All generated local files are installed by the caller through apply_patch.
"""
from pathlib import Path
import hashlib
import json
import re
import sys

ROOT = Path(__import__('os').environ['ASPBE_SOURCE_ROOT'])  # logical-root-v1://aspbe-pinned-source
TARGETS = ['StatePreparationBellRoute', 'StatePreparationPaperEntryCertificates',
           'StatePreparationPaperRoutesCompact']
PROVIDERS = {
 'StatePreparationPrimitiveRoutes': [(1, 189), (316, 316)],
 'StatePreparationBenchmarksCoreFixed': [(1, 39), (92, 108), (255, 270), (342, 342)],
 'ConcreteSemantics': [(1, 109), (296, 297)],
 'StatePreparation': [(1, 23), (105, 105)],
 'Core': [(1, 15), (44, 44), (243, 243)],
 'BlockEncoding': [(1, 1), (50, 56), (57, 57), (70, 79), (83, 83)],
 'Resources': [(1, 74), (93, 93), (152, 152)],
 'PrimitiveCircuit': [(1, 205), (229, 229)],
 'PrimitiveSemantics': [(1, 404), (493, 493)],
 'PrimitiveBasisLE': [(1, 38), (48, 212)],
 'UniformlyControlledRy': [(1, 402), (422, 422)],
 'Robin/ComplexLCU': [(1, 120), (148, 165), (401, 401)],
 'Robin/Hadamard8Verified': [(1, 3), (28, 30)],
 'TextbookStatePreparation': [(1, 1), (104, 114)],
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def masked(text):
    """Mask nested Lean comments; preserve all character positions/newlines/strings."""
    chars = list(text)
    i = 0
    depth = 0
    string = False
    line = False
    while i < len(text):
        pair = text[i:i+2]
        if line:
            if text[i] == '\n':
                line = False
            else:
                chars[i] = ' '
            i += 1
        elif depth:
            if pair == '/-':
                chars[i:i+2] = [' ', ' ']
                depth += 1
                i += 2
            elif pair == '-/':
                chars[i:i+2] = [' ', ' ']
                depth -= 1
                i += 2
            else:
                if text[i] not in '\r\n': chars[i] = ' '
                i += 1
        elif string:
            if text[i] == '\\': i += 2
            elif text[i] == '"': string = False; i += 1
            else: i += 1
        elif pair == '--':
            chars[i:i+2] = [' ', ' ']; line = True; i += 2
        elif pair == '/-':
            chars[i:i+2] = [' ', ' ']; depth = 1; i += 2
        elif text[i] == '"': string = True; i += 1
        else: i += 1
    assert depth == 0 and not string
    return ''.join(chars)

DECL = re.compile(r'(?m)^(?:@\[[^\n]*\]\s*)?(?:(?:private|protected|noncomputable|unsafe)\s+)*(?P<kind>theorem|lemma|def|abbrev|structure|inductive|opaque|axiom)\s+(?P<name>[^\s:({]+)')
COMMAND = re.compile(r'(?m)^(?:import|namespace|end|open|attribute|set_option|variable|universe|section)\b')

def split_one(command, start):
    stack = []
    pairs = {'(':')','{':'}','[':']','⦃':'⦄','⟨':'⟩'}
    i = start
    while i < len(command):
        c = command[i]
        if c == '"':
            i += 1
            while i < len(command):
                if command[i] == '\\': i += 2
                elif command[i] == '"': i += 1; break
                else: i += 1
            continue
        if c in pairs: stack.append(pairs[c])
        elif stack and c == stack[-1]: stack.pop()
        elif not stack:
            if command[i:i+2] == ':=': return i, ':='
            if re.match(r'where\b', command[i:]): return i, 'where'
            if c == '|' and not command[command.rfind('\n',0,i)+1:i].strip(): return i, '|'
        i += 1
    raise AssertionError('missing body delimiter: ' + command[:100])

def split_two(command, start):
    """Independent token-based header boundary check, including record-valued conclusions."""
    stack = []
    pairs = {'(':')','{':'}','[':']','⦃':'⦄','⟨':'⟩'}
    tokens = re.finditer(r'"(?:\\.|[^"\\])*"|:=|\bwhere\b|[(){}\[\]⦃⦄⟨⟩]|[^\s(){}\[\]⦃⦄⟨⟩]+', command[start:])
    for t in tokens:
        v = t.group()
        if v in pairs: stack.append(pairs[v])
        elif stack and v == stack[-1]: stack.pop()
        elif not stack and v in (':=', 'where', '|'): return start + t.start(), v
    raise AssertionError('independent missing delimiter')

def regression():
    samples = [
      ('theorem t (r : C) : r.cost = { auxiliaryQubits := 0, gateCount := 2 } := by rfl', ':=', 'by rfl'),
      ('noncomputable def r : C 2 where\n  target := t\n  circuit := c', 'where', 'target := t'),
      ('def f (x : {y : Nat // y = 2}) : Nat := x.val', ':=', 'x.val'),
      ('structure C (n : Nat) where\n  value : Fin n\n  proof : value.val < n', 'where', 'value : Fin n'),
      ('def f : Fin 2 → Nat\n  | 0 => 1\n  | _ => 2', '|', '0 => 1'),
    ]
    for s, delim, body in samples:
        m = DECL.match(s); a = split_one(s, m.end()); b = split_two(s, m.end())
        assert a == b and a[1] == delim and s[a[0]+len(delim):].strip().startswith(body)
    assert masked('/- x /- y -/ z -/\ndef t := "-- /-" -- z\n') == '                 \ndef t := "-- /-"     \n'
    return len(samples)

def source(name):
    path = ROOT / 'QuantumBlockEncoding' / (name + '.lean')
    raw = path.read_bytes()
    text = raw.decode('utf-8')
    assert '\x00' not in text
    return raw, text, masked(text)

def inventory(name):
    raw, text, clean = source(name)
    matches = list(DECL.finditer(clean))
    boundaries = sorted([m.start() for m in matches] + [m.start() for m in COMMAND.finditer(clean)] + [len(clean)])
    ns = 'QuantumBlockEncoding.' + ('StatePreparationPaperEntryCertificates' if name.endswith('EntryCertificates') else 'StatePreparationBenchmarks')
    rows = []
    for m in matches:
        end = min(x for x in boundaries if x > m.start())
        command = clean[m.start():end].rstrip()
        raw_command = text[m.start():m.start()+len(command)]
        d, token = split_one(command, m.end()-m.start())
        assert (d, token) == split_two(command, m.end()-m.start())
        header = command[:d].rstrip(); body = command[d+len(token):].strip()
        assert body and header + command[len(header):] == command
        assert (header + command[len(header):d] + token + command[d+len(token):]) == command
        line_start = clean.count('\n', 0, m.start()) + 1
        line_end = clean.count('\n', 0, m.start()+len(command)) + 1
        locals_ = [{'kind':x.group(1), 'name':x.group(2), 'line':line_start+command.count('\n',0,d+len(token)+x.start())}
                   for x in re.finditer(r'(?m)^[ \t]+(?:·[ \t]+)?(let|have)[ \t]+([^\s:=(]+)', command[d+len(token):])]
        rows.append({'source_identifier':ns+'.'+m.group('name'), 'name':m.group('name'), 'kind':m.group('kind'),
          'private':bool(re.match(r'(?:@\[[^\n]*\]\s*)?private\b',command)),
          'source_start_line':line_start, 'source_end_line':line_end,
          'start_character':m.start(), 'end_character_exclusive':m.start()+len(command),
          'body_delimiter':token, 'header':header, 'body':body,
          'header_sha256_utf8':sha(header.encode()), 'body_sha256_utf8':sha(body.encode()),
          'masked_command_sha256_utf8':sha(command.encode()), 'raw_command_sha256_utf8':sha(raw_command.encode()),
          'local_let_have_names':locals_, 'boundary_crosscheck':'character scanner = independent token scanner; full command reconstructed'})
    expected = expected_names(name)
    assert [r['name'] for r in rows] == expected, (name, [r['name'] for r in rows], expected)
    return {'module':'QuantumBlockEncoding/'+name+'.lean','raw_sha256':sha(raw),'raw_bytes':len(raw),
      'line_count':len(text.splitlines()), 'explicit_declaration_count':len(rows), 'declarations':rows,
      'imports': re.findall(r'(?m)^import (.+)$',clean),
      'scope_commands':[{'line':clean.count('\n',0,m.start())+1,'text':m.group(0)} for m in re.finditer(r'(?m)^(?:namespace|end|open|attribute|variable|universe|section)[^\n]*',clean)],
      'check_scope':'source text only; not elaborated signatures or kernel dependencies'}

def expected_names(name):
    if name == TARGETS[0]:
        return ['bellRyAngle','bellRyAngle_eval','standardRyMatrix_bellRyAngle','bellControl','bellTargetWire','bellControl_ne_target','bellRyCircuit','bellCxCircuit','bellPrimitiveCircuit','bellAfterRy','evalPrimitiveCircuitLE_singleton_cx_apply'] + ['bellAfterRy_'+str(i) for i in range(4)] + ['bellRy_entry_'+s for s in ['00','10','20','30']] + ['bellRy_col_zero','bellRy_prepares'] + ['bellCx_entry_'+s for s in ['00','10','20','30','01','11','21','31']] + ['bellCx_output_'+str(i) for i in range(4)] + ['bellCx_on_afterRy','bellPrimitive_prepares_target','bellPrimitiveRoute','bellVerified_cost']
    if name == TARGETS[1]:
        return ['standardRyMatrix_ryAngle35_explicit','standardRyMatrix_ryAngle513_explicit','mottonenConditionalAngles','mottonenDenseUcryCircuit','mottonenDenseUcry_entry_zero_of_context_ne'] + ['mottonenDenseUcry_entry_'+s for s in ['00','10','22','32']] + ['sparseControlWire','sparseControlWire_ne_target','sparseConditionalAngles','sparsePrunedUcryCircuit','sparsePrunedUcry_entry_zero_of_context_ne'] + ['sparsePrunedUcry_entry_'+s for s in ['00','20','44','64']]
    return ['standardRyMatrix_ryAngle513_explicit_paper','mottonenConditionalAngles','mottonenDenseUcryCircuit','mottonenDensePrimitiveCircuit','mottonenRootState'] + ['mottonenRootState_'+str(i) for i in range(4)] + ['mottonenRootRy_col_zero','mottonenRootRy_prepares'] + ['mottonenDenseUcry_entry_'+s for s in ['00','10','22','32']] + ['mottonenZeroEntry'] + ['mottonenDenseUcry_entry_'+s for s in ['02','12','20','30']] + ['mottonenDenseUcry_scalar_'+str(i) for i in range(4)] + ['mottonenDenseUcry_on_root','mottonenDensePrimitive_prepares_target','mottonenDensePrimitiveRoute','mottonenDenseVerified_cost','zeroAngleCompiledUcry_eval_eq_one','sparseControlWire','sparseControlWire_ne_target','sparseConditionalAngles','sparsePrunedUcryCircuit','sparsePrunedCircuit','sparseRootState'] + ['sparseRootState_'+str(i) for i in range(8)] + ['sparseRootRy_col_zero','sparseRootRy_prepares'] + ['sparsePrunedUcry_entry_'+s for s in ['00','20','44','64']] + ['sparseZeroEntry'] + ['sparsePrunedUcry_entry_'+s for s in ['10','30','40','50','60','70','04','14','24','34','54','74']] + ['sparsePrunedUcry_scalar_'+str(i) for i in range(8)] + ['sparsePrunedUcry_on_root','sparsePruned_prepares_target','sparsePrunedRoute','sparseDenseControlWires','sparseDenseControlWires_ne_target','sparseZeroFillCircuit','sparseDenseTreeCircuit','sparseZeroFill_eval_eq_one','sparseZeroFill_evalLE_eq_one','sparseDenseTree_evalLE_eq_pruned','sparseDenseTree_prepares_target','sparseDenseTreeRoute','sparsePrunedVerified_cost','sparseDenseTreeVerified_cost','sparsePruned_betterThan_denseTree']

def emit(name):
    raw, text, clean = source(name)
    if name in TARGETS:
        inv = inventory(name)
        signature_lines = ['# Exact source-text declaration inventory: '+name, '',
          'AUTHOR/WIP. Explicit names are source identifiers, not compiler-resolved private names. Headers and bodies are separately preserved in the adjacent JSON. No elaboration was run.', '']
        coverage = []
        for row in inv['declarations']:
            signature_lines += ['## '+row['name'], '', 'Source lines '+str(row['source_start_line'])+'–'+str(row['source_end_line'])+'; '+('private' if row['private'] else 'public')+' '+row['kind']+'.', '', '```lean', row['header'], '```', '']
            coverage.append({'item':row['source_identifier'],'disposition':'NODE','start_line':row['source_start_line'],'end_line':row['source_end_line'],'kind':'explicit-declaration-with-full-body','raw_command_sha256_utf8':row['raw_command_sha256_utf8']})
        # Every nondeclaration line has an explicit disposition; comments are not silently omitted.
        covered = set(i for r in inv['declarations'] for i in range(r['source_start_line'],r['source_end_line']+1))
        raw_lines = text.splitlines(); clean_lines = clean.splitlines()
        for i, line in enumerate(raw_lines,1):
            if i not in covered:
                significant = bool(line.strip())
                code = bool(clean_lines[i-1].strip())
                coverage.append({'item':name+':L'+str(i),'start_line':i,'end_line':i,
                  'disposition':'NODE' if significant else 'EXCLUDED',
                  'kind':'module-import-or-scope' if code else ('authored-comment-region' if significant else 'blank-line'),
                  'reason':'review module envelope and bounded prose against contract' if significant else 'whitespace has no mathematical assertion'})
        assert set(i for r in coverage for i in range(r['start_line'],r['end_line']+1)) == set(range(1,len(raw_lines)+1))
        return [{'path':'formal-only/targets/QuantumBlockEncoding/'+name+'.lean','content':clean},
                {'path':'natural/inventory/'+name+'.json','content':json.dumps(inv,ensure_ascii=False,indent=2)+'\n'},
                {'path':'natural/inventory/'+name+'.md','content':'\n'.join(signature_lines)+'\n'},
                {'path':'natural/coverage/'+name+'.json','content':json.dumps({'status':'AUTHOR_PROPOSED_NOT_INDEPENDENT_SOURCE_REVIEW','module':inv['module'],'source_scope':'whole implementation source, not named external papers','raw_sha256':inv['raw_sha256'],'every_line_disposed':True,'items':sorted(coverage,key=lambda r:r['start_line'])},ensure_ascii=False,indent=2)+'\n'}]
    ranges = PROVIDERS[name]
    lines = clean.splitlines(keepends=True)
    selected = set(i for a,b in ranges for i in range(a,b+1))
    # Retain original imports/namespaces/open commands, never rename semantic objects.
    for i,l in enumerate(lines,1):
        if re.match(r'^(?:import|namespace|end|open)\b',l): selected.add(i)
    excerpt = ''.join(l if i in selected else ''.join(c if c in '\r\n' else ' ' for c in l) for i,l in enumerate(lines,1))
    starts = list(DECL.finditer(clean))
    stops = sorted([m.start() for m in starts] + [m.start() for m in COMMAND.finditer(clean)] + [len(clean)])
    retained = []
    for m in starts:
        stop = min(x for x in stops if x > m.start())
        segment = clean[m.start():stop].rstrip()
        rendered = excerpt[m.start():m.start()+len(segment)]
        if rendered.strip():
            assert rendered == segment, ('partial provider declaration', name, m.group('name'))
            retained.append(m.group('name'))
    extent = {'source':'QuantumBlockEncoding/'+name+'.lean','raw_sha256':sha(raw), 'raw_bytes':len(raw),
      'source_line_count':len(lines),'selected_source_line_ranges':ranges,
      'scope_import_commands_also_retained':True,'line_positions_preserved':True,
      'export_line_endings':'LF; original source character/byte offsets are not exported offsets',
      'kind':'bounded-provider-excerpt-not-whole-module','masked_excerpt_sha256_utf8':sha(excerpt.replace('\r\n','\n').encode())}
    extent['retained_explicit_declarations'] = retained
    extent['whole_selected_declaration_check'] = 'all retained explicit commands preserved in full'
    return [{'path':'formal-only/providers/QuantumBlockEncoding/'+name+'.lean','content':excerpt},
            {'path':'formal-only/extents/'+name.replace('/','__')+'.json','content':json.dumps(extent,indent=2)+'\n'}]

def audit(module_filter=None):
    rows = []
    for module in TARGETS:
        if module_filter and module != module_filter: continue
        for row in inventory(module)['declarations']:
            n = row['name']; h = row['header']
            if n.startswith('bell') or n == 'standardRyMatrix_bellRyAngle': section = '3'
            elif n.startswith('mottonen') or n.endswith('explicit_paper'): section = '4'
            elif n.startswith('sparse') and not any(x in n for x in ['DenseTree','DenseControl','ZeroFill','betterThan']): section = '5'
            elif n == 'evalPrimitiveCircuitLE_singleton_cx_apply': section = '1'
            elif n.startswith('standardRyMatrix_'): section = '1'
            else: section = '6'
            if n.endswith('_cost') or 'betterThan' in n: section = '7'
            logical = []
            if n == 'evalPrimitiveCircuitLE_singleton_cx_apply':
                logical = [{'binder':'distinct','expanded_proposition':'control ≠ target','classification':'SOURCE','relative_to':'original generic CX contract, not a paper attribution'}]
            elif n == 'zeroAngleCompiledUcry_eval_eq_one':
                logical = [{'binder':'distinct','expanded_proposition':'∀ control, wires control ≠ target','classification':'SOURCE','relative_to':'original generic constant-zero UCRY contract; no injectivity requirement'}]
            elif n.endswith('zero_of_context_ne') or n in ('mottonenZeroEntry','sparseZeroEntry'):
                logical = [{'binder':'contextNe' if n.endswith('zero_of_context_ne') else 'h','expanded_proposition':'full non-target contexts from splitPrimitiveWire are unequal; exact dependent carrier and target wire are in the unabridged header','classification':'SOURCE','relative_to':'original conditional internal-provider entry contract, not assumed finite root action'}]
            definition = None
            if row['kind'] in ('def','abbrev'):
                definition = {'kind':'literal','relative_to':'pinned retrospective fixed-construction contract',
                  'choice':'none','quotient':'none','off_valid_locus':'no added fallback; Fin carriers and ExactAngle proof constructors enforce their actual domains',
                  'record_expansion':'§8 plus provider StatePreparationTarget and ExactPrimitiveStatePreparationRoute' if 'Route' in n else None,
                  'body_sha256_utf8':row['body_sha256_utf8']}
            is_anchor = n.endswith(('prepares_target','Verified_cost','PrimitiveRoute','PrunedRoute','DenseTreeRoute')) or n == 'sparsePruned_betterThan_denseTree'
            rows.append({'module':module,'identifier':row['source_identifier'],'source_lines':[row['source_start_line'],row['source_end_line']],
              'kind':row['kind'],'private':row['private'],'review_level':'A-retrospective-finite-anchor' if is_anchor else ('C-internal-provider' if row['private'] else 'B-canonical-or-route-provider'),
              'complete_header':h,'complete_header_sha256_utf8':row['header_sha256_utf8'],
              'carrier_inputs':'TYPING: every explicit dimension, Fin wire/basis/matrix index, and angle/tuple carrier in this complete header; no hidden section variables in these targets',
              'logical_inputs':logical,'additional_rule_or_correction_inputs':[],
              'excess_inputs_in_original_finite_contract':[],
              'external_paper_binder_correspondence':'UNREVIEWED; no external-paper SOURCE/STANDING/RULED claim',
              'body_local_bindings':row['local_let_have_names'],
              'definition_audit':definition,'natural_proof_expansion':'math-proof-contract.md §'+section,
              'mechanical_status':'static text author proposal; not an elaborated binder or independent semantic verdict'})
    return [{'path':'natural/audit/'+(module_filter or 'all-targets')+'.json','content':json.dumps({'status':'AUTHOR_WIP','all_explicit_target_declarations':len(rows),'expanded_provider_bundles':['StatePreparationTarget: amplitudes, normalization : Prop, source string','ExactPrimitiveStatePreparationRoute: concrete target, actual circuit, concrete normalization proof, exact action proof','PrimitiveCircuit/PrimitiveGate/ExactAngle: typed wires and exact angle syntax','BlockEncodingCost.betterThan: full nested lexicographic OR/AND definition'],'declarations':rows},ensure_ascii=False,indent=2)+'\n'}]

if __name__ == '__main__':
    tests = regression()
    if sys.argv[1] == 'check':
        invs = [inventory(n) for n in TARGETS]
        print(json.dumps({'static_only':True,'regression_cases':tests,
          'modules':[{'module':v['module'],'line_count':v['line_count'],'declarations':len(v['declarations']),
                      'private':sum(r['private'] for r in v['declarations'])} for v in invs]},ensure_ascii=False))
    elif sys.argv[1] == 'audit':
        print(json.dumps(audit(sys.argv[2] if len(sys.argv)>2 else None),ensure_ascii=False))
    else:
        artifacts = emit(sys.argv[1])
        if len(sys.argv) > 2: artifacts = [artifacts[int(sys.argv[2])]]
        print(json.dumps(artifacts,ensure_ascii=False))
