import QuantumBlockEncoding.ConcreteSemantics
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Data.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Kronecker
import Mathlib.LinearAlgebra.Matrix.Reindex
import Mathlib.Tactic

   
                                        

                                                                             
                                                                           
                                                                         
                                           
                                                      
  

namespace QuantumBlockEncoding.Robin.ComplexLCU

open scoped Kronecker

                                                                                     
noncomputable def realOrthogonalRotation (cosine sine : Real) :
    _root_.Matrix (Fin 2) (Fin 2) ℂ := fun row column =>
  match row.val, column.val with
  | 0, 0 => (cosine : ℂ)
  | 0, _ => -(sine : ℂ)
  | _, 0 => (sine : ℂ)
  | _, _ => (cosine : ℂ)

                                                                                         
theorem realOrthogonalRotation_unitary
    (cosine sine : Real) (normalization : cosine * cosine + sine * sine = 1) :
    realOrthogonalRotation cosine sine ∈
      _root_.Matrix.unitaryGroup (Fin 2) ℂ := by
  rw [_root_.Matrix.mem_unitaryGroup_iff']
  ext row column
  fin_cases row <;> fin_cases column
  · have hcast : (((cosine * cosine + sine * sine : Real) : ℂ)) = 1 := by
      exact_mod_cast normalization
    simpa [realOrthogonalRotation, _root_.Matrix.mul_apply,
      Fin.sum_univ_two] using hcast
  · simp [realOrthogonalRotation, _root_.Matrix.mul_apply,
      Fin.sum_univ_two]
    ring
  · simp [realOrthogonalRotation, _root_.Matrix.mul_apply,
      Fin.sum_univ_two]
    ring
  · have normalization' : sine * sine + cosine * cosine = 1 := by
      calc
        sine * sine + cosine * cosine =
            cosine * cosine + sine * sine := by ring
        _ = 1 := normalization
    have hcast : (((sine * sine + cosine * cosine : Real) : ℂ)) = 1 := by
      exact_mod_cast normalization'
    simpa [realOrthogonalRotation, _root_.Matrix.mul_apply,
      Fin.sum_univ_two] using hcast

                                                         
noncomputable def realRotation (angle : Real) :
    _root_.Matrix (Fin 2) (Fin 2) ℂ :=
  realOrthogonalRotation (Real.cos angle) (Real.sin angle)

@[simp] theorem realRotation_zero_zero (angle : Real) :
    realRotation angle 0 0 = (Real.cos angle : ℂ) := by
  rfl

@[simp] theorem realRotation_zero_one (angle : Real) :
    realRotation angle 0 1 = -(Real.sin angle : ℂ) := by
  rfl

@[simp] theorem realRotation_one_zero (angle : Real) :
    realRotation angle 1 0 = (Real.sin angle : ℂ) := by
  rfl

@[simp] theorem realRotation_one_one (angle : Real) :
    realRotation angle 1 1 = (Real.cos angle : ℂ) := by
  rfl

                                                      
theorem realRotation_unitary (angle : Real) :
    realRotation angle ∈
      _root_.Matrix.unitaryGroup (Fin 2) ℂ := by
  apply realOrthogonalRotation_unitary
  nlinarith [Real.sin_sq_add_cos_sq angle]

                                                                      
noncomputable def amplitudeRotation (coefficient : Real) :
    _root_.Matrix (Fin 2) (Fin 2) ℂ :=
  realRotation (Real.arccos coefficient)

                                                                       
theorem amplitudeRotation_unitary (coefficient : Real) :
    amplitudeRotation coefficient ∈
      _root_.Matrix.unitaryGroup (Fin 2) ℂ :=
  realRotation_unitary _

                                                                                    
theorem amplitudeRotation_cleanEntry
    (coefficient : Real) (lower : -1 ≤ coefficient) (upper : coefficient ≤ 1) :
    amplitudeRotation coefficient 0 0 = (coefficient : ℂ) := by
  simp [amplitudeRotation, Real.cos_arccos lower upper]

                                                                               
theorem reindex_unitary
    {ι κ : Type*} [Fintype ι] [DecidableEq ι]
    [Fintype κ] [DecidableEq κ]
    (equiv : ι ≃ κ) (operator : _root_.Matrix ι ι ℂ)
    (unitary : operator ∈ _root_.Matrix.unitaryGroup ι ℂ) :
    _root_.Matrix.reindexAlgEquiv ℂ ℂ equiv operator ∈
      _root_.Matrix.unitaryGroup κ ℂ := by
  rw [_root_.Matrix.mem_unitaryGroup_iff'] at unitary ⊢
  have star_reindex :
      star (_root_.Matrix.reindexAlgEquiv ℂ ℂ equiv operator) =
        _root_.Matrix.reindexAlgEquiv ℂ ℂ equiv (star operator) := by
    ext row column
    rfl
  rw [star_reindex, ← _root_.Matrix.reindexAlgEquiv_mul, unitary]
  simp

                                                                                 
                             
                                             
                               
                                      
                                                                
                                        
                                                
                                          
                           
                                                 
                                                                    
                                             
                                       
                       
                                              
                                                   
                                                     
                                                            
                  
                                             
                                           
            
                                                            
                                                 

                                            
def equivPermutationMatrix
    {ι : Type*} [DecidableEq ι] (equiv : ι ≃ ι) :
    _root_.Matrix ι ι ℂ := fun row column =>
  if row = equiv column then 1 else 0

                                                              
theorem equivPermutationMatrix_unitary
    {ι : Type*} [Fintype ι] [DecidableEq ι] (equiv : ι ≃ ι) :
    equivPermutationMatrix equiv ∈
      _root_.Matrix.unitaryGroup ι ℂ := by
  rw [_root_.Matrix.mem_unitaryGroup_iff']
  ext row column
  by_cases equal : row = column
  · subst column
    simp [equivPermutationMatrix, _root_.Matrix.mul_apply]
  · have reverse_ne : column ≠ row := Ne.symm equal
    simp [equivPermutationMatrix, _root_.Matrix.mul_apply, equal, reverse_ne]

                                                                                      
                                        
                                             
                                                    
                            
                                                          
                                            
           
                              
                                            
                                 
                                  
                                           
               
                        
                           
          
                                         
                                     
                                           
                                       
        

                                                                   
                          
                                        
                                             
                                                    
                            
                                                          
                                       
           
                              
                                          
                                 
                                  
                                               
        

                                                              
                                  
                                           
                            
                                                                  
                                                       
                
                                       
                                                       
                                               
                                                    
                
                                              
                       
                                                 
                   
               
                                           
                    

                                                                          
                                                                        
                                                 
                                             
                               
                                     
                                    
                                              
                                  
                                                                   
                                      
                                       
                                                 
                
                                       
                                     
                                                                   
                         
                                                 
                                                 
                                                               
                                       
                

                                                                              
                                                        
                                   

                                                                
                
                                         
                                                   
                                             
                                         
                                                   
                 
                                            
                                                 
                                                  
                                                    

                                                                                  
                            
                                         
                                                   
                                             
                                         
                                                 
                                                                 
                                                                          
                                
                                                      
                                           
                                                            
                                             
                   
                                                         

                                                                           
                 
                                         
                                                   
                                             
                                         
                                   
                                                
                 
                                            
                                                 
                                                                           

                                                                  
                             
                                         
                                                   
                                             
                                         
                                   
                                              
                                 
                                
                                                   
                            
                                
                                                      
                             
               
                                   

                                                                                       
                         
                                         
                                                
                                          
                                                
                
                                                           
                 
                                                                  
                      
        
                       
        

                                                                 
              
                                         
                                                                         
                                                
                 
                                            
                                                 
                                                            

                                                           
                          
                                         
                                                   
                                             
                                         
                                                
                                                         
                                
                                                   
                                  

                                                               
                                                 
                                         
                                                   
                                             
                                         
                                                 
                                   
                                              
                                                
                 
                                            
                                                 
                                                                               
                                                          
                               
                                                                              

                                                                                   
                                               
                                         
                                                   
                                             
                                         
                                                 
                                   
                                              
                                              
                     
                                                      
                                         
                                
                                                   
                                                                  
                                
                                                      
                                   
                                                     
                          
                                                                           
                               
                                     
                                                       
                                                                       
                                       
                                                         
                                                            
                                                               
                                                   

end QuantumBlockEncoding.Robin.ComplexLCU
