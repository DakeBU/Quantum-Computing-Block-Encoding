import Mathlib.Data.Complex.Basic
import Mathlib.Data.Matrix.Mul
import Mathlib.LinearAlgebra.UnitaryGroup
import QuantumBlockEncoding.BlockEncodingClassics
import QuantumBlockEncoding.CircuitSemantics
import QuantumBlockEncoding.StatePreparation

   
                                  

                                                                            
                                                                            
                                                                          
                      

                                                                            
                                                                        
       
  

namespace QuantumBlockEncoding
namespace ConcreteSemantics

                                                                              
abbrev FiniteMatrix (rows cols : Nat) (α : Type u) :=
  _root_.Matrix (Fin rows) (Fin cols) α

                              
abbrev StateVector (dimension : Nat) (α : Type u) :=
  Fin dimension -> α

                                                                
def basisKet (dimension : Nat) {α : Type u} [Zero α] [One α]
    (index : Fin dimension) : StateVector dimension α :=
  Pi.single index 1

                                                                              
                                                                             
                              
@[simp] theorem basisKet_apply {dimension : Nat} {α : Type u}
    [Zero α] [One α] (index row : Fin dimension) :
    basisKet dimension (α := α) index row =
      if index = row then 1 else 0 := by
  by_cases hit : index = row
  · subst row
    simp [basisKet]
  · simp [basisKet, hit]

                                                                      
def zeroKet (qubits : Nat) {α : Type u} [Zero α] [One α] :
    StateVector (gridSize qubits) α :=
  basisKet (gridSize qubits) (zeroBasisIndex qubits)

                                                                 
def applyVec {rows cols : Nat} {α : Type u} [NonUnitalNonAssocSemiring α]
    (operator : FiniteMatrix rows cols α) (state : StateVector cols α) :
    StateVector rows α :=
  operator.mulVec state

   
                                                                           
                                                   
  
structure ComplexUnitaryGate (qubits : Nat) where
  matrix : FiniteMatrix (gridSize qubits) (gridSize qubits) ℂ
  unitary :
    matrix ∈ _root_.Matrix.unitaryGroup (Fin (gridSize qubits)) ℂ

                                                                     
@[simp] theorem applyVec_basisKet {rows cols : Nat} {α : Type u}
    [NonAssocSemiring α] (operator : FiniteMatrix rows cols α)
    (index : Fin cols) :
    applyVec operator (basisKet cols index) = operator.col index := by
  exact _root_.Matrix.mulVec_single_one operator index

                                                                             
                                                                            
                                                                                
theorem applyVec_twoBasisSuperposition {rows cols : Nat}
    (operator : FiniteMatrix rows cols ℂ) (a b : ℂ)
    (left right : Fin cols) :
    applyVec operator
        (a • basisKet cols left + b • basisKet cols right) =
      a • operator.col left + b • operator.col right := by
  unfold applyVec basisKet
  rw [_root_.Matrix.mulVec_add, _root_.Matrix.mulVec_smul,
    _root_.Matrix.mulVec_smul, _root_.Matrix.mulVec_single_one,
    _root_.Matrix.mulVec_single_one]

                                                                            
                                                                             
                                                    
theorem applyVec_twoBasisSuperposition_apply {rows cols : Nat}
    (operator : FiniteMatrix rows cols ℂ) (a b : ℂ)
    (left right : Fin cols) (row : Fin rows) :
    applyVec operator
        (a • basisKet cols left + b • basisKet cols right) row =
      a * operator row left + b * operator row right := by
  have h := congrFun (applyVec_twoBasisSuperposition operator a b left right) row
  simpa using h

                                                      
@[simp] theorem applyVec_zeroKet {α : Type u} [NonAssocSemiring α]
    {qubits : Nat}
    (operator : FiniteMatrix (gridSize qubits) (gridSize qubits) α) :
    applyVec operator (zeroKet qubits) =
      operator.col (zeroBasisIndex qubits) := by
  exact applyVec_basisKet operator (zeroBasisIndex qubits)

   
                                                                    
                                                        
  
                                               
                                                    
                                                                   
                                                
                                        
                                                                  
             
                     
                         
                            
                    
                                   
                             

   
                                                                               
                                                                              
                                                                               
  
                                                                 
                                          
                                  
                                           
                    
                                                             

namespace ComplexStatePreparationCertificate

                                                                                
                                                                       
                                                                         
                                  
                                            
                              
                                    
                    
                      
                      
                                    
              
                             
                                                          

   
                                                                             
                                                                      
                                
  
                                                                      
                                                                         
                                  
                                           
              
                                                                   
                                                      
                                          
                     
                                            
                                                     
                                    

                                                                                  
                                                       
                                      
                              

end ComplexStatePreparationCertificate

                                                                               
                                                                        
                                                               

   
                                                                       
                                                                              
  
                                                                  
                                                                 
                                                  
                
            
                                                          
                                                 
                                                          
                                                 

                                                                          
                                                                           
                                                            
                                                         
                                                               

   
                                                                             
                                          
  
                                                            
                                                        
                                                               
                                   
                                  
                                                      
                                                                                
     

                                                                                     
                                                     
                               
                                                                 
                                                                      
                               
                                                       
     

   
                                                                             
                                                              
  
                                                        
                               
                                                                           
                                   
                      
                                  
                                                           
                                                                          
               
     

   
                                                                     
                                                                     
                                                                          
                                                          
  
                                                                      
                        
                                                                               
                                                                       
                   
                                     
                                                             
                                                           

                                                                                             
                                                                
                                                                 
                                                                               
                                                                  
                                                                 
                                                               
                                               
                                  
                        
                                    
         

   
                                                                        
                                                                            
                                                                              
                                                            
  
                                                
                                                                 
                                                                               
                                                                           
                      
                                                                  
                               
                
                     
                                                                     
                                   
             
                                
                                                                 
                                
                             
                                                                   
                             

end ConcreteSemantics
end QuantumBlockEncoding
