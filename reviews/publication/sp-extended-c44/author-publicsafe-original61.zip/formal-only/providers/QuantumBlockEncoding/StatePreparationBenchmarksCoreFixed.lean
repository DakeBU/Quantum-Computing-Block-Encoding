import QuantumBlockEncoding.ConcreteSemantics
import QuantumBlockEncoding.TextbookStatePreparation
import Mathlib.Tactic

   
                                                       

                                                                               
                                                                             
                                                                                 
                                             
  

open scoped ComplexConjugate

namespace QuantumBlockEncoding.StatePreparationBenchmarks

open ConcreteSemantics

                    

noncomputable abbrev bellAmplitude : ℂ :=
  TextbookStatePreparation.invSqrtTwo

noncomputable def bellState : StateVector (gridSize 2) ℂ := fun index =>
  if index.val = 0 ∨ index.val = 3 then bellAmplitude else 0

noncomputable def bellTarget : StatePreparationTarget ℂ 2 where
  amplitudes := bellState
  normalization := ∑ index, Complex.normSq (bellState index) = 1
  source := "Bell-state textbook benchmark"

theorem bellTarget_normalized : bellTarget.normalization := by
  change ∑ index : Fin 4, Complex.normSq (bellState index) = 1
  rw [Finset.sum_fin_eq_sum_range]
  have hs : Complex.normSq bellAmplitude = (1 : ℝ) / 2 := by
    simp [bellAmplitude, TextbookStatePreparation.invSqrtTwo,
      Complex.normSq_apply]
  norm_num [bellState, Finset.sum_range_succ, hs]

                                                    
                   
                                  
                           
                           
                           
                           
                           
                            
                           
                            
               

                                                            
                
                                        
                                                                         

                            
                                                                      
                                                          
                                                               
                                                                            
                                                          
                
                                        
                                                                 
                                                          
                                    

                                                       
                      
                               

                                    
                                                                 
                                                       
                         
                                                                 
                        
            
                                                    

                                                                              
                      
                  
                                             
                                                

                                        

noncomputable def mottonenDenseState : StateVector (gridSize 2) ℂ := fun index =>
  match index.val with
  | 0 => (39 : ℂ) / 169
  | 1 => (52 : ℂ) / 169
  | 2 => (60 : ℂ) / 169
  | _ => (144 : ℂ) / 169

noncomputable def mottonenDenseTarget : StatePreparationTarget ℂ 2 where
  amplitudes := mottonenDenseState
  normalization := ∑ index, Complex.normSq (mottonenDenseState index) = 1
  source := "Möttönen-style dense two-qubit nested-Pythagorean benchmark"

theorem mottonenDenseTarget_normalized : mottonenDenseTarget.normalization := by
  change ∑ index : Fin 4, Complex.normSq (mottonenDenseState index) = 1
  rw [Finset.sum_fin_eq_sum_range]
  norm_num [mottonenDenseState, Complex.normSq_apply, Finset.sum_range_succ]

                                                                             
                                       
                                           
                                
                          
                           
                           
                            
                          
                          
                            
                          
                          
                           
                          
                           
                           
                           
                          
                          

                                   
                               
                                     
                         
                                                           
                                                                   
                                          
                
                                        
                                                                 
                                                            
                                                    
                                  
                                  

                                                                
                               
                                        

                                             
                                              
                                          
                                                                
                         
                          
                           
                           
                           
                             
                        
            
                                                  

                                            
                                              
                               
                           
                                                      
                                                         

                                                               

                                                                           
              
                        
                       
                        
                        
                        

                                                                               
                                         
                                                                                
                                                                       

                                               
                                                  
                                                                              
                                  
                                                            
                          

                                              
                                           
                                
                        
                          
                          
                         
                         
                        
                          
                          
                         
                          
                        
                          
                         
                         
                         
                        

                                   
                               
                                            
                                
                                                           
                                     
                                        
                                          
                
                                        
                                                                 
                                                            
                                                           
                                  
                                  

                                                                       
                                      
                                               

                                                    
                                                     
                                                 
                                                                       
                         
                          
                         
                          
                          
                           
                        
            
                                                         

                                                   
                                              
                                      
                                  
                                                             
                                                                

                                      

noncomputable def sparseThreeState : StateVector (gridSize 3) ℂ := fun index =>
  if index.val = 0 then (3 : ℂ) / 13
  else if index.val = 2 then (4 : ℂ) / 13
  else if index.val = 4 then (12 : ℂ) / 13
  else 0

noncomputable def sparseThreeTarget : StatePreparationTarget ℂ 3 where
  amplitudes := sparseThreeState
  normalization := ∑ index, Complex.normSq (sparseThreeState index) = 1
  source := "Li--Luo sparse-state finite witness of Eq. (2), n=3 and d=3"

theorem sparseThreeTarget_normalized : sparseThreeTarget.normalization := by
  change ∑ index : Fin 8, Complex.normSq (sparseThreeState index) = 1
  rw [Finset.sum_fin_eq_sum_range]
  norm_num [sparseThreeState, Complex.normSq_apply, Finset.sum_range_succ]

                                                                                  
                                     
                                           
                                
                        
                        
                          
                        
                       
                          
                         
             
                         
             
             
             
             
             
             

                                   
                                
                                   
                       
                                                           
                                                                 
                                          
                
                                        
                                                                 
                                                            
                                                  
                                  
                                  

                                                              
                             
                                      

                                           
                                                                               
                                                              
                         
                                        
                                             
                                              
             
                        
            
                                                

                                                                                     
                             
                         
                                                    
                                                       

                                                                    

                                                     
                                                  

                                      
                                                  

                                      
                                                  

                                                      
                                                                            

end QuantumBlockEncoding.StatePreparationBenchmarks
