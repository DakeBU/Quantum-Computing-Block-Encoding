import QuantumBlockEncoding.BlockEncoding

   
                                

                                                                        
                                                                     
                                                                             
                                                                    
  

namespace QuantumBlockEncoding

                                                                       
def zeroBasisIndex (n : Nat) : Fin (gridSize n) :=
  ⟨0, Nat.pow_pos (by decide)⟩

                                                
structure StatePreparationTarget (α : Type u) (qubits : Nat) where
  amplitudes : Fin (gridSize qubits) → α
  normalization : Prop
  source : String := ""

                                                          
                                                  
                                                            
                                                        
                                                                    

                                                                         
                                                                     
                                          
                                                        
                   
                                 
                     
                            
                  

namespace StatePreparationCandidate

                                                                                  
                                                                             
                                                       

                                                                                
                                                                                
   
                                                
                                         
                                     
                                                 
   

end StatePreparationCandidate

                                                                                    
                                                                    
                                                
                                                     
                                    
                                             

                                                                              
                                              
                                     
                                                
             
                           

                                                            
                                             
                                     
                                                                 
                                                                     
                                                    
                                                         

namespace VerifiedStatePreparation

   
                                                                          
                                                                         
                       
  
                                 
                                                    
                                                      
                      
                                   
                
                                                           
   
                                                   
                                       
                                                 

                   
                                                    
                                        
                           

end VerifiedStatePreparation

end QuantumBlockEncoding
