import QuantumBlockEncoding.Circuit

   
                             

                                                                               
                                                                          
                                                                               
                                                
  

namespace QuantumBlockEncoding

                              
                    
                    
                    
                          

namespace RegisterLayout

   
                                                                              
                                                                               
            
  
                                                      
                                           

end RegisterLayout

                                                                      
                                                                
                             
                
           
                         
                   
                     

   
                                                                      
                                                            

               
                         
                          
                                 
  
structure BlockEncodingCost where
  auxiliaryQubits : Nat
  gateCount : Nat
  depth : Nat
  oracleCalls : Nat
deriving Repr, DecidableEq

namespace BlockEncodingCost

                                                                           
                           
                                           
                             
                         
                                     

                                                                          
                                                 

                                                                               
def betterThan (x y : BlockEncodingCost) : Prop :=
  x.gateCount < y.gateCount ∨
  (x.gateCount = y.gateCount ∧
    (x.depth < y.depth ∨
      (x.depth = y.depth ∧
        (x.auxiliaryQubits < y.auxiliaryQubits ∨
          (x.auxiliaryQubits = y.auxiliaryQubits ∧
            x.oracleCalls < y.oracleCalls)))))

                                                                                
                                                   
                        

end BlockEncodingCost

   
                                                                          
                                                                       
                                      
  
                                                                  
                               
                
                 
                           
                                    

   
                                                                              
                                                                        
                                                                          
                                     
  
                                                                                
                       
                                                                                
           
                                                      
                                                   
                         
                   
                                 
                     
                                                          
                  
                            

namespace OperatorBlockEncodingCandidate

                                                                      
                        
   
                                                
                                         
                                     
                                                 
   

end OperatorBlockEncodingCandidate

                                                                                    
                                                                               
                                                           
                                    
                                            

   
                                                                              

                                                                         
               

                                            

                                                                              
                                                                               
                                
  
                                                   
                                           
                                                           
             
                           

   
                                                                             
                                                                          
                  
  
                                                  
                                           
                                                                            
                                                    
                                                         

namespace VerifiedOperatorBlockEncoding

   
                                                                             
                                                                           
                                                                              
                                       
  
                                 
                                                        
                                                                 
                      
                            
                
                                                         
   
                                
                                    

end VerifiedOperatorBlockEncoding

   
                                                                             

                                                                           
                                                                            
                                                                               
                                                                               
                                                           
  
                                                        
                          
                            
                                  
                      
                            
                      
                       
                      
             

                                                                       
                                        
               
                              
                       
           
                          

   
                                                                          
                                                                             
                                                                             
                                                                        
  
                                                                    
                                      
                  
                     
                      
                          
                           
                               

namespace VerifiedBlockEncoding

                                              
                                                            
                

                                              
                                                               
              

                                                  
                                                                
                 

end VerifiedBlockEncoding

                                                                                
                                 
               
                 
                 
                        
                 
                               
                          

end QuantumBlockEncoding
