"""Static, read-only packet verification. Emits JSON; writes nothing; invokes no subprocess."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import runpy
import sys

HERE = Path(__file__).resolve().parent
M = runpy.run_path(str(HERE / 'build_packet.py'))
ROOT = M['ROOT']

def sha(data): return hashlib.sha256(data).hexdigest()
def readjson(path): return json.loads(path.read_text(encoding='utf-8'))
def pin():
    files = sorted(list((ROOT/'QuantumBlockEncoding').rglob('*.lean')) + list((ROOT/'ABEISTests').rglob('*.lean')) + [ROOT/n for n in ['QuantumBlockEncoding.lean','Tests.lean','lakefile.lean','lean-toolchain','lake-manifest.json']],key=lambda p:str(p).lower())
    assert len(files) == 207
    return {'schema':'c42-proof-inputs-raw-sha256-v1','root':str(ROOT),
      'observedUtc':datetime.now(timezone.utc).isoformat(),
      'declared_head_unverified_here':'30fe1d77735221cb86fdfc39102c151c9527dc37',
      'selection':'QuantumBlockEncoding/**/*.lean + ABEISTests/**/*.lean + five explicit root/config files',
      'count':len(files),'files':[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files]}

def verify():
    before = readjson(HERE/'pins/proof-inputs-before.json')
    after = pin()
    old = {r['path']:r for r in before['files']}; new = {r['path']:r for r in after['files']}
    changed = [p for p in sorted(old.keys()|new.keys()) if old.get(p)!=new.get(p)]
    assert not changed, changed
    assert M['regression']() == 5
    modules = []; formal = []
    for name in M['TARGETS']:
        inv = M['inventory'](name)
        saved = readjson(HERE/('natural/inventory/'+name+'.json'))
        assert saved == inv, ('inventory changed',name)
        audit = readjson(HERE/('natural/audit/'+name+'.json'))
        assert [r['identifier'] for r in audit['declarations']] == [r['source_identifier'] for r in inv['declarations']]
        for a,r in zip(audit['declarations'],inv['declarations']):
            assert a['complete_header']==r['header'] and a['complete_header_sha256_utf8']==r['header_sha256_utf8']
        raw,text,clean = M['source'](name)
        path = HERE/('formal-only/targets/QuantumBlockEncoding/'+name+'.lean')
        assert path.read_bytes()==clean.replace('\r\n','\n').encode('utf-8')
        coverage = readjson(HERE/('natural/coverage/'+name+'.json'))
        assert coverage['raw_sha256']==sha(raw)
        lines = [i for r in coverage['items'] for i in range(r['start_line'],r['end_line']+1)]
        assert sorted(lines)==list(range(1,len(text.splitlines())+1)), ('coverage partition',name)
        assert not re.search(r'\b(?:sorry|admit|axiom)\b',clean)
        modules.append({'module':inv['module'],'raw_sha256':sha(raw),'raw_bytes':len(raw),'line_count':inv['line_count'],
          'explicit_declarations':len(inv['declarations']),'private_source_declarations':sum(r['private'] for r in inv['declarations']),
          'native_decide_source_occurrences':len(re.findall(r'\bnative_decide\b',clean)),
          'all_headers_bodies_checked':True,'all_source_lines_disposed':True,
          'local_let_have_named_occurrences':sum(len(r['local_let_have_names']) for r in inv['declarations'])})
    for name in M['PROVIDERS']:
        arts = M['emit'](name)
        for a in arts:
            p = HERE/a['path']
            assert p.read_bytes()==a['content'].replace('\r\n','\n').encode('utf-8'), ('provider export differs',a['path'])
    for p in sorted((HERE/'formal-only').rglob('*')):
        if p.is_file(): formal.append({'path':p.relative_to(HERE).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
    report = {'status':'STATIC_AUTHOR_WIP_NOT_ACCEPTED_EVIDENCE','static_checks_passed':True,
      'time_utc':datetime.now(timezone.utc).isoformat(),'proof_inputs_count':207,'proof_inputs_changed':changed,
      'before_sha256':sha((HERE/'pins/proof-inputs-before.json').read_bytes()),
      'new_lean_lake_native_kernel_execution':False,'new_compilation_claim':False,
      'whole_target_modules':modules,'synthetic_boundary_regressions':5,
      'header_boundary_algorithms':'character-depth scanner and independent token-depth scanner',
      'independent_expected_name_lists':True,'source_coverage_partition':'all 1186 raw source lines exactly once',
      'provider_scope':'14 bounded excerpts; every retained explicit provider command is complete',
      'target_export':'complete comment-masked source, LF newline normalization only',
      'independent_decoder':'PENDING','independent_source_review':'PENDING','purification':'PENDING','exposition_seal':'PENDING'}
    binding = {'status':'AUTHOR_WIP_PIN_BINDING_NOT_PUBLICATION_REGISTRY','historical_formalizer':'UNKNOWN',
      'source_head':'30fe1d77735221cb86fdfc39102c151c9527dc37','head_evidence':'supplied by parent, no Git used by this worker',
      'toolchain':{'text':(ROOT/'lean-toolchain').read_text(encoding='utf-8').strip(),'raw_sha256':new['lean-toolchain']['sha256']},
      'manifest_raw_sha256':new['lake-manifest.json']['sha256'],'lakefile_raw_sha256':new['lakefile.lean']['sha256'],
      'module_bindings':modules,'binding_scope_note':'raw 207-file proof-input snapshot; not the repository publication binding_digest algorithm'}
    return after,report,{'status':'FROZEN_FORMAL_TRACK_CODE_AND_EXTENTS_ONLY','files':formal,'natural_track_excluded':True,'unavoidable_original_identifiers_and_strings_retained':True},binding

def allowlist():
    names = {'README.md','build_packet.py','verify_packet.py','handoff.md',
      'natural/math-proof-contract.md','natural/four-view-graph-proposal.md','natural/audit-guide.md',
      'pins/proof-inputs-before.json','pins/proof-inputs-after.json','pins/static-verification-report.json',
      'pins/formal-track-manifest.json','pins/whole-module-bindings.json'}
    for n in M['TARGETS']:
        names.add('formal-only/targets/QuantumBlockEncoding/'+n+'.lean')
        names.update('natural/'+folder+'/'+n+ext for folder,ext in [('inventory','.json'),('inventory','.md'),('coverage','.json'),('audit','.json')])
    for n in M['PROVIDERS']:
        names.add('formal-only/providers/QuantumBlockEncoding/'+n+'.lean')
        names.add('formal-only/extents/'+n.replace('/','__')+'.json')
    return names

if __name__=='__main__':
    after,report,formal,binding = verify()
    if sys.argv[1]=='snapshots':
        artifacts=[('pins/proof-inputs-after.json',after),('pins/static-verification-report.json',report),('pins/formal-track-manifest.json',formal),('pins/whole-module-bindings.json',binding)]
        print(json.dumps([{'path':p,'content':json.dumps(v,ensure_ascii=False,indent=2)+'\n'} for p,v in artifacts],ensure_ascii=False))
    elif sys.argv[1]=='seal':
        expected=allowlist()
        actual={p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file() and p.name!='export-seal.json'}
        assert actual==expected, {'extra':sorted(actual-expected),'missing':sorted(expected-actual)}
        sealed=[{'path':p,'bytes':(HERE/p).stat().st_size,'sha256':sha((HERE/p).read_bytes())} for p in sorted(expected)]
        assert {r['path']:r for r in readjson(HERE/'pins/proof-inputs-after.json')['files']}=={r['path']:r for r in after['files']}
        print(json.dumps({'status':'FROZEN_AUTHOR_WIP_NOT_ACCEPTED','sealed_utc':datetime.now(timezone.utc).isoformat(),
          'output_root':str(HERE),'allowed_paths':sorted(expected),'sealed_file_count':len(sealed),
          'files':sealed,'seal_excludes_only_itself':True,'sha256_table_digest':sha(json.dumps(sealed,ensure_ascii=True,sort_keys=True,separators=(',',':')).encode()),
          'proof_inputs_unchanged':207,'all_checks_static':True,'no_lean_native_kernel_claim':True,
          'next_roles':'fresh whole-module formal-only decoder, then distinct anti-anchored source/semantic reviewer'},ensure_ascii=False,indent=2))
