# Stage3 actual-decoder reconciliation: bounded LOCAL finite SP

Direction: `independent-source-formal-actual-decoder-SP-reconciliation`.
Expected gain: close genuine cross-reader semantics before current binding wrappers.

## 1. Result, first release and scope

The actual formal-only decoder reconstructs the same three fixed normalized targets, four exact primitive preparation routes, generic CX/UCRY interfaces, full zero-angle operator identity, and finite resource comparison as my previously sealed natural reconstruction and full-formal comparison. I found no mathematical state/action, binder, phase/order, full-context or fixed-cost disagreement within the released LOCAL scope. The two small language refinements below do not change a theorem or cost. This is a bounded three-way static-content judgment, not final publication, Lean acceptance, kernel trust, paper authenticity, general algorithm closure or Exposition Seal.

This was my FIRST actual-decoder release. Before reading its reconstruction/coverage content I checked decoder seal SHA256 `26cda722cb01d98adabd10ded64b8892bf4e381f4205069e0c5bcbea8c41160d`, all four sealed payload hashes/byte lengths, and all 32 before/after formal input pins against the actual previously released formal packet. They match, including manifest digest `43e1b382ee41a51ca02f17a6040c248da52840bb1c1d50f43f2a05d53d1d47fd`. All five decoder files were then read to EOF, including the complete 3214-line independent coverage artifact. A truncated display of one coverage chunk was fully reread in smaller consecutive chunks. No author graph/metadata/binder inventory, other review, production code, import expansion, network/Git, compiler/native proof execution, registry mutation or child was used.

Stage1's six files and Stage2's seven files are unchanged. Their seals remain `7b20a4f55d03141d24633211c202fcc50584ba32c88a45315750e9972bdfa832` and `f3f0fca5155e9b18924ee67204d52ddf8a1fd52ce9be4a5019f7ae26e16d3d84`. The natural input was an implementation-informed retrospective original LOCAL teaching contract. Independent present natural-before-formal ordering is retained, but neither that contract nor this reconciliation is retrospectively relabeled historical/preproof or authenticated named-paper evidence. The decoder's chronology claims formal-only source separation, with original identifiers/strings still visible; its payload and chronology binding are checked, not an external audit of model identity/history.

## 2. All-declaration and ambient reconciliation

| Released file family | My sealed coverage | Actual decoder coverage | Stage3 check |
|---|---:|---:|---|
| Bell target | 37 declarations | 37 | Same source names, start lines, syntax kinds and private visibility; per-entry dispositions compatible. |
| EntryCertificates target | 18 | 18 | Same declarations, exact full-context mismatch domains and selected-entry values. |
| Compact target | 85 | 85 | Same aliases, all coordinate/entry/scalar helpers, roots, zero identity, route records, costs and comparison. |
| All target ambient commands | 27 | 27 | Exact command start/header matches, including all local simp additions. |
| All supplied provider excerpts | 206 declarations in 14 files | 206 in 14 | Every path/line/kind/raw label paired, no missing declaration; anonymous instance empty/null labels normalized only for pairing. |

`coverage-reconciliation.json` stores all 140 target pairs, their prior mechanism-group links and all 27 ambient pairs, plus exact provider counts after individual 206-record pairing. The complete original two coverage inventories remain separately pinned. These are independent lexical records plus manual semantic reading, not elaborated theorem dependencies or generated private names. My earlier end windows include intervening blank masks; decoder end lines are command line envelopes and can differ without changing an object's start/name/kind or file digest. No command-extent hash recomputation is claimed here beyond the actual full-file seal/pin checks.

There are 73 private target declarations (20 Bell, 2 EntryCertificates, 51 Compact); every one is paired with the same private status and its decoder semantic disposition was read. The 14 private retained provider declarations are in the same source windows already read in Stage2 (angle representation, four rational parameters/Pythagorean bridge, UCRY helper definitions/proofs). The decoder provider inventory does not separately annotate visibility; it lists those same declarations and its reconstruction/coverage explicitly includes private-body reading. I do not pretend the metadata pairing alone proves that reading happened. No target ambient variable/hypothesis/axiom/option/macro command was discovered; both reviews record the same namespaces/import/open/local-simp environment. No finite root acquires a hypothesis through one of those commands.

The prior 55 mechanism groups and all 51 sealed natural-node dispositions remain at `stage2:/coverage.json`. This phase adds actual cross-reader reconciliation; it does not overwrite that source-first topology or convert a semantic description into a compiler-backed graph.

## 3. Carriers, phase, LE order and binder expansion

Decoder sections 2.1-2.3 and 8 agree with Stage1 sections 1/5 and Stage2 sections 1/2/5:

- The vector carrier is unrestricted `Fin(2^n)->C`, not a normalized-state subtype. `basisKet` is a delta, `zeroKet` the zero-index basis vector, and actual `mulVec` is row/output, column/input. Basis/zero action selects columns. Two-basis linearity needs no distinct-support-index hypothesis, although the concrete examples use distinct indices.
- `StatePreparationTarget.normalization` is an arbitrary Prop in the GENERIC carrier; source metadata has default empty String. Each concrete target instead chooses an actual sum-of-complex-normSq equation. All four route records explicitly supply target, circuit, normalization proof and ACTUAL exact preparation equality.
- Unitarity is supplied by actual primitive gate matrices, circuit induction and LE reindexing, not an unconstrained `isUnitary : Prop`. The record's arbitrary normalization FIELD does not license describing its actual preparation requirement as arbitrary: actual unitary action on normalized e0 forces unit norm mathematically as well. Decoder's generic-field warning and my Stage2 stronger observation are compatible, not competing classifications.
- The LE recursion index=b0+2*tailIndex makes q0 least significant. Sparse support is indices 0,2,4, i.e. |000>,|010>,|100>; q0 remains a TARGET wire, not ancilla. Reindexing changes coordinates of the full matrix, not the circuit or an omitted wire.
- RY(theta)=R(cos(theta/2),sin(theta/2)) with R(c,s)=[[c,-s],[s,c]], root gamma=pi/2 and a=sqrt2/2>0. The warm matrix is not a full Hadamard, though it shares its plus first column. Every target is actual phase-sensitive complex equality, not equal distribution or equality modulo global phase. The separate PrimitiveProgram phase field is not used by these circuit roots.
- Finite roots and costs have no extra external proof premise. Generic CX takes typed distinct wires and row/column; full-context zero helpers take exactly the unequal-context proposition; generic UCRY/zero identity take target-separated controls, NOT a compiler-correctness assumption. Rotation bound/sign/circle and unitary lift/reindex prerequisites are produced internal suppliers, not moved into finite public-root binders. `noncomputable` carries no runtime theorem.

Decoder makes explicit that the provider identity RY(2 arccos c)=amplitudeRotation(c) retains lower/upper binders although factor-two cancellation itself does not need them. The downstream clean coefficient characterization and sine-sign identification do need their appropriate bounds/sign/circle. This refines provider-role accounting, not a new finite-root EXCESS hypothesis or required source correction.

Literal target functions, finite catch-all patterns, angle expressions, aliases, lists/compiler calls, records and explicit equivalences agree in both accounts. Catch-all dense index means exactly index 3 on Fin 4; sparse's else branch covers every remaining valid index. Neither account adds a classical-choice, uniqueness-of-completion, phase quotient or characterized-definition claim.

## 4. Complete UCRY context, repeated controls and full zero identity

Decoder section 3 and 6.2 agree with natural nodes N06-N09/Z01 and my Stage2 section 3. A block is indexed by ALL non-target bits, not merely the named control tuple. The chosen angle reads the ROW context, which agrees with the column's in the nonzero branch. Consequently all non-target spectators are preserved. In the sparse case that includes q0 in context (q0,q2), even though the control tuple is only q2.

Only every-control-versus-target separation is required. Repeated physical controls are allowed. Decoder usefully makes explicit that inconsistent duplicated-control table assignments need never be physically realized; the compiler identity only samples the assignment induced by a fixed full context. This is compatible with the earlier generic theorem reconstruction, not a dropped injectivity requirement. Zero controls give the unique empty assignment; zero qubits with a target has no instance.

The compiler is literally half-sum recursion; CX; half-difference recursion; CX. On a fixed head-zero context its action is RY(d)RY(h)=RY(A0), and on head-one X RY(d) X RY(h)=RY(A1). Contextwise induction is the bridge from the recursively mirrored matrix to the entire direct block specification. Selected finite entries do not substitute for that bridge. Reference counts remain 2^m RY and 2(2^m-1) CX, with zero/canceling instructions retained.

The zero-angle theorem is full operator identity. On unequal contexts both sides have delta zero; on equal contexts RY(0) is the target delta, and split-wire injectivity identifies context+target equality with equality of full basis states. It is not merely a statement on e0 or the sparse support. Both reviews preserve every guard and the repeated-control domain.

## 5. Three targets, four routes and correct AND/OR

| Fixed route | Exact transcript independently reconstructed by decoder | Sealed natural/formal comparison |
|---|---|---|
| Bell | e0 -> a(e0+e1) -> a(e0+e3) | Same RY and CX entries, all four weighted outputs, append proof and norm 2a^2=1. |
| Dense | e0 -> (5e0+12e2)/13 -> (39e0+52e1+60e2+144e3)/169 | Same root on q1, conditional q1->q0 alpha/beta blocks, four cross-context zeros, four weighted scalars and exact norm identity. |
| Sparse pruned | e0 -> (5e0+12e4)/13 -> (3e0+4e2+12e4)/13 | Same root on q2, conditional q2->q1 alpha/0 blocks, all twelve mismatch zeros, on-context (6,4)=0, eight weighted scalars and norm identity. |
| Sparse dense-tree | pruned followed by two-control identity block on q0 | Same all-input LE operator equality, then reuse of pruned action and same concrete target/norm. |

Decoder sections 4-6 and its per-declaration semantic dispositions reproduce the exact chains already sealed, including Compact's literal aliases of EntryCertificates. No aliases are mistaken for independent implementations. Root append order is U(second)U(first); the exact rational and sqrt amplitudes, support zeros and phase are unchanged. The EntryCertificates target supplies selected entries and generic off-context rules, not a final preparation/root/cost theorem of its own. Its provider's whole block theorem supplies the complete operator meaning; the target's few samples do not establish it on their own.

In sparse required columns, twelve helper zeros are 10,30,40,50,60,70,04,14,24,34,54,74 (row then column). Entry 64 is DIFFERENT: contexts agree and RY(0)'s off-diagonal entry is zero. Decoder's complete coordinate proof treats it correctly. Bell/dense share target columns with separate matrix-level completions mentioned in the natural contract, but no full matrix identity for those separate completions is in the released scope. Neither review manufactures that stronger equality. Sparse dense-tree/pruned equality, in contrast, really is all-input operator equality.

Pruned and dense-tree circuits independently suffice as mathematical witnesses for the sparse target (algorithmic OR). Decoder is a formal-only reconstruction, not a source graph extractor: it correctly describes dense-tree as a literal identity extension and its proof's dependence on identity equality AND pruned preparation. My prior source OR is a sufficiency topology, not an assertion that these formal proofs are independent. There is no conflict or missing alternative witness, and this reconciliation does not turn the OR into simultaneous required resources.

## 6. Costs, exact syntax refinements and ranking

Decoder sections 6.1/6.3/6.4/7 give the same RY/CX counts, literal instruction order, touched-wire max+1 scheduler, defaults and four tuple equalities:

- Bell: 1 RY+1 CX, (aux,gates,depth,oracles)=(0,2,2,0).
- Dense and sparse pruned: each 3 RY+2 CX, (0,5,4,0).
- Sparse dense-tree: 7 RY+8 CX, (0,15,13,0).

Dense/pruned layer trace is 1,1,2,3,4 because their first two rotations are disjoint. After pruned wire depths (q0,q1,q2)=(0,4,4), the ten retained zero-fill instructions have layers 1,5,6,7,8,9,10,11,12,13. A semantically identity block therefore still adds four RY and six CX. Counts are literal emitter counts, not after cancellation, and depth is not the sum of block depths or chronological list lengths.

The resource carrier's five Nat defaults are zero; gates sum oneQubit+cnot+oracleCalls; primitive resource explicitly supplies zero oracle/pure-ancilla, and route cost explicitly sets auxiliaryQubits=0 for lists on target wires. This is not a theorem about hidden physical workspace. Both accounts retain the whole strict lexicographic disjunction: gates first, then tied-gate depth, tied-depth auxiliaries, then tied-auxiliaries oracles. It is NOT a Pareto order. The actual comparison uses only 5<15 in its first OR branch, for two circuits with the exact SAME sparse target.

Two successor-only wording refinements are recorded without editing older phases or decoder:

1. My Stage1/Stage2 shorthand that fill rotations have angle zero means EVALUATED zero. Decoder notes their emitted ExactAngle trees are recursively built half-add/half-sub expressions and need not literally equal the `ryAngleZero` constructor. That is correct. The four-rotation/six-CX syntax and all action/cost statements are unchanged.
2. Decoder section 5 calls the sparse certificates “four positive entries” while explicitly listing (6,4)=0. Read literally, positivity of all four is false. The displayed values, its coverage and all proofs use the zero correctly, so the accurate wording is “four selected/certified entries,” three nonzero and one zero. This is a terminology correction in this Stage3 record, not a theorem-level mismatch or a silent edit of decoder evidence.

The precise tier stays ideal exact-real logical RY/CX with wire conflicts. All three accounts exclude uniform arbitrary-input algorithms, universal optimality/lower bounds, finite-bit angle errors or Clifford+T, input evaluation/preprocessing/oracle construction/runtime, hardware routing/noise/readout. Zero oracle calls describes the literal modeled lists, not free access to arbitrary data. The fixed input action is deterministic; no postselection or amplification branch has been omitted.

## 7. Typed judgment and remaining boundaries

My earlier bounded mathematical judgment needs no substantive retraction or theorem repair after reading the actual decoder. The zero-syntax sharpening and decoder positivity-word correction above are explicitly new Stage3 records. All old payloads remain immutable. No REFUTED or SOURCE_INVALID finding, route retirement, production patch, promotion, default-route choice or salvage deletion is justified by this comparison.

This closes the actual cross-reader static semantic comparison for the bounded LOCAL contract and the released formal snapshots. It does not close a historical independent natural source extraction, source-paper proof graph, exact-current-input Lean/Tests/trust gate, full-original-module publication binding, schema admission, integration/purification or Exposition Seal. Provider originals remain partly masked, import/transitive environments unread, and native_decide/decide source scripts unexecuted. Count agreement and independent-reader agreement cannot replace those gates. External names, provenance strings and Eq.(2) metadata remain data rather than authenticated paper statements or algorithms; no external-paper refutation or correction is proposed.

`typed-findings.json` preserves these distinctions. `raw-input-pins.json` binds actual decoder artifacts, all 32 formal inputs and all 13 prior-stage artifacts. `coverage-reconciliation.json` exposes exact inventory pairing rather than relying on matching totals alone. Seal this successor stage, then STOP before any later current-binding wrapper or publication action.
