# Independent natural-source topology review

Verdict: ACCEPT for the bounded LOCAL natural-source topology, not for implementation correctness, external-paper fidelity, or publication admission.

Reviewer: `sp_extended_topology_independent_c44`. Proposed-graph extractor: `sp_extended_source_first_c43`. This reviewer read the two raw mathematical inputs through EOF and the six assigned governance files, without implementation, decoder, extractor rationale, prior verdict, or other worker output. Both mathematical input hashes were unchanged after reading.

The proposed graph covers all substantive regions of the retrospective contract with 51 nodes and 30 hyperedges. Its section-level coverage is coarse but its individual claims retain the needed formulas, coordinates, context distinctions, and boundaries. No substantive omission or incorrect AND/OR edge requiring revision was found. The accompanying coverage record gives a finer independent inventory.

Backward tracing reaches the actual bounded conclusions: the three fixed-target actions and normalizations, their four route records, the generic zero-angle operator identity, the sparse dense-tree/pruned operator equality, fixed-list costs, and the lexicographic comparison. Bell and dense first-column actions are not upgraded to equality with separate provider matrices. Sparse entry (6,4) is correctly an on-context RY(0) zero, while the other twelve sparse helper zeros use the full non-target context, including q0.

The sparse existence edge is a genuine OR between sufficient route witnesses. The dense-tree proof separately has an AND dependency on the pruned action and identity fill. Neither distinction is lost. Resources count the actual retained instructions; depth is wire-conflict depth, not serial list length. All output amplitudes and equalities retain their exact phases and LE coordinates.

The generic CX, primitive unitarity, and compiler semantics are explicitly reused source-supplier assertions. Acceptance here means their role and domain are represented honestly, not that this reviewer authenticated or proved those suppliers. No formal verification is inferred from a natural supplier node. G04 preserves the deferred formal/evidence gates. G01-G03 preserve absent external-paper authentication, general algorithms, and stronger complexity claims; those gaps do not support any finite-bit or named-paper conclusion.

The natural source is explicitly retrospective and implementation-informed. This review removes the distinct extractor self-approval risk for its LOCAL graph only. It does not turn the source into an independently authenticated paper, establish a pre-implementation chronology, or certify the source author's per-declaration coverage assertions. Purification, Exposition Seal, and production admission remain pending outside scope.

Failure class: NONE. Salvage: no rejected route; no implementation fragment promoted. Process-memory records: none consulted, because the allowlist excludes them. Direction: independent-source-graph-complete-coverage-without-Lean. Expected information gain: independent detection of source-region omissions and false topology, distinct from extraction and formal review. No children, compilation, native UI, network, Git, registry, or production writes were performed.
