# Stage2: source-first natural chain versus released formal snapshots

Direction: `independent-source-first-to-full-formal-comparison`. Expected gain: identify exact semantic/binder mismatch before any decoder comparison. Reviewer: `/root/sp_extended_source_first_c43`.

## Result and evidence level

Within the released complete target snapshots and the supplied bounded provider declarations, I found no mathematical state-action, operator-identity, binder, phase/order, or fixed-resource mismatch with my sealed Stage1 reconstruction. This is a text-level source-first comparison, not compilation acceptance, kernel/axiom certification, source-paper authentication, or final publication admission. Native tactics occur in source; none were executed. The actual distinct decoder, author graph, author binder inventory and other verdicts were not read.

Stage1 remains byte-for-byte unchanged, bound by `stage1:/seal.json` SHA256 `7b20a4f55d03141d24633211c202fcc50584ba32c88a45315750e9972bdfa832`. The natural input was already retrospective and implementation-informed. Only this worker's present natural-before-formal chronology is independent; no historical preproof independence is claimed.

The inspection covers all three target snapshots to EOF and every supplied provider snapshot/extent to EOF: 17 Lean snapshots, 14 extent records, 140 target and 206 provider lexical declarations, including 87 private declarations total. `coverage.json` is my own enumeration, not author inventory. It records all retained explicit declaration windows and ambient import/open/namespace/attribute/deriving commands. Those windows are lexical source locations, not elaborated types, generated private declaration names, compiler dependency edges or semantic proof of coverage. Import statements were read but not followed outside the supplied snapshots. Provider blank masks are not evidence about omitted declarations; source comments blanked in export cannot be independently recovered.

## 1. Carrier, order and actual action

`Core.lean` supplies gridSize(n)=2^n. `ConcreteSemantics.lean` supplies state vectors as finite functions, `basisKet=Pi.single index 1`, `zeroKet` at zeroBasisIndex, and `applyVec=Matrix.mulVec`. Its basis/zero column-selection and two-basis vector/scalar linearity theorems are actual equalities; none is an arbitrary Prop supplier.

`PrimitiveBasisLE.lean` defines the bit bijection recursively, with successor value b(0)+2*tailIndex. Its inverse-bit definitions and two/three-wire context lemmas agree with q0 least significant. The finite proofs contain `native_decide`; here the bit conventions are additionally checked directly from their literal definitions. `StatePreparationPrimitiveRoutes.lean:21` reindexes the actual primitive interpreter by this one bijection. The append theorem explicitly gives U(left++right)=U(right)U(left), and the target roots use that same orientation.

`PrimitiveSemantics.lean` defines CX as a permutation fixing non-target wires, and its permutation matrix provider uses row=equiv(column). Bell's generic singleton-CX theorem has arbitrary qubit count, separated typed control/target and arbitrary row/column, with precisely this row/output orientation. It does not assume a correctness theorem as an extra binder. `splitPrimitiveWire` is an explicit equivalence between full assignments and (target bit, all other wires); no basis convention is left as an unproved identification in the target proofs.

## 2. Rotations and phase

The literal rotation is R(c,s)=[[c,-s],[s,c]], `standardRyMatrix(theta)=realRotation(theta/2)`. Private rational constants 3/5,4/5,5/13,12/13 and the exact twice-arccos angle constructors agree with Stage1. The Pythagorean supplier proves sin(arccos c)=s using c in [-1,1], s>=0, and c^2+s^2=1; concrete bounds/sign/normalization are discharged inside the fixed-angle suppliers, not assumed by preparation roots. EntryCertificates' two exposing theorems and Compact's beta exposing theorem only normalize coercions.

Bell's angle is `.piRational (1/2)` and its evaluation theorem is pi/2. Its RY matrix bridge reaches the supplied warm matrix R(sqrt2/2,sqrt2/2). The target amplitude comes from the same exact real sqrt2/2 embedded in C. Therefore the plus-plus Bell state is not supplied only up to phase. Every root is literal complex-vector equality; the zero-fill relation is literal matrix equality. There is no quotient or floating tolerance. `PrimitiveProgram` has a globalPhase field in general substrate, but these roots use `PrimitiveCircuit`, not a phase-adjustable program. RZ/star/dagger general helpers were read and are not misreported as a general phase-loading algorithm for these examples.

## 3. Full-context UCRY and compiler domain

The block matrix's angle assignment reads the ROW's complete non-target context through `primitiveControlAssignment`. Its entry theorem is zero unless all non-target bits of row and column agree; only under that equality does it read the target RY row/column entry. Thus column orientation would give the same control assignment in the nonzero branch, but this is an argument using context equality, not permission to ignore non-control wires.

Both compiler and theorem take only `distinct : forall i, wires i != target`; they do not require injective controls. In the recursive proof, a fixed context supplies head and tail control bits, with `prependControlBit 0/1 tailBits` proved equal to the actual assignment. The proof works when controls repeat because neither rotation block changes that context. On head zero it adds half angles; on head one it uses X RY(d) X=RY(-d), then h-d=A1. The compiler consumes the first tuple entry as head and uses its remaining entries recursively. It retains every zero angle and both CXs per internal recursion node. The two count proofs yield 2^m RY and 2(2^m-1) CX. The recursive matrix definition is separate from the full block-diagonal specification, and the supplied theorem bridges them rather than inferring specification from samples.

Compact's generic zero-angle theorem is a complete operator theorem. Under equal contexts it proves row=column iff row(target)=column(target) using split equivalence, then rewrites RY(0)=I. Under unequal contexts it derives row!=column and both deltas vanish. There is no state-specific shortcut, omitted off-context sector, or injectivity premise. Zero controls are admissible. A typed target must exist, so this is not an executable n=0-target case.

## 4. Finite preparation chains and topology

| Chain | Snapshot anchors | Comparison with sealed natural chain |
|---|---|---|
| Bell | BellRoute:18-305 | Exact RY column (a,a,0,0), CX columns 0/1 and all four weighted outputs, linearity, append composition, concrete norm and record agree with B01-B05/RB. |
| Dense entries | EntryCertificates:23-111 | Exact alpha/beta coercions, control q1/target q0, full context mismatch zero and four nonzero required entries agree with M01/M03. |
| Dense action | Compact:25-264 | Literal aliases, four root coordinates, four required cross-context zeros, four weighted scalars, all-row linearity and root composition agree with M01-M06/RM. |
| Sparse entries | EntryCertificates:112-184 | Control q2/target q1, alpha versus zero, full context (q0,q2), three nonzero entries and on-context (6,4)=0 agree with S01/S03/S04. |
| Sparse pruned | Compact:299-632 | Root coordinates on 0/4, twelve full-context zeros, eight weighted scalars, all-row linearity and composition agree with S01-S07/RSP. |
| Zero fill/dense-tree | Compact:267-296,634-679 | Generic full identity; controls ordered (q1,q2), target q0; LE reindex identity; all-input operator equality; reuse of pruned action and same concrete target/norm agree with Z01-Z05/RSD. |

The exact targets are Bell (a,0,0,a), dense (39,52,60,144)/169 and sparse (3,0,4,0,12,0,0,0)/13. Sparse support indices are 0,2,4, not 0,1,2; q0 is a third target-register coordinate kept zero for this input, not an allocated ancilla. Dense's root has support 0,2; sparse's root 0,4. All zeros needed for their two input columns appear in the respective supplied entry or Compact helper declarations.

In particular Compact's twelve sparse mismatch zeros are 10,30,40,50,60,70,04,14,24,34,54,74 in row-column notation. Entry 64 is supplied separately with `if_pos` for equal context and `standardRyMatrix_ryAngleZero`, exactly as Stage1 diagnosed. Dense's mismatch zeros 02,12,20,30 likewise use the full context predicate, not an assumed entry table.

Sparse pruned and dense-tree are two sufficient witnesses for the same target (algorithmic OR). The dense-tree proof uses the pruned state theorem AND identity-fill operator equality. All-input equality does not need the pruned state theorem, while the final dense-tree state theorem does. This is the same AND/OR distinction sealed in Stage1; a graph must not turn either witness into a required independent preparation resource.

Bell and dense separate provider matrix completions are not among these supplied definitions and no target theorem claims their full equality to these circuits. Their absence is not a state-action mismatch. The positive claim here is actual primitive circuit action and derived unitarity, not merely a provider sharing a first column or a named circuit without action.

## 5. Expanded records, binders, defaults and definitions

`StatePreparationTarget` has amplitudes, `normalization : Prop`, and `source : String := ""`. The generic normalization slot is not intrinsically a norm-one predicate. Each of the THREE concrete targets explicitly stores sum_k Complex.normSq(amplitude(k))=1, with the supplied proofs of 2a^2=1, 39^2+52^2+60^2+144^2=169^2 and 3^2+4^2+12^2=13^2.

`ExactPrimitiveStatePreparationRoute` has target, typed circuit, `normalizationProof : target.normalization`, and actual equality `applyVec (evalPrimitiveCircuitLE circuit) (zeroKet n)=target.amplitudes`. It does not contain a user-selectable `isUnitary : Prop` placeholder. General primitive-gate unitarity is proved from the actual X/RY/RZ/CX semantics, composed by induction, then transported through LE reindexing; route.unitary derives actual matrix unitary-group membership. `ComplexUnitaryGate` likewise stores actual membership, not arbitrary named Prop, but it is not an extra root assumption. Even a vacuous generic normalization proposition would not erase the actual route action requirement; actual unitary action on e_0 also mathematically forces norm one. No such vacuous predicate is used in these four records.

For all 140 target declarations the manual binder review falls into these complete categories (individual declarations/ranges in coverage.json):

- Literal target angle/wire/list/vector/record definitions have no added proof inputs. Their bound terms are explicit finite data, aliases or proof-bearing assemblies.
- All fixed coordinate, entry, scalar, composition, route-cost and route-comparison theorems have no external proof premise. The exact source syntax's local `show`, `have`, `let`, type casts and finite distinctness proofs are internal proof steps.
- Bell's generic CX theorem has implicit qubits, explicit control/target, wire-separation proof and row/column. These are exactly the generic natural contract's typed-domain and separation requirements, not a supplied CX-correctness premise.
- EntryCertificates' two generic mismatch theorems and Compact's two private zero helpers have exactly row/column and unequal FULL context hypotheses. The generic predicate is transported unchanged; finite uses discharge it internally.
- Compact's zero-angle compiler theorem has implicit qubits/controls, wires/target and every-control-versus-target separation. No control injectivity, identity assumption, or preparation premise is added.
- The finite wire-separation theorems quantify only the finite control position; their proof is internal. There are no ambient `variable` sections or project typeclasses injecting hidden target hypotheses. The provider cost/unitary helpers' implicit qubits are typing data, not logical proof premises.

Generic provider lemmas genuinely state their necessary premises: a one-qubit unitary lift assumes its supplied gate's unitary-group membership; reindexing assumes its operator is unitary; the Pythagorean bridge assumes the numerical circle/sign/bounds; amplitudeRotation's clean entry assumes arccos bounds. These are correct internal supplier interfaces applied with produced evidence, not extra source-root binders. Generic algebraic semiring/Fintype/DecidableEq carriers were read; concrete roots specialize to the fixed complex finite carriers. No human-approved correction or source-excess hypothesis was needed in the inspected finite roots.

Definitions introduced by the target group are literal formulas, lists/compiler calls, aliases and record assembly. Private exact-angle values carry their arccos typing bounds. No classical choice, uniqueness of unitary completion, implicit normalization, off-domain zero fallback, phase quotient, or representative-independence claim occurs in the inspected group. `noncomputable` flags exact real semantics, not runtime success or runtime impossibility.

## 6. Costs and ranking

`Resource` defaults oneQubit,cnot,oracleCalls,pureAncilla,depth to zero; gates=oneQubit+cnot+oracleCalls. Primitive resource explicitly sets oracleCalls=0,pureAncilla=0 and obtains depth from per-wire `Finset.sup`/max+1 scheduling. Route.cost explicitly sets auxiliaryQubits=0 and takes circuit.resource's gates/depth/oracleCalls. All qubits in the examples are target wires.

The root cost source statements are (auxiliaries,gates,depth,oracles)=(0,2,2,0),(0,5,4,0),(0,5,4,0),(0,15,13,0) for Bell,dense,pruned,dense-tree. Each source proof is `by decide`; I did not execute it. Independently applying the visible scheduler to the visible lists gives layer traces 1,2; 1,1,2,3,4; 1,1,2,3,4; and pruned followed by 1,5,6,7,8,9,10,11,12,13 for the zero fill. That fill is 4 zero RY+6 CX, not an empty optimized list. The first fill RY_q0 can overlap layer 1; its first CX(q2,q0) waits for q2 at 4. This explains depth 13 and gate count 15 while its operator is I.

`betterThan` retains the full disjunction: fewer gates OR equal gates AND (less depth OR equal depth AND (fewer auxiliaries OR equal auxiliaries AND fewer oracles)). The final comparison selects Or.inl because 5<15; it does not redefine the ranking or discard its other branches. The compared circuits prepare the SAME sparse target. This is exact-real ideal logical count with wire conflicts, not arbitrary input access, finite-bit angle synthesis, Clifford+T, connectivity/routing/noise, preprocessing/runtime/readout, universal optimum, lower bound or asymptotic sparse-family theorem. No branch success or amplification is missing from these deterministic fixed-input lists; there is no such operation here.

## 7. Residual boundaries and handoff

Typed observations are in `typed-findings.json`: positive finite matching is retained, record weaknesses are distinguished from actual content, native/source excerpt/paper/cost boundaries remain explicit. No REFUTED or SOURCE_INVALID evidence was obtained; no production route is retired or repaired. The supplied provider extents are bounded and blank masked, not whole original modules. All 31 formal-track payload hashes/lengths match the supplied manifest; original-source digests inside extents are metadata, not locally observed original files. No imports outside the released packet were fetched. No axiom-transitive or current compiler/build assertion is made; own lexical scan sees no sorry/axiom token in the 346 windows but that is not an axiom audit.

This worker did not act as a distinct formal-only decoder and did not inspect one. A later independent decoder comparison, exact-current-input Lean/Tests and trust checks, independent topology review, common-blind-spot review of surviving routes, and publication/purification/Exposition Seal are still separate gates. External named-paper statements/full algorithms/phase loading/general complexity remain unauthenticated gaps. The present output does not self-approve them.

Failure class: NONE for this bounded text-level finite comparison; missing acceptance gates are deferred evidence, not negative mathematics. No fragments require salvage or deletion; the positive finite actions/operator/cost mechanisms remain available for later gates. Process-memory records consulted: none (not allowlisted); the six already-read process documents only govern procedure. No children, compilation/native execution, network/Git/CI, production/registry writes or actual decoder/author-graph reads occurred. Stop after content sealing; do not mutate Stage1 or this evidence in a later phase.
