"""Portable, read-only exact decoder/capsule and prior-byte verification."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--repo-root', type=Path, required=True)
p.add_argument('--workspace-root', type=Path, required=True)
args = p.parse_args()
R, W = args.repo_root.resolve(), args.workspace_root.resolve()
B = R / 'reviews/publication/sp-extended-c44'


def sha(b):
    return hashlib.sha256(b).hexdigest()


def readj(p):
    return json.loads(p.read_bytes())


expected = {
    'opaque-decoder-control.json': 'b9cea6e1d153e4e28bcffc7dd2a2472787d92310e861f0e0172aa92790f2a418',
    'final-decoders-original7.zip': '70af17def9706263cb5b3d8a6e26b4711602c5dda37972e8bf7d720010b0c8c8',
    'formal-only-original32.zip': 'e3332d9576c572cbff9f542695ef06a68cd50ecf9c7474f2fafa81e064fb1ebe',
    'sp-extended-c44-formal-decoder.zip': '8108a043a23b31e918232fec53457ba2dda5fcd3ff610487bdf770515bcb4f0c',
}
wrapper_expected = dict(zip(
    ['StatePreparationBellRoute', 'StatePreparationPaperEntryCertificates', 'StatePreparationPaperRoutesCompact'],
    ['703ae72aa9e439db3afc8203d147932f0c9423ce4198e1f989e3874368c01535',
     '030a38c1fc9277707f60200749d9af10e3acabd0ef0eada583d22ca273ccb8c3',
     '062364b5cabf8d5aa98065e73aeebc21dcaecfaa146deccb0d7c59070b66418d']))
inputs = []
for name, digest in expected.items():
    data = (B / name).read_bytes()
    assert sha(data) == digest, 'New input hash mismatch: ' + name
    inputs.append({'path': 'repository:/reviews/publication/sp-extended-c44/' + name,
                   'bytes': len(data), 'sha256': digest})
control = readj(B / 'opaque-decoder-control.json')
context = readj(B / 'prospective-context.json')
records = {r['module']: r for r in context['records']}
old_current = readj(W / 'sp-extended-c44-source-review-phase4/observed-checks.json')
old_raw = {r['path']: r['sha256'] for r in old_current['current_hash_only_inputs']}
assert len(control['proof_inputs']) == 207
assert {r['path']: r['sha256'] for r in control['proof_inputs']} == old_raw
current = []
for item in control['proof_inputs']:
    path = (R / item['path']).resolve()
    assert path.is_relative_to(R)
    actual = sha(path.read_bytes())
    assert actual == item['sha256'], 'Current raw pin drift: ' + item['path']
    current.append({'path': item['path'], 'sha256': actual})

with zipfile.ZipFile(B / 'sp-extended-c44-formal-decoder.zip') as original:
    original_members = {n: sha(original.read(n)) for n in original.namelist()}
    assert len(original_members) == 5
    original_seal = json.loads(original.read('seal.json'))
    assert original_members['seal.json'] == '26cda722cb01d98adabd10ded64b8892bf4e381f4205069e0c5bcbea8c41160d'
    for item in original_seal['payload_files']:
        assert original_members[item['path']] == item['sha256']
    original_pins = json.loads(original.read('input-pins.json'))['formal_inputs']
    assert original_members['reconstruction.md'] == '2130a3ac4fa6239928aac94e9a2c2873aecd1a87da729402ac1aa0d660bb824d'
    for name, digest in original_members.items():
        assert sha((W / 'sp-extended-c44-formal-decoder' / name).read_bytes()) == digest
with zipfile.ZipFile(B / 'formal-only-original32.zip') as formal:
    formal_members = {n: sha(formal.read(n)) for n in formal.namelist()}
    assert len(formal_members) == 32
    for item in original_pins:
        assert formal_members[item['path']] == item['sha256_before'] == item['sha256_after']
        assert len(formal.read(item['path'])) == item['bytes_before'] == item['bytes_after']

with zipfile.ZipFile(B / 'final-decoders-original7.zip') as final:
    final_members = {n: sha(final.read(n)) for n in final.namelist()}
    assert len(final_members) == 7
    seal = json.loads(final.read('seal.json'))
    for item in seal['payload_files']:
        data = final.read(item['path'])
        assert sha(data) == item['sha256'] and len(data) == item['bytes']
        assert data.endswith(b'\n') and not data.endswith(b'\n\n') and not data.startswith(b'\xef\xbb\xbf')
    integrity = json.loads(final.read('integrity.json'))
    entries = integrity['current_raw_proof_config_check']['entries']
    assert len(entries) == 207
    assert all(e['expected_sha256'] == e['actual_sha256'] == old_raw[e['path']] and e['matches'] for e in entries)
    wrappers = []
    for stem, digest in wrapper_expected.items():
        name = stem + '-decoder.json'
        data = (B / 'final-evidence' / name).read_bytes()
        assert sha(data) == digest == final_members[name]
        d = json.loads(data)
        assert d['binding_sha256'] == records[d['module']]['binding_sha256']
        assert d['role'] == 'decoder' and d['identity'] == control['original_identity']
        assert d['run_id'] == control['original_run_id']
        assert d['source_blind'] and not d['identity_blind']
        assert d['packet_path'] == control['formal_packet_path'] and d['packet_sha256'] == control['formal_packet_sha256']
        assert d['artifact_path'] == control['artifact_path'] and d['artifact_sha256'] == control['artifact_sha256']
        assert d['original_reconstruction']['sha256'] == original_members['reconstruction.md']
        assert not d['new_mathematical_reconstruction'] and not d['source_comparison_performed']
        wrappers.append({'path': 'repository:/reviews/publication/sp-extended-c44/final-evidence/' + name,
                         'module': d['module'], 'sha256': digest, 'binding_sha256': d['binding_sha256'],
                         'identity': d['identity'], 'run_id': d['run_id'], 'original_reading_reuse_verified': True})

prior = []
for name in ['sp-extended-c43-source-first', 'sp-extended-c43-source-review-phase2',
             'sp-extended-c44-source-review-phase3', 'sp-extended-c44-source-review-phase4']:
    directory = W / name
    seal = readj(directory / 'seal.json')
    for item in seal['payloads']:
        path = directory / item['path'].replace('output:/', '')
        assert sha(path.read_bytes()) == item['sha256']
        prior.append({'path': 'workspace:/' + name + '/' + path.name, 'sha256': item['sha256']})
    prior.append({'path': 'workspace:/' + name + '/seal.json', 'sha256': sha((directory / 'seal.json').read_bytes())})
private_zip = W / 'sp-extended-c44-source-review-phase4-raw-private.zip'
assert sha(private_zip.read_bytes()) == '3a59c5f9e5a1f35f66c644bd8973bf936550d2b8b862e9aa405a485e99321bb0'
print(json.dumps({'schema': 'aspbe-final-actual-decoder-integrity-v1', 'inputs': inputs,
                  'actual_decoder_wrappers': wrappers, 'formal_members': formal_members,
                  'original_decoder_members': original_members, 'late_binding_members': final_members,
                  'all207_current_pins_match': True, 'all32_original_formal_pins_match': True,
                  'single_original_reading_reused': True, 'current_hash_only_inputs': current,
                  'prior27_artifacts_unchanged': prior,
                  'privacy_quarantine': {'archive_sha256': sha(private_zip.read_bytes()),
                    'old_script_sha256': 'ae47383c8cb28fb1d336bb2291b054721c396f85e110c392188997813b6e8e8c',
                    'old_stage4_seal_sha256': '21a46e349bf6313fa9c6db09ba7654c9b3cb08473c3fe8bf3d775f3206787221',
                    'reason': 'Prior raw helper contained two literal machine root paths; preserved private, not copied into successor.',
                    'not_pushed': 'Parent attestation only; no Git check performed.'},
                  'opaque_control_alias': 'Wrapper basename names original workspace control; canonical repository opaque-decoder-control.json is pinned to the identical bytes.',
                  'no_compilation_or_new_semantic_read': True}, ensure_ascii=False))
