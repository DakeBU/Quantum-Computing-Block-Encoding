"""Read-only bounded metadata/hash reconciliation; no Lean/native/Git/network.

Current production/configuration files are read as bytes for SHA256 only.
No current declaration parser, compiler, catalog, registry, or role wrapper runs.
"""
import argparse
import hashlib
import json
import runpy
import zipfile
from pathlib import Path

parser = argparse.ArgumentParser(description='Read-only portable metadata verification')
parser.add_argument('--repo-root', type=Path, required=True)
parser.add_argument('--workspace-root', type=Path, required=True)
args = parser.parse_args()
R = args.repo_root.resolve()
W = args.workspace_root.resolve()
N = W / 'sp-extended-routes-c43-publicsafe/natural'
F = W / 'sp-extended-routes-c43-publicsafe/formal-only'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


context_path = R / 'reviews/publication/sp-extended-c44/prospective-context.json'
graph_path = R / 'reviews/publication/sp-extended-c44/current-graph-context.json'
context = read_json(context_path)
graph = read_json(graph_path)
source = next(s for s in read_json(R / 'website/research/sources.json')['sources']
              if s['id'] == context['source_row']['id'])
checker_path = R / 'website/scripts/check_research_publications.py'
# Run under a non-main name: defines original functions without its CLI/Git gate.
original = runpy.run_path(str(checker_path), run_name='bounded_hash_algorithm_only')
binding_function = original['binding_digest']
bindings = []
for record in context['records']:
    actual = binding_function(R, record)
    bindings.append({'module': record['module'], 'expected': record['binding_sha256'],
                     'actual': actual, 'match': actual == record['binding_sha256']})

paths = sorted((R / 'QuantumBlockEncoding').rglob('*.lean'))
paths += sorted((R / 'ABEISTests').rglob('*.lean'))
config_names = ['lean-toolchain', 'lake-manifest.json', 'lakefile.lean',
                'QuantumBlockEncoding.lean', 'Tests.lean']
pins = [{'path': p.relative_to(R).as_posix(), 'bytes': len(p.read_bytes()),
         'sha256': sha(p.read_bytes())} for p in paths + [R / n for n in config_names]]
current_hashes = {p['path']: p['sha256'] for p in pins}
own = read_json(W / 'sp-extended-c43-source-review-phase2/coverage.json')
own_files = {f['path']: f for f in own['files']}
decoder = read_json(W / 'sp-extended-c44-formal-decoder/independent-declaration-coverage.json')
decoder_targets = {t['path'].replace('formal-only/', ''): t for t in decoder['targets']}

author_checks, author_pins = [], []
for record in context['records']:
    base = Path(record['module']).stem
    author = {}
    for kind in ('audit', 'inventory', 'coverage'):
        p = N / kind / (base + '.json')
        author[kind] = read_json(p)
        author_pins.append({'path': 'natural:/' + kind + '/' + p.name,
                            'bytes': len(p.read_bytes()), 'sha256': sha(p.read_bytes())})
    audit, inventory, coverage = (author[k] for k in ('audit', 'inventory', 'coverage'))
    relative = 'targets/' + record['module']
    old = own_files[relative]
    snapshot = (F / relative).read_text(encoding='utf-8')
    public = {d['source_identifier'] for d in inventory['declarations'] if not d['private']}
    mapped = {n for item in record['obligation_map'] for n in item['declarations']}
    audit_by = {d['identifier']: d for d in audit['declarations']}
    rows = []
    for d in inventory['declarations']:
        a = audit_by[d['source_identifier']]
        o = next(x for x in old['decls'] if x['s'] == d['source_start_line'])
        piece = snapshot[d['start_character']:d['end_character_exclusive']]
        rows.append({'identifier': d['source_identifier'], 'line': d['source_start_line'],
                     'private': d['private'], 'prior_group': o['group'],
                     'old_name_kind_private_match': (o['n'] == d['name'] and o['k'] == d['kind'] and o['p'] == d['private']),
                     'masked_command_hash_matches_prior_formal': sha(piece.encode()) == d['masked_command_sha256_utf8'],
                     'header_hash_ok': sha(d['header'].encode()) == d['header_sha256_utf8'],
                     'body_hash_ok': sha(d['body'].encode()) == d['body_sha256_utf8'],
                     'audit_header_matches_inventory': a['complete_header'] == d['header'],
                     'audit_header_body_digests_match': (a['complete_header_sha256_utf8'] == d['header_sha256_utf8'] and
                         (a['definition_audit'] is None or a['definition_audit']['body_sha256_utf8'] == d['body_sha256_utf8'])),
                     'logical_inputs': a['logical_inputs'],
                     'corrections': a['additional_rule_or_correction_inputs'],
                     'author_excess': a['excess_inputs_in_original_finite_contract'],
                     'body_local_bindings_match': a['body_local_bindings'] == d['local_let_have_names'],
                     'public_recorded': d['source_identifier'] in record['declarations'],
                     'review_level': a['review_level']})
    line_hits = [0] * (inventory['line_count'] + 1)
    for item in coverage['items']:
        for line in range(item['start_line'], item['end_line'] + 1):
            if 0 < line < len(line_hits):
                line_hits[line] += 1
    decoder_ambient = [x for x in decoder_targets[relative]['commands'] if x['kind'] == 'ambient_command']
    author_checks.append({'module': record['module'], 'declarations': rows,
                         'counts': {'total': len(rows), 'public': len(public),
                                    'private': sum(r['private'] for r in rows)},
                         'public_set_exact': public == set(record['declarations']),
                         'obligation_set_exact': public == mapped,
                         'graph_public_nodes_present': {'declaration:' + x for x in public}.issubset(set(record['graph_contribution']['node_ids'])),
                         'original_raw_hash': inventory['raw_sha256'],
                         'current_module_hash': current_hashes[record['module']],
                         'current_raw_equals_inventory': current_hashes[record['module']] == inventory['raw_sha256'],
                         'coverage_raw_hash_matches_inventory': coverage['raw_sha256'] == inventory['raw_sha256'],
                         'coverage_line_count': inventory['line_count'],
                         'line_partition_exact': all(n == 1 for n in line_hits[1:]),
                         'coverage_items': len(coverage['items']),
                         'imports': inventory['imports'], 'scope_commands': inventory['scope_commands'],
                         'decoder_ambient_count': len(decoder_ambient)})

provider_hash_checks = []
for p in sorted((F / 'extents').glob('*.json')):
    extent = read_json(p)
    provider_hash_checks.append({'module': extent['source'], 'expected_raw': extent['raw_sha256'],
                                 'actual': current_hashes.get(extent['source']),
                                 'match': current_hashes.get(extent['source']) == extent['raw_sha256']})

archives = []
for name in ('sp-extended-c44-topology-independent.zip', 'sp-extended-c44-four-view-independent.zip'):
    p = R / 'reviews/publication/sp-extended-c44' / name
    expected = next(a for a in graph['actual_evidence_capsules'] if a['path'].endswith('/' + name))
    with zipfile.ZipFile(p) as z:
        member_checks = [{'member': n, 'sha256': sha(z.read(n)),
                          'context_match': sha(z.read(n)) == expected['members'].get(n)} for n in z.namelist()]
        seal = json.loads(z.read('seal.json'))
        seal_checks = [sha(z.read(m['path'])) == m['sha256'] and len(z.read(m['path'])) == m['bytes'] for m in seal['files']]
    archives.append({'archive': name, 'sha256': sha(p.read_bytes()),
                     'context_match': sha(p.read_bytes()) == expected['sha256'],
                     'members': member_checks, 'own_seal_payloads_all_match': all(seal_checks)})

prior = []
for name, root_label in [('sp-extended-c43-source-first', 'stage1:'),
                         ('sp-extended-c43-source-review-phase2', 'stage2:'),
                         ('sp-extended-c44-source-review-phase3', 'stage3:')]:
    directory = W / name
    seal = read_json(directory / 'seal.json')
    for item in seal['payloads']:
        p = directory / item['path'].replace('output:/', '')
        prior.append({'path': root_label + '/' + p.name, 'sha256': sha(p.read_bytes()),
                      'matches_old_seal': sha(p.read_bytes()) == item['sha256']})
    prior.append({'path': root_label + '/seal.json', 'sha256': sha((directory / 'seal.json').read_bytes())})

print(json.dumps({'schema': 'aspbe-stage4-readonly-observed-checks-v1',
                  'original_binding_algorithm_sha256': sha(checker_path.read_bytes()),
                  'binding_function_only_executed': True, 'full_check_or_Git_not_executed': True,
                  'prospective_context_sha256': sha(context_path.read_bytes()),
                  'current_graph_context_sha256': sha(graph_path.read_bytes()),
                  'graph_context_hash_matches_all_records': all(r['graph_contribution']['graph_context_sha256'] == sha(graph_path.read_bytes()) for r in context['records']),
                  'selected_actual_source_row': source, 'source_row_equals_context': source == context['source_row'],
                  'selected_source_row_canonical_sha256': sha(json.dumps(source, sort_keys=True, ensure_ascii=False).encode()),
                  'lesson_hash': sha((R / context['records'][0]['lesson_path']).read_bytes()),
                  'production_test_Lean_hash_count': len(paths), 'config_hash_count': len(config_names),
                  'current_hash_only_inputs': pins, 'bindings': bindings,
                  'author_metadata_pins': author_pins, 'author_checks': author_checks,
                  'provider_raw_hash_checks': provider_hash_checks,
                  'archives': archives, 'prior_phase_checks': prior}, ensure_ascii=False))
