# Independent natural reconstruction: extended finite SP contract

Stage: `natural-only-before-formal`. Direction: `independent-natural-extended-SP-contract-before-formal`.

This reconstruction uses only `natural-input:/math-proof-contract.md` (SHA256 in `raw-input-pins.json`) as mathematical input. That input is an implementation-informed retrospective original LOCAL teaching contract. It is not authenticated evidence for a general named-paper theorem. The present reviewer has not read the implementation, formal-only packet, inventories, other reviews, or publication records. Assertions about providers below describe the natural contract's mathematical interfaces, not independently checked implementation facts. This is neither a historical/preproof seal nor an independent decoder report.

## 1. Carriers, operators, and premises

The carrier is C^(2^n), with complex column vectors and computational basis e_k. Bits b:Fin n -> Fin 2 encode k=sum_j 2^j b(j); q0 is least significant. Thus |01> is index 1, |010> index 2, |100> index 4. Input e_0 is the all-zero target register. Chronological concatenation A;B denotes U(B)U(A), not the reverse. Reindexing the bit interpreter with the fixed LE bijection changes coordinates, not semantics. Matrix-vector multiplication on e_0 selects column 0.

Define R(c,s)=[[c,-s],[s,c]] and RY(theta)=R(cos(theta/2),sin(theta/2)). With alpha=2 arccos(3/5), beta=2 arccos(5/13), gamma=pi/2 and a=sqrt(2)/2>0:

- RY(alpha)=R(3/5,4/5), RY(beta)=R(5/13,12/13).
- RY(gamma)=R(a,a); RY(0)=I.

These follow from the nonnegative sine of arccos and the unit-circle identity, not floating-point evaluation. CX(c,t), c!=t, is the bit permutation b(t) <- b(t) xor b(c), fixing every other bit. Its matrix is the permutation delta. Primitive lists have unitary semantics. All equalities here are exact complex vector or operator equalities, including global phase; there is no phase quotient, measurement, postselection, or implicit normalization.

The fixed preparation claims have no extra external proof premise: their angles, wires, lists and targets are literal data; rotation evaluations, wire inequalities, normalization, entry actions, linearity and concatenation are suppliers inside the argument. Generic CX takes typed separated wires; generic UCRY takes a typed target, a control tuple, and each control != target. Mismatch lemmas additionally take the precise unequal-context proposition. These generic hypotheses cannot silently become added premises of the fixed roots. Dimensions/index carriers are typing data. No correction or excess-premise finding is inferred about unseen formal signatures.

## 2. UCRY mechanism and complete context

For target t let kappa_t(b) retain ALL non-target wires. For controls w_i and angle function A, the intended operator has entry zero if kappa_t(r)!=kappa_t(s), and otherwise RY(A((r(w_i))_i))[r(t),s(t)]. Under equal contexts row and column control bits agree. This specifies an entire operator, not selected samples. Controls may repeat; the condition is only w_i!=t. The concrete tuples are distinct.

The reference recursion consumes a first control and recursively uses half-sums then half-differences, with a CX after each recursive block. For one control the chronological list is RY_t((A0+A1)/2);CX(c,t);RY_t((A0-A1)/2);CX(c,t). For c=0 its rotations add to A0. For c=1 its action is X RY(d) X RY(h)=RY(-d)RY(h)=RY(A1), where h=(A0+A1)/2,d=(A0-A1)/2. Recursion fixes the whole non-target context at each step. Counts obey r_m=2r_(m-1), c_m=2c_(m-1)+2 with r_0=1,c_0=0, hence 2^m RY and 2(2^m-1) CX. This is not a Gray-code optimization and does not erase zeros or cancellations.

## 3. Three fixed targets and four sufficient circuits

| Route | Chronological circuit | Intermediate after root RY | Exact target |
|---|---|---|---|
| Bell | RY_q0(gamma); CX(q0,q1) | (a,a,0,0) | (a,0,0,a) |
| Dense | RY_q1(beta); UCRY(q1 -> q0; alpha,beta) | (5/13,0,12/13,0) | (39,52,60,144)/169 |
| Sparse pruned | RY_q2(beta); UCRY(q2 -> q1; alpha,0) | (5/13,0,0,0,12/13,0,0,0) | (3,0,4,0,12,0,0,0)/13 |
| Sparse dense-tree | sparse pruned; zero-UCRY((q1,q2) -> q0) | same sparse construction before identity fill | same sparse target |

Bell has exactly two target wires. The other two targets have two and three target wires respectively. Sparse q0 remaining zero is NOT an auxiliary-qubit assertion: q0 belongs to the target register. No route adds workspace.

Bell proof: the lift of RY_q0 gives column 0=(a,a,0,0). CX maps 0->0,1->3,2->2,3->1. Therefore CX(a e_0+a e_1)=a e_0+a e_3 by linearity. Concatenation gives the desired state. Its norm square is 2a^2=1. The two input columns actually used are CX[:,0]=(1,0,0,0) and CX[:,1]=(0,0,0,1); no additional first-column inference is needed.

Dense proof: the root lift gives (5/13)e_0+(12/13)e_2. UCRY has context q1 and blocks RY(alpha) on (0,1), RY(beta) on (2,3). Its needed columns are U[:,0]=(3/5,4/5,0,0), U[:,2]=(0,0,5/13,12/13). All four cross-context entries (r,s)=(0,2),(1,2),(2,0),(3,0) are zero. Their weighted sum yields the displayed target, one coordinate at a time. Concatenation supplies the root action. Normalization is 39^2+52^2+60^2+144^2=169^2.

Sparse proof: the root lift preserves q0,q1 and gives (5/13)e_0+(12/13)e_4. The UCRY target is q1; the full preserved context is (q0,q2), NOT q2 alone. Its columns needed for the action are U[:,0]=(3/5,0,4/5,0,0,0,0,0), U[:,4]=(0,0,0,0,1,0,0,0). Unequal full context supplies exactly (r,s)=(1,0),(3,0),(4,0),(5,0),(6,0),(7,0),(0,4),(1,4),(2,4),(3,4),(5,4),(7,4). Entry (6,4)=0 instead follows from the lower-left entry of RY(0); its contexts AGREE. The two remaining nonzero first-column entries and (4,4)=1 come from the appropriate RY blocks. Weighted linearity yields all eight target coordinates. Normalize by 3^2+4^2+12^2=13^2 and compose with the root action.

Generic zero-UCRY proof: when contexts differ both its entry and the identity delta vanish. With equal contexts RY(0) is the target-bit delta. The split-wire equivalence says that equal context AND equal target bit is equivalent to equality of the whole basis assignment, so this is exactly the identity delta. This holds for zero controls and repeated controls, and for any finite dimension admitting the typed target; n=0 has no target wire and is not an extra executable case. Reindexing preserves I. For controls (q1,q2), target q0, the dense-tree extension therefore satisfies U_denseTree=I U_pruned=U_pruned ON ALL INPUTS, not only e_0. Its state action follows.

Algorithmically pruned and dense-tree are alternative sufficient witnesses (OR). The supplied proof of dense-tree uses the pruned state action AND the zero-fill operator identity. Neither the OR nor this AND may replace the other. There is no claim that a Bell or dense primitive circuit equals its separately supplied full matrix completion: equal first columns do not identify unitary completions. The dense angle/list aliases denote the same objects, not independent constructions or changed semantics.

## 4. Resource tier and independent schedule reconstruction

The cost tuple is (auxiliaryQubits,gateCount,depth,oracleCalls); gates=one-qubit+CX+oracle calls. Primitive lists have no oracle calls or added ancilla. A gate's layer is one plus the largest previous depth on its touched wires; disjoint list entries can overlap. The fixed lists use only RY and CX.

| Route | RY | CX | Tuple | Chronological layer trace |
|---|---:|---:|---|---|
| Bell | 1 | 1 | (0,2,2,0) | 1,2 |
| Dense | 3 | 2 | (0,5,4,0) | 1,1,2,3,4 |
| Sparse pruned | 3 | 2 | (0,5,4,0) | 1,1,2,3,4 |
| Sparse dense-tree | 7 | 8 | (0,15,13,0) | 1,1,2,3,4;1,5,6,7,8,9,10,11,12,13 |

For the last trace the two-control zero fill is recursively RY_q0;CX(q2,q0);RY_q0;CX(q2,q0);CX(q1,q0);RY_q0;CX(q2,q0);RY_q0;CX(q2,q0);CX(q1,q0). Every RY angle here is zero. Its first RY can overlap layer 1; the first CX must wait for q2 at layer 4. The remaining trace reaches layer 13. Semantic identity does not make the retained list's counted cost zero.

The strict comparison order is gates first, then depth on equal gates, then auxiliaries on equal gates/depth, then oracle calls on all previous ties. Thus 5<15 is sufficient for this same-target comparison; the other lexicographic branches remain in the definition. This is neither an optimum nor a lower bound nor asymptotic sparse improvement.

The tier is exact-real ideal logical RY/CX with a wire-conflict scheduler. No finite-bit angles, Clifford+T, physical routing/connectivity/noise, classical preprocessing, arbitrary input access/construction, readout, numerical runtime, or uniform-family complexity follows. Zero oracle calls describes these literal lists, not free arbitrary data. Success is deterministic on the fixed input, with no nontrivial branch or amplification cost.

## 5. Definitions, representation boundaries, stronger-reading diagnostics

Literal objects include angle expressions, wire indices, lists/compiler calls, finite vectors, aliases and route-record assembly. There is no characterized unique choice, phase quotient, or unique unitary completion. A noncomputable marker is neither a runtime upper bound nor an impossibility result.

The route record carries a target, typed circuit, proof of its stored normalization proposition, and the ACTUAL state equality U(circuit)e_0=target amplitudes. Since the generic normalization slot can store an arbitrary Prop, the bare type/name alone does not imply unit norm. Here the three concrete norm-square predicates and identities above supply that content; alternatively actual unitary action on e_0 mathematically forces norm one. Unitarity is a supplier for typed circuits, not a freely selected record proposition.

Diagnostics for a later distinct formal comparison: verify the full-context UCRY zero rule; distinguish sparse (6,4) from mismatch zeros; preserve q0 as a sparse target wire; preserve chronological matrix order and the upper-right RY minus sign; retain exact global/relative phase; expand the normalization predicate; inspect supplier use rather than added root premises; keep operator equality distinct from state action; retain repeated-control admissibility and target existence; distinguish actual list cost from semantic simplification; keep all lexicographic disjuncts. General arbitrary complex loading, phase-loading, paper-wide Möttönen/Li--Luo algorithms and their general resource claims are not provided by these fixed positive-real examples.

## 6. Topology and scope disposition

`natural-topology.json` gives stable source-local nodes, complete AND tails, explicit witness ORs, diagnostics and section coverage. No implementation dependency graph is inferred. Source references to private coordinate/entry/scalar helpers are represented by their mathematical coordinate tables and linearity steps, not treated as kernel evidence. Bell/dense alternative matrix completions are distinct representations, not omitted identities. Supplier facts are positively retained, while implementation authentication is deferred.

The source's opening/closing provenance, comments, inventory claims and list of future gates are retained as scope metadata, not mathematical certificates. Any external-paper Anchor has SOURCE_GAP nodes for unprovided statement/authentication, full algorithm/phase topology and general complexity. The local finite construction has the mathematical mechanisms displayed above; its formal realization, exact-current-input compilation, independent formal decoding, distinct semantic review, publication/integration and Exposition Seal remain outside this stage. No final fidelity verdict is issued. STOP after sealing; later formal release requires separate authorization.
