# Formal declaration ledger

Original decoder identity: `/root/stored_givens_formal_decoder_c38`.

This is an exhaustive lexical inventory of explicit declarations in the four permitted files, not a kernel declaration census. Every theorem block below is its exact source signature (proof omitted); every definition, abbreviation, structure, inductive and instance block retains its literal source body. Namespace qualification is recorded separately. Implicit auto-bound type parameters are discussed in reconstruction.md; this extractor does not elaborate them. Blank comment-mask lines are not mathematical declarations.

Explicit declaration-command total: 77.

## QuantumBlockEncoding.StoredGivens.Op

Module0.lean:24; inductive.

```lean
inductive Op where
  | field | sqrt | angle | trig | compare | read | write | emit
  deriving DecidableEq, Fintype
```

## QuantumBlockEncoding.StoredGivens.Cost

Module0.lean:28; abbrev.

```lean
abbrev Cost := Op → ℕ
```

## QuantumBlockEncoding.StoredGivens.tick

Module0.lean:30; def.

```lean
def tick (op : Op) : Cost := fun q => if q = op then 1 else 0
```

## QuantumBlockEncoding.StoredGivens.Run

Module0.lean:32; structure.

```lean
structure Run (α : Type) where
  value : α
  cost : Cost
```

## QuantumBlockEncoding.StoredGivens.Run.pure

Module0.lean:36; def.

```lean
def Run.pure (x : α) : Run α := ⟨x, 0⟩
```

## QuantumBlockEncoding.StoredGivens.Run.bind

Module0.lean:38; def.

```lean
def Run.bind (x : Run α) (f : α → Run β) : Run β :=
  let y := f x.value
  ⟨y.value, x.cost + y.cost⟩
```

## QuantumBlockEncoding.StoredGivens.<anonymous Monad Run>

Module0.lean:42; instance.

```lean
instance : Monad Run where
  pure := Run.pure
  bind := Run.bind
```

## QuantumBlockEncoding.StoredGivens.charge

Module0.lean:46; def.

```lean
def charge (op : Op) (x : α) : Run α := ⟨x, tick op⟩
```

## QuantumBlockEncoding.StoredGivens.add

Module0.lean:48; def.

```lean
noncomputable def add (x y : ℝ) : Run ℝ := charge .field (x + y)
```

## QuantumBlockEncoding.StoredGivens.sub

Module0.lean:49; def.

```lean
noncomputable def sub (x y : ℝ) : Run ℝ := charge .field (x - y)
```

## QuantumBlockEncoding.StoredGivens.mul

Module0.lean:50; def.

```lean
noncomputable def mul (x y : ℝ) : Run ℝ := charge .field (x * y)
```

## QuantumBlockEncoding.StoredGivens.div

Module0.lean:51; def.

```lean
noncomputable def div (x y : ℝ) : Run ℝ := charge .field (x / y)
```

## QuantumBlockEncoding.StoredGivens.sqrt

Module0.lean:52; def.

```lean
noncomputable def sqrt (x : ℝ) : Run ℝ := charge .sqrt (Real.sqrt x)
```

## QuantumBlockEncoding.StoredGivens.arccos

Module0.lean:53; def.

```lean
noncomputable def arccos (x : ℝ) : Run ℝ := charge .angle (Real.arccos x)
```

## QuantumBlockEncoding.StoredGivens.cos

Module0.lean:54; def.

```lean
noncomputable def cos (x : ℝ) : Run ℝ := charge .trig (Real.cos x)
```

## QuantumBlockEncoding.StoredGivens.sin

Module0.lean:55; def.

```lean
noncomputable def sin (x : ℝ) : Run ℝ := charge .trig (Real.sin x)
```

## QuantumBlockEncoding.StoredGivens.zeroTest

Module0.lean:56; def.

```lean
noncomputable def zeroTest (x : ℝ) : Run Bool := charge .compare (decide (x = 0))
```

## QuantumBlockEncoding.StoredGivens.signTest

Module0.lean:57; def.

```lean
noncomputable def signTest (x : ℝ) : Run Bool := charge .compare (decide (x < 0))
```

## QuantumBlockEncoding.StoredGivens.read

Module0.lean:59; def.

```lean
def read {n : ℕ} (xs : Vector α n) (i : Fin n) : Run α := charge .read xs[i.val]
```

## QuantumBlockEncoding.StoredGivens.collect

Module0.lean:63; def.

```lean
def collect {n : ℕ} (f : Fin n → Run α) : Run (Vector α n) :=
  let entries : Vector (Run α) n := Vector.ofFn f
  ⟨entries.map Run.value,
    (fun op => ∑ i : Fin n, entries[i.val].cost op) +
      n • (2 • tick .read + 2 • tick .write)⟩
```

## QuantumBlockEncoding.StoredGivens.replace

Module0.lean:70; def.

```lean
def replace {n : ℕ} (xs : Vector α n) (i : Fin n) (x : α) : Run (Vector α n) :=
  ⟨xs.set i.val x, n • (tick .read + tick .write)⟩
```

## QuantumBlockEncoding.StoredGivens.StoredMatrix

Module0.lean:73; abbrev.

```lean
abbrev StoredMatrix (N M : ℕ) := Vector (Vector ℝ M) N
```

## QuantumBlockEncoding.StoredGivens.denote

Module0.lean:75; def.

```lean
def denote {N M : ℕ} (A : StoredMatrix N M) : _root_.Matrix (Fin N) (Fin M) ℝ :=
  fun i j => A[i.val][j.val]
```

## QuantumBlockEncoding.StoredGivens.materialize

Module0.lean:80; def.

```lean
def materialize {N M : ℕ} (f : Fin N → Fin M → Run ℝ) : Run (StoredMatrix N M) :=
  collect (fun i => collect (f i))
```

## QuantumBlockEncoding.StoredGivens.collect_value

Module0.lean:83; theorem.

```lean
@[simp] theorem collect_value {n : ℕ} (f : Fin n → Run α) (i : Fin n) :
    (collect f).value[i.val] = (f i).value
```

## QuantumBlockEncoding.StoredGivens.collect_cost

Module0.lean:86; theorem.

```lean
@[simp] theorem collect_cost {n : ℕ} (f : Fin n → Run α) (op : Op) :
    (collect f).cost op = (∑ i : Fin n, (f i).cost op) +
      n * (2 * tick .read op + 2 * tick .write op)
```

## QuantumBlockEncoding.StoredGivens.angle

Module0.lean:91; def.

```lean
noncomputable def angle (x y : ℝ) : Run ℝ := do
  let xx ← mul x x
  let yy ← mul y y
  let ss ← add xx yy
  let r ← sqrt ss
  let zero ← zeroTest r
  if zero then pure 0 else do
    let ratio ← div x r
    let a ← arccos ratio
    let negative ← signTest y
    let signed ← if negative then sub 0 a else pure a
    let doubled ← mul 2 signed
    sub 0 doubled
```

## QuantumBlockEncoding.StoredGivens.angle_value

Module0.lean:105; theorem.

```lean
theorem angle_value (x y : ℝ) : (angle x y).value = eliminationAngle x y
```

## QuantumBlockEncoding.StoredGivens.coefficients

Module0.lean:113; def.

```lean
noncomputable def coefficients (x y : ℝ) : Run (ℝ × ℝ × ℝ) := do
  let theta ← angle x y
  let half ← div theta 2
  let c ← cos half
  let s ← sin half
  pure (theta, c, s)
```

## QuantumBlockEncoding.StoredGivens.coefficients_value

Module0.lean:120; theorem.

```lean
theorem coefficients_value (x y : ℝ) : (coefficients x y).value =
    (eliminationAngle x y, Real.cos (eliminationAngle x y / 2),
      Real.sin (eliminationAngle x y / 2))
```

## QuantumBlockEncoding.StoredGivens.entryPair

Module0.lean:126; def.

```lean
noncomputable def entryPair (c s : ℝ) (u v : ℝ) : Run (ℝ × ℝ) := do
  let cu ← mul c u
  let sv ← mul s v
  let su ← mul s u
  let cv ← mul c v
  let first ← sub cu sv
  let second ← add su cv
  pure (first, second)
```

## QuantumBlockEncoding.StoredGivens.entryPair_value

Module0.lean:135; theorem.

```lean
@[simp] theorem entryPair_value (c s u v : ℝ) :
    (entryPair c s u v).value = (c * u - s * v, s * u + c * v)
```

## QuantumBlockEncoding.StoredGivens.entryPair_cost

Module0.lean:138; theorem.

```lean
theorem entryPair_cost (c s u v : ℝ) (op : Op) :
    (entryPair c s u v).cost op = 6 * tick .field op
```

## QuantumBlockEncoding.StoredGivens.rowPair

Module0.lean:144; def.

```lean
noncomputable def rowPair {M : ℕ} (u v : Vector ℝ M) (c s : ℝ) :
    Run (Vector ℝ M × Vector ℝ M) := do
  let pairs ← collect fun j => do
    let x ← read u j
    let y ← read v j
    entryPair c s x y
  let first ← collect fun j => do
    let pair ← read pairs j
    pure pair.1
  let second ← collect fun j => do
    let pair ← read pairs j
    pure pair.2
  pure (first, second)
```

## QuantumBlockEncoding.StoredGivens.rowPair_value

Module0.lean:158; theorem.

```lean
theorem rowPair_value {M : ℕ} (u v : Vector ℝ M) (c s : ℝ) (j : Fin M) :
    (rowPair u v c s).value.1[j.val] = c * u[j.val] - s * v[j.val] ∧
    (rowPair u v c s).value.2[j.val] = s * u[j.val] + c * v[j.val]
```

## QuantumBlockEncoding.StoredGivens.rotate

Module0.lean:164; def.

```lean
noncomputable def rotate {N M : ℕ} (A : StoredMatrix N M) (i j : Fin N)
    (c s : ℝ) : Run (StoredMatrix N M) := do
  let u ← read A i
  let v ← read A j
  let rows ← rowPair u v c s
  let B ← replace A j rows.2
  replace B i rows.1
```

## QuantumBlockEncoding.StoredGivens.rotate_value

Module0.lean:172; theorem.

```lean
theorem rotate_value {N M : ℕ} (A : StoredMatrix N M) (i j : Fin N)
    (theta : ℝ) :
    denote (rotate A i j (Real.cos (theta / 2)) (Real.sin (theta / 2))).value =
      rotateRows (denote A) i j theta
```

## QuantumBlockEncoding.StoredGivens.Elimination

Module0.lean:191; structure.

```lean
structure Elimination (N M : ℕ) where
  matrix : StoredMatrix N M
  angle : ℝ
```

## QuantumBlockEncoding.StoredGivens.eliminate

Module0.lean:195; def.

```lean
noncomputable def eliminate {N M : ℕ} (A : StoredMatrix N M)
    (i j : Fin N) (col : Fin M) : Run (Elimination N M) := do
  let u ← read A i
  let v ← read A j
  let x ← read u col
  let y ← read v col
  let cs ← coefficients x y
  let B ← rotate A i j cs.2.1 cs.2.2
  pure ⟨B, cs.1⟩
```

## QuantumBlockEncoding.StoredGivens.eliminate_angle

Module0.lean:205; theorem.

```lean
theorem eliminate_angle {N M : ℕ} (A : StoredMatrix N M)
    (i j : Fin N) (col : Fin M) :
    (eliminate A i j col).value.angle = eliminationAngle (denote A i col) (denote A j col)
```

## QuantumBlockEncoding.StoredGivens.eliminate_matrix

Module0.lean:210; theorem.

```lean
theorem eliminate_matrix {N M : ℕ} (A : StoredMatrix N M)
    (i j : Fin N) (col : Fin M) :
    denote (eliminate A i j col).value.matrix = eliminateEntry (denote A) i j col
```

## QuantumBlockEncoding.StoredGivens.Sweep

Module0.lean:216; structure.

```lean
structure Sweep (N M : ℕ) where
  matrix : StoredMatrix N M
  steps : List (Step N)
```

## QuantumBlockEncoding.StoredGivens.columnSweep

Module0.lean:222; def.

```lean
noncomputable def columnSweep {N M : ℕ} (A : StoredMatrix N M)
    (col : Fin M) (lo : ℕ) : (count : ℕ) → lo + count < N → Run (Sweep N M)
  | 0, _ => pure ⟨A, []⟩
  | count + 1, bound => do
      let first : Fin N := ⟨lo + count, by omega⟩
      let second : Fin N := ⟨lo + count + 1, by omega⟩
      let next ← eliminate A first second col
      let tail ← columnSweep next.matrix col lo count (by omega)
      let steps ← charge .emit
        ({ first := first, second := second, adjacent := rfl, angle := next.angle } :: tail.steps)
      pure ⟨tail.matrix, steps⟩
```

## QuantumBlockEncoding.StoredGivens.columnSweep_matrix

Module0.lean:234; theorem.

```lean
theorem columnSweep_matrix {N M : ℕ} (A : StoredMatrix N M)
    (col : Fin M) (lo count : ℕ) (bound : lo + count < N) :
    denote (columnSweep A col lo count bound).value.matrix =
      AdjacentGivens.columnSweep (denote A) col lo count bound
```

## QuantumBlockEncoding.StoredGivens.columnSweep_steps

Module0.lean:245; theorem.

```lean
theorem columnSweep_steps {N M : ℕ} (A : StoredMatrix N M)
    (col : Fin M) (lo count : ℕ) (bound : lo + count < N) :
    (columnSweep A col lo count bound).value.steps =
      columnSweepSteps (denote A) col lo count bound
```

## QuantumBlockEncoding.StoredGivens.angleBudget

Module0.lean:257; def.

```lean
def angleBudget : Cost :=
  7 • tick .field + tick .sqrt + tick .angle + 2 • tick .compare
```

## QuantumBlockEncoding.StoredGivens.angle_cost_le

Module0.lean:260; theorem.

```lean
theorem angle_cost_le (x y : ℝ) (op : Op) : (angle x y).cost op ≤ angleBudget op
```

## QuantumBlockEncoding.StoredGivens.coefficientBudget

Module0.lean:266; def.

```lean
def coefficientBudget : Cost := angleBudget + tick .field + 2 • tick .trig
```

## QuantumBlockEncoding.StoredGivens.coefficients_cost_le

Module0.lean:268; theorem.

```lean
theorem coefficients_cost_le (x y : ℝ) (op : Op) :
    (coefficients x y).cost op ≤ coefficientBudget op
```

## QuantumBlockEncoding.StoredGivens.rowPair_cost

Module0.lean:275; theorem.

```lean
theorem rowPair_cost {M : ℕ} (u v : Vector ℝ M) (c s : ℝ) (op : Op) :
    (rowPair u v c s).cost op =
      M * (6 * tick .field op + 10 * tick .read op + 6 * tick .write op)
```

## QuantumBlockEncoding.StoredGivens.rotate_cost

Module0.lean:282; theorem.

```lean
theorem rotate_cost {N M : ℕ} (A : StoredMatrix N M) (i j : Fin N)
    (c s : ℝ) (op : Op) :
    (rotate A i j c s).cost op =
      M * (6 * tick .field op + 10 * tick .read op + 6 * tick .write op) +
      2 * N * (tick .read op + tick .write op) + 2 * tick .read op
```

## QuantumBlockEncoding.StoredGivens.eliminationBudget

Module0.lean:290; def.

```lean
def eliminationBudget (N M : ℕ) : Cost := fun op =>
  coefficientBudget op +
    M * (6 * tick .field op + 10 * tick .read op + 6 * tick .write op) +
    2 * N * (tick .read op + tick .write op) + 6 * tick .read op
```

## QuantumBlockEncoding.StoredGivens.eliminate_cost_le

Module0.lean:295; theorem.

```lean
theorem eliminate_cost_le {N M : ℕ} (A : StoredMatrix N M)
    (i j : Fin N) (col : Fin M) (op : Op) :
    (eliminate A i j col).cost op ≤ eliminationBudget N M op
```

## QuantumBlockEncoding.StoredGivens.stepBudget

Module0.lean:303; def.

```lean
def stepBudget (N M : ℕ) : Cost := eliminationBudget N M + tick .emit
```

## QuantumBlockEncoding.StoredGivens.columnSweep_cost_succ

Module0.lean:305; theorem.

```lean
theorem columnSweep_cost_succ {N M : ℕ} (A : StoredMatrix N M)
    (col : Fin M) (lo count : ℕ) (bound : lo + (count + 1) < N) (op : Op) :
    (columnSweep A col lo (count + 1) bound).cost op =
      (eliminate A ⟨lo + count, by omega⟩ ⟨lo + count + 1, by omega⟩ col).cost op +
      (columnSweep
        (eliminate A ⟨lo + count, by omega⟩ ⟨lo + count + 1, by omega⟩ col).value.matrix
        col lo count (by omega)).cost op + tick .emit op
```

## QuantumBlockEncoding.StoredGivens.columnSweep_cost_le

Module0.lean:316; theorem.

```lean
theorem columnSweep_cost_le {N M : ℕ} (A : StoredMatrix N M)
    (col : Fin M) (lo count : ℕ) (bound : lo + count < N) (op : Op) :
    (columnSweep A col lo count bound).cost op ≤ count * stepBudget N M op
```

## QuantumBlockEncoding.StoredGivens.stepBudget_fields

Module0.lean:331; theorem.

```lean
theorem stepBudget_fields (N M : ℕ) :
    stepBudget N M .field = 6 * M + 8 ∧
    stepBudget N M .sqrt = 1 ∧
    stepBudget N M .angle = 1 ∧
    stepBudget N M .trig = 2 ∧
    stepBudget N M .compare = 2 ∧
    stepBudget N M .read = 10 * M + 2 * N + 6 ∧
    stepBudget N M .write = 6 * M + 2 * N ∧
    stepBudget N M .emit = 1
```

## QuantumBlockEncoding.StoredGivens.columnSweep_emit

Module0.lean:346; theorem.

```lean
theorem columnSweep_emit {N M : ℕ} (A : StoredMatrix N M)
    (col : Fin M) (lo count : ℕ) (bound : lo + count < N) :
    (columnSweep A col lo count bound).cost .emit = count
```

## QuantumBlockEncoding.StoredGivens.columnSweep_steps_length

Module0.lean:358; theorem.

```lean
theorem columnSweep_steps_length {N M : ℕ} (A : StoredMatrix N M)
    (col : Fin M) (lo count : ℕ) (bound : lo + count < N) :
    (columnSweep A col lo count bound).value.steps.length = count
```

## QuantumBlockEncoding.StoredGivens.columnSweep_action

Module0.lean:364; theorem.

```lean
theorem columnSweep_action {N M : ℕ} (A : StoredMatrix N M)
    (col : Fin M) (lo count : ℕ) (bound : lo + count < N) :
    applySteps (columnSweep A col lo count bound).value.steps (denote A) =
      denote (columnSweep A col lo count bound).value.matrix
```

## QuantumBlockEncoding.StoredGivens.materialize_cost

Module0.lean:372; theorem.

```lean
theorem materialize_cost {N M : ℕ} (f : Fin N → Fin M → Run ℝ) (op : Op) :
    (materialize f).cost op =
      (∑ i : Fin N, ∑ j : Fin M, (f i j).cost op) +
      (N * M + N) * (2 * tick .read op + 2 * tick .write op)
```

## QuantumBlockEncoding.AdjacentGivens.rotateRows

Module1.lean:19; def.

```lean
noncomputable def rotateRows {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (i j : Fin N) (theta : ℝ) : _root_.Matrix (Fin N) (Fin M) ℝ :=
  fun row col =>
    if row = i then Real.cos (theta / 2) * A i col - Real.sin (theta / 2) * A j col
    else if row = j then Real.sin (theta / 2) * A i col + Real.cos (theta / 2) * A j col
    else A row col
```

## QuantumBlockEncoding.AdjacentGivens.planeMatrix

Module1.lean:26; def.

```lean
noncomputable def planeMatrix {N : ℕ} (i j : Fin N) (theta : ℝ) :
    _root_.Matrix (Fin N) (Fin N) ℝ := rotateRows 1 i j theta
```

## QuantumBlockEncoding.AdjacentGivens.planeMatrix_mul

Module1.lean:29; theorem.

```lean
theorem planeMatrix_mul {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (i j : Fin N) (theta : ℝ) : planeMatrix i j theta * A = rotateRows A i j theta
```

## QuantumBlockEncoding.AdjacentGivens.eliminationAngle

Module1.lean:41; def.

```lean
noncomputable def eliminationAngle (x y : ℝ) : ℝ := -(splitAngle x y).eval
```

## QuantumBlockEncoding.AdjacentGivens.eliminateEntry

Module1.lean:43; def.

```lean
noncomputable def eliminateEntry {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (i j : Fin N) (col : Fin M) : _root_.Matrix (Fin N) (Fin M) ℝ :=
  rotateRows A i j (eliminationAngle (A i col) (A j col))
```

## QuantumBlockEncoding.AdjacentGivens.Step

Module1.lean:47; structure.

```lean
structure Step (N : ℕ) where
  first : Fin N
  second : Fin N
  adjacent : first.val + 1 = second.val
  angle : ℝ
```

## QuantumBlockEncoding.AdjacentGivens.Step.matrix

Module1.lean:53; def.

```lean
noncomputable def Step.matrix {N : ℕ} (step : Step N) :
    _root_.Matrix (Fin N) (Fin N) ℝ := planeMatrix step.first step.second step.angle
```

## QuantumBlockEncoding.AdjacentGivens.applySteps

Module1.lean:56; def.

```lean
noncomputable def applySteps {N M : ℕ} : List (Step N) →
    _root_.Matrix (Fin N) (Fin M) ℝ → _root_.Matrix (Fin N) (Fin M) ℝ
  | [], A => A
  | step :: rest, A => applySteps rest (step.matrix * A)
```

## QuantumBlockEncoding.AdjacentGivens.columnSweep

Module1.lean:61; def.

```lean
noncomputable def columnSweep {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (col : Fin M) (lo : ℕ) : (count : ℕ) → lo + count < N →
    _root_.Matrix (Fin N) (Fin M) ℝ
  | 0, _ => A
  | count + 1, bound =>
      columnSweep (eliminateEntry A ⟨lo + count, by omega⟩
        ⟨lo + count + 1, by omega⟩ col) col lo count (by omega)
```

## QuantumBlockEncoding.AdjacentGivens.columnSweepSteps

Module1.lean:69; def.

```lean
noncomputable def columnSweepSteps {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (col : Fin M) (lo : ℕ) : (count : ℕ) → lo + count < N → List (Step N)
  | 0, _ => []
  | count + 1, bound =>
      let first : Fin N := ⟨lo + count, by omega⟩
      let second : Fin N := ⟨lo + count + 1, by omega⟩
      { first := first, second := second, adjacent := rfl,
        angle := eliminationAngle (A first col) (A second col) } ::
        columnSweepSteps (eliminateEntry A first second col) col lo count (by omega)
```

## QuantumBlockEncoding.AdjacentGivens.columnSweepSteps_length

Module1.lean:79; theorem.

```lean
theorem columnSweepSteps_length {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (col : Fin M) (lo count : ℕ) (bound : lo + count < N) :
    (columnSweepSteps A col lo count bound).length = count
```

## QuantumBlockEncoding.AdjacentGivens.columnSweepSteps_action

Module1.lean:86; theorem.

```lean
theorem columnSweepSteps_action {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (col : Fin M) (lo count : ℕ) (bound : lo + count < N) :
    applySteps (columnSweepSteps A col lo count bound) A = columnSweep A col lo count bound
```

## QuantumBlockEncoding.RealAmplitudePreparation.pairNorm

Module2.lean:18; def.

```lean
noncomputable def pairNorm (a b : ℝ) : ℝ := Real.sqrt (a ^ 2 + b ^ 2)
```

## QuantumBlockEncoding.RealAmplitudePreparation.splitAngle

Module2.lean:20; def.

```lean
noncomputable def splitAngle (a b : ℝ) : ExactAngle :=
  if pairNorm a b = 0 then .rational 0 else
    .real (2 * if b < 0 then -Real.arccos (a / pairNorm a b)
      else Real.arccos (a / pairNorm a b))
```

## QuantumBlockEncoding.ExactAngle

Module3.lean:16; inductive.

```lean
inductive ExactAngle where
  | rational (value : Rat)
  | piRational (value : Rat)
  | twiceArccosRational (value : Rat)
      (bounded : |(value : Real)| ≤ 1)
  | twiceArccosSqrtRational (value : Rat)
      (bounded : 0 ≤ (value : Real) ∧ (value : Real) ≤ 1)
                                                                            
                                                                          
                                                                    
  | real (value : Real)
  | add (left right : ExactAngle)
  | neg (value : ExactAngle)
  | scale (factor : Rat) (value : ExactAngle)
```

## QuantumBlockEncoding.ExactAngle.eval

Module3.lean:33; def.

```lean
noncomputable def eval : ExactAngle → Real
  | .rational value => (value : Real)
  | .piRational value => Real.pi * (value : Real)
  | .twiceArccosRational value _ => 2 * Real.arccos (value : Real)
  | .twiceArccosSqrtRational value _ =>
      2 * Real.arccos (Real.sqrt (value : Real))
  | .real value => value
  | .add left right => left.eval + right.eval
  | .neg value => -value.eval
  | .scale factor value => (factor : Real) * value.eval
```
