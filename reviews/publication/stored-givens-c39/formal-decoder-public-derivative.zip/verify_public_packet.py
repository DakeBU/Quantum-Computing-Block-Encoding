"""Public packet lexical/privacy and SHA256 checks only; no formal execution."""
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ALLOWED = (
    "reconstruction.md", "declaration-ledger.md", "read-scope.md",
    "public-allowlist.json", "verify_public_packet.py",
    "public-manifest.json", "derivative-seal.json",
)
PAYLOAD = ALLOWED[:5]


def digest(name):
    return hashlib.sha256((HERE / name).read_bytes()).hexdigest()


def main():
    manifest = json.loads((HERE / "public-manifest.json").read_text(encoding="utf-8"))
    seal = json.loads((HERE / "derivative-seal.json").read_text(encoding="utf-8"))
    assert manifest["public_file_allowlist"] == list(ALLOWED)
    assert set(manifest["payload_sha256"]) == set(PAYLOAD)
    for name in PAYLOAD:
        assert digest(name) == manifest["payload_sha256"][name], name
    assert digest("public-manifest.json") == seal["public_manifest_sha256"]
    assert seal["payload_sha256"] == manifest["payload_sha256"]
    inventory = json.loads((HERE / "public-allowlist.json").read_text(encoding="utf-8"))
    assert len(inventory["target_named_declarations"]) == 60
    assert len(inventory["target_anonymous_instances"]) == 1
    assert len(inventory["provider_named_declarations"]) == 16
    assert inventory["public_packet_artifacts"] == list(ALLOWED)
    ledger = (HERE / "declaration-ledger.md").read_text(encoding="utf-8")
    assert len(re.findall(r"^## QuantumBlockEncoding\.", ledger, re.M)) == 77
    assert digest("reconstruction.md") == seal["original_private_artifact_sha256"]["reconstruction.md"]
    assert digest("declaration-ledger.md") == seal["original_private_artifact_sha256"]["declaration-ledger.md"]
    # Build generic detectors from components; no actual user prefix is embedded.
    sep = chr(92)
    patterns = [
        r"[A-Za-z]:[" + sep * 2 + r"/]",
        "/" + r"(?:home|Users|mnt|tmp)/",
        "file" + "://",
        re.escape(sep * 2) + r"[A-Za-z0-9_.-]+" + re.escape(sep),
    ]
    for name in ALLOWED:
        content = (HERE / name).read_text(encoding="utf-8")
        for pattern in patterns:
            assert not re.search(pattern, content), "absolute local path candidate in " + name
    print(json.dumps({
        "result": "PASS", "layer": "lexical/privacy/hash only",
        "declaration_counts": {"target_named": 60, "target_anonymous": 1, "providers": 16},
        "release_sha256": {name: digest(name) for name in ALLOWED},
    }, indent=2))


if __name__ == "__main__":
    main()
