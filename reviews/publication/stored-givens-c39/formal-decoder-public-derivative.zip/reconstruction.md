# Independent formal reconstruction

Decoder identity: `/root/stored_givens_formal_decoder_c38`.

## Scope and evidence level

This reconstruction was derived from only Module0.lean (the whole comment-masked target) and Module1.lean through Module3.lean (focused formal providers). Process documents were read as process instructions, not mathematical evidence. No natural statement, author classification, source comparison, previous verdict, production module, registry, or prior review was inspected. This document is not a natural-source agreement verdict or publication acceptance.

The declaration-ledger.md file records all 77 explicit declaration commands, with exact source signatures and literal non-theorem bodies: 61 target commands and 16 provider commands. It includes every explicit definition, abbreviation, inductive, structure, theorem and the anonymous instance. It is a lexical inventory, not an elaborated or kernel census, not a complete transitive trusted-code-body claim, and not a compilation result. No Lean, native evaluation, project build, network call, or Git operation was run. Parent-reported compile context, if used administratively, remains external to this reconstruction; I did not verify it.

## Carriers, binders and generated interfaces

The target namespace is `QuantumBlockEncoding.StoredGivens`; its opened provider namespaces are `AdjacentGivens` and `RealAmplitudePreparation`. Provider namespaces and fully qualified names are in the ledger. Dimensions n, N and M are natural numbers, with no global positivity assumptions. `Fin n` supplies an in-range index. A matrix here has N rows and M columns over the real numbers; a stored matrix is literally `Vector (Vector ℝ M) N`, and its denotation is the function `(i,j) ↦ A[i.val][j.val]`. No rank, normalization, isometry, orthogonality, sparsity or nonzero-entry premise is present.

The generic `Run` record has `(α : Type)`, a value of α and a cost. Free α and β in the source are Lean auto-implicit type parameters constrained by uses of `Run` to the ordinary `Type` carrier; they are not real-valued restrictions or mathematical hypotheses. The exact compiler-generated universe/binder telescope has not been queried. Vector operations are generic in α wherever the ledger uses α. `collect`, `collect_value`, `collect_cost`, and `materialize_cost` permit arbitrary cost-bearing functions, not merely zero-cost callbacks. `Run.bind` permits any function `α → Run β`; costs of its second argument depend on the first value.

The dimension binders in value and cost lemmas are implicit `{N M : ℕ}` or `{M : ℕ}` exactly as printed. `angleBudget`, `coefficientBudget`, and budget-value equalities do not require a matrix or valid pivot. Every sweep definition/theorem needs an actual `col : Fin M`, `lo count : ℕ`, and a proof `lo + count < N` (successor-cost equality uses `lo + (count+1) < N`). Thus a sweep instance requires M>0 and N>0 through typing/bound data, but N and M need not satisfy N≥M or a square-shape condition. The count-zero case still requires lo<N. No entries have a sign, norm or invertibility assumption. `rotate`, `eliminate` and provider `rotateRows` permit i=j; distinctness is not an unstated binder.

The explicit datatype and record interfaces are:

- `Op` has eight nullary constructors: field, sqrt, angle, trig, compare, read, write, emit. `deriving DecidableEq, Fintype` requests the corresponding instances. The one scoped option precedes this inductive: `backward.isDefEq.respectTransparency false`.
- `Run α` has constructor data `(value : α, cost : Cost)` and projections value/cost.
- `Elimination N M` has `(matrix : StoredMatrix N M, angle : ℝ)`.
- `Sweep N M` has `(matrix : StoredMatrix N M, steps : List (AdjacentGivens.Step N))`.
- `AdjacentGivens.Step N` has first and second in `Fin N`, a proof `first.val + 1 = second.val`, and a real angle. The adjacency proof entails distinct rows; the record does not include a column, matrix, pivot value, gate implementation or resource bound.
- `ExactAngle` is a syntax datatype, not a quotient of equal angles. Its eight constructors are rational(q:Rat), piRational(q:Rat), twiceArccosRational(q:Rat, |(q:Real)|≤1), twiceArccosSqrtRational(q:Rat, 0≤(q:Real) ∧ (q:Real)≤1), real(x:Real), add(left,right:ExactAngle), neg(value:ExactAngle), and scale(factor:Rat,value:ExactAngle).

The ledger preserves the literal constructors and all structure fields. Ordinary Lean elaboration also supplies inductive/record constructors, projections, recursors and auxiliary interfaces, as well as derived DecidableEq/Fintype machinery. The anonymous `Monad Run` explicitly supplies pure and bind; inherited/default Functor/Applicative/Monad interface components come from the ambient class mechanism. Their exact emitted names, synthesized defaults, proof terms and all recursor/instance declarations were not enumerated. No `LawfulMonad Run` theorem is stated in these files. These limits do not omit a mathematical premise: they limit the inventory's claim to explicit source commands plus the described constructor/field interface, rather than all emitted declarations. No claim about every transitive instance or ambient implementation body is made.

## Literal value and cost model

`Cost` is the function space `Op → ℕ`. Zero, addition, inequalities and natural multiples in the formulas are pointwise. `tick op q` is 1 when q=op and 0 otherwise. A `Run` has a deterministic mathematical value and an eight-component nonnegative count, not state, failure, effects, elapsed time, probabilistic execution or numerical rounding. `Run.pure x=(x,0)`. `Run.bind x f` evaluates `y=f x.value` and returns `(y.value,x.cost+y.cost)`. The anonymous monad instance uses those two operations. `charge op x=(x,tick op)`; it does not independently implement the operation or validate its assigned price.

The wrappers add/sub/mul/div each charge one field token for the corresponding real operation; sqrt charges one sqrt token for `Real.sqrt`; arccos one angle token for `Real.arccos`; sin and cos each one trig token. `zeroTest` returns the Boolean decision of x=0 and `signTest` that of x<0, each charging compare once. These are exact-real, noncomputable definitions. Division and the real functions are the ambient total Lean operations; there is no partial-operation error channel or finite-bit cost. The elimination-angle algorithm guards its actual ratio by testing the computed norm against zero.

`read xs i` returns xs[i.val] for one read token. `collect f` first defines `entries=Vector.ofFn f`, returns `entries.map Run.value`, and assigns cost `Σ_i entries[i.val].cost + n • (2 • tick read + 2 • tick write)`. This is a literal cost annotation on a pure mathematical construction. It is not a proved runtime of Vector.ofFn or map, and the cost sum is not claimed to cost additional field operations. `replace xs i x` returns `xs.set i.val x` and charges n reads plus n writes regardless of i, data, or whether x equals the old value. It does not charge one constant-time in-place update. `denote` is an uncharged semantic projection, not a measured input-access routine. `materialize f` is nested collection, outer over rows and inner over columns; arbitrary callback costs are retained.

All non-theorem definitions in the ledger are literal definitions. They use no uniquely-characterized-object choice or representative quotient. In particular, the zero-pair angle branch defines an explicit value 0 on its whole domain; it is not an unspecified witness. The exact-angle syntax admits arbitrary real leaves, so it is not an assertion of rational-only encodability or finite representation size.

## Angle, row update and elimination values

The providers define `pairNorm(a,b)=sqrt(a²+b²)` and splitAngle(a,b) as a rational-zero constructor if that norm is zero; otherwise it is a real leaf `2 * (-arccos(a/r))` when b<0 and `2 * arccos(a/r)` when b≥0, with r=pairNorm(a,b). `ExactAngle.eval` interprets rational by coercion, piRational as πq, the two bounded inverse-cosine constructors as 2 arccos q and 2 arccos sqrt q, real as its leaf, add as addition, neg as negation and scale as multiplication by the coerced rational. These are all eight evaluation clauses. No equality or canonicality modulo 2π or global phase is imposed.

`AdjacentGivens.eliminationAngle(x,y)` is the negative of the evaluated splitAngle. The target `angle` explicitly computes xx=x*x, yy=y*y, ss=xx+yy, r=sqrt(ss), tests r=0 and returns zero on that branch. Otherwise it computes ratio=x/r, a=arccos(ratio), tests y<0, chooses signed=-a on the negative branch and a otherwise, doubles signed and returns its negative. The `angle_value` theorem identifies this exact computed value with eliminationAngle for all real x,y. `coefficients` next divides theta by 2 and computes its cosine and sine, returning the right-associated triple `(theta,(c,s))`. `coefficients_value` states the same triple with theta=eliminationAngle(x,y).

`entryPair(c,s,u,v)` computes four multiplications cu,sv,su,cv, then `cu-sv` and `su+cv`. It returns `(c*u-s*v,s*u+c*v)` for arbitrary real c,s,u,v; c and s need not satisfy c²+s²=1. `rowPair` collects all such pairs from two input rows, then separately collects their first and second components. Its value theorem gives those two coordinate formulas for every j:Fin M.

`rotate A i j c s` reads both original rows before modifying anything, computes both new rows, replaces row j with the second, then row i with the first. If i=j, the final first-row replacement wins; there is no two-distinct-row rotation claim in that case. The provider's `rotateRows` uses exactly the same priority: row=i gets the first formula, else row=j gets the second, else remains unchanged. With c=cos(theta/2), s=sin(theta/2), `rotate_value` states equality of stored denotation and that provider matrix for all i,j,theta. The 2×2 distinct-row convention is `[[c,-s],[s,c]]`, acting by left row update and using half the real angle, not the full angle.

`planeMatrix i j theta` is rotateRows applied to the identity matrix; `planeMatrix_mul` identifies left multiplication by it with rotateRows. This identity is stated even for i=j; orthogonality/unitarity for such coincident indices is not asserted. `Step.matrix` uses its first,second,angle in planeMatrix. `applySteps [] A=A`; `applySteps (step::rest) A=applySteps rest (step.matrix*A)`. List order is execution order: the head acts first, so successive matrices accumulate on the left.

`eliminate` reads rows i,j, reads both selected column entries, computes coefficients, rotates the original A with their c,s, and returns the new stored matrix together with theta. `eliminate_angle` identifies the returned theta with eliminationAngle on the original denoted entries. `eliminate_matrix` identifies its matrix with `eliminateEntry`, itself defined as rotateRows by that angle. The provided theorem inventory contains no separate assertion that a designated lower entry is zero or upper entry equals a norm; its exact claim is the semantic agreement just stated. The name alone must not enlarge it.

## Sweep semantics and explicit mathematical theorem claims

For input count k>0, `columnSweep` first eliminates rows `lo+k-1,lo+k`, then recursively sweeps the updated matrix with count k-1. It thus visits adjacent pairs bottom-to-top down to `(lo,lo+1)` and never changes the selected column parameter. Count 0 returns A and an empty step list at zero cost. In each successor case, recursion yields tail.matrix and tail.steps; one emit token is then charged for prefixing the current step to tail.steps. Consequently the resulting list is in the same first-elimination-to-last order, even though the annotated emit charge occurs after the recursive call. Its adjacency field is a proof of consecutive natural indices.

The corresponding pure provider `columnSweep` has the identical matrix recursion. The provider `columnSweepSteps` computes the angle from the current matrix before each recursive update. The provider length and action theorems say this list has count entries and its applySteps action equals the pure sweep. The target proves:

- `columnSweep_matrix`: stored output denotation equals the pure provider sweep;
- `columnSweep_steps`: output list equals the provider's list, including angles and order;
- `columnSweep_steps_length`: the output list has length count;
- `columnSweep_action`: applying the output list to the original denoted matrix equals the denoted stored output.

All these quantify over every stored real matrix of compatible dimensions and every valid col,lo,count,bound. They are exact equalities; there is no approximation tolerance, postselection or probability parameter. They do not state a full-column triangularization theorem, QR/LQ decomposition, an all-column algorithm, a rank test, or a circuit compiler. The only structural input restriction specific to the sweep is the range proof; no linear-algebra promise is a binder.

## Exact resource formulas and upper bounds

In the following notation F,S,A,T,C,R,W,E denote the unit cost functions for field,sqrt,angle,trig,compare,read,write,emit respectively. Every equality or inequality is componentwise at an arbitrary op:Op. These abbreviations are explanatory, not new Lean declarations.

`collect_value` says each output coordinate is `(f i).value`; `collect_cost` says its cost is `Σ_i (f i).cost + n(2R+2W)`.

`entryPair_cost` is exactly 6F. `rowPair_cost` is exactly `M(6F+10R+6W)`. Three collections contribute 6M reads and 6M writes; two input reads and the two projection passes add another 4M reads. `rotate_cost` is exactly `M(6F+10R+6W)+2N(R+W)+2R`: two row reads plus two whole-outer-vector replacements are counted. These exact formulas hold for arbitrary coefficient values and even coincident indices.

The literal budgets are:

`angleBudget = 7F + S + A + 2C`;

`coefficientBudget = angleBudget + F + 2T`;

`eliminationBudget(N,M) = coefficientBudget + M(6F+10R+6W) + 2N(R+W) + 6R`;

`stepBudget(N,M) = eliminationBudget(N,M) + E`.

`angle_cost_le`, `coefficients_cost_le`, `eliminate_cost_le` bound the named run by the respective budget. These are not assertions that every branch spends the full budget. From the literal angle body, the zero-norm branch costs `3F+S+C`; the nonzero/y≥0 branch costs `6F+S+A+2C`; the nonzero/y<0 branch costs `7F+S+A+2C`. Those branch formulas are this decoder's direct reading of charges, not additional named Lean theorems. Coefficients adds exactly F+2T after any angle branch.

`stepBudget_fields` expands all eight coordinates simultaneously:

| field | sqrt | angle | trig | compare | read | write | emit |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 6M+8 | 1 | 1 | 2 | 2 | 10M+2N+6 | 6M+2N | 1 |

`columnSweep_cost_succ` is an exact recurrence: current elimination cost plus the cost of the tail sweep on that elimination's output plus E. `columnSweep_cost_le` gives `cost ≤ count * stepBudget(N,M)` for each component. In particular this explicitly retains O(count*N) outer-vector copy counts in addition to row-width work; it is not a constant-time mutable-row-update model. `columnSweep_emit` strengthens the emit bound to the exact equality `cost emit=count`, matching list length.

`materialize_cost` states `cost(materialize f) = Σ_i Σ_j cost(f i j) + (N*M+N)(2R+2W)` componentwise. Empty dimensions are meaningful for materialize, collect, rowPair and the corresponding formulas wherever their other binders can be inhabited. Input callback costs are not erased or assumed constant. Materialization cost is a separate theorem, not folded automatically into a sweep invocation on an already supplied stored A.

## Dependency and boundary summary

The formal construction spine is: exact-angle interpretation → split-angle/elimination angle → provider row update and sweep; in parallel, costed scalar wrappers → costed pair/row update → stored elimination → stored sweep. The target's value equalities bridge the two spines; the target's componentwise budgets bound its annotated counts. This is a source-code reading of visible definitions and theorem calls, not a complete elaborated theorem-dependency extraction.

The supplied provider definitions suffice to decode the target's mathematical quantities and sign/order conventions. No narrow additional formal release is currently needed. Ambient Mathlib/Lean carriers, real functions, vector primitives and class implementations remain external library interfaces rather than locally inspected implementation bodies; that is not a request for an unbounded all-TCB release.

This packet does not establish efficient finite-bit implementation, numerical stability/error accumulation, a uniform rational approximation scheme, gate synthesis, Clifford+T complexity, connectivity/depth, quantum register or bit order, phase equivalence, ancilla cleanup, success probability, or a saved executable trace. Those objects are not in the theorem interfaces read here. Exact-real noncomputability alone neither proves inefficiency nor supplies an implementation. No natural-source agreement, assumption classification against a source, accepted publication status, whole-repository proof cleanliness, current CI verification or complete transitive trust census is asserted.
