# Public derivative read scope

Decoder identity: `/root/stored_givens_formal_decoder_c38` (an agent identity, not a filesystem path).

This is a posthoc privacy-safe derivative of the original independently authored formal decoder packet. The original six sealed artifacts were not rewritten. The same actual decoder authored this derivative, without new mathematical input or source comparison. This is not an original pre-review seal and not a publication verdict.

The original mathematical read scope, expressed as logical relative identifiers, was:

- `formal/Module0.lean`: whole comment-masked target.
- `formal/Module1.lean`: focused formal provider excerpt.
- `formal/Module2.lean`: focused formal provider excerpt.
- `formal/Module3.lean`: focused formal provider excerpt.

Each was read in full. Their original content hashes are retained in derivative-seal.json, without a private path map.

Process-only documents read in full were `process/AGENTS.md`, `process/HARNESS.md`, `process/skills/qbe-substantive-worker/SKILL.md`, `process/docs/theorem-publication-protocol.md`, `process/docs/proof-digestion-protocol.md`, and `process/docs/evidence-routed-memory-protocol.md`. Truncated combined output was resolved by separate reads and a HARNESS tail reread. These identifiers are logical labels, not claims about public repository placement.

No natural-language source, author metadata, source-review record, desired statement, registry, production source, other review, or parent chat was read. Imported module names in the four formal files were not followed. No Lean, native evaluation, network, Git, production/registry writes or children were used. No new such exposure or action occurred while preparing this derivative.

For this derivative, own original reconstruction.md, declaration-ledger.md, public-allowlist.json and lexical_audit.py were inspected or scanned. Reconstruction and declaration ledger contain no detected absolute local path literals and are preserved byte-for-byte. The original lexical audit source also had no detected absolute path literal, but is intentionally excluded: its generator is tied to the private packet layout. A new public verifier uses only this derivative directory and logical filenames. Original read-scope.md and content-hash-seal.json are excluded because they contain private filesystem paths. The new read scope and seal replace them only in the derivative; the originals remain unchanged.

The public inventory retains all 60 named target declarations, the anonymous Monad Run instance and all 16 provider declarations. All mathematical semantics, binder descriptions, value/cost claims and limitations remain those of the unmodified reconstruction and literal ledger. The inventory remains explicit-source-only, not a kernel census or complete transitive TCB-body claim. Lexical/hash privacy checks do not certify mathematical fidelity or semantic acceptance.

Public release is restricted to the seven exact filenames in public-manifest.json. The manifest hashes five payload files; derivative-seal.json binds that manifest and the payload. Neither file pretends to contain its own hash. The independently returned release hash list supplies hashes for both outer binding files. No later decoder binding wrapper or opaque context binding is asserted here.
