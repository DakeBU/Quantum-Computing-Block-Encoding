import QuantumBlockEncoding.UniformlyControlledRy
import QuantumBlockEncoding.PrimitiveBasisLE
import QuantumBlockEncoding.StatePreparation

   
                                                          

                                                                        
                                                                         
                                                                      
                                                                         
  

namespace QuantumBlockEncoding.RealAmplitudePreparation

open Robin.ComplexLCU
open scoped Kronecker
noncomputable def pairNorm (a b : ℝ) : ℝ := Real.sqrt (a ^ 2 + b ^ 2)

noncomputable def splitAngle (a b : ℝ) : ExactAngle :=
  if pairNorm a b = 0 then .rational 0 else
    .real (2 * if b < 0 then -Real.arccos (a / pairNorm a b)
      else Real.arccos (a / pairNorm a b))

end QuantumBlockEncoding.RealAmplitudePreparation
