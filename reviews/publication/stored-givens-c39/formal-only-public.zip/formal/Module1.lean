import QuantumBlockEncoding.RealAmplitudePreparation
import QuantumBlockEncoding.SelectedRyPlane

   
                                                             

                                                                           
                                                                            
                                                                         
                                                                                
                                                                               
                                                                             
                                                                             
  

namespace QuantumBlockEncoding.AdjacentGivens

open RealAmplitudePreparation
noncomputable def rotateRows {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (i j : Fin N) (theta : ℝ) : _root_.Matrix (Fin N) (Fin M) ℝ :=
  fun row col =>
    if row = i then Real.cos (theta / 2) * A i col - Real.sin (theta / 2) * A j col
    else if row = j then Real.sin (theta / 2) * A i col + Real.cos (theta / 2) * A j col
    else A row col

noncomputable def planeMatrix {N : ℕ} (i j : Fin N) (theta : ℝ) :
    _root_.Matrix (Fin N) (Fin N) ℝ := rotateRows 1 i j theta

theorem planeMatrix_mul {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (i j : Fin N) (theta : ℝ) : planeMatrix i j theta * A = rotateRows A i j theta := by
  ext row col
  simp only [_root_.Matrix.mul_apply, planeMatrix, rotateRows]
  by_cases hi : row = i
  · subst row
    simp [Finset.sum_sub_distrib, sub_mul, _root_.Matrix.one_apply]
  · by_cases hj : row = j
    · subst row
      simp [hi, Finset.sum_add_distrib, add_mul, _root_.Matrix.one_apply]
    · simp [hi, hj, _root_.Matrix.one_apply]

noncomputable def eliminationAngle (x y : ℝ) : ℝ := -(splitAngle x y).eval

noncomputable def eliminateEntry {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (i j : Fin N) (col : Fin M) : _root_.Matrix (Fin N) (Fin M) ℝ :=
  rotateRows A i j (eliminationAngle (A i col) (A j col))

structure Step (N : ℕ) where
  first : Fin N
  second : Fin N
  adjacent : first.val + 1 = second.val
  angle : ℝ

noncomputable def Step.matrix {N : ℕ} (step : Step N) :
    _root_.Matrix (Fin N) (Fin N) ℝ := planeMatrix step.first step.second step.angle

noncomputable def applySteps {N M : ℕ} : List (Step N) →
    _root_.Matrix (Fin N) (Fin M) ℝ → _root_.Matrix (Fin N) (Fin M) ℝ
  | [], A => A
  | step :: rest, A => applySteps rest (step.matrix * A)

noncomputable def columnSweep {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (col : Fin M) (lo : ℕ) : (count : ℕ) → lo + count < N →
    _root_.Matrix (Fin N) (Fin M) ℝ
  | 0, _ => A
  | count + 1, bound =>
      columnSweep (eliminateEntry A ⟨lo + count, by omega⟩
        ⟨lo + count + 1, by omega⟩ col) col lo count (by omega)

noncomputable def columnSweepSteps {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (col : Fin M) (lo : ℕ) : (count : ℕ) → lo + count < N → List (Step N)
  | 0, _ => []
  | count + 1, bound =>
      let first : Fin N := ⟨lo + count, by omega⟩
      let second : Fin N := ⟨lo + count + 1, by omega⟩
      { first := first, second := second, adjacent := rfl,
        angle := eliminationAngle (A first col) (A second col) } ::
        columnSweepSteps (eliminateEntry A first second col) col lo count (by omega)

theorem columnSweepSteps_length {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (col : Fin M) (lo count : ℕ) (bound : lo + count < N) :
    (columnSweepSteps A col lo count bound).length = count := by
  induction count generalizing A with
  | zero => rfl
  | succ count ih => simp only [columnSweepSteps, List.length_cons, ih]

theorem columnSweepSteps_action {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (col : Fin M) (lo count : ℕ) (bound : lo + count < N) :
    applySteps (columnSweepSteps A col lo count bound) A = columnSweep A col lo count bound := by
  induction count generalizing A with
  | zero => rfl
  | succ count ih =>
      simp only [columnSweepSteps, applySteps, Step.matrix, planeMatrix_mul]
      exact ih _ _

end QuantumBlockEncoding.AdjacentGivens
