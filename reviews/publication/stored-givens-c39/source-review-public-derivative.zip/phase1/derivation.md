# Posthoc public derivative — not original preformal bytes

Original private derivation SHA-256: `7c53251c741c51839a48951f956e7a6021535949faa35f121faeaf72a75f2c5d`. Original preformal seal SHA-256: `2397f52ba56738f1fa135dd143b1d7604ef16859e8cca56b72e4e9debd7b7787`. This path-redacted derivative was generated after formal release by the same actual reviewer. Mathematical text is unchanged; original absolute local paths have been replaced by logical packet paths. The original private artifacts remain immutable. Preformal scope statements below refer to that original phase, not this derivative's generation time.

# Independent source-first reconstruction: stored exact-real elimination

## Identity, provenance, and frozen scope

Reviewer: the actual collaborating agent `/root/stored_givens_source_first_c38` in the current Codex session, assigned by `/root`. This is an independent natural-source reconstruction before this reviewer has received any formal statement, decoder, implementation, author seal, or previous verdict. It is not independent historical discovery: the source itself is explicitly `RETROSPECTIVE_IMPLEMENTATION_INFORMED`, and that evidence class is preserved throughout.

Sole mathematical input: `source-packet/source.md`, SHA-256 `1bcf9ba72fca92df7773cd1d8b8195d306b123f0f700307d9e4cb535f84a0143`. Line anchors below refer to the 176-line source, not implementation declarations. The six designated repository process files were read completely for process only. Their hashes and exact read scope are in `seal.json`.

No production, exporter, native/Lean execution, mathematical network input, Git operation, author metadata, other natural review, registry, or child agent was used. Computation performed for this review consists of file reads and cryptographic hashes; the mathematical witnesses below are exact hand derivations, not executed experiments. Only the four requested phase-1 artifacts are written.

Outcome at this layer: the source's explicit mathematical contracts and counter formulas are coherent and derivable from its literal definitions. I found no false in-scope source claim and no unresolved algebraic bridge. This is not a finding about what any actual Lean module declares, whether an inherited supplier exists or compiles, or whether source inventory equals a whole implementation. Those questions are withheld until an independently released formal/decoder packet. In particular, S7's implementation-inventory assertions are not independently verified here.

## R1. Reconstructing the counting algebra and scalar carrier

Source S1, lines 7-15. Let `Q` be the eight-element set in the stated order `field,sqrt,angle,trig,compare,read,write,emit`. A cost is a function `Q -> Nat`. All sums, scaling, and comparisons are componentwise. Put `e_t(q)=1` if `q=t`, otherwise `0`. A counted value is literally `(x,C)` and binding `(x,C)` to `f(x)=(y,E)` returns `(y,C+E)`. Thus a finite sequential composition has cost equal to the sum of its explicitly returned counters. This follows by substitution and associativity of natural addition, without a lawfulness assertion about an implementation monad.

`pure x=(x,0)` and `charge(t,x)=(x,e_t)` impose no condition on how `x` was obtained. The arbitrary functions used by bind, collect, and materialize are data. Their computational honesty is neither a premise nor a conclusion. For example, `f(i,j)=pure(g(i,j))` has zero callback counters for an arbitrarily complicated mathematical function `g`. Materializing it charges storage and not the concealed work of `g`. This is permitted by, not a counterexample to, the source.

The ten scalar/test primitives are four exact field operations, square root, arccos, cosine, sine, equality-to-zero, and negativity. Each has the advertised exact value and one appropriate indicator cost. They are total real functions; primitive division at zero or square root at a negative input is not excluded by the public definition. No numerical partial-function semantics should be substituted. In the elimination angle, the actual square-root input is nonnegative, and the only variable denominator `r` is used on `r != 0`. The constant denominator `2` is nonzero.

The model is stipulated annotation accounting for exact-real stored words with unit exact comparisons/transcendentals. It does not certify evaluator work, finite bits, allocation or peak memory, arithmetic stability, gate synthesis, or polynomial cost in `log N`. Proof/index/control/counter bookkeeping and ordinary list overhead are expressly omitted. Even a bound polynomial in `N=2^n` may be exponential in `n`.

## R2. Storage, sharing, and materialization

Source S2, lines 19-40. For a stored vector `xs:[n] -> alpha`, read returns the indexed entry and one read charge. Replacement returns the function equal to the new value at its selected index and equal to `xs` elsewhere; its specified charge is `n(e_read+e_write)`. Neither equality with the old value nor aliasing changes that charge. For outer matrix replacements the copied units are `N` row references; no `NM` entry-copy charge is licensed.

For `f:[n] -> Run alpha`, write the one stored counted result at index `i` as `E_i=(v_i,C_i)`. The literal collect output is `((v_i)_i, sum_i C_i+nH)` with `H=2e_read+2e_write`. Projection immediately gives `collect_value`; evaluating the cost at arbitrary `q` gives `collect_cost`. Writing `f(i).value` and `f(i).cost` in the equalities denotes components of that same result, not two evaluations. The two-pass storage charge is an accounting axiom of this source, not a derived hardware implementation result.

A stored matrix has nested carrier `Vector (Vector Real M) N`, denotation `D(A)(i,j)=A[i][j]`. Materialization is nested collect. For each counter,

    sum_i (sum_j f(i,j).cost(q) + M H(q)) + N H(q)
      = sum_i sum_j f(i,j).cost(q) + (NM+N) H(q).

This proves the exact materialization cost. The associated denotation is `f(i,j).value` by two projections, although no separate named materialize-value theorem is claimed by the source. Nothing establishes a constant-time real-entry oracle.

If `n=0`, collect has empty value and zero cost and does not require an inhabitant of `alpha`. An indexed read or replacement at length zero cannot be invoked. If `N=0`, materialization produces no rows and zero counters for any `M`. If `M=0<N`, it produces `N` empty rows and costs `2N` reads plus `2N` writes, with no entry callback. The carrier and denotation remain meaningful in both cases.

## R3. Literal angle, polar interpretation, and coefficient sharing

Source S3, lines 44-60. Set `T=x^2+y^2`, `r=sqrt T`, and, when `r != 0`, set `t=arccos(x/r)` and `a=-t` for `y<0`, `a=t` otherwise. The specified ExactAngle representation evaluates to zero at `r=0` and to `2a` otherwise. Therefore the elimination angle is `theta=0` at zero norm and `theta=-2a` otherwise. These are literal formulas, not unique solutions of a predicate and not equivalence classes modulo phase. I claim only the two supplied constructor cases, not an inventory of the withheld ambient ExactAngle type.

The counted algorithm computes the same `T,r` because `x*x=x^2` and `y*y=y^2`. At zero norm it returns zero. Otherwise the two sign branches return `-(2*t)` and `-(2*(-t))` respectively. Hence `angle_value` follows for all `x,y` without introducing nonzero or sign hypotheses. Substituting this result through one division by `2` and two trigonometric calls gives exactly the ordered triple in `coefficients_value`. There is one angle run and one shared half-angle, cosine, and sine.

The interpretative polar claim can also be derived without assuming it. Since `T>=0`, `r>=0` and `r^2=T`. Thus `r=0` iff `x=y=0`. At `r>0`, `x^2<=r^2` implies `|x/r|<=1`. Put `z=x/r`, `t=arccos z in [0,pi]`. Then `cos t=z` and `sin t=sqrt(1-z^2)=|y|/r`: the last equality follows from `(y/r)^2=1-z^2` and nonnegativity. For `y>=0`, `sin a=y/r`; for `y<0`, oddness of sine gives `sin(-t)=-|y|/r=y/r`. Cosine is unchanged by that sign. This includes `y=0`: `t` is `0` or `pi` and sine is zero. Therefore `x=r cos a`, `y=r sin a`.

For `theta=-2a`, `c=cos a`, `s=-sin a`. Consequently

    c*x-s*y = r(cos(a)^2+sin(a)^2) = r,
    s*x+c*y = r(-sin(a)cos(a)+cos(a)sin(a)) = 0.

At `x=y=0`, the actual coefficients are `(theta,c,s)=(0,1,0)` and the same two scalar equalities hold directly. Interpreting the two outputs as two different rows still requires distinct indices; no such restriction is needed for the literal angle identity.

## R4. Shared entry pairs and materialized rows

Source S3, lines 62-76. Four multiplications followed by subtraction and addition yield `(cu-sv,su+cv)` at cost `6e_field`. No data-dependent branch occurs.

The first rowPair collect reads both input entries, computes that pair once, and stores it. Its per-column charge is `6e_field+4e_read+2e_write`: two input reads and the collect's two reads/two writes. Each output projection collect costs `3e_read+2e_write` per column: one read of the stored pair plus collect overhead. Both materialized outputs therefore satisfy their respective formulas simultaneously, and their combined cost is

    M[(6e_field+4e_read+2e_write)
       +(3e_read+2e_write)+(3e_read+2e_write)]
      = M(6e_field+10e_read+6e_write).

The sharing of the stored pair is necessary to this cost derivation. For `M=0`, both output rows are empty, component equalities are vacuous, and the whole rowPair cost is zero for all `c,s`.

## R5. Persistent rotation, aliasing, and single elimination

Source S4, lines 80-105. Put `B=D(A)` and let `u,v` denote the two original stored rows, even when their indices coincide. RowPair yields `p=c*u-s*v`, `t=s*u+c*v`. The two replacements are `A1=A[j:=t]`, `A2=A1[i:=p]`. At a queried row `h`, the last write gives `p` if `h=i`; otherwise the first write gives `t` if `h=j`; otherwise `A[h]` remains. With `c=cos(theta/2)`, `s=sin(theta/2)`, these are exactly the three first-priority branches of `rotateRows`. This proves `rotate_value` for every legal pair of indices.

If `i=j`, `u=v` is the same original row, `p=(c-s)u` wins, and the second rowPair output is overwritten. One must not interpret this as a two-row orthogonal action. A minimal exact witness is `N=M=1`, `A=[1]`, `i=j=0`, `theta=pi/2`: `c=s=sqrt(2)/2`, so rotation returns `[0]`. Norm and invertibility are not preserved. This witness agrees with, rather than refutes, the source's priority rule. For eliminate on the same `A`, its pivot values are `(1,1)`, so `theta=-pi/2` and the actual returned row is `[sqrt(2)]`, not a zeroed second row. Thus the literal eliminate refinements do not imply a same-index elimination theorem.

The rotation's exact charge is the rowPair charge plus two original row-reference reads and two outer replacements:

    R(N,M)=M(6e_field+10e_read+6e_write)
             +2N(e_read+e_write)+2e_read.

There is no short-circuit for aliasing or zero angle. In particular, for `M=0` and legal row indices, rowPair is free but rotation still costs `2N+2` reads and `2N` writes.

Eliminate first reads two row references and their selected entries, hence four reads. It runs coefficients on those exact values, then rotates using their cached `c,s` and returns cached `theta`. Its matrix and angle fields are data, not proofs. Substitution of `coefficients_value`, the four read identities, and `rotate_value` proves both advertised refinements to `eliminationAngle` and `eliminateEntry`. The full exact cost, before any budget, is

    E(A,i,j,col) = coefficients(x,y).cost + R(N,M)+4e_read,
    x=B(i,col), y=B(j,col).

Neither rank nor pivot nonzeroness is assumed. At `x=y=0`, `theta=0,c=1,s=0`, so every entry is unchanged, including under aliasing; the work still occurs. For example rows `(0,1)` and `(0,2)` at column zero stay unchanged, rather than only their zero pivot entries being considered. Eliminate requires actual row indices and a column index, so `N,M` are positive for any invocation. General rotation needs `N>0` but permits `M=0`.

## R6. Fused sweep, legal recursion, and chronological action

Source S5, lines 109-128. A Step has two finite row indices, their adjacency proof on natural values, and a real angle. The matrix and log fields of Sweep contain no correctness proposition. A sweep invocation has `col in [M]`, `lo,count in Nat`, and `lo+count<N`. This strict domain condition also applies at zero. For `count=k+1`, the indices `i=lo+k`, `j=lo+k+1` satisfy `i<j<N`, and the tail bound `lo+k<N` follows. The generated adjacency proof is `i+1=j`; it is not an extra hypothesis on the public sweep result.

Define the fused producer recursively by `F(A,0)=(A,[],0)` and, for a successor, let `(A',theta)=eliminate(A,i,j,col).value`, obtain the tail from `F(A',k)`, and prepend `(i,j,theta)` with one emit charge. This runs elimination once and tail once, not once for each projected output. The resulting head is the earlier operation even though its list cell is charged after the tail returns. Thus the list order is chronological, not reversed. Zero pivot pairs are not omitted.

Simultaneous induction proves matrix and log refinement. At zero both supplier outputs are unchanged/empty. At successor the first matrix and angle are identified by eliminate's two refinements, and the induction hypothesis must be applied to `A'`, not `A`. Extending the log with the same Step proves log refinement; taking the recursive residual proves matrix refinement. Log length follows by `length(head::tail)=1+length(tail)`, or by log refinement and the supplier length identity. It does not account for any scalar or storage operations.

Current-data witness: choose `N=3,M=1,lo=0,count=2,col=0` and rows `A=(1,0,1)^T`. The first pair `(1,2)` has values `(0,1)`, so `theta1=-pi` and the intermediate rows are `(1,1,0)^T`. The second pair `(0,1)` now has values `(1,1)`, so `theta2=-pi/2` and the residual is `(sqrt(2),0,0)^T`. Precomputing the second angle from the original `(1,0)` instead gives zero and leaves `(1,1,0)^T`. Reversing the correct log also fails: it gives `(1/sqrt(2),1,1/sqrt(2))^T`. These exact witnesses distinguish two forbidden changes without proposing either as a repair.

For the action bridge, write `P=rotateRows(I,i,j,theta)` and let `B` be any `N`-by-`M` matrix. For row `i`,

    (PB)(i,k)=sum_t (c delta(i,t)-s delta(j,t)) B(t,k)
             =c B(i,k)-s B(j,k).

For row `h!=i,h=j`, the corresponding sum is `s B(i,k)+c B(j,k)`; for neither row it is `B(h,k)`. If `i=j`, the first expression is `(c-s)B(i,k)` and the same priority formula remains valid. Thus `PB=rotateRows(B,i,j,theta)` for arbitrary rectangular `B`, with no orthogonality hypothesis. Actual Steps are adjacent and distinct regardless.

Chronological action satisfies `applySteps([],B)=B` and `applySteps(step::tail,B)=applySteps(tail,P_step B)`. The preceding bridge identifies a head action with its eliminateEntry; induction on the updated supplier matrix proves supplier sweep action. The stored theorem then needs ALL of (stored matrix refinement, stored log refinement, supplier sweep action). Replacing either one by list length or an orthogonality assumption would not supply that argument.

Dimension boundaries: `N=0` forbids the strict row bound; `M=0` forbids a column index. At count zero, `lo<N` and a column still exist. At `N=1`, the only possible legal sweep has `lo=0,count=0`. More generally `count<=N-1-lo` on a legal call. No relation between `col` and `lo` is required. Source S5 does not claim a complete triangular form, SO factorization, identity residual, gate sequence, or qubit compiler.

## R7. Independent branch counts and uniform bounds

Source S6, lines 132-164. Use tuple order `(field,sqrt,angle,trig,compare,read,write,emit)`. Counting literal operations gives the following independently recovered table.

| Run | Exact counter tuple or stipulated budget |
| --- | --- |
| angle, zero norm | `(3,1,0,0,1,0,0,0)` |
| angle, nonzero norm and `y>=0` | `(6,1,1,0,2,0,0,0)` |
| angle, nonzero norm and `y<0` | `(7,1,1,0,2,0,0,0)` |
| angleBudget | `(7,1,1,0,2,0,0,0)` |
| coefficients, zero norm | `(4,1,0,2,1,0,0,0)` |
| coefficients, nonzero norm and `y>=0` | `(7,1,1,2,2,0,0,0)` |
| coefficients, nonzero norm and `y<0` | `(8,1,1,2,2,0,0,0)` |
| coefficientBudget | `(8,1,1,2,2,0,0,0)` |
| entryPair | `(6,0,0,0,0,0,0,0)` |
| rowPair | `(6M,0,0,0,0,10M,6M,0)` |
| rotate | `(6M,0,0,0,0,10M+2N+2,6M+2N,0)` |
| eliminationBudget | `(6M+8,1,1,2,2,10M+2N+6,6M+2N,0)` |
| stepBudget | `(6M+8,1,1,2,2,10M+2N+6,6M+2N,1)` |
| materialize storage only | `(0,0,0,0,0,2NM+2N,2NM+2N,0)` |

The angle's first two multiplies and sum cost three fields, then one sqrt and one zero comparison. On either nonzero branch, division, doubling, and final `0-...` add three fields; the negative-`y` branch adds one more subtraction. Arccos and the sign comparison each occur once only there. Even the zero-angle coefficients run pays one division and two trig calls. Thus all three angle tuples lie pointwise below angleBudget, and adding `e_field+2e_trig` bounds coefficients. No branch equality with the upper budget is falsely inferred.

Combining R5 with those exact branches gives the stronger descriptive elimination table: field count is `6M+4`, `6M+7`, or `6M+8`; sqrt is always `1`; angle is `0,1,1`; trig always `2`; compare is `1,2,2`; read and write are always `10M+2N+6` and `6M+2N`; emit is zero. In particular the source elimination budget is a valid pointwise maximum, and its six read constant counts four explicit pivot reads AND two rotate reads. The eight `stepBudget_fields` equalities are the entire eight-tuple conjunction, not eight alternative characterizations.

For legal successors, let `C(A,k;q)` be the actual fused run's counter at `q`, and `A'` the stored matrix returned by that actual first elimination. Binding yields exactly

    C(A,k+1;q)=E(A,i,j,col;q)+C(A',k;q)+e_emit(q).

The zero case is zero. Fix arbitrary `q` and use induction uniform over current matrices. With `S=stepBudget` and `B=eliminationBudget`,

    E(A,...;q)+C(A',k;q)+e_emit(q)
       <= B(q)+k S(q)+e_emit(q)
        = S(q)+k S(q)=(k+1)S(q).

This proves every coordinate bound for every legal input. Applying an induction hypothesis only to the original matrix would not prove it. The induction also needs the derived tail bound; no stronger domain assumption is necessary.

For exact emit, natural nonnegativity and `E(emit)<=B(emit)=0` give `E(emit)=0`. The recurrence then becomes `C(A,k+1;emit)=C(A',k;emit)+1`, with zero base, proving `C(A,count;emit)=count` independently of list length. Its sufficient AND-tail is the recurrence, elimination emit-zero, legal updated-data induction, and zero base. Length alone supplies none of the three other facts.

When initial materialization is explicitly bound into a sweep, costs add. The bound is the full supplied callback counter sum plus `(NM+N)H + count*S`. Without that composition, the sweep bound does not include materialization. The source never derives uncharged callback work or omitted runtime overhead from these formulas.

## R8. Binder and definition audit

Source S7, lines 168-174, checked against all preceding natural contracts rather than accepted as an author verdict.

All source-facing definitions described here are literal: operation enumeration and counters; all three Run operations and fields; scalar and storage functions; nested matrix denotation; the two evaluated ExactAngle cases, split/elimination angle formulas; coefficient/entry/row tuples; last-write rotation; Elimination and Sweep data records; the recursion and budget formulas. No unique-choice characterization, quotient, normalization representative, or hidden project-owned proposition is needed. Step alone carries its explicit adjacency proof, generated by the recursion. No stored correctness certificate is being unpacked from any Run/Elimination/Sweep field.

For generic bind, types `alpha,beta`, initial data and `f:alpha -> Run beta` are typing/data parameters. For charge, operation and arbitrary result value are data. For collect/read/replace, `n`, element type, vector/callback and valid finite index are typing/data. For materialize, `N,M` and the counted real callback are typing/data. For rowPair, `M,u,v,c,s` are typing/data. For rotate/eliminate, `N,M,A,i,j`, real coefficients or angle, and (for eliminate) `col` are typing/data with their finite range constraints. For every cost identity/bound, `q` is an arbitrary member of the eight-element operation carrier. Scalar formulas quantify arbitrary real inputs; branch predicates are local case splits, not added public premises.

For sweep and every sweep theorem, `N,M,A,col,lo,count` are data on their indicated carriers; `lo+count<N` is the sole explicit SOURCE domain hypothesis, including at count zero. In the successor recurrence its form is `lo+(k+1)<N`. The needed index bounds, adjacency, and recursive strict bound are produced internally from it; they are dependency results, not separate SOURCE assumptions. There are no STANDING, RULED, or EXCESS logical inputs in these reconstructed natural signatures. In particular orthogonality, square shape, rank, nonzero pivot, distinctness for a general rotate/eliminate, callback charging honesty, and an identity residual must not be appended.

This is a natural-signature audit only. Whether an actual formal module has additional typeclasses, parameters, private helpers, definitions with fallbacks, or extra public declarations is NOT determined by the source's own inventory. A future comparison must examine exact signatures and definitions without silently treating this phase as their certification.

## R9. Source topology, gaps, and disposition

The complete region inventory and declaration-family audit are in `coverage.json`. Every substantive source region is assigned a NODE or an explicit EXCLUDED disposition; heading/blank separators are not mathematical regions. No in-scope formula or prose bridge was dropped because it was not a named theorem.

The source-level reconstruction has no unresolved algebraic SOURCE_GAP. Three differently typed limitations must remain visible: (1) full actual-module inventory and formal fidelity are unavailable at phase 1; (2) inherited definitions and supplier identities have been independently reconstructed from the formulas given here, but their actual formal objects are withheld; (3) no accounting-to-machine-runtime refinement is asserted. The first two are future evidence obligations, and the third is an explicit out-of-model boundary, not a premise to add or a source error to repair.

Complete source AND-tails are recorded in the graph: collect formulas plus nested materialization; scalar angle identity plus primitive evaluation for coefficients; shared entry value plus all three collect passes for rowPair; rowPair value plus ordered writes for rotation; coefficient identity plus stored reads plus rotation for eliminate; updated-matrix recursion plus both eliminate refinements for simultaneous sweep refinement; both stored refinements plus supplier chronological action for stored action; exact primitive/storage charges plus coefficient bound for elimination budget; successor recurrence plus elimination bound plus uniform legal tail induction for sweep budget; recurrence plus elimination emit-zero plus induction for exact emission. No member of a multi-tail edge is individually sufficient.

There is one described construction route, not competing OR alternatives. Source topology is reconstructed here from a retrospective implementation-informed natural source; it is not a pre-implementation historical topology and not an elaborated Lean proof-term graph.

## Handoff and stop boundary

Mathematical delta: independently derived all literal value/cost formulas, polar interpretation, last-write alias semantics, legal updated-data recursion, action matrix bridge, exact emission, empty-dimension distinctions, and minimal counterexamples to stronger interpretations. In-scope failure class: `NONE`; excluded stronger same-index/uncharged-runtime/static-angle interpretations are not source claims. No source repair is proposed. Salvage is unnecessary; useful boundary witnesses are retained as review evidence, not admitted library theorems.

Process-memory IDs consulted: none; only the six explicitly authorized process documents. No parallel child work or multi-route comparator is applicable. Formal, executable, integration, publication, purification, and Exposition-Seal gates remain unperformed. Confidence is high in this natural reconstruction, with no conclusion yet about formal equivalence or actual whole-module coverage. Files changed are exactly `derivation.md`, `coverage.json`, `seal.json`, and `public-allowlist.json` under the requested phase-1 directory.

This reconstruction, exhaustive coverage, and public allowlist are hashed in `seal.json` before any future formal release. Phase 1 stops after the seal is reported. Only the same actual reviewer, after an explicit later release, should perform phase-2 comparison; phase-1 artifacts must not be rewritten in response to formal evidence.
