param(
  [string]$PacketRoot = $PSScriptRoot,
  [string]$FormalPacketRoot = ''
)
$ErrorActionPreference = 'Stop'
$reviewRoot = [IO.Path]::GetFullPath($PacketRoot)
$reviewAllow = Get-Content -Raw -LiteralPath (Join-Path $reviewRoot 'public-allowlist.json') | ConvertFrom-Json
$reviewSeal = Get-Content -Raw -LiteralPath (Join-Path $reviewRoot 'derivative-seal.json') | ConvertFrom-Json
$reviewForbidden = '(?i)(?:[a-z]:[\\/](?:Users|Documents and Settings)[\\/]|/(?:home|Users)/[^/\s]+/|\\\\[^\\\s]+\\(?:Users|homes)\\)'
$reviewCount = 0
foreach ($reviewRelative in $reviewAllow.public_files) {
  if ([IO.Path]::IsPathRooted($reviewRelative) -or $reviewRelative -match '(^|[\\/])\.\.([\\/]|$)') {
    throw 'Allowlist entry must stay inside logical packet root'
  }
  $reviewFile = Join-Path $reviewRoot $reviewRelative
  $reviewText = Get-Content -Raw -LiteralPath $reviewFile
  if ($reviewText -match $reviewForbidden) { throw ('Local-profile path detected in public file: ' + $reviewRelative) }
  if ($reviewRelative.EndsWith('.json')) { $null = $reviewText | ConvertFrom-Json }
  $reviewCount++
}
foreach ($reviewBinding in $reviewSeal.public_artifacts) {
  $reviewFile = Join-Path $reviewRoot $reviewBinding.file
  $reviewActual = (Get-FileHash -Algorithm SHA256 -LiteralPath $reviewFile).Hash.ToLowerInvariant()
  if ($reviewActual -ne $reviewBinding.sha256 -or (Get-Item -LiteralPath $reviewFile).Length -ne $reviewBinding.bytes) {
    throw ('Derivative content binding mismatch: ' + $reviewBinding.file)
  }
}
$reviewRows = Get-Content -Raw -LiteralPath (Join-Path $reviewRoot 'phase2/declaration-comparison.json') | ConvertFrom-Json
if ($reviewRows.rows.Count -ne 61 -or @($reviewRows.rows | Where-Object { $_.kind -ne 'instance' }).Count -ne 60) {
  throw 'Per-declaration comparison row count mismatch'
}
if ($FormalPacketRoot) {
  $reviewDeclPattern = '^(?:@\[simp\] )?(?:noncomputable )?(inductive|abbrev|structure|def|instance|theorem)\b'
  $reviewExpected = @(61, 12, 2, 2)
  for ($reviewIndex = 0; $reviewIndex -lt 4; $reviewIndex++) {
    $reviewFormalFile = Join-Path $FormalPacketRoot ('Module' + $reviewIndex + '.lean')
    $reviewFormalLines = Get-Content -LiteralPath $reviewFormalFile
    $reviewDeclarations = @($reviewFormalLines | Where-Object { $_ -match $reviewDeclPattern })
    if ($reviewDeclarations.Count -ne $reviewExpected[$reviewIndex]) { throw 'Released formal lexical inventory mismatch' }
    $reviewInput = @($reviewSeal.released_formal_inputs | Where-Object { $_.file -eq ('formal/Module' + $reviewIndex + '.lean') })
    if ($reviewInput.Count -ne 1 -or (Get-FileHash -Algorithm SHA256 -LiteralPath $reviewFormalFile).Hash.ToLowerInvariant() -ne $reviewInput[0].sha256) {
      throw 'Released formal input hash mismatch'
    }
  }
}
[pscustomobject]@{
  result = 'PASS'
  layer = 'Generic local-profile privacy, JSON, SHA-256 and bounded lexical checks only'
  public_files_scanned = $reviewCount
  target_explicit_commands = 61
  target_named_declarations = 60
  anonymous_Monad_instances = 1
  Lean_or_native_execution = 'NOT RUN'
} | ConvertTo-Json
