# Independent review of the bounded LOCAL source topology

Verdict: **requires-changes** for the proposed topology identified in `raw-input-pins.json`. This is a source-graph coverage/interface-strength verdict, not a Lean verdict, a rejection of the local mathematics, or an original-paper-fidelity verdict.

Reviewer identity: `/root/ghl_topology_independent_c44`. The topology extractor is a different agent, `/root/ghl_local_source_first_c43`. No extractor rationale, implementation, formal-context packet, decoder, prior reviewer/verdict, catalog, registry, CI output, or other mathematical source was inspected. Only the two allowlisted natural documents and proposed topology informed the mathematical review. Governance was read separately.

## Exact contract

The source is the retrospective, implementation-informed LOCAL mathematical recovery M0–M14 plus its recovery addendum. It is not an authenticated external paper. Every assertion below concerns representation of that bounded source. The original-paper gaps remain gaps: unavailable external proofs do not establish that their mathematics is false. No claim is made about unseen implementation semantics or Lean 4.33 compatibility.

Both natural documents were read through EOF twice, with a further targeted re-read of the M8/M9 and M12/M13 boundaries. The proposed JSON was read through EOF. The paragraph/formula disposition ledger is `coverage.json`; exact changes are in `findings.json`.

## Required changes

1. **Separate conditional record consequences from explicit-candidate construction (F01).** M12 line 226 distinguishes an early constructor accepting four premises from later constructors supplying them. E19 is appropriately guarded as conditional, and `OR.record-construction.same_strength=false` correctly warns about the distinction. Nevertheless E19 and E20 have the same head, `M12.constructed-record`, whose node claim specifically says the explicit candidate supplies the premises. E19 has no explicit-candidate node in its tail and cannot establish that provenance. A warning does not make these heads the same proposition. Split a conditional-record-consequences head from the constructed-record head. Let E19 reach the former; let E20 reach the latter using its existing actual-candidate evidence. Remove the unequal-strength OR entry, or re-express it only for a shared conditional conclusion with explicit premise discharge. Do not make E19 an unconditional shortcut to the restricted-column root.

2. **Expose the weaker encoded-slot image interface independently (F02).** M12 line 224 explicitly retains intermediate range/image results allowing encoded slot 7, without active-domain membership or uniqueness. `M12.candidate-image` mentions this weaker interface, but its sole incoming E16 requires `H.active-family` and `j in D`, hence slot <7. Its dependency on `M12.post`/`M12.candidate` also comes through that active restriction. A stronger-hypothesis instance does not cover the wider encoded-slot statement. Split the encoded-image and active-image interfaces, or give the image node a separate properly guarded route. Retain n>=3, three-bit width, a finite padded-clean source, and encoded slot <8 for the weaker route, as supported by the natural account; retain <7 for active membership/uniqueness. If the exact weaker interface cannot be recovered from this source, name a LOCAL interface-detail gap rather than imply it is supplied by E16. Do not invent an exact unseen formal signature.

Neither correction requires altering a mathematical source or implementing a repair. The seven-slot restricted-column route itself does not need the wider slot-7 result, and E21 does not depend on E19. These are localized graph typing/coverage repairs, not evidence against the restricted-column theorem.

## Backward closure audit

The local claim frontiers were treated as a forest, not a single full-block root:

- `M12.restricted-column`: E21 retains both j in D and quantified u in D; candidate image, candidate active membership, and uniqueness remain separate AND prerequisites. E18 uses active injectivity, which E09 obtains from reverse/global slot arithmetic, splice safety, and clean reconstruction. No conclusion about rows outside D or all-zero workspace is drawn. F01 affects the record presentation, not this E21 dependency spine; F02 affects coverage of the distinct weaker interface.
- `M10.swap-permutation`: E11 requires bit involution and finite range, not merely a label or Boolean. E10 preserves the two-slice action and range argument. No analytic-unitarity, elementary-gate, or compiled-cost edge is present.
- `M10.indicator-permutation`: E12/E13 preserve the literal q bounds and row invariance without assuming q=1+2n for incompatible widths. The generic interval classifier is not replaced by the canonical historical bulk predicate.
- `M4.image-return` and `M4.collision`: E04/E05 retain the canonical M14 guard and actual branch priority. Reverse-on-image existence is not promoted to injectivity; the colliding historical candidate is not substituted for the global-slot model.
- Literal syntax, matrices, coefficients, record fields, and symbolic rotations are definition/data frontiers, not independently certified quantum oracles. Section anchors retain their formulas; no extra analytic relationship follows from symbol names.

The prospective analytic-unitary, coefficient-oracle, full Robin projection, and compiled-resource entries are explicitly unresolved. Their gap tails are not treated as established sufficient evidence. In particular the full-product gap still owns amplitude/phase reconciliation, signal/projection register mismatch, path summation, and workspace cleanup. External paper and citation gaps are not used to reject LOCAL address/permutation results.

## Exhaustive bounded-source checks

The coverage ledger maps every substantive paragraph/formula/table and the addendum's eight external-source family rows. It distinguishes local coverage from unavailable original-paper coverage. Grouping multiple paragraphs under one stable node is acceptable when the section anchor supplies the exact formula and restrictions; this review does not require gratuitous nodes for every sentence. F02 is different: it is a broader-hypothesis local interface with no matching incoming route, not merely a missing repeated formula.

Specific preserved boundaries include arbitrary rational symbol environments; temporal matrix product order; unrestricted natural parameter records; truncated subtraction; signal versus projected-wire counts; the exterior-row off-by-one example; active slots with zero coefficients; canonical versus arbitrary bulk; n>=3 versus unused wrapper n>=2; low/high no-spill register conditions; independent Robin symbols and table priority; the unresolved single-/double-angle discrepancy; clean-workspace zero entries versus unconstrained completion; exact finite permutations versus synthesis; unbounded second overwrite u; explicit width equality ell=3; active-only uniqueness; and gamma/resource metadata versus actual state transitions.

No established alternative sufficient physical construction appears in the bounded source. The future boundary-source/repair OR decision is appropriately unproved and retains complete AND tails; it is not an accepted correction. Fixed-N8 routes and separate Hamiltonian/phase composition are excluded context, not imported OR proofs. Stored one-/multi-dimensional Hamiltonian expressions remain covered as data under M13, while their separate composition proof is excluded; these are not contradictory dispositions.

## Handoff boundary

Mathematical delta: two precise graph corrections that prevent loss of conditional provenance and loss of the wider encoded-image interface. No mathematical route was refuted, and no source was declared invalid. Failure class: NONE for mathematical route evaluation; graph disposition: requires-changes. Salvage: retain the active restricted-column spine, finite permutation routes, data/gap distinctions, and external-source exclusions. Process-memory records consulted: none, because not allowlisted. No children, compiler, native-code experiment, network, Git, production, or registry operation was used. Parallel admission/common-blind-spot comparison and default verified physical-route selection are not applicable to this scoped review.

Purification/Exposition Seal and formal/source semantic acceptance are not assessed. The output seal binds only this independent bounded-source review. Corrections need a successor topology and renewed review; this packet does not mutate or approve the proposed topology.
