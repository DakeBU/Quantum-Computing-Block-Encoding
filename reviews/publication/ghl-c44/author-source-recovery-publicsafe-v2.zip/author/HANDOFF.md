# GHL2025 c42 author/source-recovery handoff

Status: AUTHOR_SOURCE_RECOVERY only. No independent reconstruction, reviewer verdict, accepted metadata, compiler run, or paper-wide completion is claimed. Original historical formalizer: UNKNOWN. This worker is a retrospective source-recovery author, not a new independent reviewer.

## Objective and result

Recover the existing mathematical account of the WHOLE changed module without re-proving unrelated paper material. The complete actual `QuantumBlockEncoding/GHL2025.lean` was read through EOF: all 8474 lines, proofs, private helpers, structure fields, definitions, comments, and ambient commands. Paginated ranges were 1–550, 551–1500, 1501–2400, 2401–3400, 3401–3850, 3851–4500, 4501–5150, 5151–5800, 5801–6450, 6451–7100, 7101–7750, 7751–8474. Truncated overlap regions were re-read at 971–1060, 1051–1165, 2741–2810, and 2801–3100. No claim is made that tool-read length by itself certifies understanding or source fidelity.

The preexisting public lesson `docs/lessons/ghl-global-slot-clean-domain-and-transpose-boundary.md` already gives an implementation-informed whole-module mathematical derivation M0–M14. Its raw SHA-256 is `fefd00e4a255744e26dd1ceebadc0767d321d1e93c3db85af711bab0fde08fd8`; the copied `natural/original-M0-M14-lesson.md` has that SAME hash. Reuse this real derivation rather than create hundreds of nominally novel source claims. It is a retrospective LOCAL contract, not an independently verified reconstruction of the original paper.

The lexical inventory contains 405 explicit declarations: 38 structures, 114 definitions, 252 theorems (two private), and one inductive type. All 365 direct structure fields are separately captured with complete source text, including defaults and multiline propositions; theorem signatures are not cut at a record-field `:=`. There are three explicitly written inductive constructors. Compiler-generated constructors, projections, recursors, instances and private kernel names are NOT inferred as checked declarations. Obtain the elaborated inventory later if admission requires it.

## Exact migration delta and context

Initial audit commit: `30fe1d77735221cb86fdfc39102c151c9527dc37`.
Base: `f2cba045611a0d11c5995c29607569726bf1d6c5`.
During recovery, the parent advanced HEAD to `30acc66eb2730d300b2600fbd1b428431d5b86de`; a read-only diff confirmed no intervening changes to this target, lean-toolchain, or lake-manifest. The target hash and lesson hash were rechecked unchanged.

Only two production source lines differ from the base:
- line 5459, `swapOracleMatrix_eq_image`: `simp [swapOracleMatrix, swapOracleImage]` becomes the same `simp` followed by `<;> rfl`.
- line 5788, `indicatorOracleMatrix_eq_image`: analogous `<;> rfl` suffix.
No signature, definition, source data, Boolean status, import, or circuit list changed in this file. This is a static source comparison, not a proof that Lean 4.33 elaborates the complete module. The toolchain moves from 4.29.1 to `leanprover/lean4:v4.33.0`; whole-module migration binding remains mandatory.

The narrow project import closure is Core → Resources → Circuit → BlockEncoding → CircuitSemantics, with GHL2025 importing BlockEncoding and CircuitSemantics. Core imports Std. The full five local providers are comment-masked in `formal-only/`; no Mathlib theorem use is implied by the package manifest. The root toolchain/manifest and every raw provider digest are pinned separately.

## Complete declaration grouping and natural reuse

Each explicit declaration belongs to exactly one contiguous group in `declaration-inventory.json`. Counts include private declarations but exclude compiler-generated names.

| Group | Lines | Count | Existing lesson mechanism |
| --- | --- | ---: | --- |
| G01 | 1–851 | 56 | M1/M2/M8/M13: parameters, metadata, wire counts, theorem data, transcripts |
| G02 | 852–1294 | 18 | M3/M4: global offsets, reverse slots, modular uniqueness; historical map definition |
| G03 | 1295–1889 | 17 | M4: rejected row-local map, reverse witnesses, finite guards |
| G04 | 1890–2405 | 31 | M5: register extraction, global address, splice/range/no-spill |
| G05 | 2406–2679 | 17 | M4/M8: active slot domain versus rejected nonzero-domain classifiers |
| G06 | 2680–3365 | 32 | M8: obligation-only extension/citation/process records |
| G07 | 3366–3599 | 20 | M5: column audit, forward/transpose entry witnesses |
| G08 | 3600–3895 | 16 | M6/M7: row-local/global coefficient tables and shared N_D data |
| G09 | 3896–3950 | 4 | M7/M10: indicator matrix/gate/dagger record |
| G10 | 3951–4694 | 41 | M7/M8: symbolic bulk/boundary rotations and unresolved analytic routes |
| G11 | 4695–4852 | 8 | M4/M5: active sparse gate and concrete drift/collision guards |
| G12 | 4853–5409 | 34 | M9: symbolic f/N_f clean branch, arbitrary completion placeholders |
| G13 | 5410–5554 | 10 | M10/M12: SWAP definitions, old dagger helper, active transpose entry |
| G14 | 5555–5907 | 17 | M2/M10/M12: conditional cleanup record, active gate list, finite indicator cases, bit providers |
| G15 | 5908–6220 | 17 | M10: arbitrary-width SWAP involution/range/permutation |
| G16 | 6221–6694 | 19 | M11/M12: post-SWAP register equations, splice laws, clean reconstruction |
| G17 | 6695–7418 | 16 | M11/M12: active-domain injectivity, explicit preimage, restricted uniqueness |
| G18 | 7419–8264 | 18 | M8/M12/M13: inverse-on-range records, restricted transpose column, nonpromotion guards |
| G19 | 8265–8474 | 14 | M10: arbitrary-width indicator involution/range/permutation |

M0 is imported-carrier context, not a new target declaration family. M14 is the existing canonical bulk-guard clarification, not a new source theorem. All public lexical identities have prefix `QuantumBlockEncoding.GHL2025.`; private helper identifiers at lines 1100 and 1115 require separate elaborated-name handling.

## Existing source correspondence: useful assets and gaps

Use the actual existing row IDs in `website/robin-paper-map.json`: `sparse-access`, `indicator`, `boundary-rotation`, `theorem-data`, `gamma-three`, `circuit-transcript`, `fixed-n-structural-routes`, `hamiltonian-phase-audit`, `hamiltonian-composition`. The last three include other modules and must not be counted as declarations or closure of this target.

The existing paper-contribution source map uses `ODBS, ODTS, Of, HW, Uindic, RyBoundary, RobinTheorem, GammaSlices, FigRobin, OneD, MultiD, QSVT, BlockEncodingDef`. Its main.tex line references are historical locator data, not currently verified raw-paper anchors. It contains stale frontier prose (for example treating OneD as awaiting the one-term route) compared with the newer separate GHLHamiltonian audit. Do not silently merge these statuses.

| Source family | Reusable local evidence | Remaining raw/semantic boundary |
| --- | --- | --- |
| ODBS, source Lemma 2 → prior Lemma 1 | M3/M5/M11/M12; exact global slot/address and restricted cleanup derivation | Full original proof/circuit/resource paragraphs unavailable; legacy annotations say Lemma 1. Active-domain injection does not prove the full overwrite matrix unitary. |
| Uindic | M10; general involution, finite range, one 1 per matrix row/column | Fixed canonical window 2..N−3, not arbitrary K1,K2 compiler; no elementary-gate resource theorem here. |
| ODTS, shared N_D | M6/M7; literal symbolic 2×2 matrix and shared data wiring | Real/complex interpretation, nonzero/bound/division/sqrt/abs-square/unitarity and D-versus-D-transpose alignment unresolved here. |
| RyBoundary | M7; explicit single-angle/half-angle legacy formula | Edited excerpts assert doubled-angle correction; original Eq. (27) unavailable here, and independent correction review not performed. Separate fixed-N8 roots are not a retrofit to this module. |
| Of | M9; literal clean branch plus free completion symbols | Cited arXiv:2411.01131 Theorem 5 not supplied; free entries do not enforce preserved system label, normalizer bound, orthogonality or unitarity. |
| HW, GammaSlices, FigRobin, RobinTheorem | M1/M2/M13; stored tuples, prefactors, two explicit transcript lists | No whole-module product/projection theorem, gamma state transition, arbitrary-width primitive compiler or claimed resource bound proved by metadata. |
| OneD/MultiD/QSVT/BE definition | Stored claim records and cross-module/source references | Exclude actual downstream derivations from this module's closure claim; do not refute or re-prove separately established Hamiltonian work. |

The expected archive `../outer_papers/quantum/GHL2025/main.tex` is absent; `QBE_PAPER_SOURCE_ROOT` was not set. No primary TeX/bibliography/cited-theorem source was read or downloaded. `paper-notes/GHL2025/source-excerpts.tex` and `docs/guseynov_huang_liu_2025_notes.md` are edited retrospective inputs, not authenticated original paper text. Their natural copies are labelled accordingly. The excerpts omit bulk-amplitude proof, detailed gamma1/gamma2 derivation, original figure/caption, complete resource argument, boundary/ghost-point derivation and citation proofs; gamma3 retains potentially inconsistent i/j/σ notation. Every omitted raw region remains SOURCE_GAP for any original-paper fidelity claim.

No QBE-AUTO-002 conversion window, proof-obligation file, or `research-wiki/cited-results/GHL2025.md` was present in the inspected current directories, although target String fields still point there. Preserve those references as historical unresolved provenance; do not fabricate their contents. Warm/cold task files are real but define a fixed N=8 benchmark and an isolation policy, not this whole-module source graph.

At the inspected snapshot, `website/research/publications.json` had zero records for `QuantumBlockEncoding/GHL2025.lean`, and `website/research/sources.json` had no GHL/Robin/Guseynov source ID. Do not invent a canonical accepted source ID; this dossier creates no registry row.

## Binder, definition, and evidence risks that must survive review

1. Parameters are unrestricted Nat data: n=0, kappa=0, width overflow and truncated subtraction are literal allowed inputs. Indicator position is 1+n+(n−clog2 kappa)+clog2 kappa, only equal to 1+2n when width-compatible. The code proves sufficient inequalities without that unconditional equality.
2. The global κ=7 family, n≥3 and source-domain s<7 restrictions are genuine local theorem guards; `clog2 kappa=3` is redundant with kappa=7 but retained. Several n≥2/finite/clean binders are unused in smaller helpers. This is not a paper-binder acceptance audit. Do not call final source hypotheses SOURCE without raw support; do not move preimage or correctness results into the final theorem's public premises.
3. `BandedSparseAccessPostSwapCleanup` expands to 11 fields, including supplied post-image/preimage/clean/range premises. The stronger candidate route PRODUCES these facts under its local assumptions. Neither the record name nor its construction proves all-zero ancilla cleanup.
4. Restricted transpose-column formulas quantify only over the active global-source subset. Encoded slot 7 and nonclean padded states remain outside uniqueness. Full-space transpose columns may contain extra nonzero entries.
5. Single arccos legacy boundary data, doubled arccos edited text, fixed-N8 corrected circuit and original paper are FOUR distinct objects. No correction is independently approved in this recovery.
6. Gate `proved` flags and obligation flags are Bool data. Only indicator and SWAP are marked true in the active list; all source-oracle/extraction/resource obligations remain as written. Permutation proofs are literal finite zero/one-matrix results, not a complex-unitarity predicate instantiation or gate synthesis.
7. Actual boundary cardinality for a valid inclusive bulk is K1+N−K2−1; the stored deviatingIndices expression is K1+N−K2. It remains stored source/resource metadata, not an exact counting theorem.
8. `Coeff` is free rational-expression syntax. Inverse/trig/orthogonal-entry names impose no equations. The module has no characterized-choice well-definedness theorem or quotient representative construction; total default/fallback branches are local formulas, not certified literal original-paper definitions.
9. The backend seven-gate list and ten-slot theorem-facing transcript are different. Gate.swap 0 0 is a label placeholder while its supplied matrix swaps whole registers. Matching labels is not matrix/gate-action fidelity.
10. Thirteen explicit bodies use native_decide; they are enumerated in the inventory. No current elaborated type/axiom census was run. Exact native evaluator trust must be disclosed, not silently replaced with kernel-only or experimental axioms.

## Real historical tests/logs, not inherited admission

`reports/lean-433-migration/c25-cf77-lean-gate.json` records passed `lake build`, `lake build Tests`, and all listed compiled modules (including this target) at commit `cf77fde090fff00fcb829d1684b85596eec4949f`, Lean 4.33.0, proof-input digest `5a8f47f8d0afd1d4f957e55babde52a9e9c01babf05c481b988e99ebca2f7758`. It is historical evidence only: equality with the current whole proof-input set was not established by this worker.

The warm export manifest records source commit `5d7e27a7faaf9465eb405db41f6cd1f323d05db2`, target alpha 56/3, and distinct fixed-N8 Figure4/paper-seven/XOR routes. Figure4 identity is `warm-robin-figure4-fixed-n8-t3`, 881 primitive gates, depth 674, 9 qubits, circuit digest `786b35d6d795c19ef952c2e435b6f0fd5db24d6d7b0f101fcff7bcce0db1f023`; the manifest reports internal/Qiskit/OpenQASM checks. The XOR root is `QuantumBlockEncoding.Robin.warmRobinXorFourSlotPrimitiveVerifiedBlockEncoding` with 106 gates/depth96/6 qubits. These stored checks were not replayed. Their `paperLevelWinnerCertified` field is benchmark-scoped, not arbitrary-n or whole-module source certification. The earlier 20260812 experiment audit has an interrupted run and no certified root anchors; do not average incompatible dates/scopes into a completion claim.

## Bounded publication/review plan — no new paper formalization required

A. Freeze the preexisting M0–M14 local mathematical source plus this visibly separate addendum and exact formal signature/field inventory. Bind all 8474 target lines, both private helpers, ambient commands, all five providers, toolchain/manifest, and native boundary. Retain 19 mechanism groups; sourceAnchor credit only for the retrospective LOCAL contract. Internal record guards are prerequisites/providers, not 405 separately invented paper anchors.

B. Route only `formal-only/` to a genuinely distinct decoder. It has the complete comment-masked module and narrow provider context, preserves every String literal, and explicitly does NOT promise identity-blinding. Do not attach this handoff, natural lesson, source classifications, prior c30 reviews, source maps, or a desired verdict. Store actual run/input identity and output; do not populate them in advance.

C. A reviewer distinct from author and decoder receives pinned natural material, the exact formal context, and the actual reconstruction, without a prior verdict. Check all 19 groups, recursive structure fields, literal defaults, and the ten risks above. Compare against the LOCAL source separately from any unavailable original paper. A source-first global original-paper topology/repair review remains blocked on authentic raw primary material; it is not required to invent a new universal construction merely to audit this local legacy module.

D. Later permitted compilation must extract complete current types/generated declarations/axioms without field := truncation, run relevant focused tests, then required repository gates and publication check against the base. Reuse a historical build only after actual proof-input equality. Do not add native axioms, weaken compilation flags, change production, or stage acceptance metadata to bypass the gate.

E. Keep paper-fidelity, corrected fixed-N8 routes, downstream Hamiltonian composition, and the arbitrary-width primitive/resource frontier separate. A prospective local record must say the original-paper source coverage is incomplete, not claim universal Robin/paper acceptance. Purification/Exposition Seal remain PENDING; M0–M14 is reusable exposition, not an accepted seal.

## Structured handoff

- Mathematical delta: lossless reuse/source map of the full legacy local mechanism; no new theorem.
- Root-frontier effect: removes rediscovery ambiguity and supplies separately routable full formal/source inputs; does not discharge migration round-trip or compiler gate.
- Failure class: ENV_BLOCKED for unavailable primary archive/current permitted compiler execution; no mathematical route retired. Existing rejected row-local model remains separately recorded.
- Salvage: preexisting M0–M14 natural derivation and exact existing arithmetic/permutation/preimage providers retained; no fragment promoted.
- Process memory consulted: QBE-PM-LOW-TOKEN-CONTROL-PLANE; QBE-PM-VERIFIER-SEMANTIC-LEVEL.
- Direction fingerprint: independently recover large legacy GHL source correspondence; expected gain is avoiding proof rediscovery while preserving whole-changed-module admission.
- Parallel admission: no children spawned. This author is neither decoder nor reviewer; common-blind-spot review not performed.
- Default verified route/comparator: no new choice or comparator verdict; retain existing finite alternatives and their scopes.
- Files changed: ONLY this assigned recovery directory. No repository/Lean/native/configuration/catalog/registry/network/Git writes.
- Purification/Exposition-Seal: PENDING, no acceptance asserted.
- Residual risk: primary paper coverage and correction provenance incomplete; exact current compiler/native census absent; historical mapping prose drifts across modules. Confidence high in raw inventory and two-line delta, not in original-paper fidelity.
- Next dependency-ready objective: full LOCAL-contract blind reconstruction of the frozen formal-only input, followed by distinct anti-anchored comparison. Stop here; do not call this source recovery a decoder/reviewer verdict.

