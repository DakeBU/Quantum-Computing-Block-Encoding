# Public-safe text scan v2. Read-only; never prints matched text.
param([Parameter(Mandatory = $true)][string]$PacketRoot)
$ErrorActionPreference = 'Stop'
function Add-JsonStrings($Value, $Bag) {
  if ($Value -is [string]) { [void]$Bag.Add($Value); return }
  if ($null -eq $Value) { return }
  if ($Value -is [System.Collections.IDictionary]) {
    foreach ($key in $Value.Keys) { [void]$Bag.Add([string]$key); Add-JsonStrings $Value[$key] $Bag }
    return
  }
  if ($Value -is [System.Array]) { foreach ($entry in $Value) { Add-JsonStrings $entry $Bag }; return }
  if ($Value -is [PSCustomObject]) {
    foreach ($property in $Value.PSObject.Properties) { [void]$Bag.Add($property.Name); Add-JsonStrings $property.Value $Bag }
  }
}
$patterns = [ordered]@{
  windows_absolute_root = '(?<![A-Za-z0-9+.-])[A-Za-z]:[\\/]+'
  runner_home = ('/home/' + 'runner')
  recognizable_credential = '(?:sk-(?:proj-)?[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{30,}|AKIA[A-Z0-9]{16}|AIza[A-Za-z0-9_-]{30,}|xox[baprs]-[A-Za-z0-9-]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,})'
}
$members = @()
$totalHits = 0
foreach ($file in (Get-ChildItem -LiteralPath $PacketRoot -File -Recurse | Sort-Object FullName)) {
  $relative = $file.FullName.Substring($PacketRoot.TrimEnd('/','\').Length + 1).Replace('\','/')
  $text = [IO.File]::ReadAllText($file.FullName)
  $variants = [Collections.Generic.List[string]]::new()
  [void]$variants.Add($text)
  $unicodeDecoded = [regex]::Replace($text, '\\u([0-9a-fA-F]{4})', {
    param($match)
    [string][char][Convert]::ToInt32($match.Groups[1].Value, 16)
  }).Replace('\/','/')
  [void]$variants.Add($unicodeDecoded)
  try { Add-JsonStrings ($text | ConvertFrom-Json -ErrorAction Stop) $variants } catch { }
  $hits = [ordered]@{}
  foreach ($key in $patterns.Keys) {
    $count = 0
    foreach ($variant in $variants) { $count += [regex]::Matches($variant, $patterns[$key]).Count }
    $hits[$key] = $count
    $totalHits += $count
  }
  $members += [PSCustomObject]@{path = $relative; hits = $hits}
}
[PSCustomObject]@{
  status = if ($totalHits -eq 0) { 'CLEAR_BOUNDED_PATTERN_SCAN' } else { 'QUARANTINE_REQUIRED' }
  method = 'Raw UTF-8 text, Unicode-escape/slash-decoded text, and recursively decoded JSON keys/string values; URL-scheme suffix excluded from drive-root detection.'
  secret_match_values_printed = $false
  file_count = $members.Count
  total_hits = $totalHits
  members = $members
  limitation = 'Pattern screening is not a universal privacy or secret-detection guarantee.'
} | ConvertTo-Json -Depth 8
if ($totalHits -ne 0) { exit 1 }
