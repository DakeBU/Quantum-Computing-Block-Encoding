# Public-safe control successor v2

This is a bounded control/export successor of the frozen c42 recovery, not a mathematical revision. The original directory remains untouched. All 20 original members are accounted for in `original-public-hash-map.json`: 18 are byte-for-byte copies, and exactly two path-bearing control files have explicit version-2 replacements at their existing relative paths.

## Changed control fields

- `context-seal.json`: repository/read root and packet/write root become `logical:RepositoryRoot` and `logical:PacketRoot`; the historical filename-only search root becomes `logical:SourceSearchRoot`; the write allowlist refers only to the logical packet root. Added fields identify version 2, pin the original control hash, explain external root resolution and retain the original evidence-status boundary. No mathematical, proof, source or raw snapshot pin changes.
- `verify-transport.ps1`: removed both machine-specific default parameter values. RepositoryRoot and PacketRoot are now mandatory explicit CLI arguments. A version-2 comment and the original control digest identify the successor. The verification body is unchanged.

The original `output-manifest.json`, `transport-check.json`, `HANDOFF.md`, natural texts and formal metadata remain exact historical copies. In particular, the historical manifest still pins ORIGINAL control hashes; the version-2 hash map and whole successor seal are authoritative for this export's control bindings. Do not silently reinterpret historical receipts as new evidence.

## Routing and privacy boundary

Preserve `natural/`, `formal-only/` and `author/` separately. The formal-only route is unchanged and does not include natural source or author classifications. It remains comment-masked, NOT paper-identity-blind; every Lean identifier and String literal is untouched.

The bounded scan checks raw text, Unicode/slash-decoded text, and recursively JSON-decoded keys/String values for absolute Windows drive roots, the designated CI runner-home path and recognizable token/private-key patterns. Windows drive detection is token-bounded to avoid mistaking URL scheme suffixes for drive roots. No matched secret text is logged. No formal/natural member required quarantine. This is screening, not a universal guarantee that every possible secret format is recognized.

Run the read-only controls with caller-supplied roots:
```powershell
./author/verify-transport.ps1 -RepositoryRoot <repository-root> -PacketRoot <successor-root>
./author/scan-safe-members-v2.ps1 -PacketRoot <successor-root>
```

Static checks confirm the original 8474-line target and five providers remain exact comment masks, all six formal snapshots are byte-identical to c42, and M0–M14 retains raw hash `fefd00e4a255744e26dd1ceebadc0767d321d1e93c3db85af711bab0fde08fd8`. The 405-declaration/19-group recovery remains retrospective LOCAL mathematics, not exhaustive primary-paper source closure.

No Lean/lake/compiler/native evaluator/kernel run, decoder or reviewer verdict, source correction approval, production/catalog/registry/Git/network operation, or child work is part of this successor. The seal is a relative-path export allowlist with its own hash explicitly excluded.
