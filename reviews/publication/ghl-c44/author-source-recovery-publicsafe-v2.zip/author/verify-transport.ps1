# Public-safe control successor v2. Required roots are explicit CLI arguments.
# Original control SHA-256: 65a33bbd44e0b7240d1ee0639312ba05e977d157e4ede503cd74ca825687e4fe
param(
  [Parameter(Mandatory = $true)][string]$RepositoryRoot,
  [Parameter(Mandatory = $true)][string]$PacketRoot
)
$ErrorActionPreference = 'Stop'
function Get-CommentMaskedText([string]$InputText) {
  $chars = $InputText.ToCharArray()
  $mode = 'code'
  $depth = 0
  for ($i = 0; $i -lt $InputText.Length; $i++) {
    $c = $InputText[$i]
    $d = if ($i + 1 -lt $InputText.Length) { $InputText[$i + 1] } else { [char]0 }
    if ($mode -eq 'string') {
      if ($c -eq [char]92) { $i++ } elseif ($c -eq [char]34) { $mode = 'code' }
      continue
    }
    if ($mode -eq 'line') {
      if ($c -eq [char]10) { $mode = 'code' }
      elseif ($c -ne [char]13) { $chars[$i] = [char]32 }
      continue
    }
    if ($mode -eq 'block') {
      if ($c -eq '/' -and $d -eq '-') {
        $chars[$i] = [char]32; $chars[$i+1] = [char]32; $depth++; $i++
      } elseif ($c -eq '-' -and $d -eq '/') {
        $chars[$i] = [char]32; $chars[$i+1] = [char]32; $depth--; $i++
        if ($depth -eq 0) { $mode = 'code' }
      } elseif ($c -ne [char]10 -and $c -ne [char]13) { $chars[$i] = [char]32 }
      continue
    }
    if ($c -eq [char]34) { $mode = 'string'; continue }
    if ($c -eq '-' -and $d -eq '-') {
      $chars[$i] = [char]32; $chars[$i+1] = [char]32; $i++; $mode = 'line'
    } elseif ($c -eq '/' -and $d -eq '-') {
      $chars[$i] = [char]32; $chars[$i+1] = [char]32; $i++; $depth = 1; $mode = 'block'
    }
  }
  if ($depth -ne 0) { throw 'Unclosed block comment' }
  return (-join $chars).Replace(([string][char]13 + [char]10), ([string][char]10))
}
$paths = @(
  'QuantumBlockEncoding/GHL2025.lean',
  'QuantumBlockEncoding/Core.lean',
  'QuantumBlockEncoding/Resources.lean',
  'QuantumBlockEncoding/Circuit.lean',
  'QuantumBlockEncoding/BlockEncoding.lean',
  'QuantumBlockEncoding/CircuitSemantics.lean'
)
$checks = @()
foreach ($relative in $paths) {
  $rawPath = Join-Path $RepositoryRoot $relative
  $snapshotPath = Join-Path $PacketRoot ('formal-only/' + $relative)
  $rawText = [IO.File]::ReadAllText($rawPath)
  $actualText = [IO.File]::ReadAllText($snapshotPath)
  $expectedText = Get-CommentMaskedText $rawText
  if ($expectedText -cne $actualText) { throw ('Comment-mask transport mismatch: ' + $relative) }
  $checks += [PSCustomObject]@{
    path = $relative
    exact_comment_mask = $true
    raw_sha256 = (Get-FileHash -LiteralPath $rawPath -Algorithm SHA256).Hash.ToLowerInvariant()
    snapshot_sha256 = (Get-FileHash -LiteralPath $snapshotPath -Algorithm SHA256).Hash.ToLowerInvariant()
    line_count = @(Get-Content -LiteralPath $snapshotPath).Count
  }
}
$target = $checks | Where-Object path -eq 'QuantumBlockEncoding/GHL2025.lean'
if ($target.raw_sha256 -ne '2dba31e056b134107b34c7e41c6a5c3a2130c22a2634372d1e9ce794961a4fd4') { throw 'Target raw source changed after recovery' }
if ($target.line_count -ne 8474) { throw 'Whole target line-count mismatch' }
$lessonRaw = Join-Path $RepositoryRoot 'docs/lessons/ghl-global-slot-clean-domain-and-transpose-boundary.md'
$lessonCopy = Join-Path $PacketRoot 'natural/original-M0-M14-lesson.md'
$lessonHash = (Get-FileHash -LiteralPath $lessonRaw -Algorithm SHA256).Hash
if ($lessonHash -ne (Get-FileHash -LiteralPath $lessonCopy -Algorithm SHA256).Hash) { throw 'Natural lesson is not an exact raw copy' }
$inventory = Get-Content -LiteralPath (Join-Path $PacketRoot 'author/declaration-inventory.json') -Raw | ConvertFrom-Json
if ($inventory.declarations.Count -ne 405) { throw 'Explicit declaration count mismatch' }
$expectedLine = 1
foreach ($group in $inventory.groups) {
  if ($group.start_line -ne $expectedLine) { throw 'Group gap/overlap' }
  $expectedLine = $group.end_line + 1
}
if ($expectedLine -ne 8475) { throw 'Group coverage does not end at EOF' }
[PSCustomObject]@{
  status = 'STATIC_TRANSPORT_CHECK_ONLY'
  no_compiler_or_native_evaluator_run = $true
  snapshots = $checks
  natural_lesson_raw_copy_equal = $true
  natural_lesson_sha256 = $lessonHash.ToLowerInvariant()
  explicit_declaration_count = $inventory.declarations.Count
  contiguous_group_coverage = '1-8474'
} | ConvertTo-Json -Depth 8

