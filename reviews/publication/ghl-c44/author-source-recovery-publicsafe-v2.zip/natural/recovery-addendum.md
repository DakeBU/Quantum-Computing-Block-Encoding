# Recovery addendum to the frozen M0–M14 local mathematical source

This is a separately authored retrospective addendum. It does not rewrite M0–M14, certify the original paper, give an independent review, approve a source correction, or state a compiler result.

## Frozen source identity and scope

The accompanying `original-M0-M14-lesson.md` is an exact copy of the existing public lesson with raw SHA-256
`fefd00e4a255744e26dd1ceebadc0767d321d1e93c3db85af711bab0fde08fd8`.
The historical `c774...` digest mentioned in M14 is a digest recorded inside the historical account, not the digest of the current full lesson or current formal target.

The mathematical source for the prospective LOCAL review is the whole M0–M14 account, including all its restrictions, literal data descriptions and unresolved boundaries. It is not a claim that the paper's algorithm is correct or fully reproduced. Its source graph was recovered with implementation knowledge; it is not an independent source-first graph of the original paper.

The full current formal scope comprises the stored construction/resource/layout/gamma data; old row-local candidate maps and counterexamples; fixed seven-slot modular address arithmetic; register splicing and safety; symbolic bulk/boundary rotations; coefficient-function clean-branch and completion data; supplied preimage interfaces and constructed active-domain candidates; restricted transpose columns; and arbitrary-width indicator/register-exchange finite permutations. None of these local layers is omitted merely because the migration changes only two tactic endings.

## Interpretation safeguards

The canonical bulk window in the row-local candidate is exactly 2≤r≤2^n−3, with natural subtraction and the actual branch order documented in M14. It is not an arbitrary interval. Other generic classifier records accept arbitrary interval data and are a different object.

The indicator position is the literal sum 1+n+(n−ceil-log2 κ)+ceil-log2 κ. The equality to 1+2n requires width compatibility; the weaker inequalities needed by its local image proof hold without that simplification.

The source-wide active domain is padded cleanliness AND sparse slot <κ. Zero coefficient values do not delete active sparse-register slots. The row-local nonzero classifier is historical, not a source-domain replacement. The exact active restricted cleanup statement has an indispensable quantifier over that active domain: it does not prove a complete physical inverse on all rows, all padded-clean encodings, or all full-space columns.

The active symbolic boundary route retains the single-arccos angle and half-angle entries described in M7. The bundled edited excerpts/notes instead describe a doubled-arccos correction under the standard rotation convention. Preserve both as different data and an unresolved provenance/correction boundary. No correction is authorized by this addendum.

Labels, optional images, source citations, permission flags, resource expressions, and default Boolean proof-status fields are data. Equalities showing their stored values are true mathematical facts about records, but do not prove the referenced algorithm, external theorem, resource count or impossibility. The true Boolean gate statuses do not replace the explicit finite permutation arguments; those arguments in turn do not imply gate compilation, arbitrary-width Robin block extraction or finite-bit complexity.

## Original-paper coverage remains incomplete

The original archive source and its bibliography were unavailable at the prescribed local path. The following are intended source families, not authenticated raw-source coverage:

| Family | Existing locally readable input | Disposition for an original-paper proof graph |
| --- | --- | --- |
| Banded sparse access and cited prior PDE primitive | edited address display; citation transcript | SOURCE_GAP for original proof, circuit and resource derivation |
| Indicator | edited input/output display | display available as edited input; source construction/proof/cost remains SOURCE_GAP |
| Bulk sparse amplitude and N_D | local description/contracts | SOURCE_GAP for raw amplitude proof and analytic source conditions |
| Boundary rotation/ghost points | edited doubled-angle statement; local single-angle account | SOURCE_GAP for literal original wording, ghost-point steps, convention and independent repair |
| Piecewise-polynomial coefficient oracle | local citation to an external theorem | SOURCE_GAP for cited theorem/proof and full source assumptions |
| Sparse-register preparation | label/transcript data | SOURCE_GAP for source construction and cost proof |
| One-term theorem/gamma stages/figure | edited tuple, gamma3 display and local stage descriptions | SOURCE_GAP for complete raw proof, gamma1/gamma2, original gamma3 indices, circuit figure/caption and resource accounting |
| OneD/MultiD/QSVT/BE definition | contextual metadata and separate composition audit | EXCLUDED from this local module's advertised theorem closure; SOURCE_GAP if someone later claims exhaustive paper coverage |

The source's alternative constructions, complete AND/OR topology, cited results and substantive proof paragraphs cannot be exhaustively disposed from the current edited excerpts alone. There is no invented universal paper-completion claim in this packet.

## Reuse and next review

The already existing finite corrected Figure4 and other fixed-N8 routes, and the separate Hamiltonian composition/phase audit, are relevant provenance and reusable candidates. They are not mathematical consequences newly supplied by this local module, and are not silently merged into its target.

A distinct reconstruction should receive ONLY the separately routed formal-context packet. A subsequent distinct comparison may use this frozen local source and the actual reconstruction. Any original-paper-fidelity or correction finding must obtain the authentic raw source and the required independent review before it is accepted. Current compilation, complete type/axiom inventory and proof-input equality remain separate obligations.

