# GHL c42 source-recovery handoff

Author-side recovery and exact-source transport only; no decoder/reviewer verdict or publication record.

- `natural/`: preexisting M0–M14 natural lesson, explicitly labelled edited excerpts/notes, and a new recovery addendum. Author/comparison input only.
- `formal-only/`: separate complete 8474-line comment-masked target plus five narrow provider files. Preserve literal String data; not paper-identity-blind. Do not give sibling natural/author material to the blind decoder.
- `author/`: complete lexical declaration/field inventory, source-string-role list, raw-context pins, bounded review/source-gap plan, and transport checks.

Read `author/HANDOFF.md` for the bounded next objective and `author/context-seal.json` for raw pins. This is not an admission registry, completion ledger, novel paper proof, compiler certificate, or independent source audit.
