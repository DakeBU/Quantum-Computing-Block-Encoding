"""Read-only exact v3 delta/binding audit; no admission, Git, Lean or compiler."""
import sys
sys.dont_write_bytecode=True
import json, hashlib, zipfile
from pathlib import Path
R,W=map(Path,sys.argv[1:3])
P=R/'reviews/publication/ghl-c44'
def h(b):return hashlib.sha256(b).hexdigest()
def j(p):return json.loads(p.read_text(encoding='utf-8'))
def pin(p,logical):return {'path':logical,'bytes':p.stat().st_size,'sha256':h(p.read_bytes())}
def diff(a,b,path=''):
    if type(a)!=type(b):return [{'path':path,'old':a,'new':b}]
    if isinstance(a,dict):
        out=[]
        for k in sorted(set(a)|set(b)):
            out+=diff(a.get(k),b.get(k),path+'/'+k)
        return out
    if isinstance(a,list):
        if a==b:return []
        if len(a)==len(b):
            return [x for i,(u,v) in enumerate(zip(a,b)) for x in diff(u,v,path+'/'+str(i))]
    return [] if a==b else [{'path':path,'old':a,'new':b}]
c=j(P/'prospective-context-v3.json'); old=j(P/'prospective-context-v2.json')
g=j(P/'source-topology-v3-proposal.json'); gold=j(P/'source-topology-v2-proposal.json')
gc=j(R/c['record']['graph_contribution']['graph_context'])
gcold=j(P/'prospective-graph-context-v2.json')
decfile=P/'final-evidence/GHL2025-decoder-context-v3.json'
dec=j(decfile)
expected={'prospective-context-v3.json':'e9e8b3909753e1623089122f11c5d34c5ddaee90c8063d1ede584ab9b51cda30','source-topology-v3-proposal.json':'dd7b959b2f477295ea09ba12c5b61f856d355639554ff901c792cdfe8a0f327d','final-evidence/GHL2025-decoder-context-v3.json':'9d42f27e2955ea0e6c2ac6a92f11775ab5daed69890437a4bef55290ea323255','decoder-context-v3-final.zip':'3932c588e0068fc48b85b1a0676fe0af69f8f61d9c24583c98bbbf067be37d26'}
for name,digest in expected.items():assert h((P/name).read_bytes())==digest,name
checker=R/'website/scripts/check_research_publications.py'
assert h(checker.read_bytes())=='f8f6d7232376b5bc19a480b7e0ef549a5fafa8d66017e07482f7e6999962f8ad'
scope={'__name__':'binding_only_not_cli','__file__':str(checker)}
exec(checker.read_text(encoding='utf-8'),scope)
binding=scope['binding_digest'](R,c['record'])
assert binding==c['record']['binding_sha256']==dec['binding_sha256']
source=next(x for x in j(R/'website/research/sources.json')['sources'] if x['id']==c['source_row']['id'])
assert source==c['source_row']
assert h((R/c['record']['graph_contribution']['graph_context']).read_bytes())==c['record']['graph_contribution']['graph_context_sha256']
archives=[]
for name in ('topology-independent-v3.zip','decoder-context-v3-final.zip','source-review-phase4-requires-changes.zip'):
    with zipfile.ZipFile(P/name) as z:
        blobs={n:z.read(n) for n in z.namelist()}
        seal=json.loads(blobs['seal.json'])
        items=seal.get('artifacts',seal.get('sealed_outputs',seal.get('sealed_artifacts')))
        for x in items:
            member=x['path'].split('/')[-1]
            assert h(blobs[member])==x['sha256'] and len(blobs[member])==x['bytes']
        if name=='source-review-phase4-requires-changes.zip':
            for n,b in blobs.items():assert b==(W/'ghl-c44-source-review-phase4'/n).read_bytes()
        if name=='decoder-context-v3-final.zip':
            assert blobs['GHL2025-decoder-context-v3.json']==decfile.read_bytes()
            integrity=json.loads(blobs['integrity.json'])
        archives.append({'path':name,'sha256':h((P/name).read_bytes()),'members':{n:{'bytes':len(b),'sha256':h(b)} for n,b in blobs.items()},'sealed_bindings_match':True})
proofchecks=[]
for x in integrity['proof_inputs']:
    p=R/x['path']
    assert p.resolve().is_relative_to(R.resolve())
    observed=h(p.read_bytes())
    proofchecks.append({'path':x['path'],'sha256':observed,'match':observed==x['sha256']})
assert len(proofchecks)==len({x['path'] for x in proofchecks})==207
assert all(x['match'] for x in proofchecks)
original=[]
for a in integrity['archives']:
    p=R/a['path'];assert h(p.read_bytes())==a['sha256']
    with zipfile.ZipFile(p) as z:
        assert set(z.namelist())=={x['path'] for x in a['members']}
        for x in a['members']:
            b=z.read(x['path']);assert h(b)==x['sha256'] and len(b)==x['bytes']
            baseline=(W/'ghl-c42-source-recovery/formal-only'/x['path']) if a['role']=='formal' else (W/'ghl-c43-formal-decoder'/x['path'])
            assert b==baseline.read_bytes()
    original.append({'path':a['path'],'sha256':a['sha256'],'members':len(a['members']),'equals_original_frozen_bytes':True})
prior=[]
for name in ('ghl-c43-source-first','ghl-c43-source-review-phase2','ghl-c43-source-review-phase3','ghl-c44-source-review-phase4'):
    folder=W/name;seal=j(folder/'seal.json')
    for x in seal['sealed_artifacts']:
        p=W.parent/x['path'].removeprefix('workspace/')
        assert p.stat().st_size==x['bytes'] and h(p.read_bytes())==x['sha256']
    prior.append(pin(folder/'seal.json','workspace/hermite-export-work/'+name+'/seal.json'))
inputs=[pin(P/n,'repo/reviews/publication/ghl-c44/'+n) for n in expected]
inputs += [pin(R/c['record']['graph_contribution']['graph_context'],'repo/'+c['record']['graph_contribution']['graph_context']),pin(P/'topology-independent-v3.zip','repo/reviews/publication/ghl-c44/topology-independent-v3.zip'),pin(P/'source-review-phase4-requires-changes.zip','repo/reviews/publication/ghl-c44/source-review-phase4-requires-changes.zip')]
result={'schema':'independent-final-v3-static-exact-audit','input_pins':inputs,'context_delta':diff(old,c),'graph_delta':diff(gold,g),'graph_context_delta':diff(gcold,gc),'binding':binding,'selected_source_row_equal':True,'archives':archives,'original_archive_checks':original,'decoder_proof_inputs':proofchecks,'decoder_proof_count':207,'proof_count_distinction':'Decoder207 distinct raw paths=202 directory Lean+3root Lean+toolchain+manifest; original binding207 contributions=202directory Lean+4named raw+selected row. These are different 207s.','prior_seals':prior,'prior_artifacts_unchanged':True,'decoder_reuse':'Original8formal and4decoder archive members independently equal original frozen context; original reconstruction unchanged. Capsule14prior-output claim beyond original4 is recorded attestation only; other10 private outputs not read.','checker_mode':'binding_digest only,not check/validate_record/main','not_done':['Lean/native/compiler','Git/network','registry/production writes','unreleased private-file following','children']}
print(json.dumps(result,ensure_ascii=False))

