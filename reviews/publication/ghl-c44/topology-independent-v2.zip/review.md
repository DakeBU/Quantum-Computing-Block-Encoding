# Independent v2 LOCAL source-topology review

Verdict: **accept**, only for the bounded LOCAL source-topology proposal with SHA-256 `0f087c4e02ab3fd28112f2b63cb778ce23f77289c48d21ab1971c0d84dbc5442`.

Reviewer: `/root/ghl_topology_independent_c44`, distinct from the source-topology extractor and v2 proposer. This is a successor review, not an amendment of the sealed v1 requires-changes verdict. The old graph and all six old review artifacts remain byte-identical. Neither the parent request nor the proposal's repair descriptions were treated as acceptance evidence.

## F01 independently checked: resolved

The natural source M12 line 226 separates an early record constructor with four supplied premises from later constructors that supply them using an explicit candidate. The v2 E19 head is now `M12.conditional-record-consequences`, expressly conditional on post/image/clean/range premises and expressly not a proof that the candidate supplied them. E20 remains directed to `M12.constructed-record`, with the existing active-family, post, actual candidate-image/active and matrix/slice/splice evidence. The unequal-strength `OR.record-construction` entry is removed. These are now different conclusions, not two supposedly sufficient proofs of one unmatched head.

Backward tracing confirms E19 is not an ancestor of either the explicit constructed-record head or E21. No undischarged conditional record can be used to close the restricted-column result through the proposed edges. Thus the graph typing defect, not merely its warning text, is repaired.

## F02 independently checked: resolved as coverage with a retained gap

M12 line 224 mentions weaker intermediate range/image interfaces permitting the eighth encoded slot, but does not give each exact interface, complete guard set and source route. V2 does not infer a formal signature from the active case. It narrows `M12.candidate-image` explicitly to j in D and adds two distinct dispositions:

- `M12.encoded-image-interface` records that the wider interface is mentioned, without asserting active membership or uniqueness.
- `G.local-encoded-image-details` records the LOCAL interface-detail SOURCE_GAP, explicitly not an unseen formal-theorem failure or an external-paper obstruction.

The two new dispositions are named together by `coverage.wider_local_interface`; their lack of established proof edges is deliberate and accurate. Neither becomes an established ancestor of active membership, uniqueness, the constructed record or E21. This satisfies the gap alternative in F02. It resolves the omission/miscoverage finding; it does **not** discharge the weaker mathematical interface or certify any unseen signature. E16's retained caution about weaker <8 guards is only a caution, not an added route or a complete inferred guard contract.

## Minimality and new-risk assessment

Parsed comparison, independently checked against the whole unchanged natural source, found exactly three new nodes, one changed existing node claim, one changed existing edge head, removal of the unmatched OR, two added non-edge warnings, one added coverage field and revision/status/schema metadata. All 52 old nodes remain. The established edge ID set remains 21 entries, but edge content is not literally unchanged: E19's head changed. This is the precise reading of the companion proposal's `edge_set_unchanged` together with its `E19_head_changed` flag.

The repair is localized and proportionate. A different encoding could combine the wider-interface mention and its detail gap, so this is not a claim of mathematically unique minimum node count. The three new nodes have distinct roles: conditional consequence, mentioned wider interface, and missing exact interface detail. There is no new mathematical premise, implementation theorem, source correction or sufficient physical construction. No further required change was found.

All other node statements and all other established edge records are unchanged; the prospective analytic, function-oracle, full-block and compiled-resource dependency lists are unchanged. The remaining future boundary-source/correction OR retains complete AND tails and remains unproved. There are no dangling references among established node/edge records or duplicate node IDs. The new detail gap is not smuggled into an established closure route. The companion proposal's old-negative-review digest matches the old review seal; its source/Lean/target mutation flags are process declarations, not independent implementation evidence. No unseen Lean equality is certified here.

The whole two-document natural source was re-read through EOF in this successor turn, including tables, formulas, citation distinctions, register guards, phase/amplitude boundaries and resource caveats. The prior 84-region coverage ledger remains the lossless base; `coverage-delta.json` changes only the affected dispositions and records the unchanged root-backward checks. In particular E21, its complete AND tail and both active-domain quantifiers remain unchanged. The generic interval/canonical historical bulk distinction, zero-coefficient active slots, bit-width safeguards, finite permutations versus analytic unitarity, retained angle mismatch, unconstrained oracle completion and physical-cost gaps remain visible.

## Acceptance boundary

This acceptance says that the proposed v2 graph faithfully represents the bounded retrospective LOCAL natural recovery, including its explicit unresolved obligations. It does not assert authenticated original-paper coverage, completion of every mathematical construction, the weaker encoded-interface proof, full-space inverse/cleanup, normalized Robin block extraction, compiled resource correctness, source-to-formal equivalence, Lean 4.33 compatibility, publication/main admission, Proof Seal or Exposition Seal.

Failure class: NONE; no mathematical route is retired. Useful preserved material: active restricted-column spine, separate finite permutation arguments, typed data/target/gap distinctions and separate composition exclusions. No verified physical default route or cross-route comparator is selected. No process-memory or other reviewer input was used. Only the explicitly added two proposal files were newly admitted; no compiler, native experiment, network, Git, production/registry write or children were used. All outputs are NEW and limited to this v2 review directory. Stop after sealing.
