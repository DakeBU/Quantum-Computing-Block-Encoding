# Independent formal reconstruction of GHL2025

Status: independent reading complete; not a source-agreement verdict, compiler certificate, publication wrapper, or proof seal.

Decoder identity: /root/ghl_formal_decoder_c43. Run identity: ghl-c43-formal-decoder-20261017-independent-read. Direction fingerprint: whole-legacy-formal-semantics-independent-of-local-source. Expected information gain: expose hidden hypotheses and annotation/denotation gaps before comparison with any natural source.

## 1. Scope, notation, and evidence level

The mathematical input consists exclusively of the eight files pinned in input-pins.json: two context files and the complete six-file comment-masked formal closure. The target is QuantumBlockEncoding/GHL2025.lean, lines 1–8474. All six Lean files were read through EOF, including private proofs, fields, defaults, instances, imports, namespace commands, and simp attributes. Only blank/comment-mask whitespace was suppressed in several displayed chunks; original line numbers were retained. A truncated display in the 1001–2000 chunk was recovered by reading lines 1519–1538 separately. No supplied mathematical classification or earlier reconstruction was consulted.

Hereafter G:L means target-module line L; C, R, Q, B, and S mean respectively Core, Resources, Circuit, BlockEncoding, and CircuitSemantics, each under FORMAL_INPUT/QuantumBlockEncoding. FORMAL_INPUT is the logical relative root ../ghl-c42-source-recovery/formal-only. There are no physical machine paths in this packet.

This is a mathematical reading of the declarations and proof text, not evidence that this snapshot elaborates under the pinned toolchain. In particular native_decide occurring in the text was read, never executed. Strings retaining paper titles, equations, source claims, previous-process labels, or alleged proof status remain formal data; none was used as independent evidence about a paper or repository state.

Appendix A gives the independently extracted explicit lexical declaration/line map. Appendix B reproduces record/inductive carriers with exact field/default/constructor lines so that grouping below is lossless with respect to hidden fields. Neither appendix claims an elaborated census of generated constructors, recursors, projections, instances, private kernel names, or dependencies.

Write N=2^n, l=clog2(kappa), a=n-l (natural-number subtraction), m=clog2(n)+clog2(functionPieces)+3, and T=m+1+l+a+n+1. All natural subtractions everywhere in this packet truncate at zero. Definitions are total on their written carriers unless a separate theorem explicitly adds bounds. Parameter record OneTermRobinParameters has four unrestricted Nat fields; it carries no hypotheses n>=3, kappa=7, l<=n, functionPieces>0, or positivity of normalizers.

## 2. Provider substrate: what the words “matrix”, “circuit”, and “verified” mean

C:15–39 defines a matrix as Fin rows -> Fin cols -> alpha. Equality can be extensional pointwise equality; matrix multiplication is the left fold of A(i,k)*B(k,j) over List.finRange mid starting at zero. These definitions request only numeral/add/multiply operations, not field or inner-product laws. Identity is Kronecker delta. gridSize n=2^n; clog2 m=0 for m<=1 and log2(m-1)+1 otherwise. The proof at C:64–100 establishes the predecessor-power logarithm identity and clog2(2^n)=n, including n=0.

Stencil is derivativeOrder, accuracyOrder, leftRadius, rightRadius; its width is left+right+1, with no correctness promise. BulkWindow merely stores lower and upper; paperBoundaryLines=lower+N-upper. BoundaryKind is a four-constructor tag. StencilEntry is Int offset plus symbolic coefficient.

Coeff (C:148–234) is a free expression tree built from rational constants, String symbols, addition, multiplication, and negation; subtraction and division by a Nat are syntactic constructions, the latter multiplication by the rational 1/n. It is not a real/complex field. In particular a symbol named “A1*dx” is one atomic variable, not a proved product; “N_D_inv”, “N_f_inv”, “sqrt(kappa)”, and “kappa” are independent String symbols. evalWith chooses any String -> Rat environment and recursively evaluates. The evaluation lemmas establish this recursive interpretation; Coeff equality itself remains tree equality, not equality modulo ring identities. There is no supplied conjugation, square root, cosine, arccosine, operator norm, Born probability, or asymptotic semantics.

Resource (R:21–91) has five Nat fields, all default zero: oneQubit,cnot,oracleCalls,pureAncilla,depth. gates sums the first three. Sequential add sums all five, including ancilla counts; parallel sums operation counts but takes max ancillas and max depth; scale multiplies all fields. Thus these are the written accounting conventions, not a theorem of optimal ancilla reuse or legal scheduling. ofCounts(x,y,z) sets oneQubit=x,cnot=y,pureAncilla=z,oracleCalls=0,depth=x+y. ofCountsWithDepth accepts all five independently.

CostExpr is syntax for Nat, named atom, add, mul, log, and a String-indexed sum. AsymptoticResource stores two such expressions, without evaluation, Big-O relation, constants, or inequalities. At R:138–150, for arbitrary Nat n,l, the exact resource definitions are:
- bandedSparseAccessResource: oneQubit=(2^l+1)*(32*n-48), cnot=25*2^l*n-36*2^l+32*n-48, pureAncilla=n-1;
- sparseAmplitudeOracleResource: oneQubit=cnot=2^l, pureAncilla=0;
- indicatorResource: oneQubit=16*n+34, cnot=12*n-4, pureAncilla=n-1.
These use Nat arithmetic and ofCounts depth, with no semantic implementation theorem.

Gate (Q:13–21) is syntax for named one-qubit gates, labelled Y/Z rotations, CNOT, swap, recursively controlled gate with List(Nat x Bool) controls, and named oracle call. There is no wire-validity/distinctness rule or canonical matrix interpretation. Q:32–41 charges one one-qubit operation per named/rotation gate, one CNOT, three CNOTs per swap tag, one oracle/depth for an oracle call, and for controls an added (16*c,12*c,c) ofCounts cost on top of the body's resource. A circuit is a list; the layered variants do not prove disjoint wires. Circuit and layer resource folds differ exactly as above.

B:14–81 defines register/layout/cost records and a lexicographic strict cost preference by gateCount, then depth, then auxiliaryQubits, then oracleCalls; noWorseThan is equality or that strict relation. Layout auxiliaryQubits=signalQubits+pureAncillas. BlockEncodingSpec stores arbitrary matrix, normalizer,error,layout,circuit,resource without a correctness constraint or equality of its resource with circuit.resource.

At B:90–182, QueryOperatorTarget's source/semanticContract/freeParameters (default []) are metadata. OperatorBlockEncodingCandidate stores a full square matrix of dimension 2^(systemQubits+auxiliaryQubits), a layout/circuit, schedule default [], independent resource, layoutMatches only for auxiliary width, and arbitrary propositions isUnitary and blockContainsTarget. It does not define either proposition as a matrix identity. VerifiedOperatorBlockEncoding supplies proofs of those chosen propositions. Approximate candidates similarly choose epsilon and an arbitrary approximationBound proposition; verification proves it, without a norm. asZeroErrorApprox sets epsilon=0 and reuses blockContainsTarget as that proposition. Generic VerifiedBlockEncoding (B:220–241) likewise packages arbitrary unitary/block/resource propositions and proofs; its three theorems project those proofs. Adaptive policy/search-phase constructors are configuration data only. ConstructionClaim stores five descriptive Strings and a symbolic resource expression.

S:25–59 adds SemanticObligation(description,source,proved=false). GateMatrix has a gate label, a matrix, and that annotation; it has no proof that its matrix is the label's canonical semantics or unitary. gateMatricesMatchCircuit checks only the exact ordered gate labels. evalGateMatrices folds by left multiplication from identity: the ordered list [M1,...,Mt] denotes Mt*...*M1, with the concrete fold's parentheses. For arbitrary alpha there is not even an assumed associativity law.

S:71–377 develops genuine rational-evaluation finite-sum facts: evaluation commutes with the multiplication fold; if all evaluated paths vanish then the product entry vanishes; if all but a designated path vanish it equals that path; if all but two distinct paths vanish it equals their sum. The six private helpers prove zero-fold, unique/two-term summation, finite-range nodup and injective-map nodup, and extraction of an initial summand. The proofs proceed by finite-list induction, membership and nodup splits, and rational addition identities. The identity-right result and S:389 singleton gate-list result are evaluated equalities, not syntactic Coeff ring equalities. cast_square_apply preserves finite index values through dimension equality.

CircuitMatrixSemantics (S:404–424) genuinely proves that labels match and matrix equals the gate-matrix fold pointwise. It does not prove gate semantics or unitarity. PreparedCircuitEntryTarget stores two matrices, indices, entry values, and proofs that each value is the named entry; source/composition annotations remain metadata. Its theorem translates equality of stored entries into equality of those matrix entries; it supplies neither equality unconditionally.

BlockExtractionTarget (S:502) stores an arbitrary unitaryMatrix (even rectangular in rows/cols), targetMatrix, normalizer, signalIndex, blockMatrix and two annotations. There is no automatic link between the matrices. The branch contribution target stores a selected contribution and sum together with defining equalities. selectedBranchStatement is already a stored equality; projectionSummationStatement is equivalent to backendExpansionStatement by substitution, not independently proved. The two implication theorems transport a supplied summation/expansion premise.

CircuitBlockEncodingClaim and FiniteBlockCompositionContract provide dimension/target matching equalities but leave circuitUnitary, lcuComposition, projection, normalized equality and extraction as annotations. In contrast, signalSystemBlockProjection (S:695–772) actually extracts the entry at (signalIndex*rows+i, signalIndex*cols+j), proving these indices lie in range. Signal is the high-order factor, system the low-order factor. The semantics.blockExtractionTarget constructor (S:786–812) casts the evaluated matrix using a dimension equality and takes this submatrix; its projection/correctness annotations default false. It does not prove the block equals target/normalizer. totalCircuitQubits adds system and signal widths, not the pure-workspace layout model.

## 3. Target-level records and exact cost/register statements (G:18–854)

isBulkRow tests K1<=i<=K2. isBoundaryRow tests j<K1 or K2<j and ignores its gridSize argument: it does not restrict j to a physical grid. deviatingIndices=K1+gridSize-K2; the n=3 example is 5. For ordered inclusive endpoints in [0,N), this expression is one larger than the cardinality of the strict outside-boundary set; no cardinality identity is asserted. RobinBoundaryRotationSet.expectedCount multiplies this expression by kappa. Neither the recorded angles nor their number are checked against that expectedCount.

defaultRobinRegisterPartition stores widths, not indices, in the order mf, indicator, sparse, OD pure, system, ancilla:
(m,1,l,a,n,1).
totalPureAncillas=a+1. The layout separately advertises system=n (proved via clog2_gridSize), signal=clog2(n)+clog2(functionPieces)+l+4=m+l+1, pureAncillas=2*n. oneTermRobinTotalQubits=T comes from the partition, not layout.system+layout.signal+layout.pure. effectiveRobinSignalQubits=T-clog2(N). G:789–845 proves the advertised signal/pure-ancilla fields coincide among theoremData/layout/resource and
effective signal = advertised signal + a + 1.
That equation is valid with truncated subtraction even without l<=n; it is not a proof that the visible workspace is cleaned or excluded from postselection. The partition's a+1 pure-width count is not identified with 2*n.

The seven-label active circuit is U_indic; O_DT^S; Ry_boundary; O_D^BS; O_f; swap 0 0; (O_D^BS)^†. The distinct ten-label theorem-facing list prepends H_W^(kappa), uses O_DT^BS rather than O_D^BS at its fifth position, inserts U_indic^dagger before O_f, and ends with (O_D^BS)^dagger and (H_W^(kappa))^dagger. Exact spellings, including Unicode † versus ASCII dagger, matter to label matching. G:205 and 227 prove the two lists separately by definition, not their equivalence or a simulation relation.

oneTermRobinNormalizer is the expression (N_D*N_f)*symbol(kappa); G:274 proves its evaluation is env(N_D)*env(N_f)*env(kappa). Nothing equates env(kappa) with the Nat parameter p.kappa or assumes nonzero/positive values. oneTermRobinSpec accepts any N x N Coeff matrix mat, stores that normalizer, error=rat 0, the active circuit, advertised layout and resource.

oneTermRobinResource p is ofCounts(polynomialDegreeCost*n*clog2(n)+kappa*n,0,2*n). Its pure-ancilla theorem and spec-ancilla theorem are field identities. Its gates and depth equal the stored first count. In contrast, G:269 proves the syntactic seven-tag circuit resource is (oneQubit=0,cnot=3,oracleCalls=6,pureAncilla=0,depth=9). The two resource records are not proved equal or related by an implementation bound.

The one-term symbolic resource has gates=(sum_g(Q_g))*n*log(n)+kappa*n and pureAncilla=2*n. Its “precise” variant replaces kappa*n by kappa*(K1+2^n-K2)*n. The one-dimensional record's gate expression is atom(sum_g(Q_v_g)*n*log(n)) + sum_(k<eta) atom(kappa_k*n+sum_g(Q_fkg)*n*log(n)) + atom(n_xi*log(n_xi)); pureAncilla=2*n+2. The multidimensional record's gates are atom(M*Q_PET*G*Q*(d*n*log(n)+n_s*log(n_s))) + atom(n_xi*log(n_xi)) + atom(d*eta*kappa*n); pureAncilla is the single atom “O(n)”. Operators H=S1 tensor x_xi+S2 tensor I_xi and the multidimensional I tensor p_s tensor I_xi+... appear only in ConstructionClaim Strings, as do their O(kappa*||H||_max) normalizations and signal counts. The latter strings are respectively:
clog2(n_xi)+clog2(n)+clog2(G)+clog2(kappa)+clog2(eta)+7;
d*clog2(n)+clog2(n_s)+clog2(n_xi)+clog2(G)+clog2(kappa)+clog2(eta)+clog2(M)+4*d+5.
These are not tensor/operator constructions or complexity theorems.

RobinGamma1/2/3 and RobinWavefunctionDecomposition store Nat labels/widths and Coeff normalizers. Defaults use K1=2,K2=N-3; Gamma1 boundary normalizer=N_D*sqrt(kappa), bulk=sqrt(kappa), mf=m; Gamma2 normalizer=N_D*sqrt(kappa) and hasOrthogonalRemainder=true; Gamma3 normalizer=N_D*N_f*kappa, that Boolean=true, pureAncillaQubits=a+1. No vector, state, decomposition equation, normalization, orthogonality or amplitudes are fields of these records.

RobinCircuitSkeleton supplies Strings for all named steps, a merge-frame label and widths; there is no semantic equation for “merge”. RobinProofObligations defaults all ten records false: indicator, sparse amplitude, banded access, function oracle, boundary rotation, circuit unitarity, block extraction, resource bound, cleanup, ghost elimination. OneTermRobinTheoremData defaults alpha as above, signal=m+l+1, error=0, pure=2*n, gatesBound a Big-O String, obligations={}. RobinBoundaryRotationAngle stores row,sparseIndex,matrixEntry,arccosArgument without a relation between the last two. The set stores bounds,kappa,normalizer,angles but no validity proof.

DerivativeOracleContract(n) stores stencil,bandwidth,matrix,sparseCorrect annotation, and the genuine equality bandwidth=stencil.width. FunctionOracleContract(n) stores functionPieces,normalizerBound and amplitudeCorrect annotation, but no function or circuit field. derivativeOracleResource uses bandedSparseAccessResource n stencil.leftRadius, not clog2(width); its ancilla theorem is n-1.

## 4. Sparse addresses and input domains (G:869–3585)

The row-local map R(n,s,i) is:
- for 2<=i<=N-3, i-2+s if s<5, else i;
- row 0: s if s<3, else 0;
- row 1: s if s<4, else 1;
- row N-2: N-4+s if s<4, else N-2;
- row N-1: N-3+s if s<3, else N-1;
- otherwise i.
This is an ordered conditional definition; small n can make cases overlap or bulk empty, and the order is part of semantics. BranchValid uses the same row cases and respective bounds 5,3,4,4,3, otherwise false. It is not a test of the coefficient's evaluated nonzeroness. In particular row-0 slots 0 and 3 collide at address 0 although only slot 0 is valid (G:1314).

G:1329 proves R<N under n>=2,i<N for any Nat s. G:1396–1491 gives row-specific equations; right-boundary equations require n>=3. The reverse-index function is target for rows 0/1, target+2-row in bulk, target-(N-4) on row N-2, target-(N-3) on row N-1, target otherwise. G:1502–1864 proves, for n>=3,s<8,i<N, that mapping at the reverse index from R(n,s,i) returns i, and that reverse index is <8. This is an address roundtrip, not recovery of the original sparse slot in collision cases. The check at G:1875 is an explicit finite Boolean double loop, with no universal acceptance theorem attached to arbitrary n,sparseBound.

The global cyclic map is A_s(i)=(offset_s+i) mod N. Offsets s=0,...,6 are [N-2,N-1,0,1,2,N-3,3]; every s>=7 has offset 0. invSlot maps [0,1,2,3,4,5,6] to [4,3,2,1,0,6,5], and every s>=7 to 2. G:919 proves A_s(i)<N for all n,s,i. invSlot<8 is unconditional; invSlot<7, involutivity and injectivity on slots require s<7 (and t<7 where relevant). G:1009 proves A_invSlot(s)(A_s(i))=i for n>=3,s<8,i<N, including encoded slot 7, even though invSlot(7)=2 does not invert the slot label. The two private Nat lemmas at 1100 and 1115 justify modular cancellation and reduction of an offset sum below 2*N.

For n>=3 and slots s,t<7, offset bounds and finite case splits show a zero sum modulo N uniquely determines t=invSlot(s) (1183), hence a return to i uniquely determines that inverse slot (1228), and A_s(i)=A_t(i) forces s=t (1261). The exact <7 restriction excludes duplicate offset zero at slot 7. Address composition is always the sum of offsets modulo N (1149).

For a basis integer j, paperRegisters (1902) extracts:
OD=(j >> (1+n)) & (2^n-1);
padded=OD & (2^a-1);
sparse=(OD >> a) & (2^l-1);
row=(j >> 1) & (2^n-1).
Thus within the extracted OD value, padded bits are lower than sparse bits. Bounds on row,OD,sparse follow from masks; sparse<2^l, not sparse<kappa. The recorded contract's width compatibility is only a false annotation; a+l=n is an arithmetic consequence only under l<=n. The rotation-register extractors later read l sparse bits directly from the whole basis integer at position 1+n+a, whereas paperRegisters first crops an n-bit OD value. These agree in the intended width regime l<=n; the total definitions outside that regime must not be silently identified. The n-bit blocks used by access/splice/SWAP remain n bits even if a+l exceeds n.

paperAddress uses the global cyclic map on extracted sparse,row. rowDependentPaperAddress instead uses R. Their associated image functions replace the n-bit OD register, preserving low (1+n) bits and the high tail:
I(j) = j mod L + address(j)*L + floor(j/H)*H,
L=2^(1+n), H=2^(1+2*n).
They do not overwrite the system row. This differs from the legacy bandedSparseAccessMatrix at G:4695, which uses R and overwrites the system block.

G:2062 identifies mask-extraction with shifted quotient modulo a power of two. G:2076 proves 1+2*n<=T without width guards. G:2087–2396 proves, under address<2^n where written, the low block stays below H, extracted OD equals address, total finite index stays <2^T, high tail is preserved, and Boolean NoSpill is true. Low-prefix and row preservation do not require that address premise. The range lemma at 2004 retains a binder 2<=n but its body uses the unconditional modulo bound; this binder is unused in that proof. ImageFin takes a genuine address-bound proof and constructs a Fin 2^T. Its value is exactly I(j), without modulo reduction to hide an out-of-range image.

CleanInput means padded=0. SparseIndexInKappa means sparse<kappa. GlobalSlotSource is their conjunction. ValidSparseBranch means the row-local BranchValid result; ValidCleanSource is clean AND row-local-valid, with no kappa guard. UnusedSparseBranch is clean AND NOT row-local-valid, also with no kappa guard. These definitions are not interchangeable. The disjoint clean-domain split is genuinely proved at 2632 and 2657. GlobalSource includes zero-amplitude/row-local-unused slots when their global label is <kappa. It rejects encoded sparse=7 when kappa=7. G:2461 and 2493 use kappa=7 (plus n>=3 for address injectivity) to transport global slot injectivity to extracted slots.

The image-rule / unused-branch / full-clean-domain contracts (2680–3039) store computed flags, images, functions of Nat to records, Options and annotation records. proposedImageIndex is none; all image-specified/finite/injective/agreement/cleanup/unitary annotations in their constructors are false. Their theorems project these values, propagate the unused predicate, and combine the proved clean-domain partition with the still-false annotation. They do not formalize extension existence or its negation. The concrete (n,kappa,functionPieces,polynomialDegreeCost)=(3,7,1,1) collision statements concern rowDependentPaperImage at inputs 0 and 48; global I separates those inputs.

The SourceDecision, ZeroInclusionSourceContract, PriorPDESourceContract and citation-chain definitions at 3049–3341 likewise contain Strings/Options/Booleans, not propositions about external texts. The first has all three decision Booleans false; the zero-inclusion record sets inclusion=true while its three Options are none and closure/search flags false; the prior-PDE record stores the oracle equation and a decomposition String but no reversible image rule, and its resource annotation is false. The associated “blocks”, “keeps”, “guard”, and “unproved” theorems are literal record equalities. Neither their phrasing nor the cited titles establish what any paper does or does not prove.

PaperColumnContract (3366–3514) computes clean flag,image,extracted image registers and Boolean safety checks, inheriting four false annotations from the default paper contract. The actual row-preserved theorem is unconditional; address-written/range/no-spill and their conjunction use address<2^n. This positive safety evidence is separate from the annotation values.

paperMatrix(i,j)=rat 1 if i=I(j), else rat 0; paperDaggerMatrix(i,j)=rat 1 if j=I(i), else rat 0. G:3531/3567 unfold these; 3544/3579 prove selected finite image entries equal 1 under the address bound. The second is the literal transpose of the first, not an independently justified inverse. As mathematical functions the full matrices are specified even on dirty/padded or out-of-kappa columns. An off-domain value is not automatically a unitary extension.

## 5. Coefficients, rotations, and the function matrix (G:3604–5391)

For n large enough that the five row categories are disjoint, the row-local stencil coefficients in increasing local-slot order are:
- bulk: (-1/12,4/3,-5/2,4/3,-1/12);
- row 0: (-5/2+(7/3)*A,8/3,-1/6);
- row 1: (4/3-(1/6)*A,-31/12,4/3,-1/12);
- row N-2: (-1/12,4/3,-31/12,4/3+(1/6)*B);
- row N-1: (-1/6,8/3,-5/2-(7/3)*B),
where A and B denote atomic symbols “A1*dx”,“B1*dx”. Remaining slots/rows give rational zero. The definition uses the same ordered tests as the row-local address function. There is no dx^-2 factor in these definitions, no general derivativeOrder parameter, and no ghost-point-elimination proof.

robinGlobalSparseAmplitudeValue uses the same bulk/right-boundary lists but moves row 0's three entries to slots 2,3,4, and row 1's four to slots 1,2,3,4; all other slots give zero. These align those left rows to global offsets. G:3707 and 3719 prove the n=3 row-0 slot-2 expression and its syntactic inequality with the row-local slot-2 value. Such inequality is not a claim of unequal rational evaluations for every environment.

DerivativeNormalizerNDContract constructs coefficient=global coefficient D, normalizerND=symbol(N_D), normalizedCoefficient=D*symbol(N_D_inv), and a String “D_j^(s) / N_D”. Seven obligation records (nonzero,division,bound,absolute square,sqrt complement,arccos,2x2 unitary) are false. SourceBound only repackages coefficient,normalizer and the String “|D_j^(s)| <= N_D”. Projection theorems at 3808–3886 establish these exact expressions and false flags, not inequalities.

indicatorOracleMatrix acts by XOR of the indicator bit when the extracted row is in [2,N-3]. Its GateMatrix and identical-matrix dagger tag set the unitary annotation true. The genuine arbitrary-width permutation evidence appears later, not inside this Boolean field.

The unused sparseAmplitudeOracleDTMatrix (3965) is a diagonal helper: it is identity on indicator=0 and row-local coefficient on indicator=1. The actual O_DT^S GateMatrix uses sparseAmplitudeOracleDTRotationMatrix (4231). For its input column j, if indicator=0 it is identity; otherwise it preserves all non-ancilla bits and acts on the least significant ancilla bit with the two-by-two matrix, rows/columns ordered (0,1):
[c, -s; s, c].
Here c,s are the independent symbols odts_cos_half_row_sparse and odts_sin_half_row_sparse, not evaluated trigonometric functions. Its two register constructors extract ancilla=j&1, indicator, row,sparse and nonAncilla=j>>1. This acts according to the input indicator bit; only after a clean initially-zero indicator and the preceding indicator map may that bit be interpreted as bulk versus boundary.

SparseAmplitudeOracleDTCoefficientNormalizerContract records c as the ket-zero entry and s as ket-one, with formula Strings D/N_D and sqrt(1-|D|^2/N_D^2). Those relations and unitarity are false annotations. Its normalized coefficient is the global D*N_D_inv. ProofRoute repackages these fields and shares ND division/bound/abs-square/sqrt obligations. All its theorems prove projection/shared-record equalities. It does not assume or derive c=D/N_D or c^2+s^2=1 in evalWith.

The boundary rotation (4557) is identity on input indicator=1; on indicator=0 it preserves non-ancilla bits and uses the same signed two-by-two pattern with independent symbols boundary_cos_half_row_sparse,boundary_sin_half_row_sparse. BoundaryRotationAngleNormalizerContract stores the global coefficient, N_D, theta=arccos(D/N_D), and half-angle formula Strings sqrt((1+D/N_D)/2),sqrt((1-D/N_D)/2). Its control/arccos/half-angle/unitarity records are false. ProofRoute sets arccosArgument=D*N_D_inv and reuses ND records, adding a false half-angle record. G:4483–4540 proves all of this sharing, including agreement of the global coefficient across both routes. G:4610/4642 explicitly combines the sharing equalities with nineteen false flags. This is not a mathematical contradiction: a metadata flag is not the proposition whose English description it carries. No real-domain bound, square-root identity, rational-environment restriction, or unitary proof is furnished.

oneTermRobinGate_O_D_BS uses paperMatrix, not the system-overwriting legacy helper. The n=3 column-8 discriminator (4748) has I(8)=40, active entries (40,8)=1,(4,8)=0, while legacy helper(4,8)=1. At 4770/4796, inputs 0 and 48 have row0,sparse0/3; row-local addresses both 0 but global addresses 6 and 1 and global images 96 and 16. G:4821 proves both inputs are GlobalSlotSource but input 48 fails ValidCleanSource; G:4836 rejects input 112 (encoded slot7) from GlobalSlotSource. Every listed O_D_BS unitary flag remains false.

robinFunctionValue(n,i)=symbol(f_n_i), independent for each grid label, without a polynomial, partition, evaluator, smoothness, or normalization hypothesis. Its normalized expression is f_n_i*N_f_inv. functionOraclePaperRegisters extracts the high m-bit mf workspace starting at indicatorPosition+1, the system row, nonMFValue formed by clearing those bits, and cleanWorkspace=(mfValue==0). PaperImage records the cleared basis index, original system label, workspace=0, normalized clean amplitude, an orthogonal-component String, a computed systemPreserved Bool and an input-clean Bool. Its five annotations are false. The field-projection theorems at 4977–5012 identify stored data; they do not prove the systemPreserved field true.

The external-amplitude-source and amplitude-proof-route records (5022–5275) store N_f, citation/formula Strings and reused annotations. Nine external status flags and seven route annotations are false; the theorems show equality/sharing and these values, not the cited amplitude theorem. Nonzero N_f and interpreting N_f_inv as an inverse remain absent as logical facts.

functionOraclePaperMatrix (5305) has actual entry content:
- if the input mf workspace is clean, the cleared-basis output has f_n_row*N_f_inv;
- any other output with clean mf workspace has zero;
- every remaining clean-input output, and every output for a dirty input, is the free symbol orth_f_entry_n_system_row_col.
The three theorems at 5320/5330/5340 prove precisely these branches, under clean/dirty and index conditions. The free output symbols are not constrained to preserve the system or other registers, be mutually orthogonal, or complete a unitary. They are an entry skeleton rather than a vector named by the orthogonal-component String. oneTermRobinGate_O_f uses this matrix. The separate functionOracleMatrix at 5365 is only the diagonal unnormalized f helper, not that GateMatrix's matrix.

## 6. SWAP, indicator, and exact restricted cleanup (G:5410–8474)

SWAP's actual matrix exchanges the two adjacent n-bit blocks starting at bits 1 and 1+n. Given x=block1(j),y=block2(j),d=x XOR y,
W(j)=j XOR (d<<1) XOR (d<<(1+n)).
Bit 0 and bits above the two blocks are unaffected. This matrix is attached to the syntactic tag Gate.swap 0 0, whose general tag cost is only three CNOTs. The label matcher imposes no relation between that tag's two zero wire numbers and this n-bit-register matrix. The module does not synthesize this block swap into n primitive swaps or relate its matrix cost to the advertised cost.

G:5855–5902 proves shifted masks do not affect lower bits; G:5908–5965 proves d<2^n, d>>n=0, its shifted overlap mask is zero, and general shifted values stay below total width. G:5972–6071 proves finite range and the two exchanged-block equations; the XOR difference is preserved. By XOR cancellation W(W(j))=j for every Nat j (6091), hence injectivity on Nat and bijectivity on Fin 2^T. The row/column existence/uniqueness results establish exactly one rational-one entry in every row and column; combined with the defining 0/1 entries this is genuine permutation-matrix content (6194), for all p without n>=3 or kappa=7. It is stronger than a Boolean annotation, although no complex matrix adjoint theorem is defined.

Similarly the final indicator family is arbitrary-width, not merely n=1/n=3. Its indicator position b=1+n+a+l satisfies 1+n<=b<T. Toggling bit b leaves the system row and bulk predicate unchanged. XOR cancellation proves U(U(j))=j for all Nat j (8304). Range on Fin, injectivity, bijectivity, row/column one-entry existence/uniqueness and the 0/1 definition establish its permutation-matrix semantics at 8452. Earlier n=1 and n=3 native_decide declarations are concrete finite special cases, not the basis for the general proof. The dagger uses the same matrix and G:8319 combines matrix equality with the all-Nat involution. These are exact phase-free permutations; there is no global-phase quotient or relative-phase relaxation.

The actual dagger O_D_BS uses paperDaggerMatrix, whereas bandedSparseAccessDaggerMatrix at 5483 is the transpose of the unused system-overwriting helper. G:5515 proves the selected transpose entry is 1. G:5534's post-SWAP entry lemma assumes both post=W(I(source)) and post=I(pre); the proof of the entry only needs the second equality. It does not produce pre or justify inverse behavior. BandedSparseAccessPostSwapCleanup (5555) carries these two equalities, pre clean/address bound, the selected dagger entry and register-safety equalities; it does not carry an equation for the full dagger column or all ancillas=zero. Its of_preimage constructor derives all safety fields from exactly those premises. G:5626 and 5660 prove forward/transpose entry safety, preserving row, writing address, no spill, and (for GlobalSlotSource) clean plus sparse<kappa.

G:5706 lists the seven actual GateMatrices in active circuit order. G:5722 and 5738 prove exact label matching; G:5757 proves unitary annotations [true,false,false,false,false,true,false]. These do not prove their product is unitary or extracts the arbitrary target mat. No actual whole-circuit CircuitMatrixSemantics instance or block projection/equality for this seven-matrix list is constructed later in the supplied target.

After access and SWAP, G:6221/6238 shows the post row equals the global address and the post OD equals the original row. Range is preserved under an address bound. splice(j,v) replaces OD by v using the same L,H formula. G:6291–6569 proves its low-prefix/row/high-tail preservation, OD extraction, finite-range safety, replacement-over-replacement identity (given first value in range), and splice(j,OD(j))=j. cleanOD(s)=s<<a; G:6577 proves padded bits zero, G:6586 gives cleanOD<2^n from l<=n,s<2^l, and 6601 recovers sparse s. G:6621 proves OD=cleanOD(extracted sparse) for a clean input under l<=n.

G:6695 proves full basis-index injectivity of I on GlobalSlotSource with guards n>=3,kappa=7,l=3 and finite j1,j2. The proof first recovers low prefix and high tail from equal images, then row and address, uses distinct offsets for sparse-slot equality, and uses cleanliness/width to reconstruct OD and the original index. Both GlobalSlotSource premises matter: it is not all-space or all encoded-slot injectivity. l=3 is a redundant arithmetic consequence of kappa=7 but is nevertheless an explicit binder in the written theorem and downstream family.

Define P(source)=W(I(source)) and
C(source)=splice(P(source),cleanOD(invSlot(sparse(source)))).
This is the actual preimage candidate (6865). Its check Boolean requires I(C(source))=P(source), CleanInput(C(source)), and address range. G:6899 proves these checks with n>=3,kappa=7,l=3, source<2^T and CleanInput(source). Its proof only uses the source-finite/source-clean/kappa=7 hypotheses as named unused witnesses; the core roundtrip uses the masked sparse<8 and l=3. These interface guards must not be silently erased from a reconstruction of the declaration. G:7006 proves candidate finite with the same guards and source as Fin; its proof does not use source cleanliness or kappa value substantively. G:7055 packages cleanup with supplied post/pre range proofs; 7096 derives both ranges internally; 7144 replaces clean input by row-local ValidCleanSource, and 7186 replaces it by GlobalSlotSource. G:7226/7245 similarly derive checks and finite range from GlobalSlotSource. These are positive arbitrary-width results under their guards, not mere obligations.

G:7267 identifies the candidate's sparse slot with invSlot(source sparse) using n>=3,l=3, without requiring source cleanliness or kappa=7. Under GlobalSlotSource and kappa=7, that inverse slot is again <7; G:7312 proves candidate GlobalSlotSource. G:7360 proves uniqueness among preimages that themselves satisfy GlobalSlotSource, using restricted injectivity. This deliberately does not assert uniqueness among every clean input or every basis index.

GlobalSlotInverseOnRangeContract (7419–7482) stores the above indices/predicate/checks but five status annotations remain false, even though adjacent lemmas establish restricted mathematical facts. G:7506 proves source/check Booleans true under the guards while retaining those flags. G:7541 packages the unique preimage equality with flags; 7608 supplies finite post/pre witnesses and selected dagger entry; 7681 adds candidate-domain membership and uniqueness among GlobalSlotSource preimages; 7775 transports that package while explicitly retaining default-paper and GateMatrix unitary/cleanup flags false.

G:7820 shows the dagger entry is zero for an “other” index in GlobalSlotSource unequal to the candidate, at the designated post column. G:7883 combines the candidate one-entry and these off-candidate zeros with the cleanup witness. G:7972 is the strongest compact column statement: for each finite source in GlobalSlotSource and guards n>=3,kappa=7,l=3, finite post,pre exist with post=P(source), pre=C(source), pre in GlobalSlotSource and
for every finite other in GlobalSlotSource,
Dagger(other,post) = if other.val=pre.val then rat 1 else rat 0.
The quantifier is restricted on output rows. It is not a full dagger-column basis-state identity, nor a matrix multiplication identity, nor all-space unitarity. All five inverse-route flags, paper cleanup/extension flags, forward/dagger GateMatrix flags and theoremData circuit/block flags remain false in its conclusion.

G:8059–8206 then selects the activeGlobalSource enum and its predicate/evidence Strings. fullCleanDomainSelected=false, fullSpaceSelected=false, semanticCleanupPromotionAllowed=false; inherited annotations are false. These are scope-policy values, not new proofs that extension is impossible. G:8216 instantiates the positive cleanup package on source 48 at n=3,kappa=7,G=Q=1; this source is global-valid but row-local-invalid. The target ends after the general indicator permutation proof and the two namespace ends (8473–8474), not a block-encoding root.

## 7. What is and is not entailed

There are real positive formal mathematical claims here: exact finite arithmetic/range identities; symbolic coefficient tables; exact clean workspace branch entries; general indicator/SWAP permutations; the seven-offset inversion and uniqueness theorems; guarded finite post-SWAP preimage construction; and a restricted dagger-column Kronecker-delta result. Many record projection/flag theorems also prove their literal propositions exactly. None should be erased because the broader construction remains incomplete or because this independent run did not compile.

Conversely the supplied target does not entail:
- that an arbitrary mat accepted by oneTermRobinSpec is a discretized differential operator or equals the circuit's block;
- that the seven-label backend and ten-label transcript are semantically equivalent, that the missing H/indicator-uncompute steps are synthesized, or that named daggers are inverses merely because their labels say so;
- any normalizer positivity/nonzeroness, equality of inv symbols with inverses, evaluated trigonometric/half-angle relations, unitary completion of rotation/function skeletons, or general source-to-stencil/ghost-elimination bridge;
- cleanup of all 2*n advertised pure ancillas or every output row of the dagger column; a selected entry=1 alone is not such a statement;
- success probability, amplitude amplification cost, error norm/tolerance, fidelity, finite-bit accuracy, Clifford+T synthesis, connectivity, legal depth, preprocessing complexity, uniform oracle construction cost or readout cost;
- a one-/multi-dimensional Hamiltonian construction or its claimed normalizer/resource theorem, when these appear only in ConstructionClaim/CostExpr syntax.

For the exactly specified all-space paperMatrix, one can also derive a narrowly scoped collision directly from definitions (not a new compiled theorem in this packet): at p=(3,7,1,1), basis integers 32 and 112 encode row 0 and slots 2 and 7. Both global offsets are zero, the high tail and low prefix are equal, hence I(32)=I(112)=0 and the full 0/1 matrix has identical columns. At n>3 the arbitrary padded bits are also overwritten. This explains why a restricted-domain permutation result cannot certify this particular total matrix as a unitary. It does not rule out a different unitary extension agreeing on the injective s<7 clean subspace, nor refute an external mathematical theorem or paper. No impossibility inference is made from missing compilation, source access, annotations, or library operations.

The reconstruction is not a SOURCE/STANDING/TYPING/RULED/EXCESS source-binder classification: no natural source was available or read. It exposes actual carriers and guards so that a later distinct comparison can perform that audit. No repair is proposed or substituted into the formal target.

## 8. Handoff and stopped boundary

Objective/frontier: reconstruct the whole pinned module independently before opaque binding.
Mathematical delta: explicit denotation/carrier/guard reconstruction and lossless lexical/record map, preserving the restricted positive frontier and the annotation-versus-equation distinction.
Effect: supplies comparison evidence; makes no claim of source-route closure, theorem admission or production improvement.
Evidence: complete formal reads, exact input hashes, appendix line anchors and chronology; no build/test or external-source evidence.
Files changed: only this assigned output packet.
Failure class: NONE for the completed reading/reconstruction objective. Compiler/source comparison are deliberately unperformed scope boundaries, not failed mathematical routes.
Salvage: permutation/bit-register/modular-inverse fragments identified, none promoted as newly compiled reusable library nodes.
Process-memory IDs consulted: none; no out-of-allowlist process-memory mathematical evidence was loaded.
Parallelism: this independently assigned worker spawned no children. No cross-route comparison/common-blind-spot review performed here.
Default verified route/comparator: none selected.
Purification/Exposition Seal: not undertaken; this independent-read seal is not those publication gates.
Residual risk: lexical identities are not generated/elaborated names; text-reading is not kernel acceptance; no source-agreement judgement is supplied.
Next authorized boundary: STOP. Any later opaque binding/source comparison is a separate stage; this decoder does not consume its inputs.

## Appendix A. Explicit lexical declaration map

Each row names a written declaration start. Namespace prefixes below are resolved only from textual namespace commands. Private helpers are identified by lexical name and line, not Lean's generated private kernel name. Anonymous instances use their header and line instead of an invented generated identity. Structure/inductive generated names are not enumerated. The count was independently obtained after the complete reading: target 405 explicit starts, and 153 provider starts (558 total).

### Core.lean

```text
15 | abbrev | QuantumBlockEncoding.Matrix
20 | def | QuantumBlockEncoding.Matrix.PointwiseEq
25 | def | QuantumBlockEncoding.Matrix.zero
29 | def | QuantumBlockEncoding.Matrix.identity
34 | def | QuantumBlockEncoding.Matrix.mul
44 | def | QuantumBlockEncoding.gridSize
52 | def | QuantumBlockEncoding.clog2
55 | theorem | QuantumBlockEncoding.gridSize_zero
57 | theorem | QuantumBlockEncoding.clog2_zero
60 | theorem | QuantumBlockEncoding.clog2_one
64 | theorem | QuantumBlockEncoding.log2_pred_two_pow_succ
94 | theorem | QuantumBlockEncoding.clog2_gridSize
103 | inductive | QuantumBlockEncoding.BoundaryKind
111 | structure | QuantumBlockEncoding.Stencil
121 | def | QuantumBlockEncoding.Stencil.width
124 | theorem | QuantumBlockEncoding.Stencil.width_eq
134 | structure | QuantumBlockEncoding.BulkWindow
142 | def | QuantumBlockEncoding.BulkWindow.paperBoundaryLines
148 | inductive | QuantumBlockEncoding.Coeff
158 | instance | <anonymous instance> instance : OfNat Coeff n where
161 | instance | <anonymous instance> instance : Neg Coeff where
164 | instance | <anonymous instance> instance : HAdd Coeff Coeff Coeff where
167 | instance | <anonymous instance> instance : HMul Coeff Coeff Coeff where
170 | def | QuantumBlockEncoding.Coeff.sub
172 | instance | <anonymous instance> instance : HSub Coeff Coeff Coeff where
176 | def | QuantumBlockEncoding.Coeff.evalWith
183 | theorem | QuantumBlockEncoding.Coeff.evalWith_rat
186 | theorem | QuantumBlockEncoding.Coeff.evalWith_symbol
189 | theorem | QuantumBlockEncoding.Coeff.evalWith_add
192 | theorem | QuantumBlockEncoding.Coeff.evalWith_mul
195 | theorem | QuantumBlockEncoding.Coeff.evalWith_neg
199 | theorem | QuantumBlockEncoding.Coeff.rat_zero
202 | theorem | QuantumBlockEncoding.Coeff.evalWith_rat_zero
206 | theorem | QuantumBlockEncoding.Coeff.evalWith_rat_one
210 | theorem | QuantumBlockEncoding.Coeff.evalWith_rat_add
215 | theorem | QuantumBlockEncoding.Coeff.evalWith_rat_mul
220 | theorem | QuantumBlockEncoding.Coeff.evalWith_rat_neg
225 | theorem | QuantumBlockEncoding.Coeff.evalWith_eq_zero_of_rat_zero
229 | theorem | QuantumBlockEncoding.Coeff.evalWith_eq_one_of_rat_one
232 | def | QuantumBlockEncoding.Coeff.divNat
238 | structure | QuantumBlockEncoding.StencilEntry
```

### Resources.lean

```text
21 | structure | QuantumBlockEncoding.Resource
32 | def | QuantumBlockEncoding.Resource.gates
34 | def | QuantumBlockEncoding.Resource.add
45 | def | QuantumBlockEncoding.Resource.parallel
52 | instance | <anonymous instance> instance : Zero Resource := ⟨{}⟩
53 | instance | <anonymous instance> instance : HAdd Resource Resource Resource := ⟨add⟩
55 | def | QuantumBlockEncoding.Resource.scale
62 | def | QuantumBlockEncoding.Resource.ofCounts
68 | def | QuantumBlockEncoding.Resource.ofCountsWithDepth
75 | theorem | QuantumBlockEncoding.Resource.gates_eq
77 | theorem | QuantumBlockEncoding.Resource.zero_oneQubit
78 | theorem | QuantumBlockEncoding.Resource.zero_cnot
79 | theorem | QuantumBlockEncoding.Resource.zero_oracleCalls
80 | theorem | QuantumBlockEncoding.Resource.zero_pureAncilla
81 | theorem | QuantumBlockEncoding.Resource.zero_depth
82 | theorem | QuantumBlockEncoding.Resource.add_oneQubit
84 | theorem | QuantumBlockEncoding.Resource.add_cnot
86 | theorem | QuantumBlockEncoding.Resource.add_oracleCalls
88 | theorem | QuantumBlockEncoding.Resource.add_pureAncilla
90 | theorem | QuantumBlockEncoding.Resource.add_depth
96 | inductive | QuantumBlockEncoding.CostExpr
107 | instance | <anonymous instance> instance : OfNat CostExpr n where
110 | instance | <anonymous instance> instance : HAdd CostExpr CostExpr CostExpr where
113 | instance | <anonymous instance> instance : HMul CostExpr CostExpr CostExpr where
116 | def | QuantumBlockEncoding.CostExpr.atoms
122 | structure | QuantumBlockEncoding.AsymptoticResource
129 | def | QuantumBlockEncoding.AsymptoticResource.add
133 | instance | <anonymous instance> instance : HAdd AsymptoticResource AsymptoticResource AsymptoticResource := ⟨add⟩
138 | def | QuantumBlockEncoding.bandedSparseAccessResource
145 | def | QuantumBlockEncoding.sparseAmplitudeOracleResource
149 | def | QuantumBlockEncoding.indicatorResource
```

### Circuit.lean

```text
13 | inductive | QuantumBlockEncoding.Gate
23 | abbrev | QuantumBlockEncoding.Circuit
32 | def | QuantumBlockEncoding.Gate.resource
50 | abbrev | QuantumBlockEncoding.CircuitLayer
54 | def | QuantumBlockEncoding.CircuitLayer.resource
60 | abbrev | QuantumBlockEncoding.LayeredCircuit
64 | def | QuantumBlockEncoding.LayeredCircuit.resource
68 | def | QuantumBlockEncoding.LayeredCircuit.depth
75 | def | QuantumBlockEncoding.Circuit.resource
79 | theorem | QuantumBlockEncoding.Circuit.resource_nil
81 | theorem | QuantumBlockEncoding.Circuit.resource_cons
84 | def | QuantumBlockEncoding.Circuit.depth
```

### BlockEncoding.lean

```text
14 | structure | QuantumBlockEncoding.RegisterLayout
27 | def | QuantumBlockEncoding.RegisterLayout.auxiliaryQubits
33 | structure | QuantumBlockEncoding.BlockEncodingSpec
50 | structure | QuantumBlockEncoding.BlockEncodingCost
59 | def | QuantumBlockEncoding.BlockEncodingCost.fromLayoutAndResource
66 | def | QuantumBlockEncoding.BlockEncodingCost.fromSpec
70 | def | QuantumBlockEncoding.BlockEncodingCost.betterThan
80 | def | QuantumBlockEncoding.BlockEncodingCost.noWorseThan
90 | structure | QuantumBlockEncoding.QueryOperatorTarget
103 | structure | QuantumBlockEncoding.OperatorBlockEncodingCandidate
119 | def | QuantumBlockEncoding.OperatorBlockEncodingCandidate.cost
131 | structure | QuantumBlockEncoding.VerifiedOperatorBlockEncoding
148 | structure | QuantumBlockEncoding.ApproximateOperatorBlockEncodingCandidate
159 | structure | QuantumBlockEncoding.VerifiedApproximateOperatorBlockEncoding
173 | def | QuantumBlockEncoding.VerifiedOperatorBlockEncoding.asZeroErrorApprox
195 | structure | QuantumBlockEncoding.AdaptiveBlockEncodingPolicy
207 | inductive | QuantumBlockEncoding.BlockEncodingSearchPhase
220 | structure | QuantumBlockEncoding.VerifiedBlockEncoding
231 | theorem | QuantumBlockEncoding.VerifiedBlockEncoding.unitary
235 | theorem | QuantumBlockEncoding.VerifiedBlockEncoding.correct
239 | theorem | QuantumBlockEncoding.VerifiedBlockEncoding.resource_ok
246 | structure | QuantumBlockEncoding.ConstructionClaim
```

### CircuitSemantics.lean

```text
16 | def | QuantumBlockEncoding.qubitDim
25 | structure | QuantumBlockEncoding.SemanticObligation
35 | structure | QuantumBlockEncoding.GateMatrix
41 | def | QuantumBlockEncoding.gateMatricesMatchCircuit
54 | def | QuantumBlockEncoding.evalGateMatrices
71 | theorem | QuantumBlockEncoding.Matrix.evalWith_foldl_add_mul
92 | theorem | QuantumBlockEncoding.Matrix.evalWith_mul_apply
105 | private theorem | QuantumBlockEncoding.Matrix.foldl_add_zero_of_all_zero
131 | theorem | QuantumBlockEncoding.Matrix.evalWith_mul_eq_zero_of_all_paths_zero
145 | private theorem | QuantumBlockEncoding.Matrix.foldl_add_unique_of_nodup
188 | private theorem | QuantumBlockEncoding.Matrix.nodup_map_of_injective
207 | private theorem | QuantumBlockEncoding.Matrix.finRange_nodup
224 | private theorem | QuantumBlockEncoding.Matrix.foldl_add_extract_init
235 | private theorem | QuantumBlockEncoding.Matrix.foldl_add_two_of_nodup
304 | theorem | QuantumBlockEncoding.Matrix.evalWith_mul_unique_path
328 | theorem | QuantumBlockEncoding.Matrix.evalWith_mul_two_path
355 | theorem | QuantumBlockEncoding.Matrix.evalWith_mul_identity_right_apply
371 | theorem | QuantumBlockEncoding.Matrix.cast_square_apply
389 | theorem | QuantumBlockEncoding.evalWith_evalGateMatrices_single
404 | structure | QuantumBlockEncoding.CircuitMatrixSemantics
415 | def | QuantumBlockEncoding.CircuitMatrixSemantics.ofGateMatrices
436 | structure | QuantumBlockEncoding.PreparedCircuitEntryTarget
454 | def | QuantumBlockEncoding.PreparedCircuitEntryTarget.entryEqualityStatement
459 | def | QuantumBlockEncoding.PreparedCircuitEntryTarget.matrixEntryEqualityStatement
470 | theorem | QuantumBlockEncoding.PreparedCircuitEntryTarget.entryEqualityStatement_iff_matrixEntryEqualityStatement
502 | structure | QuantumBlockEncoding.BlockExtractionTarget
520 | def | QuantumBlockEncoding.blockExtractionBranchContributionSum
535 | structure | QuantumBlockEncoding.BlockExtractionBranchContributionTarget
559 | def | QuantumBlockEncoding.BlockExtractionBranchContributionTarget.selectedBranchStatement
569 | def | QuantumBlockEncoding.BlockExtractionBranchContributionTarget.projectionSummationStatement
586 | def | QuantumBlockEncoding.BlockExtractionBranchContributionTarget.backendExpansionStatement
595 | theorem | QuantumBlockEncoding.BlockExtractionBranchContributionTarget.selectedBranchStatement_of_eq
603 | theorem | QuantumBlockEncoding.BlockExtractionBranchContributionTarget.projectionSummationStatement_iff_backendExpansionStatement
629 | theorem | QuantumBlockEncoding.BlockExtractionBranchContributionTarget.projectionSummationStatement_of_backendExpansionStatement
640 | theorem | QuantumBlockEncoding.BlockExtractionBranchContributionTarget.backendExpansionStatement_of_projectionSummationStatement
661 | structure | QuantumBlockEncoding.CircuitBlockEncodingClaim
676 | structure | QuantumBlockEncoding.FiniteBlockCompositionContract
696 | def | QuantumBlockEncoding.signalSystemBlockRowIndex
700 | def | QuantumBlockEncoding.signalSystemBlockColIndex
703 | theorem | QuantumBlockEncoding.signalSystemBlockRowIndex_zero
707 | theorem | QuantumBlockEncoding.signalSystemBlockColIndex_zero
712 | theorem | QuantumBlockEncoding.signalSystemBlockRowIndex_lt
727 | theorem | QuantumBlockEncoding.signalSystemBlockColIndex_lt
753 | def | QuantumBlockEncoding.signalSystemBlockProjection
764 | theorem | QuantumBlockEncoding.signalSystemBlockProjection_apply
778 | def | QuantumBlockEncoding.totalCircuitQubits
786 | def | QuantumBlockEncoding.CircuitMatrixSemantics.blockExtractionTarget
```

### GHL2025.lean

```text
18 | structure | QuantumBlockEncoding.GHL2025.OneTermRobinParameters
32 | def | QuantumBlockEncoding.GHL2025.isBulkRow
39 | def | QuantumBlockEncoding.GHL2025.isBoundaryRow
49 | structure | QuantumBlockEncoding.GHL2025.RobinRegisterPartition
69 | def | QuantumBlockEncoding.GHL2025.RobinRegisterPartition.totalQubits
76 | def | QuantumBlockEncoding.GHL2025.defaultRobinRegisterPartition
96 | def | QuantumBlockEncoding.GHL2025.RobinRegisterPartition.totalPureAncillas
103 | def | QuantumBlockEncoding.GHL2025.oneTermRobinResourceExpr
112 | def | QuantumBlockEncoding.GHL2025.deviatingIndices
121 | def | QuantumBlockEncoding.GHL2025.oneTermRobinPreciseResourceExpr
130 | theorem | QuantumBlockEncoding.GHL2025.deviatingIndices_example
134 | def | QuantumBlockEncoding.GHL2025.oneTermRobinResource
140 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobin_pureAncilla
149 | def | QuantumBlockEncoding.GHL2025.oneTermRobinLayout
166 | def | QuantumBlockEncoding.GHL2025.oneTermRobinCircuit
185 | def | QuantumBlockEncoding.GHL2025.oneTermRobinTheoremFacingFig4Circuit
205 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinTheoremFacingFig4Circuit_gateList
227 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinActiveBackendCircuit_gateList
239 | def | QuantumBlockEncoding.GHL2025.oneTermRobinNormalizer
249 | def | QuantumBlockEncoding.GHL2025.oneTermRobinSpec
260 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinSpec_ancilla
269 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinSpec_circuitCost
274 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinNormalizer_eval
279 | def | QuantumBlockEncoding.GHL2025.oneTermRobinClaim
288 | def | QuantumBlockEncoding.GHL2025.oneDimHamiltonianResourceExpr
296 | def | QuantumBlockEncoding.GHL2025.oneDimHamiltonianClaim
305 | def | QuantumBlockEncoding.GHL2025.multiDimHamiltonianResourceExpr
313 | def | QuantumBlockEncoding.GHL2025.multiDimHamiltonianClaim
324 | structure | QuantumBlockEncoding.GHL2025.ObligationRecord
334 | structure | QuantumBlockEncoding.GHL2025.RobinCircuitSkeleton
373 | structure | QuantumBlockEncoding.GHL2025.RobinGamma1
396 | structure | QuantumBlockEncoding.GHL2025.RobinGamma2
413 | structure | QuantumBlockEncoding.GHL2025.RobinGamma3
433 | structure | QuantumBlockEncoding.GHL2025.RobinWavefunctionDecomposition
452 | def | QuantumBlockEncoding.GHL2025.defaultRobinWavefunctionDecomposition
488 | structure | QuantumBlockEncoding.GHL2025.RobinProofObligations
553 | def | QuantumBlockEncoding.GHL2025.defaultRobinCircuitSkeleton
577 | structure | QuantumBlockEncoding.GHL2025.BandedSparseAccessPaperContract
602 | def | QuantumBlockEncoding.GHL2025.defaultBandedSparseAccessPaperContract
650 | structure | QuantumBlockEncoding.GHL2025.DerivativeOracleContract
661 | structure | QuantumBlockEncoding.GHL2025.FunctionOracleContract
671 | def | QuantumBlockEncoding.GHL2025.derivativeOracleResource
675 | theorem | QuantumBlockEncoding.GHL2025.derivativeOracleResource_pureAncilla
684 | structure | QuantumBlockEncoding.GHL2025.OneTermRobinTheoremData
700 | def | QuantumBlockEncoding.GHL2025.defaultOneTermRobinTheoremData
714 | structure | QuantumBlockEncoding.GHL2025.RobinBoundaryRotationAngle
732 | structure | QuantumBlockEncoding.GHL2025.RobinBoundaryRotationSet
752 | def | QuantumBlockEncoding.GHL2025.RobinBoundaryRotationSet.expectedCount
755 | def | QuantumBlockEncoding.GHL2025.importedClaims
770 | def | QuantumBlockEncoding.GHL2025.oneTermRobinTotalQubits
777 | def | QuantumBlockEncoding.GHL2025.effectiveRobinSignalQubits
789 | theorem | QuantumBlockEncoding.GHL2025.defaultOneTermRobinTheoremData_signalQubits_eq_layout
798 | theorem | QuantumBlockEncoding.GHL2025.defaultOneTermRobinTheoremData_pureAncillas_eq_layout
807 | theorem | QuantumBlockEncoding.GHL2025.defaultOneTermRobinTheoremData_pureAncillas_eq_resource
821 | theorem | QuantumBlockEncoding.GHL2025.effectiveRobinSignalQubits_eq_layout_signal_plus_visibleWorkspace
839 | theorem | QuantumBlockEncoding.GHL2025.effectiveRobinSignalQubits_eq_theoremData_signal_plus_visibleWorkspace
852 | def | QuantumBlockEncoding.GHL2025.robinIndicatorBitPosition
869 | def | QuantumBlockEncoding.GHL2025.robinSparseColumnMap
897 | def | QuantumBlockEncoding.GHL2025.oneTermRobinGlobalSparseOffset
915 | def | QuantumBlockEncoding.GHL2025.oneTermRobinGlobalSparseAddress
919 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGlobalSparseAddress_lt_gridSize
934 | def | QuantumBlockEncoding.GHL2025.oneTermRobinGlobalSparseInverseSlot
946 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGlobalSparseInverseSlot_lt_eight
952 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGlobalSparseInverseSlot_lt_seven
967 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGlobalSparseInverseSlot_involutive_of_lt_seven
985 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGlobalSparseInverseSlot_injective_of_lt_seven
1009 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGlobalSparseAddress_inverseSlot_address_eq
1100 | private theorem | QuantumBlockEncoding.GHL2025.mod_add_eq_self_imp_offset_zero
1115 | private theorem | QuantumBlockEncoding.GHL2025.eq_zero_or_eq_base_of_mod_eq_zero_of_lt_two_mul
1131 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGlobalSparseOffset_lt_gridSize_of_lt_seven
1149 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGlobalSparseAddress_comp_eq_mod_offset_sum
1183 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGlobalSparseOffset_sum_mod_eq_zero_unique_of_lt_seven
1228 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGlobalSparseAddress_inverseSlot_unique_of_lt_seven
1261 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGlobalSparseAddress_same_row_injective_of_lt_seven
1295 | def | QuantumBlockEncoding.GHL2025.robinSparseColumnBranchValid
1314 | theorem | QuantumBlockEncoding.GHL2025.robinSparseColumnBranchValid_boundaryUnused_n3
1329 | theorem | QuantumBlockEncoding.GHL2025.robinSparseColumnMap_lt_gridSize_of_row_lt
1386 | def | QuantumBlockEncoding.GHL2025.robinSparseReverseColumnIndex
1396 | theorem | QuantumBlockEncoding.GHL2025.robinSparseColumnMap_zero
1401 | theorem | QuantumBlockEncoding.GHL2025.robinSparseColumnMap_one
1406 | theorem | QuantumBlockEncoding.GHL2025.robinSparseColumnMap_bulk
1412 | theorem | QuantumBlockEncoding.GHL2025.robinSparseColumnMap_rightBoundaryPrev
1427 | theorem | QuantumBlockEncoding.GHL2025.robinSparseColumnMap_rightBoundaryLast
1443 | theorem | QuantumBlockEncoding.GHL2025.robinSparseReverseColumnIndex_zero
1448 | theorem | QuantumBlockEncoding.GHL2025.robinSparseReverseColumnIndex_one
1453 | theorem | QuantumBlockEncoding.GHL2025.robinSparseReverseColumnIndex_bulk
1461 | theorem | QuantumBlockEncoding.GHL2025.robinSparseReverseColumnIndex_rightBoundaryPrev
1477 | theorem | QuantumBlockEncoding.GHL2025.robinSparseReverseColumnIndex_rightBoundaryLast
1502 | theorem | QuantumBlockEncoding.GHL2025.robinSparseReverseColumnRoundtrip_of_lt_eight
1715 | theorem | QuantumBlockEncoding.GHL2025.robinSparseReverseColumnIndex_lt_eight_of_columnMap
1875 | def | QuantumBlockEncoding.GHL2025.robinSparseReverseColumnRoundtripCheck
1890 | structure | QuantumBlockEncoding.GHL2025.BandedSparseAccessPaperRegisters
1902 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperRegisters
1919 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperRegisters_row_lt_gridSize
1928 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperRegisters_sparseIndexValue_eq
1936 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperRegisters_paddedZeroValue_eq
1944 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperRegisters_sparseIndex_lt
1955 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperRegisters_odRegisterValue_lt
1971 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessRowDependentPaperAddress
1983 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperAddress
1988 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperAddressInRange
1992 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperAddressInRange_iff
2004 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperAddress_lt_gridSize_of_two_le
2017 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperAddressInRange_eq_true_of_two_le
2031 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperImage
2047 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessRowDependentPaperImage
2062 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperRegisterValue_eq_mod
2076 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperHighWidth_le_totalQubits
2087 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperImage_lowBlock_lt_highBase_of_address_lt
2133 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperImage_mod_lowBase
2172 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperImage_div_lowBase_mod_eq
2219 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperImage_lt_qubitDim_of_address_lt
2268 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperImageFin
2276 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperImageFin_val
2284 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperImage_rowValue_eq
2303 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperImage_odRegisterValue_eq
2315 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperHighTail
2326 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperImage_highTail_eq_of_address_lt
2361 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperImageNoSpill
2371 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperImageNoSpill_iff
2380 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperImageNoSpill_eq_true_of_address_lt
2391 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperImageNoSpill_eq_true_of_two_le
2406 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperCleanInput
2416 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperSparseIndexInKappa
2427 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperGlobalSlotSource
2433 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperGlobalSlotSource_cleanInput_eq_true
2442 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperGlobalSlotSource_sparseIndex_lt_kappa
2461 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperGlobalSlotSource_inverseSlot_injective
2493 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperAddress_same_row_injective_of_globalSlotSource
2541 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperValidSparseBranch
2552 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperValidCleanSource
2558 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperValidCleanSource_cleanInput_eq_true
2567 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperValidCleanSource_validSparseBranch_eq_true
2580 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperValidCleanSource_separates_boundaryCollision_n3
2601 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperUnusedSparseBranch
2607 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperUnusedSparseBranch_cleanInput_eq_true
2616 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperUnusedSparseBranch_validSparseBranch_eq_false
2632 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperCleanDomainSplit_iff
2657 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperCleanDomainSplit_disjoint
2680 | structure | QuantumBlockEncoding.GHL2025.BandedSparseAccessUnusedBranchImageRuleContract
2702 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessUnusedBranchImageRuleContract
2735 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessUnusedBranchImageRuleContract_flags_false
2750 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessUnusedBranchImageRuleContract_of_unusedBranch
2775 | structure | QuantumBlockEncoding.GHL2025.BandedSparseAccessUnusedBranchExtensionContract
2797 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessUnusedBranchExtensionContract
2837 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessUnusedBranchExtensionContract_flags_false
2856 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessUnusedBranchExtensionContract_boundaryCollision_n3
2875 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessUnusedBranchExtensionContract_of_unusedBranch
2906 | structure | QuantumBlockEncoding.GHL2025.BandedSparseAccessFullCleanDomainExtensionContract
2932 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessFullCleanDomainExtensionContract
2986 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessFullCleanDomainExtensionContract_flags_false
3006 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessFullCleanDomainExtensionContract_of_unusedBranch
3032 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessFullCleanDomainExtensionContract_localCleanDomainSplit
3049 | structure | QuantumBlockEncoding.GHL2025.BandedSparseAccessUnusedZeroBranchSourceDecision
3064 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessUnusedZeroBranchSourceDecision
3078 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessUnusedZeroBranchSourceDecision_flags_false
3091 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessUnusedZeroBranchSourceDecision_keepsFullDomainFlagsFalse
3112 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessUnusedZeroBranchSourceDecision_keepsImageRuleUnspecified
3134 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessUnusedZeroBranchSourceDecision_keepsPaperContractFlagsFalse
3152 | structure | QuantumBlockEncoding.GHL2025.BandedSparseAccessRobinZeroInclusionSourceContract
3176 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessRobinZeroInclusionSourceContract
3211 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessRobinZeroInclusionSourceContract_blocks_unusedZeroBranch
3239 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessRobinZeroInclusionSourceContract_keepsImageRuleUnspecified
3264 | structure | QuantumBlockEncoding.GHL2025.BandedSparseAccessPriorPDESourceContract
3285 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPriorPDESourceContract
3308 | def | QuantumBlockEncoding.GHL2025.robinBandedSparseAccessCitationChain
3313 | theorem | QuantumBlockEncoding.GHL2025.robinBandedSparseAccessCitationChain_eq
3326 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPriorPDESourceContract_blocks_unusedZeroBranch
3335 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPriorPDESourceContract_oracleEquation
3340 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPriorPDESourceContract_resource_unproved
3350 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperCleanInput_iff
3366 | structure | QuantumBlockEncoding.GHL2025.BandedSparseAccessPaperColumnContract
3385 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperColumnContract
3409 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperColumnContract_inputRegisters_eq
3415 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperColumnContract_cleanInput_eq
3426 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperColumnContract_cleanInput_iff
3437 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperColumnContract_unitaryExtension_proved_eq_false
3442 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperColumnContract_imageIndex_eq
3448 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperColumnContract_addressInRange_eq
3454 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperColumnContract_imageNoSpill_eq
3465 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperColumnContract_rowPreserved_eq_true
3475 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperColumnContract_addressWritten_eq_true_of_address_lt
3483 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperColumnContract_addressInRange_eq_true_of_address_lt
3491 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperColumnContract_imageNoSpill_eq_true_of_address_lt
3503 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperColumnContract_registerSafety_of_address_lt
3525 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperMatrix
3531 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperMatrix_eq_image
3544 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperMatrix_imageFin_eq_one
3561 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperDaggerMatrix
3567 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperDaggerMatrix_eq_image
3579 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperDaggerMatrix_imageFin_eq_one
3604 | def | QuantumBlockEncoding.GHL2025.robinSparseAmplitudeValue
3661 | def | QuantumBlockEncoding.GHL2025.robinGlobalSparseAmplitudeValue
3707 | theorem | QuantumBlockEncoding.GHL2025.robinGlobalSparseAmplitudeValue_boundarySlot2_row0_n3
3719 | theorem | QuantumBlockEncoding.GHL2025.robinGlobalSparseAmplitudeValue_boundarySlot2_differs_rowLocal_n3
3737 | structure | QuantumBlockEncoding.GHL2025.DerivativeNormalizerNDContract
3761 | def | QuantumBlockEncoding.GHL2025.derivativeNormalizerNDContract
3808 | theorem | QuantumBlockEncoding.GHL2025.derivativeNormalizerNDContract_coefficient
3813 | theorem | QuantumBlockEncoding.GHL2025.derivativeNormalizerNDContract_normalizerND
3818 | theorem | QuantumBlockEncoding.GHL2025.derivativeNormalizerNDContract_normalizedCoefficient
3831 | structure | QuantumBlockEncoding.GHL2025.DerivativeNormalizerNDSourceBound
3849 | def | QuantumBlockEncoding.GHL2025.derivativeNormalizerNDSourceBound
3863 | theorem | QuantumBlockEncoding.GHL2025.derivativeNormalizerNDSourceBound_sourceCoefficient
3868 | theorem | QuantumBlockEncoding.GHL2025.derivativeNormalizerNDSourceBound_normalizerND
3873 | theorem | QuantumBlockEncoding.GHL2025.derivativeNormalizerNDSourceBound_boundFormula
3878 | theorem | QuantumBlockEncoding.GHL2025.derivativeNormalizerNDSourceBound_coefficientBound
3883 | theorem | QuantumBlockEncoding.GHL2025.derivativeNormalizerNDSourceBound_coefficientBound_false
3896 | def | QuantumBlockEncoding.GHL2025.indicatorOracleMatrix
3914 | def | QuantumBlockEncoding.GHL2025.oneTermRobinGate_U_indic
3931 | def | QuantumBlockEncoding.GHL2025.oneTermRobinGate_U_indic_dagger
3947 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGate_U_indic_dagger_matrix_eq
3965 | def | QuantumBlockEncoding.GHL2025.sparseAmplitudeOracleDTMatrix
3994 | structure | QuantumBlockEncoding.GHL2025.SparseAmplitudeOracleDTPaperRegisters
4007 | def | QuantumBlockEncoding.GHL2025.sparseAmplitudeOracleDTPaperRegisters
4025 | def | QuantumBlockEncoding.GHL2025.sparseAmplitudeOracleDTCosHalf
4029 | def | QuantumBlockEncoding.GHL2025.sparseAmplitudeOracleDTSinHalf
4044 | def | QuantumBlockEncoding.GHL2025.sparseAmplitudeOracleDTCoefficientNormalizerObligation
4059 | structure | QuantumBlockEncoding.GHL2025.SparseAmplitudeOracleDTCoefficientNormalizerContract
4079 | def | QuantumBlockEncoding.GHL2025.sparseAmplitudeOracleDTCoefficientNormalizerContract
4114 | def | QuantumBlockEncoding.GHL2025.sparseAmplitudeOracleDTNormalizedCoefficient
4126 | structure | QuantumBlockEncoding.GHL2025.SparseAmplitudeOracleDTCoefficientNormalizerProofRoute
4150 | def | QuantumBlockEncoding.GHL2025.sparseAmplitudeOracleDTCoefficientNormalizerProofRoute
4174 | theorem | QuantumBlockEncoding.GHL2025.sparseAmplitudeOracleDTCoefficientNormalizerProofRoute_coefficient
4179 | theorem | QuantumBlockEncoding.GHL2025.sparseAmplitudeOracleDTCoefficientNormalizerProofRoute_normalizerND
4184 | theorem | QuantumBlockEncoding.GHL2025.sparseAmplitudeOracleDTCoefficientNormalizerProofRoute_normalizedCoefficient
4189 | theorem | QuantumBlockEncoding.GHL2025.sparseAmplitudeOracleDTCoefficientNormalizerProofRoute_sharedND
4201 | theorem | QuantumBlockEncoding.GHL2025.sparseAmplitudeOracleDTCoefficientNormalizerProofRoute_sourceBound
4211 | theorem | QuantumBlockEncoding.GHL2025.sparseAmplitudeOracleDTCoefficientNormalizerProofRoute_ketZeroEntry
4216 | theorem | QuantumBlockEncoding.GHL2025.sparseAmplitudeOracleDTCoefficientNormalizerProofRoute_ketOneEntry
4231 | def | QuantumBlockEncoding.GHL2025.sparseAmplitudeOracleDTRotationMatrix
4256 | def | QuantumBlockEncoding.GHL2025.oneTermRobinGate_O_DT_S
4275 | structure | QuantumBlockEncoding.GHL2025.BoundaryRotationPaperRegisters
4288 | def | QuantumBlockEncoding.GHL2025.boundaryRotationPaperRegisters
4306 | def | QuantumBlockEncoding.GHL2025.boundaryRotationCosHalf
4310 | def | QuantumBlockEncoding.GHL2025.boundaryRotationSinHalf
4322 | def | QuantumBlockEncoding.GHL2025.boundaryRotationAngleNormalizerObligation
4336 | structure | QuantumBlockEncoding.GHL2025.BoundaryRotationAngleNormalizerContract
4359 | def | QuantumBlockEncoding.GHL2025.boundaryRotationAngleNormalizerContract
4402 | theorem | QuantumBlockEncoding.GHL2025.boundaryRotationAngleNormalizerContract_coefficient
4414 | def | QuantumBlockEncoding.GHL2025.boundaryRotationNormalizedCoefficient
4427 | structure | QuantumBlockEncoding.GHL2025.BoundaryRotationAngleNormalizerProofRoute
4454 | def | QuantumBlockEncoding.GHL2025.boundaryRotationAngleNormalizerProofRoute
4483 | theorem | QuantumBlockEncoding.GHL2025.boundaryRotationAngleNormalizerProofRoute_coefficient
4488 | theorem | QuantumBlockEncoding.GHL2025.boundaryRotationAngleNormalizerProofRoute_arccosArgument
4493 | theorem | QuantumBlockEncoding.GHL2025.boundaryRotationAngleNormalizerProofRoute_sharedND
4503 | theorem | QuantumBlockEncoding.GHL2025.boundaryRotationAngleNormalizerProofRoute_sourceBound
4513 | theorem | QuantumBlockEncoding.GHL2025.derivativeNormalizerNDSourceBound_sharedRoutes
4530 | theorem | QuantumBlockEncoding.GHL2025.robinGlobalSparseAmplitudeValue_sharedNormalizerRoutes
4557 | def | QuantumBlockEncoding.GHL2025.boundaryRotationMatrix
4592 | def | QuantumBlockEncoding.GHL2025.oneTermRobinGate_Ry_boundary
4610 | theorem | QuantumBlockEncoding.GHL2025.derivativeNormalizerNDSharedRoute_flags_false
4642 | theorem | QuantumBlockEncoding.GHL2025.derivativeNormalizerNDSharedRoute_sourceBoundAndFlags
4695 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessMatrix
4718 | def | QuantumBlockEncoding.GHL2025.oneTermRobinGate_O_D_BS
4728 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGate_O_D_BS_imageFin_eq_one
4748 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGate_O_D_BS_contractDrift_column8_n3
4770 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGate_O_D_BS_boundaryUnusedSparseCollision_n3
4796 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGate_O_D_BS_globalSparseBoundaryNoCollision_n3
4821 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperGlobalSlotSource_boundaryColumns_n3
4836 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperGlobalSlotSource_encodedOutOfRange_n3
4853 | def | QuantumBlockEncoding.GHL2025.robinFunctionValue
4865 | structure | QuantumBlockEncoding.GHL2025.FunctionOraclePaperRegisters
4880 | def | QuantumBlockEncoding.GHL2025.functionOraclePaperRegisters
4901 | def | QuantumBlockEncoding.GHL2025.functionOracleNormalizedValue
4912 | structure | QuantumBlockEncoding.GHL2025.FunctionOraclePaperImage
4936 | def | QuantumBlockEncoding.GHL2025.functionOraclePaperImage
4977 | theorem | QuantumBlockEncoding.GHL2025.functionOraclePaperImage_inputRegisters_eq
4983 | theorem | QuantumBlockEncoding.GHL2025.functionOraclePaperImage_cleanBranchBasisIndex_eq
4989 | theorem | QuantumBlockEncoding.GHL2025.functionOraclePaperImage_cleanBranchSystemValue_eq
4995 | theorem | QuantumBlockEncoding.GHL2025.functionOraclePaperImage_cleanBranchWorkspaceValue_eq
5003 | theorem | QuantumBlockEncoding.GHL2025.functionOraclePaperImage_cleanBranchAmplitude_eq
5009 | theorem | QuantumBlockEncoding.GHL2025.functionOraclePaperImage_cleanWorkspaceBranch_eq
5022 | structure | QuantumBlockEncoding.GHL2025.FunctionOracleExternalAmplitudeSourceContract
5047 | def | QuantumBlockEncoding.GHL2025.functionOracleExternalAmplitudeSourceContract
5088 | theorem | QuantumBlockEncoding.GHL2025.functionOracleExternalAmplitudeSourceContract_sourceAnchor
5092 | theorem | QuantumBlockEncoding.GHL2025.functionOracleExternalAmplitudeSourceContract_flags_false
5114 | structure | QuantumBlockEncoding.GHL2025.FunctionOracleAmplitudeProofRoute
5141 | def | QuantumBlockEncoding.GHL2025.functionOracleAmplitudeProofRoute
5166 | theorem | QuantumBlockEncoding.GHL2025.functionOracleAmplitudeProofRoute_sourceAnchor
5171 | theorem | QuantumBlockEncoding.GHL2025.functionOracleAmplitudeProofRoute_sourceFunctionValue
5176 | theorem | QuantumBlockEncoding.GHL2025.functionOracleAmplitudeProofRoute_normalizerNf
5181 | theorem | QuantumBlockEncoding.GHL2025.functionOracleAmplitudeProofRoute_normalizedAmplitude
5186 | theorem | QuantumBlockEncoding.GHL2025.functionOracleAmplitudeProofRoute_paperImage
5196 | theorem | QuantumBlockEncoding.GHL2025.functionOracleAmplitudeProofRoute_obligations_reuse_paperImage
5208 | theorem | QuantumBlockEncoding.GHL2025.functionOracleAmplitudeProofRoute_externalSourceContract
5224 | theorem | QuantumBlockEncoding.GHL2025.functionOracleAmplitudeProofRoute_flags_false
5242 | theorem | QuantumBlockEncoding.GHL2025.functionOracleAmplitudeProofRoute_externalSourceAndFlags
5285 | def | QuantumBlockEncoding.GHL2025.functionOracleOrthogonalEntry
5305 | def | QuantumBlockEncoding.GHL2025.functionOraclePaperMatrix
5320 | theorem | QuantumBlockEncoding.GHL2025.functionOraclePaperMatrix_cleanBranch_entry
5330 | theorem | QuantumBlockEncoding.GHL2025.functionOraclePaperMatrix_cleanWorkspace_offBranch_zero
5340 | theorem | QuantumBlockEncoding.GHL2025.functionOraclePaperMatrix_nonCleanInput_entry
5365 | def | QuantumBlockEncoding.GHL2025.functionOracleMatrix
5384 | def | QuantumBlockEncoding.GHL2025.oneTermRobinGate_O_f
5410 | def | QuantumBlockEncoding.GHL2025.swapOracleMatrix
5426 | def | QuantumBlockEncoding.GHL2025.swapOracleImage
5441 | def | QuantumBlockEncoding.GHL2025.swapOracleDiff
5449 | theorem | QuantumBlockEncoding.GHL2025.swapOracleImage_eq_xor_diff
5456 | theorem | QuantumBlockEncoding.GHL2025.swapOracleMatrix_eq_image
5468 | def | QuantumBlockEncoding.GHL2025.oneTermRobinGate_SWAP
5483 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessDaggerMatrix
5505 | def | QuantumBlockEncoding.GHL2025.oneTermRobinGate_O_D_BS_dagger
5515 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGate_O_D_BS_dagger_imageFin_eq_one
5534 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGate_O_D_BS_dagger_postSwap_entry_of_preimage
5555 | structure | QuantumBlockEncoding.GHL2025.BandedSparseAccessPostSwapCleanup
5585 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPostSwapCleanup_of_preimage
5626 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGate_O_D_BS_imageFin_entrySafety
5660 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGate_O_D_BS_globalSlotSource_entrySafety
5706 | def | QuantumBlockEncoding.GHL2025.oneTermRobinGateMatrixPlaceholders
5722 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinPlaceholdersMatch
5738 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGateMatrixPlaceholders_gateList
5757 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGateMatrixPlaceholders_unitaryFlags
5773 | def | QuantumBlockEncoding.GHL2025.indicatorOracleImage
5785 | theorem | QuantumBlockEncoding.GHL2025.indicatorOracleMatrix_eq_image
5796 | theorem | QuantumBlockEncoding.GHL2025.indicatorOracleImage_self_inverse_n1
5810 | theorem | QuantumBlockEncoding.GHL2025.indicatorOracleImage_self_inverse_n3
5822 | theorem | QuantumBlockEncoding.GHL2025.indicatorOracleImage_injective_n1
5838 | theorem | QuantumBlockEncoding.GHL2025.indicatorOracleImage_injective_n3
5855 | theorem | QuantumBlockEncoding.GHL2025.shiftLeft_land_mask_eq_zero
5872 | theorem | QuantumBlockEncoding.GHL2025.xor_shift_preserve_low
5883 | theorem | QuantumBlockEncoding.GHL2025.xor_shift_preserve_shift_low
5908 | theorem | QuantumBlockEncoding.GHL2025.swapOracleDiff_lt_two_pow
5926 | theorem | QuantumBlockEncoding.GHL2025.swapOracleDiff_shiftRight_eq_zero
5941 | theorem | QuantumBlockEncoding.GHL2025.swapOracleDiff_shiftLeft_mask_eq_zero
5954 | theorem | QuantumBlockEncoding.GHL2025.shiftLeft_lt_two_pow_of_lt
5972 | theorem | QuantumBlockEncoding.GHL2025.swapOracleImage_lt_qubitDim
6003 | theorem | QuantumBlockEncoding.GHL2025.swapOracleImage_block1_eq_block2
6031 | theorem | QuantumBlockEncoding.GHL2025.swapOracleImage_block2_eq_block1
6065 | theorem | QuantumBlockEncoding.GHL2025.swapOracleDiff_preserved
6074 | theorem | QuantumBlockEncoding.GHL2025.xor_two_shifted_masks_cancel
6091 | theorem | QuantumBlockEncoding.GHL2025.swapOracleImage_self_inverse
6102 | theorem | QuantumBlockEncoding.GHL2025.swapOracleImage_injective
6116 | theorem | QuantumBlockEncoding.GHL2025.swapOracleImage_bijective
6139 | theorem | QuantumBlockEncoding.GHL2025.swapOracleMatrix_col_has_one
6151 | theorem | QuantumBlockEncoding.GHL2025.swapOracleMatrix_col_unique
6161 | theorem | QuantumBlockEncoding.GHL2025.swapOracleMatrix_row_has_one
6176 | theorem | QuantumBlockEncoding.GHL2025.swapOracleMatrix_row_unique
6194 | theorem | QuantumBlockEncoding.GHL2025.swapOracleMatrix_is_permutation
6221 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperPostSwap_rowValue_eq_address
6238 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperPostSwap_odRegisterValue_eq_rowValue
6254 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperPostSwapImage_lt_qubitDim_of_address_lt
6274 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperSpliceODRegister
6283 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperImage_eq_splice
6291 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperSpliceODRegister_lowBlock_lt_highBase_of_odValue_lt
6329 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperSpliceODRegister_mod_lowBase
6364 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperSpliceODRegister_div_lowBase_mod_eq
6407 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperSpliceODRegister_rowValue_eq
6427 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperSpliceODRegister_odRegisterValue_eq
6439 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperSpliceODRegister_div_highBase_eq_of_odValue_lt
6471 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperSpliceODRegister_lt_qubitDim_of_odValue_lt
6515 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperSpliceODRegister_splice_of_odValue_lt
6530 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperSpliceODRegister_self
6572 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperCleanODValue
6577 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperCleanODValue_paddedZero_eq_zero
6586 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperCleanODValue_lt_two_pow_of_sparse_lt
6601 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperCleanODValue_sparseIndex_eq
6621 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperCleanInput_odRegisterValue_eq_cleanODValue
6695 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperImage_injective_on_globalSlotSource
6822 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperPostSwapReverseSparse_lt_two_pow
6837 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperPostSwapCleanODValue_lt_two_pow
6865 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperPostSwapPreimageCandidate
6882 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperPostSwapPreimageCandidateChecks
6899 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperPostSwapPreimageCandidateChecks_of_cleanSource
7006 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperPostSwapPreimageCandidate_lt_qubitDim_of_cleanSource
7055 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPostSwapCleanup_of_cleanSourceCandidate
7096 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPostSwapCleanup_of_cleanSourceCandidate_noRange
7144 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPostSwapCleanup_of_validCleanSourceCandidate_noRange
7186 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPostSwapCleanup_of_globalSlotSourceCandidate_noRange
7226 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperPostSwapPreimageCandidateChecks_of_globalSlotSource
7245 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperPostSwapPreimageCandidate_lt_qubitDim_of_globalSlotSource
7267 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperPostSwapPreimageCandidate_sparseIndex_eq
7312 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperPostSwapPreimageCandidate_globalSlotSource_of_globalSlotSource
7360 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessPaperPostSwapPreimageCandidate_unique_on_globalSlotSource
7419 | structure | QuantumBlockEncoding.GHL2025.BandedSparseAccessGlobalSlotInverseOnRangeContract
7443 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessGlobalSlotInverseOnRangeContract
7485 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessGlobalSlotInverseOnRangeContract_flags_false
7506 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessGlobalSlotInverseOnRangeContract_of_globalSlotSource
7541 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessGlobalSlotInverseOnRangeContract_uniquePreimageBridge
7608 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessGlobalSlotInverseOnRangeContract_daggerCleanupBridge
7681 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessGlobalSlotInverseOnRangeContract_cleanupContractMap
7775 | theorem | QuantumBlockEncoding.GHL2025.defaultBandedSparseAccessPaperContract_cleanupRouteBridge
7820 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessGlobalSlotInverseOnRangeContract_daggerOffCandidate_zero
7883 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessGlobalSlotInverseOnRangeContract_restrictedDaggerColumnCleanup
7972 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessGlobalSlotInverseOnRangeContract_restrictedDaggerColumnIndicator
8059 | inductive | QuantumBlockEncoding.GHL2025.BandedSparseAccessCleanupScope
8075 | structure | QuantumBlockEncoding.GHL2025.BandedSparseAccessCleanupScopeDecision
8095 | def | QuantumBlockEncoding.GHL2025.bandedSparseAccessCleanupScopeDecision
8116 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessCleanupScopeDecision_activeGlobalSource
8147 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessCleanupScopeDecision_priorPDESourceTranscriptGuard
8177 | theorem | QuantumBlockEncoding.GHL2025.bandedSparseAccessCleanupScopeDecision_fullCleanDomainImageRuleBlocked
8216 | theorem | QuantumBlockEncoding.GHL2025.defaultBandedSparseAccessPaperContract_cleanupRouteBridge_boundaryColumn_n3
8265 | theorem | QuantumBlockEncoding.GHL2025.robinIndicatorBitPosition_ge
8275 | theorem | QuantumBlockEncoding.GHL2025.indicatorOracleImage_systemVal_preserved
8289 | theorem | QuantumBlockEncoding.GHL2025.indicatorOracleImage_isBulk_preserved
8304 | theorem | QuantumBlockEncoding.GHL2025.indicatorOracleImage_self_inverse
8319 | theorem | QuantumBlockEncoding.GHL2025.oneTermRobinGate_U_indic_dagger_selfInverseBridge
8330 | theorem | QuantumBlockEncoding.GHL2025.indicatorOracleImage_injective
8341 | theorem | QuantumBlockEncoding.GHL2025.robinIndicatorBitPosition_lt_totalQubits
8352 | theorem | QuantumBlockEncoding.GHL2025.indicatorOracleImage_lt
8370 | theorem | QuantumBlockEncoding.GHL2025.indicatorOracleImage_bijective
8393 | theorem | QuantumBlockEncoding.GHL2025.indicatorOracleMatrix_col_has_one
8405 | theorem | QuantumBlockEncoding.GHL2025.indicatorOracleMatrix_col_unique
8418 | theorem | QuantumBlockEncoding.GHL2025.indicatorOracleMatrix_row_has_one
8436 | theorem | QuantumBlockEncoding.GHL2025.indicatorOracleMatrix_row_unique
8452 | theorem | QuantumBlockEncoding.GHL2025.indicatorOracleMatrix_is_permutation
```

Ambient commands: GHL2025 imports BlockEncoding and CircuitSemantics at lines 1–2; enters QuantumBlockEncoding and GHL2025 at 13–14; opens CostExpr at 16; closes at 8473–8474. Provider imports/namespaces and their OfNat/operation instances are present in the pinned source and the map. Simp annotations remain attached to the indicated declaration starts; no scoped variable, section, axiom, opaque declaration, or local notation command was found in these six complete texts. This is a reading/lexical observation, not an axiom-census/compiler result.

## Appendix B. Exact carrier/field/default drill-down

All 68 written structures/inductives in the six-file closure are reproduced below with original lines. These are formal carriers, not author-provided semantic classifications. A field of type Prop is proposition-valued data; a separate proof field must be read at its actual type. A field of ObligationRecord or SemanticObligation is a record containing a Boolean, never a proof of its description.

### Core.lean:103

```lean
103: inductive BoundaryKind where
104:   | periodic
105:   | robin
106:   | dirichlet
107:   | neumann
108: deriving Repr, DecidableEq
```

### Core.lean:111

```lean
111: structure Stencil where
112:   derivativeOrder : Nat
113:   accuracyOrder : Nat
114:   leftRadius : Nat
115:   rightRadius : Nat
116: deriving Repr, DecidableEq
```

### Core.lean:134

```lean
134: structure BulkWindow where
135:   lower : Nat
136:   upper : Nat
137: deriving Repr, DecidableEq
```

### Core.lean:148

```lean
148: inductive Coeff where
149:   | rat (q : Rat)
150:   | symbol (name : String)
151:   | add (a b : Coeff)
152:   | mul (a b : Coeff)
153:   | neg (a : Coeff)
154: deriving Repr, DecidableEq
```

### Core.lean:238

```lean
238: structure StencilEntry where
239:   offset : Int
240:   coeff : Coeff
241: deriving Repr, DecidableEq
```

### Resources.lean:21

```lean
21: structure Resource where
22:   oneQubit : Nat := 0
23:   cnot : Nat := 0
24:   oracleCalls : Nat := 0
25:   pureAncilla : Nat := 0
26:   depth : Nat := 0
27: deriving Repr, DecidableEq
```

### Resources.lean:96

```lean
96: inductive CostExpr where
97:   | nat (n : Nat)
98:   | atom (name : String)
99:   | add (a b : CostExpr)
100:   | mul (a b : CostExpr)
101:   | log (a : CostExpr)
102:   | sum (index : String) (body : CostExpr)
103: deriving Repr, DecidableEq
```

### Resources.lean:122

```lean
122: structure AsymptoticResource where
123:   gates : CostExpr
124:   pureAncilla : CostExpr
125: deriving Repr, DecidableEq
```

### Circuit.lean:13

```lean
13: inductive Gate where
14:   | oneQubit (name : String) (target : Nat)
15:   | rotationY (target : Nat) (angleLabel : String)
16:   | rotationZ (target : Nat) (angleLabel : String)
17:   | cnot (control target : Nat)
18:   | swap (left right : Nat)
19:   | multiControlled (controls : List (Nat × Bool)) (body : Gate)
20:   | oracleCall (name : String)
21: deriving Repr, DecidableEq
```

### BlockEncoding.lean:14

```lean
14: structure RegisterLayout where
15:   systemQubits : Nat
16:   signalQubits : Nat
17:   pureAncillas : Nat
18: deriving Repr, DecidableEq
```

### BlockEncoding.lean:33

```lean
33: structure BlockEncodingSpec (α : Type u) (rows cols : Nat) where
34:   matrix : Matrix rows cols α
35:   normalizer : α
36:   error : α
37:   layout : RegisterLayout
38:   circuit : Circuit
39:   resource : Resource
```

### BlockEncoding.lean:50

```lean
50: structure BlockEncodingCost where
51:   auxiliaryQubits : Nat
52:   gateCount : Nat
53:   depth : Nat
54:   oracleCalls : Nat
55: deriving Repr, DecidableEq
```

### BlockEncoding.lean:90

```lean
90: structure QueryOperatorTarget (α : Type u) (rows cols : Nat) where
91:   operator : Matrix rows cols α
92:   normalizer : α
93:   source : String
94:   semanticContract : String
95:   freeParameters : List String := []
```

### BlockEncoding.lean:103

```lean
103: structure OperatorBlockEncodingCandidate (α : Type u) (systemQubits : Nat) where
104:   auxiliaryQubits : Nat
105:   target : QueryOperatorTarget α (gridSize systemQubits) (gridSize systemQubits)
106:   unitary :
107:     Matrix (gridSize (systemQubits + auxiliaryQubits))
108:       (gridSize (systemQubits + auxiliaryQubits)) α
109:   layout : RegisterLayout
110:   circuit : Circuit
111:   schedule : LayeredCircuit := []
112:   resource : Resource
113:   layoutMatches : layout.auxiliaryQubits = auxiliaryQubits
114:   isUnitary : Prop
115:   blockContainsTarget : Prop
```

### BlockEncoding.lean:131

```lean
131: structure VerifiedOperatorBlockEncoding (α : Type u) (systemQubits : Nat) where
132:   candidate : OperatorBlockEncodingCandidate α systemQubits
133:   unitaryProof : candidate.isUnitary
134:   blockProof : candidate.blockContainsTarget
```

### BlockEncoding.lean:148

```lean
148: structure ApproximateOperatorBlockEncodingCandidate
149:     (α : Type u) (systemQubits : Nat) where
150:   candidate : OperatorBlockEncodingCandidate α systemQubits
151:   epsilon : α
152:   approximationBound : Prop
```

### BlockEncoding.lean:159

```lean
159: structure VerifiedApproximateOperatorBlockEncoding
160:     (α : Type u) (systemQubits : Nat) where
161:   approxCandidate : ApproximateOperatorBlockEncodingCandidate α systemQubits
162:   unitaryProof : approxCandidate.candidate.isUnitary
163:   approximationProof : approxCandidate.approximationBound
```

### BlockEncoding.lean:195

```lean
195: structure AdaptiveBlockEncodingPolicy (α : Type u) where
196:   maxExactIterations : Nat
197:   exactStallIterations : Nat
198:   requiredCost : BlockEncodingCost
199:   requestedEpsilon : α
200:   allowRelaxedEpsilon : Bool
201:   maxUpperAgents : Nat
202:   maxMiddleAgents : Nat
203:   maxLowerAgents : Nat
204: deriving Repr
```

### BlockEncoding.lean:207

```lean
207: inductive BlockEncodingSearchPhase where
208:   | exactSearch
209:   | exactConvergedApproxSearch
210:   | relaxedApproxSearch
211:   | stopped
212: deriving Repr, DecidableEq
```

### BlockEncoding.lean:220

```lean
220: structure VerifiedBlockEncoding (α : Type u) (rows cols : Nat) where
221:   spec : BlockEncodingSpec α rows cols
222:   isUnitary : Prop
223:   blockCorrect : Prop
224:   resourceBound : Prop
225:   unitaryProof : isUnitary
226:   blockProof : blockCorrect
227:   resourceProof : resourceBound
```

### BlockEncoding.lean:246

```lean
246: structure ConstructionClaim where
247:   name : String
248:   source : String
249:   target : String
250:   normalization : String
251:   layout : String
252:   resource : AsymptoticResource
253: deriving Repr, DecidableEq
```

### CircuitSemantics.lean:25

```lean
25: structure SemanticObligation where
26:   description : String
27:   source : String
28:   proved : Bool := false
29: deriving Repr, DecidableEq
```

### CircuitSemantics.lean:35

```lean
35: structure GateMatrix (α : Type u) (qubits : Nat) where
36:   gate : Gate
37:   matrix : Matrix (qubitDim qubits) (qubitDim qubits) α
38:   unitary : SemanticObligation
```

### CircuitSemantics.lean:404

```lean
404: structure CircuitMatrixSemantics (α : Type u) [OfNat α 0] [OfNat α 1]
405:     [HAdd α α α] [HMul α α α] (qubits : Nat) where
406:   circuit : Circuit
407:   gateMatrices : List (GateMatrix α qubits)
408:   gateListMatches : gateMatricesMatchCircuit circuit gateMatrices = true
409:   matrix : Matrix (qubitDim qubits) (qubitDim qubits) α
410:   matrix_eq_eval : Matrix.PointwiseEq matrix (evalGateMatrices gateMatrices)
```

### CircuitSemantics.lean:436

```lean
436: structure PreparedCircuitEntryTarget
437:     (α : Type u) (activeDim preparedDim : Nat) where
438:   activeMatrix : Matrix activeDim activeDim α
439:   preparedMatrix : Matrix preparedDim preparedDim α
440:   activeRow : Fin activeDim
441:   activeCol : Fin activeDim
442:   preparedRow : Fin preparedDim
443:   preparedCol : Fin preparedDim
444:   activeEntry : α
445:   activeEntry_eq : activeEntry = activeMatrix activeRow activeCol
446:   preparedEntry : α
447:   preparedEntry_eq : preparedEntry = preparedMatrix preparedRow preparedCol
448:   activeSource : SemanticObligation
449:   preparedComposition : SemanticObligation
```

### CircuitSemantics.lean:502

```lean
502: structure BlockExtractionTarget (α : Type u) [OfNat α 0] [OfNat α 1]
503:     [HAdd α α α] [HMul α α α]
504:     (rows cols signalDim : Nat) where
505:   unitaryMatrix : Matrix (signalDim * rows) (signalDim * cols) α
506:   targetMatrix : Matrix rows cols α
507:   normalizer : α
508:   signalIndex : Fin signalDim
509:   blockMatrix : Matrix rows cols α
510:   blockProjection : SemanticObligation
511:   blockCorrect : SemanticObligation
```

### CircuitSemantics.lean:535

```lean
535: structure BlockExtractionBranchContributionTarget
536:     (α : Type u) [OfNat α 0] [OfNat α 1]
537:     [HAdd α α α] [HMul α α α]
538:     (rows cols signalDim branchDim : Nat) where
539:   extractionTarget : BlockExtractionTarget α rows cols signalDim
540:   systemRow : Fin rows
541:   systemCol : Fin cols
542:   selectedBranch : Fin branchDim
543:   branchContribution : Fin branchDim → α
544:   selectedContribution : α
545:   selectedContribution_eq :
546:     selectedContribution = branchContribution selectedBranch
547:   branchSum : α
548:   branchSum_eq :
549:     branchSum = blockExtractionBranchContributionSum branchContribution
550:   blockEntry : α
551:   blockEntry_eq : blockEntry = extractionTarget.blockMatrix systemRow systemCol
552:   backendSource : SemanticObligation
553:   selectedBranchCorrect : SemanticObligation
554:   branchSummationCorrect : SemanticObligation
```

### CircuitSemantics.lean:661

```lean
661: structure CircuitBlockEncodingClaim (α : Type u) [OfNat α 0] [OfNat α 1]
662:     [HAdd α α α] [HMul α α α]
663:     (qubits : Nat) (dim signalDim : Nat) where
664:   semantics : CircuitMatrixSemantics α qubits
665:   target : BlockExtractionTarget α dim dim signalDim
666:   dimCompat : qubitDim qubits = signalDim * dim
667:   blockCorrect : SemanticObligation
```

### CircuitSemantics.lean:676

```lean
676: structure FiniteBlockCompositionContract (α : Type u) [OfNat α 0] [OfNat α 1]
677:     [HAdd α α α] [HMul α α α]
678:     (qubits dim signalDim : Nat) where
679:   sourceAnchor : String
680:   lcuSourceAnchor : String
681:   theoremAnchor : String
682:   claim : CircuitBlockEncodingClaim α qubits dim signalDim
683:   expectedTarget : BlockExtractionTarget α dim dim signalDim
684:   targetMatrix : Matrix dim dim α
685:   normalizer : α
686:   claimTargetMatches : claim.target = expectedTarget
687:   targetMatrixMatches : expectedTarget.targetMatrix = targetMatrix
688:   targetNormalizerMatches : expectedTarget.normalizer = normalizer
689:   circuitUnitary : SemanticObligation
690:   lcuComposition : SemanticObligation
691:   blockProjection : SemanticObligation
692:   normalizedBlockEquality : SemanticObligation
693:   finalExtraction : SemanticObligation
```

### GHL2025.lean:18

```lean
18: structure OneTermRobinParameters where
19:   n : Nat
20:   kappa : Nat
21:   functionPieces : Nat
22:   polynomialDegreeCost : Nat
23: deriving Repr, DecidableEq
```

### GHL2025.lean:49

```lean
49: structure RobinRegisterPartition where
52:   mfQubits : Nat
54:   indicatorQubit : Nat
56:   sparseIndexQubits : Nat
59:   odPureAncillaQubits : Nat
61:   systemQubits : Nat
63:   ancillaQubit : Nat
64: deriving Repr, DecidableEq
```

### GHL2025.lean:324

```lean
324: structure ObligationRecord where
325:   description : String
326:   source : String
327:   proved : Bool := false
328: deriving Repr, DecidableEq
```

### GHL2025.lean:334

```lean
334: structure RobinCircuitSkeleton where
336:   indicatorOracle : String
338:   K1 : Nat
340:   K2 : Nat
343:   sparseAmplitudeOracleDT : String
345:   bandedSparseAccessOracleD : String
348:   bandedSparseAccessOracleD_dagger : String
351:   controlledRyBoundary : String
353:   functionOracle : String
355:   swapOperation : String
357:   mergeFrame : String
359:   mfSignalQubits : Nat
361:   kappaSignalQubits : Nat
364:   pureAncillaODRegister : Nat
365: deriving Repr, DecidableEq
```

### GHL2025.lean:373

```lean
373: structure RobinGamma1 where
375:   kappa : Nat
377:   K1 : Nat
379:   K2 : Nat
381:   gridSize : Nat
384:   boundaryNormalizer : Coeff
389:   bulkNormalizer : Coeff
391:   mfQubits : Nat
392: deriving Repr, DecidableEq
```

### GHL2025.lean:396

```lean
396: structure RobinGamma2 where
398:   kappa : Nat
400:   K1 : Nat
402:   K2 : Nat
404:   gridSize : Nat
406:   normalizer : Coeff
408:   hasOrthogonalRemainder : Bool
409: deriving Repr, DecidableEq
```

### GHL2025.lean:413

```lean
413: structure RobinGamma3 where
415:   kappa : Nat
417:   K1 : Nat
419:   K2 : Nat
421:   gridSize : Nat
423:   normalizer : Coeff
425:   hasOrthogonalRemainder : Bool
427:   pureAncillaQubits : Nat
428: deriving Repr, DecidableEq
```

### GHL2025.lean:433

```lean
433: structure RobinWavefunctionDecomposition where
435:   gamma1 : RobinGamma1
437:   gamma2 : RobinGamma2
439:   gamma3 : RobinGamma3
441:   kappa : Nat
443:   K1 : Nat
445:   K2 : Nat
447:   gridSize : Nat
448: deriving Repr, DecidableEq
```

### GHL2025.lean:488

```lean
488: structure RobinProofObligations where
490:   indicatorUnitary : ObligationRecord := {
491:     description := "U_indic(K1,K2) implements the bulk/boundary indicator correctly"
492:     source := "Guseynov-Huang-Liu 2025, U_indic definition and Fig. 1-term Robin, arXiv:2506.20478"
493:     proved := false
494:   }
496:   sparseAmplitudeOracleCorrect : ObligationRecord := {
497:     description := "O_DT^S prepares the D^T sparse-amplitude branch D_j^(s)/N_D from Lemma 3, Eq. (20)"
498:     source := "Guseynov-Huang-Liu 2025, Lemma 3, Eq. (20), arXiv:2506.20478"
499:     proved := false
500:   }
502:   bandedSparseAccessCorrect : ObligationRecord := {
503:     description := "O_D^BS maps |0>^(n-l)|s>^l|i>^n to |r_si>^n|i>^n and supports dagger cleanup"
504:     source := "Guseynov-Huang-Liu 2025, Lemma 1 and Fig. 1-term Robin, arXiv:2506.20478"
505:     proved := false
506:   }
508:   functionOracleCorrect : ObligationRecord := {
509:     description := "O_f block-encodes the piecewise polynomial f(x) discretized on the grid"
510:     source := "Guseynov-Huang-Liu 2025, Theorem amplitude-oracle for piece-wise polynomial function and Fig. 1-term Robin, arXiv:2506.20478"
511:     proved := false
512:   }
514:   controlledRyCorrect : ObligationRecord := {
515:     description := "R_y rotation angles theta_j^s = arccos(D_j^(s)/N_D) are correct"
516:     source := "Guseynov-Huang-Liu 2025, Fig. 1-term Robin and boundary Ry angle formula, arXiv:2506.20478"
517:     proved := false
518:   }
520:   circuitUnitary : ObligationRecord := {
521:     description := "The full one-term Robin circuit U_Ak^(1) is unitary"
522:     source := "Guseynov-Huang-Liu 2025, one-term Robin theorem, arXiv:2506.20478"
523:     proved := false
524:   }
526:   blockExtraction : ObligationRecord := {
527:     description := "Block extraction yields A_k / alpha where alpha = N_D * N_f * kappa"
528:     source := "Guseynov-Huang-Liu 2025, one-term Robin theorem, arXiv:2506.20478"
529:     proved := false
530:   }
532:   resourceBound : ObligationRecord := {
533:     description := "Gate count O(sum_g Q_g n log n + kappa n), pure ancillas 2n"
534:     source := "Guseynov-Huang-Liu 2025, one-term Robin theorem resource claim, arXiv:2506.20478"
535:     proved := false
536:   }
538:   ancillaCleanup : ObligationRecord := {
539:     description := "All 2n pure ancilla qubits are returned to |0⟩ state"
540:     source := "Guseynov-Huang-Liu 2025, Fig. 1-term Robin caption, arXiv:2506.20478"
541:     proved := false
542:   }
544:   ghostPointElimination : ObligationRecord := {
545:     description := "Ghost-point elimination via Robin boundary relation produces correct boundary rows"
546:     source := "Guseynov-Huang-Liu 2025, Robin boundary-row derivation, arXiv:2506.20478"
547:     proved := false
548:   }
549: deriving Repr, DecidableEq
```

### GHL2025.lean:577

```lean
577: structure BandedSparseAccessPaperContract where
578:   sourceAnchor : String
579:   rowRegisterQubits : Nat
580:   paddedZeroQubits : Nat
581:   sparseIndexQubits : Nat
582:   outputAddressQubits : Nat
583:   inputKet : String
584:   outputKet : String
585:   imageFormula : String
586:   cleanInputDomain : ObligationRecord
587:   widthCompatible : ObligationRecord
588:   addressRange : ObligationRecord
589:   noSpill : ObligationRecord
590:   forwardCorrect : ObligationRecord
591:   daggerCleanup : ObligationRecord
592:   unitaryExtension : ObligationRecord
593: deriving Repr, DecidableEq
```

### GHL2025.lean:650

```lean
650: structure DerivativeOracleContract (n : Nat) where
651:   stencil : Stencil
652:   bandwidth : Nat
653:   matrix : Matrix (gridSize n) (gridSize n) Coeff
656:   sparseCorrect : ObligationRecord
657:   bandwidth_eq : bandwidth = stencil.width
```

### GHL2025.lean:661

```lean
661: structure FunctionOracleContract (n : Nat) where
662:   functionPieces : Nat
663:   normalizerBound : Coeff
666:   amplitudeCorrect : ObligationRecord
```

### GHL2025.lean:684

```lean
684: structure OneTermRobinTheoremData where
686:   alpha : Coeff
688:   signalQubits : Nat
690:   error : Coeff
692:   gatesBound : String
694:   pureAncillas : Nat
696:   obligations : RobinProofObligations
697: deriving Repr, DecidableEq
```

### GHL2025.lean:714

```lean
714: structure RobinBoundaryRotationAngle where
716:   row : Nat
718:   sparseIndex : Nat
720:   matrixEntry : Coeff
724:   arccosArgument : Coeff
725: deriving Repr, DecidableEq
```

### GHL2025.lean:732

```lean
732: structure RobinBoundaryRotationSet where
734:   K1 : Nat
736:   K2 : Nat
738:   gridSize : Nat
740:   kappa : Nat
742:   normalizerND : Coeff
745:   angles : List RobinBoundaryRotationAngle
746: deriving Repr, DecidableEq
```

### GHL2025.lean:1890

```lean
1890: structure BandedSparseAccessPaperRegisters where
1891:   odRegisterValue : Nat
1892:   paddedZeroValue : Nat
1893:   sparseIndexValue : Nat
1894:   rowValue : Nat
1895: deriving Repr, DecidableEq
```

### GHL2025.lean:2680

```lean
2680: structure BandedSparseAccessUnusedBranchImageRuleContract where
2681:   sourceAnchor : String
2682:   sourceIndex : Nat
2683:   inputRegisters : BandedSparseAccessPaperRegisters
2684:   activeImageIndex : Nat
2685:   proposedImageIndex : Option Nat
2686:   cleanInput : Bool
2687:   validSparseBranch : Bool
2688:   unusedSparseBranch : Bool
2689:   imageSpecified : ObligationRecord
2690:   imageFinite : ObligationRecord
2691:   separatesActiveCollision : ObligationRecord
2692:   validBranchAgreement : ObligationRecord
2693: deriving Repr, DecidableEq
```

### GHL2025.lean:2775

```lean
2775: structure BandedSparseAccessUnusedBranchExtensionContract where
2776:   sourceAnchor : String
2777:   inputRegisters : BandedSparseAccessPaperRegisters
2778:   activeImageIndex : Nat
2779:   cleanInput : Bool
2780:   validSparseBranch : Bool
2781:   unusedSparseBranch : Bool
2782:   unusedBranchImageRuleContract : BandedSparseAccessUnusedBranchImageRuleContract
2783:   paperAgreementOnValidBranches : ObligationRecord
2784:   unusedBranchImageRule : ObligationRecord
2785:   unusedBranchInjective : ObligationRecord
2786:   fullCleanDomainInjective : ObligationRecord
2787:   daggerCleanup : ObligationRecord
2788:   unitaryExtension : ObligationRecord
2789: deriving Repr, DecidableEq
```

### GHL2025.lean:2906

```lean
2906: structure BandedSparseAccessFullCleanDomainExtensionContract where
2907:   sourceAnchor : String
2908:   cleanInputPredicate : String
2909:   validSparseBranchPredicate : String
2910:   validCleanSourcePredicate : String
2911:   unusedSparseBranchPredicate : String
2912:   unusedBranchImageRuleContract :
2913:     Nat → BandedSparseAccessUnusedBranchImageRuleContract
2914:   unusedBranchExtensionContract :
2915:     Nat → BandedSparseAccessUnusedBranchExtensionContract
2916:   cleanDomainSplit : ObligationRecord
2917:   validBranchAgreement : ObligationRecord
2918:   unusedBranchImageSpecified : ObligationRecord
2919:   unusedBranchImageFinite : ObligationRecord
2920:   unusedBranchInjective : ObligationRecord
2921:   fullCleanDomainInjective : ObligationRecord
2922:   daggerCleanup : ObligationRecord
2923:   unitaryExtension : ObligationRecord
```

### GHL2025.lean:3049

```lean
3049: structure BandedSparseAccessUnusedZeroBranchSourceDecision where
3050:   sourceAnchor : String
3051:   citedResultKey : String
3052:   paperImageRuleSpecified : Bool
3053:   externalExtensionTheoremAccepted : Bool
3054:   lowerProofSearchAllowed : Bool
3055:   dependency : ObligationRecord
3056: deriving Repr, DecidableEq
```

### GHL2025.lean:3152

```lean
3152: structure BandedSparseAccessRobinZeroInclusionSourceContract where
3153:   sourceAnchor : String
3154:   zeroInclusionAnchor : String
3155:   equationAnchor : String
3156:   sparseIndexRange : String
3157:   zerosIncludedInSparseEnumeration : Bool
3158:   paperImageEquation : String
3159:   unusedBranchImageRule : Option String
3160:   unusedBranchImageIndex : Option Nat
3161:   reversibleExtensionTheorem : Option String
3162:   closesUnusedZeroBranchExtension : Bool
3163:   lowerProofSearchAllowed : Bool
3164:   imageRuleObligation : ObligationRecord
3165:   reversibleExtensionObligation : ObligationRecord
3166: deriving Repr, DecidableEq
```

### GHL2025.lean:3264

```lean
3264: structure BandedSparseAccessPriorPDESourceContract where
3265:   sourceAnchor : String
3266:   definitionAnchor : String
3267:   lemmaAnchor : String
3268:   appendixAnchor : String
3269:   oracleEquation : String
3270:   circuitDecomposition : String
3271:   resourceClaim : ObligationRecord
3272:   robinUnusedBranchImageRule : Option String
3273:   closesUnusedZeroBranchExtension : Bool
3274:   lowerProofSearchAllowed : Bool
3275: deriving Repr, DecidableEq
```

### GHL2025.lean:3366

```lean
3366: structure BandedSparseAccessPaperColumnContract where
3367:   sourceAnchor : String
3368:   inputRegisters : BandedSparseAccessPaperRegisters
3369:   cleanInput : Bool
3370:   imageIndex : Nat
3371:   imageRegisters : BandedSparseAccessPaperRegisters
3372:   rowPreserved : Bool
3373:   addressWritten : Bool
3374:   addressInRange : Bool
3375:   imageNoSpill : Bool
3376:   cleanInputDomain : ObligationRecord
3377:   addressRange : ObligationRecord
3378:   noSpill : ObligationRecord
3379:   unitaryExtension : ObligationRecord
3380: deriving Repr, DecidableEq
```

### GHL2025.lean:3737

```lean
3737: structure DerivativeNormalizerNDContract where
3738:   sourceAnchor : String
3739:   rowValue : Nat
3740:   sparseIndexValue : Nat
3741:   coefficient : Coeff
3742:   normalizerND : Coeff
3743:   normalizedCoefficient : Coeff
3744:   normalizedCoefficientFormula : String
3745:   nonzeroNormalizer : ObligationRecord
3746:   divisionSemantics : ObligationRecord
3747:   coefficientBound : ObligationRecord
3748:   absSquareSemantics : ObligationRecord
3749:   sqrtComplementSemantics : ObligationRecord
3750:   arccosSemantics : ObligationRecord
3751:   twoByTwoUnitary : ObligationRecord
3752: deriving Repr, DecidableEq
```

### GHL2025.lean:3831

```lean
3831: structure DerivativeNormalizerNDSourceBound where
3832:   sourceAnchor : String
3833:   rowValue : Nat
3834:   sparseIndexValue : Nat
3835:   sourceCoefficient : Coeff
3836:   normalizerND : Coeff
3837:   boundFormula : String
3838:   coefficientBound : ObligationRecord
3839: deriving Repr, DecidableEq
```

### GHL2025.lean:3994

```lean
3994: structure SparseAmplitudeOracleDTPaperRegisters where
3995:   ancillaBit : Nat
3996:   indicatorBit : Nat
3997:   rowValue : Nat
3998:   sparseIndexValue : Nat
3999:   nonAncillaValue : Nat
4000: deriving Repr, DecidableEq
```

### GHL2025.lean:4059

```lean
4059: structure SparseAmplitudeOracleDTCoefficientNormalizerContract where
4060:   sourceAnchor : String
4061:   rowValue : Nat
4062:   sparseIndexValue : Nat
4063:   coefficient : Coeff
4064:   normalizerND : Coeff
4065:   ketZeroEntry : Coeff
4066:   ketOneEntry : Coeff
4067:   ketZeroFormula : String
4068:   ketOneFormula : String
4069:   coefficientRelation : ObligationRecord
4070:   complementRelation : ObligationRecord
4071:   twoByTwoUnitary : ObligationRecord
4072: deriving Repr, DecidableEq
```

### GHL2025.lean:4126

```lean
4126: structure SparseAmplitudeOracleDTCoefficientNormalizerProofRoute where
4127:   sourceAnchor : String
4128:   rowValue : Nat
4129:   sparseIndexValue : Nat
4130:   coefficient : Coeff
4131:   normalizerND : Coeff
4132:   normalizedCoefficient : Coeff
4133:   normalizedCoefficientFormula : String
4134:   ketZeroEntry : Coeff
4135:   ketOneEntry : Coeff
4136:   ketZeroFormula : String
4137:   ketOneFormula : String
4138:   coefficientDivision : ObligationRecord
4139:   normalizerBound : ObligationRecord
4140:   absSquareSemantics : ObligationRecord
4141:   sqrtComplementSemantics : ObligationRecord
4142:   twoByTwoUnitary : ObligationRecord
4143: deriving Repr, DecidableEq
```

### GHL2025.lean:4275

```lean
4275: structure BoundaryRotationPaperRegisters where
4276:   ancillaBit : Nat
4277:   indicatorBit : Nat
4278:   rowValue : Nat
4279:   sparseIndexValue : Nat
4280:   nonAncillaValue : Nat
4281: deriving Repr, DecidableEq
```

### GHL2025.lean:4336

```lean
4336: structure BoundaryRotationAngleNormalizerContract where
4337:   sourceAnchor : String
4338:   rowValue : Nat
4339:   sparseIndexValue : Nat
4340:   coefficient : Coeff
4341:   normalizerND : Coeff
4342:   thetaFormula : String
4343:   cosHalfEntry : Coeff
4344:   sinHalfEntry : Coeff
4345:   cosHalfFormula : String
4346:   sinHalfFormula : String
4347:   boundaryControl : ObligationRecord
4348:   arccosArgumentRelation : ObligationRecord
4349:   cosHalfRelation : ObligationRecord
4350:   sinHalfRelation : ObligationRecord
4351:   twoByTwoUnitary : ObligationRecord
4352: deriving Repr, DecidableEq
```

### GHL2025.lean:4427

```lean
4427: structure BoundaryRotationAngleNormalizerProofRoute where
4428:   sourceAnchor : String
4429:   rowValue : Nat
4430:   sparseIndexValue : Nat
4431:   coefficient : Coeff
4432:   normalizerND : Coeff
4433:   arccosArgument : Coeff
4434:   arccosArgumentFormula : String
4435:   thetaFormula : String
4436:   cosHalfEntry : Coeff
4437:   sinHalfEntry : Coeff
4438:   cosHalfFormula : String
4439:   sinHalfFormula : String
4440:   coefficientDivision : ObligationRecord
4441:   realArccosSemantics : ObligationRecord
4442:   halfAngleSemantics : ObligationRecord
4443:   normalizerBound : ObligationRecord
4444:   twoByTwoUnitary : ObligationRecord
4445: deriving Repr, DecidableEq
```

### GHL2025.lean:4865

```lean
4865: structure FunctionOraclePaperRegisters where
4866:   systemValue : Nat
4867:   mfWorkspaceValue : Nat
4868:   nonMFValue : Nat
4869:   cleanWorkspace : Bool
4870: deriving Repr, DecidableEq
```

### GHL2025.lean:4912

```lean
4912: structure FunctionOraclePaperImage where
4913:   sourceAnchor : String
4914:   inputRegisters : FunctionOraclePaperRegisters
4915:   cleanBranchBasisIndex : Nat
4916:   cleanBranchSystemValue : Nat
4917:   cleanBranchWorkspaceValue : Nat
4918:   cleanBranchAmplitude : Coeff
4919:   orthogonalComponent : String
4920:   systemPreserved : Bool
4921:   cleanWorkspaceBranch : Bool
4922:   normalizedAmplitudeCorrect : ObligationRecord
4923:   orthogonalComponentCorrect : ObligationRecord
4924:   normalizerBound : ObligationRecord
4925:   unitaryCompletion : ObligationRecord
4926:   diagonalHelperIsolation : ObligationRecord
4927: deriving Repr, DecidableEq
```

### GHL2025.lean:5022

```lean
5022: structure FunctionOracleExternalAmplitudeSourceContract where
5023:   sourceAnchor : String
5024:   theoremAnchor : String
5025:   coordinateOracleAnchor : String
5026:   citedSourceAnchor : String
5027:   cleanBranchFormula : String
5028:   normalizerNf : Coeff
5029:   resourceClaim : ObligationRecord
5030:   externalTheoremFormalized : ObligationRecord
5031:   nonzeroNormalizer : ObligationRecord
5032:   divisionSemantics : ObligationRecord
5033:   theoremAmplitudeCorrect : ObligationRecord
5034:   closesNormalizerBound : Bool
5035:   closesOrthogonalCompletion : Bool
5036:   closesUnitaryCompletion : Bool
5037:   closesFunctionOracleContract : Bool
5038: deriving Repr, DecidableEq
```

### GHL2025.lean:5114

```lean
5114: structure FunctionOracleAmplitudeProofRoute where
5115:   sourceAnchor : String
5116:   systemValue : Nat
5117:   sourceFunctionValue : Coeff
5118:   normalizerNf : Coeff
5119:   normalizedAmplitude : Coeff
5120:   normalizedAmplitudeFormula : String
5121:   cleanBranchAmplitude : Coeff
5122:   cleanBranchBasisIndex : Nat
5123:   cleanWorkspaceBranch : Bool
5124:   theoremNormalizer : Coeff
5125:   normalizedAmplitudeCorrect : ObligationRecord
5126:   nonzeroNormalizer : ObligationRecord
5127:   divisionSemantics : ObligationRecord
5128:   normalizerBound : ObligationRecord
5129:   orthogonalComponentCorrect : ObligationRecord
5130:   unitaryCompletion : ObligationRecord
5131:   theoremAmplitudeCorrect : ObligationRecord
5132: deriving Repr, DecidableEq
```

### GHL2025.lean:5555

```lean
5555: structure BandedSparseAccessPostSwapCleanup
5556:     (p : OneTermRobinParameters)
5557:     (source post pre : Fin (qubitDim (oneTermRobinTotalQubits p))) where
5558:   postSwap :
5559:     post.val = swapOracleImage p (bandedSparseAccessPaperImage p source.val)
5560:   preimage : post.val = bandedSparseAccessPaperImage p pre.val
5561:   preCleanInput : bandedSparseAccessPaperCleanInput p pre.val = true
5562:   preAddressBound : bandedSparseAccessPaperAddress p pre.val < (1 <<< p.n)
5563:   daggerEntry : (oneTermRobinGate_O_D_BS_dagger p).matrix pre post = Coeff.rat 1
5564:   preRowPreserved :
5565:     (bandedSparseAccessPaperColumnContract p pre.val).rowPreserved = true
5566:   preAddressWritten :
5567:     (bandedSparseAccessPaperColumnContract p pre.val).addressWritten = true
5568:   preAddressInRange :
5569:     (bandedSparseAccessPaperColumnContract p pre.val).addressInRange = true
5570:   preImageNoSpill :
5571:     (bandedSparseAccessPaperColumnContract p pre.val).imageNoSpill = true
5572:   postRow_eq_preRow :
5573:     (bandedSparseAccessPaperRegisters p post.val).rowValue =
5574:       (bandedSparseAccessPaperRegisters p pre.val).rowValue
5575:   postOd_eq_preAddress :
5576:     (bandedSparseAccessPaperRegisters p post.val).odRegisterValue =
5577:       bandedSparseAccessPaperAddress p pre.val
```

### GHL2025.lean:7419

```lean
7419: structure BandedSparseAccessGlobalSlotInverseOnRangeContract where
7420:   sourceAnchor : String
7421:   sourcePredicate : String
7422:   imageFunction : String
7423:   preimageCandidate : String
7424:   sourceIndex : Nat
7425:   sourceRegisters : BandedSparseAccessPaperRegisters
7426:   sourceInGlobalDomain : Bool
7427:   postSwapImageIndex : Nat
7428:   candidatePreimageIndex : Nat
7429:   candidateChecks : Bool
7430:   inverseOnRange : ObligationRecord
7431:   uniquePreimage : ObligationRecord
7432:   imageInjectiveOnGlobalSource : ObligationRecord
7433:   daggerCleanup : ObligationRecord
7434:   unitaryExtension : ObligationRecord
7435: deriving Repr, DecidableEq
```

### GHL2025.lean:8059

```lean
8059: inductive BandedSparseAccessCleanupScope where
8060:   | activeGlobalSource
8061:   | fullCleanDomain
8062:   | fullSpace
8063: deriving Repr, DecidableEq
```

### GHL2025.lean:8075

```lean
8075: structure BandedSparseAccessCleanupScopeDecision where
8076:   sourceAnchor : String
8077:   selectedScope : BandedSparseAccessCleanupScope
8078:   selectedPredicate : String
8079:   selectedEvidence : String
8080:   fullCleanDomainSelected : Bool
8081:   fullSpaceSelected : Bool
8082:   semanticCleanupPromotionAllowed : Bool
8083:   paperContractCleanup : ObligationRecord
8084:   fullCleanDomainCleanup : ObligationRecord
8085:   fullSpaceUnitaryExtension : ObligationRecord
8086: deriving Repr, DecidableEq
```

