import QuantumBlockEncoding.BlockEncoding
import QuantumBlockEncoding.CircuitSemantics

   
                                               

                                                                            
                                                                              
                                                                            
                                 
  

namespace QuantumBlockEncoding
namespace GHL2025

open CostExpr

structure OneTermRobinParameters where
  n : Nat
  kappa : Nat
  functionPieces : Nat
  polynomialDegreeCost : Nat
deriving Repr, DecidableEq

   
                                                               
                                                                 
                                     
                                                         
                                     
                      
def isBulkRow (K1 K2 i : Nat) : Bool :=
  K1 ≤ i && i ≤ K2

   
                                                                           
                                                                
                            
def isBoundaryRow (K1 K2 _gridSize : Nat) (j : Nat) : Bool :=
  j < K1 || K2 < j

   
                                                                
                                            
                                                              
                                                                               
                                                                     
                               
structure RobinRegisterPartition where
                                                                             
                   
  mfQubits : Nat
                                                                            
  indicatorQubit : Nat
                                                                   
  sparseIndexQubits : Nat
                                                                            
                         
  odPureAncillaQubits : Nat
                                                        
  systemQubits : Nat
                                                                                
  ancillaQubit : Nat
deriving Repr, DecidableEq

   
                                                                   
  
def RobinRegisterPartition.totalQubits (rp : RobinRegisterPartition) : Nat :=
  rp.mfQubits + rp.indicatorQubit + rp.sparseIndexQubits +
  rp.odPureAncillaQubits + rp.systemQubits + rp.ancillaQubit

   
                                                    
                       
def defaultRobinRegisterPartition (p : OneTermRobinParameters) : RobinRegisterPartition where
  mfQubits := clog2 p.n + clog2 p.functionPieces + 3
  indicatorQubit := 1
  sparseIndexQubits := clog2 p.kappa
  odPureAncillaQubits := p.n - clog2 p.kappa
  systemQubits := p.n
  ancillaQubit := 1

   
                                                                
                                                                       
        

                                                                        
                                                            
                                                                           
                                                                               
                                                                           
                                                              
  
def RobinRegisterPartition.totalPureAncillas (rp : RobinRegisterPartition) : Nat :=
  rp.odPureAncillaQubits + rp.ancillaQubit

   
                                    
                                                              
  
def oneTermRobinResourceExpr : AsymptoticResource where
  gates :=
    (CostExpr.atom "sum_g(Q_g)") * (CostExpr.atom "n") * (CostExpr.log (CostExpr.atom "n")) +
    (CostExpr.atom "kappa") * (CostExpr.atom "n")
  pureAncilla := (2 : CostExpr) * CostExpr.atom "n"

                                                          
                                                                                   
                      
def deviatingIndices (K1 K2 gridSize : Nat) : Nat :=
  K1 + gridSize - K2

   
                                                                                  
                                                                    
                                                           
                                                                        
                      
def oneTermRobinPreciseResourceExpr : AsymptoticResource where
  gates :=
    (CostExpr.atom "sum_g(Q_g)") * (CostExpr.atom "n") * (CostExpr.log (CostExpr.atom "n")) +
    (CostExpr.atom "kappa") * (CostExpr.atom "(K1 + 2^n - K2)") * (CostExpr.atom "n")
  pureAncilla := (2 : CostExpr) * CostExpr.atom "n"

                                                                              
                                                                           
                      
theorem deviatingIndices_example :
    deviatingIndices 2 (gridSize 3 - 3) (gridSize 3) = 5 := rfl

                                                                              
def oneTermRobinResource (p : OneTermRobinParameters) : Resource :=
  Resource.ofCounts
    (p.polynomialDegreeCost * p.n * clog2 p.n + p.kappa * p.n)
    0
    (2 * p.n)

theorem oneTermRobin_pureAncilla (p : OneTermRobinParameters) :
    (oneTermRobinResource p).pureAncilla = 2 * p.n := rfl

   
                                                      
                                                    
                                               
                                                                   
  
def oneTermRobinLayout (p : OneTermRobinParameters) : RegisterLayout where
  systemQubits := clog2 (gridSize p.n)
  signalQubits := clog2 p.n + clog2 p.functionPieces + clog2 p.kappa + 4
  pureAncillas := 2 * p.n

   
                                                          
                                                          
                                                  
                                                                      
                                                                   
                                                     
                                             
                                        
                                                      
                                                              
                       
def oneTermRobinCircuit : Circuit :=
  [ Gate.oracleCall "U_indic"
  , Gate.oracleCall "O_DT^S"
  , Gate.oracleCall "Ry_boundary"
  , Gate.oracleCall "O_D^BS"
  , Gate.oracleCall "O_f"
  , Gate.swap 0 0                                                      
  , Gate.oracleCall "(O_D^BS)^†"
  ]

   
                                            

                                                                               
                                                                            
                                                                            
                                                                            
                                                               
                                              
def oneTermRobinTheoremFacingFig4Circuit : Circuit :=
  [ Gate.oracleCall "H_W^(kappa)"
  , Gate.oracleCall "U_indic"
  , Gate.oracleCall "O_DT^S"
  , Gate.oracleCall "Ry_boundary"
  , Gate.oracleCall "O_DT^BS"
  , Gate.oracleCall "U_indic^dagger"
  , Gate.oracleCall "O_f"
  , Gate.swap 0 0
  , Gate.oracleCall "(O_D^BS)^dagger"
  , Gate.oracleCall "(H_W^(kappa))^dagger"
  ]

   
                                                                             

                                                             
                                                                                
                                                          
  
theorem oneTermRobinTheoremFacingFig4Circuit_gateList :
    oneTermRobinTheoremFacingFig4Circuit =
      [ Gate.oracleCall "H_W^(kappa)"
      , Gate.oracleCall "U_indic"
      , Gate.oracleCall "O_DT^S"
      , Gate.oracleCall "Ry_boundary"
      , Gate.oracleCall "O_DT^BS"
      , Gate.oracleCall "U_indic^dagger"
      , Gate.oracleCall "O_f"
      , Gate.swap 0 0
      , Gate.oracleCall "(O_D^BS)^dagger"
      , Gate.oracleCall "(H_W^(kappa))^dagger"
      ] := rfl

   
                                                                           
                            

                                                                            
                                                                      
                             
  
theorem oneTermRobinActiveBackendCircuit_gateList :
    oneTermRobinCircuit =
      [ Gate.oracleCall "U_indic"
      , Gate.oracleCall "O_DT^S"
      , Gate.oracleCall "Ry_boundary"
      , Gate.oracleCall "O_D^BS"
      , Gate.oracleCall "O_f"
      , Gate.swap 0 0
      , Gate.oracleCall "(O_D^BS)^†"
      ] := rfl

                                                                                 
def oneTermRobinNormalizer : Coeff :=
  Coeff.mul (Coeff.mul (Coeff.symbol "N_D") (Coeff.symbol "N_f")) (Coeff.symbol "kappa")

   
                                                               
                                                                               
                                                                 
                                     
                                                   
  
def oneTermRobinSpec (p : OneTermRobinParameters)
    (mat : Matrix (gridSize p.n) (gridSize p.n) Coeff) :
    BlockEncodingSpec Coeff (gridSize p.n) (gridSize p.n) where
  matrix := mat
  normalizer := oneTermRobinNormalizer
  error := Coeff.rat 0
  layout := oneTermRobinLayout p
  circuit := oneTermRobinCircuit
  resource := oneTermRobinResource p

                                                            
theorem oneTermRobinSpec_ancilla (p : OneTermRobinParameters)
    (mat : Matrix (gridSize p.n) (gridSize p.n) Coeff) :
    (oneTermRobinSpec p mat).resource.pureAncilla = 2 * p.n := rfl

   
                                                                          
                                                                                
                   
  
theorem oneTermRobinSpec_circuitCost :
    Circuit.resource oneTermRobinCircuit = Resource.ofCountsWithDepth 0 3 6 0 9 := rfl

                                                                                 
                                          
@[simp] theorem oneTermRobinNormalizer_eval (env : String → Rat) :
    Coeff.evalWith env oneTermRobinNormalizer = env "N_D" * env "N_f" * env "kappa" := by
  simp [oneTermRobinNormalizer]

                                                                    
def oneTermRobinClaim : ConstructionClaim where
  name := "one-term-robin-block-encoding"
  source := "Guseynov-Huang-Liu 2025, Theorem one-term block-encoding"
  target := "A_k = f(x) * d^m/dx^m with Robin boundary corrections"
  normalization := "N_D * N_f * kappa"
  layout := "ceil(log2 n) + ceil(log2 G_f) + ceil(log2 kappa) + 4 signal qubits, 2n pure ancillas"
  resource := oneTermRobinResourceExpr

                                                                 
def oneDimHamiltonianResourceExpr : AsymptoticResource where
  gates :=
    CostExpr.atom "sum_g(Q_v_g) * n * log(n)" +
    CostExpr.sum "k < eta" (CostExpr.atom "kappa_k * n + sum_g(Q_fkg) * n * log(n)") +
    CostExpr.atom "n_xi * log(n_xi)"
  pureAncilla := (2 : CostExpr) * CostExpr.atom "n" + (2 : CostExpr)

                                                                    
def oneDimHamiltonianClaim : ConstructionClaim where
  name := "one-dimensional-pde-hamiltonian-block-encoding"
  source := "Guseynov-Huang-Liu 2025, Theorem one-dimensional block-encoding"
  target := "H = S1 tensor x_xi + S2 tensor I_xi"
  normalization := "O(kappa * ||H||_max)"
  layout := "ceil(log2 n_xi)+ceil(log2 n)+ceil(log2 G)+ceil(log2 kappa)+ceil(log2 eta)+7 signal qubits"
  resource := oneDimHamiltonianResourceExpr

                                                                  
def multiDimHamiltonianResourceExpr : AsymptoticResource where
  gates :=
    CostExpr.atom "M * Q_PET * G * Q * (d*n*log(n)+n_s*log(n_s))" +
    CostExpr.atom "n_xi * log(n_xi)" +
    CostExpr.atom "d * eta * kappa * n"
  pureAncilla := CostExpr.atom "O(n)"

                                                                                  
def multiDimHamiltonianClaim : ConstructionClaim where
  name := "multidimensional-pde-hamiltonian-block-encoding"
  source := "Guseynov-Huang-Liu 2025, Theorem multi-dimensional block-encoding"
  target := "H = I tensor p_s tensor I_xi + S1^(d) tensor x_xi + S2^(d) tensor I_xi"
  normalization := "O(kappa * ||H||_max)"
  layout := "d*ceil(log2 n)+ceil(log2 n_s)+ceil(log2 n_xi)+ceil(log2 G)+ceil(log2 kappa)+ceil(log2 eta)+ceil(log2 M)+4d+5 signal qubits"
  resource := multiDimHamiltonianResourceExpr

                                                                      
                                                                             
                                             
structure ObligationRecord where
  description : String
  source : String
  proved : Bool := false
deriving Repr, DecidableEq

                                                                     
                                                                   
                                                                             
                                                               
structure RobinCircuitSkeleton where
                                                                            
  indicatorOracle : String
                                                   
  K1 : Nat
                                                   
  K2 : Nat
                                                            
                                 
  sparseAmplitudeOracleDT : String
                                                                        
  bandedSparseAccessOracleD : String
                                                                        
                                                
  bandedSparseAccessOracleD_dagger : String
                                                                                    
                        
  controlledRyBoundary : String
                                                                                       
  functionOracle : String
                                                                                
  swapOperation : String
                                                                                    
  mergeFrame : String
                                                                                        
  mfSignalQubits : Nat
                                                                                  
  kappaSignalQubits : Nat
                                                                   
                                                
  pureAncillaODRegister : Nat
deriving Repr, DecidableEq

                                                           
                                               
                                                                 
                                                
                                               
                 
structure RobinGamma1 where
                                                                         
  kappa : Nat
                                                      
  K1 : Nat
                                                      
  K2 : Nat
                                        
  gridSize : Nat
                                                       
                                                                                         
  boundaryNormalizer : Coeff
                                             
                                                                    
                                                                         
                                 
  bulkNormalizer : Coeff
                                                              
  mfQubits : Nat
deriving Repr, DecidableEq

                                                           
                                                                         
structure RobinGamma2 where
                                                 
  kappa : Nat
                                                
  K1 : Nat
                                                
  K2 : Nat
                                  
  gridSize : Nat
                                                                          
  normalizer : Coeff
                                                                               
  hasOrthogonalRemainder : Bool
deriving Repr, DecidableEq

                                                           
                                                        
structure RobinGamma3 where
                                                 
  kappa : Nat
                                                
  K1 : Nat
                                                
  K2 : Nat
                                  
  gridSize : Nat
                                                                          
  normalizer : Coeff
                                                                               
  hasOrthogonalRemainder : Bool
                                                                                                 
  pureAncillaQubits : Nat
deriving Repr, DecidableEq

                                                                                  
                                                                                      
                                           
structure RobinWavefunctionDecomposition where
                                                     
  gamma1 : RobinGamma1
                                                                     
  gamma2 : RobinGamma2
                                                                 
  gamma3 : RobinGamma3
                                              
  kappa : Nat
                                             
  K1 : Nat
                                             
  K2 : Nat
                                   
  gridSize : Nat
deriving Repr, DecidableEq

                                                                
                                           
def defaultRobinWavefunctionDecomposition (p : OneTermRobinParameters) : RobinWavefunctionDecomposition where
  gamma1 := {
    kappa := p.kappa
    K1 := 2
    K2 := gridSize p.n - 3
    gridSize := gridSize p.n
    boundaryNormalizer := Coeff.mul (Coeff.symbol "N_D") (Coeff.symbol "sqrt(kappa)")
    bulkNormalizer := Coeff.symbol "sqrt(kappa)"
    mfQubits := clog2 p.n + clog2 p.functionPieces + 3
  }
  gamma2 := {
    kappa := p.kappa
    K1 := 2
    K2 := gridSize p.n - 3
    gridSize := gridSize p.n
    normalizer := Coeff.mul (Coeff.symbol "N_D") (Coeff.symbol "sqrt(kappa)")
    hasOrthogonalRemainder := true
  }
  gamma3 := {
    kappa := p.kappa
    K1 := 2
    K2 := gridSize p.n - 3
    gridSize := gridSize p.n
    normalizer := Coeff.mul (Coeff.mul (Coeff.symbol "N_D") (Coeff.symbol "N_f")) (Coeff.symbol "kappa")
    hasOrthogonalRemainder := true
    pureAncillaQubits := p.n - clog2 p.kappa + 1
  }
  kappa := p.kappa
  K1 := 2
  K2 := gridSize p.n - 3
  gridSize := gridSize p.n

                                                                      
                                                                           
                                                                    
                                                                      
structure RobinProofObligations where
                                                                      
  indicatorUnitary : ObligationRecord := {
    description := "U_indic(K1,K2) implements the bulk/boundary indicator correctly"
    source := "Guseynov-Huang-Liu 2025, U_indic definition and Fig. 1-term Robin, arXiv:2506.20478"
    proved := false
  }
                                                                         
  sparseAmplitudeOracleCorrect : ObligationRecord := {
    description := "O_DT^S prepares the D^T sparse-amplitude branch D_j^(s)/N_D from Lemma 3, Eq. (20)"
    source := "Guseynov-Huang-Liu 2025, Lemma 3, Eq. (20), arXiv:2506.20478"
    proved := false
  }
                                                                        
  bandedSparseAccessCorrect : ObligationRecord := {
    description := "O_D^BS maps |0>^(n-l)|s>^l|i>^n to |r_si>^n|i>^n and supports dagger cleanup"
    source := "Guseynov-Huang-Liu 2025, Lemma 1 and Fig. 1-term Robin, arXiv:2506.20478"
    proved := false
  }
                                                                      
  functionOracleCorrect : ObligationRecord := {
    description := "O_f block-encodes the piecewise polynomial f(x) discretized on the grid"
    source := "Guseynov-Huang-Liu 2025, Theorem amplitude-oracle for piece-wise polynomial function and Fig. 1-term Robin, arXiv:2506.20478"
    proved := false
  }
                                                                      
  controlledRyCorrect : ObligationRecord := {
    description := "R_y rotation angles theta_j^s = arccos(D_j^(s)/N_D) are correct"
    source := "Guseynov-Huang-Liu 2025, Fig. 1-term Robin and boundary Ry angle formula, arXiv:2506.20478"
    proved := false
  }
                                           
  circuitUnitary : ObligationRecord := {
    description := "The full one-term Robin circuit U_Ak^(1) is unitary"
    source := "Guseynov-Huang-Liu 2025, one-term Robin theorem, arXiv:2506.20478"
    proved := false
  }
                                                                          
  blockExtraction : ObligationRecord := {
    description := "Block extraction yields A_k / alpha where alpha = N_D * N_f * kappa"
    source := "Guseynov-Huang-Liu 2025, one-term Robin theorem, arXiv:2506.20478"
    proved := false
  }
                                                                               
  resourceBound : ObligationRecord := {
    description := "Gate count O(sum_g Q_g n log n + kappa n), pure ancillas 2n"
    source := "Guseynov-Huang-Liu 2025, one-term Robin theorem resource claim, arXiv:2506.20478"
    proved := false
  }
                                                                                        
  ancillaCleanup : ObligationRecord := {
    description := "All 2n pure ancilla qubits are returned to |0⟩ state"
    source := "Guseynov-Huang-Liu 2025, Fig. 1-term Robin caption, arXiv:2506.20478"
    proved := false
  }
                                                                                 
  ghostPointElimination : ObligationRecord := {
    description := "Ghost-point elimination via Robin boundary relation produces correct boundary rows"
    source := "Guseynov-Huang-Liu 2025, Robin boundary-row derivation, arXiv:2506.20478"
    proved := false
  }
deriving Repr, DecidableEq

                                                                 
                                                                        
def defaultRobinCircuitSkeleton (p : OneTermRobinParameters) : RobinCircuitSkeleton where
  indicatorOracle := "U_indic"
  K1 := 2                                                     
  K2 := gridSize p.n - 3                                      
  sparseAmplitudeOracleDT := "O_DT^S"
  bandedSparseAccessOracleD := "O_D^BS"
  bandedSparseAccessOracleD_dagger := "(O_D^BS)^†"
  controlledRyBoundary := "Ry_boundary"
  functionOracle := "O_f"
  swapOperation := "SWAP"
  mergeFrame := "merge"
  mfSignalQubits := clog2 p.n + clog2 p.functionPieces + 3
  kappaSignalQubits := clog2 p.kappa
  pureAncillaODRegister := p.n - clog2 p.kappa

   
                                                                           

                                                      
                                                                    
                                                                        
                                                                              
                                                                          
                                                      
structure BandedSparseAccessPaperContract where
  sourceAnchor : String
  rowRegisterQubits : Nat
  paddedZeroQubits : Nat
  sparseIndexQubits : Nat
  outputAddressQubits : Nat
  inputKet : String
  outputKet : String
  imageFormula : String
  cleanInputDomain : ObligationRecord
  widthCompatible : ObligationRecord
  addressRange : ObligationRecord
  noSpill : ObligationRecord
  forwardCorrect : ObligationRecord
  daggerCleanup : ObligationRecord
  unitaryExtension : ObligationRecord
deriving Repr, DecidableEq

   
                                                                    

                                                                             
                                                                               
                                                                         
  
def defaultBandedSparseAccessPaperContract
    (p : OneTermRobinParameters) : BandedSparseAccessPaperContract where
  sourceAnchor := "Guseynov-Huang-Liu 2025, Lemma 1, arXiv:2506.20478"
  rowRegisterQubits := p.n
  paddedZeroQubits := p.n - clog2 p.kappa
  sparseIndexQubits := clog2 p.kappa
  outputAddressQubits := p.n
  inputKet := "|0>^(n-l)|s>^l|i>^n"
  outputKet := "|r_si>^n|i>^n"
  imageFormula := "r_si = r_s0 + i mod 2^n"
  cleanInputDomain := {
    description := "Lemma 1 source equation applies to columns whose padded zero register is |0>^(n-l)"
    source := "Guseynov-Huang-Liu 2025, Lemma 1, arXiv:2506.20478"
    proved := false
  }
  widthCompatible := {
    description := "padded zero register plus sparse-index register has width n"
    source := "Guseynov-Huang-Liu 2025, Lemma 1, arXiv:2506.20478"
    proved := false
  }
  addressRange := {
    description := "the written address r_si is an n-bit value before it is placed in the O_D^BS register"
    source := "Guseynov-Huang-Liu 2025, Lemma 1, arXiv:2506.20478"
    proved := false
  }
  noSpill := {
    description := "bandedSparseAccessPaperImage changes only the n-bit O_D^BS address register and does not spill into indicator or m_f bits"
    source := "Guseynov-Huang-Liu 2025, Lemma 1 and Fig. 1-term Robin, arXiv:2506.20478"
    proved := false
  }
  forwardCorrect := {
    description := "O_D^BS maps |0>^(n-l)|s>^l|i>^n to |r_si>^n|i>^n"
    source := "Guseynov-Huang-Liu 2025, Lemma 1, arXiv:2506.20478"
    proved := false
  }
  daggerCleanup := {
    description := "(O_D^BS)^dagger cleans the padded sparse-index register after SWAP"
    source := "Guseynov-Huang-Liu 2025, Fig. 1-term Robin and Lemma 1, arXiv:2506.20478"
    proved := false
  }
  unitaryExtension := {
    description := "extend the Lemma 1 clean-input image to a full unitary on non-clean padded-register columns"
    source := "Guseynov-Huang-Liu 2025, Lemma 1, arXiv:2506.20478"
    proved := false
  }

                                                                               
                                                                                                       
structure DerivativeOracleContract (n : Nat) where
  stencil : Stencil
  bandwidth : Nat
  matrix : Matrix (gridSize n) (gridSize n) Coeff
                                                                         
                      
  sparseCorrect : ObligationRecord
  bandwidth_eq : bandwidth = stencil.width

                                                                               
                                                                                                     
structure FunctionOracleContract (n : Nat) where
  functionPieces : Nat
  normalizerBound : Coeff
                                                                     
                      
  amplitudeCorrect : ObligationRecord

                                                                                 
                                                                        
                                                                                     
def derivativeOracleResource (n : Nat) (s : Stencil) : Resource :=
  bandedSparseAccessResource n s.leftRadius

                                                                          
@[simp] theorem derivativeOracleResource_pureAncilla (n : Nat) (s : Stencil) :
    (derivativeOracleResource n s).pureAncilla = n - 1 := rfl

                                                                                
                                                                 
                                   
                                                                    
                                                 
                                                              
structure OneTermRobinTheoremData where
                                                                    
  alpha : Coeff
                                                                                       
  signalQubits : Nat
                                                                              
  error : Coeff
                                                                        
  gatesBound : String
                                                
  pureAncillas : Nat
                                                                    
  obligations : RobinProofObligations
deriving Repr, DecidableEq

                                                                                  
def defaultOneTermRobinTheoremData (p : OneTermRobinParameters) : OneTermRobinTheoremData where
  alpha := oneTermRobinNormalizer
  signalQubits := clog2 p.n + clog2 p.functionPieces + clog2 p.kappa + 4
  error := Coeff.rat 0
  gatesBound := "O(sum_g Q_g n log n + kappa n)"
  pureAncillas := 2 * p.n
  obligations := {}

   
                                                                
                                                          
                                   
                                                         
                      
structure RobinBoundaryRotationAngle where
                                                                     
  row : Nat
                                                          
  sparseIndex : Nat
                                                               
  matrixEntry : Coeff
                                                             
                                                              
                        
  arccosArgument : Coeff
deriving Repr, DecidableEq

   
                                                                                  
                                                                         
                                                                      
                                 
structure RobinBoundaryRotationSet where
                                                
  K1 : Nat
                                                
  K2 : Nat
                                        
  gridSize : Nat
                                                                                    
  kappa : Nat
                                                    
  normalizerND : Coeff
                                                                            
                        
  angles : List RobinBoundaryRotationAngle
deriving Repr, DecidableEq

   
                                             
                                                                   
                      
def RobinBoundaryRotationSet.expectedCount (rs : RobinBoundaryRotationSet) : Nat :=
  rs.kappa * deviatingIndices rs.K1 rs.K2 rs.gridSize

def importedClaims : List ConstructionClaim :=
  [oneTermRobinClaim, oneDimHamiltonianClaim, multiDimHamiltonianClaim]

                                                              

                                                                          
                                                                         
                                                                        
                                                
                                           

   
                                                     
                                                              
                      
def oneTermRobinTotalQubits (p : OneTermRobinParameters) : Nat :=
  (defaultRobinRegisterPartition p).totalQubits

   
                                                                              
                                                                  
                      
def effectiveRobinSignalQubits (p : OneTermRobinParameters) : Nat :=
  (defaultRobinRegisterPartition p).totalQubits - clog2 (gridSize p.n)

   
                                                      

                                    
                                                                         
                                                                
                                                         
                 
  
theorem defaultOneTermRobinTheoremData_signalQubits_eq_layout
    (p : OneTermRobinParameters) :
    (defaultOneTermRobinTheoremData p).signalQubits =
      (oneTermRobinLayout p).signalQubits := rfl

   
                                                                    
                            
  
theorem defaultOneTermRobinTheoremData_pureAncillas_eq_layout
    (p : OneTermRobinParameters) :
    (defaultOneTermRobinTheoremData p).pureAncillas =
      (oneTermRobinLayout p).pureAncillas := rfl

   
                                                                  
                   
  
theorem defaultOneTermRobinTheoremData_pureAncillas_eq_resource
    (p : OneTermRobinParameters) :
    (defaultOneTermRobinTheoremData p).pureAncillas =
      (oneTermRobinResource p).pureAncilla := rfl

   
                                                                  

                                                                              
                                                                               
                                                                          
                                                                         
      
  
theorem effectiveRobinSignalQubits_eq_layout_signal_plus_visibleWorkspace
    (p : OneTermRobinParameters) :
    effectiveRobinSignalQubits p =
      (oneTermRobinLayout p).signalQubits +
        (defaultRobinRegisterPartition p).odPureAncillaQubits + 1 := by
  simp [effectiveRobinSignalQubits, oneTermRobinLayout,
    defaultRobinRegisterPartition, RobinRegisterPartition.totalQubits,
    clog2_gridSize]
  omega

   
                                                                       

                                                                          
                                                                             
                                                                           
                  
  
theorem effectiveRobinSignalQubits_eq_theoremData_signal_plus_visibleWorkspace
    (p : OneTermRobinParameters) :
    effectiveRobinSignalQubits p =
      (defaultOneTermRobinTheoremData p).signalQubits +
        (defaultRobinRegisterPartition p).odPureAncillaQubits + 1 := by
  rw [effectiveRobinSignalQubits_eq_layout_signal_plus_visibleWorkspace,
    defaultOneTermRobinTheoremData_signalQubits_eq_layout]

   
                                                             
                                                                       
                                          
                 
def robinIndicatorBitPosition (p : OneTermRobinParameters) : Nat :=
  let rp := defaultRobinRegisterPartition p
  rp.ancillaQubit + rp.systemQubits + rp.odPureAncillaQubits + rp.sparseIndexQubits

   
                                                          
                                                                                    

                                                                       
                  
                                             
                                             
                                    
                                                     
                                                     
                                                                                     
                    
def robinSparseColumnMap (n s i : Nat) : Nat :=
  let N := gridSize n
  let K1 := 2
  let K2 := N - 3
  if K1 ≤ i ∧ i ≤ K2 then
    if s < 5 then i - 2 + s else i
  else if i = 0 then
    if s < 3 then s else i
  else if i = 1 then
    if s < 4 then s else i
  else if i = N - 2 then
    if s < 4 then N - 4 + s else i
  else if i = N - 1 then
    if s < 3 then N - 3 + s else i
  else i

   
                                                                            

                                                                 
                                                                          
                                                                            
                                                                              
       
                                                         
                                                             
                 
  
def oneTermRobinGlobalSparseOffset (n s : Nat) : Nat :=
  let N := gridSize n
  match s with
  | 0 => N - 2
  | 1 => N - 1
  | 2 => 0
  | 3 => 1
  | 4 => 2
  | 5 => N - 3
  | 6 => 3
  | _ => 0

   
                                                       

                                                                      
                                                  
  
def oneTermRobinGlobalSparseAddress (n s i : Nat) : Nat :=
  (oneTermRobinGlobalSparseOffset n s + i) % gridSize n

                                                                       
theorem oneTermRobinGlobalSparseAddress_lt_gridSize
    (n s i : Nat) :
    oneTermRobinGlobalSparseAddress n s i < gridSize n := by
  unfold oneTermRobinGlobalSparseAddress
  exact Nat.mod_lt _ (by
    simp [gridSize]
    exact Nat.pow_pos (by decide : 0 < 2))

   
                                                                          
             

                                                                       
                                                            
  
def oneTermRobinGlobalSparseInverseSlot (s : Nat) : Nat :=
  match s with
  | 0 => 4
  | 1 => 3
  | 2 => 2
  | 3 => 1
  | 4 => 0
  | 5 => 6
  | 6 => 5
  | _ => 2

                                                                            
theorem oneTermRobinGlobalSparseInverseSlot_lt_eight (s : Nat) :
    oneTermRobinGlobalSparseInverseSlot s < 8 := by
  unfold oneTermRobinGlobalSparseInverseSlot
  split <;> decide

                                                                           
theorem oneTermRobinGlobalSparseInverseSlot_lt_seven
    {s : Nat} (hs : s < 7) :
    oneTermRobinGlobalSparseInverseSlot s < 7 := by
  have hs_cases :
      s = 0 ∨ s = 1 ∨ s = 2 ∨ s = 3 ∨
        s = 4 ∨ s = 5 ∨ s = 6 := by
    omega
  rcases hs_cases with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals simp [oneTermRobinGlobalSparseInverseSlot]

   
                                                                          
                                                                              
                                                               
  
theorem oneTermRobinGlobalSparseInverseSlot_involutive_of_lt_seven
    {s : Nat} (hs : s < 7) :
    oneTermRobinGlobalSparseInverseSlot
        (oneTermRobinGlobalSparseInverseSlot s) = s := by
  have hs_cases :
      s = 0 ∨ s = 1 ∨ s = 2 ∨ s = 3 ∨
        s = 4 ∨ s = 5 ∨ s = 6 := by
    omega
  rcases hs_cases with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals simp [oneTermRobinGlobalSparseInverseSlot]

   
                                                                           

                                                                             
                                                                          
                  
  
theorem oneTermRobinGlobalSparseInverseSlot_injective_of_lt_seven
    {s t : Nat} (hs : s < 7) (ht : t < 7)
    (h : oneTermRobinGlobalSparseInverseSlot s =
      oneTermRobinGlobalSparseInverseSlot t) :
    s = t := by
  have hsInv :=
    oneTermRobinGlobalSparseInverseSlot_involutive_of_lt_seven hs
  have htInv :=
    oneTermRobinGlobalSparseInverseSlot_involutive_of_lt_seven ht
  calc
    s = oneTermRobinGlobalSparseInverseSlot
          (oneTermRobinGlobalSparseInverseSlot s) := hsInv.symm
    _ = oneTermRobinGlobalSparseInverseSlot
          (oneTermRobinGlobalSparseInverseSlot t) := by rw [h]
    _ = t := htInv

   
                                                                     

                                                                            
                                                                        
                                                                         
                                                     
  
theorem oneTermRobinGlobalSparseAddress_inverseSlot_address_eq
    {n s i : Nat} (hn : 3 ≤ n) (hs : s < 8) (hi : i < gridSize n) :
    oneTermRobinGlobalSparseAddress n (oneTermRobinGlobalSparseInverseSlot s)
        (oneTermRobinGlobalSparseAddress n s i) = i := by
  have hN8 : 8 ≤ gridSize n := by
    have hpow : 2 ^ 3 ≤ 2 ^ n :=
      Nat.pow_le_pow_right (by decide : 0 < 2) hn
    simpa [gridSize] using hpow
  have hs_cases :
      s = 0 ∨ s = 1 ∨ s = 2 ∨ s = 3 ∨
        s = 4 ∨ s = 5 ∨ s = 6 ∨ s = 7 := by
    omega
  rcases hs_cases with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · calc
      (2 + ((gridSize n - 2 + i) % gridSize n)) % gridSize n
          = (((gridSize n - 2 + i) % gridSize n) + 2) % gridSize n := by
            rw [Nat.add_comm]
      _ = (gridSize n - 2 + i + 2) % gridSize n := by
            rw [Nat.mod_add_mod]
      _ = (i + gridSize n) % gridSize n := by
            congr 1
            omega
      _ = i % gridSize n := by
            rw [Nat.add_mod_right]
      _ = i := Nat.mod_eq_of_lt hi
  · calc
      (1 + ((gridSize n - 1 + i) % gridSize n)) % gridSize n
          = (((gridSize n - 1 + i) % gridSize n) + 1) % gridSize n := by
            rw [Nat.add_comm]
      _ = (gridSize n - 1 + i + 1) % gridSize n := by
            rw [Nat.mod_add_mod]
      _ = (i + gridSize n) % gridSize n := by
            congr 1
            omega
      _ = i % gridSize n := by
            rw [Nat.add_mod_right]
      _ = i := Nat.mod_eq_of_lt hi
  · simpa [oneTermRobinGlobalSparseAddress, oneTermRobinGlobalSparseOffset,
      oneTermRobinGlobalSparseInverseSlot] using Nat.mod_eq_of_lt hi
  · calc
      (gridSize n - 1 + ((1 + i) % gridSize n)) % gridSize n
          = (((1 + i) % gridSize n) + (gridSize n - 1)) % gridSize n := by
            rw [Nat.add_comm]
      _ = (1 + i + (gridSize n - 1)) % gridSize n := by
            rw [Nat.mod_add_mod]
      _ = (i + gridSize n) % gridSize n := by
            congr 1
            omega
      _ = i % gridSize n := by
            rw [Nat.add_mod_right]
      _ = i := Nat.mod_eq_of_lt hi
  · calc
      (gridSize n - 2 + ((2 + i) % gridSize n)) % gridSize n
          = (((2 + i) % gridSize n) + (gridSize n - 2)) % gridSize n := by
            rw [Nat.add_comm]
      _ = (2 + i + (gridSize n - 2)) % gridSize n := by
            rw [Nat.mod_add_mod]
      _ = (i + gridSize n) % gridSize n := by
            congr 1
            omega
      _ = i % gridSize n := by
            rw [Nat.add_mod_right]
      _ = i := Nat.mod_eq_of_lt hi
  · calc
      (3 + ((gridSize n - 3 + i) % gridSize n)) % gridSize n
          = (((gridSize n - 3 + i) % gridSize n) + 3) % gridSize n := by
            rw [Nat.add_comm]
      _ = (gridSize n - 3 + i + 3) % gridSize n := by
            rw [Nat.mod_add_mod]
      _ = (i + gridSize n) % gridSize n := by
            congr 1
            omega
      _ = i % gridSize n := by
            rw [Nat.add_mod_right]
      _ = i := Nat.mod_eq_of_lt hi
  · calc
      (gridSize n - 3 + ((3 + i) % gridSize n)) % gridSize n
          = (((3 + i) % gridSize n) + (gridSize n - 3)) % gridSize n := by
            rw [Nat.add_comm]
      _ = (3 + i + (gridSize n - 3)) % gridSize n := by
            rw [Nat.mod_add_mod]
      _ = (i + gridSize n) % gridSize n := by
            congr 1
            omega
      _ = i % gridSize n := by
            rw [Nat.add_mod_right]
      _ = i := Nat.mod_eq_of_lt hi
  · simpa [oneTermRobinGlobalSparseAddress, oneTermRobinGlobalSparseOffset,
      oneTermRobinGlobalSparseInverseSlot] using Nat.mod_eq_of_lt hi

                                                                                           
private theorem mod_add_eq_self_imp_offset_zero
    {N a i : Nat} (ha : a < N) (hi : i < N)
    (h : (a + i) % N = i) : a = 0 := by
  by_cases hlt : a + i < N
  · have hmod : (a + i) % N = a + i := Nat.mod_eq_of_lt hlt
    omega
  · have hge : a + i ≥ N := by omega
    have hsum_lt : a + i < 2 * N := by omega
    have hsub_lt : a + i - N < N := by omega
    have hmod : (a + i) % N = a + i - N := by
      rw [Nat.mod_eq_sub_mod hge]
      exact Nat.mod_eq_of_lt hsub_lt
    omega

                                                                             
private theorem eq_zero_or_eq_base_of_mod_eq_zero_of_lt_two_mul
    {N a : Nat} (ha : a < 2 * N) (h : a % N = 0) :
    a = 0 ∨ a = N := by
  by_cases hlt : a < N
  · left
    have hmod : a % N = a := Nat.mod_eq_of_lt hlt
    omega
  · right
    have hge : a ≥ N := by omega
    have hsub_lt : a - N < N := by omega
    have hmod : a % N = a - N := by
      rw [Nat.mod_eq_sub_mod hge]
      exact Nat.mod_eq_of_lt hsub_lt
    omega

                                                                                 
theorem oneTermRobinGlobalSparseOffset_lt_gridSize_of_lt_seven
    {n s : Nat} (hn : 3 ≤ n) (hs : s < 7) :
    oneTermRobinGlobalSparseOffset n s < gridSize n := by
  have hN8 : 8 ≤ gridSize n := by
    have hpow : 2 ^ 3 ≤ 2 ^ n :=
      Nat.pow_le_pow_right (by decide : 0 < 2) hn
    simpa [gridSize] using hpow
  have hs_cases :
      s = 0 ∨ s = 1 ∨ s = 2 ∨ s = 3 ∨
        s = 4 ∨ s = 5 ∨ s = 6 := by
    omega
  rcases hs_cases with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals simp [oneTermRobinGlobalSparseOffset] <;> omega

   
                                                                          
                                    
  
theorem oneTermRobinGlobalSparseAddress_comp_eq_mod_offset_sum
    {n s t i : Nat} :
    oneTermRobinGlobalSparseAddress n t
        (oneTermRobinGlobalSparseAddress n s i) =
      (((oneTermRobinGlobalSparseOffset n t +
          oneTermRobinGlobalSparseOffset n s) % gridSize n) + i) %
        gridSize n := by
  unfold oneTermRobinGlobalSparseAddress
  calc
    (oneTermRobinGlobalSparseOffset n t +
          ((oneTermRobinGlobalSparseOffset n s + i) % gridSize n)) %
        gridSize n
        = (((oneTermRobinGlobalSparseOffset n s + i) % gridSize n) +
            oneTermRobinGlobalSparseOffset n t) % gridSize n := by
          rw [Nat.add_comm]
    _ = (oneTermRobinGlobalSparseOffset n s + i +
            oneTermRobinGlobalSparseOffset n t) % gridSize n := by
          rw [Nat.mod_add_mod]
    _ = (oneTermRobinGlobalSparseOffset n t +
            oneTermRobinGlobalSparseOffset n s + i) % gridSize n := by
          congr 1
          omega
    _ = (((oneTermRobinGlobalSparseOffset n t +
            oneTermRobinGlobalSparseOffset n s) % gridSize n) + i) %
          gridSize n := by
          rw [Nat.mod_add_mod]

   
                                                                               
                                       

                                                                         
                                                                        
  
theorem oneTermRobinGlobalSparseOffset_sum_mod_eq_zero_unique_of_lt_seven
    {n s t : Nat} (hn : 3 ≤ n) (hs : s < 7) (ht : t < 7)
    (hzero :
      (oneTermRobinGlobalSparseOffset n t +
          oneTermRobinGlobalSparseOffset n s) % gridSize n = 0) :
    t = oneTermRobinGlobalSparseInverseSlot s := by
  have hN8 : 8 ≤ gridSize n := by
    have hpow : 2 ^ 3 ≤ 2 ^ n :=
      Nat.pow_le_pow_right (by decide : 0 < 2) hn
    simpa [gridSize] using hpow
  have hot :
      oneTermRobinGlobalSparseOffset n t < gridSize n :=
    oneTermRobinGlobalSparseOffset_lt_gridSize_of_lt_seven hn ht
  have hos :
      oneTermRobinGlobalSparseOffset n s < gridSize n :=
    oneTermRobinGlobalSparseOffset_lt_gridSize_of_lt_seven hn hs
  have hsum :
      oneTermRobinGlobalSparseOffset n t +
            oneTermRobinGlobalSparseOffset n s = 0 ∨
        oneTermRobinGlobalSparseOffset n t +
            oneTermRobinGlobalSparseOffset n s = gridSize n :=
    eq_zero_or_eq_base_of_mod_eq_zero_of_lt_two_mul (by omega) hzero
  have hs_cases :
      s = 0 ∨ s = 1 ∨ s = 2 ∨ s = 3 ∨
        s = 4 ∨ s = 5 ∨ s = 6 := by
    omega
  rcases hs_cases with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals
    have ht_cases :
        t = 0 ∨ t = 1 ∨ t = 2 ∨ t = 3 ∨
          t = 4 ∨ t = 5 ∨ t = 6 := by
      omega
    rcases ht_cases with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals
      simp [oneTermRobinGlobalSparseOffset,
        oneTermRobinGlobalSparseInverseSlot] at hsum ⊢ <;> omega

   
                                                                            

                                                                              
                                                                          
                                                                       
                                    
  
theorem oneTermRobinGlobalSparseAddress_inverseSlot_unique_of_lt_seven
    {n s t i : Nat} (hn : 3 ≤ n) (hs : s < 7) (ht : t < 7)
    (hi : i < gridSize n)
    (h :
      oneTermRobinGlobalSparseAddress n t
          (oneTermRobinGlobalSparseAddress n s i) = i) :
    t = oneTermRobinGlobalSparseInverseSlot s := by
  have hNpos : 0 < gridSize n := by
    simp [gridSize]
    exact Nat.pow_pos (by decide : 0 < 2)
  have hcomp :=
    oneTermRobinGlobalSparseAddress_comp_eq_mod_offset_sum
      (n := n) (s := s) (t := t) (i := i)
  have hsumLt :
      (oneTermRobinGlobalSparseOffset n t +
          oneTermRobinGlobalSparseOffset n s) % gridSize n <
        gridSize n :=
    Nat.mod_lt _ hNpos
  have hzero :
      (oneTermRobinGlobalSparseOffset n t +
          oneTermRobinGlobalSparseOffset n s) % gridSize n = 0 :=
    mod_add_eq_self_imp_offset_zero hsumLt hi (by rwa [← hcomp])
  exact oneTermRobinGlobalSparseOffset_sum_mod_eq_zero_unique_of_lt_seven
    hn hs ht hzero

   
                                                                          
                             

                                                                            
                                                                            
                                            
  
theorem oneTermRobinGlobalSparseAddress_same_row_injective_of_lt_seven
    {n s t i : Nat} (hn : 3 ≤ n) (hs : s < 7) (ht : t < 7)
    (hi : i < gridSize n)
    (h :
      oneTermRobinGlobalSparseAddress n s i =
        oneTermRobinGlobalSparseAddress n t i) :
    s = t := by
  have hround :
      oneTermRobinGlobalSparseAddress n
          (oneTermRobinGlobalSparseInverseSlot s)
          (oneTermRobinGlobalSparseAddress n t i) = i := by
    rw [← h]
    exact oneTermRobinGlobalSparseAddress_inverseSlot_address_eq
      (n := n) (s := s) (i := i) hn (by omega) hi
  have hinv :
      oneTermRobinGlobalSparseInverseSlot s =
        oneTermRobinGlobalSparseInverseSlot t :=
    oneTermRobinGlobalSparseAddress_inverseSlot_unique_of_lt_seven
      (n := n) (s := t) (t := oneTermRobinGlobalSparseInverseSlot s)
      (i := i) hn ht
      (oneTermRobinGlobalSparseInverseSlot_lt_seven hs) hi hround
  exact oneTermRobinGlobalSparseInverseSlot_injective_of_lt_seven
    hs ht hinv

   
                                                                             

                                                                    
                                                                        
                                                                            
                                                                         
                                               
                                                   
  
def robinSparseColumnBranchValid (n s i : Nat) : Bool :=
  let N := gridSize n
  if 2 ≤ i ∧ i ≤ N - 3 then
    decide (s < 5)
  else if i = 0 then
    decide (s < 3)
  else if i = 1 then
    decide (s < 4)
  else if i = N - 2 then
    decide (s < 4)
  else if i = N - 1 then
    decide (s < 3)
  else false

   
                                                                             
                                                                             
                                        
  
theorem robinSparseColumnBranchValid_boundaryUnused_n3 :
    robinSparseColumnBranchValid 3 0 0 = true ∧
      robinSparseColumnBranchValid 3 3 0 = false ∧
      robinSparseColumnMap 3 0 0 = robinSparseColumnMap 3 3 0 := by
  native_decide

   
                                                    

                                                                            
                                                                         
                                                                             
                                                              
                         
  
theorem robinSparseColumnMap_lt_gridSize_of_row_lt
    {n s i : Nat} (hn : 2 ≤ n) (hi : i < gridSize n) :
    robinSparseColumnMap n s i < gridSize n := by
  have hpow : 2 ^ 2 ≤ 2 ^ n :=
    Nat.pow_le_pow_right (by decide : 0 < 2) hn
  have hN4 : 4 ≤ gridSize n := by
    simpa [gridSize] using hpow
  unfold robinSparseColumnMap
  by_cases hbulk : 2 ≤ i ∧ i ≤ gridSize n - 3
  · simp [hbulk]
    by_cases hs : s < 5
    · simp [hs]
      omega
    · simp [hs, hi]
  · simp [hbulk]
    by_cases hi0 : i = 0
    · simp [hi0]
      by_cases hs : s < 3
      · simp [hs]
        omega
      · simp [hs]
        omega
    · simp [hi0]
      by_cases hi1 : i = 1
      · simp [hi1]
        by_cases hs : s < 4
        · simp [hs]
          omega
        · simp [hs]
          omega
      · simp [hi1]
        by_cases hiN2 : i = gridSize n - 2
        · simp [hiN2]
          by_cases hs : s < 4
          · simp [hs]
            omega
          · simp [hs]
            omega
        · simp [hiN2]
          by_cases hiN1 : i = gridSize n - 1
          · simp [hiN1]
            by_cases hs : s < 3
            · simp [hs]
              omega
            · simp [hs]
              omega
          · simp [hiN1, hi]

   
                                                              

                                                                              
                                                                           
                                                                    
                                                               
                                                   
  
def robinSparseReverseColumnIndex (n target row : Nat) : Nat :=
  let N := gridSize n
  if row = 0 then target
  else if row = 1 then target
  else if 2 ≤ row ∧ row ≤ N - 3 then target + 2 - row
  else if row = N - 2 then target - (N - 4)
  else if row = N - 1 then target - (N - 3)
  else target

                                                                           
@[simp] theorem robinSparseColumnMap_zero (n s : Nat) :
    robinSparseColumnMap n s 0 = if s < 3 then s else 0 := by
  simp [robinSparseColumnMap]

                                                                         
@[simp] theorem robinSparseColumnMap_one (n s : Nat) :
    robinSparseColumnMap n s 1 = if s < 4 then s else 1 := by
  simp [robinSparseColumnMap]

                                                                     
theorem robinSparseColumnMap_bulk (n s i : Nat)
    (hbulk : 2 ≤ i ∧ i ≤ gridSize n - 3) :
    robinSparseColumnMap n s i = if s < 5 then i - 2 + s else i := by
  simp [robinSparseColumnMap, hbulk]

                                                                              
theorem robinSparseColumnMap_rightBoundaryPrev {n s : Nat} (hn : 3 ≤ n) :
    robinSparseColumnMap n s (gridSize n - 2) =
      if s < 4 then gridSize n - 4 + s else gridSize n - 2 := by
  have hN8 : 8 ≤ gridSize n := by
    have hpow : 2 ^ 3 ≤ 2 ^ n :=
      Nat.pow_le_pow_right (by decide : 0 < 2) hn
    simpa [gridSize] using hpow
  have hnotbulk :
      ¬(2 ≤ gridSize n - 2 ∧ gridSize n ≤ gridSize n - 3 + 2) := by
    omega
  have hnot0 : gridSize n - 2 ≠ 0 := by omega
  have hnot1 : gridSize n - 2 ≠ 1 := by omega
  simp [robinSparseColumnMap, hnotbulk, hnot0, hnot1]

                                                                       
theorem robinSparseColumnMap_rightBoundaryLast {n s : Nat} (hn : 3 ≤ n) :
    robinSparseColumnMap n s (gridSize n - 1) =
      if s < 3 then gridSize n - 3 + s else gridSize n - 1 := by
  have hN8 : 8 ≤ gridSize n := by
    have hpow : 2 ^ 3 ≤ 2 ^ n :=
      Nat.pow_le_pow_right (by decide : 0 < 2) hn
    simpa [gridSize] using hpow
  have hnotbulk :
      ¬(2 ≤ gridSize n - 1 ∧ gridSize n ≤ gridSize n - 3 + 1) := by
    omega
  have hnot0 : gridSize n - 1 ≠ 0 := by omega
  have hnot1 : gridSize n - 1 ≠ 1 := by omega
  have hnotN2 : gridSize n - 1 ≠ gridSize n - 2 := by omega
  simp [robinSparseColumnMap, hnotbulk, hnot0, hnot1, hnotN2]

                                              
@[simp] theorem robinSparseReverseColumnIndex_zero (n target : Nat) :
    robinSparseReverseColumnIndex n target 0 = target := by
  simp [robinSparseReverseColumnIndex]

                                             
@[simp] theorem robinSparseReverseColumnIndex_one (n target : Nat) :
    robinSparseReverseColumnIndex n target 1 = target := by
  simp [robinSparseReverseColumnIndex]

                                                
theorem robinSparseReverseColumnIndex_bulk (n target row : Nat)
    (hbulk : 2 ≤ row ∧ row ≤ gridSize n - 3) :
    robinSparseReverseColumnIndex n target row = target + 2 - row := by
  have hnot0 : row ≠ 0 := by omega
  have hnot1 : row ≠ 1 := by omega
  simp [robinSparseReverseColumnIndex, hbulk, hnot0, hnot1]

                                                         
theorem robinSparseReverseColumnIndex_rightBoundaryPrev
    {n target : Nat} (hn : 3 ≤ n) :
    robinSparseReverseColumnIndex n target (gridSize n - 2) =
      target - (gridSize n - 4) := by
  have hN8 : 8 ≤ gridSize n := by
    have hpow : 2 ^ 3 ≤ 2 ^ n :=
      Nat.pow_le_pow_right (by decide : 0 < 2) hn
    simpa [gridSize] using hpow
  have hnot0 : gridSize n - 2 ≠ 0 := by omega
  have hnot1 : gridSize n - 2 ≠ 1 := by omega
  have hnotbulk :
      ¬(2 ≤ gridSize n - 2 ∧ gridSize n ≤ gridSize n - 3 + 2) := by
    omega
  simp [robinSparseReverseColumnIndex, hnot0, hnot1, hnotbulk]

                                                  
theorem robinSparseReverseColumnIndex_rightBoundaryLast
    {n target : Nat} (hn : 3 ≤ n) :
    robinSparseReverseColumnIndex n target (gridSize n - 1) =
      target - (gridSize n - 3) := by
  have hN8 : 8 ≤ gridSize n := by
    have hpow : 2 ^ 3 ≤ 2 ^ n :=
      Nat.pow_le_pow_right (by decide : 0 < 2) hn
    simpa [gridSize] using hpow
  have hnot0 : gridSize n - 1 ≠ 0 := by omega
  have hnot1 : gridSize n - 1 ≠ 1 := by omega
  have hnotbulk :
      ¬(2 ≤ gridSize n - 1 ∧ gridSize n ≤ gridSize n - 3 + 1) := by
    omega
  have hnotN2 : gridSize n - 1 ≠ gridSize n - 2 := by omega
  simp [robinSparseReverseColumnIndex, hnot0, hnot1, hnotbulk, hnotN2]

   
                                                                       
                                                                         
                                  

                                                                            
                                                                                
                     
  
theorem robinSparseReverseColumnRoundtrip_of_lt_eight
    {n s i : Nat} (hn : 3 <= n) (hs : s < 8) (hi : i < gridSize n) :
    robinSparseColumnMap n
      (robinSparseReverseColumnIndex n i (robinSparseColumnMap n s i))
      (robinSparseColumnMap n s i) = i := by
  have hN8 : 8 ≤ gridSize n := by
    have hpow : 2 ^ 3 ≤ 2 ^ n :=
      Nat.pow_le_pow_right (by decide : 0 < 2) hn
    simpa [gridSize] using hpow
  have hs_cases : s = 0 ∨ s = 1 ∨ s = 2 ∨ s = 3 ∨
      s = 4 ∨ s = 5 ∨ s = 6 ∨ s = 7 := by
    omega
  by_cases hi0 : i = 0
  · subst i
    rcases hs_cases with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;>
      simp [robinSparseColumnMap, robinSparseReverseColumnIndex] <;>
      omega
  by_cases hi1 : i = 1
  · subst i
    have hbulk2 : 2 ≤ 2 ∧ 2 ≤ gridSize n - 3 := by omega
    have hbulk3 : 2 ≤ 3 ∧ 3 ≤ gridSize n - 3 := by omega
    rcases hs_cases with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;>
      simp [robinSparseColumnMap, robinSparseReverseColumnIndex, hbulk2,
        hbulk3] <;>
      omega
  by_cases hiN2 : i = gridSize n - 2
  · subst i
    have hrowN4 : 2 ≤ gridSize n - 4 ∧ gridSize n - 4 ≤ gridSize n - 3 := by
      omega
    have hrowN3 : 2 ≤ gridSize n - 3 ∧ gridSize n - 3 ≤ gridSize n - 3 := by
      omega
    rcases hs_cases with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · rw [robinSparseColumnMap_rightBoundaryPrev (n := n) (s := 0) hn]
      simp
      rw [robinSparseReverseColumnIndex_bulk n (gridSize n - 2)
        (gridSize n - 4) hrowN4]
      have hrev : gridSize n - 2 + 2 - (gridSize n - 4) = 4 := by omega
      rw [hrev, robinSparseColumnMap_bulk n 4 (gridSize n - 4) hrowN4]
      simp
      omega
    · rw [robinSparseColumnMap_rightBoundaryPrev (n := n) (s := 1) hn]
      simp
      rw [show gridSize n - 4 + 1 = gridSize n - 3 by omega]
      rw [robinSparseReverseColumnIndex_bulk n (gridSize n - 2)
        (gridSize n - 3) hrowN3]
      have hrev : gridSize n - 2 + 2 - (gridSize n - 3) = 3 := by omega
      rw [hrev, robinSparseColumnMap_bulk n 3 (gridSize n - 3) hrowN3]
      simp
      omega
    · rw [robinSparseColumnMap_rightBoundaryPrev (n := n) (s := 2) hn]
      simp
      rw [show gridSize n - 4 + 2 = gridSize n - 2 by omega]
      rw [robinSparseReverseColumnIndex_rightBoundaryPrev
        (n := n) (target := gridSize n - 2) hn]
      have hrev : gridSize n - 2 - (gridSize n - 4) = 2 := by omega
      rw [hrev, robinSparseColumnMap_rightBoundaryPrev (n := n) (s := 2) hn]
      simp
      omega
    · rw [robinSparseColumnMap_rightBoundaryPrev (n := n) (s := 3) hn]
      simp
      rw [show gridSize n - 4 + 3 = gridSize n - 1 by omega]
      rw [robinSparseReverseColumnIndex_rightBoundaryLast
        (n := n) (target := gridSize n - 2) hn]
      have hrev : gridSize n - 2 - (gridSize n - 3) = 1 := by omega
      rw [hrev, robinSparseColumnMap_rightBoundaryLast (n := n) (s := 1) hn]
      simp
      omega
    all_goals
      rw [robinSparseColumnMap_rightBoundaryPrev (n := n) hn]
      simp
      rw [robinSparseReverseColumnIndex_rightBoundaryPrev
        (n := n) (target := gridSize n - 2) hn]
      have hrev : gridSize n - 2 - (gridSize n - 4) = 2 := by omega
      rw [hrev, robinSparseColumnMap_rightBoundaryPrev (n := n) (s := 2) hn]
      simp
      omega
  by_cases hiN1 : i = gridSize n - 1
  · subst i
    have hrowN3 : 2 ≤ gridSize n - 3 ∧ gridSize n - 3 ≤ gridSize n - 3 := by
      omega
    rcases hs_cases with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · rw [robinSparseColumnMap_rightBoundaryLast (n := n) (s := 0) hn]
      simp
      rw [robinSparseReverseColumnIndex_bulk n (gridSize n - 1)
        (gridSize n - 3) hrowN3]
      have hrev : gridSize n - 1 + 2 - (gridSize n - 3) = 4 := by omega
      rw [hrev, robinSparseColumnMap_bulk n 4 (gridSize n - 3) hrowN3]
      simp
      omega
    · rw [robinSparseColumnMap_rightBoundaryLast (n := n) (s := 1) hn]
      simp
      rw [show gridSize n - 3 + 1 = gridSize n - 2 by omega]
      rw [robinSparseReverseColumnIndex_rightBoundaryPrev
        (n := n) (target := gridSize n - 1) hn]
      have hrev : gridSize n - 1 - (gridSize n - 4) = 3 := by omega
      rw [hrev, robinSparseColumnMap_rightBoundaryPrev (n := n) (s := 3) hn]
      simp
      omega
    · rw [robinSparseColumnMap_rightBoundaryLast (n := n) (s := 2) hn]
      simp
      rw [show gridSize n - 3 + 2 = gridSize n - 1 by omega]
      rw [robinSparseReverseColumnIndex_rightBoundaryLast
        (n := n) (target := gridSize n - 1) hn]
      have hrev : gridSize n - 1 - (gridSize n - 3) = 2 := by omega
      rw [hrev, robinSparseColumnMap_rightBoundaryLast (n := n) (s := 2) hn]
      simp
      omega
    all_goals
      rw [robinSparseColumnMap_rightBoundaryLast (n := n) hn]
      simp
      rw [robinSparseReverseColumnIndex_rightBoundaryLast
        (n := n) (target := gridSize n - 1) hn]
      have hrev : gridSize n - 1 - (gridSize n - 3) = 2 := by omega
      rw [hrev, robinSparseColumnMap_rightBoundaryLast (n := n) (s := 2) hn]
      simp
      omega
  have hbulk : 2 ≤ i ∧ i ≤ gridSize n - 3 := by
    omega
  rcases hs_cases with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · rw [robinSparseColumnMap_bulk n 0 i hbulk]
    simp
    by_cases hi2 : i = 2
    · subst i
      simp [robinSparseColumnMap, robinSparseReverseColumnIndex]
    by_cases hi3 : i = 3
    · subst i
      simp [robinSparseColumnMap, robinSparseReverseColumnIndex]
    have hrow : 2 ≤ i - 2 ∧ i - 2 ≤ gridSize n - 3 := by omega
    rw [robinSparseReverseColumnIndex_bulk n i (i - 2) hrow]
    have hrev : i + 2 - (i - 2) = 4 := by omega
    rw [hrev, robinSparseColumnMap_bulk n 4 (i - 2) hrow]
    simp
    omega
  · rw [robinSparseColumnMap_bulk n 1 i hbulk]
    simp
    by_cases hi2 : i = 2
    · subst i
      simp [robinSparseColumnMap, robinSparseReverseColumnIndex]
    have hrow : 2 ≤ i - 1 ∧ i - 1 ≤ gridSize n - 3 := by omega
    rw [show i - 2 + 1 = i - 1 by omega]
    rw [robinSparseReverseColumnIndex_bulk n i (i - 1) hrow]
    have hrev : i + 2 - (i - 1) = 3 := by omega
    rw [hrev, robinSparseColumnMap_bulk n 3 (i - 1) hrow]
    simp
    omega
  · rw [robinSparseColumnMap_bulk n 2 i hbulk]
    simp
    rw [show i - 2 + 2 = i by omega]
    rw [robinSparseReverseColumnIndex_bulk n i i hbulk]
    have hrev : i + 2 - i = 2 := by omega
    rw [hrev, robinSparseColumnMap_bulk n 2 i hbulk]
    simp
    omega
  · rw [robinSparseColumnMap_bulk n 3 i hbulk]
    simp
    by_cases hiN3 : i = gridSize n - 3
    · subst i
      rw [show gridSize n - 3 - 2 + 3 = gridSize n - 2 by omega]
      rw [robinSparseReverseColumnIndex_rightBoundaryPrev
        (n := n) (target := gridSize n - 3) hn]
      have hrev : gridSize n - 3 - (gridSize n - 4) = 1 := by omega
      rw [hrev, robinSparseColumnMap_rightBoundaryPrev (n := n) (s := 1) hn]
      simp
      omega
    have hrow : 2 ≤ i - 2 + 3 ∧ i - 2 + 3 ≤ gridSize n - 3 := by
      omega
    rw [robinSparseReverseColumnIndex_bulk n i (i - 2 + 3) hrow]
    have hrev : i + 2 - (i - 2 + 3) = 1 := by omega
    rw [hrev, robinSparseColumnMap_bulk n 1 (i - 2 + 3) hrow]
    simp
    omega
  · rw [robinSparseColumnMap_bulk n 4 i hbulk]
    simp
    by_cases hiN3 : i = gridSize n - 3
    · subst i
      rw [show gridSize n - 3 - 2 + 4 = gridSize n - 1 by omega]
      rw [robinSparseReverseColumnIndex_rightBoundaryLast
        (n := n) (target := gridSize n - 3) hn]
      have hrev : gridSize n - 3 - (gridSize n - 3) = 0 := by omega
      rw [hrev, robinSparseColumnMap_rightBoundaryLast (n := n) (s := 0) hn]
      simp
    by_cases hiN4 : i = gridSize n - 4
    · subst i
      rw [show gridSize n - 4 - 2 + 4 = gridSize n - 2 by omega]
      rw [robinSparseReverseColumnIndex_rightBoundaryPrev
        (n := n) (target := gridSize n - 4) hn]
      have hrev : gridSize n - 4 - (gridSize n - 4) = 0 := by omega
      rw [hrev, robinSparseColumnMap_rightBoundaryPrev (n := n) (s := 0) hn]
      simp
    have hrow : 2 ≤ i - 2 + 4 ∧ i - 2 + 4 ≤ gridSize n - 3 := by
      omega
    rw [robinSparseReverseColumnIndex_bulk n i (i - 2 + 4) hrow]
    have hrev : i + 2 - (i - 2 + 4) = 0 := by omega
    rw [hrev, robinSparseColumnMap_bulk n 0 (i - 2 + 4) hrow]
    simp
    omega
  all_goals
    rw [robinSparseColumnMap_bulk n _ i hbulk]
    simp
    rw [robinSparseReverseColumnIndex_bulk n i i hbulk]
    have hrev : i + 2 - i = 2 := by omega
    rw [hrev, robinSparseColumnMap_bulk n 2 i hbulk]
    simp
    omega

   
                                                                          
                                                      

                                                                            
                                                                            
                     
  
theorem robinSparseReverseColumnIndex_lt_eight_of_columnMap
    {n s i : Nat} (hn : 3 <= n) (hs : s < 8) (hi : i < gridSize n) :
    robinSparseReverseColumnIndex n i (robinSparseColumnMap n s i) < 8 := by
  have hN8 : 8 ≤ gridSize n := by
    have hpow : 2 ^ 3 ≤ 2 ^ n :=
      Nat.pow_le_pow_right (by decide : 0 < 2) hn
    simpa [gridSize] using hpow
  have hs_cases : s = 0 ∨ s = 1 ∨ s = 2 ∨ s = 3 ∨
      s = 4 ∨ s = 5 ∨ s = 6 ∨ s = 7 := by
    omega
  by_cases hi0 : i = 0
  · subst i
    rcases hs_cases with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;>
      simp [robinSparseColumnMap, robinSparseReverseColumnIndex] <;>
      omega
  by_cases hi1 : i = 1
  · subst i
    have hbulk2 : 2 ≤ 2 ∧ 2 ≤ gridSize n - 3 := by omega
    have hbulk3 : 2 ≤ 3 ∧ 3 ≤ gridSize n - 3 := by omega
    rcases hs_cases with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;>
      simp [robinSparseColumnMap, robinSparseReverseColumnIndex, hbulk2,
        hbulk3] <;>
      omega
  by_cases hiN2 : i = gridSize n - 2
  · subst i
    have hrowN4 : 2 ≤ gridSize n - 4 ∧ gridSize n - 4 ≤ gridSize n - 3 := by
      omega
    have hrowN3 : 2 ≤ gridSize n - 3 ∧ gridSize n - 3 ≤ gridSize n - 3 := by
      omega
    rcases hs_cases with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · rw [robinSparseColumnMap_rightBoundaryPrev (n := n) (s := 0) hn]
      simp
      rw [robinSparseReverseColumnIndex_bulk n (gridSize n - 2)
        (gridSize n - 4) hrowN4]
      omega
    · rw [robinSparseColumnMap_rightBoundaryPrev (n := n) (s := 1) hn]
      simp
      rw [show gridSize n - 4 + 1 = gridSize n - 3 by omega]
      rw [robinSparseReverseColumnIndex_bulk n (gridSize n - 2)
        (gridSize n - 3) hrowN3]
      omega
    · rw [robinSparseColumnMap_rightBoundaryPrev (n := n) (s := 2) hn]
      simp
      rw [show gridSize n - 4 + 2 = gridSize n - 2 by omega]
      rw [robinSparseReverseColumnIndex_rightBoundaryPrev
        (n := n) (target := gridSize n - 2) hn]
      omega
    · rw [robinSparseColumnMap_rightBoundaryPrev (n := n) (s := 3) hn]
      simp
      rw [show gridSize n - 4 + 3 = gridSize n - 1 by omega]
      rw [robinSparseReverseColumnIndex_rightBoundaryLast
        (n := n) (target := gridSize n - 2) hn]
      omega
    all_goals
      rw [robinSparseColumnMap_rightBoundaryPrev (n := n) hn]
      simp
      rw [robinSparseReverseColumnIndex_rightBoundaryPrev
        (n := n) (target := gridSize n - 2) hn]
      omega
  by_cases hiN1 : i = gridSize n - 1
  · subst i
    have hrowN3 : 2 ≤ gridSize n - 3 ∧ gridSize n - 3 ≤ gridSize n - 3 := by
      omega
    rcases hs_cases with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · rw [robinSparseColumnMap_rightBoundaryLast (n := n) (s := 0) hn]
      simp
      rw [robinSparseReverseColumnIndex_bulk n (gridSize n - 1)
        (gridSize n - 3) hrowN3]
      omega
    · rw [robinSparseColumnMap_rightBoundaryLast (n := n) (s := 1) hn]
      simp
      rw [show gridSize n - 3 + 1 = gridSize n - 2 by omega]
      rw [robinSparseReverseColumnIndex_rightBoundaryPrev
        (n := n) (target := gridSize n - 1) hn]
      omega
    · rw [robinSparseColumnMap_rightBoundaryLast (n := n) (s := 2) hn]
      simp
      rw [show gridSize n - 3 + 2 = gridSize n - 1 by omega]
      rw [robinSparseReverseColumnIndex_rightBoundaryLast
        (n := n) (target := gridSize n - 1) hn]
      omega
    all_goals
      rw [robinSparseColumnMap_rightBoundaryLast (n := n) hn]
      simp
      rw [robinSparseReverseColumnIndex_rightBoundaryLast
        (n := n) (target := gridSize n - 1) hn]
      omega
  have hbulk : 2 ≤ i ∧ i ≤ gridSize n - 3 := by
    omega
  rcases hs_cases with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · rw [robinSparseColumnMap_bulk n 0 i hbulk]
    simp
    by_cases hi2 : i = 2
    · subst i
      simp [robinSparseReverseColumnIndex]
    by_cases hi3 : i = 3
    · subst i
      simp [robinSparseReverseColumnIndex]
    have hrow : 2 ≤ i - 2 ∧ i - 2 ≤ gridSize n - 3 := by omega
    rw [robinSparseReverseColumnIndex_bulk n i (i - 2) hrow]
    omega
  · rw [robinSparseColumnMap_bulk n 1 i hbulk]
    simp
    by_cases hi2 : i = 2
    · subst i
      simp [robinSparseReverseColumnIndex]
    have hrow : 2 ≤ i - 1 ∧ i - 1 ≤ gridSize n - 3 := by omega
    rw [show i - 2 + 1 = i - 1 by omega]
    rw [robinSparseReverseColumnIndex_bulk n i (i - 1) hrow]
    omega
  · rw [robinSparseColumnMap_bulk n 2 i hbulk]
    simp
    rw [show i - 2 + 2 = i by omega]
    rw [robinSparseReverseColumnIndex_bulk n i i hbulk]
    omega
  · rw [robinSparseColumnMap_bulk n 3 i hbulk]
    simp
    by_cases hiN3 : i = gridSize n - 3
    · subst i
      rw [show gridSize n - 3 - 2 + 3 = gridSize n - 2 by omega]
      rw [robinSparseReverseColumnIndex_rightBoundaryPrev
        (n := n) (target := gridSize n - 3) hn]
      omega
    have hrow : 2 ≤ i - 2 + 3 ∧ i - 2 + 3 ≤ gridSize n - 3 := by
      omega
    rw [robinSparseReverseColumnIndex_bulk n i (i - 2 + 3) hrow]
    omega
  · rw [robinSparseColumnMap_bulk n 4 i hbulk]
    simp
    by_cases hiN3 : i = gridSize n - 3
    · subst i
      rw [show gridSize n - 3 - 2 + 4 = gridSize n - 1 by omega]
      rw [robinSparseReverseColumnIndex_rightBoundaryLast
        (n := n) (target := gridSize n - 3) hn]
      omega
    by_cases hiN4 : i = gridSize n - 4
    · subst i
      rw [show gridSize n - 4 - 2 + 4 = gridSize n - 2 by omega]
      rw [robinSparseReverseColumnIndex_rightBoundaryPrev
        (n := n) (target := gridSize n - 4) hn]
      omega
    have hrow : 2 ≤ i - 2 + 4 ∧ i - 2 + 4 ≤ gridSize n - 3 := by
      omega
    rw [robinSparseReverseColumnIndex_bulk n i (i - 2 + 4) hrow]
    omega
  all_goals
    rw [robinSparseColumnMap_bulk n _ i hbulk]
    simp
    rw [robinSparseReverseColumnIndex_bulk n i i hbulk]
    omega

   
                                                        

                                                                             
                                                     
                                                                              
                                                                           
                   
  
def robinSparseReverseColumnRoundtripCheck (n sparseBound : Nat) : Bool :=
  (List.range sparseBound).all (fun s =>
    (List.range (gridSize n)).all (fun i =>
      robinSparseColumnMap n
          (robinSparseReverseColumnIndex n i (robinSparseColumnMap n s i))
          (robinSparseColumnMap n s i) == i))

   
                                                               

                                                                     
                                                                 
                                                                             
                                                                             
                                                      
structure BandedSparseAccessPaperRegisters where
  odRegisterValue : Nat
  paddedZeroValue : Nat
  sparseIndexValue : Nat
  rowValue : Nat
deriving Repr, DecidableEq

   
                                                                           
                                                                            
                                                                       
  
def bandedSparseAccessPaperRegisters (p : OneTermRobinParameters) (j : Nat) :
    BandedSparseAccessPaperRegisters :=
  let n := p.n
  let κbits := clog2 p.kappa
  let odPure := n - κbits
  let nMask := (1 <<< n) - 1
  let zeroMask := (1 <<< odPure) - 1
  let sparseMask := (1 <<< κbits) - 1
  let odValue := (j >>> (1 + n)) &&& nMask
  {
    odRegisterValue := odValue
    paddedZeroValue := odValue &&& zeroMask
    sparseIndexValue := (odValue >>> odPure) &&& sparseMask
    rowValue := (j >>> 1) &&& nMask
  }

                                                                          
theorem bandedSparseAccessPaperRegisters_row_lt_gridSize
    (p : OneTermRobinParameters) (j : Nat) :
    (bandedSparseAccessPaperRegisters p j).rowValue < gridSize p.n := by
  simp [bandedSparseAccessPaperRegisters, gridSize]
  rw [Nat.one_shiftLeft]
  apply Nat.and_lt_two_pow
  exact Nat.sub_lt (Nat.pow_pos (by decide : 0 < 2) : 0 < 2 ^ p.n) (by decide)

                                                                                
theorem bandedSparseAccessPaperRegisters_sparseIndexValue_eq
    (p : OneTermRobinParameters) (j : Nat) :
    (bandedSparseAccessPaperRegisters p j).sparseIndexValue =
      (((bandedSparseAccessPaperRegisters p j).odRegisterValue >>>
          (p.n - clog2 p.kappa)) &&& ((1 <<< clog2 p.kappa) - 1)) := by
  rfl

                                                                              
theorem bandedSparseAccessPaperRegisters_paddedZeroValue_eq
    (p : OneTermRobinParameters) (j : Nat) :
    (bandedSparseAccessPaperRegisters p j).paddedZeroValue =
      ((bandedSparseAccessPaperRegisters p j).odRegisterValue &&&
        ((1 <<< (p.n - clog2 p.kappa)) - 1)) := by
  rfl

                                                                              
theorem bandedSparseAccessPaperRegisters_sparseIndex_lt
    (p : OneTermRobinParameters) (j : Nat) :
    (bandedSparseAccessPaperRegisters p j).sparseIndexValue <
      (1 <<< clog2 p.kappa) := by
  rw [bandedSparseAccessPaperRegisters_sparseIndexValue_eq]
  rw [Nat.one_shiftLeft]
  apply Nat.and_lt_two_pow
  exact Nat.sub_lt
    (Nat.pow_pos (by decide : 0 < 2) : 0 < 2 ^ clog2 p.kappa) (by decide)

                                                                                  
theorem bandedSparseAccessPaperRegisters_odRegisterValue_lt
    (p : OneTermRobinParameters) (j : Nat) :
    (bandedSparseAccessPaperRegisters p j).odRegisterValue < (1 <<< p.n) := by
  simp [bandedSparseAccessPaperRegisters]
  rw [Nat.one_shiftLeft]
  apply Nat.and_lt_two_pow
  exact Nat.sub_lt
    (Nat.pow_pos (by decide : 0 < 2) : 0 < 2 ^ p.n) (by decide)

   
                                            

                                                                           
                                                                             
                                                                  
  
def bandedSparseAccessRowDependentPaperAddress
    (p : OneTermRobinParameters) (j : Nat) : Nat :=
  let regs := bandedSparseAccessPaperRegisters p j
  robinSparseColumnMap p.n regs.sparseIndexValue regs.rowValue

   
                                                                       

                                                         
                                                                              
                                                                             
  
def bandedSparseAccessPaperAddress (p : OneTermRobinParameters) (j : Nat) : Nat :=
  let regs := bandedSparseAccessPaperRegisters p j
  oneTermRobinGlobalSparseAddress p.n regs.sparseIndexValue regs.rowValue

                                                                                         
def bandedSparseAccessPaperAddressInRange (p : OneTermRobinParameters) (j : Nat) : Bool :=
  decide (bandedSparseAccessPaperAddress p j < (1 <<< p.n))

                                                                   
theorem bandedSparseAccessPaperAddressInRange_iff
    (p : OneTermRobinParameters) (j : Nat) :
    bandedSparseAccessPaperAddressInRange p j = true ↔
      bandedSparseAccessPaperAddress p j < (1 <<< p.n) := by
  unfold bandedSparseAccessPaperAddressInRange
  exact decide_eq_true_iff

   
                                                                         
                                                                       
                                
  
theorem bandedSparseAccessPaperAddress_lt_gridSize_of_two_le
    (p : OneTermRobinParameters) (j : Nat) (_hn : 2 ≤ p.n) :
    bandedSparseAccessPaperAddress p j < gridSize p.n := by
  unfold bandedSparseAccessPaperAddress
  exact oneTermRobinGlobalSparseAddress_lt_gridSize p.n
    (bandedSparseAccessPaperRegisters p j).sparseIndexValue
    (bandedSparseAccessPaperRegisters p j).rowValue

   
                                                                           
                                                                      
                                             
  
theorem bandedSparseAccessPaperAddressInRange_eq_true_of_two_le
    (p : OneTermRobinParameters) (j : Nat) (hn : 2 ≤ p.n) :
    bandedSparseAccessPaperAddressInRange p j = true := by
  unfold bandedSparseAccessPaperAddressInRange
  have h := bandedSparseAccessPaperAddress_lt_gridSize_of_two_le p j hn
  simpa [gridSize, Nat.one_shiftLeft] using h

   
                                               

                                                                           
                                                                               
                                                                     
  
def bandedSparseAccessPaperImage (p : OneTermRobinParameters) (j : Nat) : Nat :=
  let lowWidth := 1 + p.n
  let highWidth := 1 + 2 * p.n
  let lowBase := 2 ^ lowWidth
  let highBase := 2 ^ highWidth
  let lowPrefix := j % lowBase
  let highTail := j / highBase
  let address := bandedSparseAccessPaperAddress p j
  lowPrefix + address * lowBase + highTail * highBase

   
                                                                            

                                                                               
                                                                    
  
def bandedSparseAccessRowDependentPaperImage
    (p : OneTermRobinParameters) (j : Nat) : Nat :=
  let lowWidth := 1 + p.n
  let highWidth := 1 + 2 * p.n
  let lowBase := 2 ^ lowWidth
  let highBase := 2 ^ highWidth
  let lowPrefix := j % lowBase
  let highTail := j / highBase
  let address := bandedSparseAccessRowDependentPaperAddress p j
  lowPrefix + address * lowBase + highTail * highBase

   
                                                                             
                                                                    
  
theorem bandedSparseAccessPaperRegisterValue_eq_mod
    (x offset n : Nat) :
    ((x >>> offset) &&& ((1 <<< n) - 1)) =
      (x / 2 ^ offset) % 2 ^ n := by
  apply Nat.eq_of_testBit_eq
  intro i
  simp only [Nat.testBit_and, Nat.testBit_shiftRight, Nat.one_shiftLeft,
    Nat.testBit_two_pow_sub_one, Nat.testBit_mod_two_pow]
  by_cases hi : i < n
  · simp [hi]
    rw [Nat.add_comm offset i, Nat.testBit_add]
  · simp [hi]

                                                                                
theorem bandedSparseAccessPaperHighWidth_le_totalQubits
    (p : OneTermRobinParameters) :
    1 + 2 * p.n ≤ oneTermRobinTotalQubits p := by
  simp only [oneTermRobinTotalQubits, RobinRegisterPartition.totalQubits,
    defaultRobinRegisterPartition]
  omega

   
                                                                               
                                         
  
theorem bandedSparseAccessPaperImage_lowBlock_lt_highBase_of_address_lt
    (p : OneTermRobinParameters) (j : Nat)
    (haddr : bandedSparseAccessPaperAddress p j < (1 <<< p.n)) :
    let lowWidth := 1 + p.n
    let highWidth := 1 + 2 * p.n
    let lowBase := 2 ^ lowWidth
    let highBase := 2 ^ highWidth
    let lowPrefix := j % lowBase
    let address := bandedSparseAccessPaperAddress p j
    lowPrefix + address * lowBase < highBase := by
  rw [Nat.one_shiftLeft] at haddr
  dsimp
  have hlowPos : 0 < 2 ^ (1 + p.n) :=
    Nat.pow_pos (by decide : 0 < 2)
  have hlow : j % 2 ^ (1 + p.n) < 2 ^ (1 + p.n) :=
    Nat.mod_lt j hlowPos
  have hbase : 2 ^ (1 + 2 * p.n) = 2 ^ (1 + p.n) * 2 ^ p.n := by
    rw [← Nat.pow_add]
    congr 1
    omega
  rw [hbase]
  have hlt1 :
      j % 2 ^ (1 + p.n) +
          bandedSparseAccessPaperAddress p j * 2 ^ (1 + p.n) <
        2 ^ (1 + p.n) +
          bandedSparseAccessPaperAddress p j * 2 ^ (1 + p.n) := by
    exact Nat.add_lt_add_right hlow
      (bandedSparseAccessPaperAddress p j * 2 ^ (1 + p.n))
  have hsucc : bandedSparseAccessPaperAddress p j + 1 ≤ 2 ^ p.n :=
    Nat.succ_le_of_lt haddr
  have hle :
      (bandedSparseAccessPaperAddress p j + 1) * 2 ^ (1 + p.n) ≤
        2 ^ p.n * 2 ^ (1 + p.n) := by
    exact Nat.mul_le_mul_right (2 ^ (1 + p.n)) hsucc
  have heq :
      2 ^ (1 + p.n) +
          bandedSparseAccessPaperAddress p j * 2 ^ (1 + p.n) =
        (bandedSparseAccessPaperAddress p j + 1) * 2 ^ (1 + p.n) := by
    rw [Nat.add_comm]
    exact (Nat.succ_mul (bandedSparseAccessPaperAddress p j)
      (2 ^ (1 + p.n))).symm
  rw [heq] at hlt1
  rw [Nat.mul_comm (2 ^ (1 + p.n)) (2 ^ p.n)]
  exact Nat.lt_of_lt_of_le hlt1 hle

                                                                                
theorem bandedSparseAccessPaperImage_mod_lowBase
    (p : OneTermRobinParameters) (j : Nat) :
    bandedSparseAccessPaperImage p j % 2 ^ (1 + p.n) =
      j % 2 ^ (1 + p.n) := by
  unfold bandedSparseAccessPaperImage
  let lowWidth := 1 + p.n
  let highWidth := 1 + 2 * p.n
  let lowBase := 2 ^ lowWidth
  let highBase := 2 ^ highWidth
  let lowPrefix := j % lowBase
  let highTail := j / highBase
  let address := bandedSparseAccessPaperAddress p j
  have hbase : highBase = lowBase * 2 ^ p.n := by
    dsimp [highBase, lowBase, highWidth, lowWidth]
    rw [← Nat.pow_add]
    congr 1
    omega
  have hlow : lowPrefix % lowBase = lowPrefix := by
    dsimp [lowPrefix]
    exact Nat.mod_eq_of_lt (Nat.mod_lt j (Nat.pow_pos (by decide : 0 < 2)))
  calc
    (lowPrefix + address * lowBase + highTail * highBase) % lowBase
        = (lowPrefix + lowBase * address + highTail * highBase) % lowBase := by
          rw [Nat.mul_comm address lowBase]
    _ = (lowPrefix + lowBase * address + highTail * (lowBase * 2 ^ p.n)) % lowBase := by
          rw [hbase]
    _ = (lowPrefix + lowBase * (address + highTail * 2 ^ p.n)) % lowBase := by
          congr 1
          rw [Nat.mul_add]
          ac_rfl
    _ = lowPrefix % lowBase := by
          rw [Nat.add_mul_mod_self_left]
    _ = lowPrefix := hlow
    _ = j % 2 ^ (1 + p.n) := by rfl

   
                                                                              
                                 
  
theorem bandedSparseAccessPaperImage_div_lowBase_mod_eq
    (p : OneTermRobinParameters) (j : Nat)
    (haddr : bandedSparseAccessPaperAddress p j < (1 <<< p.n)) :
    bandedSparseAccessPaperImage p j / 2 ^ (1 + p.n) % 2 ^ p.n =
      bandedSparseAccessPaperAddress p j := by
  unfold bandedSparseAccessPaperImage
  rw [Nat.one_shiftLeft] at haddr
  let lowWidth := 1 + p.n
  let highWidth := 1 + 2 * p.n
  let lowBase := 2 ^ lowWidth
  let highBase := 2 ^ highWidth
  let lowPrefix := j % lowBase
  let highTail := j / highBase
  let address := bandedSparseAccessPaperAddress p j
  have hlowPos : 0 < lowBase := by
    dsimp [lowBase, lowWidth]
    exact Nat.pow_pos (by decide : 0 < 2)
  have hlow : lowPrefix < lowBase := by
    dsimp [lowPrefix]
    exact Nat.mod_lt j hlowPos
  have hbase : highBase = lowBase * 2 ^ p.n := by
    dsimp [highBase, lowBase, highWidth, lowWidth]
    rw [← Nat.pow_add]
    congr 1
    omega
  have himage : lowPrefix + address * lowBase + highTail * highBase =
      lowPrefix + lowBase * (address + highTail * 2 ^ p.n) := by
    rw [hbase]
    rw [Nat.mul_add]
    ac_rfl
  have hdiv :
      (lowPrefix + lowBase * (address + highTail * 2 ^ p.n)) / lowBase =
        address + highTail * 2 ^ p.n := by
    rw [Nat.add_mul_div_left _ _ hlowPos]
    rw [Nat.div_eq_of_lt hlow]
    simp
  have hlowWidth : 2 ^ (1 + p.n) = lowBase := by rfl
  rw [hlowWidth]
  rw [himage]
  rw [hdiv]
  rw [Nat.add_mul_mod_self_right]
  exact Nat.mod_eq_of_lt haddr

   
                                                                              
                                                           
  
theorem bandedSparseAccessPaperImage_lt_qubitDim_of_address_lt
    (p : OneTermRobinParameters) (j : Nat)
    (hj : j < qubitDim (oneTermRobinTotalQubits p))
    (haddr : bandedSparseAccessPaperAddress p j < (1 <<< p.n)) :
    bandedSparseAccessPaperImage p j < qubitDim (oneTermRobinTotalQubits p) := by
  simp only [qubitDim, gridSize] at hj ⊢
  unfold bandedSparseAccessPaperImage
  let lowWidth := 1 + p.n
  let highWidth := 1 + 2 * p.n
  let lowBase := 2 ^ lowWidth
  let highBase := 2 ^ highWidth
  let lowPrefix := j % lowBase
  let highTail := j / highBase
  let address := bandedSparseAccessPaperAddress p j
  have hsmall :
      lowPrefix + address * lowBase < highBase :=
    bandedSparseAccessPaperImage_lowBlock_lt_highBase_of_address_lt p j haddr
  have hwidth : highWidth ≤ oneTermRobinTotalQubits p := by
    dsimp [highWidth]
    exact bandedSparseAccessPaperHighWidth_le_totalQubits p
  have hpowTotal : highBase * 2 ^ (oneTermRobinTotalQubits p - highWidth) =
      2 ^ oneTermRobinTotalQubits p := by
    dsimp [highBase]
    rw [← Nat.pow_add]
    congr 1
    omega
  have htail_lt : highTail < 2 ^ (oneTermRobinTotalQubits p - highWidth) := by
    dsimp [highTail]
    apply Nat.div_lt_of_lt_mul
    rwa [hpowTotal]
  have htail_succ : highTail + 1 ≤ 2 ^ (oneTermRobinTotalQubits p - highWidth) :=
    Nat.succ_le_of_lt htail_lt
  have hblock :
      lowPrefix + address * lowBase + highTail * highBase <
        highBase * (highTail + 1) := by
    rw [Nat.mul_succ, Nat.mul_comm highBase highTail]
    omega
  have htotal : highBase * (highTail + 1) ≤ 2 ^ oneTermRobinTotalQubits p := by
    have hmul := Nat.mul_le_mul_left highBase htail_succ
    rwa [hpowTotal] at hmul
  exact Nat.lt_of_lt_of_le hblock htotal

   
                                                                   

                                                                           
                                                                            
                                                                            
  
def bandedSparseAccessPaperImageFin
    (p : OneTermRobinParameters)
    (j : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (haddr : bandedSparseAccessPaperAddress p j.val < (1 <<< p.n)) :
    Fin (qubitDim (oneTermRobinTotalQubits p)) :=
  ⟨bandedSparseAccessPaperImage p j.val,
    bandedSparseAccessPaperImage_lt_qubitDim_of_address_lt p j.val j.2 haddr⟩

@[simp] theorem bandedSparseAccessPaperImageFin_val
    (p : OneTermRobinParameters)
    (j : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (haddr : bandedSparseAccessPaperAddress p j.val < (1 <<< p.n)) :
    (bandedSparseAccessPaperImageFin p j haddr).val =
      bandedSparseAccessPaperImage p j.val := rfl

                                                                           
theorem bandedSparseAccessPaperImage_rowValue_eq
    (p : OneTermRobinParameters) (j : Nat) :
    (bandedSparseAccessPaperRegisters p
      (bandedSparseAccessPaperImage p j)).rowValue =
      (bandedSparseAccessPaperRegisters p j).rowValue := by
  unfold bandedSparseAccessPaperRegisters
  simp only []
  rw [bandedSparseAccessPaperRegisterValue_eq_mod,
    bandedSparseAccessPaperRegisterValue_eq_mod]
  have hpow : 2 * 2 ^ p.n = 2 ^ (1 + p.n) := by
    rw [show 1 + p.n = p.n + 1 by omega, Nat.pow_succ]
    omega
  have hmod := bandedSparseAccessPaperImage_mod_lowBase p j
  rw [← hpow] at hmod
  rw [← Nat.mod_mul_right_div_self (bandedSparseAccessPaperImage p j) 2 (2 ^ p.n)]
  rw [← Nat.mod_mul_right_div_self j 2 (2 ^ p.n)]
  rw [hmod]

                                                                                   
theorem bandedSparseAccessPaperImage_odRegisterValue_eq
    (p : OneTermRobinParameters) (j : Nat)
    (haddr : bandedSparseAccessPaperAddress p j < (1 <<< p.n)) :
    (bandedSparseAccessPaperRegisters p
      (bandedSparseAccessPaperImage p j)).odRegisterValue =
      bandedSparseAccessPaperAddress p j := by
  unfold bandedSparseAccessPaperRegisters
  simp only []
  rw [bandedSparseAccessPaperRegisterValue_eq_mod]
  exact bandedSparseAccessPaperImage_div_lowBase_mod_eq p j haddr

                                                                            
def bandedSparseAccessPaperHighTail (p : OneTermRobinParameters) (j : Nat) : Nat :=
  j >>> (1 + 2 * p.n)

   
                                                                               
                                                                               

                                                                               
                                                                             
                                                              
  
theorem bandedSparseAccessPaperImage_highTail_eq_of_address_lt
    (p : OneTermRobinParameters) (j : Nat)
    (haddr : bandedSparseAccessPaperAddress p j < (1 <<< p.n)) :
    bandedSparseAccessPaperHighTail p (bandedSparseAccessPaperImage p j) =
      bandedSparseAccessPaperHighTail p j := by
  unfold bandedSparseAccessPaperHighTail
  rw [Nat.shiftRight_eq_div_pow, Nat.shiftRight_eq_div_pow]
  unfold bandedSparseAccessPaperImage
  let lowWidth := 1 + p.n
  let highWidth := 1 + 2 * p.n
  let lowBase := 2 ^ lowWidth
  let highBase := 2 ^ highWidth
  let lowPrefix := j % lowBase
  let highTail := j / highBase
  let address := bandedSparseAccessPaperAddress p j
  have hhighPos : 0 < highBase := by
    dsimp [highBase, highWidth]
    exact Nat.pow_pos (by decide : 0 < 2)
  have hsmall : lowPrefix + address * lowBase < highBase :=
    bandedSparseAccessPaperImage_lowBlock_lt_highBase_of_address_lt p j haddr
  have hdivsmall : (lowPrefix + address * lowBase) / highBase = 0 :=
    Nat.div_eq_of_lt hsmall
  calc
    (lowPrefix + address * lowBase + highTail * highBase) / highBase
        = (lowPrefix + address * lowBase + highBase * highTail) / highBase := by
          rw [Nat.mul_comm highTail highBase]
    _ = (lowPrefix + address * lowBase) / highBase + highTail := by
          rw [Nat.add_mul_div_left _ _ hhighPos]
    _ = highTail := by simp [hdivsmall]
    _ = j / highBase := rfl

   
                                                                            
                                                                    
  
def bandedSparseAccessPaperImageNoSpill (p : OneTermRobinParameters) (j : Nat) : Bool :=
  bandedSparseAccessPaperHighTail p (bandedSparseAccessPaperImage p j) ==
    bandedSparseAccessPaperHighTail p j

   
                                                        

                                                                          
                                                                           
  
theorem bandedSparseAccessPaperImageNoSpill_iff
    (p : OneTermRobinParameters) (j : Nat) :
    bandedSparseAccessPaperImageNoSpill p j = true ↔
      bandedSparseAccessPaperHighTail p (bandedSparseAccessPaperImage p j) =
        bandedSparseAccessPaperHighTail p j := by
  unfold bandedSparseAccessPaperImageNoSpill
  exact beq_iff_eq

                                                                            
theorem bandedSparseAccessPaperImageNoSpill_eq_true_of_address_lt
    (p : OneTermRobinParameters) (j : Nat)
    (haddr : bandedSparseAccessPaperAddress p j < (1 <<< p.n)) :
    bandedSparseAccessPaperImageNoSpill p j = true := by
  rw [bandedSparseAccessPaperImageNoSpill_iff]
  exact bandedSparseAccessPaperImage_highTail_eq_of_address_lt p j haddr

   
                                                                              
                                                                           
  
theorem bandedSparseAccessPaperImageNoSpill_eq_true_of_two_le
    (p : OneTermRobinParameters) (j : Nat) (hn : 2 ≤ p.n) :
    bandedSparseAccessPaperImageNoSpill p j = true := by
  apply bandedSparseAccessPaperImageNoSpill_eq_true_of_address_lt
  have h := bandedSparseAccessPaperAddress_lt_gridSize_of_two_le p j hn
  simpa [gridSize, Nat.one_shiftLeft] using h

   
                                                                

                                                                      
                                                                           
                                                                             
          
  
def bandedSparseAccessPaperCleanInput (p : OneTermRobinParameters) (j : Nat) : Bool :=
  (bandedSparseAccessPaperRegisters p j).paddedZeroValue == 0

   
                                                                    

                                                                       
                                                                             
                                                           
  
def bandedSparseAccessPaperSparseIndexInKappa
    (p : OneTermRobinParameters) (j : Nat) : Bool :=
  decide ((bandedSparseAccessPaperRegisters p j).sparseIndexValue < p.kappa)

   
                                                                         

                                                                              
                                                                       
                                                                                   
  
def bandedSparseAccessPaperGlobalSlotSource
    (p : OneTermRobinParameters) (j : Nat) : Bool :=
  bandedSparseAccessPaperCleanInput p j &&
    bandedSparseAccessPaperSparseIndexInKappa p j

                                                                                
theorem bandedSparseAccessPaperGlobalSlotSource_cleanInput_eq_true
    (p : OneTermRobinParameters) (j : Nat)
    (h : bandedSparseAccessPaperGlobalSlotSource p j = true) :
    bandedSparseAccessPaperCleanInput p j = true := by
  cases hclean : bandedSparseAccessPaperCleanInput p j <;>
    cases hinRange : bandedSparseAccessPaperSparseIndexInKappa p j <;>
    simp [bandedSparseAccessPaperGlobalSlotSource, hclean, hinRange] at h ⊢

                                                                           
theorem bandedSparseAccessPaperGlobalSlotSource_sparseIndex_lt_kappa
    (p : OneTermRobinParameters) (j : Nat)
    (h : bandedSparseAccessPaperGlobalSlotSource p j = true) :
    (bandedSparseAccessPaperRegisters p j).sparseIndexValue < p.kappa := by
  have hinRangeTrue :
      bandedSparseAccessPaperSparseIndexInKappa p j = true := by
    cases hclean : bandedSparseAccessPaperCleanInput p j <;>
      cases hinRange : bandedSparseAccessPaperSparseIndexInKappa p j <;>
      simp [bandedSparseAccessPaperGlobalSlotSource, hclean, hinRange] at h ⊢
  simpa [bandedSparseAccessPaperSparseIndexInKappa] using hinRangeTrue

   
                                                   

                                                                            
                                                                            
                                                                          
                                                            
  
theorem bandedSparseAccessPaperGlobalSlotSource_inverseSlot_injective
    (p : OneTermRobinParameters) {j₁ j₂ : Nat}
    (hkappa : p.kappa = 7)
    (hsource₁ : bandedSparseAccessPaperGlobalSlotSource p j₁ = true)
    (hsource₂ : bandedSparseAccessPaperGlobalSlotSource p j₂ = true)
    (h :
      oneTermRobinGlobalSparseInverseSlot
          (bandedSparseAccessPaperRegisters p j₁).sparseIndexValue =
        oneTermRobinGlobalSparseInverseSlot
          (bandedSparseAccessPaperRegisters p j₂).sparseIndexValue) :
    (bandedSparseAccessPaperRegisters p j₁).sparseIndexValue =
      (bandedSparseAccessPaperRegisters p j₂).sparseIndexValue := by
  apply oneTermRobinGlobalSparseInverseSlot_injective_of_lt_seven
  · have hs :=
      bandedSparseAccessPaperGlobalSlotSource_sparseIndex_lt_kappa
        p j₁ hsource₁
    rwa [hkappa] at hs
  · have hs :=
      bandedSparseAccessPaperGlobalSlotSource_sparseIndex_lt_kappa
      p j₂ hsource₂
    rwa [hkappa] at hs
  · exact h

   
                                                                          
       

                                                                               
                                                                            
                                                                            
                            
  
theorem bandedSparseAccessPaperAddress_same_row_injective_of_globalSlotSource
    (p : OneTermRobinParameters) {j₁ j₂ : Nat}
    (hn : 3 ≤ p.n) (hkappa : p.kappa = 7)
    (hsource₁ : bandedSparseAccessPaperGlobalSlotSource p j₁ = true)
    (hsource₂ : bandedSparseAccessPaperGlobalSlotSource p j₂ = true)
    (hrow :
      (bandedSparseAccessPaperRegisters p j₁).rowValue =
        (bandedSparseAccessPaperRegisters p j₂).rowValue)
    (haddr :
      bandedSparseAccessPaperAddress p j₁ =
        bandedSparseAccessPaperAddress p j₂) :
    (bandedSparseAccessPaperRegisters p j₁).sparseIndexValue =
      (bandedSparseAccessPaperRegisters p j₂).sparseIndexValue := by
  have hs₁ :
      (bandedSparseAccessPaperRegisters p j₁).sparseIndexValue < 7 := by
    have hs :=
      bandedSparseAccessPaperGlobalSlotSource_sparseIndex_lt_kappa
        p j₁ hsource₁
    rwa [hkappa] at hs
  have hs₂ :
      (bandedSparseAccessPaperRegisters p j₂).sparseIndexValue < 7 := by
    have hs :=
      bandedSparseAccessPaperGlobalSlotSource_sparseIndex_lt_kappa
        p j₂ hsource₂
    rwa [hkappa] at hs
  have hrowLt :
      (bandedSparseAccessPaperRegisters p j₁).rowValue < gridSize p.n :=
    bandedSparseAccessPaperRegisters_row_lt_gridSize p j₁
  have haddrSame :
      oneTermRobinGlobalSparseAddress p.n
          (bandedSparseAccessPaperRegisters p j₁).sparseIndexValue
          (bandedSparseAccessPaperRegisters p j₁).rowValue =
        oneTermRobinGlobalSparseAddress p.n
          (bandedSparseAccessPaperRegisters p j₂).sparseIndexValue
          (bandedSparseAccessPaperRegisters p j₁).rowValue := by
    simpa [bandedSparseAccessPaperAddress, hrow] using haddr
  exact oneTermRobinGlobalSparseAddress_same_row_injective_of_lt_seven
    hn hs₁ hs₂ hrowLt haddrSame

   
                                                                           

                                                                            
                                                                            
                                                                             
                                                                             
                                                                 
  
def bandedSparseAccessPaperValidSparseBranch
    (p : OneTermRobinParameters) (j : Nat) : Bool :=
  let regs := bandedSparseAccessPaperRegisters p j
  robinSparseColumnBranchValid p.n regs.sparseIndexValue regs.rowValue

   
                                                                             
                                                                           
                                                                             
                            
  
def bandedSparseAccessPaperValidCleanSource
    (p : OneTermRobinParameters) (j : Nat) : Bool :=
  bandedSparseAccessPaperCleanInput p j &&
    bandedSparseAccessPaperValidSparseBranch p j

                                                                              
theorem bandedSparseAccessPaperValidCleanSource_cleanInput_eq_true
    (p : OneTermRobinParameters) (j : Nat)
    (h : bandedSparseAccessPaperValidCleanSource p j = true) :
    bandedSparseAccessPaperCleanInput p j = true := by
  cases hclean : bandedSparseAccessPaperCleanInput p j <;>
    cases hvalid : bandedSparseAccessPaperValidSparseBranch p j <;>
    simp [bandedSparseAccessPaperValidCleanSource, hclean, hvalid] at h ⊢

                                                                           
theorem bandedSparseAccessPaperValidCleanSource_validSparseBranch_eq_true
    (p : OneTermRobinParameters) (j : Nat)
    (h : bandedSparseAccessPaperValidCleanSource p j = true) :
    bandedSparseAccessPaperValidSparseBranch p j = true := by
  cases hclean : bandedSparseAccessPaperCleanInput p j <;>
    cases hvalid : bandedSparseAccessPaperValidSparseBranch p j <;>
    simp [bandedSparseAccessPaperValidCleanSource, hclean, hvalid] at h ⊢

   
                                                                        
                                                                            
                                                                        
  
theorem bandedSparseAccessPaperValidCleanSource_separates_boundaryCollision_n3 :
    let p : OneTermRobinParameters :=
      { n := 3, kappa := 7, functionPieces := 1, polynomialDegreeCost := 1 }
    bandedSparseAccessPaperCleanInput p 0 = true ∧
      bandedSparseAccessPaperCleanInput p 48 = true ∧
      bandedSparseAccessPaperValidSparseBranch p 0 = true ∧
      bandedSparseAccessPaperValidSparseBranch p 48 = false ∧
      bandedSparseAccessPaperValidCleanSource p 0 = true ∧
      bandedSparseAccessPaperValidCleanSource p 48 = false ∧
      bandedSparseAccessRowDependentPaperImage p 0 =
        bandedSparseAccessRowDependentPaperImage p 48 ∧
      bandedSparseAccessPaperImage p 0 ≠ bandedSparseAccessPaperImage p 48 := by
  native_decide

   
                                                                           
                                    

                                                                              
                                                         
  
def bandedSparseAccessPaperUnusedSparseBranch
    (p : OneTermRobinParameters) (j : Nat) : Bool :=
  bandedSparseAccessPaperCleanInput p j &&
    !bandedSparseAccessPaperValidSparseBranch p j

                                                                         
theorem bandedSparseAccessPaperUnusedSparseBranch_cleanInput_eq_true
    (p : OneTermRobinParameters) (j : Nat)
    (h : bandedSparseAccessPaperUnusedSparseBranch p j = true) :
    bandedSparseAccessPaperCleanInput p j = true := by
  cases hclean : bandedSparseAccessPaperCleanInput p j <;>
    cases hvalid : bandedSparseAccessPaperValidSparseBranch p j <;>
    simp [bandedSparseAccessPaperUnusedSparseBranch, hclean, hvalid] at h ⊢

                                                                                    
theorem bandedSparseAccessPaperUnusedSparseBranch_validSparseBranch_eq_false
    (p : OneTermRobinParameters) (j : Nat)
    (h : bandedSparseAccessPaperUnusedSparseBranch p j = true) :
    bandedSparseAccessPaperValidSparseBranch p j = false := by
  cases hclean : bandedSparseAccessPaperCleanInput p j <;>
    cases hvalid : bandedSparseAccessPaperValidSparseBranch p j <;>
    simp [bandedSparseAccessPaperUnusedSparseBranch, hclean, hvalid] at h ⊢

   
                                                                              
                             

                                                                              
                                                                        
                                                                  
  
theorem bandedSparseAccessPaperCleanDomainSplit_iff
    (p : OneTermRobinParameters) (j : Nat) :
    bandedSparseAccessPaperCleanInput p j = true ↔
      bandedSparseAccessPaperValidCleanSource p j = true ∨
        bandedSparseAccessPaperUnusedSparseBranch p j = true := by
  constructor
  · intro hclean
    cases hvalid : bandedSparseAccessPaperValidSparseBranch p j <;>
      simp [bandedSparseAccessPaperValidCleanSource,
        bandedSparseAccessPaperUnusedSparseBranch, hclean, hvalid]
  · intro hsplit
    rcases hsplit with hvalidClean | hunused
    · exact
        bandedSparseAccessPaperValidCleanSource_cleanInput_eq_true
          p j hvalidClean
    · exact
        bandedSparseAccessPaperUnusedSparseBranch_cleanInput_eq_true
          p j hunused

   
                                                                               

                                                                         
                                                      
  
theorem bandedSparseAccessPaperCleanDomainSplit_disjoint
    (p : OneTermRobinParameters) (j : Nat) :
    ¬ (bandedSparseAccessPaperValidCleanSource p j = true ∧
        bandedSparseAccessPaperUnusedSparseBranch p j = true) := by
  intro hboth
  have hvalid :
      bandedSparseAccessPaperValidSparseBranch p j = true :=
    bandedSparseAccessPaperValidCleanSource_validSparseBranch_eq_true
      p j hboth.1
  have hinvalid :
      bandedSparseAccessPaperValidSparseBranch p j = false :=
    bandedSparseAccessPaperUnusedSparseBranch_validSparseBranch_eq_false
      p j hboth.2
  rw [hvalid] at hinvalid
  contradiction

   
                                                                                

                                                                         
                                                                          
                                                                             
  
structure BandedSparseAccessUnusedBranchImageRuleContract where
  sourceAnchor : String
  sourceIndex : Nat
  inputRegisters : BandedSparseAccessPaperRegisters
  activeImageIndex : Nat
  proposedImageIndex : Option Nat
  cleanInput : Bool
  validSparseBranch : Bool
  unusedSparseBranch : Bool
  imageSpecified : ObligationRecord
  imageFinite : ObligationRecord
  separatesActiveCollision : ObligationRecord
  validBranchAgreement : ObligationRecord
deriving Repr, DecidableEq

   
                                                                 

                                                                          
                                                                            
                                                             
  
def bandedSparseAccessUnusedBranchImageRuleContract
    (p : OneTermRobinParameters) (j : Nat) :
    BandedSparseAccessUnusedBranchImageRuleContract where
  sourceAnchor := "Guseynov-Huang-Liu 2025, Lemma 1 and one-term Robin zero-branch audit, arXiv:2506.20478"
  sourceIndex := j
  inputRegisters := bandedSparseAccessPaperRegisters p j
  activeImageIndex := bandedSparseAccessPaperImage p j
  proposedImageIndex := none
  cleanInput := bandedSparseAccessPaperCleanInput p j
  validSparseBranch := bandedSparseAccessPaperValidSparseBranch p j
  unusedSparseBranch := bandedSparseAccessPaperUnusedSparseBranch p j
  imageSpecified := {
    description := "a faithful reversible image for this clean invalid sparse branch is specified separately from the active colliding image"
    source := "QBE-AUTO-002 O_D^BS unused-branch image-rule interface"
    proved := false
  }
  imageFinite := {
    description := "the specified unused-branch image is a finite basis index in the one-term Robin Hilbert space"
    source := "QBE-AUTO-002 O_D^BS unused-branch image-rule interface"
    proved := false
  }
  separatesActiveCollision := {
    description := "the specified unused-branch image separates the known active-image collision on clean invalid branches"
    source := "QBE-AUTO-002 O_D^BS unused-branch image-rule interface"
    proved := false
  }
  validBranchAgreement := {
    description := "the eventual extension agrees with the Lemma 1 paper image on valid clean sparse branches"
    source := "Guseynov-Huang-Liu 2025, Lemma 1, arXiv:2506.20478"
    proved := false
  }

                                                                            
theorem bandedSparseAccessUnusedBranchImageRuleContract_flags_false
    (p : OneTermRobinParameters) (j : Nat) :
    (bandedSparseAccessUnusedBranchImageRuleContract p j).proposedImageIndex = none ∧
      (bandedSparseAccessUnusedBranchImageRuleContract p j).imageSpecified.proved = false ∧
      (bandedSparseAccessUnusedBranchImageRuleContract p j).imageFinite.proved = false ∧
      (bandedSparseAccessUnusedBranchImageRuleContract p j).separatesActiveCollision.proved = false ∧
      (bandedSparseAccessUnusedBranchImageRuleContract p j).validBranchAgreement.proved = false := by
  simp [bandedSparseAccessUnusedBranchImageRuleContract]

   
                                                             

                                                                             
                                                                
  
theorem bandedSparseAccessUnusedBranchImageRuleContract_of_unusedBranch
    (p : OneTermRobinParameters) (j : Nat)
    (h : bandedSparseAccessPaperUnusedSparseBranch p j = true) :
    (bandedSparseAccessUnusedBranchImageRuleContract p j).cleanInput = true ∧
      (bandedSparseAccessUnusedBranchImageRuleContract p j).validSparseBranch = false ∧
      (bandedSparseAccessUnusedBranchImageRuleContract p j).unusedSparseBranch = true ∧
      (bandedSparseAccessUnusedBranchImageRuleContract p j).proposedImageIndex = none ∧
      (bandedSparseAccessUnusedBranchImageRuleContract p j).imageSpecified.proved = false ∧
      (bandedSparseAccessUnusedBranchImageRuleContract p j).validBranchAgreement.proved = false := by
  have hclean :
      bandedSparseAccessPaperCleanInput p j = true :=
    bandedSparseAccessPaperUnusedSparseBranch_cleanInput_eq_true p j h
  have hvalid :
      bandedSparseAccessPaperValidSparseBranch p j = false :=
    bandedSparseAccessPaperUnusedSparseBranch_validSparseBranch_eq_false p j h
  simp [bandedSparseAccessUnusedBranchImageRuleContract, h, hclean, hvalid]

   
                                                                            

                                                                            
                                                                          
                                                                              
                                     
  
structure BandedSparseAccessUnusedBranchExtensionContract where
  sourceAnchor : String
  inputRegisters : BandedSparseAccessPaperRegisters
  activeImageIndex : Nat
  cleanInput : Bool
  validSparseBranch : Bool
  unusedSparseBranch : Bool
  unusedBranchImageRuleContract : BandedSparseAccessUnusedBranchImageRuleContract
  paperAgreementOnValidBranches : ObligationRecord
  unusedBranchImageRule : ObligationRecord
  unusedBranchInjective : ObligationRecord
  fullCleanDomainInjective : ObligationRecord
  daggerCleanup : ObligationRecord
  unitaryExtension : ObligationRecord
deriving Repr, DecidableEq

   
                                                                     

                                                                            
                                                                            
  
def bandedSparseAccessUnusedBranchExtensionContract
    (p : OneTermRobinParameters) (j : Nat) :
    BandedSparseAccessUnusedBranchExtensionContract where
  sourceAnchor := "Guseynov-Huang-Liu 2025, Lemma 1 and one-term Robin zero-branch audit, arXiv:2506.20478"
  inputRegisters := bandedSparseAccessPaperRegisters p j
  activeImageIndex := bandedSparseAccessPaperImage p j
  cleanInput := bandedSparseAccessPaperCleanInput p j
  validSparseBranch := bandedSparseAccessPaperValidSparseBranch p j
  unusedSparseBranch := bandedSparseAccessPaperUnusedSparseBranch p j
  unusedBranchImageRuleContract :=
    bandedSparseAccessUnusedBranchImageRuleContract p j
  paperAgreementOnValidBranches := {
    description := "the extension agrees with the Lemma 1 image on valid row-dependent sparse branches"
    source := "Guseynov-Huang-Liu 2025, Lemma 1, arXiv:2506.20478"
    proved := false
  }
  unusedBranchImageRule :=
    (bandedSparseAccessUnusedBranchImageRuleContract p j).imageSpecified
  unusedBranchInjective := {
    description := "the unused-branch image rule is injective on clean invalid branches"
    source := "QBE-AUTO-002 O_D^BS unused-branch extension contract"
    proved := false
  }
  fullCleanDomainInjective := {
    description := "valid-branch and unused-branch images are jointly injective on the full clean padded domain"
    source := "QBE-AUTO-002 O_D^BS unused-branch extension contract"
    proved := false
  }
  daggerCleanup := {
    description := "the dagger cleanup proof uses the reversible unused-branch extension where needed"
    source := "Guseynov-Huang-Liu 2025, Fig. 1-term Robin and Lemma 1, arXiv:2506.20478"
    proved := false
  }
  unitaryExtension := {
    description := "the full O_D^BS matrix extends to a unitary on valid and unused clean branches"
    source := "Guseynov-Huang-Liu 2025, Lemma 1, arXiv:2506.20478"
    proved := false
  }

                                                                          
theorem bandedSparseAccessUnusedBranchExtensionContract_flags_false
    (p : OneTermRobinParameters) (j : Nat) :
    (bandedSparseAccessUnusedBranchExtensionContract p j).paperAgreementOnValidBranches.proved = false ∧
      (bandedSparseAccessUnusedBranchExtensionContract p j).unusedBranchImageRule.proved = false ∧
      (bandedSparseAccessUnusedBranchExtensionContract p j).unusedBranchInjective.proved = false ∧
      (bandedSparseAccessUnusedBranchExtensionContract p j).fullCleanDomainInjective.proved = false ∧
      (bandedSparseAccessUnusedBranchExtensionContract p j).daggerCleanup.proved = false ∧
      (bandedSparseAccessUnusedBranchExtensionContract p j).unitaryExtension.proved = false := by
  simp [bandedSparseAccessUnusedBranchExtensionContract,
    bandedSparseAccessUnusedBranchImageRuleContract]

   
                                                                         
                                                           

                                                                       
                                                                     
                                                       
  
theorem bandedSparseAccessUnusedBranchExtensionContract_boundaryCollision_n3 :
    let p : OneTermRobinParameters :=
      { n := 3, kappa := 7, functionPieces := 1, polynomialDegreeCost := 1 }
    bandedSparseAccessPaperValidCleanSource p 0 = true ∧
      bandedSparseAccessPaperUnusedSparseBranch p 48 = true ∧
      bandedSparseAccessRowDependentPaperImage p 0 =
        bandedSparseAccessRowDependentPaperImage p 48 ∧
      bandedSparseAccessPaperImage p 0 ≠ bandedSparseAccessPaperImage p 48 ∧
      (bandedSparseAccessUnusedBranchExtensionContract p 48).unusedBranchInjective.proved = false ∧
      (bandedSparseAccessUnusedBranchExtensionContract p 48).unitaryExtension.proved = false := by
  native_decide

   
                                                                               

                                                                            
                                                                               
                                                            
  
theorem bandedSparseAccessUnusedBranchExtensionContract_of_unusedBranch
    (p : OneTermRobinParameters) (j : Nat)
    (h : bandedSparseAccessPaperUnusedSparseBranch p j = true) :
    (bandedSparseAccessUnusedBranchExtensionContract p j).cleanInput = true ∧
      (bandedSparseAccessUnusedBranchExtensionContract p j).validSparseBranch = false ∧
      (bandedSparseAccessUnusedBranchExtensionContract p j).unusedSparseBranch = true ∧
      (bandedSparseAccessUnusedBranchExtensionContract p j).unusedBranchImageRule.proved = false ∧
      (bandedSparseAccessUnusedBranchExtensionContract p j).unusedBranchInjective.proved = false ∧
      (bandedSparseAccessUnusedBranchExtensionContract p j).fullCleanDomainInjective.proved = false ∧
      (bandedSparseAccessUnusedBranchExtensionContract p j).daggerCleanup.proved = false ∧
      (bandedSparseAccessUnusedBranchExtensionContract p j).unitaryExtension.proved = false := by
  have hclean :
      bandedSparseAccessPaperCleanInput p j = true :=
    bandedSparseAccessPaperUnusedSparseBranch_cleanInput_eq_true p j h
  have hvalid :
      bandedSparseAccessPaperValidSparseBranch p j = false :=
    bandedSparseAccessPaperUnusedSparseBranch_validSparseBranch_eq_false p j h
  simp [bandedSparseAccessUnusedBranchExtensionContract,
    bandedSparseAccessUnusedBranchImageRuleContract, h, hclean, hvalid]

   
                                                                     
         

                                                        
                                                                               
                                                                       
                                                                        
                                                                              
                                                       
  
structure BandedSparseAccessFullCleanDomainExtensionContract where
  sourceAnchor : String
  cleanInputPredicate : String
  validSparseBranchPredicate : String
  validCleanSourcePredicate : String
  unusedSparseBranchPredicate : String
  unusedBranchImageRuleContract :
    Nat → BandedSparseAccessUnusedBranchImageRuleContract
  unusedBranchExtensionContract :
    Nat → BandedSparseAccessUnusedBranchExtensionContract
  cleanDomainSplit : ObligationRecord
  validBranchAgreement : ObligationRecord
  unusedBranchImageSpecified : ObligationRecord
  unusedBranchImageFinite : ObligationRecord
  unusedBranchInjective : ObligationRecord
  fullCleanDomainInjective : ObligationRecord
  daggerCleanup : ObligationRecord
  unitaryExtension : ObligationRecord

   
                                                                  

                                                                            
                                                                        
                                                                           
  
def bandedSparseAccessFullCleanDomainExtensionContract
    (p : OneTermRobinParameters) :
    BandedSparseAccessFullCleanDomainExtensionContract where
  sourceAnchor := "Guseynov-Huang-Liu 2025, Lemma 1 and one-term Robin zero-branch audit, arXiv:2506.20478"
  cleanInputPredicate := "bandedSparseAccessPaperCleanInput"
  validSparseBranchPredicate := "bandedSparseAccessPaperValidSparseBranch"
  validCleanSourcePredicate := "bandedSparseAccessPaperValidCleanSource"
  unusedSparseBranchPredicate := "bandedSparseAccessPaperUnusedSparseBranch"
  unusedBranchImageRuleContract := fun j =>
    bandedSparseAccessUnusedBranchImageRuleContract p j
  unusedBranchExtensionContract := fun j =>
    bandedSparseAccessUnusedBranchExtensionContract p j
  cleanDomainSplit := {
    description := "the full padded clean domain is partitioned into valid nonzero-stencil branches and clean unused sparse branches"
    source := "QBE-AUTO-002 O_D^BS full clean-domain extension contract"
    proved := false
  }
  validBranchAgreement := {
    description := "the full extension agrees with the Lemma 1 image on every valid clean sparse branch"
    source := "Guseynov-Huang-Liu 2025, Lemma 1, arXiv:2506.20478"
    proved := false
  }
  unusedBranchImageSpecified := {
    description := "a faithful reversible image rule is specified for every clean unused sparse branch"
    source := "QBE-AUTO-002 O_D^BS full clean-domain extension contract"
    proved := false
  }
  unusedBranchImageFinite := {
    description := "every specified unused-branch image is a finite one-term Robin basis index"
    source := "QBE-AUTO-002 O_D^BS full clean-domain extension contract"
    proved := false
  }
  unusedBranchInjective := {
    description := "the unused-branch image rule is injective on clean invalid sparse branches"
    source := "QBE-AUTO-002 O_D^BS full clean-domain extension contract"
    proved := false
  }
  fullCleanDomainInjective := {
    description := "valid-branch and unused-branch images are jointly injective on the full padded clean domain"
    source := "QBE-AUTO-002 O_D^BS full clean-domain extension contract"
    proved := false
  }
  daggerCleanup := {
    description := "the dagger cleanup proof is valid for the full padded clean domain"
    source := "Guseynov-Huang-Liu 2025, Fig. 1-term Robin and Lemma 1, arXiv:2506.20478"
    proved := false
  }
  unitaryExtension := {
    description := "the full clean-domain image rule extends to a unitary O_D^BS matrix"
    source := "Guseynov-Huang-Liu 2025, Lemma 1, arXiv:2506.20478"
    proved := false
  }

                                                                   
theorem bandedSparseAccessFullCleanDomainExtensionContract_flags_false
    (p : OneTermRobinParameters) (j : Nat) :
    (bandedSparseAccessFullCleanDomainExtensionContract p).cleanDomainSplit.proved = false ∧
      (bandedSparseAccessFullCleanDomainExtensionContract p).validBranchAgreement.proved = false ∧
      (bandedSparseAccessFullCleanDomainExtensionContract p).unusedBranchImageSpecified.proved = false ∧
      (bandedSparseAccessFullCleanDomainExtensionContract p).unusedBranchImageFinite.proved = false ∧
      (bandedSparseAccessFullCleanDomainExtensionContract p).unusedBranchInjective.proved = false ∧
      (bandedSparseAccessFullCleanDomainExtensionContract p).fullCleanDomainInjective.proved = false ∧
      (bandedSparseAccessFullCleanDomainExtensionContract p).daggerCleanup.proved = false ∧
      (bandedSparseAccessFullCleanDomainExtensionContract p).unitaryExtension.proved = false ∧
      ((bandedSparseAccessFullCleanDomainExtensionContract p).unusedBranchImageRuleContract j).proposedImageIndex = none ∧
      ((bandedSparseAccessFullCleanDomainExtensionContract p).unusedBranchImageRuleContract j).imageSpecified.proved = false ∧
      ((bandedSparseAccessFullCleanDomainExtensionContract p).unusedBranchImageRuleContract j).imageFinite.proved = false := by
  simp [bandedSparseAccessFullCleanDomainExtensionContract,
    bandedSparseAccessUnusedBranchImageRuleContract]

   
                                                                          
                                                             
  
theorem bandedSparseAccessFullCleanDomainExtensionContract_of_unusedBranch
    (p : OneTermRobinParameters) (j : Nat)
    (h : bandedSparseAccessPaperUnusedSparseBranch p j = true) :
    ((bandedSparseAccessFullCleanDomainExtensionContract p).unusedBranchImageRuleContract j).cleanInput = true ∧
      ((bandedSparseAccessFullCleanDomainExtensionContract p).unusedBranchImageRuleContract j).validSparseBranch = false ∧
      ((bandedSparseAccessFullCleanDomainExtensionContract p).unusedBranchImageRuleContract j).unusedSparseBranch = true ∧
      ((bandedSparseAccessFullCleanDomainExtensionContract p).unusedBranchImageRuleContract j).proposedImageIndex = none ∧
      (bandedSparseAccessFullCleanDomainExtensionContract p).unusedBranchImageSpecified.proved = false ∧
      (bandedSparseAccessFullCleanDomainExtensionContract p).fullCleanDomainInjective.proved = false ∧
      (bandedSparseAccessFullCleanDomainExtensionContract p).unitaryExtension.proved = false := by
  have hclean :
      bandedSparseAccessPaperCleanInput p j = true :=
    bandedSparseAccessPaperUnusedSparseBranch_cleanInput_eq_true p j h
  have hvalid :
      bandedSparseAccessPaperValidSparseBranch p j = false :=
    bandedSparseAccessPaperUnusedSparseBranch_validSparseBranch_eq_false p j h
  simp [bandedSparseAccessFullCleanDomainExtensionContract,
    bandedSparseAccessUnusedBranchImageRuleContract, h, hclean, hvalid]

   
                                                          

                                                                          
                                                                            
                                                          
  
theorem bandedSparseAccessFullCleanDomainExtensionContract_localCleanDomainSplit
    (p : OneTermRobinParameters) (j : Nat) :
    (bandedSparseAccessPaperCleanInput p j = true ↔
      bandedSparseAccessPaperValidCleanSource p j = true ∨
        bandedSparseAccessPaperUnusedSparseBranch p j = true) ∧
      (bandedSparseAccessFullCleanDomainExtensionContract p).cleanDomainSplit.proved =
        false := by
  exact ⟨bandedSparseAccessPaperCleanDomainSplit_iff p j, rfl⟩

   
                                                                        

                                                                            
                                                                          
                                                                              
                    
  
structure BandedSparseAccessUnusedZeroBranchSourceDecision where
  sourceAnchor : String
  citedResultKey : String
  paperImageRuleSpecified : Bool
  externalExtensionTheoremAccepted : Bool
  lowerProofSearchAllowed : Bool
  dependency : ObligationRecord
deriving Repr, DecidableEq

   
                                                                           

                                                                            
                                                                         
  
def bandedSparseAccessUnusedZeroBranchSourceDecision :
    BandedSparseAccessUnusedZeroBranchSourceDecision where
  sourceAnchor := "Guseynov-Huang-Liu 2025, Lemma 1 and Fig. 1-term Robin, arXiv:2506.20478"
  citedResultKey := "QBE.ODBS.UnusedZeroBranchExtension"
  paperImageRuleSpecified := false
  externalExtensionTheoremAccepted := false
  lowerProofSearchAllowed := false
  dependency := {
    description := "unused zero-amplitude sparse branches need a paper-backed image rule or accepted reversible-extension theorem before O_D^BS injectivity, cleanup, or unitarity proof search"
    source := "research-wiki/cited-results/GHL2025.md: QBE.ODBS.UnusedZeroBranchExtension"
    proved := false
  }

                                                                                 
theorem bandedSparseAccessUnusedZeroBranchSourceDecision_flags_false :
    bandedSparseAccessUnusedZeroBranchSourceDecision.paperImageRuleSpecified = false ∧
      bandedSparseAccessUnusedZeroBranchSourceDecision.externalExtensionTheoremAccepted = false ∧
      bandedSparseAccessUnusedZeroBranchSourceDecision.lowerProofSearchAllowed = false ∧
      bandedSparseAccessUnusedZeroBranchSourceDecision.dependency.proved = false := by
  simp [bandedSparseAccessUnusedZeroBranchSourceDecision]

   
                                                                           

                                                                             
                                                                
  
theorem bandedSparseAccessUnusedZeroBranchSourceDecision_keepsFullDomainFlagsFalse
    (p : OneTermRobinParameters) :
    bandedSparseAccessUnusedZeroBranchSourceDecision.lowerProofSearchAllowed = false ∧
      (bandedSparseAccessFullCleanDomainExtensionContract p).unusedBranchImageSpecified.proved =
        false ∧
      (bandedSparseAccessFullCleanDomainExtensionContract p).fullCleanDomainInjective.proved =
        false ∧
      (bandedSparseAccessFullCleanDomainExtensionContract p).daggerCleanup.proved =
        false ∧
      (bandedSparseAccessFullCleanDomainExtensionContract p).unitaryExtension.proved =
        false := by
  simp [bandedSparseAccessUnusedZeroBranchSourceDecision,
    bandedSparseAccessFullCleanDomainExtensionContract]

   
                                                                              

                                                                              
                                                                       
                                                              
  
theorem bandedSparseAccessUnusedZeroBranchSourceDecision_keepsImageRuleUnspecified
    (p : OneTermRobinParameters) (j : Nat) :
    bandedSparseAccessUnusedZeroBranchSourceDecision.lowerProofSearchAllowed = false ∧
      (bandedSparseAccessUnusedBranchImageRuleContract p j).proposedImageIndex = none ∧
      (bandedSparseAccessUnusedBranchImageRuleContract p j).imageSpecified.proved = false ∧
      ((bandedSparseAccessFullCleanDomainExtensionContract p).unusedBranchImageRuleContract
        j).proposedImageIndex = none ∧
      ((bandedSparseAccessFullCleanDomainExtensionContract p).unusedBranchImageRuleContract
        j).imageSpecified.proved = false ∧
      ((bandedSparseAccessFullCleanDomainExtensionContract p).unusedBranchImageRuleContract
        j).separatesActiveCollision.proved = false := by
  simp [bandedSparseAccessUnusedZeroBranchSourceDecision,
    bandedSparseAccessFullCleanDomainExtensionContract,
    bandedSparseAccessUnusedBranchImageRuleContract]

   
                                                                       
                  

                                                                         
                                                                               
  
theorem bandedSparseAccessUnusedZeroBranchSourceDecision_keepsPaperContractFlagsFalse
    (p : OneTermRobinParameters) :
    bandedSparseAccessUnusedZeroBranchSourceDecision.lowerProofSearchAllowed = false ∧
      (defaultBandedSparseAccessPaperContract p).forwardCorrect.proved = false ∧
      (defaultBandedSparseAccessPaperContract p).daggerCleanup.proved = false ∧
      (defaultBandedSparseAccessPaperContract p).unitaryExtension.proved = false := by
  simp [bandedSparseAccessUnusedZeroBranchSourceDecision,
    defaultBandedSparseAccessPaperContract]

   
                                                                       

                                                                              
                                                                           
                                                                       
                                                                              
                                         
  
structure BandedSparseAccessRobinZeroInclusionSourceContract where
  sourceAnchor : String
  zeroInclusionAnchor : String
  equationAnchor : String
  sparseIndexRange : String
  zerosIncludedInSparseEnumeration : Bool
  paperImageEquation : String
  unusedBranchImageRule : Option String
  unusedBranchImageIndex : Option Nat
  reversibleExtensionTheorem : Option String
  closesUnusedZeroBranchExtension : Bool
  lowerProofSearchAllowed : Bool
  imageRuleObligation : ObligationRecord
  reversibleExtensionObligation : ObligationRecord
deriving Repr, DecidableEq

   
                                                                   

                                                                    
                                                                      
                                                                        
                            
  
def bandedSparseAccessRobinZeroInclusionSourceContract :
    BandedSparseAccessRobinZeroInclusionSourceContract where
  sourceAnchor :=
    "Guseynov-Huang-Liu 2025, one-term Robin construction, arXiv:2506.20478"
  zeroInclusionAnchor :=
    "text before Theorem 1-term Robin: zeros can be included in the set of non-zero elements"
  equationAnchor :=
    "Lemma 1 and Eq. ROBIN clarified, arXiv:2506.20478"
  sparseIndexRange := "s = 0, ..., kappa - 1"
  zerosIncludedInSparseEnumeration := true
  paperImageEquation := "O_D^BS |0>^(n-l)|s>^l|i>^n = |r_si>^n|i>^n"
  unusedBranchImageRule := none
  unusedBranchImageIndex := none
  reversibleExtensionTheorem := none
  closesUnusedZeroBranchExtension := false
  lowerProofSearchAllowed := false
  imageRuleObligation := {
    description := "the Robin source includes zero-amplitude sparse branches but does not specify their injective reversible image"
    source := "Guseynov-Huang-Liu 2025, one-term Robin construction and Lemma 1, arXiv:2506.20478"
    proved := false
  }
  reversibleExtensionObligation := {
    description := "no cited reversible-extension theorem is accepted for the unused zero-amplitude sparse branches"
    source := "research-wiki/cited-results/GHL2025.md: QBE.ODBS.UnusedZeroBranchExtension"
    proved := false
  }

   
                                                                        
        

                                                                             
                                                                          
                  
  
theorem bandedSparseAccessRobinZeroInclusionSourceContract_blocks_unusedZeroBranch :
    bandedSparseAccessRobinZeroInclusionSourceContract.zerosIncludedInSparseEnumeration =
        true ∧
      bandedSparseAccessRobinZeroInclusionSourceContract.unusedBranchImageRule =
        none ∧
      bandedSparseAccessRobinZeroInclusionSourceContract.unusedBranchImageIndex =
        none ∧
      bandedSparseAccessRobinZeroInclusionSourceContract.reversibleExtensionTheorem =
        none ∧
      bandedSparseAccessRobinZeroInclusionSourceContract.closesUnusedZeroBranchExtension =
        false ∧
      bandedSparseAccessRobinZeroInclusionSourceContract.lowerProofSearchAllowed =
        false ∧
      bandedSparseAccessRobinZeroInclusionSourceContract.imageRuleObligation.proved =
        false ∧
      bandedSparseAccessRobinZeroInclusionSourceContract.reversibleExtensionObligation.proved =
        false ∧
      bandedSparseAccessUnusedZeroBranchSourceDecision.lowerProofSearchAllowed =
        false := by
  simp [bandedSparseAccessRobinZeroInclusionSourceContract,
    bandedSparseAccessUnusedZeroBranchSourceDecision]

   
                                                                           

                                                                            
                                                                  
  
theorem bandedSparseAccessRobinZeroInclusionSourceContract_keepsImageRuleUnspecified
    (p : OneTermRobinParameters) (j : Nat) :
    bandedSparseAccessRobinZeroInclusionSourceContract.zerosIncludedInSparseEnumeration =
        true ∧
      bandedSparseAccessRobinZeroInclusionSourceContract.unusedBranchImageIndex =
        none ∧
      bandedSparseAccessRobinZeroInclusionSourceContract.reversibleExtensionTheorem =
        none ∧
      bandedSparseAccessRobinZeroInclusionSourceContract.lowerProofSearchAllowed =
        false ∧
      (bandedSparseAccessUnusedBranchImageRuleContract p j).proposedImageIndex =
        none ∧
      (bandedSparseAccessUnusedBranchImageRuleContract p j).imageSpecified.proved =
        false := by
  simp [bandedSparseAccessRobinZeroInclusionSourceContract,
    bandedSparseAccessUnusedBranchImageRuleContract]

   
                                                                 

                                                                          
                                                                               
                                                                               
                                                           
  
structure BandedSparseAccessPriorPDESourceContract where
  sourceAnchor : String
  definitionAnchor : String
  lemmaAnchor : String
  appendixAnchor : String
  oracleEquation : String
  circuitDecomposition : String
  resourceClaim : ObligationRecord
  robinUnusedBranchImageRule : Option String
  closesUnusedZeroBranchExtension : Bool
  lowerProofSearchAllowed : Bool
deriving Repr, DecidableEq

   
                                                                       
                                   

                                                                            
                                                                         
                                  
  
def bandedSparseAccessPriorPDESourceContract :
    BandedSparseAccessPriorPDESourceContract where
  sourceAnchor :=
    "Guseynov-Huang-Liu 2024, arXiv:2405.12855v3, Definition 6, Lemma 1, Appendix Banded-sparse-access"
  definitionAnchor := "Definition 6: Banded-sparse-access"
  lemmaAnchor := "Lemma 1: Banded-sparse-access resource bound"
  appendixAnchor := "Appendix: Explicit quantum circuit construction for O_A^BS"
  oracleEquation := "O_A^BS |0>^(n-l)|s>^l|i>^n = |r_si>^n|i>^n"
  circuitDecomposition := "O_A^BS = U^SUM (U_A^(l) tensor I^n)"
  resourceClaim := {
    description := "transcribe the prior-paper gate and pure-ancilla resource counts for the padded banded-sparse-access primitive"
    source := "Guseynov-Huang-Liu 2024, arXiv:2405.12855v3, Lemma 1"
    proved := false
  }
  robinUnusedBranchImageRule := none
  closesUnusedZeroBranchExtension := false
  lowerProofSearchAllowed := false

   
                                                                            
                                                                      
                                                                          
  
def robinBandedSparseAccessCitationChain : List String := [
  "Guseynov-Huang-Liu 2025, arXiv:2506.20478, Lemma 2",
  "Guseynov-Huang-Liu 2024, arXiv:2405.12855v3, Lemma 1"
]

@[simp] theorem robinBandedSparseAccessCitationChain_eq :
    robinBandedSparseAccessCitationChain = [
      "Guseynov-Huang-Liu 2025, arXiv:2506.20478, Lemma 2",
      "Guseynov-Huang-Liu 2024, arXiv:2405.12855v3, Lemma 1"
    ] := rfl

   
                                                                           

                                                                               
                                                                        
                           
  
theorem bandedSparseAccessPriorPDESourceContract_blocks_unusedZeroBranch :
    bandedSparseAccessPriorPDESourceContract.robinUnusedBranchImageRule = none ∧
      bandedSparseAccessPriorPDESourceContract.closesUnusedZeroBranchExtension = false ∧
      bandedSparseAccessPriorPDESourceContract.lowerProofSearchAllowed = false ∧
      bandedSparseAccessUnusedZeroBranchSourceDecision.lowerProofSearchAllowed = false := by
  simp [bandedSparseAccessPriorPDESourceContract,
    bandedSparseAccessUnusedZeroBranchSourceDecision]

                                                                              
theorem bandedSparseAccessPriorPDESourceContract_oracleEquation :
    bandedSparseAccessPriorPDESourceContract.oracleEquation =
      "O_A^BS |0>^(n-l)|s>^l|i>^n = |r_si>^n|i>^n" := rfl

                                                                          
theorem bandedSparseAccessPriorPDESourceContract_resource_unproved :
    bandedSparseAccessPriorPDESourceContract.resourceClaim.proved = false := rfl

   
                                               

                                                                             
                                                                           
                                                                      
  
theorem bandedSparseAccessPaperCleanInput_iff
    (p : OneTermRobinParameters) (j : Nat) :
    bandedSparseAccessPaperCleanInput p j = true ↔
      (bandedSparseAccessPaperRegisters p j).paddedZeroValue = 0 := by
  unfold bandedSparseAccessPaperCleanInput
  exact beq_iff_eq

   
                                                               

                                                                          
                                                                               
                                                                       
                                                                          
                        
  
structure BandedSparseAccessPaperColumnContract where
  sourceAnchor : String
  inputRegisters : BandedSparseAccessPaperRegisters
  cleanInput : Bool
  imageIndex : Nat
  imageRegisters : BandedSparseAccessPaperRegisters
  rowPreserved : Bool
  addressWritten : Bool
  addressInRange : Bool
  imageNoSpill : Bool
  cleanInputDomain : ObligationRecord
  addressRange : ObligationRecord
  noSpill : ObligationRecord
  unitaryExtension : ObligationRecord
deriving Repr, DecidableEq

   
                                                                  
  
def bandedSparseAccessPaperColumnContract
    (p : OneTermRobinParameters) (j : Nat) :
    BandedSparseAccessPaperColumnContract :=
  let regs := bandedSparseAccessPaperRegisters p j
  let image := bandedSparseAccessPaperImage p j
  let imageRegs := bandedSparseAccessPaperRegisters p image
  let paperContract := defaultBandedSparseAccessPaperContract p
  {
    sourceAnchor := paperContract.sourceAnchor
    inputRegisters := regs
    cleanInput := bandedSparseAccessPaperCleanInput p j
    imageIndex := image
    imageRegisters := imageRegs
    rowPreserved := imageRegs.rowValue == regs.rowValue
    addressWritten := imageRegs.odRegisterValue == bandedSparseAccessPaperAddress p j
    addressInRange := bandedSparseAccessPaperAddressInRange p j
    imageNoSpill := bandedSparseAccessPaperImageNoSpill p j
    cleanInputDomain := paperContract.cleanInputDomain
    addressRange := paperContract.addressRange
    noSpill := paperContract.noSpill
    unitaryExtension := paperContract.unitaryExtension
  }

                                                                          
theorem bandedSparseAccessPaperColumnContract_inputRegisters_eq
    (p : OneTermRobinParameters) (j : Nat) :
    (bandedSparseAccessPaperColumnContract p j).inputRegisters =
      bandedSparseAccessPaperRegisters p j := rfl

                                                                                
theorem bandedSparseAccessPaperColumnContract_cleanInput_eq
    (p : OneTermRobinParameters) (j : Nat) :
    (bandedSparseAccessPaperColumnContract p j).cleanInput =
      bandedSparseAccessPaperCleanInput p j := rfl

   
                                                                          

                                                                             
                             
  
theorem bandedSparseAccessPaperColumnContract_cleanInput_iff
    (p : OneTermRobinParameters) (j : Nat) :
    (bandedSparseAccessPaperColumnContract p j).cleanInput = true ↔
      (bandedSparseAccessPaperRegisters p j).paddedZeroValue = 0 := by
  rw [bandedSparseAccessPaperColumnContract_cleanInput_eq]
  exact bandedSparseAccessPaperCleanInput_iff p j

   
                                                                      
                                                                        
  
theorem bandedSparseAccessPaperColumnContract_unitaryExtension_proved_eq_false
    (p : OneTermRobinParameters) (j : Nat) :
    (bandedSparseAccessPaperColumnContract p j).unitaryExtension.proved = false := rfl

                                                                                        
theorem bandedSparseAccessPaperColumnContract_imageIndex_eq
    (p : OneTermRobinParameters) (j : Nat) :
    (bandedSparseAccessPaperColumnContract p j).imageIndex =
      bandedSparseAccessPaperImage p j := rfl

                                                                                
theorem bandedSparseAccessPaperColumnContract_addressInRange_eq
    (p : OneTermRobinParameters) (j : Nat) :
    (bandedSparseAccessPaperColumnContract p j).addressInRange =
      bandedSparseAccessPaperAddressInRange p j := rfl

                                                                              
theorem bandedSparseAccessPaperColumnContract_imageNoSpill_eq
    (p : OneTermRobinParameters) (j : Nat) :
    (bandedSparseAccessPaperColumnContract p j).imageNoSpill =
      bandedSparseAccessPaperImageNoSpill p j := rfl

   
                                                                             

                                                                            
                                                        
  
theorem bandedSparseAccessPaperColumnContract_rowPreserved_eq_true
    (p : OneTermRobinParameters) (j : Nat) :
    (bandedSparseAccessPaperColumnContract p j).rowPreserved = true := by
  unfold bandedSparseAccessPaperColumnContract
  simp [bandedSparseAccessPaperImage_rowValue_eq]

   
                                                                            
                                                             
  
theorem bandedSparseAccessPaperColumnContract_addressWritten_eq_true_of_address_lt
    (p : OneTermRobinParameters) (j : Nat)
    (haddr : bandedSparseAccessPaperAddress p j < (1 <<< p.n)) :
    (bandedSparseAccessPaperColumnContract p j).addressWritten = true := by
  unfold bandedSparseAccessPaperColumnContract
  simp [bandedSparseAccessPaperImage_odRegisterValue_eq p j haddr]

                                                                                 
theorem bandedSparseAccessPaperColumnContract_addressInRange_eq_true_of_address_lt
    (p : OneTermRobinParameters) (j : Nat)
    (haddr : bandedSparseAccessPaperAddress p j < (1 <<< p.n)) :
    (bandedSparseAccessPaperColumnContract p j).addressInRange = true := by
  rw [bandedSparseAccessPaperColumnContract_addressInRange_eq]
  exact (bandedSparseAccessPaperAddressInRange_iff p j).2 haddr

                                                                            
theorem bandedSparseAccessPaperColumnContract_imageNoSpill_eq_true_of_address_lt
    (p : OneTermRobinParameters) (j : Nat)
    (haddr : bandedSparseAccessPaperAddress p j < (1 <<< p.n)) :
    (bandedSparseAccessPaperColumnContract p j).imageNoSpill = true := by
  rw [bandedSparseAccessPaperColumnContract_imageNoSpill_eq]
  exact bandedSparseAccessPaperImageNoSpill_eq_true_of_address_lt p j haddr

   
                                                                        
                                                                        
                                                                              
  
theorem bandedSparseAccessPaperColumnContract_registerSafety_of_address_lt
    (p : OneTermRobinParameters) (j : Nat)
    (haddr : bandedSparseAccessPaperAddress p j < (1 <<< p.n)) :
    (bandedSparseAccessPaperColumnContract p j).rowPreserved = true ∧
      (bandedSparseAccessPaperColumnContract p j).addressWritten = true ∧
      (bandedSparseAccessPaperColumnContract p j).addressInRange = true ∧
      (bandedSparseAccessPaperColumnContract p j).imageNoSpill = true := by
  exact ⟨
    bandedSparseAccessPaperColumnContract_rowPreserved_eq_true p j,
    bandedSparseAccessPaperColumnContract_addressWritten_eq_true_of_address_lt p j haddr,
    bandedSparseAccessPaperColumnContract_addressInRange_eq_true_of_address_lt p j haddr,
    bandedSparseAccessPaperColumnContract_imageNoSpill_eq_true_of_address_lt p j haddr⟩

   
                                                                      

                                           
                                                                                
                                                                           
                                                                                
                                                          
  
def bandedSparseAccessPaperMatrix (p : OneTermRobinParameters) :
    Matrix (qubitDim (oneTermRobinTotalQubits p)) (qubitDim (oneTermRobinTotalQubits p)) Coeff :=
  fun i j =>
    if i.val = bandedSparseAccessPaperImage p j.val then Coeff.rat 1 else Coeff.rat 0

                                                                                  
theorem bandedSparseAccessPaperMatrix_eq_image (p : OneTermRobinParameters)
    (i j : Fin (qubitDim (oneTermRobinTotalQubits p))) :
    bandedSparseAccessPaperMatrix p i j =
      if i.val = bandedSparseAccessPaperImage p j.val then Coeff.rat 1 else Coeff.rat 0 := by
  rfl

   
                                                            

                                                                       
                                                                         
                                                          
  
theorem bandedSparseAccessPaperMatrix_imageFin_eq_one
    (p : OneTermRobinParameters)
    (j : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (haddr : bandedSparseAccessPaperAddress p j.val < (1 <<< p.n)) :
    bandedSparseAccessPaperMatrix p (bandedSparseAccessPaperImageFin p j haddr) j =
      Coeff.rat 1 := by
  simp [bandedSparseAccessPaperMatrix, bandedSparseAccessPaperImageFin]

   
                                                                              

                                                                       
                                                                             
                                                                                
                                                                        
                  
  
def bandedSparseAccessPaperDaggerMatrix (p : OneTermRobinParameters) :
    Matrix (qubitDim (oneTermRobinTotalQubits p)) (qubitDim (oneTermRobinTotalQubits p)) Coeff :=
  fun i j =>
    if j.val = bandedSparseAccessPaperImage p i.val then Coeff.rat 1 else Coeff.rat 0

                                                                                          
theorem bandedSparseAccessPaperDaggerMatrix_eq_image (p : OneTermRobinParameters)
    (i j : Fin (qubitDim (oneTermRobinTotalQubits p))) :
    bandedSparseAccessPaperDaggerMatrix p i j =
      if j.val = bandedSparseAccessPaperImage p i.val then Coeff.rat 1 else Coeff.rat 0 := by
  rfl

   
                                                                              

                                                                            
                                                                         
  
theorem bandedSparseAccessPaperDaggerMatrix_imageFin_eq_one
    (p : OneTermRobinParameters)
    (j : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (haddr : bandedSparseAccessPaperAddress p j.val < (1 <<< p.n)) :
    bandedSparseAccessPaperDaggerMatrix p j (bandedSparseAccessPaperImageFin p j haddr) =
      Coeff.rat 1 := by
  simp [bandedSparseAccessPaperDaggerMatrix, bandedSparseAccessPaperImageFin]

   
                                                                            
                                                   

                                                                          
                                                                       
                                                                     

                                                       
                                                             
                                                                   
                                                                   
                                                                      
                                                                      
                                                      

                                          
def robinSparseAmplitudeValue (n s i : Nat) : Coeff :=
  let N := gridSize n
  let K1 := 2
  let K2 := N - 3
  if K1 ≤ i ∧ i ≤ K2 then
    match s with
    | 0 => Coeff.rat ((-1 : Rat) / 12)
    | 1 => Coeff.rat ((4 : Rat) / 3)
    | 2 => Coeff.rat ((-5 : Rat) / 2)
    | 3 => Coeff.rat ((4 : Rat) / 3)
    | 4 => Coeff.rat ((-1 : Rat) / 12)
    | _ => Coeff.rat 0
  else if i = 0 then
    match s with
    | 0 => Coeff.add (Coeff.rat ((-5 : Rat) / 2))
        (Coeff.mul (Coeff.rat ((7 : Rat) / 3)) (Coeff.symbol "A1*dx"))
    | 1 => Coeff.rat ((8 : Rat) / 3)
    | 2 => Coeff.rat ((-1 : Rat) / 6)
    | _ => Coeff.rat 0
  else if i = 1 then
    match s with
    | 0 => Coeff.add (Coeff.rat ((4 : Rat) / 3))
        (Coeff.neg (Coeff.mul (Coeff.rat ((1 : Rat) / 6)) (Coeff.symbol "A1*dx")))
    | 1 => Coeff.rat ((-31 : Rat) / 12)
    | 2 => Coeff.rat ((4 : Rat) / 3)
    | 3 => Coeff.rat ((-1 : Rat) / 12)
    | _ => Coeff.rat 0
  else if i = N - 2 then
    match s with
    | 0 => Coeff.rat ((-1 : Rat) / 12)
    | 1 => Coeff.rat ((4 : Rat) / 3)
    | 2 => Coeff.rat ((-31 : Rat) / 12)
    | 3 => Coeff.add (Coeff.rat ((4 : Rat) / 3))
        (Coeff.mul (Coeff.rat ((1 : Rat) / 6)) (Coeff.symbol "B1*dx"))
    | _ => Coeff.rat 0
  else if i = N - 1 then
    match s with
    | 0 => Coeff.rat ((-1 : Rat) / 6)
    | 1 => Coeff.rat ((8 : Rat) / 3)
    | 2 => Coeff.add (Coeff.rat ((-5 : Rat) / 2))
        (Coeff.neg (Coeff.mul (Coeff.rat ((7 : Rat) / 3)) (Coeff.symbol "B1*dx")))
    | _ => Coeff.rat 0
  else
    Coeff.rat 0

   
                                                                   

                                                                           
                                                                       
                                                                           
                                                                            
                                                      
                                                         
                                                                          
                                                            
  
def robinGlobalSparseAmplitudeValue (n s i : Nat) : Coeff :=
  let N := gridSize n
  let K1 := 2
  let K2 := N - 3
  if K1 ≤ i ∧ i ≤ K2 then
    match s with
    | 0 => Coeff.rat ((-1 : Rat) / 12)
    | 1 => Coeff.rat ((4 : Rat) / 3)
    | 2 => Coeff.rat ((-5 : Rat) / 2)
    | 3 => Coeff.rat ((4 : Rat) / 3)
    | 4 => Coeff.rat ((-1 : Rat) / 12)
    | _ => Coeff.rat 0
  else if i = 0 then
    match s with
    | 2 => Coeff.add (Coeff.rat ((-5 : Rat) / 2))
        (Coeff.mul (Coeff.rat ((7 : Rat) / 3)) (Coeff.symbol "A1*dx"))
    | 3 => Coeff.rat ((8 : Rat) / 3)
    | 4 => Coeff.rat ((-1 : Rat) / 6)
    | _ => Coeff.rat 0
  else if i = 1 then
    match s with
    | 1 => Coeff.add (Coeff.rat ((4 : Rat) / 3))
        (Coeff.neg (Coeff.mul (Coeff.rat ((1 : Rat) / 6)) (Coeff.symbol "A1*dx")))
    | 2 => Coeff.rat ((-31 : Rat) / 12)
    | 3 => Coeff.rat ((4 : Rat) / 3)
    | 4 => Coeff.rat ((-1 : Rat) / 12)
    | _ => Coeff.rat 0
  else if i = N - 2 then
    match s with
    | 0 => Coeff.rat ((-1 : Rat) / 12)
    | 1 => Coeff.rat ((4 : Rat) / 3)
    | 2 => Coeff.rat ((-31 : Rat) / 12)
    | 3 => Coeff.add (Coeff.rat ((4 : Rat) / 3))
        (Coeff.mul (Coeff.rat ((1 : Rat) / 6)) (Coeff.symbol "B1*dx"))
    | _ => Coeff.rat 0
  else if i = N - 1 then
    match s with
    | 0 => Coeff.rat ((-1 : Rat) / 6)
    | 1 => Coeff.rat ((8 : Rat) / 3)
    | 2 => Coeff.add (Coeff.rat ((-5 : Rat) / 2))
        (Coeff.neg (Coeff.mul (Coeff.rat ((7 : Rat) / 3)) (Coeff.symbol "B1*dx")))
    | _ => Coeff.rat 0
  else
    Coeff.rat 0

                                                                            
theorem robinGlobalSparseAmplitudeValue_boundarySlot2_row0_n3 :
    robinGlobalSparseAmplitudeValue 3 2 0 =
      Coeff.add (Coeff.rat ((-5 : Rat) / 2))
        (Coeff.mul (Coeff.rat ((7 : Rat) / 3)) (Coeff.symbol "A1*dx")) := by
  native_decide

   
                                                              

                                                                           
                                                         
  
theorem robinGlobalSparseAmplitudeValue_boundarySlot2_differs_rowLocal_n3 :
    robinGlobalSparseAmplitudeValue 3 2 0 ≠
      robinSparseAmplitudeValue 3 2 0 := by
  native_decide

   
                                                                      
                                       

                                                                        
                                                                           
                                                                                           
                                                                    
                                                                         
                                           
                                                                           
                                     
  
structure DerivativeNormalizerNDContract where
  sourceAnchor : String
  rowValue : Nat
  sparseIndexValue : Nat
  coefficient : Coeff
  normalizerND : Coeff
  normalizedCoefficient : Coeff
  normalizedCoefficientFormula : String
  nonzeroNormalizer : ObligationRecord
  divisionSemantics : ObligationRecord
  coefficientBound : ObligationRecord
  absSquareSemantics : ObligationRecord
  sqrtComplementSemantics : ObligationRecord
  arccosSemantics : ObligationRecord
  twoByTwoUnitary : ObligationRecord
deriving Repr, DecidableEq

   
                                                                   

                                                                              
                                                                              
                                                          
  
def derivativeNormalizerNDContract
    (p : OneTermRobinParameters) (row sparse : Nat) :
    DerivativeNormalizerNDContract where
  sourceAnchor := "Guseynov-Huang-Liu 2025, Lemma 3, Eq. (20), Fig. 1-term Robin, and boundary Ry equations, arXiv:2506.20478"
  rowValue := row
  sparseIndexValue := sparse
  coefficient := robinGlobalSparseAmplitudeValue p.n sparse row
  normalizerND := Coeff.symbol "N_D"
  normalizedCoefficient :=
    Coeff.mul (robinGlobalSparseAmplitudeValue p.n sparse row) (Coeff.symbol "N_D_inv")
  normalizedCoefficientFormula := "D_j^(s) / N_D"
  nonzeroNormalizer := {
    description := "prove N_D is nonzero before interpreting D_j^(s) / N_D"
    source := "Guseynov-Huang-Liu 2025, Lemma 3, Eq. (20), arXiv:2506.20478"
    proved := false
  }
  divisionSemantics := {
    description := "interpret the formal coefficient times N_D_inv as D_j^(s) / N_D"
    source := "Guseynov-Huang-Liu 2025, Lemma 3, Eq. (20), arXiv:2506.20478"
    proved := false
  }
  coefficientBound := {
    description := "prove the N_D bound needed for normalized derivative coefficients"
    source := "Guseynov-Huang-Liu 2025, Lemma 3, Eq. (20), and boundary Ry equations, arXiv:2506.20478"
    proved := false
  }
  absSquareSemantics := {
    description := "interpret |D_j^(s)|^2 / N_D^2 for Eq. (20)"
    source := "Guseynov-Huang-Liu 2025, Lemma 3, Eq. (20), arXiv:2506.20478"
    proved := false
  }
  sqrtComplementSemantics := {
    description := "prove the square-root complementary amplitude from the N_D bound"
    source := "Guseynov-Huang-Liu 2025, Lemma 3, Eq. (20), arXiv:2506.20478"
    proved := false
  }
  arccosSemantics := {
    description := "place D_j^(s) / N_D in the real arccos domain for boundary Ry"
    source := "Guseynov-Huang-Liu 2025, boundary Ry angle equations, arXiv:2506.20478"
    proved := false
  }
  twoByTwoUnitary := {
    description := "prove the two-by-two rotation block is unitary under the N_D bound"
    source := "Guseynov-Huang-Liu 2025, Lemma 3, Eq. (20), and boundary Ry equations, arXiv:2506.20478"
    proved := false
  }

theorem derivativeNormalizerNDContract_coefficient
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (derivativeNormalizerNDContract p row sparse).coefficient =
      robinGlobalSparseAmplitudeValue p.n sparse row := rfl

theorem derivativeNormalizerNDContract_normalizerND
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (derivativeNormalizerNDContract p row sparse).normalizerND =
      Coeff.symbol "N_D" := rfl

theorem derivativeNormalizerNDContract_normalizedCoefficient
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (derivativeNormalizerNDContract p row sparse).normalizedCoefficient =
      Coeff.mul (robinGlobalSparseAmplitudeValue p.n sparse row) (Coeff.symbol "N_D_inv") := rfl

   
                                                                   

                                                                        
                                                                           
                                                                     
          
  
structure DerivativeNormalizerNDSourceBound where
  sourceAnchor : String
  rowValue : Nat
  sparseIndexValue : Nat
  sourceCoefficient : Coeff
  normalizerND : Coeff
  boundFormula : String
  coefficientBound : ObligationRecord
deriving Repr, DecidableEq

   
                                                      
                   

                                                                                
                                                                         
                                
  
def derivativeNormalizerNDSourceBound
    (p : OneTermRobinParameters) (row sparse : Nat) :
    DerivativeNormalizerNDSourceBound :=
  let nd := derivativeNormalizerNDContract p row sparse
  {
    sourceAnchor := nd.sourceAnchor
    rowValue := nd.rowValue
    sparseIndexValue := nd.sparseIndexValue
    sourceCoefficient := nd.coefficient
    normalizerND := nd.normalizerND
    boundFormula := "|D_j^(s)| <= N_D"
    coefficientBound := nd.coefficientBound
  }

theorem derivativeNormalizerNDSourceBound_sourceCoefficient
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (derivativeNormalizerNDSourceBound p row sparse).sourceCoefficient =
      robinGlobalSparseAmplitudeValue p.n sparse row := rfl

theorem derivativeNormalizerNDSourceBound_normalizerND
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (derivativeNormalizerNDSourceBound p row sparse).normalizerND =
      Coeff.symbol "N_D" := rfl

theorem derivativeNormalizerNDSourceBound_boundFormula
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (derivativeNormalizerNDSourceBound p row sparse).boundFormula =
      "|D_j^(s)| <= N_D" := rfl

theorem derivativeNormalizerNDSourceBound_coefficientBound
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (derivativeNormalizerNDSourceBound p row sparse).coefficientBound =
      (derivativeNormalizerNDContract p row sparse).coefficientBound := rfl

theorem derivativeNormalizerNDSourceBound_coefficientBound_false
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (derivativeNormalizerNDSourceBound p row sparse).coefficientBound.proved =
      false := rfl

   
                                                                          
                                                      
                         
                                          
                                                         
                                      
                      
def indicatorOracleMatrix (p : OneTermRobinParameters) :
    Matrix (qubitDim (oneTermRobinTotalQubits p)) (qubitDim (oneTermRobinTotalQubits p)) Coeff :=
  fun i j =>
    let n := p.n
    let indPos := robinIndicatorBitPosition p
    let systemVal := (j.val >>> 1) &&& ((1 <<< n) - 1)
    let K1 := 2
    let K2 := gridSize n - 3
    let isBulk := if K1 ≤ systemVal ∧ systemVal ≤ K2 then (1 : Nat) else 0
    let expectedImage := j.val ^^^ (isBulk <<< indPos)
    if i.val = expectedImage then Coeff.rat 1 else Coeff.rat 0

   
                                                            
                                                                               
                                                                                
                                                                                        
                      
def oneTermRobinGate_U_indic (p : OneTermRobinParameters) : GateMatrix Coeff (oneTermRobinTotalQubits p) where
  gate := Gate.oracleCall "U_indic"
  matrix := indicatorOracleMatrix p
  unitary := {
    description := "U_indic(K1,K2) permutation matrix: unitarity proved via indicatorOracleMatrix_is_permutation"
    source := "main.tex:1088-1099"
    proved := true
  }

   
                                                      

                                                                              
                                                                              
                                                                          
                            
  
def oneTermRobinGate_U_indic_dagger (p : OneTermRobinParameters) :
    GateMatrix Coeff (oneTermRobinTotalQubits p) where
  gate := Gate.oracleCall "U_indic^dagger"
  matrix := indicatorOracleMatrix p
  unitary := {
    description := "U_indic^dagger uses the same self-inverse indicator permutation matrix as U_indic"
    source := "GHL2025 Fig. 1-term Robin transcript slot; self-inverse bridge from indicatorOracleImage_self_inverse"
    proved := true
  }

   
                                                                          

                                                                              
                                  
  
theorem oneTermRobinGate_U_indic_dagger_matrix_eq
    (p : OneTermRobinParameters) :
    (oneTermRobinGate_U_indic_dagger p).matrix =
      (oneTermRobinGate_U_indic p).matrix := rfl

   
                                                                                
                                                                                 

                                  
                                                                                
                                                                                        
                                  

                                                                              
                                                                             
                                                                                   
                    
def sparseAmplitudeOracleDTMatrix (p : OneTermRobinParameters) :
    Matrix (qubitDim (oneTermRobinTotalQubits p)) (qubitDim (oneTermRobinTotalQubits p)) Coeff :=
  fun i j =>
    if i.val ≠ j.val then Coeff.rat 0
    else
      let n := p.n
      let indPos := robinIndicatorBitPosition p
      let indBit := (j.val >>> indPos) &&& 1
      if indBit = 0 then
        Coeff.rat 1
      else
        let kappa := p.kappa
        let κbits := clog2 kappa
        let odPure := n - κbits
        let sysMask := (1 <<< n) - 1
        let sysVal := (j.val >>> 1) &&& sysMask
        let sparseStart := 1 + n + odPure
        let sparseMask := (1 <<< κbits) - 1
        let sparseVal := (j.val >>> sparseStart) &&& sparseMask
        robinSparseAmplitudeValue n sparseVal sysVal

   
                                                               

                                                                              
                                                                             
                                                                          
                                                                             
                                                      
structure SparseAmplitudeOracleDTPaperRegisters where
  ancillaBit : Nat
  indicatorBit : Nat
  rowValue : Nat
  sparseIndexValue : Nat
  nonAncillaValue : Nat
deriving Repr, DecidableEq

   
                                                                           
                                                                              
                                                                          
  
def sparseAmplitudeOracleDTPaperRegisters (p : OneTermRobinParameters) (j : Nat) :
    SparseAmplitudeOracleDTPaperRegisters :=
  let n := p.n
  let indPos := robinIndicatorBitPosition p
  let κbits := clog2 p.kappa
  let odPure := n - κbits
  let sysMask := (1 <<< n) - 1
  let sparseStart := 1 + n + odPure
  let sparseMask := (1 <<< κbits) - 1
  {
    ancillaBit := j &&& 1
    indicatorBit := (j >>> indPos) &&& 1
    rowValue := (j >>> 1) &&& sysMask
    sparseIndexValue := (j >>> sparseStart) &&& sparseMask
    nonAncillaValue := j >>> 1
  }

                                                                        
def sparseAmplitudeOracleDTCosHalf (row sparse : Nat) : Coeff :=
  Coeff.symbol s!"odts_cos_half_{row}_{sparse}"

                                                                      
def sparseAmplitudeOracleDTSinHalf (row sparse : Nat) : Coeff :=
  Coeff.symbol s!"odts_sin_half_{row}_{sparse}"

   
                                                                             
                           

                                                                            
                                                                         
                                              
                                               
                                                                            
                                                                          
                        
  
def sparseAmplitudeOracleDTCoefficientNormalizerObligation : ObligationRecord := {
  description := "O_DT^S symbolic rotation entries match Eq. (20): D^(s)/N_D amplitude and complementary normalizer term"
  source := "Guseynov-Huang-Liu 2025, Lemma 3, Eq. (20), arXiv:2506.20478"
  proved := false
}

   
                                                                               

                                                                     
                                                                              
                                                                          
                                                                               
      
  
structure SparseAmplitudeOracleDTCoefficientNormalizerContract where
  sourceAnchor : String
  rowValue : Nat
  sparseIndexValue : Nat
  coefficient : Coeff
  normalizerND : Coeff
  ketZeroEntry : Coeff
  ketOneEntry : Coeff
  ketZeroFormula : String
  ketOneFormula : String
  coefficientRelation : ObligationRecord
  complementRelation : ObligationRecord
  twoByTwoUnitary : ObligationRecord
deriving Repr, DecidableEq

   
                                                                           
                                                                                     
                                                                                 
  
def sparseAmplitudeOracleDTCoefficientNormalizerContract
    (p : OneTermRobinParameters) (row sparse : Nat) :
    SparseAmplitudeOracleDTCoefficientNormalizerContract where
  sourceAnchor := "Guseynov-Huang-Liu 2025, Lemma 3, Eq. (20), arXiv:2506.20478"
  rowValue := row
  sparseIndexValue := sparse
  coefficient := robinGlobalSparseAmplitudeValue p.n sparse row
  normalizerND := Coeff.symbol "N_D"
  ketZeroEntry := sparseAmplitudeOracleDTCosHalf row sparse
  ketOneEntry := sparseAmplitudeOracleDTSinHalf row sparse
  ketZeroFormula := "D_j^(s) / N_D"
  ketOneFormula := "sqrt(1 - |D_j^(s)|^2 / N_D^2)"
  coefficientRelation := {
    description := "ket-zero rotation entry equals D_j^(s) / N_D"
    source := "Guseynov-Huang-Liu 2025, Lemma 3, Eq. (20), arXiv:2506.20478"
    proved := false
  }
  complementRelation := {
    description := "ket-one rotation entry equals sqrt(1 - |D_j^(s)|^2 / N_D^2)"
    source := "Guseynov-Huang-Liu 2025, Lemma 3, Eq. (20), arXiv:2506.20478"
    proved := false
  }
  twoByTwoUnitary := {
    description := "the Eq. (20) two-by-two ancilla block is unitary under the N_D bound"
    source := "Guseynov-Huang-Liu 2025, Lemma 3, Eq. (20), arXiv:2506.20478"
    proved := false
  }

   
                                                                         

                                                                           
                                                                           
                                                                      
  
def sparseAmplitudeOracleDTNormalizedCoefficient
    (p : OneTermRobinParameters) (row sparse : Nat) : Coeff :=
  Coeff.mul (robinGlobalSparseAmplitudeValue p.n sparse row) (Coeff.symbol "N_D_inv")

   
                                                          

                                                                            
                                                                              
                                                                            
                                  
  
structure SparseAmplitudeOracleDTCoefficientNormalizerProofRoute where
  sourceAnchor : String
  rowValue : Nat
  sparseIndexValue : Nat
  coefficient : Coeff
  normalizerND : Coeff
  normalizedCoefficient : Coeff
  normalizedCoefficientFormula : String
  ketZeroEntry : Coeff
  ketOneEntry : Coeff
  ketZeroFormula : String
  ketOneFormula : String
  coefficientDivision : ObligationRecord
  normalizerBound : ObligationRecord
  absSquareSemantics : ObligationRecord
  sqrtComplementSemantics : ObligationRecord
  twoByTwoUnitary : ObligationRecord
deriving Repr, DecidableEq

   
                                                                            
                                                                        
                                                             
  
def sparseAmplitudeOracleDTCoefficientNormalizerProofRoute
    (p : OneTermRobinParameters) (row sparse : Nat) :
    SparseAmplitudeOracleDTCoefficientNormalizerProofRoute :=
  let c := sparseAmplitudeOracleDTCoefficientNormalizerContract p row sparse
  let nd := derivativeNormalizerNDContract p row sparse
  {
    sourceAnchor := c.sourceAnchor
    rowValue := c.rowValue
    sparseIndexValue := c.sparseIndexValue
    coefficient := c.coefficient
    normalizerND := nd.normalizerND
    normalizedCoefficient := nd.normalizedCoefficient
    normalizedCoefficientFormula := nd.normalizedCoefficientFormula
    ketZeroEntry := c.ketZeroEntry
    ketOneEntry := c.ketOneEntry
    ketZeroFormula := c.ketZeroFormula
    ketOneFormula := c.ketOneFormula
    coefficientDivision := nd.divisionSemantics
    normalizerBound := nd.coefficientBound
    absSquareSemantics := nd.absSquareSemantics
    sqrtComplementSemantics := nd.sqrtComplementSemantics
    twoByTwoUnitary := c.twoByTwoUnitary
  }

theorem sparseAmplitudeOracleDTCoefficientNormalizerProofRoute_coefficient
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).coefficient =
      (sparseAmplitudeOracleDTCoefficientNormalizerContract p row sparse).coefficient := rfl

theorem sparseAmplitudeOracleDTCoefficientNormalizerProofRoute_normalizerND
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).normalizerND =
      (sparseAmplitudeOracleDTCoefficientNormalizerContract p row sparse).normalizerND := rfl

theorem sparseAmplitudeOracleDTCoefficientNormalizerProofRoute_normalizedCoefficient
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).normalizedCoefficient =
      sparseAmplitudeOracleDTNormalizedCoefficient p row sparse := rfl

theorem sparseAmplitudeOracleDTCoefficientNormalizerProofRoute_sharedND
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).normalizerBound =
      (derivativeNormalizerNDContract p row sparse).coefficientBound ∧
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).coefficientDivision =
      (derivativeNormalizerNDContract p row sparse).divisionSemantics ∧
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).absSquareSemantics =
      (derivativeNormalizerNDContract p row sparse).absSquareSemantics ∧
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).sqrtComplementSemantics =
      (derivativeNormalizerNDContract p row sparse).sqrtComplementSemantics := by
  exact ⟨rfl, rfl, rfl, rfl⟩

theorem sparseAmplitudeOracleDTCoefficientNormalizerProofRoute_sourceBound
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).coefficient =
      (derivativeNormalizerNDSourceBound p row sparse).sourceCoefficient ∧
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).normalizerND =
      (derivativeNormalizerNDSourceBound p row sparse).normalizerND ∧
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).normalizerBound =
      (derivativeNormalizerNDSourceBound p row sparse).coefficientBound := by
  exact ⟨rfl, rfl, rfl⟩

theorem sparseAmplitudeOracleDTCoefficientNormalizerProofRoute_ketZeroEntry
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).ketZeroEntry =
      (sparseAmplitudeOracleDTCoefficientNormalizerContract p row sparse).ketZeroEntry := rfl

theorem sparseAmplitudeOracleDTCoefficientNormalizerProofRoute_ketOneEntry
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).ketOneEntry =
      (sparseAmplitudeOracleDTCoefficientNormalizerContract p row sparse).ketOneEntry := rfl

   
                                                           

                                                                               
                                                                          
                                                                              
                                                                       
                                                                               
                                                    
                                                      
def sparseAmplitudeOracleDTRotationMatrix (p : OneTermRobinParameters) :
    Matrix (qubitDim (oneTermRobinTotalQubits p)) (qubitDim (oneTermRobinTotalQubits p)) Coeff :=
  fun i j =>
    let regs := sparseAmplitudeOracleDTPaperRegisters p j.val
    if regs.indicatorBit = 0 then
      if i.val = j.val then Coeff.rat 1 else Coeff.rat 0
    else if i.val >>> 1 ≠ regs.nonAncillaValue then
      Coeff.rat 0
    else
      let cosHalf := sparseAmplitudeOracleDTCosHalf regs.rowValue regs.sparseIndexValue
      let sinHalf := sparseAmplitudeOracleDTSinHalf regs.rowValue regs.sparseIndexValue
      let anc_i := i.val &&& 1
      match regs.ancillaBit, anc_i with
      | 0, 0 => cosHalf
      | 0, 1 => sinHalf
      | 1, 0 => Coeff.neg sinHalf
      | _, _ => cosHalf

   
                                                                       
                                                                               
                                                                            
                                                                      
                                                                    
                    
def oneTermRobinGate_O_DT_S (p : OneTermRobinParameters) : GateMatrix Coeff (oneTermRobinTotalQubits p) where
  gate := Gate.oracleCall "O_DT^S"
  matrix := sparseAmplitudeOracleDTRotationMatrix p
  unitary := {
    description := "O_DT^S controlled-rotation skeleton on ancilla bit: unitarity and normalizer bound not yet proved"
    source := "Guseynov-Huang-Liu 2025, Lemma 3, arXiv:2506.20478"
    proved := false
  }

   
                                                                   

                                                                        
                                                                          
                                                                              
                                                                              
                                              
                                                                 
                    
structure BoundaryRotationPaperRegisters where
  ancillaBit : Nat
  indicatorBit : Nat
  rowValue : Nat
  sparseIndexValue : Nat
  nonAncillaValue : Nat
deriving Repr, DecidableEq

   
                                                                      
                                                                             
                                         
  
def boundaryRotationPaperRegisters (p : OneTermRobinParameters) (j : Nat) :
    BoundaryRotationPaperRegisters :=
  let n := p.n
  let indPos := robinIndicatorBitPosition p
  let κbits := clog2 p.kappa
  let odPure := n - κbits
  let sysMask := (1 <<< n) - 1
  let sparseStart := 1 + n + odPure
  let sparseMask := (1 <<< κbits) - 1
  {
    ancillaBit := j &&& 1
    indicatorBit := (j >>> indPos) &&& 1
    rowValue := (j >>> 1) &&& sysMask
    sparseIndexValue := (j >>> sparseStart) &&& sparseMask
    nonAncillaValue := j >>> 1
  }

                                                                       
def boundaryRotationCosHalf (row sparse : Nat) : Coeff :=
  Coeff.symbol s!"boundary_cos_half_{row}_{sparse}"

                                                                     
def boundaryRotationSinHalf (row sparse : Nat) : Coeff :=
  Coeff.symbol s!"boundary_sin_half_{row}_{sparse}"

   
                                                                            
         

                                                                            
                                                         
                                                                          
                                                                
  
def boundaryRotationAngleNormalizerObligation : ObligationRecord := {
  description := "Ry_boundary symbolic entries match theta_j^s = arccos(D_j^(s) / N_D) and the half-angle formulas"
  source := "Guseynov-Huang-Liu 2025, Fig. 1-term Robin and Eq. angles for Ry, arXiv:2506.20478"
  proved := false
}

   
                                                                     

                                                                              
                                                                               
                                                                       
                                          
  
structure BoundaryRotationAngleNormalizerContract where
  sourceAnchor : String
  rowValue : Nat
  sparseIndexValue : Nat
  coefficient : Coeff
  normalizerND : Coeff
  thetaFormula : String
  cosHalfEntry : Coeff
  sinHalfEntry : Coeff
  cosHalfFormula : String
  sinHalfFormula : String
  boundaryControl : ObligationRecord
  arccosArgumentRelation : ObligationRecord
  cosHalfRelation : ObligationRecord
  sinHalfRelation : ObligationRecord
  twoByTwoUnitary : ObligationRecord
deriving Repr, DecidableEq

   
                                                                            
                                                                                     
                                                                  
  
def boundaryRotationAngleNormalizerContract
    (p : OneTermRobinParameters) (row sparse : Nat) :
    BoundaryRotationAngleNormalizerContract where
  sourceAnchor := "Guseynov-Huang-Liu 2025, Fig. 1-term Robin and Eq. angles for Ry, arXiv:2506.20478"
  rowValue := row
  sparseIndexValue := sparse
  coefficient := robinGlobalSparseAmplitudeValue p.n sparse row
  normalizerND := Coeff.symbol "N_D"
  thetaFormula := "theta_j^s = arccos(D_j^(s) / N_D)"
  cosHalfEntry := boundaryRotationCosHalf row sparse
  sinHalfEntry := boundaryRotationSinHalf row sparse
  cosHalfFormula := "sqrt((1 + D_j^(s) / N_D) / 2)"
  sinHalfFormula := "sqrt((1 - D_j^(s) / N_D) / 2)"
  boundaryControl := {
    description := "Ry_boundary acts only on boundary rows selected by indicator bit 0"
    source := "Guseynov-Huang-Liu 2025, Fig. 1-term Robin, arXiv:2506.20478"
    proved := false
  }
  arccosArgumentRelation := {
    description := "theta_j^s is arccos(D_j^(s) / N_D) for the recorded Robin coefficient; blocked until Coeff has division and real arccos semantics"
    source := "Guseynov-Huang-Liu 2025, Eq. angles for Ry, arXiv:2506.20478"
    proved := false
  }
  cosHalfRelation := {
    description := "cos(theta_j^s / 2) equals sqrt((1 + D_j^(s) / N_D) / 2); blocked until Coeff has square-root and half-angle semantics"
    source := "Guseynov-Huang-Liu 2025, Eq. angles for Ry, arXiv:2506.20478"
    proved := false
  }
  sinHalfRelation := {
    description := "sin(theta_j^s / 2) equals sqrt((1 - D_j^(s) / N_D) / 2); blocked until Coeff has square-root and half-angle semantics"
    source := "Guseynov-Huang-Liu 2025, Eq. angles for Ry, arXiv:2506.20478"
    proved := false
  }
  twoByTwoUnitary := {
    description := "the Ry_boundary two-by-two block is unitary under the N_D bound"
    source := "Guseynov-Huang-Liu 2025, Eq. angles for Ry, arXiv:2506.20478"
    proved := false
  }

   
                                                                            
                                                  
  
theorem boundaryRotationAngleNormalizerContract_coefficient
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (boundaryRotationAngleNormalizerContract p row sparse).coefficient =
      robinGlobalSparseAmplitudeValue p.n sparse row := rfl

   
                                                         

                                                                            
                                                                               
                                                                       
  
def boundaryRotationNormalizedCoefficient
    (p : OneTermRobinParameters) (row sparse : Nat) : Coeff :=
  Coeff.mul (robinGlobalSparseAmplitudeValue p.n sparse row) (Coeff.symbol "N_D_inv")

   
                                                         

                                                       
                                                                              
                                                                               
                                                                              
           
  
structure BoundaryRotationAngleNormalizerProofRoute where
  sourceAnchor : String
  rowValue : Nat
  sparseIndexValue : Nat
  coefficient : Coeff
  normalizerND : Coeff
  arccosArgument : Coeff
  arccosArgumentFormula : String
  thetaFormula : String
  cosHalfEntry : Coeff
  sinHalfEntry : Coeff
  cosHalfFormula : String
  sinHalfFormula : String
  coefficientDivision : ObligationRecord
  realArccosSemantics : ObligationRecord
  halfAngleSemantics : ObligationRecord
  normalizerBound : ObligationRecord
  twoByTwoUnitary : ObligationRecord
deriving Repr, DecidableEq

   
                                                                         

                                                           
                                                                               
                                          
  
def boundaryRotationAngleNormalizerProofRoute
    (p : OneTermRobinParameters) (row sparse : Nat) :
    BoundaryRotationAngleNormalizerProofRoute :=
  let c := boundaryRotationAngleNormalizerContract p row sparse
  let nd := derivativeNormalizerNDContract p row sparse
  {
    sourceAnchor := c.sourceAnchor
    rowValue := c.rowValue
    sparseIndexValue := c.sparseIndexValue
    coefficient := c.coefficient
    normalizerND := nd.normalizerND
    arccosArgument := nd.normalizedCoefficient
    arccosArgumentFormula := nd.normalizedCoefficientFormula
    thetaFormula := c.thetaFormula
    cosHalfEntry := c.cosHalfEntry
    sinHalfEntry := c.sinHalfEntry
    cosHalfFormula := c.cosHalfFormula
    sinHalfFormula := c.sinHalfFormula
    coefficientDivision := nd.divisionSemantics
    realArccosSemantics := nd.arccosSemantics
    halfAngleSemantics := {
      description := "derive the displayed cosine and sine half-angle formulas from theta_j^s"
      source := "Guseynov-Huang-Liu 2025, Eq. angles for Ry, arXiv:2506.20478"
      proved := false
    }
    normalizerBound := nd.coefficientBound
    twoByTwoUnitary := c.twoByTwoUnitary
  }

theorem boundaryRotationAngleNormalizerProofRoute_coefficient
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (boundaryRotationAngleNormalizerProofRoute p row sparse).coefficient =
      (boundaryRotationAngleNormalizerContract p row sparse).coefficient := rfl

theorem boundaryRotationAngleNormalizerProofRoute_arccosArgument
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (boundaryRotationAngleNormalizerProofRoute p row sparse).arccosArgument =
      boundaryRotationNormalizedCoefficient p row sparse := rfl

theorem boundaryRotationAngleNormalizerProofRoute_sharedND
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (boundaryRotationAngleNormalizerProofRoute p row sparse).normalizerBound =
      (derivativeNormalizerNDContract p row sparse).coefficientBound ∧
    (boundaryRotationAngleNormalizerProofRoute p row sparse).coefficientDivision =
      (derivativeNormalizerNDContract p row sparse).divisionSemantics ∧
    (boundaryRotationAngleNormalizerProofRoute p row sparse).realArccosSemantics =
      (derivativeNormalizerNDContract p row sparse).arccosSemantics := by
  exact ⟨rfl, rfl, rfl⟩

theorem boundaryRotationAngleNormalizerProofRoute_sourceBound
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (boundaryRotationAngleNormalizerProofRoute p row sparse).coefficient =
      (derivativeNormalizerNDSourceBound p row sparse).sourceCoefficient ∧
    (boundaryRotationAngleNormalizerProofRoute p row sparse).normalizerND =
      (derivativeNormalizerNDSourceBound p row sparse).normalizerND ∧
    (boundaryRotationAngleNormalizerProofRoute p row sparse).normalizerBound =
      (derivativeNormalizerNDSourceBound p row sparse).coefficientBound := by
  exact ⟨rfl, rfl, rfl⟩

theorem derivativeNormalizerNDSourceBound_sharedRoutes
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).coefficient =
      (boundaryRotationAngleNormalizerProofRoute p row sparse).coefficient ∧
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).normalizerND =
      (boundaryRotationAngleNormalizerProofRoute p row sparse).normalizerND ∧
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).normalizerBound =
      (boundaryRotationAngleNormalizerProofRoute p row sparse).normalizerBound := by
  exact ⟨rfl, rfl, rfl⟩

   
                                                                         
                                     

                                                                            
                                                                          
  
theorem robinGlobalSparseAmplitudeValue_sharedNormalizerRoutes
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (derivativeNormalizerNDSourceBound p row sparse).sourceCoefficient =
      robinGlobalSparseAmplitudeValue p.n sparse row ∧
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).coefficient =
      robinGlobalSparseAmplitudeValue p.n sparse row ∧
    (boundaryRotationAngleNormalizerProofRoute p row sparse).coefficient =
      robinGlobalSparseAmplitudeValue p.n sparse row ∧
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).coefficient =
      (boundaryRotationAngleNormalizerProofRoute p row sparse).coefficient := by
  exact ⟨rfl, rfl, rfl, rfl⟩

   
                                                                                
                                                        

                                                            
                                                                         
                                                                            

                                       
                                                 
                                                 

                                                                          
                                                                       
                      
def boundaryRotationMatrix (p : OneTermRobinParameters) :
    Matrix (qubitDim (oneTermRobinTotalQubits p)) (qubitDim (oneTermRobinTotalQubits p)) Coeff :=
  fun i j =>
    let n := p.n
    let indPos := robinIndicatorBitPosition p
    let indBit_j := (j.val >>> indPos) &&& 1
    if indBit_j = 1 then
      if i.val = j.val then Coeff.rat 1 else Coeff.rat 0
    else
      let anc_j := j.val &&& 1
      let anc_i := i.val &&& 1
      if i.val >>> 1 ≠ j.val >>> 1 then Coeff.rat 0
      else
        let kappa := p.kappa
        let κbits := clog2 kappa
        let odPure := n - κbits
        let sysMask := (1 <<< n) - 1
        let sysVal := (j.val >>> 1) &&& sysMask
        let sparseStart := 1 + n + odPure
        let sparseMask := (1 <<< κbits) - 1
        let sparseVal := (j.val >>> sparseStart) &&& sparseMask
        let cosHalf := boundaryRotationCosHalf sysVal sparseVal
        let sinHalf := boundaryRotationSinHalf sysVal sparseVal
        match anc_j, anc_i with
        | 0, 0 => cosHalf
        | 0, 1 => sinHalf
        | 1, 0 => Coeff.neg sinHalf
        | _, _ => cosHalf

   
                                                                        
                                                                  
                                     
                                  
                      
def oneTermRobinGate_Ry_boundary (p : OneTermRobinParameters) : GateMatrix Coeff (oneTermRobinTotalQubits p) where
  gate := Gate.oracleCall "Ry_boundary"
  matrix := boundaryRotationMatrix p
  unitary := {
    description := "Ry_boundary honest controlled rotation matrix: unitarity not yet proved"
    source := "Guseynov-Huang-Liu 2025, Fig. 1-term Robin and Eq. angles for Ry, arXiv:2506.20478"
    proved := false
  }

   
                                         

                                                                             
                                                                         
                                   
                                                                  
                 
  
theorem derivativeNormalizerNDSharedRoute_flags_false
    (p : OneTermRobinParameters) (row sparse : Nat) :
    (derivativeNormalizerNDContract p row sparse).nonzeroNormalizer.proved = false ∧
    (derivativeNormalizerNDContract p row sparse).divisionSemantics.proved = false ∧
    (derivativeNormalizerNDContract p row sparse).coefficientBound.proved = false ∧
    (derivativeNormalizerNDContract p row sparse).absSquareSemantics.proved = false ∧
    (derivativeNormalizerNDContract p row sparse).sqrtComplementSemantics.proved = false ∧
    (derivativeNormalizerNDContract p row sparse).arccosSemantics.proved = false ∧
    (derivativeNormalizerNDContract p row sparse).twoByTwoUnitary.proved = false ∧
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).coefficientDivision.proved = false ∧
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).normalizerBound.proved = false ∧
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).absSquareSemantics.proved = false ∧
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).sqrtComplementSemantics.proved = false ∧
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).twoByTwoUnitary.proved = false ∧
    (boundaryRotationAngleNormalizerProofRoute p row sparse).coefficientDivision.proved = false ∧
    (boundaryRotationAngleNormalizerProofRoute p row sparse).realArccosSemantics.proved = false ∧
    (boundaryRotationAngleNormalizerProofRoute p row sparse).halfAngleSemantics.proved = false ∧
    (boundaryRotationAngleNormalizerProofRoute p row sparse).normalizerBound.proved = false ∧
    (boundaryRotationAngleNormalizerProofRoute p row sparse).twoByTwoUnitary.proved = false ∧
    (oneTermRobinGate_O_DT_S p).unitary.proved = false ∧
    (oneTermRobinGate_Ry_boundary p).unitary.proved = false := by
  exact ⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl,
    rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl⟩

   
                                                  

                                                                              
                                                                        
                                                                               
               
  
theorem derivativeNormalizerNDSharedRoute_sourceBoundAndFlags
    (p : OneTermRobinParameters) (row sparse : Nat) :
    ((sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).coefficient =
        (derivativeNormalizerNDSourceBound p row sparse).sourceCoefficient ∧
      (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).normalizerND =
        (derivativeNormalizerNDSourceBound p row sparse).normalizerND ∧
      (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).normalizerBound =
        (derivativeNormalizerNDSourceBound p row sparse).coefficientBound) ∧
    ((boundaryRotationAngleNormalizerProofRoute p row sparse).coefficient =
        (derivativeNormalizerNDSourceBound p row sparse).sourceCoefficient ∧
      (boundaryRotationAngleNormalizerProofRoute p row sparse).normalizerND =
        (derivativeNormalizerNDSourceBound p row sparse).normalizerND ∧
      (boundaryRotationAngleNormalizerProofRoute p row sparse).normalizerBound =
        (derivativeNormalizerNDSourceBound p row sparse).coefficientBound) ∧
    ((sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).coefficient =
        (boundaryRotationAngleNormalizerProofRoute p row sparse).coefficient ∧
      (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).normalizerND =
        (boundaryRotationAngleNormalizerProofRoute p row sparse).normalizerND ∧
      (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).normalizerBound =
        (boundaryRotationAngleNormalizerProofRoute p row sparse).normalizerBound) ∧
    (derivativeNormalizerNDContract p row sparse).nonzeroNormalizer.proved = false ∧
    (derivativeNormalizerNDContract p row sparse).divisionSemantics.proved = false ∧
    (derivativeNormalizerNDContract p row sparse).coefficientBound.proved = false ∧
    (derivativeNormalizerNDContract p row sparse).absSquareSemantics.proved = false ∧
    (derivativeNormalizerNDContract p row sparse).sqrtComplementSemantics.proved = false ∧
    (derivativeNormalizerNDContract p row sparse).arccosSemantics.proved = false ∧
    (derivativeNormalizerNDContract p row sparse).twoByTwoUnitary.proved = false ∧
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).coefficientDivision.proved = false ∧
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).normalizerBound.proved = false ∧
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).absSquareSemantics.proved = false ∧
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).sqrtComplementSemantics.proved = false ∧
    (sparseAmplitudeOracleDTCoefficientNormalizerProofRoute p row sparse).twoByTwoUnitary.proved = false ∧
    (boundaryRotationAngleNormalizerProofRoute p row sparse).coefficientDivision.proved = false ∧
    (boundaryRotationAngleNormalizerProofRoute p row sparse).realArccosSemantics.proved = false ∧
    (boundaryRotationAngleNormalizerProofRoute p row sparse).halfAngleSemantics.proved = false ∧
    (boundaryRotationAngleNormalizerProofRoute p row sparse).normalizerBound.proved = false ∧
    (boundaryRotationAngleNormalizerProofRoute p row sparse).twoByTwoUnitary.proved = false ∧
    (oneTermRobinGate_O_DT_S p).unitary.proved = false ∧
    (oneTermRobinGate_Ry_boundary p).unitary.proved = false := by
  exact ⟨
    sparseAmplitudeOracleDTCoefficientNormalizerProofRoute_sourceBound p row sparse,
    boundaryRotationAngleNormalizerProofRoute_sourceBound p row sparse,
    derivativeNormalizerNDSourceBound_sharedRoutes p row sparse,
    derivativeNormalizerNDSharedRoute_flags_false p row sparse⟩

   
                                                                        
                                                                     
                                                                   
                                                              
                                                                       
                                                          
                    
def bandedSparseAccessMatrix (p : OneTermRobinParameters) :
    Matrix (qubitDim (oneTermRobinTotalQubits p)) (qubitDim (oneTermRobinTotalQubits p)) Coeff :=
  fun i j =>
    let n := p.n
    let kappa := p.kappa
    let κbits := clog2 kappa
    let odPure := n - κbits
    let sysMask := (1 <<< n) - 1
    let sysVal := (j.val >>> 1) &&& sysMask
    let sparseStart := 1 + n + odPure
    let sparseMask := (1 <<< κbits) - 1
    let sparseVal := (j.val >>> sparseStart) &&& sparseMask
    let col := robinSparseColumnMap n sparseVal sysVal
    let expectedImage := j.val - (j.val &&& (sysMask <<< 1)) + (col <<< 1)
    if i.val = expectedImage then Coeff.rat 1 else Coeff.rat 0

   
                                                                        

                                                                        
                                                                               
                                                                      
                                                      
def oneTermRobinGate_O_D_BS (p : OneTermRobinParameters) : GateMatrix Coeff (oneTermRobinTotalQubits p) where
  gate := Gate.oracleCall "O_D^BS"
  matrix := bandedSparseAccessPaperMatrix p
  unitary := {
    description := "O_D^BS paper-image matrix skeleton: unitarity and cleanup not yet proved"
    source := "Guseynov-Huang-Liu 2025, Lemma 1, arXiv:2506.20478"
    proved := false
  }

                                                                    
theorem oneTermRobinGate_O_D_BS_imageFin_eq_one
    (p : OneTermRobinParameters)
    (j : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (haddr : bandedSparseAccessPaperAddress p j.val < (1 <<< p.n)) :
    (oneTermRobinGate_O_D_BS p).matrix
        (bandedSparseAccessPaperImageFin p j haddr) j =
      Coeff.rat 1 := by
  simpa [oneTermRobinGate_O_D_BS]
    using bandedSparseAccessPaperMatrix_imageFin_eq_one p j haddr

   
                                                                              
                                     

                                                                              
                                                                             
                                                                               
                                                                           
                                                
  
theorem oneTermRobinGate_O_D_BS_contractDrift_column8_n3 :
    let p : OneTermRobinParameters :=
      { n := 3, kappa := 7, functionPieces := 1, polynomialDegreeCost := 1 }
    bandedSparseAccessPaperImage p 8 = 40 ∧
      (oneTermRobinGate_O_D_BS p).matrix
          ⟨40, by native_decide⟩ ⟨8, by native_decide⟩ = Coeff.rat 1 ∧
      (oneTermRobinGate_O_D_BS p).matrix
          ⟨4, by native_decide⟩ ⟨8, by native_decide⟩ = Coeff.rat 0 ∧
      (bandedSparseAccessMatrix p)
          ⟨4, by native_decide⟩ ⟨8, by native_decide⟩ = Coeff.rat 1 ∧
      (oneTermRobinGate_O_D_BS p).unitary.proved = false := by
  native_decide

   
                                                                             

                                                                           
                                                                          
                                                                          
                                                                           
                                                                  
  
theorem oneTermRobinGate_O_D_BS_boundaryUnusedSparseCollision_n3 :
    let p : OneTermRobinParameters :=
      { n := 3, kappa := 7, functionPieces := 1, polynomialDegreeCost := 1 }
    bandedSparseAccessPaperCleanInput p 0 = true ∧
      bandedSparseAccessPaperCleanInput p 48 = true ∧
      (bandedSparseAccessPaperRegisters p 0).rowValue = 0 ∧
      (bandedSparseAccessPaperRegisters p 48).rowValue = 0 ∧
      (bandedSparseAccessPaperRegisters p 0).sparseIndexValue = 0 ∧
      (bandedSparseAccessPaperRegisters p 48).sparseIndexValue = 3 ∧
      bandedSparseAccessRowDependentPaperAddress p 0 = 0 ∧
      bandedSparseAccessRowDependentPaperAddress p 48 = 0 ∧
      bandedSparseAccessRowDependentPaperImage p 0 =
        bandedSparseAccessRowDependentPaperImage p 48 ∧
      bandedSparseAccessPaperAddress p 0 = 6 ∧
      bandedSparseAccessPaperAddress p 48 = 1 ∧
      bandedSparseAccessPaperImage p 0 ≠ bandedSparseAccessPaperImage p 48 ∧
      0 ≠ 48 := by
  native_decide

   
                                                                             
                                             

                                                                             
                                   
  
theorem oneTermRobinGate_O_D_BS_globalSparseBoundaryNoCollision_n3 :
    let p : OneTermRobinParameters :=
      { n := 3, kappa := 7, functionPieces := 1, polynomialDegreeCost := 1 }
    bandedSparseAccessPaperCleanInput p 0 = true ∧
      bandedSparseAccessPaperCleanInput p 48 = true ∧
      bandedSparseAccessPaperAddress p 0 = 6 ∧
      bandedSparseAccessPaperAddress p 48 = 1 ∧
      bandedSparseAccessPaperImage p 0 = 96 ∧
      bandedSparseAccessPaperImage p 48 = 16 ∧
      bandedSparseAccessPaperImage p 0 ≠ bandedSparseAccessPaperImage p 48 ∧
      (oneTermRobinGate_O_D_BS p).matrix
          ⟨96, by native_decide⟩ ⟨0, by native_decide⟩ = Coeff.rat 1 ∧
      (oneTermRobinGate_O_D_BS p).matrix
          ⟨16, by native_decide⟩ ⟨48, by native_decide⟩ = Coeff.rat 1 ∧
      (oneTermRobinGate_O_D_BS p).unitary.proved = false := by
  native_decide

   
                                                                              
                                                                    
                          

                                                                       
                                                                         
  
theorem bandedSparseAccessPaperGlobalSlotSource_boundaryColumns_n3 :
    let p : OneTermRobinParameters :=
      { n := 3, kappa := 7, functionPieces := 1, polynomialDegreeCost := 1 }
    bandedSparseAccessPaperGlobalSlotSource p 0 = true ∧
      bandedSparseAccessPaperGlobalSlotSource p 48 = true ∧
      bandedSparseAccessPaperValidCleanSource p 48 = false ∧
      bandedSparseAccessPaperImage p 0 ≠ bandedSparseAccessPaperImage p 48 ∧
      (oneTermRobinGate_O_D_BS p).unitary.proved = false := by
  native_decide

   
                                                                        
                                                                            
                                   
  
theorem bandedSparseAccessPaperGlobalSlotSource_encodedOutOfRange_n3 :
    let p : OneTermRobinParameters :=
      { n := 3, kappa := 7, functionPieces := 1, polynomialDegreeCost := 1 }
    bandedSparseAccessPaperCleanInput p 112 = true ∧
      (bandedSparseAccessPaperRegisters p 112).sparseIndexValue = 7 ∧
      bandedSparseAccessPaperSparseIndexInKappa p 112 = false ∧
      bandedSparseAccessPaperGlobalSlotSource p 112 = false ∧
      (oneTermRobinGate_O_D_BS p).unitary.proved = false := by
  native_decide

   
                                        
                                                 
                                                                             
                                     
                                                                   
                    
def robinFunctionValue (n i : Nat) : Coeff :=
  Coeff.symbol s!"f_{n}_{i}"

   
                                                                       

                                                                          
                                                                               
                                                                                
                                                                         
                                        
                                                                           
structure FunctionOraclePaperRegisters where
  systemValue : Nat
  mfWorkspaceValue : Nat
  nonMFValue : Nat
  cleanWorkspace : Bool
deriving Repr, DecidableEq

   
                                                                            
                                          

                                                                                
                                                                             
                   
  
def functionOraclePaperRegisters (p : OneTermRobinParameters) (j : Nat) :
    FunctionOraclePaperRegisters :=
  let n := p.n
  let rp := defaultRobinRegisterPartition p
  let sysMask := (1 <<< n) - 1
  let mfStart := robinIndicatorBitPosition p + 1
  let mfMask := (1 <<< rp.mfQubits) - 1
  let mfValue := (j >>> mfStart) &&& mfMask
  {
    systemValue := (j >>> 1) &&& sysMask
    mfWorkspaceValue := mfValue
    nonMFValue := j - (j &&& (mfMask <<< mfStart))
    cleanWorkspace := mfValue == 0
  }

   
                                                                           

                                                                           
                                                       
  
def functionOracleNormalizedValue (p : OneTermRobinParameters) (i : Nat) : Coeff :=
  Coeff.mul (robinFunctionValue p.n i) (Coeff.symbol "N_f_inv")

   
                                                                        

                                                      
                                                                        
                                                                              
                                                                      
  
structure FunctionOraclePaperImage where
  sourceAnchor : String
  inputRegisters : FunctionOraclePaperRegisters
  cleanBranchBasisIndex : Nat
  cleanBranchSystemValue : Nat
  cleanBranchWorkspaceValue : Nat
  cleanBranchAmplitude : Coeff
  orthogonalComponent : String
  systemPreserved : Bool
  cleanWorkspaceBranch : Bool
  normalizedAmplitudeCorrect : ObligationRecord
  orthogonalComponentCorrect : ObligationRecord
  normalizerBound : ObligationRecord
  unitaryCompletion : ObligationRecord
  diagonalHelperIsolation : ObligationRecord
deriving Repr, DecidableEq

   
                                                                         

                                       
                                                                         
                                 
  
def functionOraclePaperImage (p : OneTermRobinParameters) (j : Nat) :
    FunctionOraclePaperImage :=
  let regs := functionOraclePaperRegisters p j
  {
    sourceAnchor := "Guseynov-Huang-Liu 2025, function oracle O_f, arXiv:2506.20478"
    inputRegisters := regs
    cleanBranchBasisIndex := regs.nonMFValue
    cleanBranchSystemValue := regs.systemValue
    cleanBranchWorkspaceValue := 0
    cleanBranchAmplitude := functionOracleNormalizedValue p regs.systemValue
    orthogonalComponent := s!"orth_f_{p.n}_{regs.systemValue}"
    systemPreserved := regs.systemValue == ((regs.nonMFValue >>> 1) &&& ((1 <<< p.n) - 1))
    cleanWorkspaceBranch := regs.cleanWorkspace
    normalizedAmplitudeCorrect := {
      description := "clean O_f branch amplitude equals f(x_i) / N_f"
      source := "Guseynov-Huang-Liu 2025, function oracle O_f, arXiv:2506.20478"
      proved := false
    }
    orthogonalComponentCorrect := {
      description := "O_f orthogonal component has zero overlap with the clean m_f workspace branch and preserves the system label"
      source := "Guseynov-Huang-Liu 2025, function oracle O_f, arXiv:2506.20478"
      proved := false
    }
    normalizerBound := {
      description := "N_f bounds the coefficient-function amplitudes used by O_f"
      source := "Guseynov-Huang-Liu 2025, function oracle O_f, arXiv:2506.20478"
      proved := false
    }
    unitaryCompletion := {
      description := "O_f paper image extends to a unitary with the recorded orthogonal component"
      source := "Guseynov-Huang-Liu 2025, function oracle O_f, arXiv:2506.20478"
      proved := false
    }
    diagonalHelperIsolation := {
      description := "functionOracleMatrix is helper-only until the paper O_f image is wired to a full matrix"
      source := "QBE-AUTO-002 O_f source-contract audit"
      proved := false
    }
  }

                                                                              
theorem functionOraclePaperImage_inputRegisters_eq
    (p : OneTermRobinParameters) (j : Nat) :
    (functionOraclePaperImage p j).inputRegisters =
      functionOraclePaperRegisters p j := rfl

                                                                                 
theorem functionOraclePaperImage_cleanBranchBasisIndex_eq
    (p : OneTermRobinParameters) (j : Nat) :
    (functionOraclePaperImage p j).cleanBranchBasisIndex =
      (functionOraclePaperRegisters p j).nonMFValue := rfl

                                                                                 
theorem functionOraclePaperImage_cleanBranchSystemValue_eq
    (p : OneTermRobinParameters) (j : Nat) :
    (functionOraclePaperImage p j).cleanBranchSystemValue =
      (functionOraclePaperRegisters p j).systemValue := rfl

                                                                           
theorem functionOraclePaperImage_cleanBranchWorkspaceValue_eq
    (p : OneTermRobinParameters) (j : Nat) :
    (functionOraclePaperImage p j).cleanBranchWorkspaceValue = 0 := rfl

   
                                                                               
                                                   
  
theorem functionOraclePaperImage_cleanBranchAmplitude_eq
    (p : OneTermRobinParameters) (j : Nat) :
    (functionOraclePaperImage p j).cleanBranchAmplitude =
      functionOracleNormalizedValue p (functionOraclePaperRegisters p j).systemValue := rfl

                                                                                     
theorem functionOraclePaperImage_cleanWorkspaceBranch_eq
    (p : OneTermRobinParameters) (j : Nat) :
    (functionOraclePaperImage p j).cleanWorkspaceBranch =
      (functionOraclePaperRegisters p j).cleanWorkspace := rfl

   
                                                                        
        

                                                                        
                                                                              
                                                                     
  
structure FunctionOracleExternalAmplitudeSourceContract where
  sourceAnchor : String
  theoremAnchor : String
  coordinateOracleAnchor : String
  citedSourceAnchor : String
  cleanBranchFormula : String
  normalizerNf : Coeff
  resourceClaim : ObligationRecord
  externalTheoremFormalized : ObligationRecord
  nonzeroNormalizer : ObligationRecord
  divisionSemantics : ObligationRecord
  theoremAmplitudeCorrect : ObligationRecord
  closesNormalizerBound : Bool
  closesOrthogonalCompletion : Bool
  closesUnitaryCompletion : Bool
  closesFunctionOracleContract : Bool
deriving Repr, DecidableEq

   
                                                                   

                                                                          
                                                                          
                                                          
  
def functionOracleExternalAmplitudeSourceContract :
    FunctionOracleExternalAmplitudeSourceContract where
  sourceAnchor :=
    "GHL2025 Theorem 'Amplitude-oracle for piece-wise polynomial function' and Eq. 'coordinate oracle', arXiv:2506.20478; cited source arXiv:2411.01131"
  theoremAnchor :=
    "GHL2025 Theorem 'Amplitude-oracle for piece-wise polynomial function'"
  coordinateOracleAnchor := "GHL2025 Eq. 'coordinate oracle'"
  citedSourceAnchor :=
    "Guseynov-Liu 2024, arXiv:2411.01131, Theorem 5"
  cleanBranchFormula := "f(x_i) / N_f"
  normalizerNf := Coeff.symbol "N_f"
  resourceClaim := {
    description := "transcribe the O_f gate count O(sum_g Q_g n log n) and n - 1 pure ancillas from the cited theorem"
    source := "GHL2025 Theorem amplitude-oracle for piece-wise polynomial function, arXiv:2506.20478; Guseynov-Liu 2024, arXiv:2411.01131"
    proved := false
  }
  externalTheoremFormalized := {
    description := "formalize or contract the cited GL2024 Theorem 5 amplitude-oracle result before using it as a Lean proof"
    source := "Guseynov-Liu 2024, arXiv:2411.01131, Theorem 5"
    proved := false
  }
  nonzeroNormalizer := {
    description := "prove N_f is nonzero before interpreting f(x_i) / N_f"
    source := "Guseynov-Huang-Liu 2025, coordinate-oracle equation, arXiv:2506.20478"
    proved := false
  }
  divisionSemantics := {
    description := "interpret the formal function value times N_f_inv as f(x_i) / N_f"
    source := "Guseynov-Huang-Liu 2025, coordinate-oracle equation, arXiv:2506.20478"
    proved := false
  }
  theoremAmplitudeCorrect := {
    description := "FunctionOracleContract amplitudeCorrect for O_f remains to be proved from the clean branch and orthogonal completion"
    source := "Guseynov-Huang-Liu 2025, amplitude-oracle theorem and coordinate-oracle equation, arXiv:2506.20478"
    proved := false
  }
  closesNormalizerBound := false
  closesOrthogonalCompletion := false
  closesUnitaryCompletion := false
  closesFunctionOracleContract := false

theorem functionOracleExternalAmplitudeSourceContract_sourceAnchor :
    functionOracleExternalAmplitudeSourceContract.sourceAnchor =
      "GHL2025 Theorem 'Amplitude-oracle for piece-wise polynomial function' and Eq. 'coordinate oracle', arXiv:2506.20478; cited source arXiv:2411.01131" := rfl

theorem functionOracleExternalAmplitudeSourceContract_flags_false :
    functionOracleExternalAmplitudeSourceContract.resourceClaim.proved = false ∧
      functionOracleExternalAmplitudeSourceContract.externalTheoremFormalized.proved = false ∧
      functionOracleExternalAmplitudeSourceContract.nonzeroNormalizer.proved = false ∧
      functionOracleExternalAmplitudeSourceContract.divisionSemantics.proved = false ∧
      functionOracleExternalAmplitudeSourceContract.theoremAmplitudeCorrect.proved = false ∧
      functionOracleExternalAmplitudeSourceContract.closesNormalizerBound = false ∧
      functionOracleExternalAmplitudeSourceContract.closesOrthogonalCompletion = false ∧
      functionOracleExternalAmplitudeSourceContract.closesUnitaryCompletion = false ∧
      functionOracleExternalAmplitudeSourceContract.closesFunctionOracleContract = false := by
  exact ⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl⟩

   
                                                          

                                                                         
                                                                               
                                                                               
                                                                          
                                                                     
                                                
  
structure FunctionOracleAmplitudeProofRoute where
  sourceAnchor : String
  systemValue : Nat
  sourceFunctionValue : Coeff
  normalizerNf : Coeff
  normalizedAmplitude : Coeff
  normalizedAmplitudeFormula : String
  cleanBranchAmplitude : Coeff
  cleanBranchBasisIndex : Nat
  cleanWorkspaceBranch : Bool
  theoremNormalizer : Coeff
  normalizedAmplitudeCorrect : ObligationRecord
  nonzeroNormalizer : ObligationRecord
  divisionSemantics : ObligationRecord
  normalizerBound : ObligationRecord
  orthogonalComponentCorrect : ObligationRecord
  unitaryCompletion : ObligationRecord
  theoremAmplitudeCorrect : ObligationRecord
deriving Repr, DecidableEq

   
                                                                   

                                                                              
                                                                             
                                                
  
def functionOracleAmplitudeProofRoute
    (p : OneTermRobinParameters) (j : Nat) :
    FunctionOracleAmplitudeProofRoute :=
  let image := functionOraclePaperImage p j
  let source := functionOracleExternalAmplitudeSourceContract
  {
    sourceAnchor := source.sourceAnchor
    systemValue := image.cleanBranchSystemValue
    sourceFunctionValue := robinFunctionValue p.n image.cleanBranchSystemValue
    normalizerNf := source.normalizerNf
    normalizedAmplitude := functionOracleNormalizedValue p image.cleanBranchSystemValue
    normalizedAmplitudeFormula := source.cleanBranchFormula
    cleanBranchAmplitude := image.cleanBranchAmplitude
    cleanBranchBasisIndex := image.cleanBranchBasisIndex
    cleanWorkspaceBranch := image.cleanWorkspaceBranch
    theoremNormalizer := source.normalizerNf
    normalizedAmplitudeCorrect := image.normalizedAmplitudeCorrect
    nonzeroNormalizer := source.nonzeroNormalizer
    divisionSemantics := source.divisionSemantics
    normalizerBound := image.normalizerBound
    orthogonalComponentCorrect := image.orthogonalComponentCorrect
    unitaryCompletion := image.unitaryCompletion
    theoremAmplitudeCorrect := source.theoremAmplitudeCorrect
  }

theorem functionOracleAmplitudeProofRoute_sourceAnchor
    (p : OneTermRobinParameters) (j : Nat) :
    (functionOracleAmplitudeProofRoute p j).sourceAnchor =
      "GHL2025 Theorem 'Amplitude-oracle for piece-wise polynomial function' and Eq. 'coordinate oracle', arXiv:2506.20478; cited source arXiv:2411.01131" := rfl

theorem functionOracleAmplitudeProofRoute_sourceFunctionValue
    (p : OneTermRobinParameters) (j : Nat) :
    (functionOracleAmplitudeProofRoute p j).sourceFunctionValue =
      robinFunctionValue p.n (functionOraclePaperRegisters p j).systemValue := rfl

theorem functionOracleAmplitudeProofRoute_normalizerNf
    (p : OneTermRobinParameters) (j : Nat) :
    (functionOracleAmplitudeProofRoute p j).normalizerNf =
      Coeff.symbol "N_f" := rfl

theorem functionOracleAmplitudeProofRoute_normalizedAmplitude
    (p : OneTermRobinParameters) (j : Nat) :
    (functionOracleAmplitudeProofRoute p j).normalizedAmplitude =
      functionOracleNormalizedValue p (functionOraclePaperRegisters p j).systemValue := rfl

theorem functionOracleAmplitudeProofRoute_paperImage
    (p : OneTermRobinParameters) (j : Nat) :
    (functionOracleAmplitudeProofRoute p j).cleanBranchAmplitude =
      (functionOraclePaperImage p j).cleanBranchAmplitude ∧
    (functionOracleAmplitudeProofRoute p j).cleanBranchBasisIndex =
      (functionOraclePaperImage p j).cleanBranchBasisIndex ∧
    (functionOracleAmplitudeProofRoute p j).cleanWorkspaceBranch =
      (functionOraclePaperImage p j).cleanWorkspaceBranch := by
  exact ⟨rfl, rfl, rfl⟩

theorem functionOracleAmplitudeProofRoute_obligations_reuse_paperImage
    (p : OneTermRobinParameters) (j : Nat) :
    (functionOracleAmplitudeProofRoute p j).normalizedAmplitudeCorrect =
      (functionOraclePaperImage p j).normalizedAmplitudeCorrect ∧
    (functionOracleAmplitudeProofRoute p j).normalizerBound =
      (functionOraclePaperImage p j).normalizerBound ∧
    (functionOracleAmplitudeProofRoute p j).orthogonalComponentCorrect =
      (functionOraclePaperImage p j).orthogonalComponentCorrect ∧
    (functionOracleAmplitudeProofRoute p j).unitaryCompletion =
      (functionOraclePaperImage p j).unitaryCompletion := by
  exact ⟨rfl, rfl, rfl, rfl⟩

theorem functionOracleAmplitudeProofRoute_externalSourceContract
    (p : OneTermRobinParameters) (j : Nat) :
    (functionOracleAmplitudeProofRoute p j).sourceAnchor =
      functionOracleExternalAmplitudeSourceContract.sourceAnchor ∧
    (functionOracleAmplitudeProofRoute p j).normalizerNf =
      functionOracleExternalAmplitudeSourceContract.normalizerNf ∧
    (functionOracleAmplitudeProofRoute p j).normalizedAmplitudeFormula =
      functionOracleExternalAmplitudeSourceContract.cleanBranchFormula ∧
    (functionOracleAmplitudeProofRoute p j).nonzeroNormalizer =
      functionOracleExternalAmplitudeSourceContract.nonzeroNormalizer ∧
    (functionOracleAmplitudeProofRoute p j).divisionSemantics =
      functionOracleExternalAmplitudeSourceContract.divisionSemantics ∧
    (functionOracleAmplitudeProofRoute p j).theoremAmplitudeCorrect =
      functionOracleExternalAmplitudeSourceContract.theoremAmplitudeCorrect := by
  exact ⟨rfl, rfl, rfl, rfl, rfl, rfl⟩

theorem functionOracleAmplitudeProofRoute_flags_false
    (p : OneTermRobinParameters) (j : Nat) :
    (functionOracleAmplitudeProofRoute p j).normalizedAmplitudeCorrect.proved = false ∧
    (functionOracleAmplitudeProofRoute p j).nonzeroNormalizer.proved = false ∧
    (functionOracleAmplitudeProofRoute p j).divisionSemantics.proved = false ∧
    (functionOracleAmplitudeProofRoute p j).normalizerBound.proved = false ∧
    (functionOracleAmplitudeProofRoute p j).orthogonalComponentCorrect.proved = false ∧
    (functionOracleAmplitudeProofRoute p j).unitaryCompletion.proved = false ∧
    (functionOracleAmplitudeProofRoute p j).theoremAmplitudeCorrect.proved = false := by
  exact ⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl⟩

   
                                                           

                                                                             
                                                                             
                                                       
  
theorem functionOracleAmplitudeProofRoute_externalSourceAndFlags
    (p : OneTermRobinParameters) (j : Nat) :
    ((functionOracleAmplitudeProofRoute p j).sourceAnchor =
        functionOracleExternalAmplitudeSourceContract.sourceAnchor ∧
      (functionOracleAmplitudeProofRoute p j).normalizerNf =
        functionOracleExternalAmplitudeSourceContract.normalizerNf ∧
      (functionOracleAmplitudeProofRoute p j).normalizedAmplitudeFormula =
        functionOracleExternalAmplitudeSourceContract.cleanBranchFormula ∧
      (functionOracleAmplitudeProofRoute p j).nonzeroNormalizer =
        functionOracleExternalAmplitudeSourceContract.nonzeroNormalizer ∧
      (functionOracleAmplitudeProofRoute p j).divisionSemantics =
        functionOracleExternalAmplitudeSourceContract.divisionSemantics ∧
      (functionOracleAmplitudeProofRoute p j).theoremAmplitudeCorrect =
        functionOracleExternalAmplitudeSourceContract.theoremAmplitudeCorrect) ∧
    (functionOracleExternalAmplitudeSourceContract.resourceClaim.proved = false ∧
      functionOracleExternalAmplitudeSourceContract.externalTheoremFormalized.proved = false ∧
      functionOracleExternalAmplitudeSourceContract.nonzeroNormalizer.proved = false ∧
      functionOracleExternalAmplitudeSourceContract.divisionSemantics.proved = false ∧
      functionOracleExternalAmplitudeSourceContract.theoremAmplitudeCorrect.proved = false ∧
      functionOracleExternalAmplitudeSourceContract.closesNormalizerBound = false ∧
      functionOracleExternalAmplitudeSourceContract.closesOrthogonalCompletion = false ∧
      functionOracleExternalAmplitudeSourceContract.closesUnitaryCompletion = false ∧
      functionOracleExternalAmplitudeSourceContract.closesFunctionOracleContract = false) ∧
    (functionOracleAmplitudeProofRoute p j).normalizedAmplitudeCorrect.proved = false ∧
    (functionOracleAmplitudeProofRoute p j).nonzeroNormalizer.proved = false ∧
    (functionOracleAmplitudeProofRoute p j).divisionSemantics.proved = false ∧
    (functionOracleAmplitudeProofRoute p j).normalizerBound.proved = false ∧
    (functionOracleAmplitudeProofRoute p j).orthogonalComponentCorrect.proved = false ∧
    (functionOracleAmplitudeProofRoute p j).unitaryCompletion.proved = false ∧
    (functionOracleAmplitudeProofRoute p j).theoremAmplitudeCorrect.proved = false := by
  exact ⟨
    functionOracleAmplitudeProofRoute_externalSourceContract p j,
    functionOracleExternalAmplitudeSourceContract_flags_false,
    functionOracleAmplitudeProofRoute_flags_false p j⟩

   
                                                                       

                                                     
                                                                              
                                                                                
                                                       
  
def functionOracleOrthogonalEntry
    (p : OneTermRobinParameters) (systemValue row col : Nat) : Coeff :=
  Coeff.symbol s!"orth_f_entry_{p.n}_{systemValue}_{row}_{col}"

   
                                                                           

                                                                          
                                                                   
                                                                     
                                                                           
                                                                 
                                                                          
                                                                                
                     

                                                                              
                                                              
                                               
  
def functionOraclePaperMatrix (p : OneTermRobinParameters) :
    Matrix (qubitDim (oneTermRobinTotalQubits p)) (qubitDim (oneTermRobinTotalQubits p)) Coeff :=
  fun i j =>
    let image := functionOraclePaperImage p j.val
    if image.cleanWorkspaceBranch then
      if i.val = image.cleanBranchBasisIndex then
        image.cleanBranchAmplitude
      else if (functionOraclePaperRegisters p i.val).mfWorkspaceValue = 0 then
        Coeff.rat 0
      else
        functionOracleOrthogonalEntry p image.cleanBranchSystemValue i.val j.val
    else
      functionOracleOrthogonalEntry p image.cleanBranchSystemValue i.val j.val

                                                                                         
theorem functionOraclePaperMatrix_cleanBranch_entry
    (p : OneTermRobinParameters)
    (i j : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hClean : (functionOraclePaperImage p j.val).cleanWorkspaceBranch = true)
    (h : i.val = (functionOraclePaperImage p j.val).cleanBranchBasisIndex) :
    functionOraclePaperMatrix p i j =
      (functionOraclePaperImage p j.val).cleanBranchAmplitude := by
  simp [functionOraclePaperMatrix, hClean, h]

                                                                              
theorem functionOraclePaperMatrix_cleanWorkspace_offBranch_zero
    (p : OneTermRobinParameters)
    (i j : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hInputClean : (functionOraclePaperImage p j.val).cleanWorkspaceBranch = true)
    (hBranch : i.val ≠ (functionOraclePaperImage p j.val).cleanBranchBasisIndex)
    (hClean : (functionOraclePaperRegisters p i.val).mfWorkspaceValue = 0) :
    functionOraclePaperMatrix p i j = Coeff.rat 0 := by
  simp [functionOraclePaperMatrix, hInputClean, hBranch, hClean]

                                                                                
theorem functionOraclePaperMatrix_nonCleanInput_entry
    (p : OneTermRobinParameters)
    (i j : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hInputNonClean : (functionOraclePaperImage p j.val).cleanWorkspaceBranch = false) :
    functionOraclePaperMatrix p i j =
      functionOracleOrthogonalEntry p
        (functionOraclePaperImage p j.val).cleanBranchSystemValue i.val j.val := by
  simp [functionOraclePaperMatrix, hInputNonClean]

   
                                                                                

                                                                       
                                                                               
                                                                        
                                                     

                                                                             
                                                                     
                                                            
                                                                    
                                                                             
                                                                                

                    
def functionOracleMatrix (p : OneTermRobinParameters) :
    Matrix (qubitDim (oneTermRobinTotalQubits p)) (qubitDim (oneTermRobinTotalQubits p)) Coeff :=
  fun i j =>
    if i.val = j.val then
      let n := p.n
      let sysMask := (1 <<< n) - 1
      let sysVal := (j.val >>> 1) &&& sysMask
      robinFunctionValue n sysVal
    else Coeff.rat 0

   
                                                                     

                                                                   
                                                                              
                                                                            
                                                                               
                                                                           
                                                    
def oneTermRobinGate_O_f (p : OneTermRobinParameters) : GateMatrix Coeff (oneTermRobinTotalQubits p) where
  gate := Gate.oracleCall "O_f"
  matrix := functionOraclePaperMatrix p
  unitary := {
    description := "O_f paper-image matrix skeleton: clean branch wired, orthogonal completion and unitarity not yet proved"
    source := "Guseynov-Huang-Liu 2025, Theorem amplitude-oracle for piece-wise polynomial function and Fig. 1-term Robin, arXiv:2506.20478"
    proved := false
  }

   
                                                                   
                                                                                    

                         
                                                                
                                                                  
                            
                                                           

                                                                        
                                                                          

                                                                         
                                                                             
                                                
                                        
def swapOracleMatrix (p : OneTermRobinParameters) :
    Matrix (qubitDim (oneTermRobinTotalQubits p)) (qubitDim (oneTermRobinTotalQubits p)) Coeff :=
  fun i j =>
    let n := p.n
    let blockMask := (1 <<< n) - 1
    let block1 := (j.val >>> 1) &&& blockMask
    let block2 := (j.val >>> (1 + n)) &&& blockMask
    let diff := block1 ^^^ block2
    let swapped := j.val ^^^ (diff <<< 1) ^^^ (diff <<< (1 + n))
    if i.val = swapped then Coeff.rat 1 else Coeff.rat 0

   
                                                                      
                                                                                 
                                                                   
                 
def swapOracleImage (p : OneTermRobinParameters) (j : Nat) : Nat :=
  let n := p.n
  let blockMask := (1 <<< n) - 1
  let block1 := (j >>> 1) &&& blockMask
  let block2 := (j >>> (1 + n)) &&& blockMask
  let diff := block1 ^^^ block2
  j ^^^ (diff <<< 1) ^^^ (diff <<< (1 + n))

   
                                                                           

                                                                               
                                                                               
                                 
  
def swapOracleDiff (p : OneTermRobinParameters) (j : Nat) : Nat :=
  let n := p.n
  let blockMask := (1 <<< n) - 1
  let block1 := (j >>> 1) &&& blockMask
  let block2 := (j >>> (1 + n)) &&& blockMask
  block1 ^^^ block2

                                                                                      
theorem swapOracleImage_eq_xor_diff (p : OneTermRobinParameters) (j : Nat) :
    swapOracleImage p j =
      j ^^^ (swapOracleDiff p j <<< 1) ^^^
        (swapOracleDiff p j <<< (1 + p.n)) := by
  rfl

                                                          
theorem swapOracleMatrix_eq_image (p : OneTermRobinParameters)
    (i j : Fin (qubitDim (oneTermRobinTotalQubits p))) :
    swapOracleMatrix p i j =
      if i.val = swapOracleImage p j.val then Coeff.rat 1 else Coeff.rat 0 := by
  simp [swapOracleMatrix, swapOracleImage] <;> rfl

   
                                                         
                                                                            
                                                              
                                  
                 
def oneTermRobinGate_SWAP (p : OneTermRobinParameters) : GateMatrix Coeff (oneTermRobinTotalQubits p) where
  gate := Gate.swap 0 0
  matrix := swapOracleMatrix p
  unitary := {
    description := "SWAP permutation matrix: unitarity backed by swapOracleMatrix_is_permutation"
    source := "Guseynov-Huang-Liu 2025, Fig. 1-term Robin SWAP operation, arXiv:2506.20478"
    proved := true
  }

   
                                                                               
                                                                                   
                                                                                
                                                                              
                 
def bandedSparseAccessDaggerMatrix (p : OneTermRobinParameters) :
    Matrix (qubitDim (oneTermRobinTotalQubits p)) (qubitDim (oneTermRobinTotalQubits p)) Coeff :=
  fun i j =>
    let n := p.n
    let kappa := p.kappa
    let κbits := clog2 kappa
    let odPure := n - κbits
    let sysMask := (1 <<< n) - 1
    let sysVal := (i.val >>> 1) &&& sysMask
    let sparseStart := 1 + n + odPure
    let sparseMask := (1 <<< κbits) - 1
    let sparseVal := (i.val >>> sparseStart) &&& sparseMask
    let col := robinSparseColumnMap n sparseVal sysVal
    let image := i.val - (i.val &&& (sysMask <<< 1)) + (col <<< 1)
    if j.val = image then Coeff.rat 1 else Coeff.rat 0

   
                                                                          

                                                                               
                                                             
                                                     
def oneTermRobinGate_O_D_BS_dagger (p : OneTermRobinParameters) : GateMatrix Coeff (oneTermRobinTotalQubits p) where
  gate := Gate.oracleCall "(O_D^BS)^†"
  matrix := bandedSparseAccessPaperDaggerMatrix p
  unitary := {
    description := "(O_D^BS)^† paper-image transpose matrix: cleanup and unitarity not yet proved"
    source := "Guseynov-Huang-Liu 2025, Fig. 1-term Robin and Lemma 1, arXiv:2506.20478"
    proved := false
  }

                                                                           
theorem oneTermRobinGate_O_D_BS_dagger_imageFin_eq_one
    (p : OneTermRobinParameters)
    (j : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (haddr : bandedSparseAccessPaperAddress p j.val < (1 <<< p.n)) :
    (oneTermRobinGate_O_D_BS_dagger p).matrix j
        (bandedSparseAccessPaperImageFin p j haddr) =
      Coeff.rat 1 := by
  simpa [oneTermRobinGate_O_D_BS_dagger]
    using bandedSparseAccessPaperDaggerMatrix_imageFin_eq_one p j haddr

   
                                                                        

                                                                         
                                                                          
                                                                          
                                                                             
                                                            
  
theorem oneTermRobinGate_O_D_BS_dagger_postSwap_entry_of_preimage
    (p : OneTermRobinParameters)
    (source post pre : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hpost : post.val =
      swapOracleImage p
        (bandedSparseAccessPaperImage p source.val))
    (hpre : post.val = bandedSparseAccessPaperImage p pre.val) :
    (oneTermRobinGate_O_D_BS_dagger p).matrix pre post = Coeff.rat 1 := by
  have _postSwapWitness :
      post.val = swapOracleImage p (bandedSparseAccessPaperImage p source.val) := hpost
  simp [oneTermRobinGate_O_D_BS_dagger, bandedSparseAccessPaperDaggerMatrix, hpre]

   
                                                                   

                                                                         
                                                                                
                                                                             
                                                                            
                                                       
  
structure BandedSparseAccessPostSwapCleanup
    (p : OneTermRobinParameters)
    (source post pre : Fin (qubitDim (oneTermRobinTotalQubits p))) where
  postSwap :
    post.val = swapOracleImage p (bandedSparseAccessPaperImage p source.val)
  preimage : post.val = bandedSparseAccessPaperImage p pre.val
  preCleanInput : bandedSparseAccessPaperCleanInput p pre.val = true
  preAddressBound : bandedSparseAccessPaperAddress p pre.val < (1 <<< p.n)
  daggerEntry : (oneTermRobinGate_O_D_BS_dagger p).matrix pre post = Coeff.rat 1
  preRowPreserved :
    (bandedSparseAccessPaperColumnContract p pre.val).rowPreserved = true
  preAddressWritten :
    (bandedSparseAccessPaperColumnContract p pre.val).addressWritten = true
  preAddressInRange :
    (bandedSparseAccessPaperColumnContract p pre.val).addressInRange = true
  preImageNoSpill :
    (bandedSparseAccessPaperColumnContract p pre.val).imageNoSpill = true
  postRow_eq_preRow :
    (bandedSparseAccessPaperRegisters p post.val).rowValue =
      (bandedSparseAccessPaperRegisters p pre.val).rowValue
  postOd_eq_preAddress :
    (bandedSparseAccessPaperRegisters p post.val).odRegisterValue =
      bandedSparseAccessPaperAddress p pre.val

   
                                                                         

                                                                           
                                                                             
  
def bandedSparseAccessPostSwapCleanup_of_preimage
    (p : OneTermRobinParameters)
    (source post pre : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hpost : post.val =
      swapOracleImage p
        (bandedSparseAccessPaperImage p source.val))
    (hpre : post.val = bandedSparseAccessPaperImage p pre.val)
    (hclean : bandedSparseAccessPaperCleanInput p pre.val = true)
    (haddr : bandedSparseAccessPaperAddress p pre.val < (1 <<< p.n)) :
    BandedSparseAccessPostSwapCleanup p source post pre := by
  let hsafety :=
    bandedSparseAccessPaperColumnContract_registerSafety_of_address_lt
      p pre.val haddr
  exact {
    postSwap := hpost
    preimage := hpre
    preCleanInput := hclean
    preAddressBound := haddr
    daggerEntry :=
      oneTermRobinGate_O_D_BS_dagger_postSwap_entry_of_preimage
        p source post pre hpost hpre
    preRowPreserved := hsafety.1
    preAddressWritten := hsafety.2.1
    preAddressInRange := hsafety.2.2.1
    preImageNoSpill := hsafety.2.2.2
    postRow_eq_preRow := by
      rw [hpre]
      exact bandedSparseAccessPaperImage_rowValue_eq p pre.val
    postOd_eq_preAddress := by
      rw [hpre]
      exact bandedSparseAccessPaperImage_odRegisterValue_eq p pre.val haddr
  }

   
                                                                 

                                                                             
                                                                        
                                                                              
                
  
theorem oneTermRobinGate_O_D_BS_imageFin_entrySafety
    (p : OneTermRobinParameters)
    (j : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (haddr : bandedSparseAccessPaperAddress p j.val < (1 <<< p.n)) :
    (oneTermRobinGate_O_D_BS p).matrix
        (bandedSparseAccessPaperImageFin p j haddr) j = Coeff.rat 1 ∧
      (oneTermRobinGate_O_D_BS_dagger p).matrix j
        (bandedSparseAccessPaperImageFin p j haddr) = Coeff.rat 1 ∧
      (bandedSparseAccessPaperRegisters p
        (bandedSparseAccessPaperImage p j.val)).rowValue =
          (bandedSparseAccessPaperRegisters p j.val).rowValue ∧
      (bandedSparseAccessPaperRegisters p
        (bandedSparseAccessPaperImage p j.val)).odRegisterValue =
          bandedSparseAccessPaperAddress p j.val ∧
      bandedSparseAccessPaperImageNoSpill p j.val = true := by
  constructor
  · exact oneTermRobinGate_O_D_BS_imageFin_eq_one p j haddr
  constructor
  · exact oneTermRobinGate_O_D_BS_dagger_imageFin_eq_one p j haddr
  constructor
  · exact bandedSparseAccessPaperImage_rowValue_eq p j.val
  constructor
  · exact bandedSparseAccessPaperImage_odRegisterValue_eq p j.val haddr
  · exact bandedSparseAccessPaperImageNoSpill_eq_true_of_address_lt p j.val haddr

   
                                                                          

                                                                         
                                                                          
                                                                           
                                                                             
                                                  
  
theorem oneTermRobinGate_O_D_BS_globalSlotSource_entrySafety
    (p : OneTermRobinParameters)
    (j : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hn : 2 ≤ p.n)
    (hsource : bandedSparseAccessPaperGlobalSlotSource p j.val = true) :
    bandedSparseAccessPaperCleanInput p j.val = true ∧
      (bandedSparseAccessPaperRegisters p j.val).sparseIndexValue < p.kappa ∧
      ∃ image : Fin (qubitDim (oneTermRobinTotalQubits p)),
        image.val = bandedSparseAccessPaperImage p j.val ∧
          (oneTermRobinGate_O_D_BS p).matrix image j = Coeff.rat 1 ∧
          (oneTermRobinGate_O_D_BS_dagger p).matrix j image = Coeff.rat 1 ∧
          (bandedSparseAccessPaperRegisters p
            (bandedSparseAccessPaperImage p j.val)).rowValue =
              (bandedSparseAccessPaperRegisters p j.val).rowValue ∧
          (bandedSparseAccessPaperRegisters p
            (bandedSparseAccessPaperImage p j.val)).odRegisterValue =
              bandedSparseAccessPaperAddress p j.val ∧
          bandedSparseAccessPaperImageNoSpill p j.val = true ∧
          (oneTermRobinGate_O_D_BS p).unitary.proved = false ∧
          (oneTermRobinGate_O_D_BS_dagger p).unitary.proved = false := by
  have hclean :=
    bandedSparseAccessPaperGlobalSlotSource_cleanInput_eq_true
      p j.val hsource
  have hsparse :=
    bandedSparseAccessPaperGlobalSlotSource_sparseIndex_lt_kappa
      p j.val hsource
  have haddrGrid :=
    bandedSparseAccessPaperAddress_lt_gridSize_of_two_le p j.val hn
  have haddr : bandedSparseAccessPaperAddress p j.val < (1 <<< p.n) := by
    simpa [gridSize, Nat.one_shiftLeft] using haddrGrid
  let image := bandedSparseAccessPaperImageFin p j haddr
  have hsafety := oneTermRobinGate_O_D_BS_imageFin_entrySafety p j haddr
  refine ⟨hclean, hsparse, image, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · exact bandedSparseAccessPaperImageFin_val p j haddr
  · exact hsafety.1
  · exact hsafety.2.1
  · exact hsafety.2.2.1
  · exact hsafety.2.2.2.1
  · exact hsafety.2.2.2.2
  · rfl
  · rfl

   
                                                                      
                                           
                       
def oneTermRobinGateMatrixPlaceholders (p : OneTermRobinParameters) :
    List (GateMatrix Coeff (oneTermRobinTotalQubits p)) :=
  [ oneTermRobinGate_U_indic p
  , oneTermRobinGate_O_DT_S p
  , oneTermRobinGate_Ry_boundary p
  , oneTermRobinGate_O_D_BS p
  , oneTermRobinGate_O_f p
  , oneTermRobinGate_SWAP p
  , oneTermRobinGate_O_D_BS_dagger p
  ]

   
                                                            
                                                                
                                
                       
theorem oneTermRobinPlaceholdersMatch (p : OneTermRobinParameters) :
    gateMatricesMatchCircuit oneTermRobinCircuit (oneTermRobinGateMatrixPlaceholders p) = true := by
  simp [oneTermRobinCircuit, oneTermRobinGateMatrixPlaceholders,
    oneTermRobinGate_U_indic, oneTermRobinGate_O_DT_S,
    oneTermRobinGate_Ry_boundary, oneTermRobinGate_O_D_BS,
    oneTermRobinGate_O_f, oneTermRobinGate_SWAP,
    oneTermRobinGate_O_D_BS_dagger,
    gateMatricesMatchCircuit]

   
                                                                          
                                

                                                                              
                                                             
  
theorem oneTermRobinGateMatrixPlaceholders_gateList
    (p : OneTermRobinParameters) :
    (oneTermRobinGateMatrixPlaceholders p).map
        (fun gateMatrix => gateMatrix.gate) =
      oneTermRobinCircuit := by
  simp [oneTermRobinCircuit, oneTermRobinGateMatrixPlaceholders,
    oneTermRobinGate_U_indic, oneTermRobinGate_O_DT_S,
    oneTermRobinGate_Ry_boundary, oneTermRobinGate_O_D_BS,
    oneTermRobinGate_O_f, oneTermRobinGate_SWAP,
    oneTermRobinGate_O_D_BS_dagger]

   
                                                                            
                                

                                                                      
                                                                         
                                                               
  
theorem oneTermRobinGateMatrixPlaceholders_unitaryFlags
    (p : OneTermRobinParameters) :
    (oneTermRobinGateMatrixPlaceholders p).map
        (fun gateMatrix => gateMatrix.unitary.proved) =
      [true, false, false, false, false, true, false] := by
  simp [oneTermRobinGateMatrixPlaceholders,
    oneTermRobinGate_U_indic, oneTermRobinGate_O_DT_S,
    oneTermRobinGate_Ry_boundary, oneTermRobinGate_O_D_BS,
    oneTermRobinGate_O_f, oneTermRobinGate_SWAP,
    oneTermRobinGate_O_D_BS_dagger]

   
                                                                           
                                                                             
                                                                   
                      
def indicatorOracleImage (p : OneTermRobinParameters) (j : Nat) : Nat :=
  let n := p.n
  let indPos := robinIndicatorBitPosition p
  let systemVal := (j >>> 1) &&& ((1 <<< n) - 1)
  let K1 := 2
  let K2 := gridSize n - 3
  let isBulk := if K1 ≤ systemVal ∧ systemVal ≤ K2 then (1 : Nat) else 0
  j ^^^ (isBulk <<< indPos)

   
                                                                               
                      
theorem indicatorOracleMatrix_eq_image (p : OneTermRobinParameters)
    (i j : Fin (qubitDim (oneTermRobinTotalQubits p))) :
    indicatorOracleMatrix p i j =
      if i.val = indicatorOracleImage p j.val then Coeff.rat 1 else Coeff.rat 0 := by
  simp [indicatorOracleMatrix, indicatorOracleImage] <;> rfl

   
                                                                              
                                                      
                                                  
                      
theorem indicatorOracleImage_self_inverse_n1 :
    ∀ j : Fin (qubitDim (oneTermRobinTotalQubits
      { n := 1, kappa := 1, functionPieces := 1, polynomialDegreeCost := 1 })),
      indicatorOracleImage
        { n := 1, kappa := 1, functionPieces := 1, polynomialDegreeCost := 1 }
        (indicatorOracleImage
          { n := 1, kappa := 1, functionPieces := 1, polynomialDegreeCost := 1 } j) = j := by
  native_decide

   
                                                                              
                                                       
                                                  
                      
theorem indicatorOracleImage_self_inverse_n3 :
    ∀ j : Fin (qubitDim (oneTermRobinTotalQubits
      { n := 3, kappa := 7, functionPieces := 1, polynomialDegreeCost := 1 })),
      indicatorOracleImage
        { n := 3, kappa := 7, functionPieces := 1, polynomialDegreeCost := 1 }
        (indicatorOracleImage
          { n := 3, kappa := 7, functionPieces := 1, polynomialDegreeCost := 1 } j) = j := by
  native_decide

   
                                                        
                      
theorem indicatorOracleImage_injective_n1 {j₁ j₂ : Fin (qubitDim (oneTermRobinTotalQubits
      { n := 1, kappa := 1, functionPieces := 1, polynomialDegreeCost := 1 }))}
    (h : indicatorOracleImage
        { n := 1, kappa := 1, functionPieces := 1, polynomialDegreeCost := 1 } j₁ =
      indicatorOracleImage
        { n := 1, kappa := 1, functionPieces := 1, polynomialDegreeCost := 1 } j₂) :
    j₁ = j₂ := by
  have h1 := indicatorOracleImage_self_inverse_n1 j₁
  have h2 := indicatorOracleImage_self_inverse_n1 j₂
  apply Fin.ext
  show (j₁ : Nat) = j₂
  rw [← h1, ← h2, h]

   
                                                        
                      
theorem indicatorOracleImage_injective_n3 {j₁ j₂ : Fin (qubitDim (oneTermRobinTotalQubits
      { n := 3, kappa := 7, functionPieces := 1, polynomialDegreeCost := 1 }))}
    (h : indicatorOracleImage
        { n := 3, kappa := 7, functionPieces := 1, polynomialDegreeCost := 1 } j₁ =
      indicatorOracleImage
        { n := 3, kappa := 7, functionPieces := 1, polynomialDegreeCost := 1 } j₂) :
    j₁ = j₂ := by
  have h1 := indicatorOracleImage_self_inverse_n3 j₁
  have h2 := indicatorOracleImage_self_inverse_n3 j₂
  apply Fin.ext
  show (j₁ : Nat) = j₂
  rw [← h1, ← h2, h]

   
                                                                   
                                                           
  
theorem shiftLeft_land_mask_eq_zero (b pos n : Nat) (h : pos ≥ n) :
    (b <<< pos) &&& ((1 <<< n) - 1) = 0 := by
  have key : ∀ i, i < n → (b <<< pos).testBit i = false := by
    intro i hi; simp [Nat.testBit_shiftLeft]; omega
  have all_false : ∀ i, (b <<< pos &&& (1 <<< n - 1)).testBit i = (0 : Nat).testBit i := by
    intro i; simp only [Nat.testBit_and]
    by_cases h1 : i < n
    · rw [key i h1]; simp
    · have : (1 <<< n - 1).testBit i = false := by
        rw [Nat.one_shiftLeft, Nat.testBit_two_pow_sub_one]; simp [h1]
      simp [this]
  exact Nat.eq_of_testBit_eq all_false

   
                                                                                  
                                                                      
  
theorem xor_shift_preserve_low (x b pos n : Nat) (h : pos ≥ n) :
    (x ^^^ (b <<< pos)) &&& ((1 <<< n) - 1) = x &&& ((1 <<< n) - 1) := by
  rw [Nat.and_xor_distrib_right]
  have := shiftLeft_land_mask_eq_zero b pos n h
  rw [this, Nat.xor_zero]

   
                                                                                       
                                                                               
                  
  
theorem xor_shift_preserve_shift_low (x b pos n : Nat) (h : pos ≥ 1 + n) :
    ((x ^^^ (b <<< pos)) >>> 1) &&& ((1 <<< n) - 1) =
    (x >>> 1) &&& ((1 <<< n) - 1) := by
  have key : ∀ i, i < n →
      ((x ^^^ (b <<< pos)) >>> 1).testBit i = (x >>> 1).testBit i := by
    intro i hi
    simp only [Nat.testBit_shiftRight, Nat.testBit_xor]
    have : (b <<< pos).testBit (1 + i) = false := by
      simp [Nat.testBit_shiftLeft]; omega
    simp [this]
  have eq_bits : ∀ i,
      ((x ^^^ (b <<< pos)) >>> 1 &&& (1 <<< n - 1)).testBit i =
      ((x >>> 1) &&& (1 <<< n - 1)).testBit i := by
    intro i; simp only [Nat.testBit_and]
    by_cases h1 : i < n
    · simp [key i h1]
    · have : (1 <<< n - 1).testBit i = false := by
        rw [Nat.one_shiftLeft, Nat.testBit_two_pow_sub_one]; simp [h1]
      simp [this]
  exact Nat.eq_of_testBit_eq eq_bits

   
                                                                         
                      
                 
theorem swapOracleDiff_lt_two_pow (p : OneTermRobinParameters) (j : Nat) :
    let n := p.n
    let blockMask := (1 <<< n) - 1
    let block1 := (j >>> 1) &&& blockMask
    let block2 := (j >>> (1 + n)) &&& blockMask
    block1 ^^^ block2 < 2 ^ n := by
  dsimp
  apply Nat.xor_lt_two_pow
  · apply Nat.and_lt_two_pow
    rw [Nat.one_shiftLeft]
    exact Nat.sub_lt (Nat.pow_pos (by decide : 0 < 2) : 0 < 2 ^ p.n) (by decide)
  · apply Nat.and_lt_two_pow
    rw [Nat.one_shiftLeft]
    exact Nat.sub_lt (Nat.pow_pos (by decide : 0 < 2) : 0 < 2 ^ p.n) (by decide)

   
                                                                                 
                 
theorem swapOracleDiff_shiftRight_eq_zero (p : OneTermRobinParameters) (j : Nat) :
    let n := p.n
    let blockMask := (1 <<< n) - 1
    let block1 := (j >>> 1) &&& blockMask
    let block2 := (j >>> (1 + n)) &&& blockMask
    let diff := block1 ^^^ block2
    diff >>> n = 0 := by
  have hdiff := swapOracleDiff_lt_two_pow p j
  dsimp at hdiff ⊢
  exact Nat.shiftRight_eq_zero _ _ hdiff

   
                                                                               
                           
                 
theorem swapOracleDiff_shiftLeft_mask_eq_zero (p : OneTermRobinParameters) (j : Nat) :
    let n := p.n
    let blockMask := (1 <<< n) - 1
    let block1 := (j >>> 1) &&& blockMask
    let block2 := (j >>> (1 + n)) &&& blockMask
    let diff := block1 ^^^ block2
    (diff <<< n) &&& blockMask = 0 := by
  dsimp
  exact shiftLeft_land_mask_eq_zero
    (((j >>> 1) &&& (1 <<< p.n) - 1) ^^^ ((j >>> (1 + p.n)) &&& (1 <<< p.n) - 1))
    p.n p.n (by omega)

                                                                                            
theorem shiftLeft_lt_two_pow_of_lt
    {x width shift total : Nat}
    (hx : x < 2 ^ width) (hblock : width + shift ≤ total) :
    x <<< shift < 2 ^ total := by
  rw [Nat.shiftLeft_eq]
  have hmul : x * 2 ^ shift < 2 ^ width * 2 ^ shift :=
    Nat.mul_lt_mul_of_pos_right hx (Nat.pow_pos (by decide : 0 < 2))
  have hpow : 2 ^ width * 2 ^ shift = 2 ^ (width + shift) := by
    rw [← Nat.pow_add]
  have hle : 2 ^ (width + shift) ≤ 2 ^ total :=
    Nat.pow_le_pow_right (by decide : 0 < 2) hblock
  exact Nat.lt_of_lt_of_le (by simpa [hpow] using hmul) hle

   
                                                                             
                                                                   
                                                                             
  
theorem swapOracleImage_lt_qubitDim
    (p : OneTermRobinParameters) {j : Nat}
    (hj : j < qubitDim (oneTermRobinTotalQubits p)) :
    swapOracleImage p j < qubitDim (oneTermRobinTotalQubits p) := by
  simp only [qubitDim, gridSize] at hj ⊢
  unfold swapOracleImage
  let n := p.n
  let blockMask := (1 <<< n) - 1
  let block1 := (j >>> 1) &&& blockMask
  let block2 := (j >>> (1 + n)) &&& blockMask
  let diff := block1 ^^^ block2
  have hdiff : diff < 2 ^ p.n := by
    have h := swapOracleDiff_lt_two_pow p j
    simpa [n, blockMask, block1, block2, diff] using h
  have hshiftLow : diff <<< 1 < 2 ^ oneTermRobinTotalQubits p :=
    shiftLeft_lt_two_pow_of_lt hdiff (by
      have hhigh := bandedSparseAccessPaperHighWidth_le_totalQubits p
      omega)
  have hxorLow : j ^^^ (diff <<< 1) < 2 ^ oneTermRobinTotalQubits p :=
    Nat.xor_lt_two_pow hj hshiftLow
  have hshiftHigh : diff <<< (1 + n) < 2 ^ oneTermRobinTotalQubits p :=
    shiftLeft_lt_two_pow_of_lt hdiff (by
      have hhigh := bandedSparseAccessPaperHighWidth_le_totalQubits p
      omega)
  exact Nat.xor_lt_two_pow hxorLow hshiftHigh

   
                                                                            
                                                                              
                                                            
                 
theorem swapOracleImage_block1_eq_block2 (p : OneTermRobinParameters) (j : Nat) :
    let n := p.n
    let blockMask := (1 <<< n) - 1
    ((swapOracleImage p j) >>> 1) &&& blockMask =
      (j >>> (1 + n)) &&& blockMask := by
  dsimp [swapOracleImage]
  apply Nat.eq_of_testBit_eq
  intro i
  simp only [Nat.testBit_and]
  by_cases hi : i < p.n
  · have hmask : ((1 <<< p.n) - 1).testBit i = true := by
      rw [Nat.one_shiftLeft, Nat.testBit_two_pow_sub_one]
      simp [hi]
    have hnle : ¬p.n ≤ i := Nat.not_le_of_gt hi
    simp only [Nat.testBit_shiftRight, Nat.testBit_xor, Nat.testBit_shiftLeft,
      Nat.testBit_and]
    simp [hmask, hnle, Nat.add_comm, Nat.add_left_comm]
  · have hmask : ((1 <<< p.n) - 1).testBit i = false := by
      rw [Nat.one_shiftLeft, Nat.testBit_two_pow_sub_one]
      simp [hi]
    simp [hmask]

   
                                                                             
                                                                           
                                                                            
                           
                 
theorem swapOracleImage_block2_eq_block1 (p : OneTermRobinParameters) (j : Nat) :
    let n := p.n
    let blockMask := (1 <<< n) - 1
    ((swapOracleImage p j) >>> (1 + n)) &&& blockMask =
      (j >>> 1) &&& blockMask := by
  dsimp [swapOracleImage]
  apply Nat.eq_of_testBit_eq
  intro i
  simp only [Nat.testBit_and]
  by_cases hi : i < p.n
  · have hmask : ((1 <<< p.n) - 1).testBit i = true := by
      rw [Nat.one_shiftLeft, Nat.testBit_two_pow_sub_one]
      simp [hi]
    have hmaskHigh : ((1 <<< p.n) - 1).testBit (i + p.n) = false := by
      rw [Nat.one_shiftLeft, Nat.testBit_two_pow_sub_one]
      have hle : p.n ≤ i + p.n := by omega
      simp [Nat.not_lt.mpr hle]
    have hshift : 1 ≤ i + (p.n + 1) := by omega
    simp only [Nat.testBit_shiftRight, Nat.testBit_xor, Nat.testBit_shiftLeft,
      Nat.testBit_and]
    simp [hmask, hmaskHigh, hshift, Nat.add_comm, Nat.add_left_comm, Nat.add_assoc]
    by_cases hlow : j.testBit (i + 1)
    · by_cases hhigh : j.testBit (i + (p.n + 1)) <;> simp [hlow, hhigh]
    · by_cases hhigh : j.testBit (i + (p.n + 1)) <;> simp [hlow, hhigh]
  · have hmask : ((1 <<< p.n) - 1).testBit i = false := by
      rw [Nat.one_shiftLeft, Nat.testBit_two_pow_sub_one]
      simp [hi]
    simp [hmask]

   
                                                                               
                                                                         
                                                        
  
theorem swapOracleDiff_preserved (p : OneTermRobinParameters) (j : Nat) :
    swapOracleDiff p (swapOracleImage p j) = swapOracleDiff p j := by
  unfold swapOracleDiff
  dsimp
  rw [swapOracleImage_block1_eq_block2 p j,
    swapOracleImage_block2_eq_block1 p j]
  exact Nat.xor_comm _ _

                                                                    
theorem xor_two_shifted_masks_cancel (j diff n : Nat) :
    (j ^^^ (diff <<< 1) ^^^ (diff <<< (1 + n))) ^^^
        (diff <<< 1) ^^^ (diff <<< (1 + n)) = j := by
  apply Nat.eq_of_testBit_eq
  intro i
  simp only [Nat.testBit_xor]
  cases hj : j.testBit i <;>
    cases hlow : (diff <<< 1).testBit i <;>
    cases hhigh : (diff <<< (1 + n)).testBit i <;>
    rfl

   
                                                         

                                                                         
       
  
theorem swapOracleImage_self_inverse (p : OneTermRobinParameters) (j : Nat) :
    swapOracleImage p (swapOracleImage p j) = j := by
  rw [swapOracleImage_eq_xor_diff p (swapOracleImage p j)]
  rw [swapOracleDiff_preserved p j]
  rw [swapOracleImage_eq_xor_diff p j]
  exact xor_two_shifted_masks_cancel j (swapOracleDiff p j) p.n

   
                                                                         
                                                                        
  
theorem swapOracleImage_injective (p : OneTermRobinParameters) {j₁ j₂ : Nat}
    (h : swapOracleImage p j₁ = swapOracleImage p j₂) :
    j₁ = j₂ := by
  have h1 := swapOracleImage_self_inverse p j₁
  have h2 := swapOracleImage_self_inverse p j₂
  rw [← h1, ← h2, h]

   
                                                                         
                    

                                                                               
                                                                     
  
theorem swapOracleImage_bijective (p : OneTermRobinParameters) :
    (∀ (a b : Fin (qubitDim (oneTermRobinTotalQubits p))),
        (⟨swapOracleImage p a.val, swapOracleImage_lt_qubitDim p a.2⟩ :
          Fin (qubitDim (oneTermRobinTotalQubits p))) =
        ⟨swapOracleImage p b.val, swapOracleImage_lt_qubitDim p b.2⟩ →
        a = b) ∧
    ∀ (y : Fin (qubitDim (oneTermRobinTotalQubits p))),
      ∃ (x : Fin (qubitDim (oneTermRobinTotalQubits p))),
        (⟨swapOracleImage p x.val, swapOracleImage_lt_qubitDim p x.2⟩ :
          Fin (qubitDim (oneTermRobinTotalQubits p))) = y := by
  constructor
  · intro a b h
    apply Fin.ext
    exact swapOracleImage_injective p (Fin.ext_iff.mp h)
  · intro y
    refine ⟨⟨swapOracleImage p y.val, swapOracleImage_lt_qubitDim p y.2⟩, ?_⟩
    apply Fin.ext
    exact swapOracleImage_self_inverse p y.val

   
                                                                              
                 
  
theorem swapOracleMatrix_col_has_one (p : OneTermRobinParameters)
    (j : Fin (qubitDim (oneTermRobinTotalQubits p))) :
    swapOracleMatrix p
      (⟨swapOracleImage p j.val, swapOracleImage_lt_qubitDim p j.2⟩ :
        Fin (qubitDim (oneTermRobinTotalQubits p))) j = Coeff.rat 1 := by
  rw [swapOracleMatrix_eq_image]
  simp

   
                                                                           
                  
  
theorem swapOracleMatrix_col_unique (p : OneTermRobinParameters)
    (i j : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (h : swapOracleMatrix p i j = Coeff.rat 1) :
    i = ⟨swapOracleImage p j.val, swapOracleImage_lt_qubitDim p j.2⟩ := by
  rw [swapOracleMatrix_eq_image] at h
  split at h
  · next h_cond => exact Fin.ext h_cond
  · next _ => simp at h

                                                                     
theorem swapOracleMatrix_row_has_one (p : OneTermRobinParameters)
    (i : Fin (qubitDim (oneTermRobinTotalQubits p))) :
    ∃ (j : Fin (qubitDim (oneTermRobinTotalQubits p))),
      swapOracleMatrix p i j = Coeff.rat 1 := by
  have h_surj := (swapOracleImage_bijective p).2 i
  have ⟨⟨xval, xprop⟩, hx⟩ := h_surj
  refine ⟨⟨xval, xprop⟩, ?_⟩
  rw [swapOracleMatrix_eq_image]
  have h_eq : i.val = swapOracleImage p xval := by
    have := Fin.ext_iff.mp hx
    simp at this
    exact this.symm
  simp [h_eq]

                                                                           
theorem swapOracleMatrix_row_unique (p : OneTermRobinParameters)
    (i : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (j₁ j₂ : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (h₁ : swapOracleMatrix p i j₁ = Coeff.rat 1)
    (h₂ : swapOracleMatrix p i j₂ = Coeff.rat 1) :
    j₁ = j₂ := by
  have key₁ := swapOracleMatrix_col_unique p i j₁ h₁
  have key₂ := swapOracleMatrix_col_unique p i j₂ h₂
  have h_inj := (swapOracleImage_bijective p).1
  exact h_inj j₁ j₂ (key₁.symm.trans key₂)

   
                                                                            
                       

                                                                         
                                                                            
  
theorem swapOracleMatrix_is_permutation (p : OneTermRobinParameters) :
    (∀ (i : Fin (qubitDim (oneTermRobinTotalQubits p))),
      ∃ (j : Fin (qubitDim (oneTermRobinTotalQubits p))),
        swapOracleMatrix p i j = Coeff.rat 1 ∧
        ∀ (j' : Fin (qubitDim (oneTermRobinTotalQubits p))),
          swapOracleMatrix p i j' = Coeff.rat 1 → j' = j) ∧
    (∀ (j : Fin (qubitDim (oneTermRobinTotalQubits p))),
      ∃ (i : Fin (qubitDim (oneTermRobinTotalQubits p))),
        swapOracleMatrix p i j = Coeff.rat 1 ∧
        ∀ (i' : Fin (qubitDim (oneTermRobinTotalQubits p))),
          swapOracleMatrix p i' j = Coeff.rat 1 → i' = i) := by
  constructor
  · intro i
    have ⟨j, hj⟩ := swapOracleMatrix_row_has_one p i
    exact ⟨j, hj, fun j' hj' => (swapOracleMatrix_row_unique p i j j' hj hj').symm⟩
  · intro j
    let row := (⟨swapOracleImage p j.val, swapOracleImage_lt_qubitDim p j.2⟩ :
                  Fin (qubitDim (oneTermRobinTotalQubits p)))
    exact ⟨row, swapOracleMatrix_col_has_one p j,
      fun i' hi' => swapOracleMatrix_col_unique p i' j hi'⟩

   
                                                                               
                                                                               
                                                                              
                                               
  
theorem bandedSparseAccessPaperPostSwap_rowValue_eq_address
    (p : OneTermRobinParameters) (j : Nat)
    (haddr : bandedSparseAccessPaperAddress p j < (1 <<< p.n)) :
    (bandedSparseAccessPaperRegisters p
      (swapOracleImage p (bandedSparseAccessPaperImage p j))).rowValue =
      bandedSparseAccessPaperAddress p j := by
  have hswap :=
    swapOracleImage_block1_eq_block2 p (bandedSparseAccessPaperImage p j)
  have himage := bandedSparseAccessPaperImage_odRegisterValue_eq p j haddr
  unfold bandedSparseAccessPaperRegisters at hswap himage ⊢
  simpa using hswap.trans himage

   
                                                                        
                                                                       
                                                       
  
theorem bandedSparseAccessPaperPostSwap_odRegisterValue_eq_rowValue
    (p : OneTermRobinParameters) (j : Nat) :
    (bandedSparseAccessPaperRegisters p
      (swapOracleImage p (bandedSparseAccessPaperImage p j))).odRegisterValue =
      (bandedSparseAccessPaperRegisters p j).rowValue := by
  have hswap :=
    swapOracleImage_block2_eq_block1 p (bandedSparseAccessPaperImage p j)
  have himage := bandedSparseAccessPaperImage_rowValue_eq p j
  unfold bandedSparseAccessPaperRegisters at hswap himage ⊢
  simpa using hswap.trans himage

   
                                                                             
                                                                              
                                                           
  
theorem bandedSparseAccessPaperPostSwapImage_lt_qubitDim_of_address_lt
    (p : OneTermRobinParameters)
    (source : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (haddr : bandedSparseAccessPaperAddress p source.val < (1 <<< p.n)) :
    swapOracleImage p (bandedSparseAccessPaperImage p source.val) <
      qubitDim (oneTermRobinTotalQubits p) := by
  have himage :
      bandedSparseAccessPaperImage p source.val <
        qubitDim (oneTermRobinTotalQubits p) :=
    bandedSparseAccessPaperImage_lt_qubitDim_of_address_lt
      p source.val source.2 haddr
  exact swapOracleImage_lt_qubitDim p himage

   
                                                                            
                                                

                                                                              
                                                                            
  
def bandedSparseAccessPaperSpliceODRegister
    (p : OneTermRobinParameters) (j odValue : Nat) : Nat :=
  let lowWidth := 1 + p.n
  let highWidth := 1 + 2 * p.n
  let lowBase := 2 ^ lowWidth
  let highBase := 2 ^ highWidth
  j % lowBase + odValue * lowBase + (j / highBase) * highBase

                                                                                  
theorem bandedSparseAccessPaperImage_eq_splice
    (p : OneTermRobinParameters) (j : Nat) :
    bandedSparseAccessPaperImage p j =
      bandedSparseAccessPaperSpliceODRegister p j
        (bandedSparseAccessPaperAddress p j) := by
  rfl

                                                                                            
theorem bandedSparseAccessPaperSpliceODRegister_lowBlock_lt_highBase_of_odValue_lt
    (p : OneTermRobinParameters) (j odValue : Nat)
    (hod : odValue < (1 <<< p.n)) :
    let lowWidth := 1 + p.n
    let highWidth := 1 + 2 * p.n
    let lowBase := 2 ^ lowWidth
    let highBase := 2 ^ highWidth
    let lowPrefix := j % lowBase
    lowPrefix + odValue * lowBase < highBase := by
  rw [Nat.one_shiftLeft] at hod
  dsimp
  have hlowPos : 0 < 2 ^ (1 + p.n) :=
    Nat.pow_pos (by decide : 0 < 2)
  have hlow : j % 2 ^ (1 + p.n) < 2 ^ (1 + p.n) :=
    Nat.mod_lt j hlowPos
  have hbase : 2 ^ (1 + 2 * p.n) = 2 ^ (1 + p.n) * 2 ^ p.n := by
    rw [← Nat.pow_add]
    congr 1
    omega
  rw [hbase]
  have hlt1 :
      j % 2 ^ (1 + p.n) + odValue * 2 ^ (1 + p.n) <
        2 ^ (1 + p.n) + odValue * 2 ^ (1 + p.n) := by
    exact Nat.add_lt_add_right hlow (odValue * 2 ^ (1 + p.n))
  have hsucc : odValue + 1 ≤ 2 ^ p.n := Nat.succ_le_of_lt hod
  have hle :
      (odValue + 1) * 2 ^ (1 + p.n) ≤ 2 ^ p.n * 2 ^ (1 + p.n) := by
    exact Nat.mul_le_mul_right (2 ^ (1 + p.n)) hsucc
  have heq :
      2 ^ (1 + p.n) + odValue * 2 ^ (1 + p.n) =
        (odValue + 1) * 2 ^ (1 + p.n) := by
    rw [Nat.add_comm]
    exact (Nat.succ_mul odValue (2 ^ (1 + p.n))).symm
  rw [heq] at hlt1
  rw [Nat.mul_comm (2 ^ (1 + p.n)) (2 ^ p.n)]
  exact Nat.lt_of_lt_of_le hlt1 hle

                                                                     
theorem bandedSparseAccessPaperSpliceODRegister_mod_lowBase
    (p : OneTermRobinParameters) (j odValue : Nat) :
    bandedSparseAccessPaperSpliceODRegister p j odValue % 2 ^ (1 + p.n) =
      j % 2 ^ (1 + p.n) := by
  unfold bandedSparseAccessPaperSpliceODRegister
  let lowWidth := 1 + p.n
  let highWidth := 1 + 2 * p.n
  let lowBase := 2 ^ lowWidth
  let highBase := 2 ^ highWidth
  let lowPrefix := j % lowBase
  have hbase : highBase = lowBase * 2 ^ p.n := by
    dsimp [highBase, lowBase, highWidth, lowWidth]
    rw [← Nat.pow_add]
    congr 1
    omega
  have hlow : lowPrefix % lowBase = lowPrefix := by
    dsimp [lowPrefix]
    exact Nat.mod_eq_of_lt (Nat.mod_lt j (Nat.pow_pos (by decide : 0 < 2)))
  calc
    (lowPrefix + odValue * lowBase + j / highBase * highBase) % lowBase
        = (lowPrefix + lowBase * odValue + j / highBase * highBase) % lowBase := by
          rw [Nat.mul_comm odValue lowBase]
    _ = (lowPrefix + lowBase * odValue + j / highBase * (lowBase * 2 ^ p.n)) %
          lowBase := by
          rw [hbase]
    _ = (lowPrefix + lowBase * (odValue + j / highBase * 2 ^ p.n)) % lowBase := by
          congr 1
          rw [Nat.mul_add]
          ac_rfl
    _ = lowPrefix % lowBase := by
          rw [Nat.add_mul_mod_self_left]
    _ = lowPrefix := hlow
    _ = j % 2 ^ (1 + p.n) := by rfl

                                                                                         
theorem bandedSparseAccessPaperSpliceODRegister_div_lowBase_mod_eq
    (p : OneTermRobinParameters) (j odValue : Nat)
    (hod : odValue < (1 <<< p.n)) :
    bandedSparseAccessPaperSpliceODRegister p j odValue / 2 ^ (1 + p.n) %
        2 ^ p.n =
      odValue := by
  unfold bandedSparseAccessPaperSpliceODRegister
  rw [Nat.one_shiftLeft] at hod
  let lowWidth := 1 + p.n
  let highWidth := 1 + 2 * p.n
  let lowBase := 2 ^ lowWidth
  let highBase := 2 ^ highWidth
  let lowPrefix := j % lowBase
  have hlowPos : 0 < lowBase := by
    dsimp [lowBase, lowWidth]
    exact Nat.pow_pos (by decide : 0 < 2)
  have hlow : lowPrefix < lowBase := by
    dsimp [lowPrefix]
    exact Nat.mod_lt j hlowPos
  have hbase : highBase = lowBase * 2 ^ p.n := by
    dsimp [highBase, lowBase, highWidth, lowWidth]
    rw [← Nat.pow_add]
    congr 1
    omega
  have hsplice : lowPrefix + odValue * lowBase + j / highBase * highBase =
      lowPrefix + lowBase * (odValue + j / highBase * 2 ^ p.n) := by
    rw [hbase]
    rw [Nat.mul_add]
    ac_rfl
  have hdiv :
      (lowPrefix + lowBase * (odValue + j / highBase * 2 ^ p.n)) / lowBase =
        odValue + j / highBase * 2 ^ p.n := by
    rw [Nat.add_mul_div_left _ _ hlowPos]
    rw [Nat.div_eq_of_lt hlow]
    simp
  have hlowWidth : 2 ^ (1 + p.n) = lowBase := by rfl
  rw [hlowWidth]
  rw [hsplice]
  rw [hdiv]
  rw [Nat.add_mul_mod_self_right]
  exact Nat.mod_eq_of_lt hod

                                        
theorem bandedSparseAccessPaperSpliceODRegister_rowValue_eq
    (p : OneTermRobinParameters) (j odValue : Nat) :
    (bandedSparseAccessPaperRegisters p
      (bandedSparseAccessPaperSpliceODRegister p j odValue)).rowValue =
      (bandedSparseAccessPaperRegisters p j).rowValue := by
  unfold bandedSparseAccessPaperRegisters
  simp only []
  rw [bandedSparseAccessPaperRegisterValue_eq_mod,
    bandedSparseAccessPaperRegisterValue_eq_mod]
  have hpow : 2 * 2 ^ p.n = 2 ^ (1 + p.n) := by
    rw [show 1 + p.n = p.n + 1 by omega, Nat.pow_succ]
    omega
  have hmod := bandedSparseAccessPaperSpliceODRegister_mod_lowBase p j odValue
  rw [← hpow] at hmod
  rw [← Nat.mod_mul_right_div_self
    (bandedSparseAccessPaperSpliceODRegister p j odValue) 2 (2 ^ p.n)]
  rw [← Nat.mod_mul_right_div_self j 2 (2 ^ p.n)]
  rw [hmod]

                                                                                              
theorem bandedSparseAccessPaperSpliceODRegister_odRegisterValue_eq
    (p : OneTermRobinParameters) (j odValue : Nat)
    (hod : odValue < (1 <<< p.n)) :
    (bandedSparseAccessPaperRegisters p
      (bandedSparseAccessPaperSpliceODRegister p j odValue)).odRegisterValue =
      odValue := by
  unfold bandedSparseAccessPaperRegisters
  simp only []
  rw [bandedSparseAccessPaperRegisterValue_eq_mod]
  exact bandedSparseAccessPaperSpliceODRegister_div_lowBase_mod_eq p j odValue hod

                                                                             
theorem bandedSparseAccessPaperSpliceODRegister_div_highBase_eq_of_odValue_lt
    (p : OneTermRobinParameters) (j odValue : Nat)
    (hod : odValue < (1 <<< p.n)) :
    bandedSparseAccessPaperSpliceODRegister p j odValue / 2 ^ (1 + 2 * p.n) =
      j / 2 ^ (1 + 2 * p.n) := by
  unfold bandedSparseAccessPaperSpliceODRegister
  let lowWidth := 1 + p.n
  let highWidth := 1 + 2 * p.n
  let lowBase := 2 ^ lowWidth
  let highBase := 2 ^ highWidth
  let lowPrefix := j % lowBase
  have hhighPos : 0 < highBase := by
    dsimp [highBase, highWidth]
    exact Nat.pow_pos (by decide : 0 < 2)
  have hsmall : lowPrefix + odValue * lowBase < highBase :=
    bandedSparseAccessPaperSpliceODRegister_lowBlock_lt_highBase_of_odValue_lt
      p j odValue hod
  calc
    (lowPrefix + odValue * lowBase + j / highBase * highBase) / highBase
        = (lowPrefix + odValue * lowBase + highBase * (j / highBase)) /
            highBase := by
          rw [Nat.mul_comm (j / highBase) highBase]
    _ = (lowPrefix + odValue * lowBase) / highBase + j / highBase := by
          rw [Nat.add_mul_div_left _ _ hhighPos]
    _ = j / highBase := by simp [Nat.div_eq_of_lt hsmall]
    _ = j / 2 ^ (1 + 2 * p.n) := by rfl

   
                                                                            
                                                                              
                                                                                
  
theorem bandedSparseAccessPaperSpliceODRegister_lt_qubitDim_of_odValue_lt
    (p : OneTermRobinParameters) (j odValue : Nat)
    (hj : j < qubitDim (oneTermRobinTotalQubits p))
    (hod : odValue < (1 <<< p.n)) :
    bandedSparseAccessPaperSpliceODRegister p j odValue <
      qubitDim (oneTermRobinTotalQubits p) := by
  simp only [qubitDim, gridSize] at hj ⊢
  unfold bandedSparseAccessPaperSpliceODRegister
  let lowWidth := 1 + p.n
  let highWidth := 1 + 2 * p.n
  let lowBase := 2 ^ lowWidth
  let highBase := 2 ^ highWidth
  let lowPrefix := j % lowBase
  have hsmall :
      lowPrefix + odValue * lowBase < highBase :=
    bandedSparseAccessPaperSpliceODRegister_lowBlock_lt_highBase_of_odValue_lt
      p j odValue hod
  have hwidth : highWidth ≤ oneTermRobinTotalQubits p := by
    dsimp [highWidth]
    exact bandedSparseAccessPaperHighWidth_le_totalQubits p
  have hpowTotal : highBase * 2 ^ (oneTermRobinTotalQubits p - highWidth) =
      2 ^ oneTermRobinTotalQubits p := by
    dsimp [highBase]
    rw [← Nat.pow_add]
    congr 1
    omega
  have htail_lt : j / highBase < 2 ^ (oneTermRobinTotalQubits p - highWidth) := by
    apply Nat.div_lt_of_lt_mul
    rwa [hpowTotal]
  have htail_succ :
      j / highBase + 1 ≤ 2 ^ (oneTermRobinTotalQubits p - highWidth) :=
    Nat.succ_le_of_lt htail_lt
  have hblock :
      lowPrefix + odValue * lowBase + j / highBase * highBase <
        highBase * (j / highBase + 1) := by
    rw [Nat.mul_succ, Nat.mul_comm highBase (j / highBase)]
    omega
  have htotal :
      highBase * (j / highBase + 1) ≤ 2 ^ oneTermRobinTotalQubits p := by
    have hmul := Nat.mul_le_mul_left highBase htail_succ
    rwa [hpowTotal] at hmul
  exact Nat.lt_of_lt_of_le hblock htotal

                                                                                   
theorem bandedSparseAccessPaperSpliceODRegister_splice_of_odValue_lt
    (p : OneTermRobinParameters) (j odValue newODValue : Nat)
    (hod : odValue < (1 <<< p.n)) :
    bandedSparseAccessPaperSpliceODRegister p
        (bandedSparseAccessPaperSpliceODRegister p j odValue) newODValue =
      bandedSparseAccessPaperSpliceODRegister p j newODValue := by
  have hmod := bandedSparseAccessPaperSpliceODRegister_mod_lowBase p j odValue
  have hdiv :=
    bandedSparseAccessPaperSpliceODRegister_div_highBase_eq_of_odValue_lt
      p j odValue hod
  unfold bandedSparseAccessPaperSpliceODRegister at hmod hdiv ⊢
  simp only [] at hmod hdiv ⊢
  rw [hmod, hdiv]

                                                                                       
theorem bandedSparseAccessPaperSpliceODRegister_self
    (p : OneTermRobinParameters) (j : Nat) :
    bandedSparseAccessPaperSpliceODRegister p j
      (bandedSparseAccessPaperRegisters p j).odRegisterValue = j := by
  unfold bandedSparseAccessPaperSpliceODRegister
  let lowWidth := 1 + p.n
  let highWidth := 1 + 2 * p.n
  let lowBase := 2 ^ lowWidth
  let midBase := 2 ^ p.n
  let highBase := 2 ^ highWidth
  have hbase : highBase = lowBase * midBase := by
    dsimp [highBase, lowBase, midBase, highWidth, lowWidth]
    rw [← Nat.pow_add]
    congr 1
    omega
  have hod : (bandedSparseAccessPaperRegisters p j).odRegisterValue =
      (j / lowBase) % midBase := by
    unfold bandedSparseAccessPaperRegisters
    dsimp [lowBase, midBase, lowWidth]
    rw [bandedSparseAccessPaperRegisterValue_eq_mod]
  have hmodH :
      j % highBase = j % lowBase + ((j / lowBase) % midBase) * lowBase := by
    have hdecomp := Nat.mod_add_div (j % highBase) lowBase
    have hmodLow : j % highBase % lowBase = j % lowBase := by
      rw [hbase]
      exact Nat.mod_mul_right_mod j lowBase midBase
    have hdivMid : j % highBase / lowBase = j / lowBase % midBase := by
      rw [hbase]
      exact Nat.mod_mul_right_div_self j lowBase midBase
    rw [← hdecomp, hmodLow, hdivMid]
    ac_rfl
  calc
    j % lowBase + (bandedSparseAccessPaperRegisters p j).odRegisterValue * lowBase +
          j / highBase * highBase
        = j % lowBase + ((j / lowBase) % midBase) * lowBase +
          j / highBase * highBase := by rw [hod]
    _ = j % highBase + j / highBase * highBase := by rw [hmodH]
    _ = j := by
      rw [Nat.mul_comm (j / highBase) highBase]
      exact Nat.mod_add_div j highBase

                                                                                                    
def bandedSparseAccessPaperCleanODValue
    (p : OneTermRobinParameters) (sparseValue : Nat) : Nat :=
  sparseValue <<< (p.n - clog2 p.kappa)

                                                              
theorem bandedSparseAccessPaperCleanODValue_paddedZero_eq_zero
    (p : OneTermRobinParameters) (sparseValue : Nat) :
    bandedSparseAccessPaperCleanODValue p sparseValue &&&
        ((1 <<< (p.n - clog2 p.kappa)) - 1) = 0 := by
  unfold bandedSparseAccessPaperCleanODValue
  exact shiftLeft_land_mask_eq_zero sparseValue (p.n - clog2 p.kappa)
    (p.n - clog2 p.kappa) (by omega)

                                                                                           
theorem bandedSparseAccessPaperCleanODValue_lt_two_pow_of_sparse_lt
    (p : OneTermRobinParameters) {sparseValue : Nat}
    (hwidth : clog2 p.kappa ≤ p.n)
    (hsparse : sparseValue < 2 ^ clog2 p.kappa) :
    bandedSparseAccessPaperCleanODValue p sparseValue < (1 <<< p.n) := by
  unfold bandedSparseAccessPaperCleanODValue
  rw [Nat.shiftLeft_eq, Nat.one_shiftLeft]
  have hpow : 2 ^ p.n = 2 ^ clog2 p.kappa * 2 ^ (p.n - clog2 p.kappa) := by
    rw [← Nat.pow_add]
    congr 1
    omega
  rw [hpow]
  exact Nat.mul_lt_mul_of_pos_right hsparse (Nat.pow_pos (by decide : 0 < 2))

                                                                                    
theorem bandedSparseAccessPaperCleanODValue_sparseIndex_eq
    (p : OneTermRobinParameters) {sparseValue : Nat}
    (hsparse : sparseValue < 2 ^ clog2 p.kappa) :
    ((bandedSparseAccessPaperCleanODValue p sparseValue >>>
          (p.n - clog2 p.kappa)) &&& ((1 <<< clog2 p.kappa) - 1)) =
      sparseValue := by
  rw [bandedSparseAccessPaperRegisterValue_eq_mod]
  unfold bandedSparseAccessPaperCleanODValue
  rw [Nat.shiftLeft_eq]
  rw [Nat.mul_div_left sparseValue (Nat.pow_pos (by decide : 0 < 2))]
  exact Nat.mod_eq_of_lt hsparse

   
                                                                           
                                                          

                                                                             
                                                                         
                                                       
  
theorem bandedSparseAccessPaperCleanInput_odRegisterValue_eq_cleanODValue
    (p : OneTermRobinParameters) (j : Nat)
    (hwidth : clog2 p.kappa ≤ p.n)
    (hclean : bandedSparseAccessPaperCleanInput p j = true) :
    (bandedSparseAccessPaperRegisters p j).odRegisterValue =
      bandedSparseAccessPaperCleanODValue p
        (bandedSparseAccessPaperRegisters p j).sparseIndexValue := by
  let regs := bandedSparseAccessPaperRegisters p j
  let a := p.n - clog2 p.kappa
  let b := clog2 p.kappa
  have hcleanZero : regs.paddedZeroValue = 0 := by
    simpa [regs] using (bandedSparseAccessPaperCleanInput_iff p j).1 hclean
  have hpaddedEq :
      regs.paddedZeroValue =
        regs.odRegisterValue &&& ((1 <<< a) - 1) := by
    simpa [regs, a] using
      bandedSparseAccessPaperRegisters_paddedZeroValue_eq p j
  have hmodMask :
      regs.odRegisterValue &&& ((1 <<< a) - 1) =
        regs.odRegisterValue % 2 ^ a := by
    simpa [Nat.shiftRight_zero] using
      bandedSparseAccessPaperRegisterValue_eq_mod regs.odRegisterValue 0 a
  have hodMod : regs.odRegisterValue % 2 ^ a = 0 := by
    rw [hpaddedEq, hmodMask] at hcleanZero
    exact hcleanZero
  have hsparseMod :
      regs.sparseIndexValue =
        (regs.odRegisterValue / 2 ^ a) % 2 ^ b := by
    rw [bandedSparseAccessPaperRegisters_sparseIndexValue_eq]
    simpa [regs, a, b] using
      bandedSparseAccessPaperRegisterValue_eq_mod regs.odRegisterValue a b
  have hodLt :
      regs.odRegisterValue < 2 ^ p.n := by
    simpa [regs, Nat.one_shiftLeft] using
      bandedSparseAccessPaperRegisters_odRegisterValue_lt p j
  have hpow :
      2 ^ p.n = 2 ^ a * 2 ^ b := by
    dsimp [a, b]
    rw [← Nat.pow_add]
    congr 1
    omega
  have hdivLt :
      regs.odRegisterValue / 2 ^ a < 2 ^ b := by
    apply Nat.div_lt_of_lt_mul
    rwa [← hpow]
  have hsparseEq :
      regs.sparseIndexValue = regs.odRegisterValue / 2 ^ a := by
    rw [hsparseMod]
    exact Nat.mod_eq_of_lt hdivLt
  have hdecomp := Nat.mod_add_div regs.odRegisterValue (2 ^ a)
  calc
    regs.odRegisterValue
        = regs.odRegisterValue % 2 ^ a +
            2 ^ a * (regs.odRegisterValue / 2 ^ a) := hdecomp.symm
    _ = 2 ^ a * (regs.odRegisterValue / 2 ^ a) := by
          simp [hodMod]
    _ = (regs.odRegisterValue / 2 ^ a) * 2 ^ a := by
          rw [Nat.mul_comm]
    _ = regs.sparseIndexValue * 2 ^ a := by
          rw [hsparseEq]
    _ = bandedSparseAccessPaperCleanODValue p regs.sparseIndexValue := by
          simp [bandedSparseAccessPaperCleanODValue, Nat.shiftLeft_eq,
            regs, a]

   
                                                                      
                                

                                                                             
                                                                             
                                                                      
                                                                             
                           
  
theorem bandedSparseAccessPaperImage_injective_on_globalSlotSource
    (p : OneTermRobinParameters)
    (j₁ j₂ : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hn : 3 ≤ p.n) (hkappa : p.kappa = 7) (hκbits : clog2 p.kappa = 3)
    (hsource₁ : bandedSparseAccessPaperGlobalSlotSource p j₁.val = true)
    (hsource₂ : bandedSparseAccessPaperGlobalSlotSource p j₂.val = true)
    (himage :
      bandedSparseAccessPaperImage p j₁.val =
        bandedSparseAccessPaperImage p j₂.val) :
    j₁ = j₂ := by
  have htwo : 2 ≤ p.n := by omega
  have hwidth : clog2 p.kappa ≤ p.n := by
    rw [hκbits]
    omega
  have haddr₁ :
      bandedSparseAccessPaperAddress p j₁.val < (1 <<< p.n) := by
    have h := bandedSparseAccessPaperAddress_lt_gridSize_of_two_le
      p j₁.val htwo
    simpa [gridSize, Nat.one_shiftLeft] using h
  have haddr₂ :
      bandedSparseAccessPaperAddress p j₂.val < (1 <<< p.n) := by
    have h := bandedSparseAccessPaperAddress_lt_gridSize_of_two_le
      p j₂.val htwo
    simpa [gridSize, Nat.one_shiftLeft] using h
  have hlow :
      j₁.val % 2 ^ (1 + p.n) = j₂.val % 2 ^ (1 + p.n) := by
    calc
      j₁.val % 2 ^ (1 + p.n)
          = bandedSparseAccessPaperImage p j₁.val % 2 ^ (1 + p.n) := by
              rw [bandedSparseAccessPaperImage_mod_lowBase]
      _ = bandedSparseAccessPaperImage p j₂.val % 2 ^ (1 + p.n) := by
              rw [himage]
      _ = j₂.val % 2 ^ (1 + p.n) := by
              rw [bandedSparseAccessPaperImage_mod_lowBase]
  have htail :
      bandedSparseAccessPaperHighTail p j₁.val =
        bandedSparseAccessPaperHighTail p j₂.val := by
    calc
      bandedSparseAccessPaperHighTail p j₁.val =
          bandedSparseAccessPaperHighTail p
            (bandedSparseAccessPaperImage p j₁.val) := by
            exact (bandedSparseAccessPaperImage_highTail_eq_of_address_lt
              p j₁.val haddr₁).symm
      _ = bandedSparseAccessPaperHighTail p
            (bandedSparseAccessPaperImage p j₂.val) := by
            rw [himage]
      _ = bandedSparseAccessPaperHighTail p j₂.val :=
            bandedSparseAccessPaperImage_highTail_eq_of_address_lt
              p j₂.val haddr₂
  have htailDiv :
      j₁.val / 2 ^ (1 + 2 * p.n) =
        j₂.val / 2 ^ (1 + 2 * p.n) := by
    simpa [bandedSparseAccessPaperHighTail, Nat.shiftRight_eq_div_pow]
      using htail
  have hrow :
      (bandedSparseAccessPaperRegisters p j₁.val).rowValue =
        (bandedSparseAccessPaperRegisters p j₂.val).rowValue := by
    calc
      (bandedSparseAccessPaperRegisters p j₁.val).rowValue =
          (bandedSparseAccessPaperRegisters p
            (bandedSparseAccessPaperImage p j₁.val)).rowValue := by
            exact (bandedSparseAccessPaperImage_rowValue_eq p j₁.val).symm
      _ = (bandedSparseAccessPaperRegisters p
            (bandedSparseAccessPaperImage p j₂.val)).rowValue := by
            rw [himage]
      _ = (bandedSparseAccessPaperRegisters p j₂.val).rowValue :=
            bandedSparseAccessPaperImage_rowValue_eq p j₂.val
  have haddrEq :
      bandedSparseAccessPaperAddress p j₁.val =
        bandedSparseAccessPaperAddress p j₂.val := by
    calc
      bandedSparseAccessPaperAddress p j₁.val =
          (bandedSparseAccessPaperRegisters p
            (bandedSparseAccessPaperImage p j₁.val)).odRegisterValue := by
            exact (bandedSparseAccessPaperImage_odRegisterValue_eq
              p j₁.val haddr₁).symm
      _ = (bandedSparseAccessPaperRegisters p
            (bandedSparseAccessPaperImage p j₂.val)).odRegisterValue := by
            rw [himage]
      _ = bandedSparseAccessPaperAddress p j₂.val :=
            bandedSparseAccessPaperImage_odRegisterValue_eq p j₂.val haddr₂
  have hsparse :
      (bandedSparseAccessPaperRegisters p j₁.val).sparseIndexValue =
        (bandedSparseAccessPaperRegisters p j₂.val).sparseIndexValue :=
    bandedSparseAccessPaperAddress_same_row_injective_of_globalSlotSource
      p hn hkappa hsource₁ hsource₂ hrow haddrEq
  have hclean₁ :
      bandedSparseAccessPaperCleanInput p j₁.val = true :=
    bandedSparseAccessPaperGlobalSlotSource_cleanInput_eq_true
      p j₁.val hsource₁
  have hclean₂ :
      bandedSparseAccessPaperCleanInput p j₂.val = true :=
    bandedSparseAccessPaperGlobalSlotSource_cleanInput_eq_true
      p j₂.val hsource₂
  have hod₁ :=
    bandedSparseAccessPaperCleanInput_odRegisterValue_eq_cleanODValue
      p j₁.val hwidth hclean₁
  have hod₂ :=
    bandedSparseAccessPaperCleanInput_odRegisterValue_eq_cleanODValue
      p j₂.val hwidth hclean₂
  have hod :
      (bandedSparseAccessPaperRegisters p j₁.val).odRegisterValue =
        (bandedSparseAccessPaperRegisters p j₂.val).odRegisterValue := by
    calc
      (bandedSparseAccessPaperRegisters p j₁.val).odRegisterValue =
          bandedSparseAccessPaperCleanODValue p
            (bandedSparseAccessPaperRegisters p j₁.val).sparseIndexValue := hod₁
      _ = bandedSparseAccessPaperCleanODValue p
            (bandedSparseAccessPaperRegisters p j₂.val).sparseIndexValue := by
            rw [hsparse]
      _ = (bandedSparseAccessPaperRegisters p j₂.val).odRegisterValue := hod₂.symm
  apply Fin.ext
  calc
    j₁.val =
        bandedSparseAccessPaperSpliceODRegister p j₁.val
          (bandedSparseAccessPaperRegisters p j₁.val).odRegisterValue := by
          exact (bandedSparseAccessPaperSpliceODRegister_self p j₁.val).symm
    _ = bandedSparseAccessPaperSpliceODRegister p j₂.val
          (bandedSparseAccessPaperRegisters p j₂.val).odRegisterValue := by
          simp [bandedSparseAccessPaperSpliceODRegister, hlow, hod, htailDiv]
    _ = j₂.val :=
          bandedSparseAccessPaperSpliceODRegister_self p j₂.val

   
                                                                            
                                                                  
  
theorem bandedSparseAccessPaperPostSwapReverseSparse_lt_two_pow
    (p : OneTermRobinParameters) (source : Nat)
    (hn : 3 ≤ p.n) (hκbits : clog2 p.kappa = 3) :
    oneTermRobinGlobalSparseInverseSlot
        (bandedSparseAccessPaperRegisters p source).sparseIndexValue <
      2 ^ clog2 p.kappa := by
  have _nLower := hn
  let regs := bandedSparseAccessPaperRegisters p source
  rw [hκbits]
  exact oneTermRobinGlobalSparseInverseSlot_lt_eight regs.sparseIndexValue

   
                                                                             
                                              
  
theorem bandedSparseAccessPaperPostSwapCleanODValue_lt_two_pow
    (p : OneTermRobinParameters) (source : Nat)
    (hn : 3 ≤ p.n) (hκbits : clog2 p.kappa = 3) :
    bandedSparseAccessPaperCleanODValue p
        (oneTermRobinGlobalSparseInverseSlot
          (bandedSparseAccessPaperRegisters p source).sparseIndexValue) <
      (1 <<< p.n) := by
  have hreverse :
      oneTermRobinGlobalSparseInverseSlot
          (bandedSparseAccessPaperRegisters p source).sparseIndexValue <
        2 ^ clog2 p.kappa :=
    bandedSparseAccessPaperPostSwapReverseSparse_lt_two_pow
      p source hn hκbits
  have hwidth : clog2 p.kappa ≤ p.n := by
    rw [hκbits]
    omega
  exact bandedSparseAccessPaperCleanODValue_lt_two_pow_of_sparse_lt
    p hwidth hreverse

   
                                                  
                                           

                                                                          
                                                                              
                                                                           
                                                                 
  
def bandedSparseAccessPaperPostSwapPreimageCandidate
    (p : OneTermRobinParameters) (source : Nat) : Nat :=
  let regs := bandedSparseAccessPaperRegisters p source
  let post := swapOracleImage p (bandedSparseAccessPaperImage p source)
  let reverseSparse := oneTermRobinGlobalSparseInverseSlot regs.sparseIndexValue
  bandedSparseAccessPaperSpliceODRegister p post
    (bandedSparseAccessPaperCleanODValue p reverseSparse)

   
                                                      

                                                                         
                                                                              
                                                                         
                                                                         
                
  
def bandedSparseAccessPaperPostSwapPreimageCandidateChecks
    (p : OneTermRobinParameters) (source : Nat) : Bool :=
  let post := swapOracleImage p (bandedSparseAccessPaperImage p source)
  let pre := bandedSparseAccessPaperPostSwapPreimageCandidate p source
  (bandedSparseAccessPaperImage p pre == post) &&
    bandedSparseAccessPaperCleanInput p pre &&
    bandedSparseAccessPaperAddressInRange p pre

   
                                                                               
                                                             

                                                                                
                                                                          
                                                                               
                                                                          
  
theorem bandedSparseAccessPaperPostSwapPreimageCandidateChecks_of_cleanSource
    (p : OneTermRobinParameters) (source : Nat)
    (hn : 3 ≤ p.n) (hkappa : p.kappa = 7) (hκbits : clog2 p.kappa = 3)
    (hsource : source < qubitDim (oneTermRobinTotalQubits p))
    (hclean : bandedSparseAccessPaperCleanInput p source = true) :
    bandedSparseAccessPaperPostSwapPreimageCandidateChecks p source = true := by
  have _sourceFinite := hsource
  have _sourceClean := (bandedSparseAccessPaperCleanInput_iff p source).1 hclean
  have _kappaValue := hkappa
  let regs := bandedSparseAccessPaperRegisters p source
  let post := swapOracleImage p (bandedSparseAccessPaperImage p source)
  let reverseSparse := oneTermRobinGlobalSparseInverseSlot regs.sparseIndexValue
  let cleanOD := bandedSparseAccessPaperCleanODValue p reverseSparse
  let pre := bandedSparseAccessPaperPostSwapPreimageCandidate p source
  have htwo : 2 ≤ p.n := by omega
  have haddrSource : bandedSparseAccessPaperAddress p source < (1 <<< p.n) := by
    have h := bandedSparseAccessPaperAddress_lt_gridSize_of_two_le p source htwo
    simpa [gridSize, Nat.one_shiftLeft] using h
  have hsourceSparsePow : regs.sparseIndexValue < 2 ^ clog2 p.kappa := by
    have h := bandedSparseAccessPaperRegisters_sparseIndex_lt p source
    rw [Nat.one_shiftLeft] at h
    simpa [regs] using h
  have hsourceSparseLt8 : regs.sparseIndexValue < 8 := by
    have h := hsourceSparsePow
    rw [hκbits] at h
    simpa using h
  have hrowLt : regs.rowValue < gridSize p.n := by
    simpa [regs] using bandedSparseAccessPaperRegisters_row_lt_gridSize p source
  have hreverseLt8 : reverseSparse < 8 := by
    simpa [reverseSparse] using
      oneTermRobinGlobalSparseInverseSlot_lt_eight regs.sparseIndexValue
  have hreversePow : reverseSparse < 2 ^ clog2 p.kappa := by
    rw [hκbits]
    simpa using hreverseLt8
  have hwidth : clog2 p.kappa ≤ p.n := by
    rw [hκbits]
    omega
  have hcleanODBound : cleanOD < (1 <<< p.n) :=
    bandedSparseAccessPaperCleanODValue_lt_two_pow_of_sparse_lt p hwidth hreversePow
  have hpre_eq : pre = bandedSparseAccessPaperSpliceODRegister p post cleanOD := by
    simp [pre, bandedSparseAccessPaperPostSwapPreimageCandidate, post,
      cleanOD, reverseSparse, regs]
  have hpreRow : (bandedSparseAccessPaperRegisters p pre).rowValue =
      (bandedSparseAccessPaperRegisters p post).rowValue := by
    rw [hpre_eq]
    exact bandedSparseAccessPaperSpliceODRegister_rowValue_eq p post cleanOD
  have hpreOD : (bandedSparseAccessPaperRegisters p pre).odRegisterValue = cleanOD := by
    rw [hpre_eq]
    exact bandedSparseAccessPaperSpliceODRegister_odRegisterValue_eq
      p post cleanOD hcleanODBound
  have hpreSparse :
      (bandedSparseAccessPaperRegisters p pre).sparseIndexValue = reverseSparse := by
    rw [bandedSparseAccessPaperRegisters_sparseIndexValue_eq]
    rw [hpreOD]
    exact bandedSparseAccessPaperCleanODValue_sparseIndex_eq p hreversePow
  have hpreClean : bandedSparseAccessPaperCleanInput p pre = true := by
    rw [bandedSparseAccessPaperCleanInput_iff]
    rw [bandedSparseAccessPaperRegisters_paddedZeroValue_eq]
    rw [hpreOD]
    exact bandedSparseAccessPaperCleanODValue_paddedZero_eq_zero p reverseSparse
  have hpreAddressRange : bandedSparseAccessPaperAddressInRange p pre = true :=
    bandedSparseAccessPaperAddressInRange_eq_true_of_two_le p pre htwo
  have hpostRow : (bandedSparseAccessPaperRegisters p post).rowValue =
      bandedSparseAccessPaperAddress p source := by
    dsimp [post]
    exact bandedSparseAccessPaperPostSwap_rowValue_eq_address p source haddrSource
  have hpostOd : (bandedSparseAccessPaperRegisters p post).odRegisterValue =
      regs.rowValue := by
    dsimp [post, regs]
    exact bandedSparseAccessPaperPostSwap_odRegisterValue_eq_rowValue p source
  have hround :
      oneTermRobinGlobalSparseAddress p.n reverseSparse
        (bandedSparseAccessPaperAddress p source) = regs.rowValue := by
    have h :=
      oneTermRobinGlobalSparseAddress_inverseSlot_address_eq
        (n := p.n) (s := regs.sparseIndexValue) (i := regs.rowValue)
        hn hsourceSparseLt8 hrowLt
    simpa [reverseSparse, regs, bandedSparseAccessPaperAddress] using h
  have hroundUnfold :
      oneTermRobinGlobalSparseAddress p.n reverseSparse
        (oneTermRobinGlobalSparseAddress p.n
          (bandedSparseAccessPaperRegisters p source).sparseIndexValue
          (bandedSparseAccessPaperRegisters p source).rowValue) =
        regs.rowValue := by
    simpa [bandedSparseAccessPaperAddress, regs] using hround
  have hpreAddress : bandedSparseAccessPaperAddress p pre =
      (bandedSparseAccessPaperRegisters p post).odRegisterValue := by
    simp [bandedSparseAccessPaperAddress, hpreSparse, hpreRow, hpostRow,
      hroundUnfold, hpostOd]
  have hpreImage : bandedSparseAccessPaperImage p pre = post := by
    rw [bandedSparseAccessPaperImage_eq_splice]
    rw [hpreAddress]
    rw [hpre_eq]
    rw [bandedSparseAccessPaperSpliceODRegister_splice_of_odValue_lt p post cleanOD
      (bandedSparseAccessPaperRegisters p post).odRegisterValue hcleanODBound]
    exact bandedSparseAccessPaperSpliceODRegister_self p post
  change ((bandedSparseAccessPaperImage p pre == post) &&
      bandedSparseAccessPaperCleanInput p pre &&
      bandedSparseAccessPaperAddressInRange p pre) = true
  simp [hpreImage, hpreClean, hpreAddressRange]

   
                                                                               
                                                                          
                                                                            
            
  
theorem bandedSparseAccessPaperPostSwapPreimageCandidate_lt_qubitDim_of_cleanSource
    (p : OneTermRobinParameters)
    (source : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hn : 3 ≤ p.n) (hkappa : p.kappa = 7) (hκbits : clog2 p.kappa = 3)
    (hclean : bandedSparseAccessPaperCleanInput p source.val = true) :
    bandedSparseAccessPaperPostSwapPreimageCandidate p source.val <
      qubitDim (oneTermRobinTotalQubits p) := by
  have _kappaValue := hkappa
  have _sourceClean := hclean
  let regs := bandedSparseAccessPaperRegisters p source.val
  let post := swapOracleImage p (bandedSparseAccessPaperImage p source.val)
  let reverseSparse := oneTermRobinGlobalSparseInverseSlot regs.sparseIndexValue
  let cleanOD := bandedSparseAccessPaperCleanODValue p reverseSparse
  let pre := bandedSparseAccessPaperPostSwapPreimageCandidate p source.val
  have htwo : 2 ≤ p.n := by omega
  have haddrSource : bandedSparseAccessPaperAddress p source.val < (1 <<< p.n) := by
    have h := bandedSparseAccessPaperAddress_lt_gridSize_of_two_le
      p source.val htwo
    simpa [gridSize, Nat.one_shiftLeft] using h
  have hpostRange :
      post < qubitDim (oneTermRobinTotalQubits p) := by
    dsimp [post]
    exact bandedSparseAccessPaperPostSwapImage_lt_qubitDim_of_address_lt
      p source haddrSource
  have hcleanODBound : cleanOD < (1 <<< p.n) := by
    dsimp [cleanOD, reverseSparse, regs]
    exact bandedSparseAccessPaperPostSwapCleanODValue_lt_two_pow
      p source.val hn hκbits
  have hpre_eq : pre =
      bandedSparseAccessPaperSpliceODRegister p post cleanOD := by
    simp [pre, bandedSparseAccessPaperPostSwapPreimageCandidate, post,
      cleanOD, reverseSparse, regs]
  have hpreRange :
      pre < qubitDim (oneTermRobinTotalQubits p) := by
    rw [hpre_eq]
    exact bandedSparseAccessPaperSpliceODRegister_lt_qubitDim_of_odValue_lt
      p post cleanOD hpostRange hcleanODBound
  simpa [pre] using hpreRange

   
                                                                           
                   

                                                                         
                                                                       
                                                                          
                                                                          
                                                         
  
theorem bandedSparseAccessPostSwapCleanup_of_cleanSourceCandidate
    (p : OneTermRobinParameters)
    (source : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hn : 3 <= p.n) (hkappa : p.kappa = 7) (hκbits : clog2 p.kappa = 3)
    (hclean : bandedSparseAccessPaperCleanInput p source.val = true)
    (hpostRange :
      swapOracleImage p (bandedSparseAccessPaperImage p source.val) <
        qubitDim (oneTermRobinTotalQubits p))
    (hpreRange :
      bandedSparseAccessPaperPostSwapPreimageCandidate p source.val <
        qubitDim (oneTermRobinTotalQubits p)) :
    BandedSparseAccessPostSwapCleanup p source
      ⟨swapOracleImage p (bandedSparseAccessPaperImage p source.val), hpostRange⟩
      ⟨bandedSparseAccessPaperPostSwapPreimageCandidate p source.val, hpreRange⟩ := by
  let postNat := swapOracleImage p (bandedSparseAccessPaperImage p source.val)
  let preNat := bandedSparseAccessPaperPostSwapPreimageCandidate p source.val
  have haudit :=
    bandedSparseAccessPaperPostSwapPreimageCandidateChecks_of_cleanSource
      p source.val hn hkappa hκbits source.2 hclean
  have hparts :
      (bandedSparseAccessPaperImage p preNat == postNat) = true ∧
        bandedSparseAccessPaperCleanInput p preNat = true ∧
        bandedSparseAccessPaperAddressInRange p preNat = true := by
    simpa [bandedSparseAccessPaperPostSwapPreimageCandidateChecks, preNat,
      postNat, Bool.and_assoc] using haudit
  have hpreImage : bandedSparseAccessPaperImage p preNat = postNat :=
    beq_iff_eq.mp hparts.1
  have haddr : bandedSparseAccessPaperAddress p preNat < (1 <<< p.n) :=
    (bandedSparseAccessPaperAddressInRange_iff p preNat).1 hparts.2.2
  exact bandedSparseAccessPostSwapCleanup_of_preimage p source
    ⟨postNat, hpostRange⟩ ⟨preNat, hpreRange⟩
    (by rfl)
    (by simpa [postNat, preNat] using hpreImage.symm)
    hparts.2.1 haddr

   
                                                                              
                                                                            
                                                                        
                                                
  
theorem bandedSparseAccessPostSwapCleanup_of_cleanSourceCandidate_noRange
    (p : OneTermRobinParameters)
    (source : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hn : 3 <= p.n) (hkappa : p.kappa = 7) (hκbits : clog2 p.kappa = 3)
    (hclean : bandedSparseAccessPaperCleanInput p source.val = true) :
    BandedSparseAccessPostSwapCleanup p source
      ⟨swapOracleImage p (bandedSparseAccessPaperImage p source.val),
        by
          have htwo : 2 ≤ p.n := by omega
          have haddrSource :
              bandedSparseAccessPaperAddress p source.val < (1 <<< p.n) := by
            have h := bandedSparseAccessPaperAddress_lt_gridSize_of_two_le
              p source.val htwo
            simpa [gridSize, Nat.one_shiftLeft] using h
          exact bandedSparseAccessPaperPostSwapImage_lt_qubitDim_of_address_lt
            p source haddrSource⟩
      ⟨bandedSparseAccessPaperPostSwapPreimageCandidate p source.val,
        bandedSparseAccessPaperPostSwapPreimageCandidate_lt_qubitDim_of_cleanSource
          p source hn hkappa hκbits hclean⟩ := by
  have htwo : 2 ≤ p.n := by omega
  have haddrSource :
      bandedSparseAccessPaperAddress p source.val < (1 <<< p.n) := by
    have h := bandedSparseAccessPaperAddress_lt_gridSize_of_two_le
      p source.val htwo
    simpa [gridSize, Nat.one_shiftLeft] using h
  have hpostRange :
      swapOracleImage p (bandedSparseAccessPaperImage p source.val) <
        qubitDim (oneTermRobinTotalQubits p) :=
    bandedSparseAccessPaperPostSwapImage_lt_qubitDim_of_address_lt
      p source haddrSource
  have hpreRange :
      bandedSparseAccessPaperPostSwapPreimageCandidate p source.val <
        qubitDim (oneTermRobinTotalQubits p) :=
    bandedSparseAccessPaperPostSwapPreimageCandidate_lt_qubitDim_of_cleanSource
      p source hn hkappa hκbits hclean
  exact bandedSparseAccessPostSwapCleanup_of_cleanSourceCandidate
    p source hn hkappa hκbits hclean hpostRange hpreRange

   
                                                                     
                                    

                                                                         
                                                                          
                                                                          
                                                                           
                                                                     
  
theorem bandedSparseAccessPostSwapCleanup_of_validCleanSourceCandidate_noRange
    (p : OneTermRobinParameters)
    (source : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hn : 3 <= p.n) (hkappa : p.kappa = 7) (hκbits : clog2 p.kappa = 3)
    (hvalid : bandedSparseAccessPaperValidCleanSource p source.val = true) :
    BandedSparseAccessPostSwapCleanup p source
      ⟨swapOracleImage p (bandedSparseAccessPaperImage p source.val),
        by
          have htwo : 2 ≤ p.n := by omega
          have haddrSource :
              bandedSparseAccessPaperAddress p source.val < (1 <<< p.n) := by
            have h := bandedSparseAccessPaperAddress_lt_gridSize_of_two_le
              p source.val htwo
            simpa [gridSize, Nat.one_shiftLeft] using h
          exact bandedSparseAccessPaperPostSwapImage_lt_qubitDim_of_address_lt
            p source haddrSource⟩
      ⟨bandedSparseAccessPaperPostSwapPreimageCandidate p source.val,
        by
          have hclean :
              bandedSparseAccessPaperCleanInput p source.val = true :=
            bandedSparseAccessPaperValidCleanSource_cleanInput_eq_true
              p source.val hvalid
          exact
            bandedSparseAccessPaperPostSwapPreimageCandidate_lt_qubitDim_of_cleanSource
              p source hn hkappa hκbits hclean⟩ := by
  have hclean :
      bandedSparseAccessPaperCleanInput p source.val = true :=
    bandedSparseAccessPaperValidCleanSource_cleanInput_eq_true
      p source.val hvalid
  exact bandedSparseAccessPostSwapCleanup_of_cleanSourceCandidate_noRange
    p source hn hkappa hκbits hclean

   
                                                                          
                          

                                                                          
                                                          
                                                                            
                                                                           
                                                
  
theorem bandedSparseAccessPostSwapCleanup_of_globalSlotSourceCandidate_noRange
    (p : OneTermRobinParameters)
    (source : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hn : 3 <= p.n) (hkappa : p.kappa = 7) (hκbits : clog2 p.kappa = 3)
    (hsource : bandedSparseAccessPaperGlobalSlotSource p source.val = true) :
    BandedSparseAccessPostSwapCleanup p source
      ⟨swapOracleImage p (bandedSparseAccessPaperImage p source.val),
        by
          have htwo : 2 ≤ p.n := by omega
          have haddrSource :
              bandedSparseAccessPaperAddress p source.val < (1 <<< p.n) := by
            have h := bandedSparseAccessPaperAddress_lt_gridSize_of_two_le
              p source.val htwo
            simpa [gridSize, Nat.one_shiftLeft] using h
          exact bandedSparseAccessPaperPostSwapImage_lt_qubitDim_of_address_lt
            p source haddrSource⟩
      ⟨bandedSparseAccessPaperPostSwapPreimageCandidate p source.val,
        by
          have hclean :
              bandedSparseAccessPaperCleanInput p source.val = true :=
            bandedSparseAccessPaperGlobalSlotSource_cleanInput_eq_true
              p source.val hsource
          exact
            bandedSparseAccessPaperPostSwapPreimageCandidate_lt_qubitDim_of_cleanSource
              p source hn hkappa hκbits hclean⟩ := by
  have hclean :
      bandedSparseAccessPaperCleanInput p source.val = true :=
    bandedSparseAccessPaperGlobalSlotSource_cleanInput_eq_true
      p source.val hsource
  exact bandedSparseAccessPostSwapCleanup_of_cleanSourceCandidate_noRange
    p source hn hkappa hκbits hclean

   
                                                                             
              

                                                                             
                                                                          
                                                                   
  
theorem bandedSparseAccessPaperPostSwapPreimageCandidateChecks_of_globalSlotSource
    (p : OneTermRobinParameters) (source : Nat)
    (hn : 3 <= p.n) (hkappa : p.kappa = 7) (hκbits : clog2 p.kappa = 3)
    (hsourceFinite : source < qubitDim (oneTermRobinTotalQubits p))
    (hsource : bandedSparseAccessPaperGlobalSlotSource p source = true) :
    bandedSparseAccessPaperPostSwapPreimageCandidateChecks p source = true := by
  have hclean :
      bandedSparseAccessPaperCleanInput p source = true :=
    bandedSparseAccessPaperGlobalSlotSource_cleanInput_eq_true p source hsource
  exact bandedSparseAccessPaperPostSwapPreimageCandidateChecks_of_cleanSource
    p source hn hkappa hκbits hsourceFinite hclean

   
                                                                       

                                                                           
                                                                           
                            
  
theorem bandedSparseAccessPaperPostSwapPreimageCandidate_lt_qubitDim_of_globalSlotSource
    (p : OneTermRobinParameters)
    (source : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hn : 3 <= p.n) (hkappa : p.kappa = 7) (hκbits : clog2 p.kappa = 3)
    (hsource : bandedSparseAccessPaperGlobalSlotSource p source.val = true) :
    bandedSparseAccessPaperPostSwapPreimageCandidate p source.val <
      qubitDim (oneTermRobinTotalQubits p) := by
  have hclean :
      bandedSparseAccessPaperCleanInput p source.val = true :=
    bandedSparseAccessPaperGlobalSlotSource_cleanInput_eq_true
      p source.val hsource
  exact bandedSparseAccessPaperPostSwapPreimageCandidate_lt_qubitDim_of_cleanSource
    p source hn hkappa hκbits hclean

   
                                                                             
                   

                                                                            
                                                                        
                
  
theorem bandedSparseAccessPaperPostSwapPreimageCandidate_sparseIndex_eq
    (p : OneTermRobinParameters) (source : Nat)
    (hn : 3 <= p.n) (hκbits : clog2 p.kappa = 3) :
    (bandedSparseAccessPaperRegisters p
      (bandedSparseAccessPaperPostSwapPreimageCandidate p source)).sparseIndexValue =
      oneTermRobinGlobalSparseInverseSlot
        (bandedSparseAccessPaperRegisters p source).sparseIndexValue := by
  let regs := bandedSparseAccessPaperRegisters p source
  let post := swapOracleImage p (bandedSparseAccessPaperImage p source)
  let reverseSparse := oneTermRobinGlobalSparseInverseSlot regs.sparseIndexValue
  let cleanOD := bandedSparseAccessPaperCleanODValue p reverseSparse
  let pre := bandedSparseAccessPaperPostSwapPreimageCandidate p source
  have hreverseLt8 : reverseSparse < 8 := by
    simpa [reverseSparse] using
      oneTermRobinGlobalSparseInverseSlot_lt_eight regs.sparseIndexValue
  have hreversePow : reverseSparse < 2 ^ clog2 p.kappa := by
    rw [hκbits]
    simpa using hreverseLt8
  have hwidth : clog2 p.kappa <= p.n := by
    rw [hκbits]
    omega
  have hcleanODBound : cleanOD < (1 <<< p.n) :=
    bandedSparseAccessPaperCleanODValue_lt_two_pow_of_sparse_lt
      p hwidth hreversePow
  have hpre_eq : pre =
      bandedSparseAccessPaperSpliceODRegister p post cleanOD := by
    simp [pre, bandedSparseAccessPaperPostSwapPreimageCandidate, post,
      cleanOD, reverseSparse, regs]
  have hpreOD :
      (bandedSparseAccessPaperRegisters p pre).odRegisterValue = cleanOD := by
    rw [hpre_eq]
    exact bandedSparseAccessPaperSpliceODRegister_odRegisterValue_eq
      p post cleanOD hcleanODBound
  rw [bandedSparseAccessPaperRegisters_sparseIndexValue_eq]
  rw [hpreOD]
  simpa [reverseSparse, regs] using
    bandedSparseAccessPaperCleanODValue_sparseIndex_eq p hreversePow

   
                                                                        

                                                                          
                                                                           
                                                                            
  
theorem bandedSparseAccessPaperPostSwapPreimageCandidate_globalSlotSource_of_globalSlotSource
    (p : OneTermRobinParameters)
    (source : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hn : 3 <= p.n) (hkappa : p.kappa = 7) (hκbits : clog2 p.kappa = 3)
    (hsource : bandedSparseAccessPaperGlobalSlotSource p source.val = true) :
    bandedSparseAccessPaperGlobalSlotSource p
      (bandedSparseAccessPaperPostSwapPreimageCandidate p source.val) = true := by
  let pre := bandedSparseAccessPaperPostSwapPreimageCandidate p source.val
  have hchecks :
      bandedSparseAccessPaperPostSwapPreimageCandidateChecks p source.val = true :=
    bandedSparseAccessPaperPostSwapPreimageCandidateChecks_of_globalSlotSource
      p source.val hn hkappa hκbits source.2 hsource
  have hparts :
      (bandedSparseAccessPaperImage p pre ==
          swapOracleImage p (bandedSparseAccessPaperImage p source.val)) = true ∧
        bandedSparseAccessPaperCleanInput p pre = true ∧
        bandedSparseAccessPaperAddressInRange p pre = true := by
    simpa [bandedSparseAccessPaperPostSwapPreimageCandidateChecks, pre,
      Bool.and_assoc] using hchecks
  have hclean : bandedSparseAccessPaperCleanInput p pre = true := hparts.2.1
  have hsourceSparseLt7 :
      (bandedSparseAccessPaperRegisters p source.val).sparseIndexValue < 7 := by
    have hs :=
      bandedSparseAccessPaperGlobalSlotSource_sparseIndex_lt_kappa
        p source.val hsource
    rwa [hkappa] at hs
  have hreverseLtKappa :
      oneTermRobinGlobalSparseInverseSlot
          (bandedSparseAccessPaperRegisters p source.val).sparseIndexValue <
        p.kappa := by
    rw [hkappa]
    exact oneTermRobinGlobalSparseInverseSlot_lt_seven hsourceSparseLt7
  have hpreSparse :
      (bandedSparseAccessPaperRegisters p pre).sparseIndexValue < p.kappa := by
    rw [bandedSparseAccessPaperPostSwapPreimageCandidate_sparseIndex_eq
      p source.val hn hκbits]
    exact hreverseLtKappa
  simp [bandedSparseAccessPaperGlobalSlotSource,
    bandedSparseAccessPaperSparseIndexInKappa, hclean, hpreSparse, pre]

   
                                                                             

                                                                             
                                                                              
                                                                          
                     
  
theorem bandedSparseAccessPaperPostSwapPreimageCandidate_unique_on_globalSlotSource
    (p : OneTermRobinParameters)
    (source pre : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hn : 3 <= p.n) (hkappa : p.kappa = 7) (hκbits : clog2 p.kappa = 3)
    (hsource : bandedSparseAccessPaperGlobalSlotSource p source.val = true)
    (hpreSource : bandedSparseAccessPaperGlobalSlotSource p pre.val = true)
    (hpreImage :
      bandedSparseAccessPaperImage p pre.val =
        swapOracleImage p (bandedSparseAccessPaperImage p source.val)) :
    pre.val =
      bandedSparseAccessPaperPostSwapPreimageCandidate p source.val := by
  let candVal := bandedSparseAccessPaperPostSwapPreimageCandidate p source.val
  have hcandRange : candVal < qubitDim (oneTermRobinTotalQubits p) := by
    simpa [candVal] using
      bandedSparseAccessPaperPostSwapPreimageCandidate_lt_qubitDim_of_globalSlotSource
        p source hn hkappa hκbits hsource
  let cand : Fin (qubitDim (oneTermRobinTotalQubits p)) :=
    ⟨candVal, hcandRange⟩
  have hcandSource :
      bandedSparseAccessPaperGlobalSlotSource p cand.val = true := by
    simpa [cand, candVal] using
      bandedSparseAccessPaperPostSwapPreimageCandidate_globalSlotSource_of_globalSlotSource
        p source hn hkappa hκbits hsource
  have hchecks :
      bandedSparseAccessPaperPostSwapPreimageCandidateChecks p source.val = true :=
    bandedSparseAccessPaperPostSwapPreimageCandidateChecks_of_globalSlotSource
      p source.val hn hkappa hκbits source.2 hsource
  have hparts :
      (bandedSparseAccessPaperImage p candVal ==
          swapOracleImage p (bandedSparseAccessPaperImage p source.val)) = true ∧
        bandedSparseAccessPaperCleanInput p candVal = true ∧
        bandedSparseAccessPaperAddressInRange p candVal = true := by
    simpa [bandedSparseAccessPaperPostSwapPreimageCandidateChecks, candVal,
      Bool.and_assoc] using hchecks
  have hcandImage :
      bandedSparseAccessPaperImage p cand.val =
        swapOracleImage p (bandedSparseAccessPaperImage p source.val) := by
    simpa [cand, candVal] using beq_iff_eq.mp hparts.1
  have himage :
      bandedSparseAccessPaperImage p pre.val =
        bandedSparseAccessPaperImage p cand.val := by
    rw [hpreImage, hcandImage]
  have hfin :
      pre = cand :=
    bandedSparseAccessPaperImage_injective_on_globalSlotSource
      p pre cand hn hkappa hκbits hpreSource hcandSource himage
  simpa [cand, candVal] using congrArg Fin.val hfin

   
                                                                             

                                                                            
                                                                        
                                          
                                            
                                                                             
                                                                             
                               
  
structure BandedSparseAccessGlobalSlotInverseOnRangeContract where
  sourceAnchor : String
  sourcePredicate : String
  imageFunction : String
  preimageCandidate : String
  sourceIndex : Nat
  sourceRegisters : BandedSparseAccessPaperRegisters
  sourceInGlobalDomain : Bool
  postSwapImageIndex : Nat
  candidatePreimageIndex : Nat
  candidateChecks : Bool
  inverseOnRange : ObligationRecord
  uniquePreimage : ObligationRecord
  imageInjectiveOnGlobalSource : ObligationRecord
  daggerCleanup : ObligationRecord
  unitaryExtension : ObligationRecord
deriving Repr, DecidableEq

   
                                                                               

                                                                        
                                                             
  
def bandedSparseAccessGlobalSlotInverseOnRangeContract
    (p : OneTermRobinParameters) (source : Nat) :
    BandedSparseAccessGlobalSlotInverseOnRangeContract where
  sourceAnchor := "Guseynov-Huang-Liu 2025, Lemma 1 and Fig. 1-term Robin, arXiv:2506.20478"
  sourcePredicate := "bandedSparseAccessPaperGlobalSlotSource"
  imageFunction := "bandedSparseAccessPaperImage"
  preimageCandidate := "bandedSparseAccessPaperPostSwapPreimageCandidate"
  sourceIndex := source
  sourceRegisters := bandedSparseAccessPaperRegisters p source
  sourceInGlobalDomain := bandedSparseAccessPaperGlobalSlotSource p source
  postSwapImageIndex := swapOracleImage p (bandedSparseAccessPaperImage p source)
  candidatePreimageIndex :=
    bandedSparseAccessPaperPostSwapPreimageCandidate p source
  candidateChecks :=
    bandedSparseAccessPaperPostSwapPreimageCandidateChecks p source
  inverseOnRange := {
    description := "the active global-slot preimage candidate maps by O_D^BS to the post-SWAP column on every global-source input"
    source := "QBE-AUTO-002 O_D^BS global-source inverse-on-range interface"
    proved := false
  }
  uniquePreimage := {
    description := "the active global-slot preimage candidate is the unique clean preimage of the post-SWAP column"
    source := "QBE-AUTO-002 O_D^BS global-source inverse-on-range interface"
    proved := false
  }
  imageInjectiveOnGlobalSource := {
    description := "bandedSparseAccessPaperImage is injective on the active global-slot clean source domain"
    source := "QBE-AUTO-002 O_D^BS global-source inverse-on-range interface"
    proved := false
  }
  daggerCleanup := {
    description := "(O_D^BS)^dagger cleans the active global-slot source image after SWAP"
    source := "Guseynov-Huang-Liu 2025, Fig. 1-term Robin and Lemma 1, arXiv:2506.20478"
    proved := false
  }
  unitaryExtension := {
    description := "the active global-slot image route extends to a full O_D^BS unitary"
    source := "Guseynov-Huang-Liu 2025, Lemma 1, arXiv:2506.20478"
    proved := false
  }

                                                                                 
theorem bandedSparseAccessGlobalSlotInverseOnRangeContract_flags_false
    (p : OneTermRobinParameters) (source : Nat) :
    (bandedSparseAccessGlobalSlotInverseOnRangeContract p source).inverseOnRange.proved =
        false ∧
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p source).uniquePreimage.proved =
        false ∧
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p source).imageInjectiveOnGlobalSource.proved =
        false ∧
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p source).daggerCleanup.proved =
        false ∧
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p source).unitaryExtension.proved =
        false := by
  simp [bandedSparseAccessGlobalSlotInverseOnRangeContract]

   
                                                                               
                           

                                                                       
                                                   
  
theorem bandedSparseAccessGlobalSlotInverseOnRangeContract_of_globalSlotSource
    (p : OneTermRobinParameters) (source : Nat)
    (hn : 3 <= p.n) (hkappa : p.kappa = 7) (hκbits : clog2 p.kappa = 3)
    (hsourceFinite : source < qubitDim (oneTermRobinTotalQubits p))
    (hsource : bandedSparseAccessPaperGlobalSlotSource p source = true) :
    (bandedSparseAccessGlobalSlotInverseOnRangeContract p source).sourceInGlobalDomain =
        true ∧
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p source).candidateChecks =
        true ∧
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p source).inverseOnRange.proved =
        false ∧
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p source).uniquePreimage.proved =
        false ∧
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p source).imageInjectiveOnGlobalSource.proved =
        false ∧
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p source).daggerCleanup.proved =
        false ∧
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p source).unitaryExtension.proved =
        false := by
  have hchecks :
      bandedSparseAccessPaperPostSwapPreimageCandidateChecks p source = true :=
    bandedSparseAccessPaperPostSwapPreimageCandidateChecks_of_globalSlotSource
      p source hn hkappa hκbits hsourceFinite hsource
  simp [bandedSparseAccessGlobalSlotInverseOnRangeContract, hsource, hchecks]

   
                                                                              
                                      

                                                                             
                                                                           
                                                                               
                                                                        
                    
  
theorem bandedSparseAccessGlobalSlotInverseOnRangeContract_uniquePreimageBridge
    (p : OneTermRobinParameters)
    (source pre : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hn : 3 <= p.n) (hkappa : p.kappa = 7) (hκbits : clog2 p.kappa = 3)
    (hsource : bandedSparseAccessPaperGlobalSlotSource p source.val = true)
    (hpreSource : bandedSparseAccessPaperGlobalSlotSource p pre.val = true)
    (hpreImage :
      bandedSparseAccessPaperImage p pre.val =
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).postSwapImageIndex) :
    pre.val =
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).candidatePreimageIndex ∧
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).sourceInGlobalDomain = true ∧
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).candidateChecks = true ∧
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).inverseOnRange.proved = false ∧
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).uniquePreimage.proved = false ∧
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).imageInjectiveOnGlobalSource.proved = false ∧
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).daggerCleanup.proved = false ∧
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).unitaryExtension.proved = false := by
  have hpreImageTarget :
      bandedSparseAccessPaperImage p pre.val =
        swapOracleImage p (bandedSparseAccessPaperImage p source.val) := by
    simpa [bandedSparseAccessGlobalSlotInverseOnRangeContract] using hpreImage
  have hunique :
      pre.val =
        bandedSparseAccessPaperPostSwapPreimageCandidate p source.val :=
    bandedSparseAccessPaperPostSwapPreimageCandidate_unique_on_globalSlotSource
      p source pre hn hkappa hκbits hsource hpreSource hpreImageTarget
  have hcontract :
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).sourceInGlobalDomain = true ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).candidateChecks = true ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).inverseOnRange.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).uniquePreimage.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).imageInjectiveOnGlobalSource.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).daggerCleanup.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).unitaryExtension.proved = false :=
    bandedSparseAccessGlobalSlotInverseOnRangeContract_of_globalSlotSource
      p source.val hn hkappa hκbits source.2 hsource
  exact ⟨by
    simpa [bandedSparseAccessGlobalSlotInverseOnRangeContract] using hunique,
    hcontract⟩

   
                                                                          
                       

                                                                          
                                                          
                                                                              
                                                                   
                                                   
  
theorem bandedSparseAccessGlobalSlotInverseOnRangeContract_daggerCleanupBridge
    (p : OneTermRobinParameters)
    (source : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hn : 3 <= p.n) (hkappa : p.kappa = 7) (hκbits : clog2 p.kappa = 3)
    (hsource : bandedSparseAccessPaperGlobalSlotSource p source.val = true) :
    ∃ (post pre : Fin (qubitDim (oneTermRobinTotalQubits p))),
      BandedSparseAccessPostSwapCleanup p source post pre ∧
        post.val =
          (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).postSwapImageIndex ∧
        pre.val =
          (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).candidatePreimageIndex ∧
        (oneTermRobinGate_O_D_BS_dagger p).matrix pre post = Coeff.rat 1 ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).candidateChecks = true ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).daggerCleanup.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).unitaryExtension.proved = false := by
  let post : Fin (qubitDim (oneTermRobinTotalQubits p)) :=
    ⟨swapOracleImage p (bandedSparseAccessPaperImage p source.val), by
      have htwo : 2 ≤ p.n := by omega
      have haddrSource :
          bandedSparseAccessPaperAddress p source.val < (1 <<< p.n) := by
        have h := bandedSparseAccessPaperAddress_lt_gridSize_of_two_le
          p source.val htwo
        simpa [gridSize, Nat.one_shiftLeft] using h
      exact bandedSparseAccessPaperPostSwapImage_lt_qubitDim_of_address_lt
        p source haddrSource⟩
  let pre : Fin (qubitDim (oneTermRobinTotalQubits p)) :=
    ⟨bandedSparseAccessPaperPostSwapPreimageCandidate p source.val,
      bandedSparseAccessPaperPostSwapPreimageCandidate_lt_qubitDim_of_globalSlotSource
        p source hn hkappa hκbits hsource⟩
  have hcleanup :
      BandedSparseAccessPostSwapCleanup p source post pre := by
    simpa [post, pre] using
      bandedSparseAccessPostSwapCleanup_of_globalSlotSourceCandidate_noRange
        p source hn hkappa hκbits hsource
  have hcontract :
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).sourceInGlobalDomain = true ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).candidateChecks = true ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).inverseOnRange.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).uniquePreimage.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).imageInjectiveOnGlobalSource.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).daggerCleanup.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).unitaryExtension.proved = false :=
    bandedSparseAccessGlobalSlotInverseOnRangeContract_of_globalSlotSource
      p source.val hn hkappa hκbits source.2 hsource
  refine ⟨post, pre, hcleanup, ?_, ?_, hcleanup.daggerEntry, ?_, ?_, ?_⟩
  · rfl
  · rfl
  · exact hcontract.2.1
  · exact hcontract.2.2.2.2.2.1
  · exact hcontract.2.2.2.2.2.2

   
                                                                        

                                                                      
                                                                          
                                                                        
                                                                               
                                                                             
                              
  
theorem bandedSparseAccessGlobalSlotInverseOnRangeContract_cleanupContractMap
    (p : OneTermRobinParameters)
    (source : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hn : 3 <= p.n) (hkappa : p.kappa = 7) (hκbits : clog2 p.kappa = 3)
    (hsource : bandedSparseAccessPaperGlobalSlotSource p source.val = true) :
    ∃ (post pre : Fin (qubitDim (oneTermRobinTotalQubits p))),
      BandedSparseAccessPostSwapCleanup p source post pre ∧
        post.val =
          (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).postSwapImageIndex ∧
        pre.val =
          (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).candidatePreimageIndex ∧
        bandedSparseAccessPaperGlobalSlotSource p pre.val = true ∧
        (∀ (pre' : Fin (qubitDim (oneTermRobinTotalQubits p))),
          bandedSparseAccessPaperGlobalSlotSource p pre'.val = true →
          bandedSparseAccessPaperImage p pre'.val = post.val →
          pre'.val = pre.val) ∧
        (oneTermRobinGate_O_D_BS_dagger p).matrix pre post = Coeff.rat 1 ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).candidateChecks = true ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).inverseOnRange.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).uniquePreimage.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).imageInjectiveOnGlobalSource.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).daggerCleanup.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).unitaryExtension.proved = false := by
  rcases bandedSparseAccessGlobalSlotInverseOnRangeContract_daggerCleanupBridge
      p source hn hkappa hκbits hsource with
    ⟨post, pre, hcleanup, hpost, hpre, hentry, hchecks, hdaggerFlag,
      hunitaryFlag⟩
  have hcontract :
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).sourceInGlobalDomain = true ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).candidateChecks = true ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).inverseOnRange.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).uniquePreimage.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).imageInjectiveOnGlobalSource.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).daggerCleanup.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).unitaryExtension.proved = false :=
    bandedSparseAccessGlobalSlotInverseOnRangeContract_of_globalSlotSource
      p source.val hn hkappa hκbits source.2 hsource
  have hpreGlobalCandidate :
      bandedSparseAccessPaperGlobalSlotSource p
        (bandedSparseAccessPaperPostSwapPreimageCandidate p source.val) = true :=
    bandedSparseAccessPaperPostSwapPreimageCandidate_globalSlotSource_of_globalSlotSource
      p source hn hkappa hκbits hsource
  have hpreSource :
      bandedSparseAccessPaperGlobalSlotSource p pre.val = true := by
    rw [hpre]
    simpa [bandedSparseAccessGlobalSlotInverseOnRangeContract]
      using hpreGlobalCandidate
  have hunique :
      ∀ (pre' : Fin (qubitDim (oneTermRobinTotalQubits p))),
        bandedSparseAccessPaperGlobalSlotSource p pre'.val = true →
        bandedSparseAccessPaperImage p pre'.val = post.val →
        pre'.val = pre.val := by
    intro pre' hpreSource' hpreImage'
    have hpreImageContract :
        bandedSparseAccessPaperImage p pre'.val =
          (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).postSwapImageIndex :=
      hpreImage'.trans hpost
    have hbridge :=
      bandedSparseAccessGlobalSlotInverseOnRangeContract_uniquePreimageBridge
        p source pre' hn hkappa hκbits hsource hpreSource'
        hpreImageContract
    exact hbridge.1.trans hpre.symm
  refine ⟨post, pre, hcleanup, hpost, hpre, hpreSource, hunique, hentry,
    hchecks, ?_, ?_, ?_, hdaggerFlag, hunitaryFlag⟩
  · exact hcontract.2.2.1
  · exact hcontract.2.2.2.1
  · exact hcontract.2.2.2.2.1

   
                                                                      
               

                                                           
                                                                             
                                                                         
                                                                              
                                                       
  
theorem defaultBandedSparseAccessPaperContract_cleanupRouteBridge
    (p : OneTermRobinParameters)
    (source : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hn : 3 <= p.n) (hkappa : p.kappa = 7) (hκbits : clog2 p.kappa = 3)
    (hsource : bandedSparseAccessPaperGlobalSlotSource p source.val = true) :
    ∃ (post pre : Fin (qubitDim (oneTermRobinTotalQubits p))),
      BandedSparseAccessPostSwapCleanup p source post pre ∧
        post.val =
          (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).postSwapImageIndex ∧
        pre.val =
          (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).candidatePreimageIndex ∧
        bandedSparseAccessPaperGlobalSlotSource p pre.val = true ∧
        (∀ (pre' : Fin (qubitDim (oneTermRobinTotalQubits p))),
          bandedSparseAccessPaperGlobalSlotSource p pre'.val = true →
          bandedSparseAccessPaperImage p pre'.val = post.val →
          pre'.val = pre.val) ∧
        (oneTermRobinGate_O_D_BS_dagger p).matrix pre post = Coeff.rat 1 ∧
        (defaultBandedSparseAccessPaperContract p).daggerCleanup.proved =
          false ∧
        (defaultBandedSparseAccessPaperContract p).unitaryExtension.proved =
          false ∧
        (oneTermRobinGate_O_D_BS p).unitary.proved = false ∧
        (oneTermRobinGate_O_D_BS_dagger p).unitary.proved = false := by
  rcases bandedSparseAccessGlobalSlotInverseOnRangeContract_cleanupContractMap
      p source hn hkappa hκbits hsource with
    ⟨post, pre, hcleanup, hpost, hpre, hpreSource, hunique, hentry,
      _hchecks, _hinverseFlag, _huniqueFlag, _himageFlag, _hdaggerFlag,
      _hunitaryFlag⟩
  refine ⟨post, pre, hcleanup, hpost, hpre, hpreSource, hunique, hentry,
    ?_, ?_, ?_, ?_⟩
  · rfl
  · rfl
  · rfl
  · rfl

   
                                                                              

                                                                            
                                                                              
                                                                             
                                                                              
  
theorem bandedSparseAccessGlobalSlotInverseOnRangeContract_daggerOffCandidate_zero
    (p : OneTermRobinParameters)
    (source other post : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hn : 3 <= p.n) (hkappa : p.kappa = 7) (hκbits : clog2 p.kappa = 3)
    (hsource : bandedSparseAccessPaperGlobalSlotSource p source.val = true)
    (hotherSource : bandedSparseAccessPaperGlobalSlotSource p other.val = true)
    (hpost :
      post.val =
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).postSwapImageIndex)
    (hne :
      other.val ≠
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).candidatePreimageIndex) :
    (oneTermRobinGate_O_D_BS_dagger p).matrix other post = Coeff.rat 0 ∧
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).daggerCleanup.proved = false ∧
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).unitaryExtension.proved = false := by
  have hnotImage :
      ¬ post.val = bandedSparseAccessPaperImage p other.val := by
    intro himage
    have hotherImage :
        bandedSparseAccessPaperImage p other.val =
          (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).postSwapImageIndex :=
      himage.symm.trans hpost
    have hbridge :=
      bandedSparseAccessGlobalSlotInverseOnRangeContract_uniquePreimageBridge
        p source other hn hkappa hκbits hsource hotherSource hotherImage
    exact hne hbridge.1
  have hentry :
      (oneTermRobinGate_O_D_BS_dagger p).matrix other post = Coeff.rat 0 := by
    simp [oneTermRobinGate_O_D_BS_dagger,
      bandedSparseAccessPaperDaggerMatrix, hnotImage]
  have hcontract :
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).sourceInGlobalDomain = true ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).candidateChecks = true ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).inverseOnRange.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).uniquePreimage.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).imageInjectiveOnGlobalSource.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).daggerCleanup.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).unitaryExtension.proved = false :=
    bandedSparseAccessGlobalSlotInverseOnRangeContract_of_globalSlotSource
      p source.val hn hkappa hκbits source.2 hsource
  exact ⟨hentry, hcontract.2.2.2.2.2.1, hcontract.2.2.2.2.2.2⟩

   
                                                                         

                                                                            
                                                                              
                                                                            
                                                                           
            
  
theorem bandedSparseAccessGlobalSlotInverseOnRangeContract_restrictedDaggerColumnCleanup
    (p : OneTermRobinParameters)
    (source : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hn : 3 <= p.n) (hkappa : p.kappa = 7) (hκbits : clog2 p.kappa = 3)
    (hsource : bandedSparseAccessPaperGlobalSlotSource p source.val = true) :
    ∃ (post pre : Fin (qubitDim (oneTermRobinTotalQubits p))),
      BandedSparseAccessPostSwapCleanup p source post pre ∧
        post.val =
          (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).postSwapImageIndex ∧
        pre.val =
          (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).candidatePreimageIndex ∧
        bandedSparseAccessPaperGlobalSlotSource p pre.val = true ∧
        (oneTermRobinGate_O_D_BS_dagger p).matrix pre post = Coeff.rat 1 ∧
        (∀ (other : Fin (qubitDim (oneTermRobinTotalQubits p))),
          bandedSparseAccessPaperGlobalSlotSource p other.val = true →
          other.val ≠ pre.val →
          (oneTermRobinGate_O_D_BS_dagger p).matrix other post =
            Coeff.rat 0) ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).daggerCleanup.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).unitaryExtension.proved = false ∧
        (defaultBandedSparseAccessPaperContract p).daggerCleanup.proved =
          false ∧
        (defaultBandedSparseAccessPaperContract p).unitaryExtension.proved =
          false ∧
        (oneTermRobinGate_O_D_BS p).unitary.proved = false ∧
        (oneTermRobinGate_O_D_BS_dagger p).unitary.proved = false ∧
        (defaultOneTermRobinTheoremData p).obligations.circuitUnitary.proved =
          false ∧
        (defaultOneTermRobinTheoremData p).obligations.blockExtraction.proved =
          false := by
  rcases defaultBandedSparseAccessPaperContract_cleanupRouteBridge
      p source hn hkappa hκbits hsource with
    ⟨post, pre, hcleanup, hpost, hpre, hpreSource, _hunique, hentry,
      hpaperCleanupFlag, hpaperUnitaryFlag, hforwardUnitaryFlag,
      hdaggerUnitaryFlag⟩
  have hcontract :
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).sourceInGlobalDomain = true ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).candidateChecks = true ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).inverseOnRange.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).uniquePreimage.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).imageInjectiveOnGlobalSource.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).daggerCleanup.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).unitaryExtension.proved = false :=
    bandedSparseAccessGlobalSlotInverseOnRangeContract_of_globalSlotSource
      p source.val hn hkappa hκbits source.2 hsource
  have hzero :
      ∀ (other : Fin (qubitDim (oneTermRobinTotalQubits p))),
        bandedSparseAccessPaperGlobalSlotSource p other.val = true →
        other.val ≠ pre.val →
        (oneTermRobinGate_O_D_BS_dagger p).matrix other post =
          Coeff.rat 0 := by
    intro other hotherSource hotherNePre
    have hotherNeContract :
        other.val ≠
          (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).candidatePreimageIndex := by
      intro hotherEqContract
      exact hotherNePre (hotherEqContract.trans hpre.symm)
    exact
      (bandedSparseAccessGlobalSlotInverseOnRangeContract_daggerOffCandidate_zero
        p source other post hn hkappa hκbits hsource hotherSource hpost
        hotherNeContract).1
  refine ⟨post, pre, hcleanup, hpost, hpre, hpreSource, hentry, hzero,
    ?_, ?_, hpaperCleanupFlag, hpaperUnitaryFlag, hforwardUnitaryFlag,
    hdaggerUnitaryFlag, ?_, ?_⟩
  · exact hcontract.2.2.2.2.2.1
  · exact hcontract.2.2.2.2.2.2
  · rfl
  · rfl

   
                                                             

                                                       
                                                                                   
                                                                    
                                                                       
  
theorem bandedSparseAccessGlobalSlotInverseOnRangeContract_restrictedDaggerColumnIndicator
    (p : OneTermRobinParameters)
    (source : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (hn : 3 <= p.n) (hkappa : p.kappa = 7) (hκbits : clog2 p.kappa = 3)
    (hsource : bandedSparseAccessPaperGlobalSlotSource p source.val = true) :
    ∃ (post pre : Fin (qubitDim (oneTermRobinTotalQubits p))),
      BandedSparseAccessPostSwapCleanup p source post pre ∧
        post.val =
          (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).postSwapImageIndex ∧
        pre.val =
          (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).candidatePreimageIndex ∧
        bandedSparseAccessPaperGlobalSlotSource p pre.val = true ∧
        (∀ (other : Fin (qubitDim (oneTermRobinTotalQubits p))),
          bandedSparseAccessPaperGlobalSlotSource p other.val = true →
          (oneTermRobinGate_O_D_BS_dagger p).matrix other post =
            if other.val = pre.val then Coeff.rat 1 else Coeff.rat 0) ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).inverseOnRange.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).uniquePreimage.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).imageInjectiveOnGlobalSource.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).daggerCleanup.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).unitaryExtension.proved = false ∧
        (defaultBandedSparseAccessPaperContract p).daggerCleanup.proved =
          false ∧
        (defaultBandedSparseAccessPaperContract p).unitaryExtension.proved =
          false ∧
        (oneTermRobinGate_O_D_BS p).unitary.proved = false ∧
        (oneTermRobinGate_O_D_BS_dagger p).unitary.proved = false ∧
        (defaultOneTermRobinTheoremData p).obligations.circuitUnitary.proved =
          false ∧
        (defaultOneTermRobinTheoremData p).obligations.blockExtraction.proved =
          false := by
  rcases bandedSparseAccessGlobalSlotInverseOnRangeContract_restrictedDaggerColumnCleanup
      p source hn hkappa hκbits hsource with
    ⟨post, pre, hcleanup, hpost, hpre, hpreSource, hentry, hzero,
      hcontractCleanupFlag, hcontractUnitaryFlag, hpaperCleanupFlag,
      hpaperUnitaryFlag, hforwardUnitaryFlag, hdaggerUnitaryFlag,
      htheoremCircuitFlag, htheoremBlockFlag⟩
  have hcontract :
      (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).sourceInGlobalDomain = true ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).candidateChecks = true ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).inverseOnRange.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).uniquePreimage.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).imageInjectiveOnGlobalSource.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).daggerCleanup.proved = false ∧
        (bandedSparseAccessGlobalSlotInverseOnRangeContract p
          source.val).unitaryExtension.proved = false :=
    bandedSparseAccessGlobalSlotInverseOnRangeContract_of_globalSlotSource
      p source.val hn hkappa hκbits source.2 hsource
  have hindicator :
      ∀ (other : Fin (qubitDim (oneTermRobinTotalQubits p))),
        bandedSparseAccessPaperGlobalSlotSource p other.val = true →
        (oneTermRobinGate_O_D_BS_dagger p).matrix other post =
          if other.val = pre.val then Coeff.rat 1 else Coeff.rat 0 := by
    intro other hotherSource
    by_cases hotherPre : other.val = pre.val
    · have hotherEq : other = pre := Fin.ext hotherPre
      subst other
      simp [hentry]
    · exact (by
        simp [hotherPre, hzero other hotherSource hotherPre])
  refine ⟨post, pre, hcleanup, hpost, hpre, hpreSource, hindicator,
    ?_, ?_, ?_, hcontractCleanupFlag, hcontractUnitaryFlag, hpaperCleanupFlag,
    hpaperUnitaryFlag, hforwardUnitaryFlag, hdaggerUnitaryFlag,
    htheoremCircuitFlag, htheoremBlockFlag⟩
  · exact hcontract.2.2.1
  · exact hcontract.2.2.2.1
  · exact hcontract.2.2.2.2.1

   
                                                            

                                                                              
                                                                      
  
inductive BandedSparseAccessCleanupScope where
  | activeGlobalSource
  | fullCleanDomain
  | fullSpace
deriving Repr, DecidableEq

   
                                                                    

                                                                               
                                                                              
                                                                          
                                                                        
                                                                
                
  
structure BandedSparseAccessCleanupScopeDecision where
  sourceAnchor : String
  selectedScope : BandedSparseAccessCleanupScope
  selectedPredicate : String
  selectedEvidence : String
  fullCleanDomainSelected : Bool
  fullSpaceSelected : Bool
  semanticCleanupPromotionAllowed : Bool
  paperContractCleanup : ObligationRecord
  fullCleanDomainCleanup : ObligationRecord
  fullSpaceUnitaryExtension : ObligationRecord
deriving Repr, DecidableEq

   
                                                                            

                                                                          
                                                                               
                                                                              
  
def bandedSparseAccessCleanupScopeDecision
    (p : OneTermRobinParameters) :
    BandedSparseAccessCleanupScopeDecision where
  sourceAnchor := "Guseynov-Huang-Liu 2025, Lemma 1 and Fig. 1-term Robin, arXiv:2506.20478"
  selectedScope := BandedSparseAccessCleanupScope.activeGlobalSource
  selectedPredicate := "bandedSparseAccessPaperGlobalSlotSource"
  selectedEvidence :=
    "bandedSparseAccessGlobalSlotInverseOnRangeContract_restrictedDaggerColumnIndicator"
  fullCleanDomainSelected := false
  fullSpaceSelected := false
  semanticCleanupPromotionAllowed := false
  paperContractCleanup := (defaultBandedSparseAccessPaperContract p).daggerCleanup
  fullCleanDomainCleanup :=
    (bandedSparseAccessFullCleanDomainExtensionContract p).daggerCleanup
  fullSpaceUnitaryExtension :=
    (defaultBandedSparseAccessPaperContract p).unitaryExtension

   
                                                                             
                                                                         
  
theorem bandedSparseAccessCleanupScopeDecision_activeGlobalSource
    (p : OneTermRobinParameters) :
    (bandedSparseAccessCleanupScopeDecision p).selectedScope =
        BandedSparseAccessCleanupScope.activeGlobalSource ∧
      (bandedSparseAccessCleanupScopeDecision p).selectedPredicate =
        "bandedSparseAccessPaperGlobalSlotSource" ∧
      (bandedSparseAccessCleanupScopeDecision p).selectedEvidence =
        "bandedSparseAccessGlobalSlotInverseOnRangeContract_restrictedDaggerColumnIndicator" ∧
      (bandedSparseAccessCleanupScopeDecision p).fullCleanDomainSelected =
        false ∧
      (bandedSparseAccessCleanupScopeDecision p).fullSpaceSelected = false ∧
      (bandedSparseAccessCleanupScopeDecision p).semanticCleanupPromotionAllowed =
        false ∧
      (bandedSparseAccessCleanupScopeDecision p).paperContractCleanup.proved =
        false ∧
      (bandedSparseAccessCleanupScopeDecision p).fullCleanDomainCleanup.proved =
        false ∧
      (bandedSparseAccessCleanupScopeDecision p).fullSpaceUnitaryExtension.proved =
        false := by
  simp [bandedSparseAccessCleanupScopeDecision,
    defaultBandedSparseAccessPaperContract,
    bandedSparseAccessFullCleanDomainExtensionContract]

   
                                                                      
                                                   

                                                                              
                                                                         
                                                               
  
theorem bandedSparseAccessCleanupScopeDecision_priorPDESourceTranscriptGuard
    (p : OneTermRobinParameters) :
    (bandedSparseAccessCleanupScopeDecision p).selectedScope =
        BandedSparseAccessCleanupScope.activeGlobalSource ∧
      (bandedSparseAccessCleanupScopeDecision p).fullSpaceSelected = false ∧
      (bandedSparseAccessCleanupScopeDecision p).fullSpaceUnitaryExtension.proved =
        false ∧
      bandedSparseAccessPriorPDESourceContract.oracleEquation =
        "O_A^BS |0>^(n-l)|s>^l|i>^n = |r_si>^n|i>^n" ∧
      bandedSparseAccessPriorPDESourceContract.resourceClaim.proved = false ∧
      bandedSparseAccessPriorPDESourceContract.robinUnusedBranchImageRule =
        none ∧
      bandedSparseAccessPriorPDESourceContract.closesUnusedZeroBranchExtension =
        false ∧
      bandedSparseAccessPriorPDESourceContract.lowerProofSearchAllowed =
        false ∧
      (defaultBandedSparseAccessPaperContract p).unitaryExtension.proved =
        false := by
  simp [bandedSparseAccessCleanupScopeDecision,
    defaultBandedSparseAccessPaperContract,
    bandedSparseAccessPriorPDESourceContract]

   
                                                                               

                                                                          
                                                                          
                                                                              
                                                                 
  
theorem bandedSparseAccessCleanupScopeDecision_fullCleanDomainImageRuleBlocked
    (p : OneTermRobinParameters) (j : Nat) :
    (bandedSparseAccessCleanupScopeDecision p).selectedScope =
        BandedSparseAccessCleanupScope.activeGlobalSource ∧
      (bandedSparseAccessCleanupScopeDecision p).fullCleanDomainSelected =
        false ∧
      (bandedSparseAccessCleanupScopeDecision p).semanticCleanupPromotionAllowed =
        false ∧
      (bandedSparseAccessCleanupScopeDecision p).fullCleanDomainCleanup.proved =
        false ∧
      bandedSparseAccessUnusedZeroBranchSourceDecision.lowerProofSearchAllowed =
        false ∧
      (bandedSparseAccessUnusedBranchImageRuleContract p j).proposedImageIndex =
        none ∧
      ((bandedSparseAccessFullCleanDomainExtensionContract p).unusedBranchImageRuleContract
        j).proposedImageIndex = none ∧
      ((bandedSparseAccessFullCleanDomainExtensionContract p).unusedBranchImageRuleContract
        j).imageSpecified.proved = false ∧
      (bandedSparseAccessFullCleanDomainExtensionContract p).unusedBranchImageSpecified.proved =
        false ∧
      (bandedSparseAccessFullCleanDomainExtensionContract p).fullCleanDomainInjective.proved =
        false ∧
      (bandedSparseAccessFullCleanDomainExtensionContract p).daggerCleanup.proved =
        false ∧
      (bandedSparseAccessFullCleanDomainExtensionContract p).unitaryExtension.proved =
        false := by
  simp [bandedSparseAccessCleanupScopeDecision,
    bandedSparseAccessUnusedZeroBranchSourceDecision,
    bandedSparseAccessUnusedBranchImageRuleContract,
    bandedSparseAccessFullCleanDomainExtensionContract]

   
                                                                                 

                                                                             
                                                                           
                                                                      
                                           
  
theorem defaultBandedSparseAccessPaperContract_cleanupRouteBridge_boundaryColumn_n3 :
    let p : OneTermRobinParameters :=
      { n := 3, kappa := 7, functionPieces := 1, polynomialDegreeCost := 1 }
    let source : Fin (qubitDim (oneTermRobinTotalQubits p)) :=
      ⟨48, by native_decide⟩
    ∃ (post pre : Fin (qubitDim (oneTermRobinTotalQubits p))),
      BandedSparseAccessPostSwapCleanup p source post pre ∧
        post.val =
          (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).postSwapImageIndex ∧
        pre.val =
          (bandedSparseAccessGlobalSlotInverseOnRangeContract p
            source.val).candidatePreimageIndex ∧
        bandedSparseAccessPaperGlobalSlotSource p source.val = true ∧
        bandedSparseAccessPaperValidCleanSource p source.val = false ∧
        bandedSparseAccessPaperGlobalSlotSource p pre.val = true ∧
        (∀ (pre' : Fin (qubitDim (oneTermRobinTotalQubits p))),
          bandedSparseAccessPaperGlobalSlotSource p pre'.val = true →
          bandedSparseAccessPaperImage p pre'.val = post.val →
          pre'.val = pre.val) ∧
        (oneTermRobinGate_O_D_BS_dagger p).matrix pre post = Coeff.rat 1 ∧
        (defaultBandedSparseAccessPaperContract p).daggerCleanup.proved =
          false ∧
        (defaultBandedSparseAccessPaperContract p).unitaryExtension.proved =
          false ∧
        (oneTermRobinGate_O_D_BS p).unitary.proved = false ∧
        (oneTermRobinGate_O_D_BS_dagger p).unitary.proved = false := by
  let p : OneTermRobinParameters :=
    { n := 3, kappa := 7, functionPieces := 1, polynomialDegreeCost := 1 }
  let source : Fin (qubitDim (oneTermRobinTotalQubits p)) :=
    ⟨48, by native_decide⟩
  have hsource :
      bandedSparseAccessPaperGlobalSlotSource p source.val = true := by
    native_decide
  have hvalidSourceRejected :
      bandedSparseAccessPaperValidCleanSource p source.val = false := by
    native_decide
  rcases defaultBandedSparseAccessPaperContract_cleanupRouteBridge
      p source (by native_decide) rfl (by native_decide) hsource with
    ⟨post, pre, hcleanup, hpost, hpre, hpreSource, hunique, hentry,
      hpaperCleanupFlag, hpaperUnitaryFlag, hforwardUnitaryFlag,
      hdaggerUnitaryFlag⟩
  exact ⟨post, pre, hcleanup, hpost, hpre, hsource, hvalidSourceRejected,
    hpreSource, hunique, hentry, hpaperCleanupFlag, hpaperUnitaryFlag,
    hforwardUnitaryFlag, hdaggerUnitaryFlag⟩

   
                                                                  
  
theorem robinIndicatorBitPosition_ge (p : OneTermRobinParameters) :
    robinIndicatorBitPosition p ≥ 1 + p.n := by
  unfold robinIndicatorBitPosition defaultRobinRegisterPartition
  simp only
  omega

   
                                                                         
                                                                            
                      
theorem indicatorOracleImage_systemVal_preserved (p : OneTermRobinParameters) (j : Nat) :
    ((indicatorOracleImage p j) >>> 1) &&& ((1 <<< p.n) - 1) =
    (j >>> 1) &&& ((1 <<< p.n) - 1) := by
  show (j ^^^ (if (2 : Nat) ≤ (j >>> 1) &&& (1 <<< p.n - 1) ∧
      (j >>> 1) &&& (1 <<< p.n - 1) ≤ gridSize p.n - 3 then 1 else 0) <<<
      robinIndicatorBitPosition p) >>> 1 &&& (1 <<< p.n - 1) =
    j >>> 1 &&& (1 <<< p.n - 1)
  apply xor_shift_preserve_shift_low
  exact robinIndicatorBitPosition_ge p

   
                                                                                        
                                                                             
                      
theorem indicatorOracleImage_isBulk_preserved (p : OneTermRobinParameters) (j : Nat) :
    (if (2 : Nat) ≤ ((indicatorOracleImage p j) >>> 1) &&& ((1 <<< p.n) - 1) ∧
        ((indicatorOracleImage p j) >>> 1) &&& ((1 <<< p.n) - 1) ≤ gridSize p.n - 3
     then (1 : Nat) else 0) =
    (if (2 : Nat) ≤ (j >>> 1) &&& ((1 <<< p.n) - 1) ∧
        (j >>> 1) &&& ((1 <<< p.n) - 1) ≤ gridSize p.n - 3
     then (1 : Nat) else 0) := by
  have h := indicatorOracleImage_systemVal_preserved p j
  split <;> split <;> simp_all

   
                                                                 
                                                                               
                                                                   
                      
theorem indicatorOracleImage_self_inverse (p : OneTermRobinParameters) (j : Nat) :
    indicatorOracleImage p (indicatorOracleImage p j) = j := by
  simp only [indicatorOracleImage]
  have h_pres := indicatorOracleImage_isBulk_preserved p j
  simp only [indicatorOracleImage] at h_pres
  rw [h_pres]
  rw [Nat.xor_assoc, Nat.xor_self, Nat.xor_zero]

   
                                                                       

                                                                        
                                                                             
                                                                   
  
theorem oneTermRobinGate_U_indic_dagger_selfInverseBridge
    (p : OneTermRobinParameters) :
    (oneTermRobinGate_U_indic_dagger p).matrix =
        (oneTermRobinGate_U_indic p).matrix ∧
      (∀ j : Nat, indicatorOracleImage p (indicatorOracleImage p j) = j) := by
  exact ⟨oneTermRobinGate_U_indic_dagger_matrix_eq p,
    indicatorOracleImage_self_inverse p⟩

   
                                                                                  
                      
theorem indicatorOracleImage_injective (p : OneTermRobinParameters) {j₁ j₂ : Nat}
    (h : indicatorOracleImage p j₁ = indicatorOracleImage p j₂) :
    j₁ = j₂ := by
  have h1 := indicatorOracleImage_self_inverse p j₁
  have h2 := indicatorOracleImage_self_inverse p j₂
  rw [← h1, ← h2, h]

   
                                                                              
                                                                                       
  
theorem robinIndicatorBitPosition_lt_totalQubits (p : OneTermRobinParameters) :
    robinIndicatorBitPosition p < oneTermRobinTotalQubits p := by
  simp only [robinIndicatorBitPosition, oneTermRobinTotalQubits,
    RobinRegisterPartition.totalQubits, defaultRobinRegisterPartition]
  omega

   
                                                            
                                                                          
                                                                     
  
theorem indicatorOracleImage_lt (p : OneTermRobinParameters) {j : Nat}
    (hj : j < qubitDim (oneTermRobinTotalQubits p)) :
    indicatorOracleImage p j < qubitDim (oneTermRobinTotalQubits p) := by
  simp only [qubitDim, gridSize] at *
  show j ^^^ (if (2 : Nat) ≤ (j >>> 1) &&& (1 <<< p.n - 1) ∧
      (j >>> 1) &&& (1 <<< p.n - 1) ≤ gridSize p.n - 3 then 1 else 0) <<<
      robinIndicatorBitPosition p < 2 ^ oneTermRobinTotalQubits p
  split
  · apply Nat.xor_lt_two_pow hj
    rw [Nat.one_shiftLeft]
    exact Nat.pow_lt_pow_of_lt (by omega) (robinIndicatorBitPosition_lt_totalQubits p)
  · simp only [Nat.zero_shiftLeft, Nat.xor_zero]; exact hj

   
                                                                
                                                      
                                                                  
                      
theorem indicatorOracleImage_bijective (p : OneTermRobinParameters) :
    (∀ (a b : Fin (qubitDim (oneTermRobinTotalQubits p))),
        (⟨indicatorOracleImage p a.val, indicatorOracleImage_lt p a.2⟩ :
          Fin (qubitDim (oneTermRobinTotalQubits p))) =
        ⟨indicatorOracleImage p b.val, indicatorOracleImage_lt p b.2⟩ →
        a = b) ∧
    ∀ (y : Fin (qubitDim (oneTermRobinTotalQubits p))),
      ∃ (x : Fin (qubitDim (oneTermRobinTotalQubits p))),
        (⟨indicatorOracleImage p x.val, indicatorOracleImage_lt p x.2⟩ :
          Fin (qubitDim (oneTermRobinTotalQubits p))) = y := by
  constructor
  · intro a b h
    apply Fin.ext
    exact indicatorOracleImage_injective p (Fin.ext_iff.mp h)
  · intro y
    refine ⟨⟨indicatorOracleImage p y.val, indicatorOracleImage_lt p y.2⟩, ?_⟩
    apply Fin.ext
    exact indicatorOracleImage_self_inverse p y.val

   
                                                                         
                                               
                      
theorem indicatorOracleMatrix_col_has_one (p : OneTermRobinParameters)
    (j : Fin (qubitDim (oneTermRobinTotalQubits p))) :
    indicatorOracleMatrix p
      (⟨indicatorOracleImage p j.val, indicatorOracleImage_lt p j.2⟩ :
        Fin (qubitDim (oneTermRobinTotalQubits p))) j = Coeff.rat 1 := by
  rw [indicatorOracleMatrix_eq_image]
  simp

   
                                                                  
                                                                         
                      
theorem indicatorOracleMatrix_col_unique (p : OneTermRobinParameters)
    (i j : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (h : indicatorOracleMatrix p i j = Coeff.rat 1) :
    i = ⟨indicatorOracleImage p j.val, indicatorOracleImage_lt p j.2⟩ := by
  rw [indicatorOracleMatrix_eq_image] at h
  split at h
  · next h_cond => exact Fin.ext h_cond
  · next h_cond => simp at h

   
                                                                   
                                          
                      
theorem indicatorOracleMatrix_row_has_one (p : OneTermRobinParameters)
    (i : Fin (qubitDim (oneTermRobinTotalQubits p))) :
    ∃ (j : Fin (qubitDim (oneTermRobinTotalQubits p))),
      indicatorOracleMatrix p i j = Coeff.rat 1 := by
  have h_surj := (indicatorOracleImage_bijective p).2 i
  have ⟨⟨xval, xprop⟩, hx⟩ := h_surj
  refine ⟨⟨xval, xprop⟩, ?_⟩
  rw [indicatorOracleMatrix_eq_image]
  have h_eq : i.val = indicatorOracleImage p xval := by
    have := Fin.ext_iff.mp hx
    simp at this
    exact this.symm
  simp [h_eq]

   
                                                                  
                                         
                      
theorem indicatorOracleMatrix_row_unique (p : OneTermRobinParameters)
    (i : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (j₁ j₂ : Fin (qubitDim (oneTermRobinTotalQubits p)))
    (h₁ : indicatorOracleMatrix p i j₁ = Coeff.rat 1)
    (h₂ : indicatorOracleMatrix p i j₂ = Coeff.rat 1) :
    j₁ = j₂ := by
  have key₁ := indicatorOracleMatrix_col_unique p i j₁ h₁
  have key₂ := indicatorOracleMatrix_col_unique p i j₂ h₂
  have h_inj := (indicatorOracleImage_bijective p).1
  exact h_inj j₁ j₂ (key₁.symm.trans key₂)

   
                                                                             
                                                                       
                                                                           
                      
theorem indicatorOracleMatrix_is_permutation (p : OneTermRobinParameters) :
    (∀ (i : Fin (qubitDim (oneTermRobinTotalQubits p))),
      ∃ (j : Fin (qubitDim (oneTermRobinTotalQubits p))),
        indicatorOracleMatrix p i j = Coeff.rat 1 ∧
        ∀ (j' : Fin (qubitDim (oneTermRobinTotalQubits p))),
          indicatorOracleMatrix p i j' = Coeff.rat 1 → j' = j) ∧
    (∀ (j : Fin (qubitDim (oneTermRobinTotalQubits p))),
      ∃ (i : Fin (qubitDim (oneTermRobinTotalQubits p))),
        indicatorOracleMatrix p i j = Coeff.rat 1 ∧
        ∀ (i' : Fin (qubitDim (oneTermRobinTotalQubits p))),
          indicatorOracleMatrix p i' j = Coeff.rat 1 → i' = i) := by
  constructor
  · intro i
    have ⟨j, hj⟩ := indicatorOracleMatrix_row_has_one p i
    exact ⟨j, hj, fun j' hj' => (indicatorOracleMatrix_row_unique p i j j' hj hj').symm⟩
  · intro j
    let row := (⟨indicatorOracleImage p j.val, indicatorOracleImage_lt p j.2⟩ :
                  Fin (qubitDim (oneTermRobinTotalQubits p)))
    exact ⟨row, indicatorOracleMatrix_col_has_one p j,
           fun i' hi' => indicatorOracleMatrix_col_unique p i' j hi'⟩

end GHL2025
end QuantumBlockEncoding
