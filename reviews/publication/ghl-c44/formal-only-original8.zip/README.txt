FORMAL-CONTEXT INPUT ONLY — no reconstruction or verdict is present.

Read QuantumBlockEncoding/GHL2025.lean in its entirety. It has 8474 lines; comments have been replaced with spaces while every original code character, identifier, String literal, record field, proof body, private helper, and ambient command is retained. Source-bearing String literals are part of the formal code and remain visible. Thus this input is NOT identity-blind.

The five other .lean files are the complete comment-masked project import closure down to Std. Their content is formal context, not a desired reconstruction. The pinned external Std/toolchain/dependency context is listed in context-pins.json. No natural-source text, lesson, author's classifications, prior verdict, or required mathematical answer is included in this directory. Do not retrieve sibling natural/ or author/ files during the blind reconstruction phase.

No compiler run, current type elaboration, axiom census, independent decoder action, independent review, or acceptance is represented by this packet. An actual decoder must record its own run/input digest and independently reconstruct the formal mathematics rather than trust file names or comments removed from this input.
