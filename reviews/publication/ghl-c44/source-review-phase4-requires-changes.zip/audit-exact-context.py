"""Read-only static/binding audit. Does not run admission, Git, Lean or a compiler."""
import sys
sys.dont_write_bytecode = True
import hashlib
import json
import re
import zipfile
from pathlib import Path

repo = Path(sys.argv[1])
workspace = Path(sys.argv[2])
prospective = repo / 'reviews/publication/ghl-c44'
context = json.loads((prospective / 'prospective-context-v2.json').read_text(encoding='utf-8'))
record = context['record']
author = workspace / 'hermite-export-work/ghl-c43-publicsafe/author'
inventory = json.loads((author / 'declaration-inventory.json').read_text(encoding='utf-8'))
supplement = json.loads((author / 'structure-fields-and-string-roles.json').read_text(encoding='utf-8'))
own = json.loads((workspace / 'hermite-export-work/ghl-c43-source-review-phase2/declaration-coverage-map.json').read_text(encoding='utf-8'))
frozen = workspace / 'hermite-export-work/ghl-c42-source-recovery/formal-only'
target_lines = (frozen / 'QuantumBlockEncoding/GHL2025.lean').read_text(encoding='utf-8').splitlines()
own_decls = next(x['declarations'] for x in own['files'] if x['path'].endswith('/GHL2025.lean'))
by_line = {x[0]: x for x in own_decls}
signature_errors = []
identity_errors = []
for declaration in inventory['declarations']:
    line = declaration['line']
    previous = by_line.get(line)
    if not previous or previous[4] != declaration['fqname'] or previous[2] != declaration['kind'] or (previous[3] == 'private') != declaration['private']:
        identity_errors.append(line)
    block = '\n'.join(target_lines[line-1:declaration['lexical_neighborhood_end_line']])
    normalize = lambda text: re.sub(r'\s+', ' ', text).strip()
    signature = normalize(declaration['source_signature'])
    normalized_block = normalize(block)
    if not normalized_block.startswith(signature):
        signature_errors.append({'line': line, 'kind': 'not-exact-prefix'})
    elif declaration['kind'] in ('theorem', 'def'):
        remainder = normalized_block[len(signature):].lstrip()
        if not (remainder.startswith(':=') or remainder.startswith('where')):
            signature_errors.append({'line': line, 'kind': 'not-outer-body-delimiter'})

field_errors = []
field_count = 0
for structure in supplement['structure_fields']:
    for field in structure['fields']:
        field_count += 1
        expected_lines = field['full_masked_field_source'].splitlines()
        observed = target_lines[field['line']-1:field['line']-1+len(expected_lines)]
        if [x.rstrip() for x in expected_lines] != [x.rstrip() for x in observed]:
            field_errors.append(field['line'])

string_errors = []
for item in supplement['source_bearing_strings']:
    if item['literal'] not in target_lines[item['line']-1]:
        string_errors.append(item['line'])
public = {x[4] for x in own_decls if x[3] != 'private'}
private = {x[4] for x in own_decls if x[3] == 'private'}
declared = record['declarations']
obligation_errors = []
for item in record['obligation_map']:
    for name in item['declarations']:
        declaration = next((x for x in inventory['declarations'] if x['fqname'] == name), None)
        expected_kind = 'proof-edge' if declaration and declaration['kind'] == 'theorem' else 'prerequisite'
        if not declaration or declaration['private'] or item['kind'] != expected_kind or item['source_lines'] != [declaration['line'], declaration['lexical_neighborhood_end_line']]:
            obligation_errors.append(name)
mapped = {n for item in record['obligation_map'] for n in item['declarations']}
graph_context = json.loads((prospective / 'prospective-graph-context-v2.json').read_text(encoding='utf-8'))
group_checks = []
last = 0
for group in graph_context['declaration_groups']:
    count = sum(group['start_line'] <= x[0] <= group['end_line'] for x in own_decls)
    group_checks.append({'id':group['id'],'count':count,'expected':group['explicit_declaration_count'],'contiguous':group['start_line']==last+1})
    last = group['end_line']

source_rows = json.loads((repo / 'website/research/sources.json').read_text(encoding='utf-8'))['sources']
selected = [x for x in source_rows if x['id'] == context['source_row']['id']]
if len(selected) != 1:
    raise RuntimeError('Selected source row not unique')
source = selected[0]
del source_rows

# Execute only the already-read original binding algorithm's definitions.
# No invocation of check(), validate_record(), main(), Git or evidence wrappers.
checker = repo / 'website/scripts/check_research_publications.py'
scope = {'__file__':str(checker), '__name__':'binding_audit_not_cli'}
exec(checker.read_text(encoding='utf-8'), scope)
computed = scope['binding_digest'](repo, record)
proof_inputs = []
for directory in ('QuantumBlockEncoding', 'ABEISTests'):
    base = repo / directory
    for path in sorted(base.rglob('*.lean')):
        if not path.resolve().is_relative_to(base.resolve()):
            raise RuntimeError('Proof-input path escaped approved root')
        proof_inputs.append({'path':path.relative_to(repo).as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})

archive_checks = []
for archive_name in ('topology-independent-original-requires-changes.zip','topology-independent-v2.zip','formal-only-original8.zip'):
    with zipfile.ZipFile(prospective / archive_name) as archive:
        pins = {name:hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist()}
        if archive_name == 'formal-only-original8.zip':
            result = all(hashlib.sha256((frozen / name).read_bytes()).hexdigest() == digest for name,digest in pins.items())
        else:
            seal = json.loads(archive.read('seal.json'))
            result = all(pins[item['path']] == item['sha256'] and len(archive.read(item['path'])) == item['bytes'] for item in seal['artifacts'])
        archive_checks.append({'archive':archive_name,'members':len(pins),'member_sha256':pins,'binding_match':result})

topology = json.loads((prospective / 'source-topology-v2-proposal.json').read_text(encoding='utf-8'))
old_topology = json.loads((workspace / 'hermite-export-work/ghl-c43-source-first/natural-topology.json').read_text(encoding='utf-8'))
old_nodes = {x['id']:x for x in old_topology['nodes']}
new_nodes = {x['id']:x for x in topology['nodes']}
old_edges = {x['id']:x for x in old_topology['hyperedges']}
new_edges = {x['id']:x for x in topology['hyperedges']}
def ancestors(root):
    seen = {root}
    changed = True
    while changed:
        changed = False
        for edge in topology['hyperedges']:
            if set(edge['head']) & seen:
                for tail in edge['tail']:
                    if tail not in seen:
                        seen.add(tail)
                        changed = True
    return seen
active_ancestors = ancestors('M12.restricted-column')
construction_ancestors = ancestors('M12.constructed-record')

result = {
 'schema':'independent-stage4-read-only-check-v1',
 'scope':'Static exact-source/context and original binding algorithm only; no admission/compiler/trust claim',
 'catalogue':{'public':len(public),'private':len(private),'whole':len(own_decls),'public_set_equal':set(declared)==public and len(declared)==len(public),'obligation_set_equal':mapped==public,'private_ids':sorted(private),'identity_errors':identity_errors,'signature_errors':signature_errors,'field_headers':field_count,'field_errors':field_errors,'source_string_occurrences':len(supplement['source_bearing_strings']),'string_errors':string_errors,'obligation_errors':obligation_errors,'graph_node_public_ids_complete':{'declaration:'+x for x in public}.issubset(record['graph_contribution']['node_ids'])},
 'groups':group_checks,'coverage_end':last,
 'selected_source_row':source,'selected_source_row_equal':source==context['source_row'],
 'binding':{'recorded':record['binding_sha256'],'computed':computed,'matches':computed==record['binding_sha256'],'proof_input_count':len(proof_inputs),'proof_inputs':proof_inputs,'algorithm':'Original binding_digest function; sorted-key ensure_ascii=False default-separator JSON payload; raw named files,sorted production/test Lean bytes,selected source-row JSON','checker_sha256':hashlib.sha256(checker.read_bytes()).hexdigest()},
 'raw_current_pins':[{'path':name,'sha256':hashlib.sha256((repo/name).read_bytes()).hexdigest()} for name in (record['module'],record['lesson_path'],'lean-toolchain','lake-manifest.json')],
 'archives':archive_checks,
 'topology':{'added_nodes':sorted(set(new_nodes)-set(old_nodes)),'changed_nodes':[key for key in old_nodes if new_nodes.get(key)!=old_nodes[key]],'changed_edges':[key for key in old_edges if new_edges.get(key)!=old_edges[key]],'E21_unchanged':old_edges['E21']==new_edges['E21'],'unclosed_dependencies_unchanged':old_topology['prospective_unclosed_dependencies']==topology['prospective_unclosed_dependencies'],'all_edge_refs_resolve':all(x in new_nodes for e in topology['hyperedges'] for x in e['tail']+e['head']),'conditional_ancestor_of_active':'M12.conditional-record-consequences' in active_ancestors,'conditional_ancestor_of_constructed':'M12.conditional-record-consequences' in construction_ancestors,'weak_gap_ancestor_of_active':'G.local-encoded-image-details' in active_ancestors,'weak_mention_ancestor_of_active':'M12.encoded-image-interface' in active_ancestors},
 'excluded_operations':{'admission_checker':False,'new_decoder_wrapper_read':False,'Git':False,'Lean_native_compiler':False,'production_write':False,'registry_write':False,'network':False}
}
print(json.dumps(result,ensure_ascii=False,separators=(',',':')))
