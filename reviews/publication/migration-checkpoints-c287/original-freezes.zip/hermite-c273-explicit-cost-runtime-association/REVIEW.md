# C273: focused recorded-runtime association

Classification: INTERNAL RECORDED-RUNTIME ASSOCIATION, separately authorized AFTER the immutable C264 static review. No compiler rerun, new mathematics, source-publication review, external SourceAnchor, ProofSeal or scientific ROOT admission. C264's three original hashes/lengths still match.

## Result and exact binding

No concrete source/output/type/selected-dependency mismatch was found in the inspected C263 records. They support the focused local gate for `HermiteExplicitCachedStored.produceExplicitStored_cost_counters`, not full-module/publication acceptance or C250's complete same-run value conclusion. C264's independent arithmetic findings are unchanged; this report does not repeat or replace them.

The staged proof is byte-length/hash identical to the C262 source reviewed in C264: 20978 bytes, SHA256 `62d6a008fe63961b75330a8e6d06cbfabeffba5b4b4df57c771a07e9eac15f3b`. The staged consumer likewise matches: 796 bytes, `c628185332bf6147157ec2f5cfd6c7bd2b38dab401a5c85478cf0cb6c4cc4bfd`. Current own proof output is 2481040 bytes, `0c75651b0b6d6aa18064eb8d835097074ac2db762cf378802780dfb15e30ad20`; own consumer output is 2224 bytes, `5ec12a9d7aed1a2948d8c8e8d8d7903e74178e6a818cc42834c56840a0de6654`. All four match the runtime records. Hashing an olean is an opaque byte binding, not a decompilation or independent kernel replay.

The consumer source assigns the exact universally quantified three-conjunct expression to the root, with no extra premise, no existential replacement run and no weaker counter/budget. Actual consumer stdout prints the same k,n:Nat and R,delta:Rat type:

```text
let result := produceExplicitStored k n R delta
total result.run.cost <= frontierBudget k n delta
AND result.quotientCalls <= 14*(n+1)*(assemblySize k delta)^2+4*assemblySize k delta
AND result.remainderCalls <= 14*(n+1)*(assemblySize k delta)^2+4*assemblySize k delta
```

This is the cost/counter tail of the C250 sealed same-run type. It does not contain or establish `denoteChain result.run.value = actualChain k n R delta`; C252/C261/C268 value packets were NOT opened.

## Raw records versus wrapper assertions

All ten private archive members were read only in memory and hashed. No archive, host path, prefix, requested search-path payload or credential was copied into public output. The manifest identifies this evidence only by opaque archive/member IDs and hashes. Both raw stderr streams are empty. Reapplying the wrapper's path-label/CRLF sanitation read-only gives EXACT current feedback text for both modules. Raw source stdout hash is `1b1ed41ffd256ed67291ec9fe6e10bfe54592162ffc618d23549ed95a9afbec7`; raw consumer stdout hash is `f2e43a99be2b57940a125d18a066c810c3f3e2e2d8c59d5531cb58afca978c72`.

Actual source feedback contains seven linter warnings: unused simp arguments at lines30/89, sequence-focus warnings at46/87/353, and unused/unreachable omega at270. These remain visible; no linter/trust/budget option was modified by this review. Actual consumer stdout contains the complete type and exactly ONE quoted axiom report for the named public root:
`[propext, Classical.choice, Quot.sound]`.
I directly read that row; it is not merely the result JSON's parsed array. The strict parser source accepts ordinary fully qualified names plus optional universe suffixes, then ordinary_only allows only this three-name set (or subsets). No universe suffix occurs in this actual row, so no nonordinary axiom is hidden by normalization here.

The proof module has no #print command and emits ZERO axiom rows. The wrapper deliberately accepts zero rows there; that means no source-phase axiom print, NOT an empty-axiom proof. The subsequent own-output consumer requires exactly one row for the exact root and ordinary-only content. Missing root row, extra matched row, unknown parsed axiom, parser error, nonzero compiler exit or timeout would fail that focused gate. The regex scans the quoted “depends on axioms: [...]” form only; it is not a general audit of every declaration or arbitrary malformed diagnostic. In these actual complete streams I found no unparsed competing axiom row or sorryAx. No claim about unused private declarations or all imported module axioms is made.

The result records assert exit0/no timeout for both compiler subprocesses, 44.391 and26.968 parent-measured seconds. Those exit codes, timing and pre/post historical pin assertions are wrapper-produced records, not facts independently observed by this reviewer during execution. The raw streams, current hashes, source/consumer and full wrapper logic are consistent with them. This is historical recorded-run association, not tamper-proof process attestation or an independent rerun. The wrapper's status string alone was not used as proof.

## Selected imports and loader boundary

Raw proof --deps has seven lines: two Init entries, then exactly the five explicit imports below. Raw consumer --deps has three lines: two Init entries, then the C263 own proof output above, not an old C253/C258 output. The selected provider files currently hash exactly to the pre-execution plan, C262/C250 inherited pins and result list:

| Direct proof provider | SHA256 |
| --- | --- |
| ExplicitFiveBlockDefinitions | e034f934ccd6aadb5e5a250ccfdcec26a8d8a30b36e9a38dd55bd62da457be9f |
| CachedMiddleCostProof | 21569e2b203c086a2107de0337198ffca2ebc75b4d13ed100395fd153cf94c10 |
| SetupCostProof | 38f8d7689c5858f497f0552c735a8e557505d8dadd011770fb0ad56f85c7aa6d |
| CacheConsumerChecks | c10ccf0fe072c26df636bdcb5f12b747a0b21e9d3bd071b53ca782bcd0eb93a9 |
| AccountedTraffic | 8ca4ece88d7a83216e8d9c99ad5042d800398f4fb7e0f41259c436944cb7a039 |

Both recorded Init entries have current 5784-byte digest `26523a3af45a445bdbae0b9070334c12856c650808276348189e2999fa1d07aa`. Their recorded location is outside the invoked binary prefix even after textual full-path normalization. The invoked prefix's own Init has the SAME length/hash. This is not a discovered byte mismatch, but directory identity/realpath/junction provenance and the whole toolchain library are not certified. The invoked binary currently hashes `dd86e9b24990b1da425ea4af910f016e4db8f9a25c9ddad27bc6bee3690e677f`, matching C250's expected binary pin; I did not execute it. Requested LEAN_PATH has32 entries with the own stage and selected providers first, duplicate inherited entries and many caches. Its final library location is also outside that prefix; no full effective loader trace is archived.

The wrapper tests expected direct-provider paths by substring inclusion in --deps stdout, not exact set equality or full transitive resolution. I inspected the actual whole lines separately: the five and the own consumer import really are the intended files. The same environment/root is then used for compilation. This closes the observed direct selection ambiguity, not the general loader/transitive dependency gap. C159's inherited primitive output still has pin `77547431cc9e4759adcd8c25f6a3e57622da492bdb31ac36f2061ab06e50d473`; it is a transitive candidate/provider pin, not an independently traced loaded body. C155/C156/C249 provenance, inherited repository binaries and dirty dependency state remain inherited, not a clean source-to-binary rebuild or printed-definition audit.

## Wrapper and derivation audit

The complete runner source binds author manifest/freeze, C250 seal, output/source/provider lists, protocol intake and inherited binary pins; verify runs before stage creation, before each module and after execution. New stage creation uses exist_ok=False. Exact transport and present bytes bind the copied .lean files. --deps must return0 and include selected outputs before either compile. The proof output is generated before the consumer, whose selected own import hash is then recorded. With the stage nonexisting initially, stale same-stage own output reuse is not the intended path. However historical race freedom and all pre/post assertions are not independently rerun/attested.

Compiler parameters in the runner are -M3072, -j1,180s per module with a5120MiB available-memory admission check; the result's available-memory figures exceed that check. These are bounded gate settings, not algorithmic resource theorems. No source/root/counter/assumption change is introduced by the runner. The readable preparation source and derivation record describe two literal normalization replacements and inherited runner substitutions; the resulting runner hash matches their new-runner pin. I did not open or recompute predecessor templates or feedback, and therefore do not upgrade the preparation author's array-equality/change-count assertions into independently verified historical facts. The transport helper source was read; its imported installer/helper dependency was not audited or executed. Current source/output bindings do not rely solely on its asserted exact-copy behavior.

No concrete evasion of this particular exact-type/root-axiom gate was found. Limits remain: subset rather than exhaustive --deps checking in the runner, no complete effective-loader recording, no independent binary replay, and no whole-module/imported-TCB axiom audit. The focused gate should not be promoted beyond those boundaries.

## Handoff, exposure and stop

Objective/mathematical delta: associate C264's independently reviewed C262 three-conjunct supplier with actual C263 recorded source/own-output/consumer evidence; no new mathematical theorem or bound invented. Effect on root frontier: focused runtime association is supported, while the C250 value conjunct, full finite-bit SPBE error/success/resource chain, scientific ROOT, publication, main integration and PURIFIED remain outside this report. Partial eight-counter/selected quotient-remainder semantics, native Rat/GCD/bit/evaluator/allocation/captured-sharing/cast/QR/gates/cleanup/export gaps are unchanged.

Actions: read-only PowerShell/Get-Content/Get-Item/Get-FileHash/Get-ChildItem and .NET ZIP memory reads, no extraction; apply_patch only in this NEW packet. No compiler/lake/Python/project script/Git/network/subagent ran. No C252/C261/C268, other review or historical C256/C259 feedback file was opened. C264 all three original bytes were preserved. Prior distinct Hermite static/runtime slices and C206/C230 authorship remain disclosed; this is not a fresh universal decoder. New C263 runtime exposure happened only after the parent validated C264 and explicitly released it.

Tooling failures retained: an initial ZIP feedback-comparison helper used a flattened pair array and failed Regex.Replace on a null replacement; one corrective read-only PowerShell attempt had a missing-brace parse error and executed nothing; the corrected read-only check succeeded for both feedback files. Initial path mapping withheld unmapped private paths; those were then classified by leaf/hash without publishing them. No evidence or predecessor was altered to repair these diagnostics.

Named evidence: exact manifest pins, actual type/one ordinary axiom row and selected directdeps, not independent rerun. Failure class: NONE concrete association mismatch found; residual TCB/process-attestation limitations explicit. Salvage: C264 untouched; all actual warnings/records retained. qbe-substantive-worker and QBE-PM-LOW-TOKEN-CONTROL-PLANE / QBE-PM-VERIFIER-SEMANTIC-LEVEL guide the evidence-level distinction. Direction C273_FOCUSED_OWN_OUTPUT_ASSOCIATION; no parallel delegation or alternative winner. Default comparator is exact C262/C250/C264 binding, not success JSON. Source construction, Lean dependencies and native/quantum resource graphs remain distinct. Purification/Exposition-Seal not performed. Recommended next step is parent whole-read/hash verification of this separate packet, without automatic new exposure or scientific promotion. Only REVIEW.md, INPUT_MANIFEST.json and REVIEW_FREEZE_SEAL.json in this new packet are public-allowlisted. Freeze and STOP.
