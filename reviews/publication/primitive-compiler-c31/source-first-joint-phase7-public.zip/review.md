# Phase7: same original source-first reviewer, joint fresh CSP/Cubic environment

Identity: `/root/primitive_compiler_source_first_c31`. Run: `c31-source-first/phase7-joint-actual-c38/20261017T030059Z`. This is a continuation of the original natural-source derivation and Phase6 judgment, not a new blind reviewer or a new natural-source review. This independent judgment is sealed without reading `joint-comparison.json` or any new decoder output.

## Outcome

`JOINT_FRESH_PROVIDER_ENVIRONMENT_SUPPORTS_SAME_WHOLE_CUBIC_SOURCE_REVIEWED_LOCAL_CANDIDATE_PENDING_FINAL_BINDING`.

The joint evidence resolves the specific Phase6 uncertainty that the new Cubic-three-proof candidate had previously been compiled with the old inherited CSP provider. CSP-nine is now freshly compiled first in the same four-target cohort, and the entire observed Cubic module retains the separately reviewed candidate's exact contracts. My original source-side support for its whole 25-source-root module therefore carries to this joint environment, within the same finite n=2 ideal semantics and inherited-provider evidence boundary. This is not final registry `accepted`, main, scientific ROOT, nativeAccepted, SourceAgreement, publication admission, or PURIFIED.

No production source or registry is changed. No final new source-statement/raw-source binding exists merely because this joint diagnostic succeeded. Original Phase1 seal SHA `13a68071140ae9cd87b7f520cdf9cf88421e53357bdadcb7b44cdfe5adaf0675` and Phase6 seal SHA `d36d8a88b57966226e88028adf6ef7f7c57466b7fd0f8b922bbb723154d21360` were rehashed unchanged.

## Exact sources and independent mathematical invariant

The supplied joint ZIP hash independently matches `c540fc35303cf5c7f865d90cd4b3fbca3b3ef840bd926c743657e606e85b5d51`. Independent baseline ZIP checks match CSP `c1ed298ad9736c4ec3b4ab71b4324fa407a1415d7cf1c45350e0b12ef74f149d` and C31 `3e69139f0a9e1d275bc2eb0b89a0bb36206501f2def3510ba4876ac20a6a7267`. No author comparison algorithm/result was executed or adopted as the comparison oracle.

The virtual source replacement map has exactly two entries:

- CSP original `d125f8c239bca1c15e6e4fa6e788df6dd8984394630cb2dcc9be8946c4cbcb55` to candidate `6ee53311b5d6e18c46afb3e068341689acb86f1bdbc425e774705e81c9142f44`.
- Cubic original `48c9a4a1c47c925c93493eede21eb7b492d23d2cb7dadf254782e4485c349cb3` to candidate `952e2b359796ef695a1b1c1a376d40a80affbc679f503f94227ea0c775a6cd48`.

I independently read only the original/candidate source members of the pinned CSP source-transport ZIP, reconstructing its complete bytes by substitutions at original lines 252,372,437,441,771,775,779,2465,2535. Eight replace `native_decide` with `decide +kernel`; line 2465 replaces the local proof of `(0 : Rat)-0=0` with `exact Rat.sub_self`. All other source bytes are equal. The same entire-byte test independently rechecks Phase6's three Cubic `native_decide +revert -> decide +kernel +revert` substitutions at lines 40,93,100. I do not infer proof-only character merely from `exactSourceDelta` flags. The joint C31 profile differs from the separate candidate profile only by CSP's source hash and removing CSP from the inherited-provider list; its 87-root vector and all other data remain equal.

Consequently imports, statements and implicit/explicit binders, ordinary definitions, type-valued/Prop-valued structure fields, literal circuits, normalization/register/phase conventions, resource expressions and semantic source statements are unchanged. Different proof terms may appear as proof-valued arguments, notably the exact-angle amplitude bound; proof irrelevance preserves the corresponding data/interpretation rather than asserting proof-body byte equality. This is a bounded transport of the source semantics already reconstructed independently in Phase1, not a new mathematical review of every CSP theorem or every ambient module.

In particular the finite target remains diag`(0,1/64,1/8,27/64)`. Encoding is `(j mod 2, floor(j/2) mod 2, signal)`, and the two nonsignal coordinates determine j independently of signal. Exact standard-RY twice-arccos semantics, zero global phase, both diagonal/off-diagonal context branches, little-endian flat transport, concrete unitarity/clean-block proofs and final verified wrapper are unchanged. The corrected whole-module source graph does not acquire a missing producer or extra hypothesis through a proof tactic substitution.

## Actual raw streams: independent, exhaustive field comparison

There are exactly 104 flat public ZIP files. I read/hash 103, excluding the author `joint-comparison.json` contents and its member hash until after this independent judgment (it remains unread). The 102 read non-receipt files match their public export-receipt SHA rows; the receipt file itself is independently hashed. Transport SHA covers the whole ZIP opaquely and is not a claim to have semantically read the excluded member.

I independently parse all tagged lines in actual streams 30/40/41 and the respective separate actual baselines:

| Stream | Source roots | Dynamic generated | Other tagged rows | Comparison |
| --- | ---: | ---: | --- | --- |
| C31 30 | 87, including 8 private | 113 | 3 binding +1 summary | All 200 complete declaration objects equal separate C31 candidate |
| CSP 40 | 319, including 50 private | 449 | 1 binding +1 summary | All 768 complete declaration objects equal separate CSP candidate |
| CSP 41 | — | 2 exact observed names | 1 binding +1 summary | Both complete supplement objects equal separate two-type baseline |

Comparison discovers actual-name sets, uses case-sensitive identity maps, checks complete key sets, and compares every field, including entire type/value strings where present, universes, actual kind/private names, source labels, recursive axioms, self-occurrence and value availability. No normalization or ignored semantic field hides a delta. All 968 owned declarations have kernel presence, no unsafe flag, no actual axiomInfo, and no self-axiom. Their recursive union is exactly `Classical.choice`, `Quot.sound`, `propext`. C31's actual module-index-owned partition remains 98 Macros, 58 Uniform, 44 Cubic; its structures/fields/constructors/projections are unchanged. All 11 CSP actual structure metadata records also match. This is observed owned scope, not a claim that every imported declaration was audited.

The complete C31 rows retain its explicit ci/ki kind/type/universe equality guards. The full CSP probe checks checked-kernel presence and kind agreement, but prints most type/universe/value/unsafe fields from ci; it does NOT provide C31's stronger type/universe equality guard. The narrow two-type supplement prints its two complete types/universes from kernelInfo directly. Recursive axiom arrays use Lean collectAxioms, not an assertion that every field comes from ki. These existing, distinct observation interfaces remain disclosed.

CSP's two generated type strings containing ellipses are exactly `linearDiagonalFourSquareBranchVector_unit._proof_1_1` and `cubicDiagonalFourSquareBranchVector_unit._proof_1_1`; stream 41 supplies their complete non-ellipsis types, equal to the separate baseline. CSP's 96 generated value strings containing ellipses remain incomplete and equal, not repaired by the type supplement. There are also 22 null generated value texts and no requested value text for its 319 source roots. All 200 C31 value texts remain deliberately omitted. Pretty text is not lossless Expr serialization; this is not a full proof-body audit, and no new all-body prerequisite is imposed.

The public stream SHA values are:

- 30: `7e3881e95d8236e8ed53270c2458a29646f37f5b9ccd8c02e79f78edfe40aee5`.
- 40: `1528ecbc2040e28ed63e2a74d975ca2c67f1cba1e2516db10bc31afcd9d3d8cb`.
- 41: `00fbbcc3929ff2e103ea2d94ee0254c3fae1b4ecec11f20045b96d6da647ee47`.

Original raw stdout receipt hashes are separately indexed and differ because of public path sanitization. I do not claim to recover or independently rehash unavailable original raw bytes. The full comparison index records every compared identity and complete-observation/type digest.

## Four fresh targets and actual process/provider boundary

Cohort `612290bf907a4a55b9ecb79ac379c263` compiles CSP, Macros, Uniform, Cubic in that order. All four source-before/source-after/copied-source hashes and actual compile output paths agree with the virtual joint input map. CSP's fresh artifact SHA is `a570144205d89df5604c2f0096df773c8a9174a01d42043bc73a40dd420adb71`; it is explicitly not inherited. Both actual CSP probes resolve exactly this artifact, with expected-fresh environment bindings and the common cohort-first search path. C31's three observed resolved paths equal its three newly compiled target paths; cohort IDs agree across target receipts and stream bindings. The three C31 olean hashes happen to equal the separate candidate hashes; equality alone is not used to infer provider semantics.

There are 24 inherited project-provider copies, not 25: CSP is removed. Exactly those 24 profile modules form the two-hop project-to-shadow-to-cohort copy chains with equal hashes and exact endpoints. The preparation list's additional typed row is a data-only shared helper, not a 25th provider or a newly executed helper. The new entry rejects all four target caches/fallback artifacts before compiling and continuously rechecks relevant source/provider/driver pins. Actual entry/reused-guard source hashes are independently checked; the unchanged C31 generated-driver source hash vector matches the separate run. The wrapper source was read, not run. This is a faithful-wrapper source-file/receipt boundary, not OS/code-object attestation, a native load trace, or clean-transitive recompilation of inherited providers. The external inventory remains a distinct layer, not required membership for project-copy rows.

All eleven actual process start/result/observation records agree on PID/result and have exit 0, no timeout and empty stderr; four-target receipts and both CSP-probe native results match their corresponding process records. The substantive nine processes have actual 5120MiB, one thread, timeout at most 900s within the existing 2100s whole budget; help/prefix use 30s. Twenty-two pre/post snapshots satisfy the unchanged 5120+2048MiB policy, with 11 file reads plus one self-namespace read/12 attempts apiece and no sampled OOM/oom_kill. Minimum sampled headroom is 15305162752 bytes. Root memory interfaces remain typed not-applicable, not an observed unlimited value. Public raw-proc/path omission, noncontinuous sampling, no peak-RSS observation and the self-namespace fingerprint boundary are retained, not turned into new TCB requirements.

The artifact itself reports GITHUB_SHA `e79996d363d1c4fa591a45718d8286a6dfbce5ce`, distinct from parent's API head `ad025220321160b83f33ab2a3a2dc3e6f1982d39`. After finding this I read the explicitly authorized parent-supplied context metadata: it reports e799's parents `[f2cba045...,ad025220...]` and equal API/local tree `525aaa30843a7f3c2030bf197e41364d6974915c`. I did not perform a Git/API query. This reconciles the reported merge/head labels at the metadata layer, not independently attested execution; the 31 source/config pins and executing-code observations remain separate evidence.

## Corrected source graph, semantic slots, and remaining bridge

The corrected v3 binder audit hash `7f5093cd9b28e9e26286de2173bcaf686ca36f5a9b1ee83ddd5859d1aac1506e`, exhaustive source coverage `23953cd12776ce9dde13e4d306495bc44df2f914660777b1255f0cec7fc12da9`, and v4 graph `7015fcde26154192f0d03242ffa3056f42c6fe3cdd0382575343f752da3bf109` were rehashed unchanged. Their independent prior reasoning is retained, not replaced by author classifications.

F1/F2 corrected full Pi binders, roles and 87-root source links remain applicable. F3's full 32 AND tails and compiler-definition producer, both all-required branch cases, direct full-block versus recursive denotation distinction, local phase OR and separate unitary/clean/wrapper/count obligations remain unchanged. F4 still separates generic Prop fields from the concrete physics proofs. F5 native blockers are absent in the actual joint candidates, while finite-bit execution/presentation/scalable arithmetic boundaries remain open/excluded. Neither a generic witness nor workflow green closes those source gaps.

The seven slots remain exactly:

- `target`: whole finite n=2 diagonal Cubic module and concrete wrappers, not generic-width arithmetic or rank-one state loading.
- `normalization`: clean-block normalizer 1, not a unit-norm coefficient vector.
- `registers`: system 0/1, clean signal 2, little-endian flat index j+4s; full contexts; general repeated control wires still allowed if each avoids target, with no added injectivity premise.
- `oracles`: zero opaque oracle calls in the emitted primitive circuit; exact-angle/table production is not thereby free.
- `ancillas_phases`: one signal, zero extra pure ancillas, exact zero program global phase; exact macro phase bookkeeping is not quotiented away.
- `error_success`: exact ideal matrix and clean block; input-dependent success can be zero; no finite-bit angle-error or deterministic normalized-state guarantee.
- `resources`: unchanged definitional gate-list resource, four RY and six CX at n=2; not hardware/precision/depth-optimality certification. CI resource budgets are a separate classical verification-process contract.

The actual 26-record carry-forward partition and prospective plan are in `record-partition-and-binding-plan.md` and the exact index. All 26 have no header-import path to either changed source; two additionally have current actual recompiled observations, the other 24 do not. The 142 production/60 test distinction is explicit. An ambient digest change still requires honest new versioned binding/owner provenance, not blanket rehash or new mathematical acceptance of those records.

Still pending for a final whole-Cubic reviewer wrapper: the exact versioned candidate/source-statement/StatementSeal for the new source bytes, the separately authorized independent decoder's exact successor/final evidence digest, and the final prospective source-row/ambient binding. Those are not present by inference from this actual run. The original source derivation need not be restarted; this joint check does not require all proof bodies or a new whole-TCB audit. No current decoder result or author joint-comparison has been read, and no reviewer result has been invented. STOP after immutable handoff.
