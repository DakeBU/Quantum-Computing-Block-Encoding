# Exact current 26-record impact partition and prospective binding plan

This is metadata/import impact analysis by the original C31 source-first reviewer, not mathematical acceptance of 26 modules or adoption of their WIP statuses. Registry module/source-id/current-binding/selected-declaration/graph metadata was read with authorization; no linked reviewer or decoder body was opened.

The current registry actually has 26 records, none for CubicStatePreparation or CubicAmplitudePrimitive. The proposed changed roots are therefore separate prospective records, not two rows silently substituted into these 26. The source-row catalog provides 16 selected source IDs for the current records; exact selected-row metadata digests and each old binding are in independent-index.json. No prospective final binding is invented.

The observed source inventory is 142 QuantumBlockEncoding production modules plus 60 ABEISTests Lean files. Only the 142 production import headers were parsed. The 60 tests were hashed only; neither their headers nor proof bodies were semantically read. Prior shorthand “202 production” is corrected here without rewriting any frozen historical file. This remains a 202-file raw ambient set, not 202 production source reads.

I extracted ordinary import headers, stripped comments, stopped before declarations, and followed project-module imports transitively. All QuantumBlockEncoding-prefixed imported modules encountered are present in the 142-file map. This is a module-header overapproximation of elaborated theorem dependencies, not a claim that every imported fact is used. Every current record's closure has empty intersection with BOTH changed modules. This zero-intersection result was computed per record, not presumed from unchanged filenames.

| Current record module | Reaches changed CSP/Cubic | Evidence in this review |
| --- | --- | --- |
| PrimitiveMacros | none | source/header + joint actual |
| UniformlyControlledRy | none | source/header + joint actual |
| StoredMatrixProductChain | none | source/header only |
| ThinLQ | none | source/header only |
| PrimitiveBasisLE | none | source/header only |
| GrayBasis | none | source/header only |
| ConstructiveThinLQ | none | source/header only |
| StoredTensorTrainNorm | none | source/header only |
| MatrixProductChain | none | source/header only |
| StoredTensorTrain | none | source/header only |
| ConstructiveTensorTrain | none | source/header only |
| HermiteCutRank | none | source/header only |
| TensorTrainCanonical | none | source/header only |
| TensorTrainNormEnvironment | none | source/header only |
| TensorTrainLocalCompiler | none | source/header only |
| TensorTrainWord | none | source/header only |
| TensorTrainPrimitivePreparation | none | source/header only |
| HermiteSmoothness | none | source/header only |
| HermiteTransferCores | none | source/header only |
| HermiteBinaryCutoff | none | source/header only |
| StoredHermiteChildGeometry | none | source/header only |
| StoredHermiteKernelTable | none | source/header only |
| ConcreteSemantics | none | source/header only |
| PrimitiveSemantics | none | source/header only |
| ReversibleClassical | none | source/header only |
| RectangularGivens | none | source/header only |

The first two records additionally have all 156 actual owned rows (98 Macros, 58 Uniform) equal to their separately compiled candidate observations in the joint stream. The other 24 rows have no new actual observation or new proof-body audit here; their old semantic evidence retains its old scope. The actual new Cubic target directly imports fresh CSP, and its 44 owned rows are covered by the separate 200-row C31 comparison; CSP's 768 rows and two type supplements are compared to its own actual candidate baseline. Neither should be confused with a registry claim that the 26 unrelated records were recompiled.

For integration:

1. Freeze the exact virtual replacement map of only two source hashes: CSP d125f8c239bca1c15e6e4fa6e788df6dd8984394630cb2dcc9be8946c4cbcb55 -> 6ee53311b5d6e18c46afb3e068341689acb86f1bdbc425e774705e81c9142f44 and Cubic 48c9a4a1c47c925c93493eede21eb7b492d23d2cb7dadf254782e4485c349cb3 -> 952e2b359796ef695a1b1c1a376d40a80affbc679f503f94227ea0c775a6cd48. Bind all other 140 production sources, 60 tests, three configs, selected source rows, selected declarations and graph metadata to their actual prospective bytes. A metadata change outside this map needs its own recorded delta, not a silent refresh.
2. Retain this explicit per-record zero-import-intersection certificate and each exact old evidence digest. For the 26 existing records, distinguish ambient-only digest invalidation from a changed selected theorem/definition. Provided selected source/contract/graph rows and relevant imports are unchanged, preserve old semantic judgments through truthful versioned owner carry-forward metadata; do not pretend the original artifact inspected a new global digest. Do not impersonate their original reviewers or reuse stale binding fields as if current.
3. Issue new candidate/source-statement/StatementSeal versions for the two changed roots, with same statements/data definitions and explicit nine/three proof-site provenance. The complete raw-source seals must change, even though the mathematical source and statement/data-definition invariants do not. Fresh joint evidence here discharges Phase6's joint-provider uncertainty; the original CSP review owner's semantic scope and the independently authorized exact decoder successor still have their own final evidence obligations.
4. Compute actual new bindings only after final intended source-row and candidate metadata bytes exist, using the unchanged binding/checker contract. Bind the actual independent decoder/reviewer successor digests and original identities. This review neither supplies other reviewers' verdicts nor creates a global accepted state. Existing old files remain immutable; registry pointers, if authorized later, point to new files.
5. If installation changes anything beyond this frozen pair/explicit metadata overlay, or a record later imports either changed root, recompute its actual affected intersection and review that specific delta. No all-body/all-TCB rereview or arbitrary clean-transitive build is added for untouched records. Conversely, an empty header intersection is not a new full semantic audit of their proofs.

This is bounded semantic carry-forward, not blanket rehash: exact proof-only data/signature invariants, independently compared actual joint producer/consumer observations, a named per-record import partition, retained omission/trust limits, and honest late binding are all separate pieces.
