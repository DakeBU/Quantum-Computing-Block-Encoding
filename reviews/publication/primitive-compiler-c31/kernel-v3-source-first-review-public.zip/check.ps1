param([Parameter(Mandatory)][string]$Project,[Parameter(Mandatory)][string]$Capture,[Parameter(Mandatory)][string]$OldCapture)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
function Require($ok,$label){if(-not $ok){throw "INDEPENDENT_CHECK_FAILED: $label"}}
function HashBytes([byte[]]$b){[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($b)).ToLowerInvariant()}
function HashFile($p){HashBytes ([IO.File]::ReadAllBytes($p))}
function J($v){ConvertTo-Json -InputObject $v -Depth 100 -Compress}
function Equal($a,$b){(J $a) -ceq (J $b)}
function ParseRows([string]$text){
  $parts=@{}; $lines=@($text -split "`n" | Where-Object {$_ -ne ''})
  foreach($line in $lines){Require ($line -cmatch '^(C31_[A-Z_]+) (\{.*\})$') 'tagged complete stdout line'; $tag=$Matches[1]; $v=$Matches[2]|ConvertFrom-Json -AsHashtable; if(-not $parts.ContainsKey($tag)){$parts[$tag]=[Collections.Generic.List[object]]::new()}; $parts[$tag].Add($v)}
  Require ($lines.Count -eq 204) '204 lines'; Require ($parts.Count -eq 4) 'four exact tag families'; return $parts
}
$zip=[IO.Compression.ZipFile]::OpenRead($Capture)
try {
  Require ((HashFile $Capture) -ceq '3e69139f0a9e1d275bc2eb0b89a0bb36206501f2def3510ba4876ac20a6a7267') 'ZIP transport pin'
  Require ($zip.Entries.Count -eq 79) '79 public files'
  $texts=@{}; $members=@(); $memberMap=@{}
  foreach($e in $zip.Entries){
    Require ($e.FullName -notmatch '[/\\]' -and -not $memberMap.ContainsKey($e.FullName)) 'flat unique member name'
    $ms=[IO.MemoryStream]::new(); $s=$e.Open(); try{$s.CopyTo($ms); $b=$ms.ToArray()}finally{$s.Dispose();$ms.Dispose()}
    $texts[$e.FullName]=[Text.Encoding]::UTF8.GetString($b)
    $m=[ordered]@{path='$CAPTURE/'+$e.FullName;sha256=(HashBytes $b);bytes=$b.Length}; $members+=,$m; $memberMap[$e.FullName]=$m
    if($e.FullName.EndsWith('.json')){$null=$texts[$e.FullName]|ConvertFrom-Json -AsHashtable}
  }
  function ZJ($n){$texts[$n]|ConvertFrom-Json -AsHashtable}
  $receipts=ZJ 'raw-derivation-receipts.json'; Require ($receipts.files.Count -eq 78) '78 export receipts'
  $receiptNames=@{}; foreach($r in $receipts.files){Require (-not $receiptNames.ContainsKey($r.publicRelativePath)) 'unique receipt';$receiptNames[$r.publicRelativePath]=$true; Require ($memberMap[$r.publicRelativePath].sha256 -ceq $r.publicSHA256) ('public receipt '+$r.publicRelativePath)}
  Require (@($memberMap.Keys|Where-Object {$_ -ne 'raw-derivation-receipts.json' -and -not $receiptNames.ContainsKey($_)}).Count -eq 0) 'all public members receipted'
  $raw=[IO.File]::ReadAllBytes((Join-Path $Project 'QuantumBlockEncoding/CubicAmplitudePrimitive.lean'))
  Require ((HashBytes $raw) -ceq '48c9a4a1c47c925c93493eede21eb7b492d23d2cb7dadf254782e4485c349cb3') 'original target unchanged'
  $oldText=[Text.Encoding]::UTF8.GetString($raw)
  $sites=@([regex]::Matches($oldText,'(?m)^  (?:  )?native_decide \+revert$'))
  Require ($sites.Count -eq 3) 'three exact full proof lines'
  $patchSites=@(); foreach($m in $sites){$line=1+([regex]::Matches($oldText.Substring(0,$m.Index),"`n")).Count; $prefix=$oldText.Substring(0,$m.Index); $name=([regex]::Matches($prefix,'(?:theorem|lemma)\s+(\w+)'))[-1].Groups[1].Value; $patchSites+=,[ordered]@{sourceName=$name;line=$line;oldLine=$m.Value;newLine=$m.Value.Replace('native_decide','decide +kernel')}}
  Require ((J @($patchSites.sourceName)) -ceq (J @('cubicN2Amplitude_abs_le_one','cubicN2ControlIndex_encode','cubicN2EncodeBits_context_eq_iff'))) 'independent site identities'
  $expectedText=[regex]::Replace($oldText,'(?m)^(  (?:  )?)native_decide (\+revert)$','$1decide +kernel $2')
  $expected=[Text.Encoding]::UTF8.GetBytes($expectedText)
  $candidatePath='tools/c31_kernel_proof_v1/candidate/QuantumBlockEncoding/CubicAmplitudePrimitive.lean'
  $candidate=[IO.File]::ReadAllBytes((Join-Path $Project $candidatePath))
  Require ([Convert]::ToBase64String($expected) -ceq [Convert]::ToBase64String($candidate)) 'entire candidate exact three proof-line substitution'
  Require ((HashBytes $candidate) -ceq '952e2b359796ef695a1b1c1a376d40a80affbc679f503f94227ea0c775a6cd48') 'candidate pin'
  Require ($expectedText.Replace('decide +kernel +revert','native_decide +revert') -ceq $oldText) 'inverse full source equality'
  $originalProfile=Get-Content -Raw -LiteralPath (Join-Path $Project 'tools/c31_kernel_proof_v1/original-profile.json')|ConvertFrom-Json -AsHashtable
  $profile=Get-Content -Raw -LiteralPath (Join-Path $Project 'tools/c31_kernel_proof_v1/profile.json')|ConvertFrom-Json -AsHashtable
  $clone=(J $profile)|ConvertFrom-Json -AsHashtable
  $rel='QuantumBlockEncoding/CubicAmplitudePrimitive.lean'; $clone.projectInputs[$rel]=HashBytes $raw
  $changedModules=0; foreach($m in $clone.modules){if($m.module -ceq 'QuantumBlockEncoding.CubicAmplitudePrimitive'){$m.rawSHA256=HashBytes $raw;$changedModules++}}
  Require ($changedModules -eq 1 -and (Equal $clone $originalProfile)) 'profile changes only two target source hashes'
  $input=ZJ 'input-bindings.json'; $prep=ZJ 'candidate-input-bindings.json'
  Require ($input.projectInputs.Count -eq 31 -and $prep.inputCopies.Count -eq 31 -and $profile.projectInputs.Count -eq 31) '31 exact input pins'
  $inputRows=@(); foreach($r in $input.projectInputs){$p=if($r.relativePath -ceq $rel){Join-Path $Project $candidatePath}else{Join-Path $Project $r.relativePath}; $actual=HashFile $p; Require ($actual -ceq $r.sha256 -and $actual -ceq $profile.projectInputs[$r.relativePath]) ('source pin '+$r.relativePath); $copy=@($prep.inputCopies|Where-Object relativePath -CEQ $r.relativePath); Require ($copy.Count -eq 1) 'unique input copy'; foreach($k in @('sha256','sourceSHA256Before','sourceSHA256After')){Require ($copy[0][$k] -ceq $actual) 'copy source pin'}; $inputRows+=,[ordered]@{path='$PROJECT/'+$r.relativePath;sha256=$actual;bytes=$r.bytes}}
  $new=ParseRows $texts['30-observe.stdout.raw.sanitized.txt']
  $oldStreamPath=Join-Path $OldCapture '30-observe.stdout.raw.sanitized.txt'
  Require ((HashFile $oldStreamPath) -ceq 'a1c6025fa6f90eb449a08a6857da2f858757282bba775b3767135dce2cc63c2b') 'previously reviewed actual stdout pin'
  $old=ParseRows ([IO.File]::ReadAllText($oldStreamPath))
  $rows=@($new.C31_ROOT_JSON)+@($new.C31_GENERATED_JSON); $oldRows=@($old.C31_ROOT_JSON)+@($old.C31_GENERATED_JSON)
  Require ($new.C31_ROOT_JSON.Count -eq 87 -and $new.C31_GENERATED_JSON.Count -eq 113 -and $new.C31_BINDING_JSON.Count -eq 3 -and $new.C31_SUMMARY_JSON.Count -eq 1) 'exact partitions'
  $om=@{};foreach($r in $oldRows){Require (-not $om.ContainsKey($r.actualName)) 'unique old actual identity';$om[$r.actualName]=$r}
  $nm=@{};foreach($r in $rows){Require (-not $nm.ContainsKey($r.actualName)) 'unique new actual identity';$nm[$r.actualName]=$r}
  $native=@($oldRows|Where-Object actualAxiomInfo|ForEach-Object actualName);Require ($native.Count -eq 3) 'old actual axiom set three'
  $removed=@($om.Keys|Where-Object {-not $nm.ContainsKey($_)}|Sort-Object);$added=@($nm.Keys|Where-Object {-not $om.ContainsKey($_)}|Sort-Object)
  Require ((J $removed) -ceq (J @($native|Sort-Object))) 'exact removal actual old native three'
  Require ($added.Count -eq 3) 'three dynamic generated additions'
  $comparisons=@();$changedAxiomRows=0;$typesBytes=0;$axiomUnion=[Collections.Generic.HashSet[string]]::new()
  foreach($r in $rows){
    Require ($r.kernelRootPresent -eq $true -and $r.kernelTypeAndUniversesAgree -eq $true -and $r.actualKind -ceq $r.kernelKind) 'ci/ki explicit guard'
    Require (-not $r.isUnsafe -and -not $r.actualAxiomInfo -and -not $r.selfOccursInAxioms) 'no actual unsafe/axiom/selfaxiom'
    Require ($r.typePrettyExplicit.Length -gt 0 -and $r.typePrettyExplicit -notmatch '⋯|\.\.\.|REDACTED') 'full nontruncated type text'
    Require ($r.valueTextRequested -eq $false -and $null -eq $r.valuePrettyExplicitAllowOpaque) 'honest value omission'
    $typesBytes += [Text.Encoding]::UTF8.GetByteCount($r.typePrettyExplicit)
    foreach($a in $r.axioms){$null=$axiomUnion.Add($a);Require ($a -notin $native) 'old native absent dependencies'}
    if($om.ContainsKey($r.actualName)){
      $o=$om[$r.actualName];Require ((J @($r.Keys|Sort-Object)) -ceq (J @($o.Keys|Sort-Object))) 'survivor fields identical'
      foreach($k in $r.Keys){if($k -notin @('axioms','selfOccursInAxioms')){Require (Equal $r[$k] $o[$k]) ('surviving complete field '+$k+' '+$r.actualName)}}
      $wanted=@($o.axioms|Where-Object {$_ -notin $native}|Sort-Object);$got=@($r.axioms|Sort-Object)
      Require ((J $wanted) -ceq (J $got)) ('exact recursive old minus three '+$r.actualName)
      if(-not (Equal @($o.axioms|Sort-Object) $got)){$changedAxiomRows++}
      $comparisons+=,[ordered]@{actualName=$r.actualName;state='SURVIVING';allNonAxiomFieldsExactlyEqual=$true;typeSHA256=(HashBytes ([Text.Encoding]::UTF8.GetBytes($r.typePrettyExplicit)));oldAxioms=$o.axioms;newAxioms=$r.axioms}
    }else{Require ($r.actualName -in $new.C31_GENERATED_JSON.actualName -and $r.actualKind -ceq 'thmInfo' -and $r.actualHasValueAllowOpaque) 'new generated actual theorem with value';$comparisons+=,[ordered]@{actualName=$r.actualName;state='NEW_GENERATED';observation=$r}}
  }
  Require ((J @($axiomUnion|Sort-Object)) -ceq (J @('Classical.choice','Quot.sound','propext'|Sort-Object))) 'exact remaining recursive axiom union'
  foreach($b in $new.C31_BINDING_JSON){$ob=@($old.C31_BINDING_JSON|Where-Object module -CEQ $b.module);Require ($ob.Count -eq 1 -and (Equal $b.structures $ob[0].structures) -and (Equal $b.ownedNames.Count $b.ownedCount)) 'structures and owned cardinality';Require ($b.freshOleanPathComparisonPassed -and $b.ownershipMethod -ceq 'ENVIRONMENT_MODULE_INDEX_NOT_NAME_PREFIX') 'actual ownership/path check';$names=@($rows|Where-Object module -CEQ $b.module|ForEach-Object actualName|Sort-Object);Require ((J $names) -ceq (J @($b.ownedNames|Sort-Object))) 'exhaustive module ownership'}
  foreach($p in $profile.roots){$matches=@($new.C31_ROOT_JSON|Where-Object {$_.module -ceq $p.module -and $_.sourceUserName -ceq $p.sourceUserName});Require ($matches.Count -eq 1 -and $matches[0].sourcePrivate -eq $p.sourcePrivate -and $matches[0].sourceKind -ceq $p.sourceKind) 'each original root contract identity'}
  $copies=ZJ 'provider-copies.json'; $providerSeeds=@($prep.providerSeedCopies|Where-Object {$_.ContainsKey('module')}); $helperSeeds=@($prep.providerSeedCopies|Where-Object {$_.ContainsKey('kind')}); Require ($copies.files.Count -eq 25 -and $providerSeeds.Count -eq 25 -and $helperSeeds.Count -eq 1 -and $helperSeeds[0].kind -ceq 'SHARED_HELPER_PIN_COPY_NOT_PROVIDER_ARTIFACT') 'two project-provider copy layers plus typed helper'
  $providerModules=@($profile.providers|Sort-Object)
  Require ((J @($copies.files.module|Sort-Object)) -ceq (J $providerModules)) 'exact profile project provider set'
  foreach($r in $copies.files){$seed=@($providerSeeds|Where-Object module -CEQ $r.module);Require ($seed.Count -eq 1 -and $seed[0].sha256 -ceq $r.sha256 -and $seed[0].destination -ceq $r.source) 'provider two-hop hash chain';$suffix=$r.module.Replace('.','/')+'.olean';Require ($seed[0].source -ceq ('$PROJECT/.lake/build/lib/lean/'+$suffix) -and $r.destination -ceq ('$CANDIDATE_WORKSPACE/_out/primitive-compiler-native-profile-v1/cohort/'+$suffix)) 'provider exact endpoints'}
  $stages=@('01-help','02-prefix','11-target','12-target','13-target','21-driver','22-driver','30-observe');$stageRows=@();$minHeadroom=[long]::MaxValue
  foreach($stage in $stages){$s=ZJ ($stage+'.setup.json');$r=ZJ ($stage+'.result.json');$start=ZJ ($stage+'.started.json');$o=ZJ ('ci2-'+$stage+'.observation.json');Require ($r.exitCode -eq 0 -and -not $r.timedOut -and $r.PID -eq $start.PID -and (Equal $o.nativeResult $r)) 'actual process receipt';Require ($o.classification -ceq 'PROCESS_EXIT_ZERO' -and $o.actualStreamHashesMatch -and $o.actualPIDResultReceiptsMatch) 'process linkage'; Require ($memberMap[$stage+'.stderr.raw.sanitized.txt'].bytes -eq 0) 'all stderr empty'; if($stage -notin @('01-help','02-prefix')){Require ('--threads=1' -in $s.argv -and '--memory=5120' -in $s.argv -and $s.timeoutSeconds -le 900) 'finite actual process resources'}
    foreach($phase in @('preflight','postflight')){$p=ZJ ('ci2-'+$stage+'.'+$phase+'.json');Require ($p.gatePassed -and $p.observationComplete -and $p.budgetMiB -eq 5120 -and $p.reserveMiB -eq 2048 -and $p.effectiveHeadroomBytes -ge 7516192768) 'resource gate';$minHeadroom=[Math]::Min($minHeadroom,[long]$p.effectiveHeadroomBytes);Require ($p.fileReads.Count -eq 11 -and $p.namespaceReads.Count -eq 1 -and $p.readAttempts.Count -eq 12) 'complete resource attempts';foreach($cg in $p.cgroups){Require ($cg.memoryEvents.oom -eq 0 -and $cg.memoryEvents.oom_kill -eq 0) 'no sampled OOM'};Require ($p.rootObservation.type -ceq 'DOCUMENTED_TRUE_ROOT_NOT_APPLICABLE_NOT_UNLIMITED') 'root NA not unlimited'}
    $stageRows+=,[ordered]@{label=$stage;pid=$r.PID;exitCode=$r.exitCode;wallSeconds=$r.wallSeconds;actualMemoryMiB=if($stage -in @('01-help','02-prefix')){$null}else{5120};stdoutPublicSHA256=$memberMap[$stage+'.stdout.raw.sanitized.txt'].sha256;stdoutRawSHA256=$r.stdoutSHA256;timeoutSeconds=$s.timeoutSeconds}
  }
  $fresh=ZJ 'fresh-target-cohort.json';Require ($fresh.targets.Count -eq 3 -and $fresh.cohortID -ceq $new.C31_SUMMARY_JSON[0].cohortID) 'fresh three/cohort linkage'
  for($i=0;$i -lt 3;$i++){$f=$fresh.targets[$i];$r=ZJ ($stages[2+$i]+'.result.json');Require ((Equal $f.nativeResult $r) -and $f.sourceSHA256Before -ceq $f.sourceSHA256After -and $f.sourceSHA256Before -ceq $f.copiedSourceSHA256) 'fresh process/source pin';$sourceRel=$f.module.Replace('.','/')+'.lean';Require ($f.copiedSourceSHA256 -ceq $profile.projectInputs[$sourceRel]) 'fresh source profile';$b=@($new.C31_BINDING_JSON|Where-Object module -CEQ $f.module)[0];Require ($b.resolvedOleanPath -ceq $f.artifacts[0].path) 'fresh resolved observed path'}
  $exec=ZJ 'executing-code-bindings.json';Require ($exec.entry.sourceSHA256 -ceq (HashFile (Join-Path $Project 'tools/c31_kernel_proof_v3/entry.py'))) 'executed entry source pin';foreach($m in $exec.modules){Require ($m.sourceSHA256 -ceq (HashFile (Join-Path $Project ('tools/c31_kernel_proof_v1/'+($m.actualFile -split '/')[-1])))) 'actual imported source pin'}
  Require ($exec.guardProfileSHA256 -ceq (HashFile (Join-Path $Project 'tools/c31_kernel_proof_v3/profile.json')) -and $exec.guardManifestSHA256 -ceq (HashFile (Join-Path $Project 'tools/c31_kernel_proof_v3/bindings.json'))) 'actual guard data pins'
  $kernelProfile=Get-Content -Raw -LiteralPath (Join-Path $Project 'tools/c31_kernel_proof_v1/kernel-profile.json')|ConvertFrom-Json -AsHashtable
  $necessaryCode=@(); foreach($pkg in $kernelProfile.runtimePackages.Keys){foreach($name in $kernelProfile.runtimePackages[$pkg].Keys){if($name -match '^(runner(?:_v[234])?\.py|validator\.py|resource_gate(?:_v[34])?\.py|Collector\.lean|pending-drivers/(Profile|Probe)\.lean)$'){$path=$pkg+'/'+$name;$h=HashFile (Join-Path $Project $path);Require ($h -ceq $kernelProfile.runtimePackages[$pkg][$name]) ('previously reviewed necessary code pin '+$path);$necessaryCode+=,[ordered]@{path='$PROJECT/'+$path;sha256=$h;readMode='Previously read source; current byte-pin recheck, not reread of excluded results'}}}}
  $inv=ZJ 'provider-inventory.json';$helper=ZJ 'shared-helper-copy.json';Require (-not $helper.copiedHelperExecuted -and $helper.sha256 -ceq $helper.destinationSHA256 -and $helper.sha256 -ceq $helper.executingAPISourceSHA256) 'helper data copy not execution'
  [ordered]@{schema='C31_SOURCE_FIRST_KERNEL_V3_INDEPENDENT_CHECK_V1';identity='/root/primitive_compiler_source_first_c31';transportSHA256=(HashFile $Capture);publicFiles=$members;proofChange=[ordered]@{originalSHA256=(HashBytes $raw);candidateSHA256=(HashBytes $candidate);originalBytes=$raw.Length;candidateBytes=$candidate.Length;sites=$patchSites;entireOtherSourceBytesEqual=$true;profileOnlyTwoTargetPinsChange=$true};inputPins=$inputRows;actual=[ordered]@{roots=87;privateRoots=@($new.C31_ROOT_JSON|Where-Object actualPrivate).Count;generated=113;owned=200;surviving=197;removed=$removed;added=$added;changedAxiomRows=$changedAxiomRows;remainingAxioms=@($axiomUnion|Sort-Object);typeUTF8Bytes=$typesBytes;allValueTextOmitted=$true;modulePartitions=@($new.C31_BINDING_JSON|ForEach-Object {[ordered]@{module=$_.module;owned=$_.ownedCount;sourceRoots=$_.expectedRoots}});comparisons=$comparisons};processes=$stageRows;minimumSampledHeadroomBytes=$minHeadroom;cohortID=$fresh.cohortID;projectProviderCopies=25;externalInventoryArtifacts=$inv.artifacts.Count;externalSearchRoots=$inv.actualExternalSearchRoots.Count;absentConfiguredRoots=$inv.absentConfiguredRoots.Count;execution=$exec;testStatus='PASS_READ_ONLY_BYTES_JSON_NOT_LEAN';sourceAgreement=$null;axiomPolicyPass=$null;publicationBinding=$null;scientificAcceptance=$false;nativeAccepted=$false;trustClosure=$false}|ConvertTo-Json -Depth 100
} finally {$zip.Dispose()}
