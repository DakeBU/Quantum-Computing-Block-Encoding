# Phase8: released decoder comparison against the sealed original source-first judgment

Identity `/root/primitive_compiler_source_first_c31`; run `c31-source-first/phase8-joint-decoder-comparison-c38/20261017T032228Z`. Same original reviewer, original independent natural derivation and Phase7 judgment retained. Phase7 seal `9597644512de771c23c7d65570d38a54e49c99648f47ee96df457664234b0a0e` predates this explicitly authorized decoder release and was rehashed unchanged. No new blind identity or perpetual-blind claim is made.

## Bounded result

`DECODER_JOINT_ADDENDUM_CONCORDANT_WITH_INDEPENDENT_PHASE7_WHOLE_CUBIC_CANDIDATE_JUDGMENT`.

I found no mathematical or observed-contract discrepancy requiring reversal of my Phase7 whole-module source-side support. This applies to all 25 source roots/44 owned declarations of the exact finite n=2 Cubic candidate under the jointly fresh CSP-nine provider, not only three repaired lemmas. It remains a LOCAL source-reviewed candidate judgment, not final registry accepted evidence. Prospective candidate/source-statement/StatementSeal/global binding is still pending. SourceAgreement, axiom-policy admission, publication binding, nativeAccepted, main, scientific ROOT and PURIFIED are not granted.

The released decoder identity is `/root/primitive_compiler_formal_decoder_c31`, run `c38-raw-joint-replay-20261017-v1`. It explicitly discloses authoring the instrumentation and a continuation of its old formal-only reconstruction. This is a distinct reader/data calculation, not independent instrumentation authorship or a newly source-blind run. Its reference to prior whole-Cubic reconstruction SHA `457b369bcb1c98933f144551eb1ee82fcfb20d032437aa5b2536120a4d3c4309` is recorded as its immutable prior-provenance claim; that separate file was not reopened here. The whole-Cubic semantic comparison rests on my original source reasoning, already read whole target, proof-only byte invariants, and actual full-type objects, not that reference alone.

## Exact transport and independent row reconstruction

Decoder outer seal SHA is `5bac711b87c61f30b20c3b66d43ee957bcdc9721ffd20dfdb247f3b016f01bc1`; outer bindings SHA `732036b718c9b02495a71add5cd818c8509abbaaab3bd67cf5dba999ff0fb834`; final allowlist SHA `29a7c1cc5bbb2bcc19c60858f7d0a9aa1cabbf27b945f113a9916453612bbbc2`. All match actual bytes. The allowlist has exactly 23 unique public members, with exactly 21 manifest entries plus manifest and outer seal. I hash only those public members, not the excluded private process file/cache. Code and test receipt bytes are bound but their bodies/results are not used as mathematical evidence and no decoder code/tests were executed.

My new independent read-only Node checker directly parses pinned ZIP members without extracting files, importing decoder algorithms, or reading the author `joint-comparison.json`. Its input pins are joint `c540fc35303cf5c7f865d90cd4b3fbca3b3ef840bd926c743657e606e85b5d51`, separate C31 candidate `3e69139f0a9e1d275bc2eb0b89a0bb36206501f2def3510ba4876ac20a6a7267`, and separate CSP candidate `c1ed298ad9736c4ec3b4ab71b4324fa407a1415d7cf1c45350e0b12ef74f149d`.

For every one of the decoder's 200 C31 and 768 CSP owned records, I independently resolve its joint/baseline one-based line and tag, recalculate its canonical complete JSON-row SHA including original value text, and compare the complete raw objects between the same-candidate runs. All agree, matching my independently sealed Phase7 calculation. I also compare every captured nontext field against raw data; all complete actual/supplement type strings and hashes; direct kind/private/universe/value-availability/unsafe/axiom fields; and value-text hashes and omission flags. Every generated identity comes from actual stream rows, with case-sensitive matching, not guessed names or namespace ownership.

The two exact supplemental CSP full-type objects match the separately actual supplement and decoder's stored supplemental objects. They repair precisely the two type omissions in the joint/full v5 stream. The 96 CSP generated value texts containing ellipses remain incomplete; 22 generated value texts are null, and CSP's 319 source roots did not print bodies. C31's 200 value texts were not requested. Has-value is not printed-value evidence. No omitted body is silently filled, no lossless Expr serialization is claimed, and no new all-body prerequisite is introduced.

## Original native delta independently recomputed

This extends Phase7's same-candidate comparison with a direct original-production comparison. I pin original CSP public ZIP `a742a870d2475dd231029c01daa485e98043f2f8285888497dc4f1f15dde8658` and its actual `06-probe-v5` stream, and original C31 public stdout SHA `a1c6025fa6f90eb449a08a6857da2f858757282bba775b3767135dce2cc63c2b` from my original Phase3 input. No other reviewer's native-delta conclusion is substituted.

| Owned family | Original/joint rows | Exact removed native axioms | Actual generated additions | Surviving rows checked | Surviving native-dependent consumers |
| --- | --- | ---: | ---: | ---: | ---: |
| CSP | 769 /768 | 9 | 8 | 760 | 12 |
| C31 | 200 /200 | 3 | 3 | 197 | 21 |

Each removed identity is an actual owned axiomInfo/self-axiom in the original stream, not an imported axiom attributed by name prefix. The removed row set is exactly that native set; all added/removed full observation objects equal the decoder's corresponding objects. For every surviving declaration, the actual new recursive axiom set equals precisely the old set minus that native set, with no other addition or removal. Every decoder surviving-row delta agrees, including all actual consumers. The counts above exclude the removed self-axioms themselves; they are target-owned consumers, not a repository-wide downstream inventory.

CSP's removed native owners are `ratEuclideanOperatorNormErrorAtMost_not_vacuous`, `ratMatrixErrorAction_eq_diagonal`, `arithmeticRankOneCubicResourceTuple_n2_default`, `cubicNormSq_n1`, `cubicNormSq_n2`, `cubicNormSq_n3`, `hadamardCountingCubicResourceTuple_n2`, `hardModeLowerAgentSchedule_final`, `hardModeSchedules_have_four_levels`. Its local zero-subtraction proof is `exact Rat.sub_self`, so eight new generated proof constants for nine source edits is an observation, not a missing-row inference. C31's exact three native owners remain `cubicN2Amplitude_abs_le_one`, `cubicN2ControlIndex_encode`, `cubicN2EncodeBits_context_eq_iff`; they are not confused with the prior CSP repair. Full names, exact affected consumers and row evidence are retained in the independent index.

All surviving captured kind/private/universe/type-pretty fields also match. This does NOT assert a direct original full-signature comparison for the two original CSP generated types whose full signatures were never captured there. Equality of omitted pretty strings is only equality of captured fields. Their complete candidate/joint signatures are available and independently equal, and source-statement/data bytes remain unchanged, but missing original observations are not invented.

The joint owned closure union remains exactly Classical.choice, Quot.sound, propext, as in Phase7. This removes the specific 9+3 observed native-axiom obstacles within the fixed candidate/actual scope, not a universal claim of axiom freedom or scientific admission.

## Source and technical bridge

The decoder's nine CSP and three Cubic source-token byte coordinates and replacements were independently regenerated from the actual original source files, including each oldByteStart/oldByteEnd. Their complete reconstructed candidate hashes match the same `6ee53311b5d6e18c46afb3e068341689acb86f1bdbc425e774705e81c9142f44` and `952e2b359796ef695a1b1c1a376d40a80affbc679f503f94227ea0c775a6cd48` already sealed in Phase7. Its original/shadow 31-input maps match actual joint input records. Statements, binders, data definitions, imports/options, resource expressions and the remaining proof suffixes are not changed by these replacements. This is not a statement that every elaborated definition body was printed.

Decoder technical objects for cohort, runtime environment, executing-code bindings, inherited provider inventory, driver bindings, input copies, shadow input map, helper and provider copy chains all match the actual raw JSON objects. All eleven result/setup/PID objects match their raw stage objects. For every pre/post resource projection I compare the retained fields to raw receipts; its twelve combined file/link observations are exactly the original eleven file reads plus namespace read. I independently recalculate all 22 effective-headroom minima from MemAvailable and finite nonroot cgroup limits, retaining the same resource policy. This corroborates Phase7's four-target cohort `612290bf907a4a55b9ecb79ac379c263`, fresh CSP consumed before C31, 24 inherited providers, same-fresh CSP probes and finite process/resource scope.

The existing interface distinctions remain: C31 prints ci type/universes with explicit ci/ki equality guards; CSP's full v5 probe has kernel presence/kind agreement but not that stronger type/universe guard; the two-type supplement prints directly from kernelInfo. Axiom collection is Lean collectAxioms, not a claim every printed field came directly from ki. Public/raw SHA separation, unavailable raw proc-file bytes and hidden path spelling, inherited providers, no load trace/clean-transitive build, noncontinuous resource sampling, source-file rather than OS/code-object attestation all remain explicit. Artifact GITHUB_SHA e79996d... and parent API head ad025220... are not conflated. The decoder did not use the parent's optional merge-tree explanation; my separately authorized Phase7 reading of it is late context and not an independent API query.

## Whole module and seven slots

The decoder's finite block matrix `[[D,-S],[S,D]]`, with D=diag`((j/4)^3)` and S=diag`sqrt(1-((j/4)^3)^2)`, agrees with my original exact standard-RY convention and signal-major flattening j+4s. In particular the relative minus sign and zero global phase are preserved, and clean-block compression to D does not say the signal always returns to zero.

The prior corrected full Pi/binder/definition audit, 87-root coverage and 32-AND-tail source graph remain valid for the unchanged statements/data, including the finite compiler-definition tail, direct versus recursive denotation, both required branch cases, local phase OR, and separate unitary/clean/wrapper/count obligations. No graph/StatementSeal is silently rebound here. Generic Prop witnesses remain distinct from concrete physics, and omitted precision/scalable routes remain omitted.

- target: entire concrete finite n=2 cubic diagonal module/verified wrapper; no arbitrary-width cubic or rank-one loader result.
- normalization: clean-block normalizer 1, not normalized coefficient-vector preparation.
- registers: system wires 0/1, signal 2, little-endian j+4s, full context; generic control map need not be injective, but every control avoids target.
- oracles: zero opaque oracle calls for the literal primitive list, not free exact-angle generation.
- ancillas_phases: one clean signal, no extra pure ancilla, exact program/macro phases; no quotienting away a global phase.
- error_success: ideal exact matrix/block; input-dependent success may be zero; no finite-bit synthesis or deterministic normalized-state guarantee.
- resources: definitional four RY/six CX n=2 gate list; no hardware/precision/depth-optimality claim; native verification budgets are a separate classical-process resource layer.

## Remaining minimal carry-forward contract; STOP

The decoder comparison obligation is now supported at this exact addendum digest, without inventing a final decoder evidence wrapper or registry result. The new candidate/source-statement/StatementSeal versions and prospective global/source-row binding are still needed before a final reviewer wrapper can reference an exact final decoder evidence SHA.

For the 26 pre-existing records, reuse the exact per-record Phase7 partition and hashes: none has a header-import path to either changed module; only Macros/Uniform received additional actual recompiled observations here. Do not open a new 26-module mathematical-review project. Minimal truthful transport is: freeze the two proof-only replacements and explicit intended metadata/source-row delta; retain each old selected statement/data/semantic-slot/graph invariant and its original evidence identity/digest; disclose ambient-only digest changes; have the appropriate original owners issue versioned carry-forward bindings/opaque binding labels for the exact new manifest without claiming a new blind reading or new actual compilation of the other 24. If selected semantic payload changes, review only that concrete delta. Final digests must be computed from the actual intended metadata bytes under the unchanged contract, not guessed here or filled by another owner's impersonated verdict. The two new candidate records are separate from those 26.

No author joint-comparison, unrelated CI5 material, decoder program/test execution, Lean, Git, network, production or registry mutation occurred. The only new outputs are this bounded package. No arbitrary all-TCB/all-body requirement is added. Original files stay sealed; STOP after handoff.
