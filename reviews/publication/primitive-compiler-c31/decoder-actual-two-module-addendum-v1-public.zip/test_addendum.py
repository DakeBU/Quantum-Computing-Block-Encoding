import json
from pathlib import Path
import unittest
import pi_contracts as pi

PACKAGE=Path(__file__).parent


class PiTests(unittest.TestCase):
    def test_implicit_instance_arrow_and_nested_types(self):
        rows,body=pi.pi_type('{index : Type u_1} → [Fintype.{u_1} index] → [DecidableEq.{u_1 + 1} index] → (index → Complex) → Complex')
        self.assertEqual([r['kind'] for r in rows],['implicit','instance','instance','explicit'])
        self.assertEqual(body,'Complex')
        rows,_=pi.pi_type('∀ {q k : Nat} (w : Fin k → Fin q) (h : ∀ (i : Fin k), w i ≠ w i), True')
        self.assertEqual([r['name'] for r in rows],['q','k','w','h'])

    def test_inner_let_source_signature_recovery_not_old_packet_edit(self):
        record=dict(kind='theorem',sourceName='f',signatureSource='theorem f : let x : Nat',
            completeFormalRegion='theorem f : let x : Nat := 1; x = 1 := by rfl')
        header,rows,body=pi.source_pi(record)
        self.assertEqual(header,'theorem f : let x : Nat := 1; x = 1')
        self.assertEqual(record['signatureSource'],'theorem f : let x : Nat')

    def test_missing_hidden_binder_and_visibility_mismatch_detected(self):
        source,_=pi.pi_type('∀ {q : Nat} (t : Fin q), True')
        actual,_=pi.pi_type('∀ (q : Nat) (t : Fin q), True')
        self.assertTrue(pi.align(source,actual)['issues'])
        self.assertFalse(pi.align(source,actual[1:])['sameArity'])
        with self.assertRaises(ValueError): pi.pi_type('∀ {q : Nat (t : Fin q), True')

    def test_complete_actual_two_module_partition_and_all_root_pi(self):
        report=json.loads((PACKAGE/'report.json').read_text(encoding='utf-8'))
        roots=json.loads((PACKAGE/'root-contract-comparisons.json').read_text(encoding='utf-8'))['roots']
        generated=json.loads((PACKAGE/'generated-observations.json').read_text(encoding='utf-8'))['rows']
        self.assertEqual(len(roots),62); self.assertEqual(len(generated),94)
        self.assertEqual(report['binderAlignmentIssues'],[])
        for row in roots:
            self.assertTrue(row['sourceBinderComparison']['sameArity'])
            self.assertEqual(row['sourceBinderComparison']['issues'],[])
            self.assertEqual(pi.pi_type(row['actualObservation']['typePrettyExplicit'])[0],
                [e['actual'] for e in row['sourceBinderComparison']['entries']])
        for module in report['modules']:
            observed=[r['actualObservation'] for r in roots if r['module']==module['module']]+[r for r in generated if r['module']==module['module']]
            self.assertEqual({r['actualName'] for r in observed},set(module['actualBinding']['ownedNames']))
            self.assertEqual(sorted({a for r in observed for a in r['axioms']}),module['actualRecursiveAxiomUnion'])
            self.assertEqual(module['actualNativeNamedDependencies'],[])
        self.assertEqual([r['name'] for r in report['oldCatalogDefects']],['QuantumBlockEncoding.hadamardMatrix_apply'])
        self.assertFalse(report['nativeAccepted']); self.assertIsNone(report['sourceAgreement'])


if __name__=='__main__': unittest.main()
