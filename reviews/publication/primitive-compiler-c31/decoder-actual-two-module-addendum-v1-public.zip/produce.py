"""Compare every own sealed source contract with authorized actual CI4 observations."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

import pi_contracts

MODULES=('QuantumBlockEncoding.PrimitiveMacros','QuantumBlockEncoding.UniformlyControlledRy')
NO_ACCEPT=dict(sourceAgreement=None,axiomPolicyPass=None,publicationBinding=None,
    scientificAcceptance=False,nativeAccepted=False,trustClosure=False)


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path): return json.loads(path.read_text(encoding='utf-8'))
def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as out: json.dump(value,out,indent=2,ensure_ascii=False); out.write('\n')


def calculate(project,source_root,public,kernel_package):
    if sha(kernel_package/'bindings.json')!='6a3bfa246013397e867d4c3427748abcb1faa17aa5b90ecd9889969640886057' or \
        sha(kernel_package/'seal.json')!='5ed9c0c9d9dcb5ce75bd79748e42efc504a631b5c61c326d5e8f6e66cd6ccf80':
        raise ValueError('own kernel technical package drift')
    for name,value in read(kernel_package/'bindings.json')['files'].items():
        if sha(kernel_package/name)!=value: raise ValueError('own technical code pin drift')
    old=sys.dont_write_bytecode; sys.dont_write_bytecode=True; sys.path.insert(0,str(kernel_package))
    try:
        if 'runtime' in sys.modules and Path(sys.modules['runtime'].__file__).resolve()!=(kernel_package/'runtime.py').resolve():
            raise ValueError('unexpected runtime module')
        import runtime
        config=read(kernel_package/'kernel-profile.json')
        ci4,ci2,base,p1,profile,api=runtime.load_runtime(project,config)
    finally: sys.path.pop(0); sys.dont_write_bytecode=old
    baseline=read(kernel_package/'baseline.json')
    runtime.verify(public,baseline['actualPublicMemberSHA256'])
    runtime.verify(project,profile['projectInputs'])
    seal=read(source_root/'source-formal-seal.json')
    if sha(source_root/'source-formal-seal.json')!=profile['sourceSealSHA256']: raise ValueError('old source seal drift')
    runtime.verify(source_root,seal['artifactBindings'])
    contracts=read(source_root/'declaration-contracts.json')['declarations']
    text=(public/'30-observe.stdout.raw.sanitized.txt').read_text(encoding='utf-8'); records=base.validator.parse(text)
    bindings=records['C31_BINDING_JSON']; summary=records['C31_SUMMARY_JSON'][0]
    base.validator.validate(profile,text,0,timed_out=False,profile_sha=sha(kernel_package/'original-profile.json'),
        cohort_id=summary['cohortID'],expected_oleans={r['module']:r['resolvedOleanPath'] for r in bindings})
    fresh=read(public/'fresh-target-cohort.json')
    for target in fresh['targets']:
        module=target['module']; expected=profile['projectInputs'][module.replace('.','/')+'.lean']
        if target['sourceSHA256Before']!=expected or target['sourceSHA256After']!=expected or \
            target['copiedSourceSHA256']!=expected or target['nativeResult']['exitCode']!=0 or target['nativeResult']['timedOut']:
            raise ValueError('actual raw source/fresh compilation binding drift')
    roots=[r for r in records['C31_ROOT_JSON'] if r['module'] in MODULES]
    generated=[r for r in records['C31_GENERATED_JSON'] if r['module'] in MODULES]
    by={(r['module'],r['sourceUserName']):r for r in roots}
    expected=[c for c in contracts if c['module'] in MODULES]
    if len(roots)!=62 or len(by)!=62 or set(by)!={(c['module'],c['name']) for c in expected}:
        raise ValueError('complete 62 source/root identity alignment failed')
    compared=[]; defects=[]; issues=[]
    for contract in expected:
        actual=by[contract['module'],contract['name']]
        if actual['actualPrivate']!=contract['private'] or actual['sourceKind']!=contract['kind']:
            raise ValueError('private/kind mismatch')
        header,source_binders,source_body=pi_contracts.source_pi(contract)
        actual_binders,actual_body=pi_contracts.pi_type(actual['typePrettyExplicit'])
        aligned=pi_contracts.align(source_binders,actual_binders)
        if aligned['issues']: issues.append(dict(name=contract['name'],issues=aligned['issues']))
        note=None
        if header!=contract['signatureSource']:
            if contract['kind']=='structure': note='Structure constructor type view separates header from four fields; field metadata is separately preserved'
            else:
                note='OLD_CATALOG_SIGNATURE_TRUNCATED_AT_INNER_LET_ASSIGNMENT; recovered from same sealed completeFormalRegion, not an edit of old packet'
                defects.append(dict(name=contract['name'],oldSignature=contract['signatureSource'],recoveredHeader=header))
        compared.append(dict(module=contract['module'],ordinal=contract['ordinal'],name=contract['name'],
            sourceKind=contract['kind'],sourcePrivate=contract['private'],sourceLine=contract['line'],
            oldSealedSourceSignature=contract['signatureSource'],recoveredCompleteHeader=header,catalogNote=note,
            sealedCompleteRegionSHA256=hashlib.sha256(contract['completeFormalRegion'].encode()).hexdigest(),
            sealedReconstructedMeaning=contract['reconstructedMeaning'],
            sourceBinderComparison=aligned,sourceResultText=source_body,
            actualResultTextAfterLeadingPi=actual_body,actualObservation=actual,
            comparisonBoundary='Complete pretty-type retained; binder arity/name/visibility structurally aligned. Source notation and elaborated result/type text are not asserted string-identical or cross-environment kernel-defeq. Mathematical reading uses the same pinned formal source/fresh-cohort binding; no natural-source comparison.'))
    modules=[]
    for module in MODULES:
        part=[r for r in roots+generated if r['module']==module]; binding=next(b for b in bindings if b['module']==module)
        if {r['actualName'] for r in part}!=set(binding['ownedNames']): raise ValueError('whole-owned target partition')
        union=sorted({a for r in part for a in r['axioms']})
        modules.append(dict(module=module,sourceRoots=sum(r['module']==module for r in roots),
            generated=sum(r['module']==module for r in generated),owned=len(part),
            privateSourceRoots=sum(r['sourcePrivate'] for r in roots if r['module']==module),
            actualRecursiveAxiomUnion=union,
            actualNativeNamedDependencies=[a for a in union if 'native_decide' in a or '._native.' in a],
            actualUnsafe=sum(r['isUnsafe'] for r in part),actualSelfAxioms=sum(r['selfOccursInAxioms'] for r in part),
            actualAxiomInfo=sum(r['actualKind']=='axiomInfo' for r in part),actualBinding=binding))
    report=dict(scope='ONLY_TWO_UNCHANGED_MODULES_FROM_OWN_ACTUAL_CI4',modules=modules,
        comparedSourceRoots=len(compared),generatedObserved=len(generated),wholeOwnedObserved=len(roots)+len(generated),
        binderAlignmentIssues=issues,oldCatalogDefects=defects,
        oldSourceSealSHA256=sha(source_root/'source-formal-seal.json'),
        oldContractsSHA256=sha(source_root/'declaration-contracts.json'),
        oldReconstructionSHA256=sha(source_root/'formal-only-reconstruction.md'),
        actualStreamSHA256=sha(public/'30-observe.stdout.raw.sanitized.txt'),
        actualFreshReceiptSHA256=sha(public/'fresh-target-cohort.json'),
        actualPublicInputsSHA256=baseline['actualPublicMemberSHA256'],
        localLeanInvocationCount=0,oldPacketChanged=False,readerReviewerPacketRead=False,
        admission='PARENT_OWNED_NOT_PERFORMED',**NO_ACCEPT)
    return report,compared,generated


if __name__=='__main__':
    project,source_root,public,kernel_package=map(lambda p:Path(p).resolve(),sys.argv[1:5])
    report,roots,generated=calculate(project,source_root,public,kernel_package)
    package=Path(__file__).parent
    write(package/'report.json',report); write(package/'root-contract-comparisons.json',dict(roots=roots,**NO_ACCEPT))
    write(package/'generated-observations.json',dict(rows=generated,**NO_ACCEPT))
    print(json.dumps(dict(modules=[{k:m[k] for k in ('module','sourceRoots','generated','owned','actualRecursiveAxiomUnion','actualSelfAxioms')} for m in report['modules']],
        comparedRoots=report['comparedSourceRoots'],binderAlignmentIssues=report['binderAlignmentIssues'],catalogDefectNames=[r['name'] for r in report['oldCatalogDefects']]),ensure_ascii=False))
