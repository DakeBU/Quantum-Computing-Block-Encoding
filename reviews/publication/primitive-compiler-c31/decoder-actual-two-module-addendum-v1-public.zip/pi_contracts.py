"""Finite pretty-Pi/source-header comparison; never a kernel Expr serializer."""
import re

PAIRS={'(':')','{':'}','[':']'}


def group(text):
    if not text or text[0] not in PAIRS: raise ValueError('expected grouped binder')
    stack=[]; quoted=False; escape=False
    for i,c in enumerate(text):
        if quoted:
            if escape: escape=False
            elif c=='\\': escape=True
            elif c=='"': quoted=False
            continue
        if c=='"': quoted=True; continue
        if c in PAIRS: stack.append(PAIRS[c])
        elif c in PAIRS.values():
            if not stack or c!=stack.pop(): raise ValueError('unbalanced binder')
            if not stack: return text[:i+1],text[i+1:].lstrip()
    raise ValueError('unterminated binder')


def top_index(text,token):
    stack=[]; quoted=False; escape=False
    for i,c in enumerate(text):
        if not quoted and not stack and text.startswith(token,i): return i
        if quoted:
            if escape: escape=False
            elif c=='\\': escape=True
            elif c=='"': quoted=False
        elif c=='"': quoted=True
        elif c in PAIRS: stack.append(PAIRS[c])
        elif c in PAIRS.values():
            if not stack or c!=stack.pop(): raise ValueError('unbalanced type')
    return -1


def binder(raw):
    body=raw[1:-1].strip(); colon=top_index(body,':')
    kind={'(':'explicit','{':'implicit','[':'instance'}[raw[0]]
    if colon<0:
        if kind!='instance': raise ValueError('untyped grouped binder')
        return [dict(name=None,kind=kind,typeText=body,raw=raw)]
    names=body[:colon].split(); typ=body[colon+1:].strip()
    if not names: raise ValueError('empty names')
    return [dict(name=n,kind=kind,typeText=typ,raw=raw) for n in names]


def pi_type(text):
    remaining=text.strip(); out=[]
    while True:
        if remaining.startswith('∀ '):
            comma=top_index(remaining,',')
            if comma<0: raise ValueError('forall missing outer comma')
            part=remaining[2:comma].strip()
            while part:
                raw,part=group(part); out.extend(binder(raw))
            remaining=remaining[comma+1:].strip(); continue
        arrow=top_index(remaining,'→')
        if arrow<0: break
        left=remaining[:arrow].strip()
        if left and left[0] in PAIRS:
            raw,tail=group(left)
            if not tail and (raw[0]=='[' or top_index(raw[1:-1],':')>=0):
                out.extend(binder(raw))
            else: out.append(dict(name=None,kind='explicit',typeText=left,raw=left))
        else: out.append(dict(name=None,kind='explicit',typeText=left,raw=left))
        remaining=remaining[arrow+1:].strip()
    return out,remaining


def source_header(record):
    region=record['completeFormalRegion']
    if record['kind'] in ('theorem','lemma'):
        match=re.search(r':=\s*by\b',region)
        if not match: return record['signatureSource']
        return region[:match.start()].rstrip()
    if record['kind']=='structure': return region.split(' where',1)[0].rstrip()
    return record['signatureSource']


def source_pi(record):
    header=source_header(record)
    match=re.search(r'\b(?:def|theorem|lemma|abbrev|structure)\s+'+re.escape(record['sourceName'])+r'\b',header)
    if not match: raise ValueError('source declaration identity delimiter')
    tail=header[match.end():].strip(); out=[]
    while tail and tail[0] in PAIRS:
        raw,tail=group(tail); out.extend(binder(raw))
    if tail.startswith(':'):
        more,body=pi_type(tail[1:]); out+=more
    else: body=tail
    return header,out,body


def align(source,actual):
    if len(source)!=len(actual): return dict(sameArity=False,entries=[],issues=['arity'])
    entries=[]; issues=[]
    for i,(a,b) in enumerate(zip(source,actual),1):
        # Pretty nondependent arrows erase names. Anonymous instance names may
        # be assigned by elaboration; neither is an extra hypothesis.
        name_ok=a['name'] is None or b['name'] is None or a['name']==b['name']
        kind_ok=a['kind']==b['kind']
        if not name_ok or not kind_ok: issues.append(str(i)+':name/visibility')
        entries.append(dict(ordinal=i,source=a,actual=b,nameCompatible=name_ok,visibilityEqual=kind_ok,
            typeTextComparison='Source notation versus elaborated qualified text; both retained, not string-equated'))
    return dict(sameArity=True,entries=entries,issues=issues)
