from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import produce

FILES=['README.md','pi_contracts.py','produce.py','test_addendum.py','freeze.py','report.json',
    'root-contract-comparisons.json','generated-observations.json','python-tests.json','bindings.json','seal.json']


def freeze(project,source_root,public,kernel_package):
    package=Path(__file__).parent
    def check():
        report,roots,generated=produce.calculate(project,source_root,public,kernel_package)
        if report!=produce.read(package/'report.json') or roots!=produce.read(package/'root-contract-comparisons.json')['roots'] or \
            generated!=produce.read(package/'generated-observations.json')['rows']:
            raise ValueError('actual addendum derivation drift')
        return report
    report=check(); started=datetime.now(timezone.utc).isoformat()
    command=[sys.executable,'-B','-m','unittest','discover','-s',str(package),'-p','test_addendum.py','-v']
    child=subprocess.Popen(command,cwd=project,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    raw,_=child.communicate(timeout=60)
    sanitized=raw.decode('utf-8').replace(str(package),'$ADDENDUM')
    produce.write(package/'python-tests.json',dict(PID=child.pid,exitCode=child.returncode,
        startedUTC=started,finishedUTC=datetime.now(timezone.utc).isoformat(),rawStdoutSHA256=hashlib.sha256(raw).hexdigest(),
        stdoutSanitized=sanitized,kind='ACTUAL_PYTHON_ONLY_NO_LEAN',**produce.NO_ACCEPT))
    print(sanitized)
    if child.returncode!=0: raise ValueError('Python test failure')
    check()
    files={p.name:produce.sha(p) for p in package.iterdir() if p.is_file() and p.name not in ('bindings.json','seal.json')}
    if set(files)!=set(FILES)-{'bindings.json','seal.json'}: raise ValueError('package partition drift')
    produce.write(package/'bindings.json',dict(files=files))
    seal=dict(state='INDEPENDENT_FINITE_TWO_MODULE_ACTUAL_CONTRACT_ADDENDUM_NOT_ADMISSION',
        UTC=datetime.now(timezone.utc).isoformat(),manifestSHA256=produce.sha(package/'bindings.json'),
        sourceSealSHA256=report['oldSourceSealSHA256'],actualStreamSHA256=report['actualStreamSHA256'],
        rootsCompared=62,generatedObserved=94,ownedObserved=156,implicitPiAlignmentIssues=0,
        oldCatalogSignatureDefects=1,oldCatalogDefectName='QuantumBlockEncoding.hadamardMatrix_apply',
        publicSafeReviewAllowlist=FILES,oldFilesChanged=False,localLeanInvocationCount=0,
        sourceFirstReportRead=False,admission='PARENT_OWNED_PENDING',**produce.NO_ACCEPT)
    produce.write(package/'seal.json',seal)
    print(json.dumps(dict(manifestSHA256=seal['manifestSHA256'],sealSHA256=produce.sha(package/'seal.json'),files=len(FILES))))


if __name__=='__main__': freeze(*map(lambda s:Path(s).resolve(),sys.argv[1:5]))
