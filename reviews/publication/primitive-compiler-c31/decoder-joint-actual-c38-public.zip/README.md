# C38 joint actual formal-result reconstruction

Identity: `/root/primitive_compiler_formal_decoder_c31`; role: formal-only decoder.
Run: `c38-raw-joint-replay-20261017-v1`. This is continuation of my original
formal-only reconstruction, not a new source-blind run. I authored the joint
instrumentation. The new replay is a separate, direct calculation over raw
sanitized JSON streams; it neither imports the runtime comparator nor reads its
joint-comparison result as evidence. No source-first reviewer, natural source,
author candidate narrative, registry, or acceptance wrapper was read.

## Finite result

The same candidates, now compiled in one four-target cohort, retain **all captured
row fields** of their separately actual baselines: CSP319 explicit +449 generated,
C31 87 explicit +113 generated, total968. Actual names/roles, kinds, privacy,
universe lists, implicit-Pi-inclusive type text, unsafe flags, value availability,
recursive axioms, and captured value text all compare equal. Generated names are
the actual rows emitted by environment-module ownership enumeration, not a
guessed generated-name list. All actual structure constructors/fields are checked
for row membership and actual kind; structure records also remain identical.

Two CSP generated proof signatures contain omissions in the legacy v5 printer.
The actual two-types streams from each run exactly cover those names and compare
equal with no omission glyphs. Ninety-six CSP generated **value** texts still have
omission glyphs, exactly as before. They are retained as incomplete body text, not
treated as incomplete types or silently promoted to complete values. C31 did not
request ordinary value text; `hasValueAllowOpaque` is an actual availability
observation, not a claim that a body was printed. The full immutable raw member
and JSON-line reference plus canonical row hash preserve the exact captured
value text; `whole-owned.json` retains all non-text fields, complete type text,
value-text hashes, and omission flags without another fourteen-megabyte copy.

All968 observed recursive axiom closures contain only `Classical.choice`,
`Quot.sound`, and/or `propext`. Compared directly to precisely pinned original
production raw observations, nine CSP and three C31 self native axioms disappear;
the removed-name sets are exactly those12. CSP adds eight ordinary generated
rows; C31 adds three. All surviving recursive closures equal their old closure
minus those native axioms:12 CSP and21 C31 surviving owned consumers were affected.
This is a target-owned consumer inventory, not a claim about every downstream
consumer in the repository. Original CSP did not have the two supplemental full
signatures in that archive; no original full-signature comparison is invented.

## Source and environment relation

The31 original source/config bytes are rehashed before and after replay. Candidate
CSP is `6ee53311b5d6e18c46afb3e068341689acb86f1bdbc425e774705e81c9142f44`;
candidate Cubic is `952e2b359796ef695a1b1c1a376d40a80affbc679f503f94227ea0c775a6cd48`.
Independently rebuilding the nine/three exact proof-token edits reproduces both
candidates byte-for-byte. All statements, binders, ordinary data definitions,
remaining proof suffixes, imports and options are unchanged. This does not claim
that every definition body was printed by a collector.

CSP compiled before Macros, Uniform and Cubic, into cohort
`612290bf907a4a55b9ecb79ac379c263`. The four compile receipts bind source-before,
copied-source, source-after, output paths/hashes, PID/exit/UTC, and one cohort.
Both CSP probes' raw binding rows and actual environment resolve its exact fresh
path. C31 raw rows resolve their three fresh modules. All relevant child search
paths have that cohort first, driver second, and the inventoried external roots;
the four targets are absent from the24 inherited project provider seeds. The
source imports and these receipts support joint provider consumption. This is
not an OS load trace: undeclared/dynamic loads are not independently traced.

Eleven actual native children have unique PIDs, zero exits, no timeout, serial UTC
intervals, and actual `--memory=5120 --threads=1`. Help/prefix append those flags;
compiler/probe calls replace only the prior3072 budget. Every child has a complete
Linux CI preflight/postflight chain; preflight effective headroom is recalculated
as the minimum of actual MemAvailable and every finite nonroot cgroup headroom,
and must be at least5120+2048MiB. The namespace self fingerprint and documented
true-root-not-applicable observation remain distinct from unlimited; PID1 was
not requested. Raw resource-file contents are not in the public archive: their
hashes and read-attempt records are chain observations, not locally re-read Linux
interfaces. Public logical cgroup coordinates do not reconstruct hidden raw path
spelling. No Windows/local Lean run occurred. The observed interval fits2100s;
per-child timeout is bounded900s.

The24 project provider artifacts and external Lean/library artifacts are inherited,
not clean-transitively rebuilt. The OS artifact inventory is not a load trace or
a new complete TCB audit. Entry/main/argv0, the three actual loaded source-file
paths/hashes, reused guard, copied helper and executing original helper are bound;
that is source-file observation, not OS/code-object attestation.

## Mathematical carryforward

This joint calculation does not redo an author's interpretation of CSP319 roots.
It retains the exact formal contracts of the separately actual candidate, now
with the provider consumed in the same fresh environment. My original whole-C31
source reconstruction and actual continuation remain immutable. For the concrete
Cubic part this still means the finite two-system-bit construction: wire0 is the
least significant system bit, wire1 the other, wire2 the signal, and encode(s,j)
=j+4s. With a_j=(j/4)^3, j=0..3, the full unitary is [[D,-S],[S,D]], D=diag(a_j),
S=diag(sqrt(1-a_j^2)), preserving the relative signs/phases. Signal-zero compression
is D, not a claim that the signal returns zero on every input. There are zero extra
pure ancillas beyond the signal; the generic controlled compiler's control/target
alias hypotheses remain, and the concrete controls0/1 are distinct from signal2.
No arbitrary-width cubic theorem, free angle-synthesis assumption, or benchmark
claim is added by changing proof tactics. My prior25-declaration Cubic reconstruction
is referenced by immutable hash in `readscope.json`; it is not edited here.

## Provenance and limits

Joint ZIP SHA256:
`c540fc35303cf5c7f865d90cd4b3fbca3b3ef840bd926c743657e606e85b5d51`.
Parent reports job117288170050/run38995863052, artifact12087176088, API head
ad02522. Artifact context independently contains GITHUB_SHA
`e79996d363d1c4fa591a45718d8286a6dfbce5ce`. These are distinct observations;
no API was fetched here and exact executed checkout SHA is not independently
attested. Parent's optional merge-tree explanation is not needed or used.
Repository-wide counts such as202 must not be called202 production modules:
the parent scope is142 production +60 test Lean files; this replay hashes only
its stated31 source/config vector, not that wider scope.

Every public member's actual bytes are rehashed against its raw-derivation
receipt. Where redaction changed bytes, only the unavailable raw digest chain is
checked; public hashes never stand in for original raw hashes. Archive authenticity
and remote process execution are bounded by the exact parent-supplied capture.
No old comparator verdict or Python test is substituted for native evidence.
All sourceAgreement/axiomPolicyPass/publicationBinding remain null; scientific
acceptance/nativeAccepted/trustClosure remain false. No ROOT/PURIFIED/main or
admission conclusion is authorized.

## Reproduce / rollback

Run `python freeze.py --workspace <workspace> --project <read-only-project>` from
this package for the direct replay and real Python-child tests. Output generation
is local JSON only. It performs no Lean, network or Git action. An existing seal
causes refusal; use a new versioned directory for changes. Rollback is simply to
ignore this addendum; all prior artifacts and production remain byte-identical.
Only exact `allowlist.json` members may be transported. `private-python-process.json`
and `__pycache__` are explicitly excluded; actual host paths stay private. There is
no workflow/controller/acceptance delta.
