"""Generate a new local artifact and run Python tests; never invoke Lean/Git/network."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import replay

PUBLIC = ['replay.py','test_replay.py','freeze.py','README.md','readscope.json',
          'summary.json','whole-owned.json','technical-chain.json','source-delta.json',
          'original-native-delta.json','artifact-bindings.json','python-tests.json',
          'development-diagnostics.json','allowlist.json','bindings.json','seal.json']


def output(path, data):
    raw = (json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode()
    replay.require(not path.exists(), 'refuse artifact overwrite: '+path.name)
    path.write_bytes(raw)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--workspace', type=Path, required=True); ap.add_argument('--project', type=Path, required=True)
    args = ap.parse_args(); home = Path(__file__).resolve().parent
    replay.require(not (home/'seal.json').exists(), 'already sealed')
    replay.require(set(PUBLIC) == set(PUBLIC) and len(PUBLIC) == len(set(PUBLIC)), 'allowlist collision')
    result = replay.run(args.workspace, args.project)
    packet = args.project/'reviews/publication/primitive-compiler-c31/decoder-c31'
    old_cubic = args.workspace/'.c31-kernel-v3-actual-decoder-addendum-v1/Cubic-reconstruction.md'
    replay.require(replay.sha((packet/'source-formal-seal.json').read_bytes()) == '0fd3e599c0532c6e308dbb87b26b420f939886d9d39de89c419692946f40cd68', 'original source-only seal')
    replay.require(replay.sha(old_cubic.read_bytes()) == '457b369bcb1c98933f144551eb1ee82fcfb20d032437aa5b2536120a4d3c4309', 'own prior whole Cubic reconstruction')
    scope = dict(schema='C38_BOUNDED_FORMAL_ACTUAL_READSCOPE_V1', identity='/root/primitive_compiler_formal_decoder_c31',
                 purpose='Same-candidate joint formal environment relation from raw actual rows, not scientific admission',
                 authorizedArchives={
                     '$CAPTURE/public-artifact.zip':replay.PINS['joint'],
                     '$PROJECT/reviews/publication/primitive-compiler-c31/kernel-v3-actual-success-public.zip':replay.PINS['c31'],
                     '$PROJECT/reviews/publication/cubic-source-c29/kernel-two-types-v2-actual-public.zip':replay.PINS['csp'],
                     '$PROJECT/reviews/publication/cubic-source-c29/ci3-formal-runtime-public.zip':replay.PINS['originalCSP'],
                     '$PROJECT/tools/cubic_c29_kernel_ci1/public-runtime-package.zip':replay.PINS['candidateArchive']},
                 originalC31MemberVectorBoundByManifest='73761459f5dd7f59b70beaf7c92758d04f6b97cbda39be7373c4eedd17812901',
                 originalSourceOnlyPacket=dict(logicalPath='$PROJECT/reviews/publication/primitive-compiler-c31/decoder-c31',sealSHA256='0fd3e599c0532c6e308dbb87b26b420f939886d9d39de89c419692946f40cd68'),
                 ownPriorWholeCubicReconstruction=dict(logicalPath='$PRIOR_DECODER/Cubic-reconstruction.md',sha256='457b369bcb1c98933f144551eb1ee82fcfb20d032437aa5b2536120a4d3c4309'),
                 rawStreams=['30-observe.stdout.raw.sanitized.txt','40-csp-probe.stdout.raw.sanitized.txt','41-csp-two-types.stdout.raw.sanitized.txt'],
                 rawReferenceConvention='jointRef/baselineRef line is one-based in the respective family raw stream; rowSHA256 hashes canonical complete emitted JSON, value text included',
                 exactTextRecovery='C31 joint and baseline 30-observe; CSP joint40-csp-probe, baseline cubic-c29-kernel-only-v1/public/04-full-kernel-candidate-probe; full types joint41 and baseline cubic-c29-kernel-types-v2/public/05-two-kernel-types',
                 hashOnlyNotInterpreted=['joint-comparison.json','joint-result.json','result.json','completeness.json','relational-axiom-signature-comparison.json','baseline-observations.json'],
                 sourceBytes='Hashes and proof-token-only deterministic transformations; nested comments masked before token recognition; formal strings preserved as data',
                 previousScopes='Original C31 formal-only whole-source reconstruction; later own actual technical evidence and authorized CSP formal candidate/actual technical inputs',
                 excluded=['author/natural-source packages','source-first reviewer material','registry/admission conclusions','raw unsanitized metadata/logs','other agents mathematics'],
                 instrumentAuthorship='I authored the reused runtime; new direct data replay is not independent instrumentation authorship or a fresh source-blind claim',
                 localLeanChildren=0, **replay.NO_ACCEPT)
    output(home/'readscope.json', scope)
    mapping = {'summary.json':'summary','whole-owned.json':'wholeRows','technical-chain.json':'technical','source-delta.json':'source',
               'original-native-delta.json':'originalNativeDelta','artifact-bindings.json':'artifactBindings'}
    for name, key in mapping.items(): output(home/name, result[key])
    output(home/'development-diagnostics.json', dict(
        firstReplayAttempt=dict(status='FAILED_BEFORE_SEAL', exception='ValueError', message='only finite memory adaptation',
            actualCause='New replay initially expected only a3072 replacement; actual help/prefix append5120/thread1 flags',
            correction='Separate exact help/prefix argument contract; actual run artifacts unchanged',
            sourceRevisionWasNotSealed=True, nativeChildrenStarted=0),
        earlierShellDiagnostic=dict(status='NO_PYTHON_STARTED', reason='Workspace .venv/Scripts/python.exe did not exist; actual existing Python311 used instead'),
        initialPythonTests=dict(actualRun=True, tests=28, failures=0, sourceThenUnsealed=True), **replay.NO_ACCEPT))
    env = dict(os.environ); env['C38_PROJECT'] = str(args.project.resolve())
    started = datetime.now(timezone.utc).isoformat(); began = time.monotonic()
    proc = subprocess.Popen([sys.executable,str(home/'test_replay.py')],cwd=home,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    try:
        stdout, stderr = proc.communicate(timeout=120); timed_out=False
    except subprocess.TimeoutExpired:
        proc.kill(); stdout,stderr=proc.communicate(); timed_out=True
    finished = datetime.now(timezone.utc).isoformat()
    private = dict(PID=proc.pid,exitCode=proc.returncode,timedOut=timed_out,startedUTC=started,finishedUTC=finished,
                   actualArgv=[sys.executable,str(home/'test_replay.py')],actualCwd=str(home),project=str(args.project),
                   stdout=stdout.decode('utf-8'),stderr=stderr.decode('utf-8'),wallSeconds=time.monotonic()-began)
    output(home/'private-python-process.json', private)
    replay.require(proc.returncode == 0 and not timed_out and b'Ran 28 tests' in stderr and stderr.rstrip().endswith(b'OK'), 'Python tests failed; no seal')
    # Passing unittest output contains only test names and durations, no host paths.
    receipt = dict(PID=proc.pid,exitCode=proc.returncode,timedOut=timed_out,startedUTC=started,finishedUTC=finished,wallSeconds=private['wallSeconds'],
                   actualInterpreterSHA256=replay.sha(Path(sys.executable).read_bytes()), argvLogical=['$PYTHON311','$ADDENDUM/test_replay.py'],
                   tests=28,failures=0, stdoutSHA256=replay.sha(stdout),stderrSHA256=replay.sha(stderr),
                   stdout=stdout.decode(),stderr=stderr.decode(), privateActualReceiptSHA256=replay.sha((home/'private-python-process.json').read_bytes()),
                   sourcePins={n:replay.sha((home/n).read_bytes()) for n in ('replay.py','test_replay.py','freeze.py')},
                   boundary='Actual Python tests, not Lean evidence; actual paths excluded, raw private receipt digest retained', **replay.NO_ACCEPT)
    output(home/'python-tests.json',receipt)
    output(home/'allowlist.json',dict(schema='EXACT_PUBLIC_ALLOWLIST_V1',members=PUBLIC,
                 privateExcluded=['private-python-process.json','__pycache__/**'], noImplicitGlobPublication=True,
                 noHostPathsInPublic=True,rollback='Ignore this new addendum; no prior artifacts/production modified',**replay.NO_ACCEPT))
    # Artifact generation is mechanical; existing source files are never rewritten.
    filepins={n:replay.sha((home/n).read_bytes()) for n in PUBLIC if n not in ('bindings.json','seal.json')}
    output(home/'bindings.json',dict(schema='C38_DECODER_ADDENDUM_FILES_V1',files=filepins, archivePins=replay.PINS,**replay.NO_ACCEPT))
    output(home/'seal.json',dict(schema='C38_DECODER_ADDENDUM_SEAL_V1',manifestSHA256=replay.sha((home/'bindings.json').read_bytes()),
                 allowlistSHA256=replay.sha((home/'allowlist.json').read_bytes()),actualPythonReceiptSHA256=replay.sha((home/'python-tests.json').read_bytes()),
                 sourceZIP=replay.PINS['joint'], identity='/root/primitive_compiler_formal_decoder_c31',localLeanChildren=0,**replay.NO_ACCEPT))
    for n in PUBLIC:
        raw=(home/n).read_bytes()
        replay.require(b'C:/Users/' not in raw and b'C:\\Users\\' not in raw and b'D:/Users/' not in raw, 'host path public leak: '+n)
    print(json.dumps({n:replay.sha((home/n).read_bytes()) for n in ('summary.json','whole-owned.json','python-tests.json','bindings.json','seal.json')},indent=2))


if __name__ == '__main__': main()
