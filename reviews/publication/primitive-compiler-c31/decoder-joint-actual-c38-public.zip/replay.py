"""C38 direct public-byte replay. No imports of runtime/validator/comparator code.

This decoder authored the joint runtime. Independence here is of the new data
calculation, not instrumentation authorship, OS attestation, or a new blind run.
"""
import argparse
from collections import Counter
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import zipfile

PINS = {
    'joint': 'c540fc35303cf5c7f865d90cd4b3fbca3b3ef840bd926c743657e606e85b5d51',
    'c31': '3e69139f0a9e1d275bc2eb0b89a0bb36206501f2def3510ba4876ac20a6a7267',
    'csp': 'c1ed298ad9736c4ec3b4ab71b4324fa407a1415d7cf1c45350e0b12ef74f149d',
    'originalCSP': 'a742a870d2475dd231029c01daa485e98043f2f8285888497dc4f1f15dde8658',
    'candidateArchive': 'dd55fbd7a9e9ad8dd9168109271433c71ec4c26687a196e42584e3aceeb5d54e',
}
NO_ACCEPT = dict(sourceAgreement=None, axiomPolicyPass=None, publicationBinding=None,
                 scientificAcceptance=False, nativeAccepted=False, trustClosure=False)
SHARED = '61733fc92f5e99672e0ce0260ff397e07c94a349e98e12c48dd6a3171d5a75d9'
PROFILE = '3e9193d85397211508c09a44e44e2d44b51a24196d278fc32dcaf07196e99950'
C31PROFILE = '955a1300915eff199d59d9d0bb864090ae398fa1560548f397d621e4f3cb6943'
MANIFEST = '58bd63b45f9ac0ee1bdd9c787a0d050a5b02cb3f0e2aa431010b6712f09a0168'
FRESH = '$JOINT_WORKSPACE/_out/primitive-compiler-native-profile-v1/cohort'
DRIVER = '$JOINT_WORKSPACE/_out/primitive-compiler-native-profile-v1/driver'
ORDER = ['QuantumBlockEncoding.CubicStatePreparation', 'QuantumBlockEncoding.PrimitiveMacros',
         'QuantumBlockEncoding.UniformlyControlledRy', 'QuantumBlockEncoding.CubicAmplitudePrimitive']
LABELS = ['01-help', '02-prefix', '10-csp-target', '11-target', '12-target', '13-target',
          '21-driver', '22-driver', '30-observe', '40-csp-probe', '41-csp-two-types']
STANDARD = {'Classical.choice', 'Quot.sound', 'propext'}
KINDS = {'def': 'defnInfo', 'theorem': 'thmInfo', 'structure': 'inductInfo',
         'opaque': 'opaqueInfo', 'axiom': 'axiomInfo'}


def require(ok, message):
    if not ok: raise ValueError(message)


def sha(data): return hashlib.sha256(data).hexdigest()
def canonical(x): return json.dumps(x, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()
def pairs(items):
    result = {}
    for key, value in items:
        require(key not in result, 'duplicate JSON key: ' + key)
        result[key] = value
    return result
def parse(data): return json.loads(data, object_pairs_hook=pairs)
def read(path): return parse(path.read_bytes())
def digest_ok(x): return isinstance(x, str) and re.fullmatch('[0-9a-f]{64}', x) is not None
def omitted(text): return isinstance(text, str) and any(g in text for g in ('…', '⋯'))
def utc(x):
    value = datetime.fromisoformat(x)
    require(value.tzinfo is not None, 'unqualified UTC')
    return value


def archive(path, pin):
    data = path.read_bytes(); require(sha(data) == pin, 'archive pin')
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        require(len(names) == len(set(names)) and names, 'archive duplicate/empty')
        require(all(not n.startswith('/') and '..' not in Path(n).parts and not n.endswith('/') for n in names), 'unsafe member')
        result = {n: z.read(n) for n in names}
    require(sha(path.read_bytes()) == pin, 'archive drift')
    return result


def artifact(files):
    """Rehash public bytes. Raw bytes redacted by exporter are NOT rehashed."""
    rows = parse(files['raw-derivation-receipts.json'])['files']
    require(len(rows) == len({r['publicRelativePath'] for r in rows}), 'duplicate receipt')
    require({r['publicRelativePath'] for r in rows} == set(files) - {'raw-derivation-receipts.json'}, 'receipt partition')
    receipts = {r['publicRelativePath']: r for r in rows}
    same, redacted = [], []
    for name, row in receipts.items():
        require(digest_ok(row['rawSHA256']) and digest_ok(row['publicSHA256']), 'receipt digest')
        require(type(row['rawBytes']) is int and row['rawBytes'] >= 0, 'receipt raw byte count')
        require(sha(files[name]) == row['publicSHA256'], 'public byte digest: ' + name)
        if row['rawSHA256'] == row['publicSHA256']:
            require(row['rawBytes'] == len(files[name]), 'raw/public length')
            same.append(name)
        else: redacted.append(name)
    return receipts, dict(members=len(files), allPublicMemberSHA256={n: sha(v) for n, v in sorted(files.items())},
                         byteVerifiedRawEqualsPublic=sorted(same), unavailableRawDigestOnly=sorted(redacted))


def stream(data, family):
    allowed = {family + '_' + t + '_JSON' for t in ('ROOT', 'GENERATED', 'BINDING', 'SUMMARY')}
    if family == 'C29_TWO': allowed = {family + '_' + t + '_JSON' for t in ('TYPE', 'BINDING', 'SUMMARY')}
    result = []
    for index, line in enumerate(data.decode('utf-8').splitlines(), 1):
        tag, sep, text = line.partition(' ')
        require(sep and tag in allowed, 'unknown/blank/truncated stream line')
        row = parse(text); require(isinstance(row, dict), 'nonobject stream')
        require(row.get('nativeAccepted') is False and row.get('sourceAgreement') is None, 'stream acceptance drift')
        result.append((tag, row, index))
    require(result and result[-1][0] == family + '_SUMMARY_JSON', 'terminal summary')
    require(sum(t == family + '_SUMMARY_JSON' for t, _, _ in result) == 1, 'summary multiplicity')
    return result


def partition(records, family, specs, expected_roots):
    roots = [r for t, r, _ in records if t == family + '_ROOT_JSON']
    generated = [r for t, r, _ in records if t == family + '_GENERATED_JSON']
    names = [r['actualName'] for r in roots + generated]
    require(len(roots) == len(specs) == expected_roots and len(names) == len(set(names)), 'root/generated partition collision/count')
    for actual, spec in zip(roots, specs):
        for key in ('sourceUserName', 'sourcePrivate', 'sourceKind'):
            require(actual[key] == spec[key], 'explicit source binding: ' + key)
        require(actual['actualPrivate'] == spec['sourcePrivate'], 'actual private resolution')
        require(actual['actualKind'] == KINDS[spec['sourceKind']], 'actual root kind')
        if family == 'C31': require(actual['module'] == spec['module'], 'source module')
        else: require(actual['ordinal'] == spec['ordinal'], 'CSP ordinal')
    bindings = [r for t, r, _ in records if t == family + '_BINDING_JSON']
    summary = records[-1][1]
    rows = {r['actualName']: r for r in roots + generated}
    for row in rows.values():
        require(row['kernelRootPresent'] is True and isinstance(row['universeParameters'], list), 'kernel/universes missing')
        require(type(row['actualHasValueAllowOpaque']) is bool and type(row['isUnsafe']) is bool, 'value/unsafe missing')
        require(row['selfOccursInAxioms'] is (row['actualName'] in row['axioms']), 'self axiom membership')
        require(len(row['axioms']) == len(set(row['axioms'])), 'axiom duplicates')
        if family == 'C31':
            require(row['actualKind'] == row['kernelKind'] and row['kernelTypeAndUniversesAgree'] is True, 'kernel kind/type')
            require(row['valueTextRequested'] is False and row['valuePrettyExplicitAllowOpaque'] is None, 'C31 value scope')
    if family == 'C31':
        require(len(bindings) == 3 and len({r['module'] for r in bindings}) == 3, 'C31 module bindings')
        for b in bindings:
            owned = [r for r in rows.values() if r['module'] == b['module']]
            require(b['ownedCount'] == len(owned) == len(b['ownedNames']) and set(b['ownedNames']) == {r['actualName'] for r in owned}, 'exact actual owned names')
            require(b['expectedRoots'] == sum(r['module'] == b['module'] for r in roots), 'module roots')
            require(b['ownershipMethod'] == 'ENVIRONMENT_MODULE_INDEX_NOT_NAME_PREFIX', 'ownership API')
            require(b['ppDeepTerms'] is True and b['ppMaxSteps'] == 2000000 and b['maxRecDepth'] == 10000, 'type print bounds')
        require(summary['rootsCompleted'] == len(roots) and summary['generatedCompleted'] == len(generated) and summary['ownedCompleted'] == len(rows) and summary['privateCompleted'] == 8, 'C31 summary partition')
        require(summary['allNamesResolvedUniquely'] is True and summary['modulesCompleted'] == 3, 'C31 complete source resolution')
    else:
        require(len(bindings) == 1, 'CSP binding count')
        b = bindings[0]
        require(b['expectedNamedRoots'] == 319 and b['observedTargetOwnedConstants'] == len(rows), 'CSP actual owned count')
        require(summary['explicitRootsCompleted'] == len(roots) and summary['generatedTargetOwnedConstants'] == len(generated) and summary['observedTargetOwnedConstants'] == len(rows), 'CSP summary partition')
        require(summary['explicitPrivateCompleted'] == 50 and b['sourceOpaqueCount'] == 7, 'CSP private/opaque roots')
        require(summary['allExplicitNamesResolvedUniquely'] is True and summary['generatedTypeValueAxiomAuditCompleted'] == len(generated), 'CSP complete generated observations')
    structures = [s for b in bindings for s in b.get('structures', b.get('actualStructures', []))]
    for s in structures:
        require(s['actualName'] in rows and rows[s['actualName']]['actualKind'] == 'inductInfo', 'structure root')
        for f in s['fields']:
            require(f['projection'] in rows and rows[f['projection']]['actualKind'] == f['actualKind'], 'structure field membership/kind')
        for c in s['constructors']: require(c in rows and rows[c]['actualKind'] == 'ctorInfo', 'constructor membership')
    return dict(rows=rows, roots={r['actualName'] for r in roots}, generated={r['actualName'] for r in generated}, bindings=bindings, summary=summary,
                refs={r['actualName']: {'line': line, 'rowSHA256': sha(canonical(r)), 'tag': tag} for tag, r, line in records if 'actualName' in r})


def two_types(records, csp):
    bindings = [r for t, r, _ in records if t == 'C29_TWO_BINDING_JSON']
    rows = {r['actualName']: r for t, r, _ in records if t == 'C29_TWO_TYPE_JSON'}
    require(len(bindings) == 1 and len(rows) == 2 and records[-1][1]['completed'] == 2, 'two signature partition')
    b = bindings[0]
    require(set(b['expectedNames']) == set(rows) and b['ppDeepTerms'] is True and b['ppMaxSteps'] == 2000000 and b['maxRecDepth'] == 10000, 'two deep pp contract')
    gaps = {n for n, r in csp['rows'].items() if omitted(r['typePrettyExplicit'])}
    require(gaps == set(rows), 'supplement does not exactly cover type omissions')
    for n, row in rows.items():
        require(not omitted(row['typePrettyExplicit']) and row['valuesPrinted'] is False, 'two signature incomplete/value scope')
        for key in ('actualKind', 'kernelRootPresent', 'universeParameters', 'isUnsafe', 'axioms', 'selfOccursInAxioms'):
            require(row[key] == csp['rows'][n][key], 'supplement actual row mismatch')
    return dict(rows=rows, binding=b)


def compare(old, new, old_two, new_two):
    require(set(old['rows']) == set(new['rows']), 'same-candidate actual name drift')
    require(old['roots'] == new['roots'] and old['generated'] == new['generated'], 'same-candidate role drift')
    require(old_two == new_two, 'same-candidate supplemental type drift')
    result = []
    for name in sorted(new['rows']):
        a, b = old['rows'][name], new['rows'][name]
        require(a == b, 'same-candidate captured row drift: ' + name)
        require(set(b['axioms']) <= set(a['axioms']) <= STANDARD, 'axiom increase/nonstandard dependency')
        require(not b['selfOccursInAxioms'] and b['actualKind'] != 'axiomInfo', 'self/native axiom remains')
        full = new_two.get(name, {}).get('typePrettyExplicit', b['typePrettyExplicit'])
        require(not omitted(full), 'incomplete actual type')
        result.append(dict(actualName=name, role='source-root' if name in new['roots'] else 'generated',
                           baselineRef=old['refs'][name], jointRef=new['refs'][name], allCapturedFieldsIdentical=True,
                           capturedFields={k:v for k,v in b.items() if k not in ('typePrettyExplicit','valuePrettyExplicitAllowOpaque')},
                           actualKind=b['actualKind'], actualPrivate=b['actualPrivate'], universeParameters=b['universeParameters'],
                           actualHasValueAllowOpaque=b['actualHasValueAllowOpaque'], isUnsafe=b['isUnsafe'],
                           completeTypeSHA256=sha(full.encode()), typeFromSupplement=name in new_two,
                           typePrettyExplicitComplete=full,
                           valueTextSHA256=sha(b['valuePrettyExplicitAllowOpaque'].encode()) if isinstance(b.get('valuePrettyExplicitAllowOpaque'), str) else None,
                           valueTextOmitted=omitted(b.get('valuePrettyExplicitAllowOpaque')), axioms=b['axioms']))
    return result


def resource(s, before):
    require(all(s.get(k) is v for k, v in NO_ACCEPT.items()), 'resource acceptance fields')
    require(s['schema'] == 'C31_CI4_RESOURCE_SELF_NAMESPACE_V1' and s['observationComplete'] is True, 'resource incomplete')
    c = s['context']; require(c['platform'] == 'linux' and c['CI'] == c['GITHUB_ACTIONS'] == 'true' and c['RUNNER_OS'] == 'Linux', 'not explicit Linux CI')
    threshold = 7168 * 1024 * 1024
    require((s['budgetMiB'], s['reserveMiB'], s['requiredHeadroomBytes']) == (5120, 2048, threshold), 'resource threshold')
    require(s['cgroupVersion'] == 2 and s['cgroupMountRoot'] == '/', 'hidden cgroup root')
    ns = s['namespaceObservation']; require(ns['selfInode'] == ns['requiredInitInode'] == 4026531835 and ns['policy'] == 'SELF_ONLY_RESERVED_INIT_V1', 'namespace ambiguity')
    require(ns['pid1Observation'] == dict(status='NOT_REQUESTED_NOT_REQUIRED', readRequested=False, value=None), 'fake PID1')
    root = s['rootObservation']
    require(root['type'] == 'DOCUMENTED_TRUE_ROOT_NOT_APPLICABLE_NOT_UNLIMITED' and root['atVerifiedMountRoot'] is True and root['mountFSType'] == 'cgroup2' and root['mountRoot'] == '/' and root['namespaceObservation'] == ns, 'root applicability')
    require(root['coreControllerMemoryObserved'] is True and root['coreProcessCount'] > 0, 'root core observations')
    for name in ('memory.max', 'memory.current', 'memory.events'):
        require(root['memoryInterfaces'][name] == dict(applicability='DOCUMENTED_TRUE_ROOT_NOT_APPLICABLE_NOT_UNLIMITED', value=None, readRequested=False, unlimitedObserved=False), 'root NA/unlimited confusion')
    groups = s['cgroups']; require(groups and [g['logicalPath'] for g in groups] == ['$CGROUP_NONROOT_' + str(i) for i in range(len(groups))], 'nonroot ancestor partition')
    head = [s['memAvailableBytes']]; require(type(head[0]) is int and head[0] > 0, 'MemAvailable absent')
    for g in groups:
        require(g['atVerifiedMountRoot'] is False and type(g['memoryCurrentBytes']) is int and g['memoryCurrentBytes'] >= 0, 'nonroot current')
        if g['memoryMaxRaw'] == 'max':
            require(g['memoryMaxBytes'] is None and g['headroomBytes'] is None and g['limitUnlimited'] is True, 'unlimited consistency')
        else:
            maximum = int(g['memoryMaxRaw']); h = max(0, maximum - g['memoryCurrentBytes'])
            require(maximum >= 0 and g['memoryMaxBytes'] == maximum and g['headroomBytes'] == h and g['limitUnlimited'] is False, 'finite arithmetic')
            head.append(h)
        require({'low', 'high', 'max', 'oom', 'oom_kill'} <= g['memoryEvents'].keys() and all(type(v) is int and v >= 0 for v in g['memoryEvents'].values()), 'nonroot events')
    effective = min(head)
    require(s['effectiveHeadroomBytes'] == effective and s['gatePassed'] is (effective >= threshold), 'effective minimum')
    if before: require(effective >= threshold, 'pre-child threshold not met')
    needed = {'$PROC/meminfo', '$PROC/self/cgroup', '$PROC/self/mountinfo', '$PROC/self/ns/cgroup', '$CGROUP_REAL_ROOT/cgroup.controllers', '$CGROUP_REAL_ROOT/cgroup.procs'}
    needed |= {g['logicalPath'] + '/' + n for g in groups for n in ('memory.max', 'memory.current', 'memory.events')}
    reads = s['fileReads'] + s['namespaceReads']; attempts = s['readAttempts']
    require(len(reads) == len(attempts) == len(needed) and {r['logicalPath'] for r in reads} == {r['logicalPath'] for r in attempts} == needed, 'resource reads partition')
    require(s['failedReadLogicalPath'] is None and s['failedReadAtVerifiedMountRoot'] is None, 'resource failed read')
    for r in reads:
        a = [a for a in attempts if a['logicalPath'] == r['logicalPath']]
        require(len(a) == 1 and a[0]['status'] == 'READ_OK' and digest_ok(r['sha256']) and type(r['bytes']) is int and r['bytes'] >= 0, 'resource read receipt')
        require(all(a[0][k] == r[k] for k in ('sha256', 'bytes', 'atVerifiedMountRoot')), 'resource read binding')
    link = [r for r in reads if r['logicalPath'] == '$PROC/self/ns/cgroup'][0]
    require(link['sha256'] == sha(b'cgroup:[4026531835]') and link['bytes'] == 19, 'self namespace link bytes')
    return dict(startedUTC=s['startedUTC'], finishedUTC=s['finishedUTC'], memAvailableBytes=s['memAvailableBytes'],
                effectiveHeadroomBytes=effective, nonrootAncestors=len(groups), cgroups=groups,
                rootObservation=root, namespaceObservation=ns, context=c, fileReads=reads, readAttempts=attempts)


def processes(files, receipts):
    result = []; pids = set(); previous = None
    preparation = resource(parse(files['joint-preparation-resource.json']), True)
    for label in LABELS:
        r = parse(files[label + '.result.json']); setup = parse(files[label + '.setup.json']); start = parse(files[label + '.started.json'])
        obs = parse(files['ci2-' + label + '.observation.json'])
        require(type(r['PID']) is int and r['PID'] > 0 and r['PID'] == start['PID'] and r['PID'] not in pids, 'native PID')
        pids.add(r['PID'])
        require(r['exitCode'] == 0 and r['timedOut'] is False and r['wallSeconds'] >= 0, 'native did not exit zero')
        require(setup['startedUTC'] == r['startedUTC'] and utc(r['startedUTC']) <= utc(start['startedUTC']) <= utc(r['finishedUTC']), 'PID UTC chain')
        if previous is not None: require(previous <= utc(r['startedUTC']), 'overlapping Lean children')
        previous = utc(r['finishedUTC'])
        require(setup['argv'] == obs['actualArgv'] and '--threads=1' in setup['argv'] and '--memory=5120' in setup['argv'], 'actual native flags')
        adapted = [a.replace('--memory=3072', '--memory=5120') for a in obs['requestedArgv']]
        if label in ('01-help', '02-prefix'):
            adapted += ['--memory=5120', '--threads=1']
        require(adapted == setup['argv'], 'only finite memory/thread adaptation')
        require(obs['nativeResult'] == r and obs['exceptionType'] is None and obs['classification'] == 'PROCESS_EXIT_ZERO', 'actual process chain')
        snapshots = {}
        for when in ('preflight', 'postflight'):
            n = 'ci2-' + label + '.' + when + '.json'
            require(obs[when + 'SHA256'] == receipts[n]['rawSHA256'], 'resource raw digest chain')
            snapshots[when] = resource(parse(files[n]), when == 'preflight')
        for kind in ('stdout', 'stderr'):
            n = label + '.' + kind + '.raw.sanitized.txt'
            require(r[kind + 'SHA256'] == obs[kind + 'RawSHA256'] == receipts[n]['rawSHA256'], 'process raw stream chain')
        b = obs['binding']; require(b['jointProfileSHA256'] == PROFILE and b['jointManifestSHA256'] == MANIFEST and b['compileOrder'] == ORDER and b['wholeSeconds'] == 2100 and b['resourceContract'] == 'CI4_SELF_ONLY_5120_PLUS_2048_THREADS1', 'process finite binding')
        require(0 < setup['timeoutSeconds'] <= 900, 'native timeout')
        result.append(dict(label=label, result=r, setup=setup, pidReceipt=start, resource=snapshots))
    require((previous - utc(preparation['startedUTC'])).total_seconds() <= 2100, 'whole bounded interval')
    return dict(preparation=preparation, processes=result, serialChildren=len(result))


def cohorts(files, c31, csp, two, profile, c31profile):
    env = parse(files['runtime-environment.json']); joint = parse(files['joint-four-target-cohort.json'])
    csp_fresh = parse(files['joint-csp-fresh.json']); three = parse(files['fresh-target-cohort.json'])
    cid = env['cohortID']; require(isinstance(cid, str) and cid, 'cohort ID')
    require(env['C31_FRESH_ROOT'] == FRESH and env['profileSHA256'] == C31PROFILE and env['nativeMemoryMiB'] == 5120 and env['nativeThreads'] == 1, 'runtime environment')
    require(joint['compileOrder'] == ORDER and joint['cohortID'] == three['cohortID'] == cid and joint['targets'] == [csp_fresh] + three['targets'], 'four target cohort')
    for module, label, t in zip(ORDER, LABELS[2:6], joint['targets']):
        source = module.replace('.', '/') + '.lean'; output = FRESH + '/' + module.replace('.', '/') + '.olean'
        require(t['module'] == module and t['cohortID'] == cid and t['sourceSHA256Before'] == t['sourceSHA256After'] == t['copiedSourceSHA256'] == c31profile['projectInputs'][source], 'target source before/after/cohort')
        require(t['nativeResult'] == parse(files[label + '.result.json']), 'target PID receipt')
        require(any(a['path'] == output and digest_ok(a['sha256']) for a in t['artifacts']), 'fresh target artifact')
        setup = parse(files[label + '.setup.json']); require(output in setup['argv'], 'actual output argv')
        require(setup['selectedEnvironment']['LEAN_PATH'].split(':')[:2] == [FRESH, DRIVER], 'fresh target first search root')
    csp_path = FRESH + '/QuantumBlockEncoding/CubicStatePreparation.olean'
    require(csp_fresh['sourceArtifactInherited'] is False and csp_fresh['freshOlean'] == csp_path, 'CSP fresh not inherited')
    require(csp_fresh['freshOleanSHA256'] == csp_fresh['artifacts'][0]['sha256'], 'CSP artifact SHA chain')
    require(joint['bothCSPProbesSameFreshOlean'] == csp_path, 'merged CSP probe binding')
    for label, b in [('40-csp-probe', csp['bindings'][0]), ('41-csp-two-types', two['binding'])]:
        setup = parse(files[label + '.setup.json']); se = setup['selectedEnvironment']
        require(b['actualResolvedOleanPath'] == csp_path and b['freshOleanPathComparisonPassed'] is True and se['QBE_EXPECT_FRESH_OLEAN'] == csp_path, 'raw CSP actual resolve and environment')
        require(se['LEAN_PATH'].split(':')[:2] == [FRESH, DRIVER], 'CSP probe fresh search path')
    for b in c31['bindings']:
        require(b['cohortID'] == cid and b['profileSHA256'] == C31PROFILE and b['freshOleanPathComparisonPassed'] is True and b['resolvedOleanPath'] == FRESH + '/' + b['module'].replace('.', '/') + '.olean', 'C31 raw fresh resolve')
    inp = parse(files['joint-inputs.json']); observed = parse(files['input-bindings.json'])
    require(inp['originalProjectInputs'] == profile['originalProjectInputs'] and inp['shadowProjectInputs'] == c31profile['projectInputs'], 'joint exact source/config pins')
    require({r['relativePath']: r['sha256'] for r in inp['inputCopies']} == c31profile['projectInputs'] and len(inp['inputCopies']) == 31, 'shadow source copy vector')
    require({r['relativePath']: r['sha256'] for r in observed['projectInputs']} == c31profile['projectInputs'] and len(observed['projectInputs']) == 31, 'actual source/config vector')
    helper = inp['sharedHelperCopy']
    for key in ('sha256', 'sourceSHA256Before', 'sourceSHA256After', 'destinationSHA256', 'executingAPISourceSHA256'):
        require(helper[key] == SHARED, 'helper copy pin')
    require(helper['copiedHelperExecuted'] is False and helper['source'] == helper['executingAPIOrigin'] == '$PROJECT/tools/cubic_c29_diagnostic/runner.py' and helper['destination'] == '$JOINT_WORKSPACE/tools/cubic_c29_diagnostic/runner.py', 'helper copy/execution distinction')
    seeds = [r for r in inp['providerSeedCopies'] if 'module' in r]; copies = parse(files['provider-copies.json'])['files']
    require(len(inp['providerSeedCopies']) == 25 and len(seeds) == len(copies) == 24 and helper in inp['providerSeedCopies'], 'provider/helper typed partition')
    require({r['module'] for r in seeds} == {r['module'] for r in copies} == set(c31profile['providers']) and not set(ORDER) & set(c31profile['providers']), 'four targets excluded from inherited cohort')
    for row in copies:
        seed = [s for s in seeds if s['module'] == row['module']]; require(len(seed) == 1, 'provider collision')
        rel = row['module'].replace('.', '/') + '.olean'
        require(row['source'] == seed[0]['destination'] == '$JOINT_WORKSPACE/.lake/build/lib/lean/' + rel and row['destination'] == FRESH + '/' + rel and row['sha256'] == seed[0]['sha256'] and digest_ok(row['sha256']), 'inherited provider SHA/copy chain')
    code = parse(files['executing-code-bindings.json']); e = code['entry']
    require(e['actualFile'] == e['actualMainModuleFile'] == e['actualArgv0Resolved'] == e['expectedLogicalFile'] == '$JOINT_PACKAGE/entry.py' and e['sourceSHA256'] == profile['_entrySHA256'], 'actual executing entry')
    require(code['sourceFileObservationOnly'] is True and code['OSAttestation'] is False and code['codeObjectAttestation'] is False, 'entry boundary')
    expected = {'runtime.py': '704b91c0e83adf57adc15c57d225dba2393a4248a3f0dc25d586ca3ec53dd313', 'compare.py': '119f209497c3a463fb3c3d733620232e69d21774a05cd16e456fd9b49b36d70a', 'proof_patch.py': 'f2376032bdcb9206240d24f7456ce4677d553af4e0ad7beb443e0a9d1874b93c'}
    require(len(code['modules']) == 3, 'loaded module partition')
    for name, pin in expected.items():
        matches = [m for m in code['modules'] if m['actualFile'] == '$PROJECT/tools/c31_kernel_proof_v1/' + name]
        require(len(matches) == 1 and matches[0]['sourceSHA256'] == pin and matches[0]['expectedLogicalFile'] == '$KERNEL_V1_PACKAGE/' + name, 'actual loaded source pin')
    inventory = parse(files['provider-inventory.json'])
    require(inventory['mode'] == 'ACTUAL_OS_ARTIFACT_INVENTORY_NOT_LOAD_TRACE' and digest_ok(inventory['leanBinarySHA256']), 'provider inventory mode/binary pin')
    wanted_search = ':'.join([FRESH, DRIVER] + inventory['actualExternalSearchRoots'])
    require(env['LEAN_PATH'] == wanted_search, 'runtime effective search root vector')
    for label in LABELS[2:]:
        se = parse(files[label + '.setup.json'])['selectedEnvironment']
        require(se['LEAN_PATH'] == wanted_search, 'per-child exact effective search path')
    require(joint['CSPProbeNativeResult'] == parse(files['40-csp-probe.result.json']) and joint['twoTypesNativeResult'] == parse(files['41-csp-two-types.result.json']), 'merged probe PID chains')
    require(code['jointComparisonModule']['actualFile'] == '$JOINT_PACKAGE/joint_compare.py' and code['jointComparisonModule']['sourceSHA256'] == profile['_comparatorSHA256'], 'runtime comparator source identity only')
    require(code['reusedGuardAPI']['actualFile'] == '$PROJECT/tools/c31_kernel_proof_v3/entry.py' and code['reusedGuardAPI']['sourceSHA256'] == '2b0332e8ad5b59a6a17e8df3bcd5d49869a644d0c10467813e730e614edb4cc4', 'reused guard source identity')
    return dict(cohort=joint, inputCopies=inp['inputCopies'], shadowProjectInputs=inp['shadowProjectInputs'], inherited24=seeds, providerCopies=copies,
                helper=helper, runtimeEnvironment=env, executingCodeBindings=code,
                providerInventory=inventory, driverBindings=parse(files['driver-bindings.json']))


def production_delta(old, new):
    a, b = old['rows'], new['rows']
    native = {n for n, r in a.items() if r['actualKind'] == 'axiomInfo' and r['selfOccursInAxioms'] and 'native_decide' in n}
    removed, added = set(a) - set(b), set(b) - set(a)
    require(native and removed == native, 'original removed set is not exactly self native axioms')
    rows = []
    for n in sorted(set(a) & set(b)):
        require(set(b[n]['axioms']) <= set(a[n]['axioms']) - native, 'original-production axiom increase')
        rows.append(dict(actualName=n, oldAxioms=a[n]['axioms'], newAxioms=b[n]['axioms'], removedNativeDependencies=sorted(set(a[n]['axioms']) & native),
                         exactOldMinusNative=set(b[n]['axioms']) == set(a[n]['axioms']) - native))
    require(not any(r['selfOccursInAxioms'] or r['actualKind'] == 'axiomInfo' or set(r['axioms']) - STANDARD for r in b.values()), 'joint native/nonstandard residual')
    return dict(originalOwned=len(a), jointOwned=len(b), removedNativeAxioms=sorted(removed), removedObservedRows={n:a[n] for n in sorted(removed)},
                addedObservedRows={n: b[n] for n in sorted(added)}, survivingAxiomRows=rows,
                survivingNativeConsumers=sum(bool(r['removedNativeDependencies']) for r in rows),
                allSurvivingAxesExactlyOldMinusNative=all(r['exactOldMinusNative'] for r in rows),
                scope='Recursive axiom closures and actual owned-name delta; original full supplemental two types were not available here')


def mask_comments(raw):
    out = bytearray(raw); i = 0; depth = 0; line = string = escape = False
    while i < len(raw):
        pair = raw[i:i+2]
        if line:
            if raw[i] in (10, 13): line = False
            else: out[i] = 32
            i += 1; continue
        if depth:
            if pair == b'/-': out[i:i+2] = b'  '; depth += 1; i += 2
            elif pair == b'-/': out[i:i+2] = b'  '; depth -= 1; i += 2
            else:
                if raw[i] not in (10, 13): out[i] = 32
                i += 1
            continue
        if string:
            if escape: escape = False
            elif raw[i] == 92: escape = True
            elif raw[i] == 34: string = False
            i += 1; continue
        if pair == b'--': out[i:i+2] = b'  '; line = True; i += 2
        elif pair == b'/-': out[i:i+2] = b'  '; depth = 1; i += 2
        else:
            if raw[i] == 34: string = True
            i += 1
    require(not depth and not string, 'source tokenizer incomplete')
    return bytes(out)


def proof_delta(old, new, special_line=None):
    matches = list(re.finditer(rb'\bnative_decide\b', mask_comments(old)))
    rebuilt = old; sites = []
    for m in reversed(matches):
        line = old[:m.start()].count(b'\n') + 1
        replacement = b'exact Rat.sub_self' if line == special_line else b'decide +kernel'
        rebuilt = rebuilt[:m.start()] + replacement + rebuilt[m.end():]
        sites.append(dict(line=line, oldByteStart=m.start(), oldByteEnd=m.end(), replacement=replacement.decode()))
    require(rebuilt == new, 'changes beyond exact proof tokens')
    return list(reversed(sites))


def run(workspace, project):
    joint_path = workspace/'hermite-export-work/c38-joint-kernel-actual-success/public-artifact.zip'
    joint = archive(joint_path, PINS['joint']); receipts, art = artifact(joint)
    baseline31 = archive(project/'reviews/publication/primitive-compiler-c31/kernel-v3-actual-success-public.zip', PINS['c31'])
    baseline_sp = archive(project/'reviews/publication/cubic-source-c29/kernel-two-types-v2-actual-public.zip', PINS['csp'])
    original_sp = archive(project/'reviews/publication/cubic-source-c29/ci3-formal-runtime-public.zip', PINS['originalCSP'])
    arsp = archive(project/'tools/cubic_c29_kernel_ci1/public-runtime-package.zip', PINS['candidateArchive'])
    package = workspace/'.c29-c31-joint-kernel-v1-staging'
    require(sha((package/'profile.json').read_bytes()) == PROFILE and sha((package/'c31-profile.json').read_bytes()) == C31PROFILE and sha((package/'bindings.json').read_bytes()) == MANIFEST, 'immutable joint package pins')
    profile = read(package/'profile.json'); cp = read(package/'c31-profile.json')
    profile['_entrySHA256'] = sha((package/'entry.py').read_bytes())
    profile['_comparatorSHA256'] = sha((package/'joint_compare.py').read_bytes())
    manifest = read(package/'bindings.json')
    for name, pin in manifest['files'].items(): require(sha((package/name).read_bytes()) == pin, 'joint source package file pin')
    for name, pin in profile['originalProjectInputs'].items(): require(sha((project/name).read_bytes()) == pin, 'production source/config changed')
    for name, pin in profile['externalFiles'].items(): require(sha((project/name).read_bytes()) == pin, 'external technical file pin')
    for name, pin in profile['cspArchiveMembers'].items(): require(sha(arsp[name]) == pin, 'CSP frozen member pin')
    require(sha((project/'tools/cubic_c29_diagnostic/runner.py').read_bytes()) == SHARED, 'actual original helper pin')
    sp_specs = parse(arsp['vendor/expected-roots.json'])['roots']
    c31 = partition(stream(joint['30-observe.stdout.raw.sanitized.txt'], 'C31'), 'C31', cp['roots'], 87)
    csp = partition(stream(joint['40-csp-probe.stdout.raw.sanitized.txt'], 'C29'), 'C29', sp_specs, 319)
    two = two_types(stream(joint['41-csp-two-types.stdout.raw.sanitized.txt'], 'C29_TWO'), csp)
    old31 = partition(stream(baseline31['30-observe.stdout.raw.sanitized.txt'], 'C31'), 'C31', cp['roots'], 87)
    sp_prefix = 'cubic-c29-kernel-only-v1/public/'
    two_prefix = 'cubic-c29-kernel-types-v2/public/'
    bsp = {n[len(sp_prefix):]: v for n, v in baseline_sp.items() if n.startswith(sp_prefix)}
    btp = {n[len(two_prefix):]: v for n, v in baseline_sp.items() if n.startswith(two_prefix)}
    oldsp = partition(stream(bsp['04-full-kernel-candidate-probe.stdout.raw.sanitized.txt'], 'C29'), 'C29', sp_specs, 319)
    oldtwo = two_types(stream(btp['05-two-kernel-types.stdout.raw.sanitized.txt'], 'C29_TWO'), oldsp)
    baseline31_inputs = parse(baseline31['input-bindings.json'])
    baseline31_vector = {r['relativePath']:r['sha256'] for r in baseline31_inputs['projectInputs']}
    # Separate C31 baseline used the same Cubic candidate but original CSP provider.
    expected31 = dict(cp['projectInputs']); expected31['QuantumBlockEncoding/CubicStatePreparation.lean'] = profile['originalProjectInputs']['QuantumBlockEncoding/CubicStatePreparation.lean']
    require(baseline31_vector == expected31, 'separate C31 baseline source/config binding')
    baseline_sp_inputs = parse(bsp['input-pins.json']); baseline_sp_artifacts = parse(bsp['fresh-candidate-artifacts.json']); baseline_two_inputs = parse(btp['input-bindings.json'])
    for r in (baseline_sp_inputs,): require(r['candidateRawSHA256'] == profile['candidateCSP_SHA256'], 'separate CSP candidate input binding')
    require(baseline_sp_artifacts['candidateSourceSHA256'] == baseline_two_inputs['candidateSourceSHA256'] == profile['candidateCSP_SHA256'], 'separate CSP full/two source binding')
    oldsp_path = oldsp['bindings'][0]['actualResolvedOleanPath']
    require(oldsp_path == oldtwo['binding']['actualResolvedOleanPath'] and any(a['path'] == oldsp_path and a['sha256'] == baseline_two_inputs['targetFreshOleanSHA256'] for a in baseline_sp_artifacts['files']), 'separate CSP full/two same artifact')
    row31 = compare(old31, c31, {}, {}); rowsp = compare(oldsp, csp, oldtwo['rows'], two['rows'])
    require([b['structures'] for b in old31['bindings']] == [b['structures'] for b in c31['bindings']], 'C31 structures changed')
    require(oldsp['bindings'][0]['actualStructures'] == csp['bindings'][0]['actualStructures'], 'CSP structures changed')
    technical = cohorts(joint, c31, csp, two, profile, cp)
    technical['processResourceReplay'] = processes(joint, receipts)
    old_public = workspace/'hermite-export-work/c31-native-ci4-actual-capture/public'
    old_manifest_path = workspace/'.c31-kernel-v3-actual-decoder-addendum-v1/bindings.json'
    require(sha(old_manifest_path.read_bytes()) == '73761459f5dd7f59b70beaf7c92758d04f6b97cbda39be7373c4eedd17812901', 'original C31 receipt manifest pin')
    old_manifest = read(old_manifest_path)['immutableInputSHA256']
    old_files = {key[len('$OLD_PUBLIC/'):]: (old_public/key[len('$OLD_PUBLIC/'):]).read_bytes() for key in old_manifest if key.startswith('$OLD_PUBLIC/')}
    require(len(old_files) == 73, 'original C31 member inventory')
    for n, data in old_files.items(): require(sha(data) == old_manifest['$OLD_PUBLIC/'+n], 'original C31 immutable byte pin')
    o31 = partition(stream(old_files['30-observe.stdout.raw.sanitized.txt'], 'C31'), 'C31', cp['roots'], 87)
    osp = partition(stream(original_sp['06-probe-v5.stdout.raw.sanitized.txt'], 'C29'), 'C29', sp_specs, 319)
    cub_old = (project/'QuantumBlockEncoding/CubicAmplitudePrimitive.lean').read_bytes()
    cub_new = (workspace/'.c31-kernel-proof-v1-staging/candidate/QuantumBlockEncoding/CubicAmplitudePrimitive.lean').read_bytes()
    require(sha(cub_new) == cp['projectInputs']['QuantumBlockEncoding/CubicAmplitudePrimitive.lean'], 'Cubic actual candidate pin')
    source = dict(CSP=proof_delta(arsp['original/CubicStatePreparation.lean'], arsp['candidate/CubicStatePreparation.lean'], 2465),
                  Cubic=proof_delta(cub_old, cub_new), originalProjectInputs=profile['originalProjectInputs'], shadowProjectInputs=cp['projectInputs'])
    require(len(source['CSP']) == 9 and len(source['Cubic']) == 3, 'proof site counts')
    source['allOtherSourceBytesIdenticalIncludingStatementsBindersDataDefinitions'] = True
    baseline_artifacts = {}
    for label, data in [('c31', baseline31), ('csp-candidate-probe', bsp), ('csp-two-types', btp), ('original-csp', original_sp), ('original-c31', old_files)]:
        _, baseline_artifacts[label] = artifact(data)
    native = dict(CSP=production_delta(osp, csp), C31=production_delta(o31, c31))
    # Original source bindings are checked directly, not inferred from filenames.
    original_sp_inputs = parse(original_sp['inputs.json'])
    original31_inputs = parse(old_files['input-bindings.json'])
    original_sp_target = parse(original_sp['target-output.json'])
    old_sp_sha = profile['originalProjectInputs']['QuantumBlockEncoding/CubicStatePreparation.lean']
    require(original_sp_target['targetRawSHA256'] == old_sp_sha and any(r['relativePath'] == 'QuantumBlockEncoding/CubicStatePreparation.lean' and r['sha256'] == old_sp_sha for r in original_sp_inputs['projectInputs']), 'original CSP exact source input binding')
    require(any(r['path'] == osp['bindings'][0]['actualResolvedOleanPath'] for r in original_sp_target['artifacts']), 'original CSP actual artifact path')
    require(any(r['relativePath'] == 'QuantumBlockEncoding/CubicAmplitudePrimitive.lean' and r['sha256'] == sha(cub_old) for r in original31_inputs['projectInputs']), 'original C31 source input binding')
    summary = dict(schema='C38_DIRECT_JOINT_ACTUAL_DECODER_V1', identity='/root/primitive_compiler_formal_decoder_c31', role='formal-only-decoder',
                   runID='c38-raw-joint-replay-20261017-v1', inputZIP=PINS['joint'], separatelyActualBaselineZIPs={k:PINS[k] for k in ('c31','csp')},
                   sourceRoots=len(c31['roots'])+len(csp['roots']), ownedRows=len(row31)+len(rowsp),
                   C31=dict(roots=len(c31['roots']), generated=len(c31['generated']), allCapturedRowsIdentical=True),
                   CSP=dict(roots=len(csp['roots']), generated=len(csp['generated']), allCapturedRowsIdentical=True, completeSupplementalTypes=len(two['rows']), unchangedBodyOmissions=sum(r['valueTextOmitted'] for r in rowsp)),
                   observedAxiomUnion=sorted(set().union(*(set(r['axioms']) for r in c31['rows'].values()), *(set(r['axioms']) for r in csp['rows'].values()))),
                   freshFourTargetCohort=technical['cohort']['cohortID'], serialNativeChildren=technical['processResourceReplay']['serialChildren'], inheritedProjectProviders=24,
                   independentNewDataCalculation=True, authoredRuntimeDisclosed=True, freshSourceBlindClaim=False,
                   parentReportedAPI=dict(job='117288170050',run='38995863052',headShort='ad02522',artifact='12087176088',independentlyFetchedHere=False),
                   artifactGITHUB_SHA=technical['processResourceReplay']['preparation']['context'].get('GITHUB_SHA'),
                   exactExecutedCheckoutSHA=None, localLeanChildren=0, **NO_ACCEPT)
    # Immutable bytes are checked again after the complete calculation.
    require(sha(joint_path.read_bytes()) == PINS['joint'], 'joint ZIP after-read drift')
    for name, pin in profile['originalProjectInputs'].items(): require(sha((project/name).read_bytes()) == pin, 'source/config after-read drift')
    for name, pin in profile['externalFiles'].items(): require(sha((project/name).read_bytes()) == pin, 'external technical file after-read drift')
    return dict(summary=summary, wholeRows=dict(C31=row31, CSP=rowsp, supplementalRows=two['rows']),
                technical=technical, source=source, originalNativeDelta=native,
                artifactBindings=dict(joint=art, baselines=baseline_artifacts, archivePins=PINS,
                                      baselineInputBindings=dict(C31=baseline31_inputs,CSP=baseline_sp_inputs,CSPFresh=baseline_sp_artifacts,CSPTwo=baseline_two_inputs,originalCSP=original_sp_target),
                                      externalTechnicalFilePinsRehashed=profile['externalFiles'], originalJointPackageManifest=MANIFEST,
                                      originalC31MemberPins={n:sha(v) for n,v in old_files.items()}))


if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('--workspace', type=Path, required=True); ap.add_argument('--project', type=Path, required=True)
    args = ap.parse_args(); result = run(args.workspace, args.project)
    print(json.dumps(result, ensure_ascii=False, indent=2))
