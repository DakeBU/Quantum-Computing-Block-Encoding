import ast
from copy import deepcopy
import os
from pathlib import Path
import unittest
import replay as r

ROOT = Path(__file__).resolve().parent.parent
PROJECT = Path(os.environ['C38_PROJECT'])


class ReplayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.files = r.archive(ROOT/'hermite-export-work/c38-joint-kernel-actual-success/public-artifact.zip', r.PINS['joint'])
        cls.receipts, _ = r.artifact(cls.files)
        cls.cp = r.read(ROOT/'.c29-c31-joint-kernel-v1-staging/c31-profile.json')
        cls.profile = r.read(ROOT/'.c29-c31-joint-kernel-v1-staging/profile.json')
        cls.profile['_entrySHA256'] = r.sha((ROOT/'.c29-c31-joint-kernel-v1-staging/entry.py').read_bytes())
        cls.profile['_comparatorSHA256'] = r.sha((ROOT/'.c29-c31-joint-kernel-v1-staging/joint_compare.py').read_bytes())
        arsp = r.archive(PROJECT/'tools/cubic_c29_kernel_ci1/public-runtime-package.zip', r.PINS['candidateArchive'])
        cls.specs = r.parse(arsp['vendor/expected-roots.json'])['roots']
        cls.c31_records = r.stream(cls.files['30-observe.stdout.raw.sanitized.txt'], 'C31')
        cls.csp_records = r.stream(cls.files['40-csp-probe.stdout.raw.sanitized.txt'], 'C29')
        cls.c31 = r.partition(cls.c31_records, 'C31', cls.cp['roots'], 87)
        cls.csp = r.partition(cls.csp_records, 'C29', cls.specs, 319)
        cls.two_records = r.stream(cls.files['41-csp-two-types.stdout.raw.sanitized.txt'], 'C29_TWO')
        cls.two = r.two_types(cls.two_records, cls.csp)

    def test_full_actual_replay(self):
        x = r.run(ROOT, PROJECT)
        self.assertEqual(x['summary']['ownedRows'], 968)
        self.assertEqual(x['summary']['CSP']['unchangedBodyOmissions'], 96)
        self.assertEqual(len(x['originalNativeDelta']['CSP']['removedNativeAxioms']), 9)
        self.assertEqual(len(x['originalNativeDelta']['C31']['removedNativeAxioms']), 3)
        self.assertEqual(x['summary']['sourceAgreement'], None)

    def test_no_old_comparator_import(self):
        tree = ast.parse(Path(r.__file__).read_text(encoding='utf-8'))
        imports = [n for n in ast.walk(tree) if isinstance(n, (ast.Import, ast.ImportFrom))]
        names = [a.name for n in imports for a in n.names]
        self.assertFalse(any(n in names for n in ('joint_compare','compare','runtime','kernel_only')))

    def test_duplicate_json_key(self):
        with self.assertRaises(ValueError): r.parse('{"x":1,"x":2}')

    def test_unknown_stream_tag(self):
        with self.assertRaises(ValueError): r.stream(b'FAKE_JSON {}\n', 'C31')

    def test_missing_summary(self):
        with self.assertRaises(ValueError): r.stream(b'C31_ROOT_JSON {"nativeAccepted":false,"sourceAgreement":null}\n', 'C31')

    def test_generated_collision(self):
        rows = deepcopy(self.c31_records)
        root = next(x[1] for x in rows if x[0] == 'C31_ROOT_JSON')
        gen = next(x[1] for x in rows if x[0] == 'C31_GENERATED_JSON')
        gen['actualName'] = root['actualName']
        with self.assertRaises(ValueError): r.partition(rows, 'C31', self.cp['roots'], 87)

    def test_root_binder_type_drift(self):
        changed = deepcopy(self.c31)
        next(iter(changed['rows'].values()))['typePrettyExplicit'] += ' -> False'
        with self.assertRaises(ValueError): r.compare(self.c31, changed, {}, {})

    def test_universe_drift(self):
        changed = deepcopy(self.csp)
        next(iter(changed['rows'].values()))['universeParameters'] = ['unbound']
        with self.assertRaises(ValueError): r.compare(self.csp, changed, self.two['rows'], self.two['rows'])

    def test_actual_value_availability_drift(self):
        changed = deepcopy(self.csp)
        row = next(iter(changed['rows'].values())); row['actualHasValueAllowOpaque'] = not row['actualHasValueAllowOpaque']
        with self.assertRaises(ValueError): r.compare(self.csp, changed, self.two['rows'], self.two['rows'])

    def test_axiom_increase(self):
        changed = deepcopy(self.c31)
        next(iter(changed['rows'].values()))['axioms'].append('invented.axiom')
        with self.assertRaises(ValueError): r.compare(self.c31, changed, {}, {})

    def test_two_type_ellipsis(self):
        changed = deepcopy(self.two_records)
        next(x[1] for x in changed if x[0] == 'C29_TWO_TYPE_JSON')['typePrettyExplicit'] = '... ⋯'
        with self.assertRaises(ValueError): r.two_types(changed, self.csp)

    def test_uncovered_type(self):
        changed = deepcopy(self.csp)
        next(iter(changed['rows'].values()))['typePrettyExplicit'] = '…'
        with self.assertRaises(ValueError): r.two_types(self.two_records, changed)

    def test_body_omissions_are_not_type_failures(self):
        rows = r.compare(self.csp, self.csp, self.two['rows'], self.two['rows'])
        self.assertEqual(sum(x['valueTextOmitted'] for x in rows), 96)

    def mutate_file(self, name, change):
        files = dict(self.files); value = r.parse(files[name]); change(value); files[name] = r.canonical(value)
        return files

    def test_public_digest_mismatch(self):
        files = dict(self.files); files['30-observe.stdout.raw.sanitized.txt'] += b' '
        with self.assertRaises(ValueError): r.artifact(files)

    def test_entry_mismatch(self):
        files = self.mutate_file('executing-code-bindings.json', lambda x:x['entry'].update(actualMainModuleFile='$FAKE/entry.py'))
        with self.assertRaises(ValueError): r.cohorts(files, self.c31, self.csp, self.two, self.profile, self.cp)

    def test_helper_copy_drift(self):
        files = self.mutate_file('joint-inputs.json', lambda x:x['sharedHelperCopy'].update(destinationSHA256='0'*64))
        with self.assertRaises(ValueError): r.cohorts(files, self.c31, self.csp, self.two, self.profile, self.cp)

    def test_wrong_fresh_probe(self):
        changed = deepcopy(self.two); changed['binding']['actualResolvedOleanPath'] = '$OLD_CACHE/CubicStatePreparation.olean'
        with self.assertRaises(ValueError): r.cohorts(self.files, self.c31, self.csp, changed, self.profile, self.cp)

    def test_wrong_cohort(self):
        files = self.mutate_file('joint-four-target-cohort.json', lambda x:x.update(cohortID='other'))
        with self.assertRaises(ValueError): r.cohorts(files, self.c31, self.csp, self.two, self.profile, self.cp)

    def test_wrong_source_sha(self):
        files = self.mutate_file('joint-csp-fresh.json', lambda x:x.update(sourceSHA256After='0'*64))
        with self.assertRaises(ValueError): r.cohorts(files, self.c31, self.csp, self.two, self.profile, self.cp)

    def test_no_target_seed(self):
        files = self.mutate_file('provider-copies.json', lambda x:x['files'][0].update(module=r.ORDER[0]))
        with self.assertRaises(ValueError): r.cohorts(files, self.c31, self.csp, self.two, self.profile, self.cp)

    def test_pid_mismatch(self):
        files = self.mutate_file('30-observe.started.json', lambda x:x.update(PID=999999))
        with self.assertRaises(ValueError): r.processes(files, self.receipts)

    def test_native_nonzero(self):
        files = self.mutate_file('30-observe.result.json', lambda x:x.update(exitCode=-9))
        with self.assertRaises(ValueError): r.processes(files, self.receipts)

    def test_low_one_byte(self):
        s = r.parse(self.files['ci2-30-observe.preflight.json'])
        s['memAvailableBytes'] = s['effectiveHeadroomBytes'] = s['requiredHeadroomBytes'] - 1; s['gatePassed'] = False
        with self.assertRaises(ValueError): r.resource(s, True)

    def test_missing_nonroot_field(self):
        s = r.parse(self.files['ci2-30-observe.preflight.json']); del s['cgroups'][0]['memoryEvents']['oom']
        with self.assertRaises(ValueError): r.resource(s, True)

    def test_hidden_namespace(self):
        s = r.parse(self.files['ci2-30-observe.preflight.json']); s['namespaceObservation']['selfInode'] = 999
        with self.assertRaises(ValueError): r.resource(s, True)

    def test_windows(self):
        s = r.parse(self.files['ci2-30-observe.preflight.json']); s['context']['platform'] = 'win32'
        with self.assertRaises(ValueError): r.resource(s, True)

    def test_source_nonproof_drift(self):
        old = b'theorem p : True := by native_decide\n'
        with self.assertRaises(ValueError): r.proof_delta(old, b'theorem p : False := by decide +kernel\n')

    def test_comment_mask_preserves_strings(self):
        x = b'/- native_decide /- nested -/ -/ def s := "native_decide" -- hint\n'
        masked = r.mask_comments(x)
        self.assertEqual(len(x), len(masked)); self.assertIn(b'"native_decide"', masked); self.assertNotIn(b'nested', masked)


if __name__ == '__main__': unittest.main(verbosity=2)
