# C38 final handoff

The operative transport boundary is `final-allowlist-v2.json`, binding exactly23
members through `final-bindings-v2.json` and `final-seal-v2.json`. The inner16-file
seal, all its results, and all old source bytes remain untouched. The first builder
completed direct replay and28 tests, wrote its seal, then exited1 when its generic
host-prefix scanner matched a literal inside its own `freeze.py`. That exact
failure is retained in `postfreeze-verification-v2.json`; it was not Lean or
mathematical evidence. The new outer verifier recalculates the direct replay,
compares every stored result, re-runs28 tests in a real Python child, and scans
for an actual home-user segment. No old code or result was patched to hide it.

Finite conclusion: same-candidate joint raw observations preserve all968 captured
rows, all406 explicit roots, all562 dynamically observed generated rows, both
supplemental full signatures, and all actual value-availability fields. The96
incomplete CSP value texts remain incomplete. Source changes are exactly9+3 proof
tokens; original production9+3 native axioms disappear and all surviving recursive
closures are exactly old-minus-native. Full row calculations and complete actual
type texts are in `whole-owned.json`; all captured values are losslessly addressed
by immutable raw-member/line/row-hash references, not claimed fully printed.

Scope is my original identity `/root/primitive_compiler_formal_decoder_c31`.
I authored runtime instrumentation; this is independent direct data replay, not
independent authorship or a new blind context. No comparator conclusion, reviewer,
natural-source package, or registry was used. Fresh source/path/PID/resource
chains are checked, but raw-redacted-byte, inherited24-provider, non-load-trace,
non-clean-transitive and non-OS-attestation boundaries remain. SourceAgreement,
policy and publication binding stay null; acceptance/nativeAccepted/trustClosure
stay false. Production candidates are not installed by this work.

To replay without rewriting any artifact, set `C38_PROJECT` to the read-only
project path, then run `python test_replay.py` (28 tests), or run `python replay.py
--workspace <workspace> --project <project>` to emit the full new calculation.
`finalize_v2.py` is the recorded one-shot outer artifact generator; it refuses
overwriting its final generated files. `freeze.py` is preserved historical
packaging code with the documented post-seal false positive, not the recommended
replay command. No Lean/Git/network/production action is performed by replay.
Do not publish `private-python-process.json` or cache files. Rollback: ignore this
new addendum; no previous artifact, target, workflow or registry changed.

Parent API head label ad02522 and artifact GITHUB_SHA e79996d363d1c4fa591a45718d8286a6dfbce5ce
remain separately labeled; exact checkout and the optional merge-tree explanation
are not independently attested here. This work hashes its31 source/config vector;
it does not mislabel142 production +60 test Lean files as202 production modules.
STOP after this handoff; parent/source-first reviewer retains all admission decisions.
