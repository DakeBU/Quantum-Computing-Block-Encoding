"""Read-only replay of first seal, then new outer artifact; old bytes never changed."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import replay


def output(path, data):
    replay.require(not path.exists(), 'refuse overwrite: '+path.name)
    path.write_bytes((json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode())


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--workspace',type=Path,required=True); ap.add_argument('--project',type=Path,required=True)
    args=ap.parse_args(); home=Path(__file__).resolve().parent
    old_manifest=replay.read(home/'bindings.json'); old_allow=replay.read(home/'allowlist.json'); old_seal=replay.read(home/'seal.json')
    old_hashes={n:replay.sha((home/n).read_bytes()) for n in old_allow['members']}
    replay.require(old_seal['manifestSHA256']==old_hashes['bindings.json'],'first seal manifest')
    replay.require(old_seal['allowlistSHA256']==old_hashes['allowlist.json'],'first seal allowlist')
    for n,pin in old_manifest['files'].items(): replay.require(old_hashes[n]==pin,'first sealed file drift: '+n)
    actual=replay.run(args.workspace,args.project)
    for filename,key in {'summary.json':'summary','whole-owned.json':'wholeRows','technical-chain.json':'technical','source-delta.json':'source',
                         'original-native-delta.json':'originalNativeDelta','artifact-bindings.json':'artifactBindings'}.items():
        replay.require(replay.read(home/filename)==actual[key],'stored result differs from direct re-replay: '+filename)
    # Match an actual home segment, not a generic prefix literal in source code.
    user_path=re.compile(r'[A-Za-z]:[\\/]+Users[\\/]+[A-Za-z0-9_.-]+[\\/]')
    members=old_allow['members']+['finalize_v2.py','FINAL-HANDOFF.md','final-python-tests-v2.json','postfreeze-verification-v2.json',
                               'final-allowlist-v2.json','final-bindings-v2.json','final-seal-v2.json']
    replay.require(len(members)==len(set(members)),'outer allowlist duplicate')
    for n in old_allow['members']+['finalize_v2.py','FINAL-HANDOFF.md']:
        replay.require(not user_path.search((home/n).read_text(encoding='utf-8')),'actual user host path in public file: '+n)
    env=dict(os.environ); env['C38_PROJECT']=str(args.project.resolve())
    start=datetime.now(timezone.utc).isoformat(); began=time.monotonic()
    p=subprocess.Popen([sys.executable,str(home/'test_replay.py')],cwd=home,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    timed_out=False
    try: stdout,stderr=p.communicate(timeout=120)
    except subprocess.TimeoutExpired:
        p.kill(); stdout,stderr=p.communicate(); timed_out=True
    end=datetime.now(timezone.utc).isoformat()
    replay.require(p.returncode==0 and not timed_out and b'Ran 28 tests' in stderr and stderr.rstrip().endswith(b'OK'),'final Python tests did not pass')
    receipt=dict(PID=p.pid,startedUTC=start,finishedUTC=end,wallSeconds=time.monotonic()-began,exitCode=p.returncode,timedOut=timed_out,
                 actualInterpreterSHA256=replay.sha(Path(sys.executable).read_bytes()),argvLogical=['$PYTHON311','$ADDENDUM/test_replay.py'],
                 tests=28,failures=0,stdout=stdout.decode(),stderr=stderr.decode(),stdoutSHA256=replay.sha(stdout),stderrSHA256=replay.sha(stderr),
                 sourcePins={n:replay.sha((home/n).read_bytes()) for n in ('replay.py','test_replay.py','finalize_v2.py')},localLeanChildren=0,**replay.NO_ACCEPT)
    output(home/'final-python-tests-v2.json',receipt)
    output(home/'postfreeze-verification-v2.json',dict(
        firstFreezeActualExitCode=1,firstFailure='ValueError: host path public leak: freeze.py',
        location='Post-seal publication scanner; first seal had already been written',
        cause='Generic prefix literal inside the scanner matched its own source, not an actual user host path',
        oldSealAndAllOld16PublicFilesPreservedByteExact=old_hashes,oldSourceNotRewritten=True,
        correction='New outer scanner requires an actual user segment; direct replay recalculated and stored outputs compared exactly',
        finalReplayOwnedRows=actual['summary']['ownedRows'],allStoredDirectResultsRecalculatedEqual=True,
        testReceiptSHA256=replay.sha((home/'final-python-tests-v2.json').read_bytes()),
        noAcceptanceOrNativeBoundaryChange=True,**replay.NO_ACCEPT))
    output(home/'final-allowlist-v2.json',dict(members=members,privateExcluded=['private-python-process.json','__pycache__/**'],
                 supersedesForTransportOnly='allowlist.json',noImplicitGlobPublication=True,**replay.NO_ACCEPT))
    for n in members:
        if n in ('final-bindings-v2.json','final-seal-v2.json'):continue
        replay.require(not user_path.search((home/n).read_text(encoding='utf-8')),'public host path')
    pins={n:replay.sha((home/n).read_bytes()) for n in members if n not in ('final-bindings-v2.json','final-seal-v2.json')}
    output(home/'final-bindings-v2.json',dict(files=pins,firstSealSHA256=old_hashes['seal.json'],**replay.NO_ACCEPT))
    output(home/'final-seal-v2.json',dict(schema='C38_ACTUAL_DECODER_OUTER_SEAL_V2',
                 manifestSHA256=replay.sha((home/'final-bindings-v2.json').read_bytes()),
                 allowlistSHA256=replay.sha((home/'final-allowlist-v2.json').read_bytes()),
                 testReceiptSHA256=replay.sha((home/'final-python-tests-v2.json').read_bytes()),
                 actualJointZIP=replay.PINS['joint'],identity='/root/primitive_compiler_formal_decoder_c31',**replay.NO_ACCEPT))
    for n,pin in old_hashes.items(): replay.require(replay.sha((home/n).read_bytes())==pin,'old sealed bytes changed')
    print(json.dumps({n:replay.sha((home/n).read_bytes()) for n in ['summary.json','whole-owned.json','final-python-tests-v2.json','final-bindings-v2.json','final-seal-v2.json']},indent=2))


if __name__=='__main__':main()
