# Phase4B — original source-first comparison with the frozen actual decoder addendum

Status: TWO_WHOLE_MODULES_SUPPORTED_FOR_SOURCE_REVIEWED_LOCAL_INTEGRATION_PENDING; FINAL_PARENT_LATE_BINDING_WRAPPERS_PENDING. No accepted registry record or final wrapper is created.

## Timing and exact scope

Phase4A metadata judgment was sealed FIRST, SHA 22bbdb4217c6ff8f1a2ae40032bab917b0b7ecc6f6a64b2921bb5a886c70024a. It was not edited after seeing this addendum. The late author-metadata alignment and parent's corrected versioned pointer remain explicit in that report.

Only six authorized addendum files were opened: README.md, report.json, root-contract-comparisons.json, generated-observations.json, bindings.json, seal.json, logically $DECODER_ADDENDUM/. Directory listing confirms eleven files. The other five entries—produce.py, pi_contracts.py, freeze.py, test_addendum.py and python-tests.json—were not read, executed, or used as evidence. In particular no test PASS was adopted.

Actual addendum seal SHA is 775f7249bcad57053e2622e79f88837220f394375ebb3741d2cc750d5181646d, matching the separate authorization. Actual bindings SHA cae94b66fdb890397f5143f1a150292f3eeb0e89fd231983529354fb3b31e22e matches the seal; all four authorized payload hashes match that manifest. I make no claim to have rehashed the five unread manifest entries. All six exact file hashes/lengths are in the new addendum index.

The parent identifies this as the original independent formal decoder's frozen addendum. Its reported original source-seal/contracts/reconstruction hashes are retained, not confused with my Phase1 natural-source seal. Those old decoder files were not newly opened or independently re-attested in this grant. Exact per-module decoder evidence/wrapper and identity/run binding remain for the parent's late binding, not invented here.

## Independent actual-record and Pi checks

The addendum's 62 complete actualObservation objects and 94 generated objects were compared recursively, across EVERY field, to the previously authorized actual CI4 public stdout. All 156 match exactly, with unique identities and the exact two owned partitions. Both actualBinding objects match the actual stream bindings. All 73 reported public-input hashes match the original reviewer's sealed independent capture index; the actual stdout and fresh-cohort derivative hashes were independently recomputed again.

This is not acceptance by matching the decoder's summary count. The corresponding source headers, original formal-context identities/private flags and actual type hashes also agree with Phase4A's 62-root alignment. The whole unchanged module/source/config bindings and previously inspected proof bodies remain the same.

I wrote a separate balanced-delimiter Pi splitter. It did not import/read/execute the decoder extractor or its tests. On each of all 62 complete recovered headers and corresponding actual pretty-types it independently parses:
- every explicit, implicit and instance input, expanding grouped binders;
- every leading post-colon dependent or nondependent arrow;
- all outer forall groups without accidentally flattening quantified propositions INSIDE a single proof argument;
- the remaining result text after those leading Pi binders.

The independently parsed arities, binder visibility and retained names match both the source and actual addendum entries for every root. Anonymous arrows legitimately lose parameter names; an unnamed [Fintype ...] arrow remains an instance, not an explicit argument. Universe-polymorphic index/context carriers and finite/decidable instances remain visible. Parsed individual type/result slices agree with the complete preserved pretty-type text. Complete recovered headers, after whitespace normalization only, are actual prefixes of the exact source blocks already bound by the v3 audit/formal-context hashes.

One initial local reviewer-check failure was my comparison of a parenthesized anonymous domain with its unwrapped equivalent. I corrected only my unsealed splitter's outer-parenthesis/whitespace normalization and reran it successfully. This was neither a CI/Lean failure nor a decoder mathematical mismatch. It adds no semantic rewriting or proof acceptance.

These checks are structured source/pretty-type comparison, not a kernel Expr serialization, cross-environment definitional-equality theorem, or a general Lean parser correctness certificate. Source notation and elaborated qualified types are NOT asserted string-identical. Mathematical reading, including the meanings of the types and results, is supplied by the retained independent first-hand source derivations, complete actual-source proof reading, and the 62 decoder meanings inspected here; parser arity alone does not prove semantic fidelity.

## Contract comparison and actual defect

I compared the reconstructed mathematical meanings for ALL 43 Macros roots and ALL 19 Uniform roots, including the eight private helpers, to my independent natural/actual-source work. No new mismatch was found.

The decoder addendum visibly records one old catalog truncation: hadamardMatrix_apply.oldSealedSourceSignature stops at the INNER let-scale assignment. The recovered header correctly includes the scale expression and all match branches of the proposition. Its complete result is the exact matrix-entry formula, not a new hypothesis or a changed theorem. I independently confirmed this full recovered header against the actual same bound source block and its captured actual type. I did not reopen the old decoder packet to independently attest how its earlier extractor produced the truncated string. The defect and correction remain explicit; the old packet is not silently edited.

MonomialProgram's root header is separated from its where-fields for root-type comparison. This does not erase program, phase, permutation or exact: those four fields, constructor and projections remain covered by the bound source and actual generated observations. The exact projection is thmInfo with an actual evaluation equality, not arbitrary physics-Prop data or a metadata Boolean.

Specific high-risk contracts agree:
- H/T/inverse-T retain exact global phases, chronological composition and full spectator-sector equality.
- General monomial multiplication has arbitrary complex phases and the correct transported phase/permutation order; it does not assume unit modulus.
- The final literal CCX network requires three pairwise inequalities, but target-block/conjugation identities require only a!=target and b!=target and genuinely allow a=b.
- Uniform's complete control-assignment context and both post-colon Pi definitions are retained. No implicit injectivity, clean-input, fixed-width, bounded-angle or correctness premise appeared.
- Zero-control/base and successor cases, repeated controls, exact half-sum/half-difference tables, full independent context block equality, recursive-denotation equality and separate Ry/CX count conclusions agree.
- The five-control specialization is 32/62 for all valid maps, including repeated wires; zero opaque calls is not zero table-generation/numerical-synthesis cost.

Source topology/AND tails, exhaustive all-required cases, local phase-proof OR and the seven quantum-slot exclusions are exactly those frozen in Phase4A. This decoder comparison does not turn a conceptual transport into an elaborated dependency or a local phase proof into a second verified compiler route.

## Whole-owned trust and omission boundary

Macros has 43 roots + 55 generated = 98 owned; Uniform has 19 roots, including eight private, + 39 generated = 58 owned. Each complete partition has collected axiom union Classical.choice, Quot.sound, propext; actual unsafe, self-axiom and axiomInfo counts are zero. Names containing _unsafe_rec or familiar imported prefixes are not themselves unsafe/ownership evidence: actual flags and module-index attribution govern the observed inventory.

The three Cubic native axioms are absent from every one of these 156 records. They do not block these two modules. This neither admits Cubic nor repairs its actual dependencies.

All 156 ordinary-value texts are unrequested. Of these, 153 report an available value; MonomialProgram, its constructor and recursor have no ordinary value available. No body dump or full clean-transitive trust audit is inferred. The ci/ki distinction, reported collectAxioms mechanism, inherited providers, sanitized raw-path limitation, untraced loads and exact executed-checkout boundary remain as sealed in Phase3. No new arbitrary TCB standard is introduced; these are limits on what this evidence actually observes.

## Scoped conclusion and next actions

B1 from Phase4A is now discharged at this authorized text/actual-evidence level: all 62 root contract records and 94 generated records have been independently compared, including implicit/Pi inputs and the explicit catalog correction. No additional source premise or changed semantic slot was discovered.

Both COMPLETE modules—not merely their headline roots—remain supported for the requested SOURCE_REVIEWED_LOCAL_INTEGRATION_PENDING scope on these exact v4 candidates:
- Macros candidate b8471cce274f063e322c8ef952f1cfe840c9f774cd043dda530090b763188b60, prospective binding a5cd337cfc829f09e9247871004e20c1bcec29ebfe13a8ac7550f107638e1e4a.
- Uniform candidate e09b2209dbe78ad0bc6ff3042133ad8aa13647bf8bb7e63162b5613bf714413e, prospective binding 0c0083d8d20df25d3bd5589e0c45b3edd7622700abcb8967dbd8065f2cfb8817.

This is a scoped review recommendation and comparison, not a final acceptance wrapper. B2 remains: parent supplies exact per-module decoder artifact/evidence/wrapper hashes and late candidate-binding relation; a final separately authorized reviewer wrapper may then bind this exact evidence. Pending paths are not evidence. B3 remains: local integration/publication/reader gates stay PENDING under this limited scope. There is no reason to wait for a Cubic repair to bind the two clean modules, and no authority to claim main/ROOT/PURIFIED, finite-bit synthesis, polynomial preprocessing, full executable-family acceptance or global sourceAgreement.

No source/production/accepted record was changed; no Lean/Git/network/checker/native runner/test or child agent was used. Only new phase4-* reviewer artifacts were written with apply_patch. All seventeen old files and the three already sealed Phase4A files remain immutable. STOP after bounded handoff; final wrapper waits for the parent's exact late bindings.

