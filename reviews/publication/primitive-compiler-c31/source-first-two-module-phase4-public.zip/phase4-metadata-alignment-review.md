# Phase4A — two-module late author-metadata alignment, before decoder addendum

Status: TWO_MODULE_SOURCE_REVIEW_SUPPORTED; FINAL_ACTUAL_DECODER_BRIDGE_AND_LOCAL_INTEGRATION_PENDING. No final acceptance wrapper or accepted registry record is issued.

This is the original source-first reviewer continuing the sealed Phase1/v4/CI4 review. It is explicitly a late author-metadata alignment after independent source/actual-source work, not a new blind natural-source reading. Original mathematical derivations, whole target/private proof readings, and actual 200-record checks are reused at their exact hashes. At the time this report was written and sealed, the newly authorized decoder addendum had NOT been read.

## 1. Pointer error, correction, and exact reviewee

The parent's first Phase4 directory pointer selected the top-level historical AUTHOR/WIP candidates. Those files really retain F1 missing post-colon binders, F2 broad section links, and a fifteen-edge coarse graph. I reported that exact mismatch; it was not silently repaired and is not evidence against the unchanged mathematical modules.

The parent then corrected the pointer to already versioned metadata-v3/v4. These corrected files match byte-for-byte the original reviewer's previously independently reviewed v3/v4 inputs. No old source/private-coverage/build file was opened to repair the story, and the top-level historical files are left unchanged. This report concerns only:

- Macros candidate SHA b8471cce274f063e322c8ef952f1cfe840c9f774cd043dda530090b763188b60, prospective binding a5cd337cfc829f09e9247871004e20c1bcec29ebfe13a8ac7550f107638e1e4a.
- Uniform candidate SHA e09b2209dbe78ad0bc6ff3042133ad8aa13647bf8bb7e63162b5613bf714413e, prospective binding 0c0083d8d20df25d3bd5589e0c45b3edd7622700abcb8967dbd8065f2cfb8817.
- v3 binder SHA 7f5093cd9b28e9e26286de2173bcaf686ca36f5a9b1ee83ddd5859d1aac1506e.
- v3 coverage SHA 23953cd12776ce9dde13e4d306495bc44df2f914660777b1255f0cec7fc12da9.
- v4 graph SHA 7015fcde26154192f0d03242ffa3056f42c6fe3cdd0382575343f752da3bf109.

All are under $PROJECT/reviews/publication/primitive-compiler-c31/, with versioned subdirectories as recorded in the new alignment index. Both current complete module sources and all three configuration files still match their sealed hashes. The lesson is byte-identical to original source SHA 5907262565b6202fec61b189c42d942cb84d6215223a0da4211d63b92d3ad168. Formal context remains a0b798f1e74b084274a44061514f7944ea6b694c13af2b8f718a27ea7b0ac408. All seventeen earlier reviewer files were rehashed unchanged.

The author decoder packet now read is an authorized formal-input descriptor only, SHA 819f8413afb69daab2e282c863900b198f32feae93d57ec3df5cc8c1179f5fde. It is NOT a decoder result. All candidate decoder/reviewer pending pointers remain unattached. No result is inferred from those pointers.

## 2. Whole-module coverage and definitions

The new alignment index covers every one of the 62 authored roots: Macros 43 public, Uniform 11 public plus 8 private. Each exact complete declaration/proof block hash agrees with the sealed original formal-context inventory; each narrow source link resolves to its actual source atom/hash/paragraph. Public candidate declaration and obligation vectors have the correct scope; Uniform's eight private helpers are covered in the whole-module audit, not improperly counted as public publication declarations.

Previously read complete sources included all proof bodies, structures/fields, namespaces, imports, opens and local options. There are no hidden target-level variable/universe/typeclass sections omitted from that scope. This is retained actual-source reading, not a new assertion that source-derived inventory is a compiler elaborator.

Macros definitions fix literal full complex matrix representatives: H=i Ry(pi/2)Rz(pi), P(theta)=exp(i theta/2)Rz(theta); chronological primitive programs include their required global phases. General phase-permutation multiplication permits arbitrary complex phases and does not assert their unitarity. MonomialProgram's program/phase/permutation data and exact evaluation equality remain distinct. Its seq constructor consumes both exact proofs and supplies the composite proof; it does not expose an unrelated final source theorem's desired conclusion as a new hypothesis. PrimitiveProgramRefinement likewise stores an actual evaluation equality, not a freely chosen Prop or a Boolean validity flag.

The middle network includes all thirteen instructions and all exact T/inverse-T phases. Its permutation restoration AND phase E=4abt are both needed before CCZ; H-squared/HZH, fixed-context lifting and exact composition then supply CCX/refinement. Final network guards are a!=b, a!=target and b!=target. Intermediate target-block/conjugation identities retain only the two target inequalities. Their weaker regime must not be narrowed by copying the final network's stronger guard everywhere.

Uniform's private helpers remain:
044 prependControlBit; 045 halfAddAngles; 046 halfSubAngles; 050 kronecker_one_eq_blockDiagonal; 051 evalPrimitiveRy_eq_controlledRyBlockMatrix_zero; 052 controlledXBlock; 053 xMatrix_flipBit; 054 evalPrimitiveCx_eq_controlledXBlock.
They provide head/tail indexing, exact angle-table arithmetic, zero-control and CX target/context blocks. They are internal providers with source-linked roles, not eight new externally sourced theorems.

All target definitions are literal formulas, recursion or proof-carrying constructors. There is no characterized-choice uniqueness claim, quotient representative claim, or off-carrier fallback. ExactAngle's mathematical real evaluation is standing semantics; its stored bound fields are not a computational-access oracle. The two Uniform definitions with post-colon Pi inputs have all six outer inputs audited: qubit carrier, controls, wires, target, target-avoidance proof and angle table. The guard is SOURCE; the data have TYPING roles as source-specified data. No injectivity premise exists. The complete-context argument of primitiveControlAssignment is also retained. No visible EXCESS binder is found; exact actual implicit-Pi reconciliation is a separate still-pending decoder bridge.

## 3. Coverage, topology and graph meanings

The actual v3 coverage bytes are the same ones previously reviewed individually, not a count-only substitute. In this alignment, all 34 paragraph byte slices reconstruct the exact natural source; all 60 atom quotations/hashes/slices match; all 62 in-scope narrower root links resolve. The 34 paragraphs preserve NODE versus reasoned heading/provenance EXCLUDED dispositions. Internal providers are linked to their mathematical roles rather than falsely claimed as literal named source theorems. No substantive source content is erased by limiting this decision to two modules; S8/S9 Cubic and S10 stronger consumers remain separate, not admitted.

A fresh recursive comparison of every graph JSON value confirms v4 differs from v3 only at /views/source-construction-graph/AND_hyperedges/20/tails/4, adding claim:compiler-definition. This is the finite Cubic definition's already-existing producer, not a new theorem or an extra public binder. The other 31 AND records and all OR/case/boundary/functor content are identical. This sparse finite-consumer repair neither introduces a new prerequisite into Macros/Uniform nor makes either depend on Cubic.

For the in-scope routes, the full mathematical AND meaning is preserved:
- Exact macros require literal lists, phases, 2x2 identities and lifting; CCZ requires produced monomial semantics, permutation restoration and the exponent proof; CCX requires the block/conjugation identities and exact composition.
- Recursive-denotation equality uses compiler plus recursive matrix definition, append law, base and both recursive hypotheses.
- The independent full-block compiler theorem instead uses the independent specification, compiler, zero/CX blocks, exact half-angle evaluation, Ry addition, X-Ry-X, context/reindex product laws, head/tail reconstruction, both semantic induction hypotheses and both head-bit branches. It does not call the recursive-denotation theorem merely because the source presents that theorem first.
- Count theorems use the literal compiler, count definitions/additivity, recursive count hypotheses and arithmetic. Semantic correctness does not by itself imply counts; counts do not prove semantic correctness.

Head-zero/head-one, same/different context and base/successor are exhaustive cases with ALL required branches, not optional constructions. The eight-bit check OR XOR expansion are alternative sufficient local proofs of E=4abt only. The actual implementation uses the eight-case route; there is no separately compiled alternative compiler claim. Macro, compiler and finite consumer paths are distinct objectives, not false OR alternatives for one theorem and not a false CCX-to-Cubic implication.

Functor records preserve exactly the corresponding full source-hyperedge tails and heads. They remain conceptual transports, not certified categorical functors or elaborated theorem dependencies. Lean imports/ownership and source construction remain separate. Compressed groups are navigation with lossless expansion, still pending purification.

This supports the in-scope source-construction alignment of the TWO modules. It does not retroactively turn the earlier sparse v4 report into a global root-closure certificate, nor close the seven stronger-consumer/admission gaps for the three-module package.

## 4. Old findings: two-module disposition

| Finding | Macros | Uniform |
| --- | --- | --- |
| F1 incomplete Pi binder metadata | Not a Macros defect | Corrected in exact v3 bytes; complete five post-colon inputs plus qubits now present. Actual implicit-Pi bridge still pending separately. |
| F2 broad source links | Corrected narrow links retained | Corrected narrow links include all private helpers. |
| F3 incomplete AND/OR topology | In-scope full source tails and local phase OR are faithful | Direct semantics versus recursive denotation, all branches and independent count tails are faithful. |
| F4 generic Prop versus physics | Not a blocking defect: actual refinement equality, not arbitrary certificate Prop | No concrete block-encoding wrapper is claimed here; arbitrary imported generic Props do not supply the compiler theorem. |
| F5 native / finite-bit / presentation boundary | Actual 98 owned records show only ordinary baseline axioms; stronger synthesis/export claims excluded | Actual 58 owned records show only ordinary baseline axioms; exact-real counts, not finite-bit synthesis. |

The three Cubic native axioms belong to Cubic generated constants and affect its consumers; no collected dependency on them exists among these 156 owned constants. They do NOT block these two modules merely through package association. Conversely, absence of native axioms does NOT automatically accept modules: the semantic, coverage, definition, binder and graph work above remains essential.

The actual axiom union for each module is exactly Classical.choice, Quot.sound, propext; unsafe/self-axiom/native counts are zero in the sealed observations. Type/universe agreement is guarded through ki versus ci as described in Phase3. Value bodies were not exported; source proof bodies were previously inspected statically. This phase adds no native execution, no claim of full kernel-body serialization, no actual-load trace and no clean-transitive trust claim.

## 5. Seven quantum slots, scoped to these modules

1. Target/normalization: exact H/T/inverse-T/CCX and independent controlled-Ry matrices, not normalized state preparation or a cubic block result.
2. Dimensions/scalars/order: finite complex matrices on named wires, output rows/input columns, chronological products reversed in matrix order. No generic integer endianness silently added.
3. Access/controls/inverses: actual primitive gates, exact inverse-T, every selected control avoids target; repeats allowed, inconsistent tuples not physical inputs. Angle-table data are not a free efficient producer.
4. Workspace/garbage: compiler changes only target and preserves complete non-target context, with zero controls included. No additional clean-workspace or deterministic postselection promise.
5. Phase: exact full global/relative phases, including monomial phases and macro phases. No replacement by probabilities or equality modulo phase.
6. Norm/error/success: ideal exact equalities, no uniform finite-precision error/success certificate. Arbitrary monomial phases are not assumed unit modulus.
7. Resources: Ry=2^n, CX=2(2^n−1), five-control 32/62 and zero stored opaque oracle calls. n counts control positions even with repeated wires. No polynomial table production, finite-bit/Clifford+T, classical storage/access, depth/connectivity or executable-family certificate follows.

## 6. Supported recommendation and remaining executable obligations

On retained first-hand mathematical/actual-source evidence plus exact late metadata alignment, BOTH entire modules are suitable candidates for SOURCE_REVIEWED_LOCAL_INTEGRATION_PENDING. There is no remaining identified source-mathematical F1/F2/F3/F4 defect for these two exact module hashes. This is a scoped recommendation, not the final independently bound publication wrapper, no global accepted status and no Cubic admission.

Remaining obligations are narrow:
B1. Read only the separately authorized frozen original decoder addendum; verify its seal/bindings, every one of the 62 actual root contract comparisons (including all implicit/Pi parameters), and 94 generated observations against the already sealed 156 actual records. Compare, do not presume agreement from its verdict.
B2. Parent supplies exact decoder artifact/evidence/wrapper hashes and candidate-binding relation; only then produce a separately authorized final reviewer bridge/wrapper tying that exact decoder reconstruction to these exact candidates. Never fabricate a decoder result or use its pending path as evidence.
B3. Retain local integration/publication/reader gates as PENDING under the requested status. No main/ROOT/PURIFIED or newly claimed finite-bit/executable guarantee; no need to wait for or read a Cubic repair to finish this two-module decision.

No source/metadata correction, build, Git/network call, checker run, production write or accepted-record edit was performed. Only new phase4-* reviewer files are written. Skills were used to retain binder/source-edge and graph-layer discipline, not to expand authority. Mathematical failure class: NONE for these two scoped modules; unresolved items are evidence-binding/integration obligations, not refutations. Purification/Exposition Seal remain pending. No children or competing route claims.

