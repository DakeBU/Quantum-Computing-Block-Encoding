// Independent read-only text/record check of the authorized frozen decoder addendum.
// This is not Lean, a kernel Expr comparator, the decoder's extractor, or admission.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const [addendum, capture, reviewer, project]=process.argv.slice(2);
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
function ok(x,m){if(!x)throw Error(m);}
function strict(s){let i=0;function ws(){while(i<s.length&&/\s/.test(s[i]))i++;}
 function str(){let st=i++;while(i<s.length){if(s[i]==='\\'){i+=2;continue;}if(s[i++]==='"')return JSON.parse(s.slice(st,i));}throw Error('unterminated');}
 function val(){ws();let z=s[i];if(z==='"')return str();if(z==='{'){i++;ws();let o={},seen=new Set;if(s[i]==='}'){i++;return o;}while(true){ws();ok(s[i]==='"','key');let k=str();ok(!seen.has(k),'duplicate JSON key');seen.add(k);ws();ok(s[i++]===':','colon');o[k]=val();ws();let c=s[i++];if(c==='}')return o;ok(c===',','object');}}
 if(z==='['){i++;ws();let a=[];if(s[i]===']'){i++;return a;}while(true){a.push(val());ws();let c=s[i++];if(c===']')return a;ok(c===',','array');}}
 let m=/^(?:true|false|null|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?)/.exec(s.slice(i));ok(m,'primitive');i+=m[0].length;return JSON.parse(m[0]);}
 let v=val();ws();ok(i===s.length,'trailing JSON');return v;}
const bfile=(root,n)=>fs.readFileSync(path.join(root,n));
const read=(root,n)=>strict(bfile(root,n).toString('utf8'));
const canon=v=>Array.isArray(v)?v.map(canon):(v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,canon(v[k])])):v);
const equal=(a,b)=>JSON.stringify(canon(a))===JSON.stringify(canon(b));
const names=['README.md','report.json','root-contract-comparisons.json','generated-observations.json','bindings.json','seal.json'];
const fileIndex=names.map(n=>({logicalPath:'$DECODER_ADDENDUM/'+n,bytes:bfile(addendum,n).length,sha256:hash(bfile(addendum,n))}));
const bindings=read(addendum,'bindings.json'),seal=read(addendum,'seal.json'),report=read(addendum,'report.json'),roots=read(addendum,'root-contract-comparisons.json').roots,generated=read(addendum,'generated-observations.json').rows;
ok(hash(bfile(addendum,'seal.json'))==='775f7249bcad57053e2622e79f88837220f394375ebb3741d2cc750d5181646d','exact addendum seal');
ok(hash(bfile(addendum,'bindings.json'))===seal.manifestSHA256,'manifest');
for(const n of names.filter(n=>n!=='bindings.json'&&n!=='seal.json'))ok(bindings.files[n]===hash(bfile(addendum,n)),'authorized payload hash');
const preSeal=read(reviewer,'phase4-metadata-alignment-seal.json');
ok(preSeal.frozenBeforeDecoder===true&&preSeal.newDecoderArtifactsRead===false,'pre-decoder seal');
ok(hash(bfile(reviewer,'phase4-metadata-alignment-seal.json'))==='22bbdb4217c6ff8f1a2ae40032bab917b0b7ecc6f6a64b2921bb5a886c70024a','pre-seal unchanged');
const stream=bfile(capture,'30-observe.stdout.raw.sanitized.txt');
ok(hash(stream)===seal.actualStreamSHA256&&hash(stream)===report.actualStreamSHA256,'stream hash');
const actual=stream.toString('utf8').trim().split(/\r?\n/).map(line=>{const n=line.indexOf(' ');return{tag:line.slice(0,n),row:strict(line.slice(n+1))};});
const targetModules=['QuantumBlockEncoding.PrimitiveMacros','QuantumBlockEncoding.UniformlyControlledRy'];
const wanted=actual.filter(x=>targetModules.includes(x.row.module)&&['C31_ROOT_JSON','C31_GENERATED_JSON'].includes(x.tag));
ok(roots.length===62&&generated.length===94&&wanted.length===156,'partition counts');
const byActual=new Map(wanted.map(x=>[x.row.actualName,x]));
for(const r of roots){const a=byActual.get(r.actualObservation.actualName);ok(a?.tag==='C31_ROOT_JSON'&&equal(r.actualObservation,a.row),'root observation differs');}
for(const r of generated){const a=byActual.get(r.actualName);ok(a?.tag==='C31_GENERATED_JSON'&&equal(r,a.row),'generated observation differs');}
ok(new Set([...roots.map(r=>r.actualObservation.actualName),...generated.map(r=>r.actualName)]).size===156,'exact unique owned');
for(const m of report.modules){const actualBinding=actual.find(x=>x.tag==='C31_BINDING_JSON'&&x.row.module===m.module).row;ok(equal(actualBinding,m.actualBinding),'module binding differs');}
const oldIndex=read(reviewer,'phase3-ci4-evidence-index.json');
for(const [n,h] of Object.entries(report.actualPublicInputsSHA256)){ok(oldIndex.fileIndex.find(f=>f.logicalPath==='$CAPTURE/'+n)?.sha256===h,'public input vector');}
ok(Object.keys(report.actualPublicInputsSHA256).length===73,'public vector not all73');
ok(hash(bfile(capture,'fresh-target-cohort.json'))===report.actualFreshReceiptSHA256,'fresh cohort hash');

// Own balanced-delimiter parser; no decoder parser/source imported or executed.
const pairs={'(':')','[':']','{':'}'};
function group(s){const close=pairs[s[0]];ok(close,'group opener');const stack=[close];for(let i=1;i<s.length;i++){const ch=s[i];if(pairs[ch])stack.push(pairs[ch]);else if([')',']','}'].includes(ch)){ok(stack.pop()===ch,'unbalanced delimiter');if(!stack.length)return[s.slice(0,i+1),s.slice(i+1).trim()];}}throw Error('unclosed group');}
function topAt(s,predicate){const stack=[];for(let i=0;i<s.length;i++){const ch=s[i];if(!stack.length&&predicate(ch,i))return i;if(pairs[ch])stack.push(pairs[ch]);else if([')',']','}'].includes(ch)){ok(stack.pop()===ch,'unbalanced scan');}}return-1;}
function binder(g){let inside=g.slice(1,-1).trim(),kind=g[0]==='{'?'implicit':g[0]==='['?'instance':'explicit',colon=topAt(inside,c=>c===':');
 if(colon<0)return[{name:null,kind,type:inside}];
 let ns=inside.slice(0,colon).trim().split(/\s+/),type=inside.slice(colon+1).trim();
 return ns.map(name=>({name,kind,type}));}
function parsePi(text){let s=text.trim(),out=[];
 while(true){if(s.startsWith('∀')){s=s.slice(1).trim();while(true){ok(pairs[s[0]],'unsupported bare forall');let[g,tail]=group(s);out.push(...binder(g));s=tail;if(s[0]===','){s=s.slice(1).trim();break;}}continue;}
 const arrow=topAt(s,c=>c==='→');if(arrow<0)break;
 let domain=s.slice(0,arrow).trim(),tail=s.slice(arrow+1).trim();
 if(pairs[domain[0]]){const[g,rest]=group(domain);if(!rest)out.push(...binder(g));else out.push({name:null,kind:'explicit',type:domain});}
 else out.push({name:null,kind:'explicit',type:domain});
 s=tail;
 }return{binders:out,result:s};}
function sourceHeader(h){const m=/\b(def|theorem|lemma|structure)\s+[^\s{(:]+/.exec(h);ok(m,'source declaration prefix');let rest=h.slice(m.index+m[0].length).trim(),out=[];
 while(pairs[rest[0]]){let[g,tail]=group(rest);out.push(...binder(g));rest=tail;}
 if(rest.startsWith(':'))rest=rest.slice(1).trim();
 let tail=parsePi(rest);return{binders:[...out,...tail.binders],result:tail.result};}
const squash=s=>{s=s.trim();while(s.startsWith('(')){const[g,rest]=group(s);if(rest)break;s=g.slice(1,-1).trim();}return s.replace(/\s+/g,' ').trim();};
const rootIndex=roots.map(r=>{
 const a=parsePi(r.actualObservation.typePrettyExplicit),s=sourceHeader(r.recoveredCompleteHeader),reported=r.sourceBinderComparison.entries;
 ok(a.binders.length===s.binders.length&&a.binders.length===reported.length,'own arity '+r.name);
 const checks=a.binders.map((b,i)=>{let src=s.binders[i],rep=reported[i];ok(b.kind===src.kind&&b.kind===rep.actual.kind&&src.kind===rep.source.kind,'visibility '+r.name);
  ok(b.name===rep.actual.name&&src.name===rep.source.name,'parser name disagreement '+r.name);
  ok(!src.name||!b.name||src.name===b.name,'retained binder name mismatch');
  ok(squash(b.type)===squash(rep.actual.typeText)&&squash(src.type)===squash(rep.source.typeText),'parsed type text mismatch '+r.name);
  return{ordinal:i+1,source:src,actual:b};});
 ok(squash(a.result)===squash(r.actualResultTextAfterLeadingPi),'result split');
 return{name:r.name,module:r.module,private:r.sourcePrivate,sourceKind:r.sourceKind,actualName:r.actualObservation.actualName,sourceLine:r.sourceLine,sourceHeaderSHA256:hash(r.recoveredCompleteHeader),actualTypeSHA256:hash(r.actualObservation.typePrettyExplicit),sourceResultText:r.sourceResultText,actualResultSHA256:hash(a.result),binders:checks,meaning:r.sealedReconstructedMeaning,catalogNote:r.catalogNote,oldSealedCompleteRegionSHA256:r.sealedCompleteRegionSHA256};
});
const boundAuthorBinder=read(project,'reviews/publication/primitive-compiler-c31/metadata-v3/author-binder-definition-audit.json');
for(const r of roots){const b=boundAuthorBinder.whole_module_inventory.find(b=>b.name===r.name);ok(b,'bound source block');ok(b.definition_audit.exact_source_region.replace(/\s+/g,' ').trim().startsWith(r.recoveredCompleteHeader.replace(/\s+/g,' ').trim()),'recovered header not exact bound source prefix '+r.name);}
const meta=read(reviewer,'phase4-metadata-alignment-index.json');
ok(rootIndex.every(r=>meta.rows.some(m=>m.name===r.name&&m.actualTypeSHA256===r.actualTypeSHA256&&m.private===r.private)),'metadata-to-actual vector');
const stats=targetModules.map(module=>{const own=wanted.filter(x=>x.row.module===module);return{module,roots:roots.filter(r=>r.module===module).length,generated:generated.filter(r=>r.module===module).length,owned:own.length,axioms:[...new Set(own.flatMap(x=>x.row.axioms))].sort(),privateSource:roots.filter(r=>r.module===module&&r.sourcePrivate).length,unsafe:own.filter(x=>x.row.isUnsafe).length,selfAxioms:own.filter(x=>x.row.selfOccursInAxioms).length,axiomInfo:own.filter(x=>x.row.actualKind==='axiomInfo').length,valuesNotRequested:own.filter(x=>x.row.valueTextRequested===false&&x.row.valuePrettyExplicitAllowOpaque===null).length};});
ok(stats.every(s=>!s.unsafe&&!s.selfAxioms&&!s.axiomInfo),'unexpected trust flag');
console.log(JSON.stringify({schema:'C31_PHASE4B_INDEPENDENT_DECODER_ADDENDUM_CROSSCHECK_V1',scope:'ORIGINAL_SOURCE_FIRST_REVIEWER_AFTER_SEALED_METADATA_JUDGMENT',fileIndex,preDecoderSealSHA256:hash(bfile(reviewer,'phase4-metadata-alignment-seal.json')),authorizedPayloadHashesChecked:true,unreadManifestEntries:Object.keys(bindings.files).filter(n=>!names.includes(n)),actualRecordObjectEquality:{roots:62,generated:94,owned:156,allFieldsCompared:true},all73ReportedPublicHashesMatchPriorIndependentIndex:true,ownParser:'INDEPENDENT_BALANCED_TEXT_PI_SPLITTER_NOT_DECODER_CODE_OR_KERNEL_EXPR_SERIALIZATION',stats,roots:rootIndex,oldDecoderPacketHashesReportedNotIndependentlyOpened:{sourceSeal:report.oldSourceSealSHA256,contracts:report.oldContractsSHA256,reconstruction:report.oldReconstructionSHA256},oldCatalogDefects:report.oldCatalogDefects,remaining:'PARENT_EXACT_DECODER_EVIDENCE_WRAPPER_AND_CANDIDATE_LATE_BINDING_PENDING',sourceAgreement:null,publicationBinding:null,accepted:false,nativeAccepted:false,main_admission:false,scientific_ROOT:false,PURIFIED:false},null,2));

