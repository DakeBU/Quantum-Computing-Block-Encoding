# C31 Phase3: bounded CI4 evidence review

Status: ACTUAL_PUBLIC_EVIDENCE_CONSISTENT_WITH_RECORDED_DIAGNOSTIC; THREE_TARGET_NATIVE_AXIOMS_OPEN; NO_ADMISSION.

Reviewer continuity: the original source-first reviewer, not a replacement, decoder, or author. The eleven pre-existing Phase1/Phase2/v3/v4 files were rehashed and remain byte-identical. The original first-hand S1–S10 reconstruction remains the mathematical baseline. No prior static finding is silently promoted to a runtime, kernel, or publication certificate.

## 1. Authorized evidence and actual work

New evidence is exactly 73 regular files in the authorized CI4 public capture, here called $CAPTURE. I read all bytes for hashing, strictly parsed every JSON object including duplicate-key rejection, and strictly parsed all 204 observation-stdout records. There are 40 process files, 24 resource pre/post/observation files, and nine aggregate files. All 72 receipt-listed derivatives exist exactly once and their actual public hashes match. The receipt file is the 73rd file, not self-hashed by that receipt.

The read-only reviewer analyzer and two resulting indices are new $REVIEWER/phase3-ci4-* files. It launched only Node for local text/JSON/hash analysis, not Lean or a runner. No imported analyzer/validator was executed. Its PASS status means its stated bounded checks, not scientific acceptance.

Necessary original runner code actually inspected: V1 runner and validator; CI2 runner/resource gate; CI3 runner/resource gate; CI4 runner/resource gate; Collector.lean; pending Profile.lean and Probe.lean; shared C29 instrumentation lines 1–228 only, ending at the public exporter; and the current C31 workflow entry source. Relevant profiles/manifests were parsed to compare necessary byte pins, not to adopt their classifications. Twenty-one necessary code/metadata hash entries and 31 project input pins are in the evidence index. Manifest entries naming handoffs, old analyses, tests, or freeze/build scripts were not opened or used as semantic evidence. This is not a claim that every file named by every nested manifest was independently reviewed.

Original source SHA remains 5907262565b6202fec61b189c42d942cb84d6215223a0da4211d63b92d3ad168. The previously reviewed formal context rehashes to a0b798f1e74b084274a44061514f7944ea6b694c13af2b8f718a27ea7b0ac408. All 87 actual source-root identities/kinds/private flags were compared in order against both the profile and that original independently reviewed inventory. Complete target sources and bounded provider mathematics remain the previously sealed Phase2 reading; this phase did not claim to reread the entire provider closure.

Not read: job.raw.json, artifact.raw.json, decoder packets, sibling/other-reviewer results, new author mathematics, CI test results, C29 new-run artifacts, native caches/binaries, handoffs, or prohibited author scripts. Parent scheduling reports concerning C29 are not evidence here. No network, Git, Lean, proof repair, production write, checker admission, or child agent.

## 2. Transport and execution identity

The supplied ZIP SHA 5f727a0947f3f6f00cb313b292609a21d553de23094ecfa6088b90e87027666d is only a supplied transport locator; the ZIP itself was not opened or independently rehashed within this authorization.

Receipt comparison finds 33 raw/public hashes equal and 39 changed derivatives. For changed files, the raw hash is a reported commitment; the public bytes cannot independently reproduce erased raw bytes. In particular, observation stdout has reported raw SHA 110fd5b6c29eafb183d194634df2b290a83c1941a6c103124c61fbc69d6d9e39 and 773895 raw bytes, versus independently rehashed public SHA a1c6025fa6f90eb449a08a6857da2f858757282bba775b3767135dce2cc63c2b and 773670 public bytes. The index binds the actual derivative used.

All sixteen resource contexts consistently identify run 38986418195, job c31-native-diagnostic-independent, and GITHUB_SHA 905232845190c462c45bb2ff90d5d244456ed2f0. The task supplied API job 117258839657/head54f2225. These are different identifiers; the public files alone do not attest the exact executed checkout or establish the merge-context/head relation. I do not equate them. Workflow source is a locally inspected entry description, not independent API attestation.

## 3. Actual process, fresh cohort, input and driver bindings

All eight process result/started/setup/observation tuples agree on PID, streams, actual arguments and result, exit 0, and no timeout. Pre/post timestamps bracket their process receipts. Wrapper PID is 6267. Every actual argv contains exactly one --threads=1 and --memory=5120; the adapter retains the requested V1 3072 description separately.

| Stage | PID | Recorded wall seconds | Timeout seconds |
| --- | ---: | ---: | ---: |
| help | 6268 | 0.032038 | 30 |
| prefix | 6271 | 0.032117 | 30 |
| PrimitiveMacros | 6278 | 42.483701 | 900 |
| UniformlyControlledRy | 6292 | 2.919163 | 900 |
| CubicAmplitudePrimitive | 6297 | 2.268706 | 900 |
| Collector driver | 6307 | 1.266563 | 900 |
| Profile driver | 6313 | 0.916125 | 900 |
| observation | 6318 | 4.222762 | 900 |

Help stdout reports Lean 4.33.0, release d8b18978322de05a8f3dba51ef03cf5461676c17. The reported executable SHA is e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550; I did not inspect/re-execute that executable. Target stdout contains linter/deprecation warnings and tactic suggestions; I do not call these streams warning-free. All eight stderr derivatives are empty; driver compile stdout is empty. No unexpected line occurs in the observation stream.

Cohort ID is 879743fff94a4402af1fc621be205025. Compile order is Macros → Uniform → Cubic. Each target receipt has equal before/after/copied-source hashes, exactly matching the three previously reviewed source bytes:
- Macros: bd5ada5cb61430ea9d32ce1b3adbd84e6b13d8c3fe2c1b6f2758da2a06903664.
- Uniform: 78d1aed9bb4068bcee138b665bd93a389463bbb591108837758a6d80752a1cf1.
- Cubic: 48c9a4a1c47c925c93493eede21eb7b492d23d2cb7dadf254782e4485c349cb3.

All 31 current project input files rehash to their recorded pins and byte lengths, and agree with the raw87 profile vector: 28 Lean sources including the three targets, plus lean-toolchain/lakefile.lean/lake-manifest.json. No claim that all 28 source files were mathematically reread this phase follows from hashing them.

Collector source hash d7032780427c14c006203d46d2589124bafb48209fbc9b9fbf8ef8813fbba231, Profile source hash 3a413352840c7166ad54c81eaf7edcf5c82a4e7628c581465a2bf016a51bf0eb, and Probe source hash f5f5baf35938472d30b3792a4722f1066abce2ca92358ec7e0f1b9f030484723 match the actual driver-binding receipts and authorized local driver sources. The generator deterministically renders exactly the three imports and 87 source-root specifications, compares its output with frozen pending driver hashes, then compiles Collector/Profile before running Probe. No acceptance predicate is rendered.

The source runner refuses an existing output/cohort, forbids target inheritance during provider copying, checks target sidecars absent before each compile, uses fresh cohort then driver as LEAN_PATH prefixes, removes the project build/root fallback entries, and rechecks source/artifact pins after stages. Each actual binding resolves its target .olean to the corresponding fresh-cohort path and records a successful comparison. Fresh output hashes and driver .olean hashes are present as receipts, not binary bytes in public. I therefore verify the receipt/source-code binding and stdout path checks, not an independent local rehash of the historical .olean bodies or an actual native load trace.

The 25 project-provider .olean copy receipts have unique module names, exclude all targets, equal the exact declared provider set, and have the expected project-build source and fresh-cohort destination coordinates and well-formed hashes. The 44754 provider-inventory entries instead cover external/native search roots, with unique paths and well-formed hashes/sizes. Project copy membership in that different external inventory is neither required nor claimed: project providers have separate copy/recheck receipts. These are inherited-artifact receipts, not 44754 source proofs inspected or known actual loaded dependencies. Sixteen external search roots are configured, seven marked absent. Neither this review nor the runner claims clean-transitive trust or traced native loads outside the inventory.

## 4. Resource process: what can actually be checked

All sixteen pre/post snapshots report complete/gatePassed, budget 5120 MiB plus reserve 2048 MiB, required headroom 7516192768 bytes. Recomputing min(MemAvailable, every finite nonroot maximum-minus-current) agrees everywhere; observed effective headroom ranges from 15289970688 to 15472046080 bytes. Each snapshot has two nonroot groups, eleven file-read receipts, one self-namespace readlink receipt and twelve successful attempt records. Logical coordinate sets, attempt/receipt hashes and byte counts, namespace hash, memory arithmetic, and failed-read null fields agree. All recorded nonroot oom/oom_kill counters are zero; this is not a per-PID OOM attribution theorem or a continuous peak-RSS observation.

CI4 dynamically supplies the self-only sampler through CI3/CI2 callbacks, preserving revalidation and finite budget rewriting. It does not request PID1. The required self cgroup namespace inode is 4026531835 (0xEFFFFFFB). The code correctly labels this as an implementation fingerprint, not binary attestation. The true-root memory interfaces are typed DOCUMENTED_TRUE_ROOT_NOT_APPLICABLE_NOT_UNLIMITED, with null values, readRequested=false and unlimitedObserved=false; nonroot raw max is distinct from true-root NA. No unknown value is treated as unlimited.

The sampler's code checks actual membership/mount ancestry and raw resource bytes at run time. But the public sanitizer has erased absolute resource paths and does not export original proc/cgroup file contents. I cannot replay those exact original-path ancestry checks or derive the raw file hashes from absent bytes. This is a bounded public-evidence limitation, not evidence of an observed bad ancestry. Nor are two endpoint samples an enforcement mechanism for all concurrent memory consumption.

## 5. Full observation partition, types, axioms and omissions

The actual 204 lines are exactly 3 bindings + 87 roots + 113 generated + 1 terminal summary, with no trailing/unexpected stream line. All 200 actual identities are unique, and emitted root/generated sets equal each module's actual owned-name inventory exactly, not a guessed name-prefix census.

| Module | Source roots | Generated | Owned | All owned private |
| --- | ---: | ---: | ---: | ---: |
| PrimitiveMacros | 43 | 55 | 98 | 10 |
| UniformlyControlledRy | 19 | 39 | 58 | 24 |
| CubicAmplitudePrimitive | 25 | 19 | 44 | 0 |

The eight private source roots are not the same count as 34 private owned constants. Private API user names resolve to their source identities; generated auxiliaries remain outside the 87 count. Actual structure constructor and all four MonomialProgram projections are represented and their field metadata agree with the root specification.

All 200 actual type strings were mechanically parsed and individually indexed with UTF8 length/SHA, universe vector, stdout line, actual/kernel kind, complete axiom vector, and omission state. They total 528330 type-text bytes; 38 records have nonempty universe parameter vectors. None is empty or contains ⋯, …, ..., or a redaction token. Kind totals: 68 defnInfo, 126 thmInfo, 1 inductInfo, 1 ctorInfo, 1 recInfo, 3 axiomInfo. All recorded isUnsafe flags are false. The only observed axiom union is propext, Classical.choice, Quot.sound, and the three target-generated native axioms below; no sorryAx is observed.

This is an exhaustive text/record-field check, not a claim to have semantically rederived every one of 528330 pretty-print bytes or every generated proof. Named mathematical type inspections include exact H-program equality, general complex phase-permutation composition, both post-colon Pi binder roots 055/056, full controlled-Ry equality and reference count types, and concrete Cubic wrapper/resource signatures. Full mathematical target-source proofs were already independently checked in sealed Phase2. Pretty-print text is explicitly ACTUAL_META_PPEXPR_NOT_LOSSLESS_EXPR_SERIALIZATION.

No value text is requested or supplied for any of 200 records. Precisely 194 report NOT_REQUESTED_VALUE_AVAILABLE; six report NOT_REQUESTED_NO_VALUE_AVAILABLE: MonomialProgram, its mk and rec, and the three native axiomInfo constants. These omissions are typed and not missing-proof exceptions. Definitions/proofs present in the environment are not thereby independently body-audited here. A high-level verified-wrapper type alone does not reveal its concrete field values.

## 6. ci versus ki: precise field provenance

Collector iterates ci from env.constants.toList, selects module ownership using env.getModuleIdxFor? against the actual target module index, and finds ki separately through env.toKernelEnv.find?. It aborts unless kind(ki)=kind(ci), ki.type=ci.type and ki.levelParams=ci.levelParams. Thus the recorded kernelRootPresent, kernelKind and type/universe agreement checks are meaningful. The printed type is nevertheless Meta.ppExpr(ci.type), and universe parameters/actualKind are read from ci, not directly printed from ki.

isUnsafe, actualOpaqueInfo, actualAxiomInfo, hasValue and allowOpaque value availability are ci/API fields. The code cross-checks ci availability internally; it does not compare ci.value with ki.value or print either body. Private/user names use actual name APIs; sourceKind/sourcePrivate/sourceUserName are profile expectations. Axiom vectors come from actual collectAxioms(actualName), explicitly using imported extension plus local bodies, not solely from ki fields.

Consequently it would be false to say every output field was taken directly from ki. For the recorded types/kinds/universes, the explicit exact-expression guards address the ci/ki origin difference; I found no concrete semantic mismatch caused by that mixture. I do not invent a new acceptance criterion requiring all API fields to be direct ki fields. The real boundedness is that body equality, value text, and full trust closure are not observed. Axiom collection is evidence of reported transitive dependencies, not a printed direct proof-term edge graph.

## 7. Three actual target-owned native axioms: OPEN-NATIVE-3

All three are actual GENERATED rows, owned by module QuantumBlockEncoding.CubicAmplitudePrimitive using module-index attribution, with actualKind=kernelKind=axiomInfo, actualAxiomInfo=true, no value, selfOccursInAxioms=true, actualPrivate=false. They are not merely imported dependencies misassigned by a name prefix.

All names below have prefix QuantumBlockEncoding.CubicDiagonalOracle.

| Generated name suffix | Stdout line | Exact target source site |
| --- | ---: | --- |
| cubicN2Amplitude_abs_le_one._native.native_decide.ax_1_1 | 201 | CubicAmplitudePrimitive.lean:34–41; native_decide at 40 |
| cubicN2ControlIndex_encode._native.native_decide.ax_1_1 | 202 | CubicAmplitudePrimitive.lean:86–93; native_decide at 93 |
| cubicN2EncodeBits_context_eq_iff._native.native_decide.ax_1_1 | 203 | CubicAmplitudePrimitive.lean:95–100; native_decide at 100 |

Their actual type texts are Bool equality of Decidable.decide for the finite proposition to Bool.true, not the original high-level theorem text. The source propositions respectively express rational cubic absolute bound (then cast to Real), encode/decode control index, and signal-independent context equality iff equality of the four-valued system index. The original Phase1 rational and bitwise derivations still justify the mathematics independently; this does not remove the actual native dependencies.

All actual collectAxioms consumers are exhaustively listed with exact stdout lines in phase3-ci4-evidence-index.json:
- Amplitude axiom: 19 consumers including itself = 16 explicit roots + cubicN2Angle.eq_1 + cubicN2PrimitiveVerifiedBlockEncoding._proof_1 + itself. The 16 are the amplitude theorem, Angle, Circuit, Program, both eval theorems, cleanEntry, FlatUnitary, its unitary theorem, its cleanBlock theorem, Presentation, Resource, OperatorCandidate, VerifiedBlockEncoding, oracleCalls_eq_zero, resource_faithful.
- Control-index axiom: six including itself = cubicN2ControlIndex_encode, cleanEntry, FlatUnitary_cleanBlock, VerifiedBlockEncoding, wrapper _proof_1, itself.
- Context-equality axiom: seven including itself = cubicN2EncodeBits_context_eq_iff, cleanEntry, FlatUnitary_cleanBlock, VerifiedBlockEncoding, context theorem _simp_1, wrapper _proof_1, itself.

The union of affected observed constants is 24, all in Cubic; neither Macros nor Uniform has a collected native axiom. Some definitional resource/presentation constants inherit the amplitude-bound proof through ExactAngle, which explains their axiom vector without claiming numerical resource mathematics intrinsically needs native computation.

In particular the actual final VerifiedBlockEncoding and clean-block theorem carry all three. If ordinary-kernel admission means proofs from the ordinary specified axiom baseline without these native-generated axioms, this evidence does NOT satisfy it. The Lean kernel can accept declared axioms and proofs using them; exit 0 is not a proof that no extra axioms were used. This is an actual remaining native-trust/admission dependency, not mathematical falsity or an implementation compile failure. Prior C29 nine-item kernel repairs are irrelevant to eliminating these three current constants. No repair is authorized or performed.

## 8. Retained source-first mathematical and publication boundaries

Earlier F1/F2 and v4 OPEN-F3-D1 resolutions remain STATIC_ONLY; this run does not newly attest author graphs. Actual Pi types 055/056 include their complete context-function arguments and only control/target separation, not injectivity. The compiler's noninjective-control regime, exact phase/order requirements, recursive denotation versus direct full-block theorem, and independent unitarity/clean/wrapper/count obligations remain as previously independently analyzed.

Seven slot limits remain unchanged: (1) exact target/normalizer, not normalized state or rank-one loading; (2) finite complex named-wire semantics, Cubic only n=2 and flat j+4s; (3) repeated controls allowed but none equals target, no free angle producer; (4) full context preservation and one finite signal, no deterministic clean return; (5) exact global/relative phases, not probability-only equality; (6) exact ideal entries with d_j-squared success, no positive uniform success/numerical certificate; (7) reference Ry=2^n and CX=2(2^n−1), finite 4/6, no scalable polynomial cubic arithmetic, finite-bit/Clifford+T, optimization or preprocessing guarantee.

F4 remains a boundary: generic candidate fields are arbitrary Prop; the previously source-inspected concrete Cubic definitions supply particular physics predicates, but this type-only runtime export does not itself unfold/attest those values. F5 remains a boundary: public native execution/pretty-print evidence is not source agreement, finite-bit presentation correctness, clean-transitive trust, scientific ROOT, or publication admission. The three native axioms are now a specifically observed instance, not an old hypothetical flag.

## 9. Bounded verdict and stop

Supported: internally consistent public derivative hash/receipt bindings; actual eight exit-zero process observations; recorded fresh three-target source/cohort/driver bindings; exhaustive 87+113 owned record partition, actual type/axiom/omission fields; and independently checked public logical resource accounting. Supported negative finding: exactly three actual target-generated native axioms propagate into the concrete clean-block/verified result.

Not established: exact executed checkout/API-head attestation, reconstruction of sanitized raw resource paths/bytes, independent historical binary/.olean body rehash, actual-load tracing/clean-transitive closure, full value/proof-body audit, ordinary-baseline axiom admission, sourceAgreement, scientific acceptance, publicationBinding, nativeAccepted, ROOT/main, or PURIFIED.

All acceptance/trust fields remain false/null. Eleven old artifacts remain immutable. New artifacts are sealed only as this bounded review. STOP; further formal/body/bridge/admission work needs separate authorization.

