// Read-only evidence analysis. No Lean, process launch, network, or filesystem write.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const [cap, project, contextFile] = process.argv.slice(2);
function ok(x,m){if(!x)throw Error(m);}
function hash(x){return crypto.createHash('sha256').update(x).digest('hex');}
function bytes(p){return fs.readFileSync(p);}
function strict(s){
 let i=0;
 function ws(){while(/\s/.test(s[i]||'')&&i<s.length)i++;}
 function str(){const st=i++;while(i<s.length){if(s[i]==='\\'){i+=2;continue;}if(s[i++]==='"')return JSON.parse(s.slice(st,i));}throw Error('unterminated JSON string');}
 function val(){ws();const c=s[i];if(c==='"')return str();
  if(c==='{'){i++;ws();const o=Object.create(null),seen=new Set();if(s[i]==='}'){i++;return o;}while(true){ws();ok(s[i]==='"','JSON key');let k=str();ok(!seen.has(k),'duplicate JSON key '+k);seen.add(k);ws();ok(s[i++]===':','JSON colon');o[k]=val();ws();let z=s[i++];if(z==='}')return o;ok(z===',','JSON object separator');}}
  if(c==='['){i++;ws();let a=[];if(s[i]===']'){i++;return a;}while(true){a.push(val());ws();let z=s[i++];if(z===']')return a;ok(z===',','JSON array separator');}}
  const m=/^(?:true|false|null|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?)/.exec(s.slice(i));ok(m,'JSON primitive');i+=m[0].length;return JSON.parse(m[0]);}
 const r=val();ws();ok(i===s.length,'JSON trailing data');return r;
}
function read(p){return strict(bytes(p).toString('utf8'));}
function load(n){return read(path.join(cap,n));}
function eq(a,b){return JSON.stringify(a)===JSON.stringify(b);}
function unique(a,m){ok(new Set(a).size===a.length,'duplicate '+m);}
function noAccept(o){for(const [k,v]of Object.entries({sourceAgreement:null,axiomPolicyPass:null,publicationBinding:null,scientificAcceptance:false,nativeAccepted:false,trustClosure:false})){ok(k in o&&o[k]===v,'acceptance field '+k);}}
const fileNames=fs.readdirSync(cap).sort();
ok(fileNames.length===73,'not 73 files');
const fileIndex=fileNames.map(n=>{let p=path.join(cap,n),st=fs.lstatSync(p);ok(st.isFile()&&!st.isSymbolicLink(),'nonregular public file');return {logicalPath:'$CAPTURE/'+n,bytes:st.size,sha256:hash(bytes(p))};});
const allJSON=Object.fromEntries(fileNames.filter(n=>n.endsWith('.json')).map(n=>[n,load(n)]));
const receipts=allJSON['raw-derivation-receipts.json'].files;
ok(receipts.length===72,'receipt count');unique(receipts.map(r=>r.publicRelativePath),'receipt');
ok(eq(receipts.map(r=>r.publicRelativePath).sort(),fileNames.filter(n=>n!=='raw-derivation-receipts.json')),'receipt exact set');
for(const r of receipts){ok(fileIndex.find(f=>f.logicalPath==='$CAPTURE/'+r.publicRelativePath).sha256===r.publicSHA256,'public hash mismatch');ok(/^[0-9a-f]{64}$/.test(r.rawSHA256)&&Number.isInteger(r.rawBytes)&&r.rawBytes>=0,'raw receipt malformed');}
const rawFor=n=>receipts.find(r=>r.publicRelativePath===n);
const stages=['01-help','02-prefix','11-target','12-target','13-target','21-driver','22-driver','30-observe'];
const processIndex=[],resourceIndex=[];
for(const label of stages){
 const setup=load(label+'.setup.json'),started=load(label+'.started.json'),result=load(label+'.result.json');
 const observation=load('ci2-'+label+'.observation.json'),pre=load('ci2-'+label+'.preflight.json'),post=load('ci2-'+label+'.postflight.json');
 noAccept(observation);noAccept(pre);noAccept(post);
 ok(result.PID===started.PID&&result.PID===post.childPID,'PID binding');
 ok(eq(observation.nativeResult,result)&&eq(observation.actualArgv,setup.argv),'result/argv binding');
 ok(result.exitCode===0&&result.timedOut===false&&result.wallSeconds>=0,'process result');
 ok(Date.parse(started.startedUTC)>=Date.parse(result.startedUTC)&&Date.parse(result.finishedUTC)>=Date.parse(started.startedUTC),'process time order');
 ok(Date.parse(pre.finishedUTC)<=Date.parse(result.startedUTC)&&Date.parse(post.startedUTC)>=Date.parse(result.finishedUTC),'resource bracket');
 ok(observation.classification==='PROCESS_EXIT_ZERO'&&observation.actualStreamHashesMatch===true&&observation.actualPIDResultReceiptsMatch===true,'observation flags');
 ok(observation.preflightSHA256===rawFor('ci2-'+label+'.preflight.json').rawSHA256&&observation.postflightSHA256===rawFor('ci2-'+label+'.postflight.json').rawSHA256,'raw snapshot binding');
 for(const stream of ['stdout','stderr']){const r=rawFor(label+'.'+stream+'.raw.sanitized.txt');ok(result[stream+'SHA256']===r.rawSHA256&&observation[stream+'RawSHA256']===r.rawSHA256,'raw stream binding');}
 ok(setup.argv.filter(x=>x==='--memory=5120').length===1&&setup.argv.filter(x=>x==='--threads=1').length===1,'bounded args');
 ok(setup.wrapperPID===observation.wrapperPID&&setup.wrapperPID===pre.wrapperPID&&pre.wrapperPID===post.wrapperPID,'wrapper PID');
 processIndex.push({stage:label,PID:result.PID,wrapperPID:setup.wrapperPID,exitCode:0,timedOut:false,wallSeconds:result.wallSeconds,startedUTC:result.startedUTC,finishedUTC:result.finishedUTC,timeoutSeconds:setup.timeoutSeconds,stdoutRawSHA256:result.stdoutSHA256,stderrRawSHA256:result.stderrSHA256,stdoutBytes:fileIndex.find(f=>f.logicalPath==='$CAPTURE/'+label+'.stdout.raw.sanitized.txt').bytes});
 for(const [phase,s] of [['pre',pre],['post',post]]){
  ok(s.schema==='C31_CI4_RESOURCE_SELF_NAMESPACE_V1'&&s.observationComplete===true&&s.gatePassed===true,'resource status');
  ok(s.budgetMiB===5120&&s.reserveMiB===2048&&s.requiredHeadroomBytes===7168*1024**2,'resource budget');
  ok(s.context.platform==='linux'&&s.context.CI==='true'&&s.context.GITHUB_ACTIONS==='true'&&s.context.RUNNER_OS==='Linux'&&s.context.GITHUB_RUN_ID==='38986418195','CI context');
  ok(s.cgroupVersion===2&&s.cgroupMountRoot==='/'&&s.cgroups.length>0,'visible hierarchy claim');
  const ns=s.namespaceObservation;ok(ns.selfInode===4026531835&&ns.requiredInitInode===4026531835&&ns.policy==='SELF_ONLY_RESERVED_INIT_V1'&&ns.pid1Observation.readRequested===false&&ns.pid1Observation.value===null,'namespace contract');
  const root=s.rootObservation;ok(root.type==='DOCUMENTED_TRUE_ROOT_NOT_APPLICABLE_NOT_UNLIMITED'&&root.atVerifiedMountRoot===true&&root.coreControllerMemoryObserved===true,'true root NA');
  for(const n of ['memory.max','memory.current','memory.events']){const m=root.memoryInterfaces[n];ok(m.value===null&&m.readRequested===false&&m.unlimitedObserved===false&&m.applicability===root.type,'NA not unlimited');}
  let head=[s.memAvailableBytes];const expected=['$PROC/meminfo','$PROC/self/cgroup','$PROC/self/mountinfo','$CGROUP_REAL_ROOT/cgroup.controllers','$CGROUP_REAL_ROOT/cgroup.procs'];
  for(const [j,g]of s.cgroups.entries()){
   ok(g.logicalPath==='$CGROUP_NONROOT_'+j&&g.atVerifiedMountRoot===false,'nonroot coordinate');
   if(g.memoryMaxBytes===null){ok(g.memoryMaxRaw==='max'&&g.limitUnlimited===true&&g.headroomBytes===null,'unlimited');}
   else{ok(g.memoryMaxRaw===String(g.memoryMaxBytes)&&g.limitUnlimited===false&&g.headroomBytes===Math.max(0,g.memoryMaxBytes-g.memoryCurrentBytes),'finite memory subtraction');head.push(g.headroomBytes);}
   ok(Number.isInteger(g.memoryCurrentBytes)&&g.memoryCurrentBytes>=0&&Object.values(g.memoryEvents).every(x=>Number.isInteger(x)&&x>=0)&&'oom' in g.memoryEvents&&'oom_kill' in g.memoryEvents,'events');
   expected.push(...['memory.max','memory.current','memory.events'].map(n=>g.logicalPath+'/'+n));
  }
  ok(s.effectiveHeadroomBytes===Math.min(...head)&&s.effectiveHeadroomBytes>=s.requiredHeadroomBytes,'effective headroom');
  unique(s.fileReads.map(r=>r.logicalPath),'resource logical file');
  ok(eq(s.fileReads.map(r=>r.logicalPath).sort(),expected.sort())&&s.namespaceReads.length===1&&s.readAttempts.length===expected.length+1,'complete logical read set');
  for(const r of [...s.fileReads,...s.namespaceReads]){const a=s.readAttempts.filter(a=>a.logicalPath===r.logicalPath);ok(a.length===1&&a[0].status==='READ_OK'&&a[0].sha256===r.sha256&&a[0].bytes===r.bytes&&a[0].atVerifiedMountRoot===r.atVerifiedMountRoot&&/^[a-f0-9]{64}$/.test(r.sha256),'resource attempt binding');}
  ok(s.namespaceReads[0].sha256===hash('cgroup:[4026531835]')&&s.namespaceReads[0].bytes===19,'namespace text hash');
  ok(s.failedReadLogicalPath===null&&s.failedReadAtVerifiedMountRoot===null,'failed resource read');
  resourceIndex.push({stage:label,phase,context:s.context,headroomBytes:s.effectiveHeadroomBytes,memAvailableBytes:s.memAvailableBytes,nonrootGroups:s.cgroups.length,fileReads:s.fileReads.length,namespaceReads:s.namespaceReads.length,readAttempts:s.readAttempts.length,oom:s.cgroups.map(g=>g.memoryEvents.oom),oomKill:s.cgroups.map(g=>g.memoryEvents.oom_kill),rootMemoryNA:true,namespaceSelfInode:ns.selfInode,rawProcBytesIncluded:false,absoluteAncestryRedacted:true});
 }
}
const profilePath=path.join(project,'tools/primitive_compiler_native_profile_v1/profile.json'),profile=read(profilePath);
const inputs=load('input-bindings.json');
ok(inputs.projectInputs.length===31&&inputs.profileSHA256===hash(bytes(profilePath)),'input profile binding');
unique(inputs.projectInputs.map(r=>r.relativePath),'project input');
ok(eq(inputs.projectInputs.map(r=>r.relativePath).sort(),Object.keys(profile.projectInputs).sort()),'project input exact set');
const pinIndex=inputs.projectInputs.map(r=>{ok(!r.relativePath.includes('..')&&!path.isAbsolute(r.relativePath),'unsafe input');const b=bytes(path.join(project,r.relativePath));ok(hash(b)===r.sha256&&b.length===r.bytes&&profile.projectInputs[r.relativePath]===r.sha256,'project input drift '+r.relativePath);return{logicalPath:'$PROJECT/'+r.relativePath,bytes:b.length,sha256:r.sha256};});
const cohort=load('fresh-target-cohort.json'),drivers=load('driver-bindings.json'),runtime=load('runtime-environment.json');
ok(cohort.targets.length===3&&eq(cohort.compileOrder,profile.modules.map(m=>m.module)),'fresh compile order');
for(const [j,t]of cohort.targets.entries()){const spec=profile.modules[j];ok(t.module===spec.module&&t.cohortID===cohort.cohortID&&[t.sourceSHA256Before,t.sourceSHA256After,t.copiedSourceSHA256].every(h=>h===spec.rawSHA256),'fresh source pins');ok(eq(t.nativeResult,load('1'+(j+1)+'-target.result.json')),'fresh process receipt');ok(t.artifacts.length>0,'fresh artifact receipt');}
for(const [name,key]of [['Collector.lean','collectorSHA256'],['pending-drivers/Profile.lean','profileDriverSHA256'],['pending-drivers/Probe.lean','probeSHA256']]){ok(hash(bytes(path.join(project,'tools/primitive_compiler_native_profile_v1',name)))===drivers.generatedDrivers[key],'driver source drift');}
ok(runtime.cohortID===cohort.cohortID&&runtime.profileSHA256===inputs.profileSHA256&&runtime.nativeMemoryMiB===5120&&runtime.baseReportedMemoryMiB===3072&&runtime.nativeThreads===1&&runtime.processTimeoutSeconds===900,'runtime binding');
const stdout=bytes(path.join(cap,'30-observe.stdout.raw.sanitized.txt')).toString('utf8');
const lines=stdout.split(/\r?\n/).filter(Boolean), parsed=lines.map((line,j)=>{const k=line.indexOf(' '),tag=line.slice(0,k);ok(['C31_BINDING_JSON','C31_ROOT_JSON','C31_GENERATED_JSON','C31_SUMMARY_JSON'].includes(tag),'stdout tag');let row=strict(line.slice(k+1));noAccept(row);return{tag,line:j+1,row};});
ok(parsed.length===204&&parsed.at(-1).tag==='C31_SUMMARY_JSON'&&parsed.filter(p=>p.tag==='C31_SUMMARY_JSON').length===1,'terminal exact lines');
const bindings=parsed.filter(p=>p.tag==='C31_BINDING_JSON').map(p=>p.row), roots=parsed.filter(p=>p.tag==='C31_ROOT_JSON'),gen=parsed.filter(p=>p.tag==='C31_GENERATED_JSON'),records=[...roots,...gen];
ok(bindings.length===3&&roots.length===87&&gen.length===113,'family counts');unique(records.map(p=>p.row.actualName),'actual name');
const context=read(contextFile);ok(context.inventory.length===87,'old source inventory');
const recordIndex=records.map(p=>{const r=p.row;ok(r.kernelRootPresent===true&&r.kernelTypeAndUniversesAgree===true&&r.kernelKind===r.actualKind,'kernel type guard');
 ok(['axiomInfo','defnInfo','thmInfo','opaqueInfo','quotInfo','inductInfo','ctorInfo','recInfo'].includes(r.actualKind),'unknown kind');
 for(const k of ['actualPrivate','isUnsafe','actualHasValueAllowOpaque','selfOccursInAxioms','actualOpaqueInfo','actualAxiomInfo','sourceOpaque','valueTextRequested'])ok(typeof r[k]==='boolean','missing boolean '+k);
 ok(r.typeTextScope==='ACTUAL_META_PPEXPR_NOT_LOSSLESS_EXPR_SERIALIZATION'&&r.axiomCollection==='ACTUAL_LEAN_COLLECT_AXIOMS_IMPORTED_EXTENSION_AND_LOCAL_BODIES','observation method');
 ok(r.axioms.every(x=>typeof x==='string'&&x)&&r.universeParameters.every(x=>typeof x==='string'&&x),'name/universe vectors');
 ok(typeof r.typePrettyExplicit==='string'&&r.typePrettyExplicit.trim()&&!/[⋯…]|\.\.\./.test(r.typePrettyExplicit),'type omission');
 unique(r.axioms,'axioms');unique(r.universeParameters,'universes');
 ok(r.valueTextRequested===false&&r.valuePrettyExplicitAllowOpaque===null&&r.selfOccursInAxioms===r.axioms.includes(r.actualName),'omission/self consistency');
 ok(r.actualAxiomInfo===(r.actualKind==='axiomInfo')&&r.actualOpaqueInfo===(r.actualKind==='opaqueInfo'),'kind flags');
 const available=['defnInfo','thmInfo','opaqueInfo'].includes(r.actualKind);ok(r.actualHasValueAllowOpaque===available&&r.valueObservation===(available?'NOT_REQUESTED_VALUE_AVAILABLE':'NOT_REQUESTED_NO_VALUE_AVAILABLE'),'value availability');
 return{stdoutLine:p.line,family:p.tag,module:r.module,actualName:r.actualName,sourceUserName:r.sourceUserName??null,sourceKind:r.sourceKind??null,actualKind:r.actualKind,kernelKind:r.kernelKind,typeUTF8Bytes:Buffer.byteLength(r.typePrettyExplicit),typeSHA256:hash(r.typePrettyExplicit),universes:r.universeParameters,axioms:r.axioms,actualPrivate:r.actualPrivate,isUnsafe:r.isUnsafe,selfAxiom:r.selfOccursInAxioms,valueObservation:r.valueObservation,typeScope:r.typeTextScope};
});
for(const [j,p]of roots.entries()){const r=p.row,spec=profile.roots[j],old=context.inventory[j];ok(r.module===spec.module&&r.sourceUserName===spec.sourceUserName&&r.sourceKind===spec.sourceKind&&r.sourcePrivate===spec.sourcePrivate,'profile root vector');ok(old.name===r.sourceUserName&&old.kind===r.sourceKind&&old.private===r.sourcePrivate&&old.module.replace('.lean','').replaceAll('/','.')===r.module,'original source inventory vector');ok(r.actualPrivate===r.sourcePrivate&&r.userNameViaActualAPI===r.sourceUserName,'private API resolution');if(!r.sourcePrivate)ok(r.actualName===r.sourceUserName,'public exact name');ok(({def:'defnInfo',theorem:'thmInfo',structure:'inductInfo'})[r.sourceKind]===r.actualKind,'source kind mapping');}
for(const [j,b]of bindings.entries()){const spec=profile.modules[j],rs=roots.filter(p=>p.row.module===b.module),gs=gen.filter(p=>p.row.module===b.module);ok(b.module===spec.module&&b.profileSHA256===inputs.profileSHA256&&b.cohortID===cohort.cohortID&&b.freshOleanPathComparisonPassed===true,'binding cohort');ok(b.resolvedOleanPath===cohort.targets[j].artifacts.find(a=>a.path.endsWith('.olean')).path,'fresh olean lookup');
 ok(b.ownershipMethod==='ENVIRONMENT_MODULE_INDEX_NOT_NAME_PREFIX'&&b.expectedRoots===spec.sourceRoots&&b.ownedCount===rs.length+gs.length,'ownership contract');
 ok(b.ppDeepTerms===true&&b.ppMaxSteps===2000000&&b.maxRecDepth===10000,'pp options');
 unique(b.ownedNames,'owned');ok(eq([...b.ownedNames].sort(),[...rs,...gs].map(p=>p.row.actualName).sort()),'owned partition exact');
 for(const [k,p]of rs.entries())ok(p.row.moduleOrdinal===k+1,'ordinal');
 for(const p of gs)ok(p.row.includedInExplicitRootCount===false,'generated explicit confusion');
 for(const s of b.structures){const own=records.filter(p=>p.row.module===b.module).map(p=>p.row);ok(own.find(r=>r.actualName===s.actualName&&r.actualKind==='inductInfo'),'structure');
  const sp=profile.roots.find(r=>r.sourceUserName===s.actualName&&r.sourceKind==='structure');if(sp)ok(eq(sp.structureFields,s.fieldNames),'profile structure fields');
  ok(eq(s.fields.map(f=>f.fieldName).sort(),[...s.fieldNames].sort()),'structure field partition');
  for(const f of s.fields)ok(own.find(r=>r.actualName===f.projection&&r.actualKind===f.actualKind),'projection observation');
  for(const c of s.constructors)ok(own.find(r=>r.actualName===c&&r.actualKind==='ctorInfo'),'constructor');
 }
}
const self=recordIndex.filter(r=>r.selfAxiom);
const selfAxioms=self.map(r=>({actualName:r.actualName,module:r.module,stdoutLine:r.stdoutLine,typeSHA256:r.typeSHA256,consumers:recordIndex.filter(c=>c.axioms.includes(r.actualName)).map(c=>({actualName:c.actualName,family:c.family,stdoutLine:c.stdoutLine}))}));
const inventory=load('provider-inventory.json'),copies=load('provider-copies.json');
unique(inventory.artifacts.map(a=>a.path),'provider artifact path');
ok(inventory.artifacts.every(a=>/^[a-f0-9]{64}$/.test(a.sha256)&&Number.isInteger(a.bytes)&&a.bytes>=0),'provider artifact receipts');
ok(copies.files.every(c=>!profile.modules.some(m=>m.module===c.module)&&profile.providers.includes(c.module)),'target inherited as provider');
unique(copies.files.map(c=>c.module),'copied project provider');
ok(eq(copies.files.map(c=>c.module).sort(),[...profile.providers].sort()),'project provider exact set');
for(const c of copies.files){const stem=c.module.replaceAll('.','/');ok(c.source==='$PROJECT/.lake/build/lib/lean/'+stem+'.olean'&&c.destination==='$PROJECT/_out/primitive-compiler-native-profile-v1/cohort/'+stem+'.olean'&&/^[a-f0-9]{64}$/.test(c.sha256),'project provider copy coordinates');}
const summary=parsed.at(-1).row,complete=load('completeness.json'),result=load('result.json');
ok(summary.ownedCompleted===200&&summary.generatedCompleted===113&&summary.rootsCompleted===87&&summary.privateCompleted===8,'summary totals');
ok(complete.observedSelfAxioms===self.length&&complete.observedUnsafe===recordIndex.filter(r=>r.isUnsafe).length&&eq(complete.observedAxiomUnion,[...new Set(recordIndex.flatMap(r=>r.axioms))].sort()),'completeness independent recomputation');
const codeIndex=[];
function codePin(rel,expected){const b=bytes(path.join(project,rel)),h=hash(b);ok(h===expected,'necessary code/metadata pin drift '+rel);codeIndex.push({logicalPath:'$PROJECT/'+rel,sha256:h,bytes:b.length});return b;}
const base='tools/primitive_compiler_native_profile_v1/',c2='tools/primitive_compiler_native_profile_ci2/',c3='tools/primitive_compiler_native_profile_ci3/',c4='tools/primitive_compiler_native_profile_ci4/';
const p2=read(path.join(project,c2+'ci2-profile.json')),p3=read(path.join(project,c3+'ci3-profile.json')),p4=read(path.join(project,c4+'ci4-profile.json'));
const m1=read(path.join(project,base+'proposal-bindings.json')),m2=read(path.join(project,c2+'ci2-bindings.json')),m3=read(path.join(project,c3+'ci3-bindings.json')),m4=read(path.join(project,c4+'ci4-bindings.json'));
const bind=runtime.ci2Binding,b3=bind.ci3Binding,b4=b3.ci4Binding;
for(const [rel,h] of [[base+'profile.json',bind.baseRaw87ProfileSHA256],[base+'proposal-bindings.json',bind.base14FileManifestSHA256],[c2+'ci2-profile.json',bind.ci2ProfileSHA256],[c2+'ci2-bindings.json',bind.ci2CodeManifestSHA256],[c3+'ci3-profile.json',b3.profileSHA256],[c3+'ci3-bindings.json',b3.manifestSHA256],[c4+'ci4-profile.json',b4.profileSHA256],[c4+'ci4-bindings.json',b4.manifestSHA256]])codePin(rel,h);
ok(eq(p4.priorFiles,m3.files)&&eq(p3.priorFiles,m2.files)&&eq(p2.baseFiles,m1.files),'nested manifest exact vectors');
for(const [baseDir,manifest,names] of [[base,m1,['runner.py','validator.py','Collector.lean','pending-drivers/Profile.lean','pending-drivers/Probe.lean']],[c2,m2,['runner_v2.py','resource_gate.py']],[c3,m3,['runner_v3.py','resource_gate_v3.py']],[c4,m4,['runner_v4.py','resource_gate_v4.py']]])for(const n of names)codePin(baseDir+n,manifest.files[n]);
codePin(profile.sharedInstrumentation.path,profile.sharedInstrumentation.sha256);
for(const x of resourceIndex){ok(x.context.GITHUB_JOB==='c31-native-diagnostic-independent','CI job context');}
for(const label of stages)ok(eq(load('ci2-'+label+'.preflight.json').binding,bind)&&eq(load('ci2-'+label+'.postflight.json').binding,bind)&&eq(load('ci2-'+label+'.observation.json').binding,bind),'per-stage nested binding');
const workflowRel='.github/workflows/c31-native-diagnostic.yml',workflow=bytes(path.join(project,workflowRel));
codeIndex.push({logicalPath:'$PROJECT/'+workflowRel,sha256:hash(workflow),bytes:workflow.length,scope:'LOCAL_NECESSARY_ENTRY_SOURCE_NOT_CI_API_ATTESTATION'});
ok(workflow.toString('utf8').includes('lake env python3 -B tools/primitive_compiler_native_profile_ci4/runner_v4.py'),'workflow entrypoint');

const tally=k=>Object.fromEntries([...new Set(recordIndex.map(r=>r[k]))].map(v=>[v,recordIndex.filter(r=>r[k]===v).length]));
console.log(JSON.stringify({status:'BOUNDED_READONLY_CHECKS_PASSED_NOT_ACCEPTANCE',fileIndex,codeIndex,pinIndex,processIndex,resourceIndex,recordIndex,selfAxioms,counts:{files:fileIndex.length,receipts:receipts.length,lines:lines.length,roots:roots.length,sourcePrivate:roots.filter(p=>p.row.sourcePrivate).length,generated:gen.length,owned:records.length,allOwnedPrivate:recordIndex.filter(r=>r.actualPrivate).length,kind:tally('actualKind'),values:tally('valueObservation'),unsafe:recordIndex.filter(r=>r.isUnsafe).length,selfAxioms:self.length,typeUTF8Bytes:recordIndex.reduce((n,r)=>n+r.typeUTF8Bytes,0),providerArtifactReceipts:inventory.artifacts.length,providerCopyReceipts:copies.files.length,projectInputs:pinIndex.length},bindings,cohort,drivers,runtime,actualContextSHAs:[...new Set(resourceIndex.map(r=>r.context.GITHUB_SHA))],axiomUnion:complete.observedAxiomUnion,transportReceiptBoundary:'Public hashes rehashed. Raw hashes cannot be rederived where sanitizer changed bytes. No binary/provider/actual-load reinspection.',noAccept:{sourceAgreement:null,axiomPolicyPass:null,publicationBinding:null,scientificAcceptance:false,nativeAccepted:false,trustClosure:false}},null,2));

