# C45: current production versus the reviewed paired kernel candidates

Original reviewer `/root/primitive_compiler_source_first_c31`; diagnosis run `c45-production-obstruction/20261017T091230Z`. Original natural-source derivation and Phase6–8 history remain available and sealed. This is an obstruction diagnosis, not accepted-role evidence or a policy-change request.

## Finding

The minimal next step is a **single exact paired proof-only adoption**, followed by genuine current-context role bindings and the unchanged integration gates—not a different scientific target, relaxed verifier, scoring rule, or native-axiom exception. This diagnosis does not perform or authorize that installation.

| Source | Current production | Reviewed candidate | Exact delta |
| --- | --- | --- | --- |
| CubicAmplitudePrimitive | `48c9a4a1…` | `952e2b35…` | Three proof substitutions |
| CubicStatePreparation | `d125f8c2…` | `6ee53311…` | Nine proof substitutions |

Full hashes and every current source/config pin are in `pins.json`. Current Cubic is 9510 bytes; the stored candidate is 9513 bytes. Independently replacing only the three `native_decide +revert` proof lines 40/93/100 with `decide +kernel +revert` reproduces its complete candidate bytes. Independently applying the previously sealed CSP nine-site map to the actual current CSP bytes yields exactly the reviewed `6ee53311…` candidate: eight `decide +kernel` replacements and one local `exact Rat.sub_self`. All other bytes, including statements, binders, ordinary definitions, imports/options, layout, normalization, literal gate list and resource expressions, are unchanged. Different Prop proofs are not different amplitude data; no proof-body equality is claimed.

All 31 current original source/config pins equal the joint CI's original-input map. Thus the current source relation to the joint shadow workspace is exactly the two candidate replacements, not an already-installed repair. Current toolchain is Lean v4.33.0; toolchain, lakefile and manifest hashes are unchanged. The manifest's Mathlib revision is pinned, not inferred from a floating tag.

## What was actually proved about native dependencies

“87 native blocker” must not be read as 87 axioms. C31 has 87 explicit source roots, including eight private, and its original actual observation contained **three** target-owned generated native axioms in the Cubic module. CSP separately had nine. Current production still contains those original proof calls. No new current-production kernel process was run here.

The reviewed candidate observations—not the current production checkout—show the removal:

- Separate C31 candidate: all 87 roots and dynamically observed 113 generated declarations were checked; its exact three old native axioms disappeared, three ordinary generated theorem rows appeared, and 197 surviving rows' recursive axioms were exactly old-minus-three. Twenty-one surviving owned consumers were affected.
- Joint candidate cohort `612290bf907a4a55b9ecb79ac379c263`: fresh CSP first, then Macros, Uniform, Cubic. CSP's original nine disappeared, eight generated rows appeared, and all 760 surviving owned closures were exactly old-minus-nine, affecting twelve surviving consumers. The new joint C31 200 and CSP 768 complete captured rows match their separately actual candidates; two supplemental CSP full types also match.

That candidate union is exactly `Classical.choice`, `Quot.sound`, `propext`, **not axiom-free**. The old observations identify generated target-owned axioms by actual module ownership, not name-prefix attribution of imported axioms. The 96 incomplete CSP generated value texts, 22 null generated values, omitted source bodies, C31's unrequested value text, and missing original CSP two complete generated signatures remain explicit limits. Existing full source/type/finite reasoning is reused by exact equality; no all-PP-proof-text reread is needed or claimed.

## Source alignment is not TCB authorization

Current `tools/proof_trust.py` scans stripped source for `sorry`, `admit`, `axiom`; its companion checker has no approved sorry entries. It is not a generated-kernel-axiom collector and does not detect `native_decide`'s generated axioms merely by that source token. Current `check_research_publications.py` explicitly describes itself as evidence-integrity checking, not semantic equivalence or fabricated-identity detection. Neither observation is a permission to skip existing trust gates.

No human positive TCB authorization is established by this review. Equally, absence of such evidence here is **not evidence of an existing policy ban**, and this diagnosis does not manufacture a new consent requirement or request a policy exception. Apply the unchanged governing policy. A source-aligned proof and a green diagnostic are not themselves nativeAccepted or scientific authorization; using ordinary kernel proofs also does not remove trust in Lean, its imported library, compiler/runtime and the stated ordinary axioms.

## Already available versus still needed

Available: immutable own natural/static/actual reviews, exact candidate byte maps, complete captured statement/type comparisons, and the successful joint provider-consumer cohort. Published Phase6/7/8 ZIP members were individually matched byte-for-byte to my original files. The joint ZIP is `c540fc35…`, the separate candidate ZIP `3e69139f…`. The joint cohort compiler binary SHA is `e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550`; its target olean hashes and source pins are recorded. It inherited 24 project providers and 44754 external/native artifacts; this is not clean-transitive rebuilding or an OS load trace.

Unknown here: the currently installed compiler executable, current compiled provider/target cache, and a new current-production cohort. A toolchain file hash does not identify those binaries. Do not relabel old Linux receipts as a fresh local production build. At integration, preserve the actual compiler/provider/source/cohort relation under the existing process. If a compiler/provider/context change invalidates the old equality bridge, obtain the focused fresh joint four-target observation for that change; do not replace it with a source hash alone. Conversely, matching inputs legitimately reuse the reviewed mathematics rather than demanding an arbitrary new TCB or all-body audit.

The mathematical contract remains the finite n=2 clean diagonal `(0,1/64,1/8,27/64)`, normalizer 1, system wires0/1 and signal2, flat little-endian j+4s, exact standard-RY signs/global phase, one signal and no extra pure ancilla, zero opaque oracle calls, definitional four-RY/six-CX resource. Success can be zero; finite-bit synthesis, generic-width arithmetic, hardware lowering and normalized rank-one preparation are not newly certified. Generic Prop fields are not substituted for concrete physics. The corrected source graph/binder/coverage reasoning is unchanged.

## Minimal one-pass adoption/evidence sequence

1. Prepare one frozen prospective overlay containing **both exact candidate source files**, their truthful versioned source/StatementSeal/proof-only provenance, and all intended associated source-row/publication metadata. Keep configurations and unrelated files unchanged unless a separately identified delta is actually intended. Obtain the appropriate adoption authority; this diagnosis is not that action.
2. Bind the pair to the already reviewed joint source/provider/cohort evidence, not the separate C31 run with old inherited CSP. Preserve native binary/provider artifact pins and the disclosed inherited scope. Schedule the ordinary required production integration/build/test gates on the final installed batch, after the exact evidence packet is ready; none were run in this task. No verifier/scoring/scientific target change is needed by the proof substitutions.
3. Freeze the exact intended final ambient file set, selected source rows, lessons and record payloads **once**, using actual prospective bytes rather than guessed hashes. The current publication binding hashes record semantic metadata, module/lesson/toolchain/manifest bytes, every Lean file under QuantumBlockEncoding and ABEISTests, then the selected source row. Lakefile is separately included in the CI input pins, not silently added to that checker formula. Adopting C29, binding everything, then separately adopting C31 would invalidate the same ambient digests twice.
4. Reuse the exact prior per-record import-impact partition only where its input invariants still hold. The earlier 26-record certificate had no import path to either changed module; it was not a new semantic audit of all records and is not asserted to be a newly enumerated current registry. Enumerate the actual final record set and explicit metadata delta at adoption. Current-context carry-forward must retain each original owner's scope, packet/artifact hashes and identity, with honest new binding labels. Do not blanket-rehash evidence or impersonate another owner.
5. Obtain real distinct formalizer/decoder/reviewer evidence for the final exact module records. Whole changed-module inventory/obligations, exact decoder-result SHA, original source-blind/anti-anchored lineage with disclosed late context, and seven quantum slots remain required by the unchanged checker. Old raw-source seals cannot masquerade as new candidate seals. Only after intended final bytes exist can genuine role evidence bind the final digest. The authorized integrator can then install the source pair and associated packet/pointers in one coordinated batch, verify equality to that frozen overlay, and run the unchanged required gates before claiming production integration. Preserve old files; use new versioned pointers, not this diagnosis as an accepted-role JSON.

Typed status: **installation/context mismatch and final exact binding pending; no new source-mathematical obstruction found in the exact proof-only pair**. TCB authorization is not adjudicated here. Stop after this compact handoff; production, registry, verifier, scoring and scientific target are untouched.
