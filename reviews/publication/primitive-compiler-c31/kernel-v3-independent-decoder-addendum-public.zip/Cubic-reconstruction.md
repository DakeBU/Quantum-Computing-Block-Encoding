# Whole Cubic module: formal-only reconstruction joined to actual types

Identity: `/root/primitive_compiler_formal_decoder_c31`. This is the same original formal-only decoder, not the source-first reviewer. The original 87-root source reconstruction remains unchanged. The new observation closes its native/private/generated/type/axiom gap for the exact proof-token candidate, not a natural-source correspondence or admission decision. All 25 Cubic source roots are public, have no universe parameters, and retain exactly their old actual explicit types. The exhaustive actual type text (including all Pi binders), kind/value observations and old/new recursive axiom sets are in `whole-owned-replay.json`, selected by module `QuantumBlockEncoding.CubicAmplitudePrimitive` and role `source-root`.

## Concrete mathematical object and its limits

The two system bits occupy physical wires 0 and 1, with wire 0 least significant. Physical wire 2 is the signal. Thus `encode(s,j)` is `(j mod 2, floor(j/2) mod 2, s)` and its little-endian flat index is `j+4s`. The controls are fixed, mutually distinct, and disjoint from the signal. The generic imported compiler theorem requires each control to differ from the target, not pairwise control injectivity; that weaker generic contract must not be silently strengthened. This concrete instance has no aliasing.

With `j` in `Fin 4`, the amplitude is `a_j=(j/4)^3`, namely `(0, 1/64, 1/8, 27/64)`. This follows from the actual formal providers `gridSize n=2^n`, `gridPoint n j=j/2^n`, and `cubicAmplitude=(gridPoint)^3`; these providers are among the rehashed 31 inputs. The exact angle is `2 arccos(a_j)`. The primitive list is the actual recursive uniformly-controlled Ry compiler at two controls, not an opaque cubic-oracle instruction. Its program's explicit global phase is zero, and both circuit/program matrix equalities are exact, not modulo phase.

Under the actual `standardRyMatrix` convention, the signal block at system index `j` is

`[[a_j, -sqrt(1-a_j^2)], [sqrt(1-a_j^2), a_j]]`.

Consequently in flat order `(signal 0 systems 0..3, signal 1 systems 0..3)`, the full matrix is `[[D,-S],[S,D]]`, with `D=diag(a_j)` and `S=diag(sqrt(1-a_j^2))`. The minus sign is relative phase data; it is not discarded. On `|signal=0,j>`, the result is `a_j|0,j>+sqrt(1-a_j^2)|1,j>`. Only the signal-zero clean block is asserted to equal `D`. The signal is generally NOT returned to zero. There are zero *additional pure ancillas*, not zero signal space or zero failure branch/garbage amplitude.

The compiler's literal recursion yields four Ry instructions and six CNOT instructions here (base Ry count 1/CNOT count 0; each level doubles both and adds two CNOTs). This is a source-level syntactic calculation, not a newly run Lean resource theorem or hardware benchmark. The formal resource claims are the actual circuit/program resource identity and `oracleCalls=0`. They do not establish free rotations, fault-tolerant angle synthesis, optimal gate/depth bounds, or zero physical implementation cost. The presentation replaces exact angles by an `exact-angle` string and is not an angle-bearing numerical exporter.

This Cubic module is specifically two system qubits plus one signal, a 4-by-4 target and 8-by-8 unitary. It does not supply a general arbitrary-width cubic compiler theorem merely because the imported Ry compiler is generic. Descriptive target strings are formal record data, not evidence of agreement with author prose.

## Exhaustive source-declaration contracts

Names below are in namespace `QuantumBlockEncoding.CubicDiagonalOracle`; order is the original source order. Actual native types are linked by each name and `moduleOrdinal` in the full 87-root replay.

| # | Declaration | Reconstructed contract, including parameter scope |
|---|---|---|
| 1 | `cubicN2ControlWires` | A function `Fin 2 -> Fin 3`, mapping logical controls 0,1 to physical 0,1. |
| 2 | `cubicN2ControlWires_ne_signal` | For every logical control, its physical wire differs from signal wire 2. |
| 3 | `cubicN2ControlIndex` | Every two-bit assignment maps to `b0+2*b1` in `Fin 4`. |
| 4 | `cubicN2Amplitude_abs_le_one` | For every two-bit assignment, the real absolute value of its rational cubic amplitude is at most 1. Candidate changes only the finite rational subproof to `decide +kernel +revert`; the outer real cast and statement are unchanged. |
| 5 | `cubicN2Angle` | A function on two-bit assignments producing the exact twice-arccos rational angle, carrying the preceding bound proof. |
| 6 | `cubicN2PrimitiveCircuit` | The fixed three-wire, two-control uniformly-controlled Ry list with controls 0,1 and target 2. |
| 7 | `cubicN2PrimitiveProgram` | That circuit with exact rational global-phase angle 0. |
| 8 | `cubicN2PrimitiveCircuit_eval` | An unconditional equality of the actual three-wire circuit matrix and context-preserving controlled Ry block matrix. |
| 9 | `cubicN2PrimitiveProgram_eval` | The same unconditional matrix equality for the program, with its zero global phase explicitly discharged. |
| 10 | `cubicN2EncodeBits` | For every signal bit and `Fin 4` system index, produces the concrete three-wire basis assignment described above. |
| 11 | `cubicN2EncodeBits_signal` | For every signal/system pair, wire 2 of the encoding equals that signal; simp theorem. |
| 12 | `cubicN2ControlIndex_encode` | For every signal/system pair, taking the non-signal context and control assignment returns the original system index; simp theorem. Only proof token changes to kernel decide. |
| 13 | `cubicN2EncodeBits_context_eq_iff` | For all two signal bits and all two system indices, equality of their non-signal contexts is equivalent to equality of their system indices; signal values need not agree. Only proof token changes to kernel decide. |
| 14 | `cubicN2PrimitiveProgram_cleanEntry` | For every row/column in `Fin 4`, the entry between their signal-zero encoded bases equals the rational cubic diagonal entry cast to complex. |
| 15 | `cubicN2PrimitiveFlatUnitary` | Little-endian reindexing of the actual program matrix to an 8-by-8 complex matrix. |
| 16 | `cubicN2PrimitiveFlatUnitary_unitary` | This specific flat matrix belongs to the complex matrix unitary group; no extra source hypotheses. |
| 17 | `cubicN2PrimitiveCleanIndex` | Every `Fin 4` index maps to the flat image of its concrete signal-zero encoding (derived flat value `j`). |
| 18 | `cubicN2PrimitiveFlatUnitary_cleanBlock` | For every `Fin 4` row/column, restriction along that concrete clean index equals the cast cubic diagonal entry. |
| 19 | `cubicN2ComplexTarget` | A 4-by-4 complex query-operator target whose operator is the cast cubic diagonal and normalizer is 1; its strings are descriptive data. |
| 20 | `cubicN2PrimitivePresentation` | Maps the actual primitive list into display gates, preserving wire indices but replacing rotation-angle data with string labels. |
| 21 | `cubicN2PrimitiveResource` | The actual primitive program's resource record. |
| 22 | `cubicN2PrimitiveOperatorCandidate` | A concrete candidate: system 2, auxiliary signal 1, pure ancillas 0, the actual flat unitary, display circuit and resource. Its unitarity and block obligations are the actual propositions, not proofs supplied by a string. |
| 23 | `cubicN2PrimitiveVerifiedBlockEncoding` | Supplies the concrete candidate's unitarity proof and all-row/column clean-block proof; no new arbitrary-width or external-oracle assumption. |
| 24 | `cubicN2Primitive_oracleCalls_eq_zero` | The resource's modeled oracle call count is exactly zero. |
| 25 | `cubicN2Primitive_resource_faithful` | The resource record is definitionally the resource of the actual primitive circuit, not an external runtime measurement. |

## Actual proof-token effect

All three old `._native.native_decide.ax_1_1` declarations are absent from the new actual owned inventory. Three new `._proof_1_1` declarations at those sites are observed as ordinary `thmInfo`, with values available through `allowOpaque=true`, not self axioms. Ordinary proof text was intentionally not requested: no proof body was printed or independently reconstructed from native machine code.

The 21 surviving target-owned declarations whose recursive axiom sets changed consist of 18 source roots and 3 generated declarations. Those consumers survive; their native dependencies do not. Every surviving row's new axiom set is exactly its old set minus the three removed native axioms. New ordinary auxiliary declarations have only the observed union `Classical.choice`, `Quot.sound`, `propext`; the full new 200-owned union is those same three. No unsafe/self/native axiom is observed in this finite target-owned closure. This is not an automatic whitelist, axioms policy pass, all-provider trust closure, source agreement, or admission.
