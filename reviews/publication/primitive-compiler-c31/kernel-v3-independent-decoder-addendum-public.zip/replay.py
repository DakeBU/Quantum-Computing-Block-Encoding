"""Independent data replay: no imports/calls of prior validator/compare/runtime."""
import argparse
from collections import Counter
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import zipfile

ZIP_SHA='3e69139f0a9e1d275bc2eb0b89a0bb36206501f2def3510ba4876ac20a6a7267'
NO_ACCEPT=dict(sourceAgreement=None,axiomPolicyPass=None,publicationBinding=None,
    scientificAcceptance=False,nativeAccepted=False,trustClosure=False)
ROW_TAGS=('C31_ROOT_JSON','C31_GENERATED_JSON')
TAGS=(*ROW_TAGS,'C31_BINDING_JSON','C31_SUMMARY_JSON')
KINDS={'def':'defnInfo','theorem':'thmInfo','structure':'inductInfo','opaque':'opaqueInfo','axiom':'axiomInfo'}
SHARED_PATH='tools/cubic_c29_diagnostic/runner.py'
SHARED_SHA='61733fc92f5e99672e0ce0260ff397e07c94a349e98e12c48dd6a3171d5a75d9'
TARGET='QuantumBlockEncoding/CubicAmplitudePrimitive.lean'
OLD_TARGET='48c9a4a1c47c925c93493eede21eb7b492d23d2cb7dadf254782e4485c349cb3'
NEW_TARGET='952e2b359796ef695a1b1c1a376d40a80affbc679f503f94227ea0c775a6cd48'
ORIGINAL_PROFILE='72c0931c4c62906835d831742a3b797b381e947fbb8e3ecb58c4ad62aaa64473'
NEW_PROFILE='e3e46b04819500acc83eaadfd34ad5185ea79b3d778f26e7b5624d84377850e7'
SOURCE_SEAL='0fd3e599c0532c6e308dbb87b26b420f939886d9d39de89c419692946f40cd68'
SOURCE_ROOTS='750d11a48ddd17431ce0bf327fcaa329a373af5791db1aad3ee261c12945dca0'
FRESH='$CANDIDATE_WORKSPACE/_out/primitive-compiler-native-profile-v1/cohort'
DRIVER='$CANDIDATE_WORKSPACE/_out/primitive-compiler-native-profile-v1/driver'
PROCESS_LABELS=('01-help','02-prefix','11-target','12-target','13-target','21-driver','22-driver','30-observe')
SIGNATURE_FIELDS=('module','actualName','actualKind','kernelKind','actualPrivate','userNameViaActualAPI',
    'universeParameters','typePrettyExplicit','kernelRootPresent','kernelTypeAndUniversesAgree',
    'isUnsafe','actualHasValueAllowOpaque','actualOpaqueInfo','actualAxiomInfo','sourceOpaque',
    'valueTextRequested','valuePrettyExplicitAllowOpaque','valueObservation','typeTextScope','axiomCollection')


def require(condition,message):
    if not condition: raise ValueError(message)


def digest(data): return hashlib.sha256(data).hexdigest()
def sha(path): return digest(path.read_bytes())
def unique_object(pairs):
    obj={}
    for key,value in pairs:
        require(key not in obj,'duplicate JSON key: '+key); obj[key]=value
    return obj
def parse(data): return json.loads(data,object_pairs_hook=unique_object)
def read(path): return parse(path.read_bytes())
def canonical(value): return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def is_digest(value): return type(value) is str and re.fullmatch('[0-9a-f]{64}',value) is not None
def no_accept(row):
    require(all(k in row and row[k] is value for k,value in NO_ACCEPT.items()),'acceptance field mismatch')


def artifact(files):
    """Check every available byte, and separate unavailable raw-byte claims."""
    require(files and all('/' not in n and '\\' not in n and n not in ('.','..') for n in files),'artifact flat partition')
    manifest=parse(files['raw-derivation-receipts.json'])
    rows=manifest['files']; names=[r['publicRelativePath'] for r in rows]
    require(len(names)==len(set(names)) and set(names)==set(files)-{'raw-derivation-receipts.json'},'receipt partition')
    receipts={r['publicRelativePath']:r for r in rows}; same=[]; changed=[]
    for name,row in receipts.items():
        require(is_digest(row['rawSHA256']) and is_digest(row['publicSHA256']),'invalid receipt digest')
        require(type(row['rawBytes']) is int and row['rawBytes']>=0,'invalid raw bytes')
        require(digest(files[name])==row['publicSHA256'],'public member byte digest mismatch: '+name)
        if row['rawSHA256']==row['publicSHA256']:
            require(row['rawBytes']==len(files[name]),'unchanged raw/public length mismatch'); same.append(name)
        else: changed.append(name)
    return receipts,dict(members=len(files),receiptMembers=len(rows),
        allMemberSHA256={n:digest(b) for n,b in sorted(files.items())},
        rawAndPublicIdenticalByteVerified=sorted(same),redactedRawDigestOnlyNotRecomputed=sorted(changed),
        boundary='Public bytes rehashed independently; changed raw bytes absent, so their raw digests are chain-consistency observations only')


def load_zip(path):
    require(sha(path)==ZIP_SHA,'authorized ZIP pin')
    with zipfile.ZipFile(path) as archive:
        names=archive.namelist(); require(len(names)==len(set(names)),'duplicate ZIP member')
        require(all(not n.endswith('/') for n in names),'unexpected ZIP directory')
        files={n:archive.read(n) for n in names}
    require(sha(path)==ZIP_SHA,'ZIP drift'); return files


def parse_stream(data):
    records=[]
    for line in data.decode('utf-8').splitlines():
        require(bool(line.strip()),'blank stream line')
        tag,sep,text=line.partition(' '); require(sep and tag in TAGS,'unknown/truncated stream line')
        row=parse(text); require(type(row) is dict,'non-object stream row'); no_accept(row)
        records.append((tag,row))
    require(records and records[-1][0]=='C31_SUMMARY_JSON','summary must terminate stream')
    require(sum(t=='C31_SUMMARY_JSON' for t,r in records)==1,'summary multiplicity')
    return records


def validate_stream(records,profile,profile_sha):
    modules=[m['module'] for m in profile['modules']]
    require(len(modules)==3 and len(set(modules))==3,'module vector')
    specs=profile['roots']; require(len(specs)==87,'source vector is not 87')
    keys=[(s['module'],s['sourceUserName']) for s in specs]
    require(len(set(keys))==87 and sum(s['sourcePrivate'] for s in specs)==8,'source vector collision/private count')
    bindings={}; rows={}; roots={}; generated={}; cohorts=set()
    for tag,row in records:
        if tag=='C31_BINDING_JSON':
            module=row['module']; require(module in modules and module not in bindings,'module binding collision/unknown')
            require(row['profileSHA256']==profile_sha,'binding profile pin')
            require(row['ownershipMethod']=='ENVIRONMENT_MODULE_INDEX_NOT_NAME_PREFIX','ownership method')
            require(row['freshOleanPathComparisonPassed'] is True,'fresh lookup comparison')
            require(row['resolvedOleanPath'].endswith('/'+module.replace('.','/')+'.olean'),'fresh module suffix')
            require(row['ppDeepTerms'] is True and row['ppMaxSteps']==2000000 and row['maxRecDepth']==10000,'pp bounds')
            owned=row['ownedNames']; require(owned and len(owned)==len(set(owned))==row['ownedCount'],'owned-list collision/count')
            bindings[module]=row; cohorts.add(row['cohortID'])
        elif tag in ROW_TAGS:
            n=row['actualName']; require(type(n) is str and n and n not in rows,'actual name collision')
            require(row['module'] in modules,'row module')
            require(row['kernelRootPresent'] is True and row['kernelTypeAndUniversesAgree'] is True,'kernel disagreement')
            require(row['kernelKind']==row['actualKind'],'kernel kind mismatch')
            require(row['actualKind'] in {'defnInfo','thmInfo','inductInfo','recInfo','ctorInfo','axiomInfo','opaqueInfo','quotInfo'},'unknown actual kind')
            require(type(row['typePrettyExplicit']) is str and bool(row['typePrettyExplicit']) and
                not any(c in row['typePrettyExplicit'] for c in ('⋯','…')),'truncated type')
            require(type(row['universeParameters']) is list and len(set(row['universeParameters']))==len(row['universeParameters']),'universe vector')
            for k in ('actualPrivate','isUnsafe','actualHasValueAllowOpaque','actualOpaqueInfo','actualAxiomInfo','sourceOpaque','selfOccursInAxioms'):
                require(type(row[k]) is bool,'non-boolean observation')
            require(row['actualOpaqueInfo']==(row['actualKind']=='opaqueInfo') and row['actualAxiomInfo']==(row['actualKind']=='axiomInfo'),'actual kind flags')
            require(row['valueTextRequested'] is False and row['valuePrettyExplicitAllowOpaque'] is None,'unexpected value-text scope')
            require(row['valueObservation']==('NOT_REQUESTED_VALUE_AVAILABLE' if row['actualHasValueAllowOpaque'] else 'NOT_REQUESTED_NO_VALUE_AVAILABLE'),'value availability observation')
            if row['actualAxiomInfo']: require(row['actualHasValueAllowOpaque'] is False,'axiom body availability')
            axes=row['axioms']; require(type(axes) is list and len(set(axes))==len(axes) and all(type(a) is str and a for a in axes),'axiom vector')
            require(row['selfOccursInAxioms']==(n in axes),'self-axiom inconsistency')
            require(row['axiomCollection']=='ACTUAL_LEAN_COLLECT_AXIOMS_IMPORTED_EXTENSION_AND_LOCAL_BODIES','axiom collection scope')
            require(row['typeTextScope']=='ACTUAL_META_PPEXPR_NOT_LOSSLESS_EXPR_SERIALIZATION','type scope')
            if tag=='C31_ROOT_JSON': roots[n]=row
            else:
                require(row['includedInExplicitRootCount'] is False,'generated counted explicit'); generated[n]=row
            rows[n]=row
    require(list(bindings)==modules and len(cohorts)==1,'ordered modules/cohort')
    resolved=[]
    for module in modules:
        expected=[s for s in specs if s['module']==module]
        actual=[r for r in roots.values() if r['module']==module]
        require(len(actual)==len(expected)==bindings[module]['expectedRoots'],'module root count')
        for ordinal,spec in enumerate(expected,1):
            matches=[r for r in actual if r['sourceUserName']==spec['sourceUserName']]
            require(len(matches)==1,'source root resolution multiplicity')
            r=matches[0]; resolved.append(r['actualName'])
            require(r['moduleOrdinal']==ordinal and r['sourceKind']==spec['sourceKind'],'source order/kind')
            require(r['sourcePrivate'] is spec['sourcePrivate'] and r['actualPrivate'] is spec['sourcePrivate'],'private binding')
            require(r['userNameViaActualAPI']==spec['sourceUserName'],'actual private/user API binding')
            if not spec['sourcePrivate']: require(r['actualName']==spec['sourceUserName'],'public name binding')
            require(r['actualKind']==KINDS[spec['sourceKind']],'source/actual kind')
        actual_names={n for n,r in rows.items() if r['module']==module}
        owned=set(bindings[module]['ownedNames'])
        require(actual_names==owned,'whole owned partition missing/extra')
        require(set(generated)&owned==owned-{r['actualName'] for r in actual},'generated is not exact owned-minus-source')
        structures=bindings[module]['structures']; structure_names=[s['actualName'] for s in structures]
        require(len(set(structure_names))==len(structure_names),'structure collision')
        require(set(structure_names)=={r['actualName'] for r in actual if r['sourceKind']=='structure'},'source structure inventory')
        for s in structures:
            require(len(s['fieldNames'])==len(set(s['fieldNames'])),'structure field collision')
            structure_spec=next(r for r in expected if r['sourceUserName']==s['actualName'])
            require(s['fieldNames']==structure_spec['structureFields'],'complete source/actual structure field vector')
            require(len(s['fields'])==len(s['fieldNames']) and {f['fieldName'] for f in s['fields']}==set(s['fieldNames']),'structure fields incomplete')
            require(all(c in owned and rows[c]['actualKind']=='ctorInfo' for c in s['constructors']),'structure constructor ownership')
            for f in s['fields']:
                require(f['projection'] in owned and rows[f['projection']]['actualKind']==f['actualKind'],'structure projection ownership/kind')
    require(len(resolved)==len(set(resolved))==87,'root resolution/global collision')
    require(sum(r['actualPrivate'] for r in roots.values())==8,'actual private-root count')
    summary=records[-1][1]
    expected=dict(modulesCompleted=3,rootsCompleted=len(roots),privateCompleted=8,
        generatedCompleted=len(generated),ownedCompleted=len(rows),profileSHA256=profile_sha,cohortID=next(iter(cohorts)))
    require(all(summary.get(k)==v for k,v in expected.items()),'summary vs independent counts')
    return dict(rows=rows,roots=roots,generated=generated,bindings=bindings,cohortID=next(iter(cohorts)))


def compare_owned(old,new):
    a,b=old['rows'],new['rows']; survivors=sorted(a.keys()&b.keys())
    removed=sorted(a.keys()-b.keys()); added=sorted(b.keys()-a.keys())
    legacy={n for n,r in a.items() if r['actualAxiomInfo'] and r['selfOccursInAxioms']}
    require(len(a)==200 and len(legacy)==3 and all('._native.native_decide.ax_' in n for n in legacy),'old actual200/native3 baseline')
    vector=[]; unexpected=[]; ax_changed=[]; surviving_consumers=[]
    require(set(old['roots'])==set(new['roots']),'source root identity change')
    for n in survivors:
        x,y=a[n],b[n]; source=n in old['roots']
        fields=list(SIGNATURE_FIELDS)+(['sourceUserName','sourceKind','sourcePrivate','moduleOrdinal'] if source else ['includedInExplicitRootCount'])
        changed=[k for k in fields if x[k]!=y[k]]
        expected_axes=set(x['axioms'])-legacy; actual_axes=set(y['axioms'])
        dependency_ok=expected_axes==actual_axes
        consumers=sorted(set(x['axioms'])&legacy)
        if consumers: surviving_consumers.append(n)
        if set(x['axioms'])!=actual_axes: ax_changed.append(n)
        if changed or not dependency_ok: unexpected.append(n)
        vector.append(dict(actualName=n,module=x['module'],role='source-root' if source else 'generated',
            unchangedSignatureAndObservations=not changed,changedObservationFields=changed,
            oldSignatureSHA256=digest(canonical({k:x[k] for k in fields})),
            newSignatureSHA256=digest(canonical({k:y[k] for k in fields})),
            signatureAndObservations={k:y[k] for k in fields},
            oldAxioms=sorted(x['axioms']),newAxioms=sorted(actual_axes),
            removedNativeDependencies=consumers,exactOldMinusNativeAxioms=dependency_ok))
    union_old=set().union(*(set(r['axioms']) for r in a.values()))
    union_new=set().union(*(set(r['axioms']) for r in b.values()))
    residual_native=[n for n,r in b.items() if r['actualAxiomInfo'] or r['selfOccursInAxioms'] or
        any('native_decide' in ax or ax in legacy for ax in r['axioms'])]
    new_observations=[dict(actualName=n,observation=b[n],axiomsWithinOldUnionMinusNative=set(b[n]['axioms'])<=union_old-legacy) for n in added]
    for r in new_observations:
        if not r['axiomsWithinOldUnionMinusNative'] or r['observation']['isUnsafe']: unexpected.append(r['actualName'])
    removed_exact=set(removed)==legacy
    structures_equal=all(old['bindings'][m]['structures']==new['bindings'][m]['structures'] for m in old['bindings'])
    stats=dict(oldOwned=len(a),newOwned=len(b),sourceRoots=len(new['roots']),
        oldGenerated=len(old['generated']),newGenerated=len(new['generated']),surviving=len(survivors),
        sourceRootSignaturesUnchanged=sum(r['role']=='source-root' and r['unchangedSignatureAndObservations'] for r in vector),
        survivingGeneratedSignaturesUnchanged=sum(r['role']=='generated' and r['unchangedSignatureAndObservations'] for r in vector),
        axiomClosuresChanged=len(ax_changed),rootAxiomClosuresChanged=sum(n in new['roots'] for n in ax_changed),
        generatedAxiomClosuresChanged=sum(n in new['generated'] for n in ax_changed),
        oldAxiomUnion=sorted(union_old),newAxiomUnion=sorted(union_new),
        newUnsafeObserved=sum(r['isUnsafe'] for r in b.values()),newSelfAxiomsObserved=sum(r['selfOccursInAxioms'] for r in b.values()))
    return dict(stats=stats,legacyNativeAxioms=sorted(legacy),removedExactlyLegacyNativeAxioms=removed_exact,
        removed=[dict(actualName=n,observation=a[n]) for n in removed],added=new_observations,
        survivingRows=vector,oldNativeConsumersStillPresent=surviving_consumers,
        changedAxiomClosureNames=ax_changed,unexpectedDifferenceNames=sorted(set(unexpected)),
        nativeOrSelfAxiomResidualNames=residual_native,
        structuresUnchanged=structures_equal,
        finiteReplayConsistent=(not unexpected and removed_exact and not residual_native and not stats['newUnsafeObserved'] and structures_equal),
        consumerBoundary='Consumers remain as declarations; their recursive native dependencies disappear. All consumers here are target-owned, not an inventory of downstream imported/external consumers',
        typeBoundary='Exact complete pp text/universe equality, including implicit Pi binders; not independently serialized Expr equality across processes or proof-value equality',**NO_ACCEPT)


def mask_comments(raw):
    """Byte-preserving comment masking, nested blocks; quoted strings are data."""
    out=bytearray(raw); i=0; depth=0; line=False; string=False; escape=False
    while i<len(raw):
        pair=raw[i:i+2]
        if line:
            if raw[i] in (10,13): line=False
            else: out[i]=32
            i+=1; continue
        if depth:
            if pair==b'/-': out[i:i+2]=b'  '; depth+=1; i+=2
            elif pair==b'-/': out[i:i+2]=b'  '; depth-=1; i+=2
            else:
                if raw[i] not in (10,13): out[i]=32
                i+=1
            continue
        if string:
            if escape: escape=False
            elif raw[i]==92: escape=True
            elif raw[i]==34: string=False
            i+=1; continue
        if pair==b'--': out[i:i+2]=b'  '; line=True; i+=2
        elif pair==b'/-': out[i:i+2]=b'  '; depth=1; i+=2
        else:
            if raw[i]==34: string=True
            i+=1
    require(not depth and not string,'unterminated masked source'); return bytes(out)


def verify_file_vector(root,files):
    require(files,'empty file pins')
    for name,wanted in files.items():
        path=Path(name); require(not path.is_absolute() and '..' not in path.parts,'file pin path')
        require(sha(root/path)==wanted,'actual file pin drift: '+name)


def source_bindings(project,packet,kernel,guard,files):
    original_bytes=(kernel/'original-profile.json').read_bytes(); candidate_profile_bytes=(kernel/'profile.json').read_bytes()
    require(digest(original_bytes)==ORIGINAL_PROFILE and digest(candidate_profile_bytes)==NEW_PROFILE,'raw profile pins')
    original,derived=parse(original_bytes),parse(candidate_profile_bytes)
    require(original_bytes.count(OLD_TARGET.encode())==2 and original_bytes.replace(OLD_TARGET.encode(),NEW_TARGET.encode())==candidate_profile_bytes,'raw profile is not exact two SHA substitutions')
    require(sha(packet/'source-formal-seal.json')==SOURCE_SEAL and sha(packet/'declaration-contracts.json')==SOURCE_ROOTS,'original decoder seal/root inventory')
    catalog=read(packet/'declaration-contracts.json')['declarations']
    source_specs=[dict(module=r['module'],sourceUserName=r.get('sourceScopedName',r['name']),sourcePrivate=r['private'],sourceKind=r['kind']) for r in catalog]
    for root,spec in zip(catalog,source_specs):
        if root['kind']=='structure':
            spec['structureFields']=re.findall(r'^  ([A-Za-z_][A-Za-z0-9_]*)\s*:',root['completeFormalRegion'],re.MULTILINE)
    require(source_specs==original['roots']==derived['roots'],'raw87/source reconstruction vector mismatch')
    old=(project/TARGET).read_bytes(); candidate=(kernel/'candidate'/TARGET).read_bytes()
    require(digest(old)==OLD_TARGET and digest(candidate)==NEW_TARGET,'actual old/candidate source bytes')
    masked=mask_comments(old); matches=list(re.finditer(rb'\bnative_decide\b',masked))
    require(len(matches)==3,'proof-token source sites')
    rebuilt=old
    for match in reversed(matches): rebuilt=rebuilt[:match.start()]+b'decide +kernel'+rebuilt[match.end():]
    require(candidate==rebuilt,'candidate has changes beyond three exact proof tokens')
    sites=[]
    for match in matches:
        line=old[:match.start()].count(b'\n')+1
        owners=[r for r in catalog if r['module']=='QuantumBlockEncoding.CubicAmplitudePrimitive' and r['line']<=line<=r['endLine']]
        require(len(owners)==1 and owners[0]['kind']=='theorem','proof-token source owner')
        sites.append(dict(originalByteStart=match.start(),originalByteEnd=match.end(),line=line,
            sourceRoot=owners[0]['name'],oldToken='native_decide',newToken='decide +kernel',allOtherSourceBytesPreserved=True))
    require({s['sourceRoot'].split('.')[-1] for s in sites}=={'cubicN2Amplitude_abs_le_one','cubicN2ControlIndex_encode','cubicN2EncodeBits_context_eq_iff'},'proof site names')
    verify_file_vector(project,original['projectInputs'])
    require(len(original['projectInputs'])==31 and len(original['providers'])==25,'original input/provider vectors')
    observed=parse(files['input-bindings.json']); copied=parse(files['candidate-input-bindings.json'])
    no_accept(observed); no_accept(copied)
    expected_inputs=derived['projectInputs']
    rows=observed['projectInputs']; require(len(rows)==31 and len({r['relativePath'] for r in rows})==31,'actual project input vector')
    require({r['relativePath']:r['sha256'] for r in rows}==expected_inputs,'actual candidate input pins')
    inputcopies=copied['inputCopies']; require(len(inputcopies)==31 and len({r['relativePath'] for r in inputcopies})==31,'copy input vector')
    for row in inputcopies:
        wanted=expected_inputs[row['relativePath']]
        require(row['sha256']==row['sourceSHA256Before']==row['sourceSHA256After']==wanted,'actual input source before/after')
    require(observed['profileSHA256']==NEW_PROFILE and observed['sourceSealSHA256']==SOURCE_SEAL,'actual profile/source seal binding')
    require(copied['originalRaw87ProfileSHA256']==ORIGINAL_PROFILE and copied['candidateRaw87ProfileSHA256']==NEW_PROFILE,'actual profile provenance')
    require(observed['sharedInstrumentation']==dict(path=SHARED_PATH,sha256=SHARED_SHA),'actual shared pin')
    require(sha(project/SHARED_PATH)==SHARED_SHA,'actual helper source bytes')
    km=read(kernel/'bindings.json'); verify_file_vector(kernel,km['files'])
    gp=read(guard/'profile.json'); gm=read(guard/'bindings.json'); verify_file_vector(guard,gm['files'])
    require(sha(kernel/'bindings.json')=='6a3bfa246013397e867d4c3427748abcb1faa17aa5b90ecd9889969640886057','immutable kernel package manifest')
    require(sha(guard/'bindings.json')=='3787083e273c5728c3dd84799999a9487e1f62dfef54e1bc1bee83bc8f98f460','immutable v3 guard manifest')
    verify_file_vector(kernel,gp['baseFiles'])
    config=read(kernel/'kernel-profile.json')
    for path,vector in config['runtimePackages'].items(): verify_file_vector(project/path,vector)
    require((config['wholeSeconds'],config['budgetMiB'],config['reserveMiB'],config['threads'])==(2100,5120,2048,1),'finite resource code profile')
    entry=parse(files['executing-code-bindings.json']); no_accept(entry)
    require(entry['guardProfileSHA256']==sha(guard/'profile.json') and entry['guardManifestSHA256']==sha(guard/'bindings.json'),'actual guard package pins')
    require(entry['immutableKernelV1ManifestSHA256']==sha(kernel/'bindings.json') and entry['immutableKernelV1SealSHA256']==sha(kernel/'seal.json'),'actual base manifest/seal')
    e=entry['entry']; expected_entry='$PROJECT/tools/c31_kernel_proof_v3/entry.py'
    require(e['actualFile']==e['actualArgv0Resolved']==e['actualMainModuleFile']==expected_entry,'actual entry/main/argv0')
    require(e['sourceSHA256']==sha(guard/'entry.py') and e['expectedLogicalFile']=='$KERNEL_V3_PACKAGE/entry.py','actual entry source pin')
    modules=entry['modules']; require(len(modules)==3,'actual loaded three modules')
    for name in ('runtime.py','compare.py','proof_patch.py'):
        matches=[r for r in modules if r['expectedLogicalFile']=='$KERNEL_V1_PACKAGE/'+name]
        require(len(matches)==1 and matches[0]['actualFile']=='$KERNEL_PACKAGE/'+name and matches[0]['sourceSHA256']==sha(kernel/name),'actual module path/source SHA')
    require(entry['sourceFileObservationOnly'] is True and entry['OSAttestation'] is False and entry['codeObjectAttestation'] is False,'entry attestation boundary')
    helper=parse(files['shared-helper-copy.json']); no_accept(helper)
    for key in ('sha256','sourceSHA256Before','sourceSHA256After','destinationSHA256','executingAPISourceSHA256'):
        require(helper[key]==SHARED_SHA,'actual helper dual-endpoint pin')
    require(helper['relativePath']==SHARED_PATH and helper['source']=='$PROJECT/'+SHARED_PATH and
        helper['destination']=='$CANDIDATE_WORKSPACE/'+SHARED_PATH and helper['executingAPIOrigin']=='$PROJECT/'+SHARED_PATH,
        'actual helper endpoints/executing origin')
    require(helper['copiedHelperExecuted'] is False and helper['bytes']==(project/SHARED_PATH).stat().st_size,'helper data-only observation')
    seeds=copied['providerSeedCopies']; special=[r for r in seeds if r.get('kind')=='SHARED_HELPER_PIN_COPY_NOT_PROVIDER_ARTIFACT']
    require(len(seeds)==26 and special==[helper],'typed shared helper is not provider artifact')
    return original,derived,dict(originalProfileSHA256=ORIGINAL_PROFILE,candidateProfileSHA256=NEW_PROFILE,
        originalSourceSealSHA256=SOURCE_SEAL,originalDeclarationContractsSHA256=SOURCE_ROOTS,
        originalTargetSHA256=digest(old),candidateTargetSHA256=digest(candidate),exactThreeProofTokenSites=sites,
        originalProjectInputsRehashed=original['projectInputs'],candidateInputCopies=inputcopies,
        executingCodeBindings=entry,sharedHelperCopy=helper,
        immutableRuntimePackagesRehashed={p:len(v) for p,v in config['runtimePackages'].items()},
        sourceChangedBeyondProofTokens=False,sourceStatementBinderDefinitionBytesUnchanged=True,
        rawProfileOnlyTwoTargetSHAReplacements=True,sourceCatalogRootVectorEqual=True,**NO_ACCEPT)


def resource_snapshot(snapshot,require_pass):
    no_accept(snapshot)
    require(snapshot['schema']=='C31_CI4_RESOURCE_SELF_NAMESPACE_V1' and snapshot['observationComplete'] is True,'resource observation incomplete')
    context=snapshot['context']; require(context['platform']=='linux' and context['CI']==context['GITHUB_ACTIONS']=='true' and context['RUNNER_OS']=='Linux','resource CI context')
    required=7168*1024*1024
    require((snapshot['budgetMiB'],snapshot['reserveMiB'],snapshot['requiredHeadroomBytes'])==(5120,2048,required),'resource threshold changed')
    require(snapshot['cgroupVersion']==2 and snapshot['cgroupMountRoot']=='/','unknown/hidden cgroup mount')
    ns=snapshot['namespaceObservation']
    require(ns['selfInode']==ns['requiredInitInode']==4026531835 and ns['policy']=='SELF_ONLY_RESERVED_INIT_V1','unknown namespace fingerprint')
    require(ns['pid1Observation']==dict(status='NOT_REQUESTED_NOT_REQUIRED',readRequested=False,value=None),'PID1 scope')
    root=snapshot['rootObservation']
    require(root['type']=='DOCUMENTED_TRUE_ROOT_NOT_APPLICABLE_NOT_UNLIMITED' and root['atVerifiedMountRoot'] is True and
        root['mountFSType']=='cgroup2' and root['mountRoot']=='/' and root['namespaceObservation']==ns,'typed true-root boundary')
    require(root['coreControllerMemoryObserved'] is True and type(root['coreProcessCount']) is int and root['coreProcessCount']>0,'root core observations')
    for name in ('memory.max','memory.current','memory.events'):
        require(root['memoryInterfaces'][name]==dict(applicability='DOCUMENTED_TRUE_ROOT_NOT_APPLICABLE_NOT_UNLIMITED',value=None,readRequested=False,unlimitedObserved=False),'root NA is not unlimited')
    groups=snapshot['cgroups']; require(groups and len({g['logicalPath'] for g in groups})==len(groups),'nonroot ancestor partition')
    require([g['logicalPath'] for g in groups]==['$CGROUP_NONROOT_'+str(i) for i in range(len(groups))],'ancestor logical index order')
    candidates=[snapshot['memAvailableBytes']]
    require(type(candidates[0]) is int and candidates[0]>0,'MemAvailable missing/invalid')
    for g in groups:
        require(g['atVerifiedMountRoot'] is False and type(g['memoryCurrentBytes']) is int and g['memoryCurrentBytes']>=0,'nonroot current')
        if g['memoryMaxRaw']=='max':
            require(g['memoryMaxBytes'] is None and g['headroomBytes'] is None and g['limitUnlimited'] is True,'nonroot max consistency')
        else:
            maximum=int(g['memoryMaxRaw']); head=max(0,maximum-g['memoryCurrentBytes'])
            require(maximum>=0 and g['memoryMaxBytes']==maximum and g['headroomBytes']==head and g['limitUnlimited'] is False,'nonroot finite limit')
            candidates.append(head)
        events=g['memoryEvents']; require({'low','high','max','oom','oom_kill'}<=events.keys() and all(type(v) is int and v>=0 for v in events.values()),'memory event completeness')
    effective=min(candidates)
    require(snapshot['effectiveHeadroomBytes']==effective and snapshot['gatePassed'] is (effective>=required),'effective headroom arithmetic')
    if require_pass: require(effective>=required,'pre-child headroom below 5120+2048')
    required_reads={'$PROC/meminfo','$PROC/self/cgroup','$PROC/self/mountinfo','$PROC/self/ns/cgroup','$CGROUP_REAL_ROOT/cgroup.controllers','$CGROUP_REAL_ROOT/cgroup.procs'}
    required_reads|={g['logicalPath']+'/'+name for g in groups for name in ('memory.max','memory.current','memory.events')}
    reads=snapshot['fileReads']+snapshot['namespaceReads']; attempts=snapshot['readAttempts']
    require(len(reads)==len(required_reads)==len(attempts) and {r['logicalPath'] for r in reads}==required_reads and
        {r['logicalPath'] for r in attempts}==required_reads,'required resource read partition')
    require(snapshot['failedReadLogicalPath'] is None and snapshot['failedReadAtVerifiedMountRoot'] is None,'resource failed read')
    for r in reads:
        matches=[a for a in attempts if a['logicalPath']==r['logicalPath']]
        require(len(matches)==1 and matches[0]['status']=='READ_OK' and is_digest(r['sha256']) and type(r['bytes']) is int and r['bytes']>=0,'resource read attempt')
        require(all(matches[0][k]==r[k] for k in ('sha256','bytes','atVerifiedMountRoot')),'resource read attempt binding')
    link=[r for r in reads if r['logicalPath']=='$PROC/self/ns/cgroup'][0]
    require(link['sha256']==digest(b'cgroup:[4026531835]') and link['bytes']==19,'namespace readlink digest')
    return dict(effectiveHeadroomBytes=effective,requiredHeadroomBytes=required,memAvailableBytes=snapshot['memAvailableBytes'],
        finiteLimitsObserved=sum(g['memoryMaxRaw']!='max' for g in groups),nonrootAncestors=len(groups),
        context=context,namespaceRecognition=ns['recognition'],resourceFileBytesNotBundled=True)


def runtime_chain(files,receipts,profile,observations,project,kernel):
    J=lambda name:parse(files[name])
    env=J('runtime-environment.json'); inventory=J('provider-inventory.json'); fresh=J('fresh-target-cohort.json')
    no_accept(env); no_accept(inventory); no_accept(fresh)
    modules=[m['module'] for m in profile['modules']]
    require(fresh['compileOrder']==modules and [r['module'] for r in fresh['targets']]==modules,'fresh topological target vector')
    require(fresh['cohortID']==env['cohortID']==observations['cohortID'],'cohort identity chain')
    require(env['C31_FRESH_ROOT']==FRESH and env['profileSHA256']==NEW_PROFILE,'fresh environment/profile')
    require(env['nativeMemoryMiB']==5120 and env['nativeThreads']==1 and env['baseReportedMemoryMiB']==3072,'actual finite native options')
    search=env['LEAN_PATH'].split(':')
    require(search==[FRESH,DRIVER]+inventory['actualExternalSearchRoots'],'fresh search ordering')
    require(inventory['removedProjectFallbackRoots']==['$CANDIDATE_WORKSPACE','$CANDIDATE_WORKSPACE/.lake/build/lib/lean'],'removed shadow fallback roots')
    require(all(r.startswith('$PROJECT/.lake/packages/') or r=='$ABSOLUTE_PATH_REDACTED' for r in search[2:]),'original project fallback present')
    require(inventory['mode']=='ACTUAL_OS_ARTIFACT_INVENTORY_NOT_LOAD_TRACE' and is_digest(inventory['leanBinarySHA256']),'provider inventory mode/binary digest')
    for item in inventory['artifacts']:
        require(is_digest(item['sha256']) and type(item['bytes']) is int and item['bytes']>=0,'provider OS inventory row')
    helper=J('shared-helper-copy.json'); wrapper=helper['wrapperPID']
    require(type(wrapper) is int and wrapper>0,'wrapper PID')
    processes=[]; snapshots=[]; previous_finish=None; pids=set(); contexts=[]
    for label in PROCESS_LABELS:
        result,setup,started=J(label+'.result.json'),J(label+'.setup.json'),J(label+'.started.json')
        obs=J('ci2-'+label+'.observation.json'); pre=J('ci2-'+label+'.preflight.json'); post=J('ci2-'+label+'.postflight.json')
        no_accept(obs)
        require(type(result['PID']) is int and result['PID']>0 and result['PID'] not in pids,'native PID collision'); pids.add(result['PID'])
        require(result['exitCode']==0 and result['timedOut'] is False,'actual nonzero/timeout')
        require(started['PID']==result['PID'] and result['startedUTC']==setup['startedUTC'],'actual PID/setup-start receipt')
        begin,end=datetime.fromisoformat(result['startedUTC']),datetime.fromisoformat(result['finishedUTC'])
        require(begin.tzinfo is not None and end>=begin and result['wallSeconds']>=0,'native UTC/wall range')
        require(begin<=datetime.fromisoformat(started['startedUTC'])<=end,'actual post-Popen PID receipt UTC bracket')
        if previous_finish is not None: require(begin>=previous_finish,'overlapping native children')
        previous_finish=end
        require(setup['wrapperPID']==obs['wrapperPID']==pre['wrapperPID']==post['wrapperPID']==wrapper,'wrapper PID binding')
        require(post['childPID']==result['PID'] and obs['nativeResult']==result,'actual child/result observation')
        require(obs['actualArgv']==setup['argv'],'actual argv/setup binding')
        argv=setup['argv']; require(argv.count('--memory=5120')==argv.count('--threads=1')==1,'actual CLI memory/thread')
        require(len([x for x in argv if x.startswith('--memory')])==len([x for x in argv if x.startswith('--threads')])==1,'duplicate CLI memory/thread')
        stripped=lambda values:[x for x in values if not x.startswith(('--threads=','--memory='))]
        require(stripped(obs['requestedArgv'])==stripped(argv),'unexpected argv change beyond resource adapter')
        require(0<setup['timeoutSeconds']<=900,'per child bounded timeout')
        for stream in ('stdout','stderr'):
            raw=receipts[label+'.'+stream+'.raw.sanitized.txt']['rawSHA256']
            require(result[stream+'SHA256']==obs[stream+'RawSHA256']==raw,'native raw/public stream receipt chain')
        require(obs['preflightSHA256']==receipts['ci2-'+label+'.preflight.json']['rawSHA256'] and
            obs['postflightSHA256']==receipts['ci2-'+label+'.postflight.json']['rawSHA256'],'resource raw digest chain')
        require(obs['classification']=='PROCESS_EXIT_ZERO' and obs['exceptionType'] is None,'native exception/classification')
        for phase,snapshot in (('preflight',pre),('postflight',post)):
            resource=resource_snapshot(snapshot,phase=='preflight'); contexts.append(resource['context'])
            snapshots.append(dict(label=label,phase=phase,**resource))
        require(datetime.fromisoformat(pre['finishedUTC'])<=begin and datetime.fromisoformat(post['startedUTC'])>=end,'resource/native UTC bracketing')
        expected_path=('$CANDIDATE_WORKSPACE/.lake/build/lib/lean:'+':'.join(search[2:])) if label in ('01-help','02-prefix') else env['LEAN_PATH']
        require(setup['selectedEnvironment']['LEAN_PATH']==expected_path,'per child actual search environment')
        processes.append(dict(label=label,**result,argv=argv,cwd=setup['cwd'],timeoutSeconds=setup['timeoutSeconds']))
    require(len({canonical(c) for c in contexts})==1,'CI context drift')
    require(contexts[0]['GITHUB_RUN_ID']=='38992000000','observed run context label')
    initial=J('candidate-preparation-resource.json'); initial_resource=resource_snapshot(initial,True)
    elapsed=(previous_finish-datetime.fromisoformat(initial['startedUTC'])).total_seconds()
    require(0<=elapsed<=2100,'whole 35 minute observed span')
    for index,(module,target) in enumerate(zip(modules,fresh['targets'])):
        wanted=profile['modules'][index]['rawSHA256']
        require(target['sourceSHA256Before']==target['sourceSHA256After']==target['copiedSourceSHA256']==wanted,'target before/after/copy source binding')
        require(target['cohortID']==fresh['cohortID'] and target['nativeResult']==J(str(11+index)+'-target.result.json'),'target actual result binding')
        path=FRESH+'/'+module.replace('.','/')+'.olean'
        require(observations['bindings'][module]['resolvedOleanPath']==path,'actual target cohort lookup path')
        artifacts=target['artifacts']; require(len(artifacts)==1 and artifacts[0]['path']==path and is_digest(artifacts[0]['sha256']),'fresh target artifact pin')
        setup=J(str(11+index)+'-target.setup.json')
        require(setup['argv'][-3:]==['-o',path,module.replace('.','/')+'.lean'] and setup['cwd']=='$CANDIDATE_WORKSPACE/_out/primitive-compiler-native-profile-v1/source','fresh compile source/output path')
    copied=J('candidate-input-bindings.json')['providerSeedCopies']
    seed={r['module']:r for r in copied if 'module' in r}
    cohort=J('provider-copies.json')['files']
    require(len(seed)==len(cohort)==len(profile['providers'])==25 and set(seed)==set(profile['providers']),'provider seed module vector')
    require(len({r['module'] for r in cohort})==25,'provider cohort copy collision')
    for row in cohort:
        m=row['module']; relative=m.replace('.','/')+'.olean'; s=seed[m]
        require(m not in modules and is_digest(row['sha256']) and row['sha256']==s['sha256'],'inherited provider artifact chain')
        require(s['source']=='$PROJECT/.lake/build/lib/lean/'+relative and s['destination']==row['source']=='$CANDIDATE_WORKSPACE/.lake/build/lib/lean/'+relative and
            row['destination']==FRESH+'/'+relative,'provider original/seed/cohort path chain')
    drivers=J('driver-bindings.json'); no_accept(drivers)
    source_package=project/'tools/primitive_compiler_native_profile_v1'
    expected_driver_hashes=dict(profileDriverSHA256=sha(source_package/'pending-drivers/Profile.lean'),
        probeSHA256=sha(source_package/'pending-drivers/Probe.lean'),collectorSHA256=sha(source_package/'Collector.lean'))
    require(drivers['generatedDrivers']==expected_driver_hashes,'pinned actual collector/profile/probe sources')
    source_to_key={'Profile.lean':'profileDriverSHA256','Probe.lean':'probeSHA256','Collector.lean':'collectorSHA256'}
    for name,key in source_to_key.items():
        matches=[r for r in drivers['artifacts'] if r['path']==DRIVER+'/'+name]
        require(len(matches)==1 and matches[0]['sha256']==expected_driver_hashes[key],'driver artifact source pin')
    require(J('21-driver.setup.json')['argv'][-3:]==['-o',DRIVER+'/Collector.olean','Collector.lean'],'collector compile argv')
    require(J('22-driver.setup.json')['argv'][-3:]==['-o',DRIVER+'/Profile.olean','Profile.lean'],'profile compile argv')
    require(J('30-observe.setup.json')['argv'][-1]=='Probe.lean','actual collector probe argv')
    require(b'Lean (version 4.33.0,' in files['01-help.stdout.raw.sanitized.txt'],'actual Lean version output')
    return dict(actualProcesses=processes,serialNonoverlapChecked=True,resourceSnapshots=snapshots,
        initialResourceSnapshot=initial_resource,wholeObservedSpanSeconds=elapsed,wholeBoundSeconds=2100,
        freshTargetCohort=fresh,driverBindings=drivers,providerCopyChain=cohort,
        providerInventory=dict(artifacts=len(inventory['artifacts']),mode=inventory['mode'],
            leanBinarySHA256=inventory['leanBinarySHA256'],boundary=inventory['boundary'],
            actualExternalSearchRoots=inventory['actualExternalSearchRoots'],
            redactionMayCollapseDistinctRawPaths=True),
        artifactContextGITHUB_SHA=contexts[0]['GITHUB_SHA'],
        executedCheckoutSHAIndependentlyAttested=False,
        freshBinaryRehashBoundary='Only source/helper/entry/current package files rehashed locally. Linux fresh .olean/binary hashes are consistent actual process/cohort receipts; artifact bytes are not bundled and cannot be independently rehashed here',
        inheritedProviderBoundary='Project and external inherited providers are not clean-transitively rebuilt; inventory is not an actual import/load trace',
        namespaceBoundary='Reserved-init namespace implementation fingerprint is not OS/kernel binary attestation',**NO_ACCEPT)


def replay(zip_path,baseline,packet,project,kernel,guard):
    current=load_zip(zip_path); oldfiles={p.name:p.read_bytes() for p in baseline.iterdir() if p.is_file()}
    new_receipts,new_artifact=artifact(current); old_receipts,old_artifact=artifact(oldfiles)
    original,derived,source=source_bindings(project,packet,kernel,guard,current)
    old=validate_stream(parse_stream(oldfiles['30-observe.stdout.raw.sanitized.txt']),original,ORIGINAL_PROFILE)
    new=validate_stream(parse_stream(current['30-observe.stdout.raw.sanitized.txt']),derived,NEW_PROFILE)
    whole=compare_owned(old,new); runtime=runtime_chain(current,new_receipts,derived,new,project,kernel)
    source['sourceTokenNativeAxiomOwnerNamesMatch']=set(whole['legacyNativeAxioms'])=={
        r['sourceRoot']+'._native.native_decide.ax_1_1' for r in source['exactThreeProofTokenSites']}
    require(source['sourceTokenNativeAxiomOwnerNamesMatch'],'source-site/old actual native ownership mismatch')
    old_result=parse(oldfiles['30-observe.result.json'])
    require(old_result['stdoutSHA256']==old_receipts['30-observe.stdout.raw.sanitized.txt']['rawSHA256'],'old native stream raw/public chain')
    artifact_report=dict(authorizedZIP_SHA256=ZIP_SHA,current=new_artifact,baseline=old_artifact,
        oldCollectorStreamPublicSHA256=digest(oldfiles['30-observe.stdout.raw.sanitized.txt']),
        newCollectorStreamPublicSHA256=digest(current['30-observe.stdout.raw.sanitized.txt']),
        ignoredAsVerdictInputs=['completeness.json','whole-owned-comparison.json','result.json','kernel-successor-result.json'],
        independentReplayerImportsPriorValidatorCompareRuntime=False,**NO_ACCEPT)
    module_counts=[]
    for module in new['bindings']:
        module_counts.append(dict(module=module,sourceRoots=sum(r['module']==module for r in new['roots'].values()),
            oldGenerated=sum(r['module']==module for r in old['generated'].values()),
            newGenerated=sum(r['module']==module for r in new['generated'].values()),owned=new['bindings'][module]['ownedCount']))
    summary=dict(role='decoder',identity='/root/primitive_compiler_formal_decoder_c31',
        runID='c31-kernel-v3-actual-independent-replay-v1',direction='formal-only/actual-runtime/proof-token-kernel-successor',
        parentReportedJobID='117276202178',parentReportedRunID='38992000000',parentReportedArtifactID='12085383615',
        parentLabelsNotIndependentlyFetched=True,authorizedZIP_SHA256=ZIP_SHA,
        finiteReplayConsistent=whole['finiteReplayConsistent'],moduleCounts=module_counts,
        **whole['stats'],
        allSurvivingSourceAndGeneratedSignaturesPreserved=all(r['unchangedSignatureAndObservations'] for r in whole['survivingRows']),
        allSurvivingAxiomsExactOldMinusNative=all(r['exactOldMinusNativeAxioms'] for r in whole['survivingRows']),
        oldNativeAxiomsAndTheirTargetOwnedDependencyOccurrencesAbsent=not whole['nativeOrSelfAxiomResidualNames'],
        independentDataReplayNotNewLeanExecution=True,localLeanInvocationCount=0,
        originalSourceBlindScopePreserved=True,
        laterInputs='Own sealed formal source reconstruction, authorized old CI4 actual output, own proof-token and v1/v2/v3 technical packages, current authorized sanitized actual output; no natural source/author context/reviewer/registry',
        scientificClaimBoundary='No source agreement, axiom policy pass, publication binding, ROOT/PURIFIED/main admission, or arbitrary downstream trust-closure claim',**NO_ACCEPT)
    return {'artifact-replay.json':artifact_report,'whole-owned-replay.json':whole,
        'source-runtime-replay.json':dict(source=source,runtime=runtime,**NO_ACCEPT),'evidence-summary.json':summary}


def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as out: json.dump(value,out,indent=2,ensure_ascii=False); out.write('\n')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('zip','baseline-public','source-packet','project','kernel-v1','guard-v3'):
        parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args(); package=Path(__file__).parent
    reports=replay(args.zip,args.baseline_public,args.source_packet,args.project,args.kernel_v1,args.guard_v3)
    for name,value in reports.items(): write(package/name,value)
    print(json.dumps(reports['evidence-summary.json'],indent=2))
