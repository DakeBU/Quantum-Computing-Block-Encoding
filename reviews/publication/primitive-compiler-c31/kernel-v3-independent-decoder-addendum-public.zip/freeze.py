"""Actual Python receipt plus immutable-input replay/addendum seal."""
from datetime import datetime,timezone
import os
from pathlib import Path
import re
import subprocess
import sys
import replay as R

FILES=['README.md','Cubic-reconstruction.md','replay.py','test_replay.py','freeze.py',
    'development-diagnostics.json','artifact-replay.json','whole-owned-replay.json',
    'source-runtime-replay.json','evidence-summary.json','python-tests.json','bindings.json','seal.json']


def run(zip_path,baseline,packet,project,kernel,guard,package):
    gp=R.read(guard/'profile.json'); old_guard=project/'tools/c31_kernel_proof_v2_guard'
    def input_hashes():
        pins={'$ACTUAL_ZIP':R.sha(zip_path)}
        for label,root in (('$OLD_PUBLIC',baseline),('$SOURCE_PACKET',packet),('$KERNEL_V1',kernel),('$GUARD_V3',guard),('$GUARD_V2',old_guard)):
            for p in sorted(root.rglob('*')):
                if p.is_file(): pins[label+'/'+p.relative_to(root).as_posix()]=R.sha(p)
        return pins
    before=input_hashes()
    R.verify_file_vector(kernel,gp['baseFiles']); R.verify_file_vector(old_guard,gp['priorGuardFiles'])
    source_seal=R.read(packet/'source-formal-seal.json'); R.verify_file_vector(packet,source_seal['artifactBindings'])
    values=(zip_path,baseline,packet,project,kernel,guard)
    env=dict(os.environ)
    for key,value in zip(('ZIP','BASELINE','PACKET','PROJECT','KERNEL','GUARD'),values): env['C31_REPLAY_'+key]=str(value)
    command=[sys.executable,'-B','-m','unittest','discover','-s',str(package),'-p','test_replay.py','-v']
    started=datetime.now(timezone.utc).isoformat(); child=subprocess.Popen(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    timeout=False
    try: raw,_=child.communicate(timeout=60)
    except subprocess.TimeoutExpired: timeout=True; child.kill(); raw,_=child.communicate()
    output=raw.decode('utf-8')
    for label,root in (('$ADDENDUM',package),('$OLD_PUBLIC',baseline),('$SOURCE_PACKET',packet),('$PROJECT',project),('$KERNEL_V1',kernel),('$GUARD_V3',guard)):
        output=output.replace(str(root),label).replace(str(root).replace('\\','/'),label)
    R.write(package/'python-tests.json',dict(kind='ACTUAL_INDEPENDENT_REPLAYER_PYTHON_POSITIVE_MUTATION_TESTS',
        startedUTC=started,finishedUTC=datetime.now(timezone.utc).isoformat(),PID=child.pid,
        exitCode=child.returncode,timedOut=timeout,rawStdoutSHA256=R.digest(raw),stdoutSanitized=output,
        logicalArgv=['$PYTHON','-B','-m','unittest','discover','-s','$ADDENDUM','-p','test_replay.py','-v'],
        localLeanInvocationCount=0,**R.NO_ACCEPT))
    print(output)
    R.require(not timeout and child.returncode==0,'actual Python tests failed; receipt retained')
    reports=R.replay(*values)
    for name,value in reports.items(): R.require(value==R.read(package/name),'fresh independent replay differs from saved report: '+name)
    R.require(reports['evidence-summary.json']['finiteReplayConsistent'],'replay differences require report/review')
    R.require(before==input_hashes(),'input changed during tests/replay')
    R.verify_file_vector(old_guard,gp['priorGuardFiles'])
    cubic=[r for r in reports['whole-owned-replay.json']['survivingRows'] if r['role']=='source-root' and r['module']=='QuantumBlockEncoding.CubicAmplitudePrimitive']
    R.require(len(cubic)==25 and all(r['signatureAndObservations']['universeParameters']==[] for r in cubic),'whole-Cubic finite signature scope')
    actual={p.name for p in package.iterdir() if p.is_file()}
    R.require(actual==set(FILES)-{'bindings.json','seal.json'} and not any(p.is_dir() for p in package.iterdir()),'addendum partition')
    for name in actual:
        text=(package/name).read_text(encoding='utf-8')
        R.require(re.search(r'[A-Za-z]:[\\/](?:Users|home|tmp)[\\/]',text) is None,'host path leak: '+name)
    manifest={name:R.sha(package/name) for name in sorted(actual)}
    R.write(package/'bindings.json',dict(files=manifest,immutableInputSHA256=before,**R.NO_ACCEPT))
    R.write(package/'seal.json',dict(state='INDEPENDENT_ACTUAL_RUNTIME_DATA_REPLAY_SEALED_NOT_ADMISSION',
        UTC=datetime.now(timezone.utc).isoformat(),role='decoder',identity='/root/primitive_compiler_formal_decoder_c31',
        runID='c31-kernel-v3-actual-independent-replay-v1',manifestSHA256=R.sha(package/'bindings.json'),
        authorizedZIP_SHA256=R.ZIP_SHA,actualEvidenceSummarySHA256=R.sha(package/'evidence-summary.json'),
        exhaustiveWholeOwnedReplaySHA256=R.sha(package/'whole-owned-replay.json'),
        originalSourceSealSHA256=R.SOURCE_SEAL,immutableInputsUnchanged=True,
        priorKernelV1_19PinsUnchanged=True,priorGuardV2_9PinsUnchanged=True,priorGuardV3_11PinsUnchanged=True,
        publicSafeAllowlist=FILES,localLeanInvocationCount=0,newNativeRunPerformed=False,
        productionChanged=False,workflowChanged=False,registryChanged=False,gitOperations=0,networkOperations=0,
        originalSourceBlindScope=True,laterActualTechnicalContextDisclosed=True,
        publicTransport='Only exact listed technical source/derived data; authorized original ZIP remains separately SHA-bound, raw host paths/private outputs excluded',
        boundary='Independent data/schema/hash/difference replay of actual Lean API observations, not independent native recompilation, raw redaction inversion, OS attestation or provider trust closure',
        **R.NO_ACCEPT))
    print('MANIFEST',R.sha(package/'bindings.json'))
    print('SEAL',R.sha(package/'seal.json'))
    print('SUMMARY',R.sha(package/'evidence-summary.json'))


if __name__=='__main__': run(*(Path(p).resolve() for p in sys.argv[1:7]),Path(__file__).parent.resolve())
