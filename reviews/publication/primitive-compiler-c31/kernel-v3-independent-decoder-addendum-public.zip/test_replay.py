"""Mutation tests of independent replay, using authorized data, never Lean."""
import copy
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
import replay as R

PACKAGE=Path(__file__).parent


class ReplayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.zip=Path(os.environ['C31_REPLAY_ZIP'])
        cls.baseline=Path(os.environ['C31_REPLAY_BASELINE'])
        cls.packet=Path(os.environ['C31_REPLAY_PACKET'])
        cls.project=Path(os.environ['C31_REPLAY_PROJECT'])
        cls.kernel=Path(os.environ['C31_REPLAY_KERNEL'])
        cls.guard=Path(os.environ['C31_REPLAY_GUARD'])
        cls.files=R.load_zip(cls.zip); cls.receipts,_=R.artifact(cls.files)
        cls.original=R.read(cls.kernel/'original-profile.json'); cls.profile=R.read(cls.kernel/'profile.json')
        cls.records=R.parse_stream(cls.files['30-observe.stdout.raw.sanitized.txt'])
        cls.new=R.validate_stream(cls.records,cls.profile,R.NEW_PROFILE)
        olddata=(cls.baseline/'30-observe.stdout.raw.sanitized.txt').read_bytes()
        cls.old=R.validate_stream(R.parse_stream(olddata),cls.original,R.ORIGINAL_PROFILE)

    def fresh_records(self): return copy.deepcopy(self.records)
    def validate(self,records): return R.validate_stream(records,self.profile,R.NEW_PROFILE)
    def J(self,name): return R.parse(self.files[name])
    def mutated_files(self,name,value): return dict(self.files,**{name:R.canonical(value)})

    def test_full_replay_is_independent_and_matches_sealed_report_bytes(self):
        result=R.replay(self.zip,self.baseline,self.packet,self.project,self.kernel,self.guard)
        for name,value in result.items(): self.assertEqual(value,R.read(PACKAGE/name))
        self.assertTrue(result['whole-owned-replay.json']['finiteReplayConsistent'])
        self.assertFalse(result['evidence-summary.json']['nativeAccepted'])
        for name in ('validator','compare','proof_patch','runtime'):
            self.assertNotIn(name,sys.modules)

    def test_duplicate_json_key_unknown_stream_and_missing_summary_rejected(self):
        with self.assertRaises(ValueError): R.parse('{"x":1,"x":2}')
        with self.assertRaises(ValueError): R.parse_stream(b'UNKNOWN {}\n')
        with self.assertRaises(ValueError): R.parse_stream(b'')
        with self.assertRaises(ValueError): R.parse_stream(self.files['30-observe.stdout.raw.sanitized.txt']+b'\n')

    def test_duplicate_actual_name_and_partial_generated_partition_rejected(self):
        records=self.fresh_records(); records.insert(-1,copy.deepcopy(next(r for r in records if r[0]=='C31_GENERATED_JSON')))
        with self.assertRaises(ValueError): self.validate(records)
        records=self.fresh_records(); i=next(i for i,(t,r) in enumerate(records) if t=='C31_GENERATED_JSON'); records.pop(i)
        with self.assertRaises(ValueError): self.validate(records)

    def test_owned_collision_and_private_source_user_mismatch_rejected(self):
        records=self.fresh_records(); binding=next(r for t,r in records if t=='C31_BINDING_JSON'); binding['ownedNames'].append(binding['ownedNames'][0])
        with self.assertRaises(ValueError): self.validate(records)
        records=self.fresh_records(); private=next(r for t,r in records if t=='C31_ROOT_JSON' and r['sourcePrivate']); private['userNameViaActualAPI']='wrong'
        with self.assertRaises(ValueError): self.validate(records)

    def test_ordinal_source_kind_and_kernel_disagreement_rejected(self):
        for key,value in [('moduleOrdinal',999),('sourceKind','opaque'),('kernelTypeAndUniversesAgree',False),('kernelKind','axiomInfo')]:
            records=self.fresh_records(); row=next(r for t,r in records if t=='C31_ROOT_JSON'); row[key]=value
            with self.assertRaises(ValueError): self.validate(records)

    def test_incomplete_type_text_and_value_availability_lie_rejected(self):
        for key,value in [('typePrettyExplicit','Nat → ⋯'),('typePrettyExplicit','…'),('valueObservation','NOT_REQUESTED_NO_VALUE_AVAILABLE')]:
            records=self.fresh_records(); row=next(r for t,r in records if t=='C31_ROOT_JSON'); row[key]=value
            with self.assertRaises(ValueError): self.validate(records)

    def test_structure_field_omission_rejected(self):
        records=self.fresh_records(); structure=next(r['structures'][0] for t,r in records if t=='C31_BINDING_JSON' and r['structures'])
        structure['fieldNames'].pop()
        with self.assertRaises(ValueError): self.validate(records)

    def test_unknown_generated_names_are_observed_not_whitelisted(self):
        records=self.fresh_records(); row=copy.deepcopy(next(r for t,r in records if t=='C31_GENERATED_JSON' and r['actualKind']=='thmInfo'))
        row['actualName']=row['userNameViaActualAPI']='Synthetic.FullyObservedNewGenerated'
        records.insert(-1,('C31_GENERATED_JSON',row))
        binding=next(r for t,r in records if t=='C31_BINDING_JSON' and r['module']==row['module'])
        binding['ownedNames'].append(row['actualName']); binding['ownedCount']+=1
        records[-1][1]['ownedCompleted']+=1; records[-1][1]['generatedCompleted']+=1
        observed=self.validate(records)
        self.assertEqual(len(observed['generated']),114); self.assertEqual(len(observed['rows']),201)
        delta=R.compare_owned(self.old,observed)
        self.assertIn(row['actualName'],[r['actualName'] for r in delta['added']])
        self.assertIsNone(delta['axiomPolicyPass'])

    def test_signature_drift_and_new_axiom_dependency_are_reported(self):
        for key,value in [('typePrettyExplicit','Nat'),('axioms',['Unexpected.imported_axiom'])]:
            records=self.fresh_records(); row=next(r for t,r in records if t=='C31_ROOT_JSON'); row[key]=value
            result=R.compare_owned(self.old,self.validate(records))
            self.assertFalse(result['finiteReplayConsistent']); self.assertIn(row['actualName'],result['unexpectedDifferenceNames'])

    def test_self_axiom_observation_mismatch_rejected(self):
        records=self.fresh_records(); row=next(r for t,r in records if t=='C31_ROOT_JSON'); row['axioms'].append(row['actualName'])
        with self.assertRaises(ValueError): self.validate(records)

    def test_unsafe_drift_is_not_success(self):
        records=self.fresh_records(); row=next(r for t,r in records if t=='C31_ROOT_JSON'); row['isUnsafe']=True
        self.assertFalse(R.compare_owned(self.old,self.validate(records))['finiteReplayConsistent'])

    def test_retained_native_axiom_cannot_pass_partition_and_dependency_check(self):
        records=self.fresh_records(); row=copy.deepcopy(next(r for r in self.old['generated'].values() if r['actualAxiomInfo']))
        records.insert(-1,('C31_GENERATED_JSON',row)); binding=next(r for t,r in records if t=='C31_BINDING_JSON' and r['module']==row['module'])
        binding['ownedNames'].append(row['actualName']); binding['ownedCount']+=1
        records[-1][1]['ownedCompleted']+=1; records[-1][1]['generatedCompleted']+=1
        result=R.compare_owned(self.old,self.validate(records))
        self.assertFalse(result['finiteReplayConsistent']); self.assertIn(row['actualName'],result['nativeOrSelfAxiomResidualNames'])

    def test_public_bytes_corruption_and_receipt_partition_fail_closed(self):
        files=dict(self.files); files['30-observe.stdout.raw.sanitized.txt']+=b'corruption'
        with self.assertRaises(ValueError): R.artifact(files)
        files=dict(self.files); files.pop('01-help.result.json')
        with self.assertRaises(ValueError): R.artifact(files)

    def test_raw_public_hash_distinction_is_explicit(self):
        receipts,report=R.artifact(self.files)
        self.assertEqual(report['members'],79); self.assertEqual(report['receiptMembers'],78)
        self.assertEqual(len(report['rawAndPublicIdenticalByteVerified']),35)
        self.assertEqual(len(report['redactedRawDigestOnlyNotRecomputed']),43)
        name='30-observe.stdout.raw.sanitized.txt'
        self.assertNotEqual(receipts[name]['rawSHA256'],receipts[name]['publicSHA256'])
        self.assertEqual(R.digest(self.files[name]),receipts[name]['publicSHA256'])

    def test_preflight_one_byte_below_and_finite_parent_limit_fail_closed(self):
        snapshot=self.J('ci2-11-target.preflight.json'); threshold=7168*1024*1024
        snapshot.update(memAvailableBytes=threshold-1,effectiveHeadroomBytes=threshold-1,gatePassed=False)
        with self.assertRaises(ValueError): R.resource_snapshot(snapshot,True)
        snapshot=self.J('ci2-11-target.preflight.json'); g=snapshot['cgroups'][-1]
        limit=g['memoryCurrentBytes']+threshold-1
        g.update(memoryMaxRaw=str(limit),memoryMaxBytes=limit,headroomBytes=threshold-1,limitUnlimited=False)
        snapshot.update(effectiveHeadroomBytes=threshold-1,gatePassed=False)
        with self.assertRaises(ValueError): R.resource_snapshot(snapshot,True)

    def test_missing_resource_fields_unknown_namespace_and_root_fake_unlimited_rejected(self):
        for change in ('missing-current','missing-read','namespace','fake-root','windows'):
            snapshot=self.J('ci2-11-target.preflight.json')
            if change=='missing-current': snapshot['cgroups'][0].pop('memoryCurrentBytes')
            if change=='missing-read': snapshot['fileReads'].pop()
            if change=='namespace': snapshot['namespaceObservation']['selfInode']=999
            if change=='fake-root': snapshot['rootObservation']['memoryInterfaces']['memory.max']['unlimitedObserved']=True
            if change=='windows': snapshot['context']['platform']='win32'
            with self.assertRaises((ValueError,KeyError)): R.resource_snapshot(snapshot,True)

    def test_actual_entry_and_helper_pin_mutations_fail_closed(self):
        for name,key,value in [('executing-code-bindings.json','entry',None),('shared-helper-copy.json','destinationSHA256','0'*64)]:
            row=self.J(name)
            if key=='entry': row['entry']['actualFile']='$PROJECT/tools/old-entry.py'
            else: row[key]=value
            with self.assertRaises(ValueError): R.source_bindings(self.project,self.packet,self.kernel,self.guard,self.mutated_files(name,row))

    def test_fresh_cohort_mismatch_and_child_pid_mismatch_rejected(self):
        for name,key,value in [('fresh-target-cohort.json','cohortID','other-cohort'),('11-target.result.json','PID',999999)]:
            row=self.J(name); row[key]=value
            with self.assertRaises(ValueError): R.runtime_chain(self.mutated_files(name,row),self.receipts,self.profile,self.new,self.project,self.kernel)

    def test_comment_mask_and_pin_drift_are_not_bypassed(self):
        raw=b'-- native_decide\n/- outer /- native_decide -/ -/\nnative_decide +revert\n"formal string"'
        masked=R.mask_comments(raw)
        self.assertEqual(masked.count(b'native_decide'),1); self.assertEqual(len(masked),len(raw))
        with tempfile.TemporaryDirectory(prefix='.test-',dir=PACKAGE) as name:
            root=Path(name); (root/'file').write_bytes(b'actual')
            with self.assertRaises(ValueError): R.verify_file_vector(root,{'file':'0'*64})


if __name__=='__main__': unittest.main()
