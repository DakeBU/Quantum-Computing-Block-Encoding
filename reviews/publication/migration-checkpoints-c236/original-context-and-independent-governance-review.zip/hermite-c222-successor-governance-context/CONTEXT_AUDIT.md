# Explicit successor process context before a new proof gate

The previous C156 seal is immutable. A new gate must bind this successor
context explicitly, not pretend the original context bytes are still current.
Thirty-four source/context pins are byte-identical. HARNESS alone changes:
the29-line section8a insertion links the already-recorded user-authorized
asynchronous policy. Old instructions are not edited or deleted in LF view.
The archive preserves exact original mixed-line-ending bytes, not a uniform
CRLF reconstruction. Both raw versions and their Git LF views are pinned.

The insertion delegates bounded tactics/retrieval/screens inside the existing
contract, asks humans for material scientific/oracle/error/success/budget
changes, preserves blind release barriers and requires matched evidence/cost
comparisons. It explicitly does not implement a production event scheduler,
change scoring or claim strategy superiority. It neither weakens a Lean,
root/executable/source/publication gate nor permits finite examples as proofs.

C202 preproof setup-cost signature and C156 scientific statements are unchanged.
C150 definitions, provider hashes, toolchain and binary pins remain original;
the next fresh gate must recheck all of them before and after execution.
Only this new process-context vector can be used for the new run; original
receipts retain their original scopes. No prior result accepts a new source.

C219 did not start Lean: original context assertion rejected the new document.
That stop is expected stale-context protection, not a refuted theorem. The new
gate must keep that observation and C210/C216 failures distinct. C217 remains
an uncompiled candidate. Source+own-output consumer+definition audit are still
required under the original3072MiB/2048reserve/one-thread/180s-per-module caps.

Separate independent process-context review is pending. This document is not
a source-publication review, scientific Proof Seal or policy exception. A
genuine target, definition, verifier or cost-model change is out of scope and
would require its own authorization and new scientific seal.
