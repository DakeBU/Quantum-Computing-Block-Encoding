import QuantumBlockEncoding.Robin.SymmetryFourSlotLogicalUnitary
import QuantumBlockEncoding.PrimitiveBasisLE
import QuantumBlockEncoding.Robin.Hadamard8BlockEncoding
import Mathlib.Tactic

/-!
# Verified four-slot Robin block encoding in the original basis

The sector-basis logical unitary is conjugated by the exact reversal-pair
basis change, reindexed to the original `Fin 8` system order, and flattened to
six qubits.  The resulting clean block is the fixed Robin target divided by
`56/3`, so this module promotes the structural four-slot route to a complete
T2 `VerifiedOperatorBlockEncoding`.

No primitive `{u, cx}` refinement is asserted here.
-/

namespace QuantumBlockEncoding.Robin

open ComplexLCU
open scoped Kronecker

/-- Map a reversal-pair coordinate back to the original `Fin 8` basis. -/
def warmRobinPairSystemToOriginal
    (index : WarmRobinSymmetrySystem) : Fin 8 :=
  if index.1.val = 0 then
    warmRobinPairLow index.2
  else
    warmRobinPairHigh index.2

@[simp] theorem warmRobinPairSystemToOriginal_zero (pair : Fin 4) :
    warmRobinPairSystemToOriginal (0, pair) = warmRobinPairLow pair := by
  rfl

@[simp] theorem warmRobinPairSystemToOriginal_one (pair : Fin 4) :
    warmRobinPairSystemToOriginal (1, pair) = warmRobinPairHigh pair := by
  rfl

/-- Pair coordinates enumerate the original eight basis states exactly once. -/
theorem warmRobinPairSystemToOriginal_bijective :
    Function.Bijective warmRobinPairSystemToOriginal := by
  native_decide

/-- Equivalence between pair coordinates and the original Robin basis. -/
noncomputable def warmRobinPairSystemEquiv :
    WarmRobinSymmetrySystem ≃ Fin 8 :=
  Equiv.ofBijective warmRobinPairSystemToOriginal
    warmRobinPairSystemToOriginal_bijective

@[simp] theorem warmRobinPairSystemEquiv_apply
    (index : WarmRobinSymmetrySystem) :
    warmRobinPairSystemEquiv index = warmRobinPairSystemToOriginal index := by
  rfl

@[simp] theorem warmRobinPairSystemToOriginal_symm (system : Fin 8) :
    warmRobinPairSystemToOriginal (warmRobinPairSystemEquiv.symm system) = system := by
  rw [← warmRobinPairSystemEquiv_apply]
  exact warmRobinPairSystemEquiv.apply_symm_apply system

/-- The symmetry-sector-to-pair basis change: one exact Hadamard-like rotation. -/
noncomputable def warmRobinSymmetryBasisChange :
    _root_.Matrix WarmRobinSymmetrySystem WarmRobinSymmetrySystem ℂ :=
  warmRobinUniformBitPrepare ⊗ₖ
    (1 : _root_.Matrix (Fin 4) (Fin 4) ℂ)

/-- The symmetry basis change is unitary. -/
theorem warmRobinSymmetryBasisChange_unitary :
    warmRobinSymmetryBasisChange ∈
      _root_.Matrix.unitaryGroup WarmRobinSymmetrySystem ℂ := by
  apply _root_.Matrix.kronecker_mem_unitary
  · exact warmRobinUniformBitPrepare_unitary
  · exact (_root_.Matrix.unitaryGroup (Fin 4) ℂ).one_mem

/-- Every entry of the real two-dimensional basis change is self-conjugate. -/
@[simp] theorem star_warmRobinUniformBitPrepare_apply
    (row column : Fin 2) :
    star (warmRobinUniformBitPrepare row column) =
      warmRobinUniformBitPrepare row column := by
  rw [Complex.star_def]
  fin_cases row <;> fin_cases column <;>
    simp only [warmRobinUniformBitPrepare, realOrthogonalRotation]
  · exact Complex.conj_ofReal _
  · rw [map_neg, Complex.conj_ofReal]
  · exact Complex.conj_ofReal _
  · exact Complex.conj_ofReal _

/-- The common real selector amplitude has squared magnitude `1/2`. -/
@[simp] theorem warmRobinUniformScalar_square_complex :
    (((Real.sqrt 2 / 2 : Real) : ℂ) *
      ((Real.sqrt 2 / 2 : Real) : ℂ)) = (1 / 2 : ℂ) := by
  have squareRoot : (Real.sqrt 2) ^ 2 = (2 : Real) :=
    Real.sq_sqrt (by norm_num)
  have realSquare :
      (Real.sqrt 2 / 2) * (Real.sqrt 2 / 2) = (1 / 2 : Real) := by
    nlinarith
  apply Complex.ext
  · simpa using realSquare
  · simp

/-- Entry formula for the exact symmetry basis change. -/
@[simp] theorem warmRobinSymmetryBasisChange_apply
    (row column : WarmRobinSymmetrySystem) :
    warmRobinSymmetryBasisChange row column =
      if row.2 = column.2 then
        warmRobinUniformBitPrepare row.1 column.1
      else 0 := by
  by_cases pairMatch : row.2 = column.2 <;>
    simp [warmRobinSymmetryBasisChange, Matrix.one_apply, pairMatch]

/-- Entry formula for the adjoint symmetry basis change. -/
@[simp] theorem star_warmRobinSymmetryBasisChange_apply
    (row column : WarmRobinSymmetrySystem) :
    star warmRobinSymmetryBasisChange row column =
      if row.2 = column.2 then
        star (warmRobinUniformBitPrepare column.1 row.1)
      else 0 := by
  change star (warmRobinSymmetryBasisChange column row) = _
  rw [warmRobinSymmetryBasisChange_apply]
  by_cases pairMatch : row.2 = column.2 <;>
    simp [pairMatch, eq_comm]

/-- Left multiplication preserves the pair index and sums only over sectors. -/
theorem warmRobinSymmetryBasisChange_mul_pairRow
    {columnType : Type*} [Fintype columnType]
    (operator : _root_.Matrix WarmRobinSymmetrySystem columnType ℂ)
    (rowSide : Fin 2) (rowPair : Fin 4) (column : columnType) :
    (warmRobinSymmetryBasisChange * operator)
        (rowSide, rowPair) column =
      ∑ side : Fin 2,
        warmRobinUniformBitPrepare rowSide side *
          operator (side, rowPair) column := by
  classical
  rw [_root_.Matrix.mul_apply]
  simp_rw [Fintype.sum_prod_type]
  simp_rw [warmRobinSymmetryBasisChange_apply]
  apply Finset.sum_congr rfl
  intro side _
  rw [Finset.sum_eq_single rowPair]
  · simp
  · intro pair _ pair_ne
    simp [Ne.symm pair_ne]
  · simp

/-- Right multiplication by the adjoint also preserves the pair index. -/
theorem mul_star_warmRobinSymmetryBasisChange_pairColumn
    {rowType : Type*} [Fintype rowType]
    (operator : _root_.Matrix rowType WarmRobinSymmetrySystem ℂ)
    (row : rowType) (columnSide : Fin 2) (columnPair : Fin 4) :
    (operator * star warmRobinSymmetryBasisChange)
        row (columnSide, columnPair) =
      ∑ side : Fin 2,
        operator row (side, columnPair) *
          star (warmRobinUniformBitPrepare columnSide side) := by
  classical
  rw [_root_.Matrix.mul_apply]
  simp_rw [Fintype.sum_prod_type]
  simp_rw [star_warmRobinSymmetryBasisChange_apply]
  apply Finset.sum_congr rfl
  intro side _
  rw [Finset.sum_eq_single columnPair]
  · simp
  · intro pair _ pair_ne
    simp [pair_ne]
  · simp

/-- Lower-left pair block equals the upper-right pair block by centrosymmetry. -/
theorem warmRobinIntegerTarget_pair_high_low
    (row column : Fin 4) :
    warmRobinIntegerTarget (warmRobinPairHigh row) (warmRobinPairLow column) =
      warmRobinIntegerTarget (warmRobinPairLow row) (warmRobinPairHigh column) := by
  have symmetry := warmRobinIntegerTarget_centrosymmetric
    (warmRobinPairLow row) (warmRobinPairHigh column)
  simpa [warmRobinPairHigh] using symmetry.symm

/-- The high-high pair block equals the low-low block. -/
theorem warmRobinIntegerTarget_pair_high_high
    (row column : Fin 4) :
    warmRobinIntegerTarget (warmRobinPairHigh row) (warmRobinPairHigh column) =
      warmRobinIntegerTarget (warmRobinPairLow row) (warmRobinPairLow column) := by
  have symmetry := warmRobinIntegerTarget_centrosymmetric
    (warmRobinPairLow row) (warmRobinPairLow column)
  simpa [warmRobinPairHigh] using symmetry.symm

/-- The fixed integer target, reordered by reversal pairs and divided by `224`. -/
def warmRobinPairNormalizedTargetRat :
    _root_.Matrix WarmRobinSymmetrySystem WarmRobinSymmetrySystem Rat :=
  fun row column =>
    warmRobinIntegerTargetRat
      (warmRobinPairSystemToOriginal row)
      (warmRobinPairSystemToOriginal column) / 224

@[simp] theorem warmRobinPairNormalizedTargetRat_zero_zero
    (row column : Fin 4) :
    warmRobinPairNormalizedTargetRat (0, row) (0, column) =
      (warmRobinIntegerTarget
        (warmRobinPairLow row) (warmRobinPairLow column) : Rat) / 224 := by
  rfl

@[simp] theorem warmRobinPairNormalizedTargetRat_zero_one
    (row column : Fin 4) :
    warmRobinPairNormalizedTargetRat (0, row) (1, column) =
      (warmRobinIntegerTarget
        (warmRobinPairLow row) (warmRobinPairHigh column) : Rat) / 224 := by
  rfl

@[simp] theorem warmRobinPairNormalizedTargetRat_one_zero
    (row column : Fin 4) :
    warmRobinPairNormalizedTargetRat (1, row) (0, column) =
      (warmRobinIntegerTarget
        (warmRobinPairLow row) (warmRobinPairHigh column) : Rat) / 224 := by
  unfold warmRobinPairNormalizedTargetRat
  simp only [warmRobinPairSystemToOriginal_one,
    warmRobinPairSystemToOriginal_zero, warmRobinIntegerTargetRat]
  rw [warmRobinIntegerTarget_pair_high_low]

@[simp] theorem warmRobinPairNormalizedTargetRat_one_one
    (row column : Fin 4) :
    warmRobinPairNormalizedTargetRat (1, row) (1, column) =
      (warmRobinIntegerTarget
        (warmRobinPairLow row) (warmRobinPairLow column) : Rat) / 224 := by
  unfold warmRobinPairNormalizedTargetRat
  simp only [warmRobinPairSystemToOriginal_one, warmRobinIntegerTargetRat]
  rw [warmRobinIntegerTarget_pair_high_high]

/-- Complex view of the pair-ordered normalized Robin target. -/
def warmRobinPairNormalizedTargetComplex :
    _root_.Matrix WarmRobinSymmetrySystem WarmRobinSymmetrySystem ℂ :=
  fun row column => (warmRobinPairNormalizedTargetRat row column : ℂ)

/-- Complex view of the direct-sum sector target. -/
def warmRobinFourSlotSectorTargetComplex :
    _root_.Matrix WarmRobinSymmetrySystem WarmRobinSymmetrySystem ℂ :=
  fun row column => (warmRobinFourSlotSectorTarget row column : ℂ)

private theorem warmRobinSymmetryConjugation00
    (c a b : ℂ) (square : c * c = 1 / 2) :
    c * (((a + b) / 224) * c) +
      (-c) * (((a - b) / 224) * (-c)) = a / 224 := by
  calc
    c * (((a + b) / 224) * c) +
        (-c) * (((a - b) / 224) * (-c)) =
      (c * c) * ((a + b) + (a - b)) / 224 := by ring
    _ = a / 224 := by rw [square]; ring

private theorem warmRobinSymmetryConjugation01
    (c a b : ℂ) (square : c * c = 1 / 2) :
    c * (((a + b) / 224) * c) +
      (-c) * (((a - b) / 224) * c) = b / 224 := by
  calc
    c * (((a + b) / 224) * c) +
        (-c) * (((a - b) / 224) * c) =
      (c * c) * ((a + b) - (a - b)) / 224 := by ring
    _ = b / 224 := by rw [square]; ring

private theorem warmRobinSymmetryConjugation10
    (c a b : ℂ) (square : c * c = 1 / 2) :
    c * (((a + b) / 224) * c) +
      c * (((a - b) / 224) * (-c)) = b / 224 := by
  calc
    c * (((a + b) / 224) * c) +
        c * (((a - b) / 224) * (-c)) =
      (c * c) * ((a + b) - (a - b)) / 224 := by ring
    _ = b / 224 := by rw [square]; ring

private theorem warmRobinSymmetryConjugation11
    (c a b : ℂ) (square : c * c = 1 / 2) :
    c * (((a + b) / 224) * c) +
      c * (((a - b) / 224) * c) = a / 224 := by
  calc
    c * (((a + b) / 224) * c) +
        c * (((a - b) / 224) * c) =
      (c * c) * ((a + b) + (a - b)) / 224 := by ring
    _ = a / 224 := by rw [square]; ring

/-- The exact symmetry transform reconstructs the pair-ordered Robin matrix. -/
theorem warmRobinSymmetryBasisChange_conjugates_target :
    warmRobinSymmetryBasisChange *
        (warmRobinFourSlotSectorTargetComplex *
          star warmRobinSymmetryBasisChange) =
      warmRobinPairNormalizedTargetComplex := by
  classical
  ext ⟨rowSide, rowPair⟩ ⟨columnSide, columnPair⟩
  rw [warmRobinSymmetryBasisChange_mul_pairRow]
  simp_rw [mul_star_warmRobinSymmetryBasisChange_pairColumn]
  simp_rw [star_warmRobinUniformBitPrepare_apply]
  let c : ℂ := ((Real.sqrt 2 / 2 : Real) : ℂ)
  let a : ℂ :=
    (warmRobinIntegerTarget
      (warmRobinPairLow rowPair) (warmRobinPairLow columnPair) : ℂ)
  let b : ℂ :=
    (warmRobinIntegerTarget
      (warmRobinPairLow rowPair) (warmRobinPairHigh columnPair) : ℂ)
  have square : c * c = (1 / 2 : ℂ) := by
    simpa [c] using warmRobinUniformScalar_square_complex
  fin_cases rowSide <;> fin_cases columnSide
  · simpa [Fin.sum_univ_two, warmRobinFourSlotSectorTargetComplex,
      warmRobinFourSlotSectorTarget, warmRobinPairNormalizedTargetComplex,
      warmRobinUniformBitPrepare, realOrthogonalRotation,
      warmRobinSymmetryPlusBlock, warmRobinSymmetryMinusBlock,
      c, a, b] using
        warmRobinSymmetryConjugation00 c a b square
  · simpa [Fin.sum_univ_two, warmRobinFourSlotSectorTargetComplex,
      warmRobinFourSlotSectorTarget, warmRobinPairNormalizedTargetComplex,
      warmRobinUniformBitPrepare, realOrthogonalRotation,
      warmRobinSymmetryPlusBlock, warmRobinSymmetryMinusBlock,
      c, a, b] using
        warmRobinSymmetryConjugation01 c a b square
  · simpa [Fin.sum_univ_two, warmRobinFourSlotSectorTargetComplex,
      warmRobinFourSlotSectorTarget, warmRobinPairNormalizedTargetComplex,
      warmRobinUniformBitPrepare, realOrthogonalRotation,
      warmRobinSymmetryPlusBlock, warmRobinSymmetryMinusBlock,
      c, a, b] using
        warmRobinSymmetryConjugation10 c a b square
  · simpa [Fin.sum_univ_two, warmRobinFourSlotSectorTargetComplex,
      warmRobinFourSlotSectorTarget, warmRobinPairNormalizedTargetComplex,
      warmRobinUniformBitPrepare, realOrthogonalRotation,
      warmRobinSymmetryPlusBlock, warmRobinSymmetryMinusBlock,
      c, a, b] using
        warmRobinSymmetryConjugation11 c a b square

/-- Conjugate the sector logical unitary back to reversal-pair coordinates. -/
noncomputable def warmRobinFourSlotPairLogicalUnitary :
    _root_.Matrix
      (LCUIndex (Fin 2) (Fin 4) WarmRobinSymmetrySystem)
      (LCUIndex (Fin 2) (Fin 4) WarmRobinSymmetrySystem) ℂ :=
  conjugateSystem warmRobinSymmetryBasisChange
    warmRobinFourSlotMiddleLogicalUnitary

/-- The pair-basis logical unitary remains exactly unitary. -/
theorem warmRobinFourSlotPairLogicalUnitary_unitary :
    warmRobinFourSlotPairLogicalUnitary ∈
      _root_.Matrix.unitaryGroup
        (LCUIndex (Fin 2) (Fin 4) WarmRobinSymmetrySystem) ℂ := by
  apply conjugateSystem_unitary
  · exact warmRobinSymmetryBasisChange_unitary
  · exact warmRobinFourSlotMiddleLogicalUnitary_unitary

/-- Its clean system block is the pair-ordered normalized Robin target. -/
theorem warmRobinFourSlotPairLogicalUnitary_cleanSystemBlock :
    cleanSystemBlock warmRobinFourSlotPairLogicalUnitary 0 0 =
      warmRobinPairNormalizedTargetComplex := by
  rw [warmRobinFourSlotPairLogicalUnitary,
    cleanSystemBlock_conjugateSystem,
    warmRobinFourSlotMiddleLogicalUnitary_cleanSystemBlock]
  exact warmRobinSymmetryBasisChange_conjugates_target

/-- Entry form of the pair-basis clean-block certificate. -/
theorem warmRobinFourSlotPairLogicalUnitary_cleanEntry
    (row column : WarmRobinSymmetrySystem) :
    warmRobinFourSlotPairLogicalUnitary
        (0, (0, row)) (0, (0, column)) =
      warmRobinPairNormalizedTargetComplex row column := by
  have matrixEquality :=
    warmRobinFourSlotPairLogicalUnitary_cleanSystemBlock
  exact congr_fun (congr_fun matrixEquality row) column

/-- Reindex only the system component from pair order to original `Fin 8`. -/
noncomputable def warmRobinFourSlotProductSystemEquiv :
    LCUIndex (Fin 2) (Fin 4) WarmRobinSymmetrySystem ≃
      LCUIndex (Fin 2) (Fin 4) (Fin 8) :=
  Equiv.prodCongr (Equiv.refl (Fin 2))
    (Equiv.prodCongr (Equiv.refl (Fin 4)) warmRobinPairSystemEquiv)

/-- Flatten coefficient × selector × original system into six qubits. -/
def warmRobinFourSlotOriginalIndexEquiv :
    LCUIndex (Fin 2) (Fin 4) (Fin 8) ≃ Fin (gridSize 6) :=
  (Equiv.prodCongr (Equiv.refl (Fin 2)) finProdFinEquiv).trans
    finProdFinEquiv

/-- The six primitive wires interpreted as coefficient, selector, and system
registers through the already-certified T2 flattening.  Consequently q0--q2
are system, q3--q4 are selector, and q5 is coefficient. -/
def warmRobinFourSlotProductBitsEquiv :
    PrimitiveBasis 6 ≃ LCUIndex (Fin 2) (Fin 4) (Fin 8) :=
  (primitiveBasisLEEquiv 6).trans warmRobinFourSlotOriginalIndexEquiv.symm

/-- Primitive little-endian indexing is exactly the original T2 index map. -/
theorem warmRobinFourSlotProductBitsEquiv_index (bits : PrimitiveBasis 6) :
    warmRobinFourSlotOriginalIndexEquiv
        (warmRobinFourSlotProductBitsEquiv bits) =
      primitiveBasisLEEquiv 6 bits := by
  simp [warmRobinFourSlotProductBitsEquiv]

/-- Regression over all 64 basis states, stated as the concrete register
formula consumed by executable backends. -/
theorem warmRobinFourSlotProductBitsEquiv_all_basis :
    ∀ bits : PrimitiveBasis 6,
      (warmRobinFourSlotOriginalIndexEquiv
          (warmRobinFourSlotProductBitsEquiv bits)).val =
        (bits 0).val + 2 * (bits 1).val + 4 * (bits 2).val +
        8 * (bits 3).val + 16 * (bits 4).val + 32 * (bits 5).val := by
  intro bits
  rw [warmRobinFourSlotProductBitsEquiv_index]
  exact primitiveBasisLEEquiv_six_value bits

/-- Combined system reindexing and six-qubit flattening. -/
noncomputable def warmRobinFourSlotIndexEquiv :
    LCUIndex (Fin 2) (Fin 4) WarmRobinSymmetrySystem ≃
      Fin (gridSize 6) :=
  warmRobinFourSlotProductSystemEquiv.trans
    warmRobinFourSlotOriginalIndexEquiv

/-- Flat clean index for an original Robin system basis state. -/
noncomputable def warmRobinFourSlotCleanIndex (system : Fin 8) : Fin (gridSize 6) :=
  warmRobinFourSlotIndexEquiv
    (0, (0, warmRobinPairSystemEquiv.symm system))

/-- Six-qubit matrix in the original system order. -/
noncomputable def warmRobinFourSlotFlatUnitary :
    _root_.Matrix (Fin (gridSize 6)) (Fin (gridSize 6)) ℂ :=
  _root_.Matrix.reindexAlgEquiv ℂ ℂ warmRobinFourSlotIndexEquiv
    warmRobinFourSlotPairLogicalUnitary

/-- Reindexing preserves exact unitarity. -/
theorem warmRobinFourSlotFlatUnitary_unitary :
    warmRobinFourSlotFlatUnitary ∈
      _root_.Matrix.unitaryGroup (Fin (gridSize 6)) ℂ := by
  apply reindex_unitary
  exact warmRobinFourSlotPairLogicalUnitary_unitary

/-- Applying the flat matrix at flattened indices recovers the product entry. -/
@[simp] theorem warmRobinFourSlotFlatUnitary_reindex
    (row column :
      LCUIndex (Fin 2) (Fin 4) WarmRobinSymmetrySystem) :
    warmRobinFourSlotFlatUnitary
        (warmRobinFourSlotIndexEquiv row)
        (warmRobinFourSlotIndexEquiv column) =
      warmRobinFourSlotPairLogicalUnitary row column := by
  simp [warmRobinFourSlotFlatUnitary]

/-- Pair-ordered target at inverse-reindexed indices is the original target. -/
theorem warmRobinPairNormalizedTargetComplex_symm
    (row column : Fin 8) :
    warmRobinPairNormalizedTargetComplex
        (warmRobinPairSystemEquiv.symm row)
        (warmRobinPairSystemEquiv.symm column) =
      ((warmRobinIntegerTargetRat row column / 224 : Rat) : ℂ) := by
  simp [warmRobinPairNormalizedTargetComplex,
    warmRobinPairNormalizedTargetRat]

/-- The flat clean block is exactly the original fixed Robin target. -/
theorem warmRobinFourSlotFlatUnitary_cleanBlock
    (row column : Fin 8) :
    warmRobinFourSlotFlatUnitary
        (warmRobinFourSlotCleanIndex row)
        (warmRobinFourSlotCleanIndex column) =
      ((RobinEvolution.warmRobinTarget row column /
        RobinEvolution.warmRobinNormalizer : Rat) : ℂ) := by
  unfold warmRobinFourSlotCleanIndex
  rw [warmRobinFourSlotFlatUnitary_reindex]
  rw [warmRobinFourSlotPairLogicalUnitary_cleanEntry]
  rw [warmRobinPairNormalizedTargetComplex_symm]
  have normalizedIdentity := congr_fun
    (congr_fun warmRobin_normalized_eq_integer_div_224 row) column
  exact_mod_cast normalizedIdentity.symm

/-- Fair T2 logical-stage schedule for the four-slot construction. -/
def warmRobinFourSlotT2Schedule : LayeredCircuit :=
  [ [ Gate.oneQubit "T2 selector-H-0" 0
    , Gate.oneQubit "T2 selector-H-1" 1
    , Gate.oneQubit "T2 symmetry-basis-change" 3 ]
  , [ Gate.oracleCall "T2 controlled amplitude rotation" ]
  , [ Gate.oracleCall "T2 sector-preserving SELECT" ]
  , [ Gate.oneQubit "T2 selector-H-0 dagger" 0
    , Gate.oneQubit "T2 selector-H-1 dagger" 1
    , Gate.oneQubit "T2 symmetry-basis-change dagger" 3 ]
  ]

/-- The corresponding logical gate list. -/
def warmRobinFourSlotT2Circuit : Circuit :=
  warmRobinFourSlotT2Schedule.flatten

/-- Exact resource row under the declared T2 logical-stage convention. -/
def warmRobinFourSlotT2Resource : Resource :=
  warmRobinFourSlotT2Schedule.resource

/-- The operator-first clean-block predicate for the four-slot route. -/
def warmRobinFourSlotBlockContainsTarget : Prop :=
  ∀ row column : Fin 8,
    warmRobinFourSlotFlatUnitary
        (warmRobinFourSlotCleanIndex row)
        (warmRobinFourSlotCleanIndex column) =
      warmRobinQueryTarget.operator row column /
        warmRobinQueryTarget.normalizer

/-- The clean-block predicate is discharged by the original-basis theorem. -/
theorem warmRobinFourSlotBlockContainsTarget_proof :
    warmRobinFourSlotBlockContainsTarget := by
  intro row column
  rw [warmRobinFourSlotFlatUnitary_cleanBlock]
  norm_num [warmRobinQueryTarget, warmRobinComplexTarget]

/-- Four-slot T2 candidate for the fixed `N=8` Robin target. -/
noncomputable def warmRobinFourSlotOperatorCandidate :
    OperatorBlockEncodingCandidate ℂ 3 where
  auxiliaryQubits := 3
  target := warmRobinQueryTarget
  unitary := warmRobinFourSlotFlatUnitary
  layout := {
    systemQubits := 3
    signalQubits := 3
    pureAncillas := 0
  }
  circuit := warmRobinFourSlotT2Circuit
  schedule := warmRobinFourSlotT2Schedule
  resource := warmRobinFourSlotT2Resource
  layoutMatches := by decide
  isUnitary :=
    warmRobinFourSlotFlatUnitary ∈
      _root_.Matrix.unitaryGroup (Fin (gridSize 6)) ℂ
  blockContainsTarget := warmRobinFourSlotBlockContainsTarget

/-- Fully verified T2 block encoding for the four-slot symmetry route. -/
noncomputable def warmRobinFourSlotVerifiedBlockEncoding :
    VerifiedOperatorBlockEncoding ℂ 3 where
  candidate := warmRobinFourSlotOperatorCandidate
  unitaryProof := warmRobinFourSlotFlatUnitary_unitary
  blockProof := warmRobinFourSlotBlockContainsTarget_proof

/-- Under one T2 logical-stage convention, four slots strictly improve the
Hadamard-8 route: gate count and depth tie, while the clean layout uses one
fewer auxiliary qubit. -/
theorem warmRobinFourSlotT2Cost_betterThan_hadamard8 :
    warmRobinFourSlotOperatorCandidate.cost.betterThan
      warmRobinHadamard8OperatorCandidate.cost := by
  norm_num [OperatorBlockEncodingCandidate.cost,
    warmRobinFourSlotOperatorCandidate, warmRobinHadamard8OperatorCandidate,
    warmRobinFourSlotT2Resource, warmRobinHadamard8T2Resource,
    warmRobinFourSlotT2Schedule, warmRobinHadamard8T2Schedule,
    LayeredCircuit.resource, CircuitLayer.resource, Gate.resource,
    Resource.parallel, Resource.add, Resource.gates,
    BlockEncodingCost.betterThan]

/-- Honest boundary: primitive synthesis and refinement remain a T3 obligation. -/
def warmRobinFourSlotT3BlockedLeaf : String :=
  "prove that a concrete primitive circuit refines warmRobinFourSlotFlatUnitary and certify its primitive resource counts"

end QuantumBlockEncoding.Robin
