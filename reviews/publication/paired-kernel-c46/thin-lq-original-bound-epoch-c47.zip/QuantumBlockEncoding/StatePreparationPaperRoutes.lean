import QuantumBlockEncoding.StatePreparationPaperRoutesCompact

/-!
# Paper-grounded state-preparation routes

Stable public re-export for the Möttönen dense and Li--Luo sparse benchmark
routes.  Finite UCRY scalar semantics are compiled in
`StatePreparationPaperEntryCertificates`; the proof-bearing route composition
lives in `StatePreparationPaperRoutesCompact` and uses coordinate-level sparse
matrix action to keep finite verification leaves small.  The public declaration
catalog indexes this re-export together with its certificate and benchmark
modules, so the website graph exposes the same proof boundary that Lean builds.
This boundary is intentionally stable for generated catalog and site admission.
-/
