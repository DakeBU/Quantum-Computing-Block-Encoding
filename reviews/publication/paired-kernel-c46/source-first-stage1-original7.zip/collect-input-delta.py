"""Read-only C46 metadata calculation; no compiler, admission, subprocess or writes.

CLI roots are private execution parameters. Output paths use logical roots.
Only binding_digest is called from the unchanged publication checker.
"""
import argparse
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
ap = argparse.ArgumentParser()
ap.add_argument('--project', required=True)
ap.add_argument('--prospective', required=True)
a = ap.parse_args()
R, F = Path(a.project), Path(a.prospective)
O = F / 'overlay'
KEYS = ('module', 'source_id', 'source_statement', 'source_anchor', 'lesson_path',
        'declarations', 'obligation_map', 'assumption_deltas', 'graph_contribution',
        'formalizer', 'residual_boundary')
SLOTS = {'target', 'normalization', 'registers', 'oracles', 'ancillas_phases',
         'error_success', 'resources'}

def sha(b):
    return hashlib.sha256(b).hexdigest()

def pin(p):
    b = p.read_bytes()
    return {'sha256': sha(b), 'bytes': len(b)}

def load(p):
    return json.loads(p.read_text(encoding='utf-8'))

def canonical(x):
    return json.dumps(x, sort_keys=True, ensure_ascii=False).encode()

def local(root, rel):
    p = root / rel
    if Path(rel).is_absolute() or '..' in Path(rel).parts or '\\' in rel:
        raise ValueError('unsafe relative input')
    if not p.resolve().is_relative_to(root.resolve()):
        raise ValueError('escaped root')
    return p

checker = R / 'website/scripts/check_research_publications.py'
spec = importlib.util.spec_from_file_location('c46_original_binding_only', checker)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
context, manifest, seal = (load(F / x) for x in ('context.json', 'overlay-manifest.json', 'seal.json'))
registry = load(R / 'website/research/publications.json')
records = registry['records']
old_sources, new_sources = (load(x / 'website/research/sources.json') for x in (R, O))
old_by = {x['id']: x for x in old_sources['sources']}
new_by = {x['id']: x for x in new_sources['sources']}
pair = {x['module'] for x in context['pair']}
out = {'schema': 'C46_STAGE1_INDEPENDENT_CURRENT_INPUT_DELTA_NOT_ADMISSION',
       'reviewer_identity': '/root/primitive_compiler_source_first_c31',
       'freeze_seal': pin(F / 'seal.json'), 'checker': pin(checker),
       'binding_semantic_keys': list(KEYS),
       'binding_execution': 'Only original binding_digest; not check/validate_record/main; no subprocess/compiler/native/tests',
       'payload': [], 'overlay': {}, 'pair': [], 'candidates': [], 'records': []}
for item in seal['payload']:
    actual = pin(local(F, item['path']))
    out['payload'].append({'path': '$PROSPECTIVE/' + item['path'], **actual,
                           'matches_seal': all(actual[k] == item[k] for k in actual)})
listed = {x['path']: x for x in manifest['files']}
actual_paths = sorted(p.relative_to(O).as_posix() for p in O.rglob('*') if p.is_file())
entries, differences = [], []
for rel, expected in listed.items():
    op, rp = local(O, rel), local(R, rel)
    actual, original = pin(op), pin(rp)
    same = actual == original
    e = {'path': rel, 'overlay': actual, 'current': original, 'equal': same,
         'matches_manifest': all(actual[k] == expected[k] for k in actual)}
    entries.append(e)
    if not same:
        differences.append(rel)
out['overlay'] = {'inventory_exact': actual_paths == sorted(listed),
                  'file_count': len(actual_paths), 'files': entries,
                  'different_paths': differences,
                  'production_module_count': sum(x.startswith('QuantumBlockEncoding/') and x.endswith('.lean') for x in actual_paths),
                  'test_lean_count': sum(x.startswith('ABEISTests/') and x.endswith('.lean') for x in actual_paths)}
out['sources'] = {'current_file': pin(R / 'website/research/sources.json'),
                  'overlay_file': pin(O / 'website/research/sources.json'),
                  'current_count': len(old_by), 'overlay_count': len(new_by),
                  'old_rows_changed_or_missing': [k for k in old_by if old_by[k] != new_by.get(k)],
                  'added_ids': sorted(set(new_by) - set(old_by)),
                  'non_rows_metadata_equal': {k: v for k, v in old_sources.items() if k != 'sources'} == {k: v for k, v in new_sources.items() if k != 'sources'}}

# Read the import command prefix only. Comments are nested in Lean; stop at the
# first non-import/non-prelude command. No theorem bodies are interpreted.
def header_imports(path):
    imports, depth, read_lines = [], 0, 0
    with path.open(encoding='utf-8', newline='') as stream:
        for line in stream:
            read_lines += 1
            clean, i = '', 0
            while i < len(line):
                if depth:
                    if line.startswith('/-', i):
                        depth += 1; i += 2
                    elif line.startswith('-/', i):
                        depth -= 1; i += 2
                    else:
                        i += 1
                elif line.startswith('--', i):
                    break
                elif line.startswith('/-', i):
                    depth = 1; i += 2
                else:
                    clean += line[i]; i += 1
            clean = clean.strip().lstrip('\ufeff')
            if not clean or clean == 'prelude':
                continue
            m = re.fullmatch(r'(?:public\s+|private\s+)?import\s+(.+)', clean)
            if not m:
                break
            tokens = m.group(1).split()
            if any(not re.fullmatch(r'[A-Za-z_][A-Za-z_0-9.]*', t) for t in tokens):
                raise ValueError('unsupported import syntax')
            imports.extend(tokens)
    return imports, read_lines

graphs, headers = [], []
for root in (R, O):
    g = {}
    h = []
    for p in sorted((root / 'QuantumBlockEncoding').rglob('*.lean')):
        rel = p.relative_to(root).as_posix()
        imps, n = header_imports(p)
        g[rel] = sorted(x.replace('.', '/') + '.lean' for x in imps if x.startswith('QuantumBlockEncoding.'))
        h.append({'path': rel, 'imports': imps, 'prefix_lines_consumed': n})
    graphs.append(g)
    headers.append(h)
G, GO = graphs
missing_local_imports = sorted({q for vals in GO.values() for q in vals if q not in GO})
out['imports'] = {'scope': '142 production module import-prefixes each root; module-level overapproximation, not theorem dependency/binary attestation; no test headers',
                  'graphs_equal': G == GO, 'missing_local_imports': missing_local_imports,
                  'current_headers': headers[0], 'overlay_headers': headers[1]}

def closure(g, start):
    seen, stack = set(), [start]
    while stack:
        x = stack.pop()
        if x in seen:
            continue
        seen.add(x)
        stack.extend(g.get(x, []))
    return sorted(seen)

for item in context['pair']:
    rel = item['module']
    old, new = (local(x, rel).read_bytes() for x in (R, O))
    old_lines, new_lines = old.decode().splitlines(keepends=True), new.decode().splitlines(keepends=True)
    changes = []
    for tag, i, j, k, l in difflib.SequenceMatcher(a=old_lines, b=new_lines, autojunk=False).get_opcodes():
        if tag != 'equal':
            changes.append({'tag': tag, 'old_lines': [i + 1, j], 'new_lines': [k + 1, l],
                            'old': ''.join(old_lines[i:j]), 'new': ''.join(new_lines[k:l])})
    # Independent reverse transformation to an exact old byte string. Cubic has
    # three identical replacements; CSP's exceptional finite rational case is
    # explicitly visible in the diff rather than classified by substring alone.
    out['pair'].append({'module': rel, 'current': pin(local(R, rel)), 'overlay': pin(local(O, rel)),
                        'matches_context_old': sha(old) == item['original_sha256'],
                        'matches_context_new': sha(new) == item['candidate_sha256'],
                        'changes': changes, 'imports_equal': G[rel] == GO[rel]})

original = load(F / 'original-candidates.json')
for orig_path, expected_sha in zip(original['paths'], original['sha256']):
    old = load(local(R, orig_path))
    rel = old['module']
    candidate_path = 'candidate-record-' + Path(rel).stem + '.json'
    candidate = load(F / candidate_path)
    semantic_delta = [k for k in KEYS if old.get(k) != candidate.get(k)]
    outer_delta = [k for k in sorted(set(old) | set(candidate)) if k not in KEYS and old.get(k) != candidate.get(k)]
    out['candidates'].append({'module': rel, 'original_path': '$PROJECT/' + orig_path,
                             'original_pin': pin(local(R, orig_path)), 'original_pin_matches': pin(local(R, orig_path))['sha256'] == expected_sha,
                             'candidate_path': '$PROSPECTIVE/' + candidate_path, 'candidate_pin': pin(F / candidate_path),
                             'semantic_11_field_delta': semantic_delta, 'other_changed_fields': outer_delta,
                             'declared_roots': len(candidate['declarations']), 'obligation_entries': len(candidate['obligation_map']),
                             'computed_binding': mod.binding_digest(O, candidate), 'claimed_binding': candidate['binding_sha256'],
                             'semantic_metadata_sha256': sha(canonical({k: candidate.get(k) for k in KEYS})),
                             'status': candidate.get('status'), 'decoder_evidence_path_not_read': candidate['decoder_evidence'],
                             'reviewer_evidence_path_not_read': candidate['reviewer_evidence']})

ctx_by = {x['module']: x for x in context['contexts']}
impact_by = {x['module']: x for x in context['import_impact']}
for record in records:
    rel, old_binding = record['module'], record['binding_sha256']
    current_digest, prospective_digest = (mod.binding_digest(root, record) for root in (R, O))
    c = closure(GO, rel)
    row = {'module': rel, 'source_id': record['source_id'], 'lesson_path': record['lesson_path'],
           'record_json_canonical_sha256': sha(canonical(record)),
           'semantic_11_field_sha256': sha(canonical({k: record.get(k) for k in KEYS})),
           'declared_roots': len(record['declarations']),
           'declarations_sha256': sha(canonical(record['declarations'])),
           'mapping_sha256': sha(canonical(record['obligation_map'])),
           'assumption_delta_sha256': sha(canonical(record['assumption_deltas'])),
           'source_graph_sha256': sha(canonical(record['graph_contribution'])),
           'selected_source_equal': old_by[record['source_id']] == new_by[record['source_id']],
           'selected_source_sha256': sha(canonical(old_by[record['source_id']])),
           'lesson_pin': pin(local(R, record['lesson_path'])),
           'lesson_equal': local(R, record['lesson_path']).read_bytes() == local(O, record['lesson_path']).read_bytes(),
           'claimed_old_binding': old_binding, 'computed_current_binding': current_digest,
           'computed_prospective_binding': prospective_digest,
           'current_binding_matches': old_binding == current_digest,
           'matches_context_old': ctx_by[rel]['original_binding'] == current_digest,
           'matches_context_prospective': ctx_by[rel]['prospective_binding'] == prospective_digest,
           'import_closure': c, 'changed_pair_in_closure': sorted(pair.intersection(c)),
           'closure_matches_context': c == sorted(impact_by[rel]['import_closure']),
           'closure_raw_bytes_equal': all(local(R, p).read_bytes() == local(O, p).read_bytes() for p in c),
           'formalizer_as_recorded': record['formalizer'], 'role_lineage': []}
    dec = load(local(R, record['decoder_evidence']))
    rev = load(local(R, record['reviewer_evidence']))
    dh = pin(local(R, record['decoder_evidence']))['sha256']
    for role, ev in (('decoder', dec), ('reviewer', rev)):
        ep = record[role + '_evidence']
        context_pin = ctx_by[rel]['prior_' + role + '_sha256']
        e = {'role': role, 'path': ep, 'pin': pin(local(R, ep)),
             'context_path_matches': ctx_by[rel]['prior_' + role] == ep,
             'context_pin_matches': pin(local(R, ep))['sha256'] == context_pin,
             'identity': ev.get('identity'), 'run_id': ev.get('run_id'),
             'role_matches': ev.get('role') == role, 'old_binding_matches': ev.get('binding_sha256') == old_binding,
             'packet_path': ev.get('packet_path'), 'artifact_path': ev.get('artifact_path')}
        for kind in ('packet', 'artifact'):
            p = ev.get(kind + '_path')
            observed = pin(local(R, p))
            e[kind + '_pin'] = observed
            e[kind + '_pin_matches'] = observed['sha256'] == ev.get(kind + '_sha256')
        if role == 'decoder':
            e['source_blind_recorded'] = ev.get('source_blind') is True
            e['reconstruction_present'] = bool(ev.get('reconstruction'))
        else:
            e['anti_anchored_recorded'] = ev.get('anti_anchored') is True
            e['prior_verdict_recorded'] = ev.get('verdict')
            e['exact_decoder_binding_matches'] = ev.get('decoder_evidence_sha256') == dh
            e['seven_slot_shape_nonempty'] = set(ev.get('semantic_slots', {})) == SLOTS and all(ev.get('semantic_slots', {}).values())
        row['role_lineage'].append(e)
    row['three_recorded_identities_distinct'] = len({record['formalizer'], dec.get('identity'), rev.get('identity')}) == 3
    out['records'].append(row)

out['registry'] = {'pin': pin(R / 'website/research/publications.json'), 'record_count': len(records),
                   'distinct_modules': len({x['module'] for x in records}),
                   'matches_context_module_set': set(ctx_by) == {x['module'] for x in records},
                   'scope': 'Current existing record bytes only; no changed registry, future role evidence, verdict-prose assimilation or admission check'}
out['root_entry'] = {'current': pin(R / 'QuantumBlockEncoding.lean'), 'overlay': pin(O / 'QuantumBlockEncoding.lean'),
                     'LF_normalized_sha256': sha((O / 'QuantumBlockEncoding.lean').read_bytes().replace(b'\r\n', b'\n')),
                     'binding_digest_includes_root_entry': False}
out['protocol'] = pin(R / 'docs/theorem-publication-protocol.md')
print(json.dumps(out, ensure_ascii=False, indent=2))
