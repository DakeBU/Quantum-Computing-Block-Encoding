# C46 Stage1: prospective paired proof-only epoch and current input-delta review

Original identity `/root/primitive_compiler_source_first_c31`; run `c31-source-first/c46-current-input-delta-stage1/20261017`. Direction fingerprint: `current-source-metadata-proofonly-delta-carryforward`.

## Bounded judgment

The exact prospective pair supports continuation of my previously sealed **whole Cubic module source-side judgment**. The 37 existing records also support retaining their original genuine reviews together with this new, explicit current-input delta assessment. This is not 37 fresh mathematical/source-blind reviews, another owner's identity, a parent rehash, final accepted-role evidence, or production integration.

There is no newly found source-mathematical obstruction in this frozen epoch. The remaining gates are concrete: compare the separately released actual current decoder evidence, bind real versioned role results to these exact prospective inputs and decoder hashes, then install the exact pair once and complete the unchanged integration/publication gates. Stage1 does none of those future actions. No new decoder result or author joint-comparison was read.

The original natural derivation preceded implementation reading. Subsequent formal/static/actual/decoder exposures were explicitly staged late context, not permanent blindness. My original notes, Phase1/6/7/8 seals and all six C45 files were rehashed unchanged; the exact pins are in `independent-index.json`. C45 diagnosis is not rewritten. This is the same reviewer, not a fabricated fresh identity.

## Independently reconstructed epoch

The actual prospective seal is `888047e7d9aa187392b5af6f99064db7e53b0e723872775529713ce42ce8e477`. Its five payloads match their byte counts and hashes. The overlay's complete actual file set equals all 229 manifest entries. Against current production, exactly three paths differ:

- `QuantumBlockEncoding/CubicStatePreparation.lean`: `d125f8c239bca1c15e6e4fa6e788df6dd8984394630cb2dcc9be8946c4cbcb55` becomes `6ee53311b5d6e18c46afb3e068341689acb86f1bdbc425e774705e81c9142f44`.
- `QuantumBlockEncoding/CubicAmplitudePrimitive.lean`: `48c9a4a1c47c925c93493eede21eb7b492d23d2cb7dadf254782e4485c349cb3` becomes `952e2b359796ef695a1b1c1a376d40a80affbc679f503f94227ea0c775a6cd48`.
- `website/research/sources.json`: the 41 old selected rows and all non-row catalog metadata are unchanged; exactly the C29 retrospective source row is added, giving 42 rows. No old record selects that added row. Its canonical row hash is `5169daabbb6a17e4afb46a5df14f4e5f5cd431ae80f91d4ae8f75c2438045539`.

The source inventory is 142 production modules and 60 test Lean files, not 202 production modules. All 60 tests, the other 140 production modules, all 22 bundled lesson/source documents, three configs and the top-level root entry are raw-byte equal between current production and overlay. The 31 current source/config pins in my C45 relation still equal the original inputs of the reviewed joint cohort. The overlay changes only the two intended candidate hashes within that map.

The root entry's raw SHA is `cf50e72feb667107efe17132c8834db81a135c0072a80c3cb7365ebbc294815e`; normalizing its CRLF to LF gives `0a143b763e80aa4c6c9e6bc883f0a2ee50512520f7111156afe2f7e717b8fafb`. I independently observed that byte relation. Parent's committed-Linux-root attribution and packaging-test reports are not an independent Git/runtime observation by me. The unchanged checker excludes this root entry from `binding_digest`; equality of that digest cannot certify root-entry/build/cohort equality. I did not read or endorse a new package/test result to repair that boundary.

## Proof-only source and full Cubic semantics

I recomputed the exact line diff from current production to the frozen overlay, not from the parent's diff flags. Cubic differs only at original lines 40/93/100: `native_decide +revert` becomes `decide +kernel +revert`. CSP differs at 252/372/437/441/771/775/779/2465/2535: eight `native_decide` calls become `decide +kernel`; the local Rat zero-subtraction proof becomes `exact Rat.sub_self`. No other source byte changes. The candidate Cubic also equals the previously reviewed stored candidate exactly.

Consequently statements and implicit/explicit binders, imports, ordinary definitions, structure/Prop fields, literal programs, normalization, phases, register order and resource expressions remain the already-reviewed ones. Proof terms change; proof-body equality is neither required nor asserted. Proof irrelevance is the relevant bridge for data definitions carrying proof-valued arguments such as the amplitude bound. No all-pretty-proof-body rereading or new whole-TCB standard is introduced.

Both candidate records retain every one of the original checker's **11 semantic payload fields**, including full declaration lists, source mapping, assumptions, graph contribution and residual boundary. The only changed outer fields are `binding_sha256`, `decoder_evidence`, `reviewer_evidence`, `status` and explicit `proof_context_successor`. “Metadata12” is shorthand at most for those 11 fields plus binding, not 12 hashed semantic fields. Original candidate files match their frozen hashes. Cubic still covers all 25 public source roots, not only three repaired lemmas; CSP has 269 public declarations but is not newly reviewed in full by me.

For Cubic, original F1/F2 full binder roles and exhaustive source links remain fixed; F3 retains the corrected v4 full AND tails, compiler-definition producer, both required branches, local phase OR, separate direct block/recursive denotation and unitary/clean/wrapper/count obligations. F4 generic Prop contracts remain distinct from concrete physics. F5 finite-bit/presentation and scalable-target limits remain; candidate native observations are not current production observations. Neither the historical pending labels nor the new source row's `primary-text-checked` label is a mathematical verdict.

The seven Cubic semantic slots are unchanged:

- `target`: finite n=2 diagonal `(0,1/64,1/8,27/64)`, concrete clean compression and all whole-module wrappers; not generic-width/scalable arithmetic, normalized rank-one preparation or Hermite closure.
- `normalization`: clean-block normalizer 1, not coefficient-vector norm 1.
- `registers`: system wires 0/1, signal wire 2, little-endian `j+4s`, full contexts. Generic controls may repeat, provided each avoids the target; no new injectivity premise is added.
- `oracles`: zero opaque oracle calls in the primitive list; exact angle/table construction is not thereby free.
- `ancillas_phases`: one signal, no extra pure ancilla, exact zero program global phase with exact macro phase bookkeeping, not equality only modulo global phase. Clean compression is not a claim that the signal always exits zero.
- `error_success`: exact ideal matrix/clean block; success can be zero. No finite-bit angle-error, hardware execution or deterministic normalized-state preparation certificate is added.
- `resources`: unchanged definitional four RY/six CX at n=2; generic recurrence remains exponential, not efficient merely because oracle count is zero. Classical CI process budgets are a separate resource contract.

## Current 37-record carry-forward: what was independently checked

The actual current registry has 37 distinct module records, SHA `e8b9910f60c6e674ca5849685625ca2eae4218fd0bb8c504fb8c0223b86982c3`. I did not import the old 26-record result as a current partition. I independently reread all 142 production import-command prefixes in both roots and computed each current record's transitive closure. Both import graphs match; every local imported production module resolves; all 37 closures agree with the frozen context and contain neither changed module. Every closure's complete raw source bytes match. This is a module-level import overapproximation, not elaborated theorem use, proof-term export dependence or binary/load attestation. No test header or whole background proof was newly read for mathematics.

For each record, the index pins the entire current record, all 11 semantic fields, declaration mapping, assumptions, graph metadata, selected source row and lesson. The same unchanged actual record object is used in both calculations: there is no overlay replacement of these 37 records. Each module/source/lesson/config/closure relation is explicit, not inferred from a new hash alone. All 37 selected source rows, lessons, configs and semantic payloads are unchanged. The only ambient Lean delta is the known proof-only pair outside their source import closures.

I additionally verified 74 actual old role JSON files mechanically: exact current/context paths and file hashes; declared role, identity/run and old binding; actual packet and artifact byte hashes; pairwise-distinct recorded formalizer/decoder/reviewer identities; decoder's recorded original source-blind/reconstruction fields; reviewer's recorded anti-anchoring, old verdict, exact decoder-file hash and seven nonempty slots. Every compared field/pin matched. Packet/artifact bytes were hashed opaquely, not newly treated as mathematical proof text. Old verdict prose was not used as new semantic reasoning. These are traceable original results, not identity authentication by a JSON string or a fresh audit of another reviewer's original work.

The old genuine reviews can therefore be retained **as immutable historical source judgments**, with this distinct, genuinely new current-input delta assessment covering the only intervening change. I do not assume another owner's identity or claim to have redone their mathematical reading. This is a justified bounded semantic carry-forward, not a blanket global rehash. It leaves any original scope/exclusions and historical audit debt intact.

All 37 global binding digests nevertheless change, correctly: the original formula deliberately binds every Lean source under both directories even when a module does not import them. Old role files remain bound to their old contexts and cannot be copied with a new binding field or silently passed as current evidence. New explicit versioned current-context role results must retain exact old lineage and this input-delta reasoning. This Stage1 package supplies reasoning, not final role JSON; the separately authorized actual decoder comparison remains pending. Nothing here bypasses the checker's stale-binding gate or changes protocol section 8.

## Exact binding and remaining execution boundary

I imported the byte-pinned original checker and invoked **only `binding_digest`**, a read-only hash computation. I did not invoke `validate_record`, `check`, `main`, Git, a compiler, tests or admission. Original checker SHA is `f8f6d7232376b5bc19a480b7e0ef549a5fafa8d66017e07482f7e6999962f8ad`.

All 37 old digests match current production and all 37 new digests match the frozen context. Both candidates' recomputed digests match exactly:

- Cubic: `96cbdfe00cbf40da9e6d2dcabfc7223b022f0ea37bbdfb3b99bfef1b90f5a29c`.
- CSP: `4f514db87d3981a540b874342f4c643ec196f60ccfe01461e518b96512da9066`.

The formula hashes 11 metadata fields, selected module/lesson/toolchain/manifest, both full Lean directory sets and only the selected source row. It does not hash root entry, lakefile, the whole source catalog or role-result prose; these exclusions are disclosed, not silently added to the formula. Lakefile/root equality is independently pinned above.

The already-reviewed C38 joint cohort, ZIP `c540fc35303cf5c7f865d90cd4b3fbca3b3ef840bd926c743657e606e85b5d51`, had fresh CSP-nine followed by Macros/Uniform/Cubic. Its source/type/axiom conclusions are reused only for those exact candidate/source/provider pins and the previously recorded observation interfaces. It removed the three Cubic and nine CSP target-owned native axioms in that candidate scope, retaining the standard union `Classical.choice`, `Quot.sound`, `propext`, not axiom freedom. Current production still has the original two source files. Its installed compiler/cache/providers/cohort were not observed anew here.

Inherited-provider and process/collector boundaries, missing proof-value text and the 96 incomplete CSP generated values remain as previously disclosed. Source-import absence does not attest runtime binaries. Source alignment does not authorize a new native TCB policy, and absence of positive authorization in this scope is neither a policy ban nor a newly invented requirement. Existing production integration, trust, build/test and publication gates remain pending on the final installed batch; no extra arbitrary gate is imposed.

Stop after Stage1 sealing. No final registry accepted/nativeAccepted/main/ROOT/SourceAgreement/PURIFIED claim is made, and no production, policy or old sealed file was changed.
