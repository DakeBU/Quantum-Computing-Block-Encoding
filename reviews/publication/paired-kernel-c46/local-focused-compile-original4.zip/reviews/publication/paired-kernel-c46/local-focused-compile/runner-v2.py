"""Versioned namespace-seeded focused compile; original failed runner preserved."""
import argparse,hashlib,json,os,shutil,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
sha=lambda b:hashlib.sha256(b).hexdigest()
ap=argparse.ArgumentParser();ap.add_argument('--project',type=Path,required=True);ap.add_argument('--frozen',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
a=ap.parse_args();assert not a.output.exists(),'Never restart/overwrite an actual run'
assert sha((a.frozen/'seal.json').read_bytes())=='888047e7d9aa187392b5af6f99064db7e53b0e723872775529713ce42ce8e477'
manifest=json.loads((a.frozen/'overlay-manifest.json').read_bytes())['files'];overlay=a.frozen/'overlay'
assert all(sha((overlay/r['path']).read_bytes())==r['sha256'] for r in manifest)
shim=shutil.which('lean');assert shim,'Run through lake env'
prefix=Path(subprocess.check_output([shim,'--print-prefix'],cwd=a.project,text=True).strip())
lean=prefix/'bin'/('lean.exe' if os.name=='nt' else 'lean');assert lean.is_file()
version=subprocess.check_output([str(lean),'--version'],cwd=a.project,text=True).strip();assert 'version 4.33.0' in version
binary=sha(lean.read_bytes())
memory_script='(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory'
available=int(subprocess.check_output(['powershell.exe','-NoProfile','-Command',memory_script],text=True).strip())//1024
assert available>=4608,dict(free_MiB=available,needed_MiB=4608,decision='no_compile_no_retry')
a.output.mkdir();fresh=a.output/'fresh';fresh.mkdir();private=a.output/'private';private.mkdir()
# Lean resolves a package namespace as one search root; an empty first root
# cannot fall through for sibling providers. Preserve exact inherited cache
# bytes in a separate namespace, excluding all four targets to compile fresh.
target_names={'CubicStatePreparation','PrimitiveMacros','UniformlyControlledRy','CubicAmplitudePrimitive'}
cache=a.project/'.lake/build/lib/lean/QuantumBlockEncoding'
assert cache.is_dir()
seeded=[]
for path in sorted(cache.rglob('*')):
    if not path.is_file() or path.name.split('.')[0] in target_names:continue
    relative=path.relative_to(cache);dest=fresh/'QuantumBlockEncoding'/relative
    dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,dest)
    raw=path.read_bytes();assert dest.read_bytes()==raw
    seeded.append(dict(path='QuantumBlockEncoding/'+relative.as_posix(),sha256=sha(raw),bytes=len(raw)))
assert seeded
env=dict(os.environ);env['LEAN_PATH']=str(fresh)+os.pathsep+env.get('LEAN_PATH','')
targets=['CubicStatePreparation','PrimitiveMacros','UniformlyControlledRy','CubicAmplitudePrimitive'];rows=[]
start=datetime.now(timezone.utc).isoformat()
originals={n:sha((a.project/'QuantumBlockEncoding'/str(n+'.lean')).read_bytes()) for n in targets}
for n in targets:
    name='QuantumBlockEncoding/'+n+'.lean';source=overlay/name
    out=fresh/'QuantumBlockEncoding'/str(n+'.olean');out.parent.mkdir(exist_ok=True)
    source_before=sha(source.read_bytes());command=[str(lean),'--threads=1','--memory=3072','--root='+str(overlay),str(source),'-o',str(out)]
    began=time.monotonic();timed_out=False
    try:run=subprocess.run(command,cwd=a.project,env=env,capture_output=True,timeout=600);code=run.returncode;stdout=run.stdout;stderr=run.stderr
    except subprocess.TimeoutExpired as ex:code=None;timed_out=True;stdout=ex.stdout or b'';stderr=ex.stderr or b''
    (private/str(n+'.stdout')).write_bytes(stdout);(private/str(n+'.stderr')).write_bytes(stderr)
    private_command=dict(command=command,LEAN_PATH=env['LEAN_PATH']);(private/str(n+'.command.json')).write_text(json.dumps(private_command,indent=2)+'\n',encoding='utf-8')
    row=dict(module=name,source_sha256=source_before,source_unchanged=sha(source.read_bytes())==source_before,
      command=['lean','--threads=1','--memory=3072','--root=$FROZEN/overlay','$FROZEN/overlay/'+name,'-o','$OUTPUT/fresh/QuantumBlockEncoding/'+n+'.olean'],
      exit_code=code,timed_out=timed_out,wall_seconds=time.monotonic()-began,
      stdout_sha256=sha(stdout),stderr_sha256=sha(stderr),olean_created=out.is_file(),olean_sha256=sha(out.read_bytes()) if out.is_file() else None)
    rows.append(row);print(json.dumps(dict(module=name,exit_code=code,timed_out=timed_out,wall_seconds=row['wall_seconds'],olean=row['olean_created'])),flush=True)
    if code!=0 or not out.is_file() or not row['source_unchanged']:break
assert all(sha((overlay/r['path']).read_bytes())==r['sha256'] for r in manifest)
assert binary==sha(lean.read_bytes())
assert originals=={n:sha((a.project/'QuantumBlockEncoding'/str(n+'.lean')).read_bytes()) for n in targets}
receipt=dict(schema='C46_ACTUAL_LOCAL_FROZEN_PAIRED_FOCUSED_COMPILE_V2_NOT_FULL_GATE',startedUTC=start,finishedUTC=datetime.now(timezone.utc).isoformat(),
  PID=os.getpid(),Lean_version=version,Lean_binary_sha256=binary,preflight_free_MiB=available,memory_cap_MiB=3072,threads=1,per_target_timeout_seconds=600,
  overlay_seal_sha256='888047e7d9aa187392b5af6f99064db7e53b0e723872775529713ce42ce8e477',
  overlay_manifest_sha256=sha((a.frozen/'overlay-manifest.json').read_bytes()),rows=rows,
  inherited_namespace_artifacts=seeded,runner_sha256=sha(Path(__file__).read_bytes()),
  prior_failure='Original unseeded firstnamespace lacked BlockEncodingClassics.olean; original run/receipt retained. This successor copies inherited sibling namespace artifacts byteexactly,excludes four targets,doesnot change proof/config/policy or claim clean-transitive build.',
  all_four_fresh=len(rows)==4 and all(r['exit_code']==0 and r['olean_created'] and r['source_unchanged'] for r in rows),
  provider_boundary='Inherited project and Mathlib/native caches via actual lake env; fresh only these four target modules with fresh CSP first. Source/command/output evidence,not clean-transitive rebuild or dynamic loader/recursive-axiom audit.',
  raw_logs='Private only because actual command/diagnostics can include host paths; public receipt retains exact hashes and logical command.',
  production_source_changed=False,registry_changed=False,verifier_changed=False,full_Lean_Tests_gate=False,main_admitted=False,scientific_ROOT=False,PURIFIED=False)
(a.output/'receipt.public.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(actual_focused_success=receipt['all_four_fresh'],receipt_sha256=sha((a.output/'receipt.public.json').read_bytes()))),flush=True)
raise SystemExit(0 if receipt['all_four_fresh'] else 1)
