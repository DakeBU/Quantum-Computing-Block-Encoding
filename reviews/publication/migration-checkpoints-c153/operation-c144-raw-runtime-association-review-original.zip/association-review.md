# C144 independent raw/runtime association review

Reviewer: temporary_and_operation_statement_review_c120.
Finding: LOCAL_ISOLATED_COMPILE_AND_TYPE_AXIOM_RECEIPTS_ASSOCIATE_WITH_REVIEWED_TARGET, WITH_INHERITED_CONTEXT_LIMITS.

This review now inspects actual retained runtime evidence, after the immutable source-first, proposal, C138 own-formal and C140 actual-decoder comparison freezes. It does not rerun a compiler or execute any supplied script/binary. It is not final source admission, a Proof Seal, a clean-transitive-TCB certificate, production/main admission or scientific SP/BE root closure.

## What has actually been associated

The fixed private C143 input manifest has SHA-256 fe482fe89a0ac4f540e8f115ce0a2f5d772a0e5e4b19c4cd01072cff4ac8f508. All51 specified member byte lengths and hashes matched, including the three retained .olean artifacts HASHED ONLY. The optional outer ZIP was unnecessary and not opened. Private log ZIP entries were read in memory without extraction or execution.

The raw OperationBridge source is byte-identical to the previously independently reviewed formal target, SHA-256 2f1150d4c6c48c24e0d62155e94316004efb72ed70ce9d69105ba1a737d64ce3. Whole raw OperationBridge, StatementProbe and TemporaryAnd were read, as were the complete Statement Seal, its root text file, and actual RootAudit source. Raw StatementProbe differs from its formal snapshot only by its module comment mask, while TemporaryAnd is also byte-identical to its formal counterpart.

An independently authored static scanner reproduced all30 raw-to-formal derivatives exactly, including1323 comment regions and CRLF normalization, while preserving supported strings/quoted identifiers. It did NOT execute the provided mask or transport wrapper. The supplied mask and transport wrapper were also read statically. This is a bounded association check for these exact inputs, not a universal Lean lexer or proof of arbitrary program-equivalence. Relevant raw provider comments and selected raw code ranges were inspected explicitly; thirty byte matches are not thirty semantic reviews.

The current target root header equals the exact Statement Seal signature string and its recorded UTF8 digest69d7f9c468246474b119e7bd542d1122d86fe91e3c9e074aa3d9682df6150bfe. The separately sealed signature text matches modulo its final newline, explaining its different file-byte digest. The seal binds the actual StatementProbe raw source and retained .olean, helper raw source and .olean, and the already reviewed design version. It states STATEMENT_SEALED_NOT_PROVED and does not self-grant a Proof Seal. The sealed outcome binder is labeled TYPING, whereas my earlier source review called the outcome value SOURCE; both have exactly m:Fin2 and no logical correctness hypothesis, so no mathematical premise changed.

## Actual compile and import receipts

| Stage | Directly checked evidence | Honest capability and limit |
| --- | --- | --- |
| C105 attempt2 | Helper source26d7ed…; outputeaf2f23e…; embedded raw stdout/stderr hashes; exit0,27.625seconds | Isolated helper equality/mass compilation receipt under inherited providers; not the operation bridge or a clean dependency rebuild |
| C126 | Raw StatementProbe sourceaaa953…; helper source/output pins; actual seven Prop-valued check outputs; exit0,48.265seconds | Definition/signature elaboration only, not any theorem proof. Its JSON does not itself record its own output .olean hash; retained StatementProbe outputed652f2d… is separately bound by the later Statement Seal |
| C134 integration | Target raw source2f1150…; Statement Seal08934e…; retained target output57045ea1…; actual empty stdout and dirty-Verso stderr hashes; exit0,66.828seconds,no timeout | Positive isolated whole-target compilation receipt for the same source, not merely C126 typing or an author's desired signature |
| C134 actual output audit | RootAudit source41cd61…; same target source/output pins; actual stdout92db0cf1… and stderr448d0b14…; exit0,26.031seconds | Imported-output actual type/axiom audit for all seven public target declarations, not just a source command waiting to run |

Full source/output/log hashes and attribution are in runtime-evidence.json. These are inspected retained observations, not runs performed by this reviewer. A receipt remains evidence of the recorded execution and retained association, not an independent clean-room rebuild or cryptographic execution attestation.

The C105 first attempt also has exit0 with unused/unreachable trailing-ring warnings in its recorded raw stdout. Its source and .olean differ from attempt2 and are not among this packet's three retained binaries/current raw core. I checked its embedded log hashes but cannot independently reconstruct the claimed one-line cleanup from an absent attempt1 source. That limitation does not change the reviewed current helper source.

The integration wrapper asserts three prior failed attempts and a C132 isolated repair source/output plus exact proof-block delta. Those old attempt sources/results, C132 source/binary and delta artifact are not supplied in the authorized51 members. I do not promote those assertions into independently verified repair-history evidence. The final current source, output and actual audit can still be associated directly without pretending that this entire prior history was inspected.

## Actual types and axiom output

The audit source has exactly seven checks and seven axiom-print commands for the seven public OperationBridge declarations. Its raw output contains the actual corresponding types: graph production; J isometry; C isometry; all-carrier X completeness; actual operation-to-helper bridge; exact scaled-J matrix root; finite joint-coordinate half-mass. The displayed parameters and quantification match the unchanged source and my already frozen C138/C140 readings. No normalization, factorizability, desired-action or gate-correctness hypothesis appears in the actual root or bridge.

Every one of these seven actual axiom lines reports exactly propext, Classical.choice and Quot.sound. No sorryAx or native-evaluation axiom is reported for these loaded audited roots. Thus the prior C138/C140 root-axiom uncertainty is now narrowly resolved by actual audit output for this retained module under the recorded import context. The earlier observation that other imported source files contain native_decide remains true, but their mere import does not imply native-axiom dependence of these roots. Conversely this audit does not certify all imported declarations, the entire cache, the compiler executable, or source-to-binary equality for every provider.

The helper attempt2 raw output similarly reports these three axioms for its equality, mass and summed-mass theorems. The source branchScale_normSq and normalized helper corollary are read, but no separate standalone helper axiom line is supplied for those two declarations. The target mass audit covers its actual transitive theorem dependencies as reported by Lean; it is not a declaration-by-declaration global helper/TCB audit.

## Routing, memory, time and provenance

The C126 wrapper requests LEAN_PATH in order helper-stage then definition-stage. C134 integration and its output audit request helper-stage, definition-stage, then integration-stage. Compilation supplies an explicit source path, --root for its isolated stage, output path for its own .olean, -M3072 and -j1, with repository cwd and lake env lean. The output audit supplies RootAudit source explicitly and imports OperationBridge with the same requested stage list. It verifies the retained target source/output hashes before launching the import audit. This is consistent with auditing the successful own target, not one of the earlier failed-attempt directories.

However, the effective environment after lake env augmentation, resolver trace, executed Lean/Lake executable bytes, and hashes of every loaded provider .olean are not supplied. The wrappers request a path order; they do not prove the complete runtime resolver order. Neither C134 wrapper rehashes the helper/definition binaries immediately around every import. C126 verifies the helper pins before launch and four repository context sources before/after, but does not create a complete import-load transcript. These are transitive provenance limits, not an observed conflicting import. Matching current retained stage binaries and sealed hashes does not alone rule out every load-time race or cache mismatch.

The wrappers use a prelaunch available-memory check of at least5120MiB, with a3072MiB Lean command cap and an intended2048MiB margin; one Lean thread is requested. This is not an OS memory reservation or process-tree enforcement. Recorded available memory is7643MiB for C126,7299MiB for C134 compile,7579MiB for C134 audit; helper attempt2 records6397MiB. Observed wall times include subprocess/Lake overhead and are not quantum-circuit depth, gate complexity or proof-term elaboration-only timing. The timeout parameter is180seconds. Successful receipts have returned normally; no process-tree timeout-cleanup behavior is validated. C105 command routing itself is not supplied as a wrapper here, so its memory/thread fields are receipt observations rather than independently inspected launch code.

Every supplied stderr channel retains the warning that the Verso dependency checkout has local changes. The warning is not silently removed or reclassified as a theorem counterexample. It prevents describing this environment as clean and reproducibly rebuilt from the pinned manifest alone. The C105 summary records an observed Lean4.33.0 release/version/commit string; no executable hash or independent version-command raw transcript is supplied here. Toolchain text, package revisions and four source-context hashes are useful pins but not a clean transitive source-to-binary certificate.

## True current mathematical capability

The evidence supports a locally compiled, imported-output-audited, exact ideal finite-linear branch bridge for actual CCX on zero target with identity use only, under inherited provider/cache context. For both outcomes m,

    J C_m X_m U J = (sqrt(2)/2) J,

with arbitrary complex retained coefficients/reference slices and a finite half-mass corollary, together with the three all-carrier operation validations. The direct actual PrimitiveProgram supplier is ONLY U, the CCX prefix. J, X_m and C_m remain literal mathematical matrices, not a supplied adaptive measurement/reset/correction program. Package AND tails remain all required despite not all being direct root proof calls.

This is an unnormalized linear branch identity, not a normalized conditional-state map or a physical measurement theorem. Complete-family algebra does not generate random outcomes or reset discarded hardware. No nonidentity-use invariant, dirty-target cleanup, generic-f compiler, physical readout/control/reset, Born interpreter, resource/precision/noise certificate, full repository/tests/docs/publication gate, production canonicalization, source-registry admission or SP/BE scientific root follows from exit0. No production file or earlier evidence was changed. Stop before any final admission step.
