# C145 phase-1 freeze: actual C23 cache consumption in the C22 chain

Status: DESIGN_ONLY / STATEMENT_SEAL_PENDING. No Lean source, proof search,
compiler, supplied script, network, Git operation, or finite computation was
run. Nothing here is proved, compiled, accepted, published, or root closure.

Direction fingerprint: `C145_ACTUAL_C23_CACHE_CONSUMPTION_IN_C22_SAME_CHAIN`.
Original scientific target: `SP-HERMITE-POLY-002`, the original normalized,
little-endian Hermite state. The exact-real circuit frontier is inherited as
closed from the parent packet, not reverified here. Full finite-bit classical
extraction and executable/scientific ROOT remain OPEN.

## 1. Decision and actual mathematical delta proposed

Use the existing C23 rational source cache, not a second source-coefficient
producer and not the positive Bernstein compiler. Materialize the signed C21
monomial middle coefficients once, by charged reads of the returned C23 vector.
Read this middle vector in the actual right-boundary collection feeding C22.
Keep every local kernel, left boundary, finite-index reindexing, rational-to-real
cast, and canonical stored-chain assembly on the existing object.

The raw source identifies the exact repeated work:

`sourceCoefficientQ -> middleCoeffQ -> middleQ.right -> actualBlocksQ.right
-> produceQData.right -> castData -> ofTable`.

`sourceCoefficientQ` is not used by `actualBlocksQ.kernel` or `.left`.
Capturing one `actualBlocksQ` record, as C22 already does, does not cache any
coefficient values: the `.right` function still evaluates `middleCoeffQ`.
There are nine middle-component boundary addresses per coefficient. A source
coefficient also occurs repeatedly across different coefficient sums. The
proposed run calls `produceSourceCache k` once, builds one middle vector, and
performs a charged stored read at each middle boundary address. It does not
claim an exact physical call-count reduction from the Lean evaluator.

This is a dependency-ready implementation design, not a wrapper around the old
`produceQData`. The new run must actually collect new tables/boundaries; the old
producer appears only in the value-refinement specification.

## 2. Source construction, reconstructed before reading the review

Let `W=k+1`, `d=sourceDegree delta`, `T=tailCutoff delta`,
`D=assemblySize k delta=18*(d+1)+9*(2*k+2)+18`.

The actual rational function is
`piecewiseValue k delta p`: negative finite-exponential midpoint for `p < -1`,
the C21 rational middle for `-1 <= p <= 0`, and the reflected negative midpoint
for `p > 0`. The five-component decomposition uses:

- A: strict `p < -1`; B: inclusive `p <= 0`;
- C: inclusive `p <= -T`; D-mask: inclusive `T <= p`;
- clipped constant, negative tail polynomial, signed monomial middle,
  clipped constant, reflected tail polynomial, in that exact sum order.

The positive cutoff uses the complement of `strictCut ... T`, not an
inclusive-cut replacement. The little-endian grid and bit progression remain
`rationalGrid n R (wordIndex n x)` and `q=0,...,n`. The flattening remains
`finProdFinEquiv (bit,column)`, not `(column,bit)`.

For a stored vector `a : Vector Rat W` and scalar `e : Rat`, the middle
coefficient at `j : Fin (2*k+2)` is literally

```
sum i : Fin W,
  if W <= j.val then e*a[i.val]*(-1)^W*choose(i.val,j.val-W) else 0
+ sum i : Fin W,
  if i.val <= j.val then a[i.val]*(-1)^i.val*choose(W,j.val-i.val) else 0.
```

This is a specification, not an executable use of `Nat.choose`. At
`a=(produceSourceCache k).value` and `e=expMidpoint delta`, it is exactly
`middleCoeffQ k delta j.val`. It is not a Bernstein coefficient and may be
negative. Out-of-range binomials equal zero. Their explicit zero branches are
necessary; `chooseFrom` may not be called with a false range proof.

Source topology (not a Lean dependency claim): finite rational exponential
supplier + source coefficients -> C21 signed middle -> five exact masks and
polynomials -> physical-grid amplitudes -> existing normalized-source bridge.
The new cache implementation is an alternative supplier for one node of this
same construction, not a new quantum state or a change to its normalization.
Normalization/error/circuit material is excluded from this narrow proof target
because it is unchanged; it remains an AND-tail of the scientific ROOT.

## 3. Exact executable plan, no arbitrary callbacks declared free

Proposed namespace: `HermiteCachedPiecewiseStored`.
Suggested new modules: `CachedMiddle.lean`, `CachedRightSetup.lean`,
`CachedStoredProducer.lean`. They are proposals only and have not been created.

### 3.1 Reusable charged middle supplier

`middleFromCache k e a : Run (Vector Rat (2*k+2))`:

1. Generate a factorial table through `2*k+1` using the existing rational
   `HermiteChargedSourceCache.factorials`. This is a second **factorial** setup
   pass, counted explicitly, not another source-coefficient producer. C23's
   output deliberately does not return its internal factorial vector. Avoid
   changing frozen C23 merely to recover it.
2. Compute `sigma=(-1)^W` by a new charged multiplication recurrence `powQ`.
3. Materialize two vectors: `u_i=e*a_i*sigma` and `v_i=a_i*(-1)^i`. Each input
   read, multiplication, power recurrence step and collection pass is charged.
   Use two scalar vectors, not a pair treated as a single scalar word.
4. For each `j`, sum the first vector times `choose(i,j-W)` and the second
   vector times `choose(W,j-i)`. Use the existing `chooseFrom` on the actual
   generated factorial table. Charge two comparisons per summand even for a
   zero branch. Guard `W<=j && j-W<=i` in the first term and
   `i<=j && j-i<=W` in the second. The original formulas are recovered using
   the zero-binomial theorem outside these guards.
5. Use the existing rational `sumEntries`; its addition to zero is charged.
   Charge the final addition between the two sums and all materialization.

No public correctness premise about `a` is required: the generic value theorem
states the expression above for arbitrary input data. The actual source-cache
specialization must obtain every coefficient equality from
`produceSourceCache_entry`; it may not assume cache correctness.

Conservative proposed bound: `total (middleFromCache k e a).cost <= 400*W^2`.
Manual operation audit, not a checked theorem: factorial setup <= `320*W^2`
by eight times the current per-category factorial bound; the two weighted
vectors including the sign recurrence <= `14*W^2`; middle entries including
two comparisons per term and materialization <= `50*W^2`. Total <= `384*W^2`,
leaving slack to 400. If proof/implementation changes invalidate this audit,
revise the candidate bound and seal; do not quietly assert it.

### 3.2 Explicit source-independent setup, not an exp oracle

To avoid hiding midpoint and boundary setup, require a concrete
`rightSetup n R delta : Run (RightSetup n R delta)` before the actual-chain
integration theorem. `RightSetup` is data only:

```
structure RightSetup (n : Nat) (R delta : Rat) where
  cutMinusOne : Nat
  cutZero : Nat
  cutMinusT : Nat
  cutT : Nat
  tailCoeffs : Vector Rat (sourceDegree delta+1)
  clipped : Rat
  midpoint : Rat
```

No proof fields, arbitrary callbacks, cached cost assumptions, normalization,
positivity, or desired-output witness are fields of this structure.

Frozen implementation requirements:

- Compute `q=1/delta` by `qDiv`, then the literal
  `T=Nat.clog 2 (max 1 (Nat.ceil q))`; compute the literal degree from T.
- Compute grid step once using charged `powQ 2 (n+1)`, multiply and divide.
  Compute the four literal cuts with charged rational addition/division and
  comparisons, then the original min/ceil/floor rules. Retain truncation at
  zero and at `2^(n+1)` exactly, including `R=0` in the generic value contract.
- Generate the rational factorial table through `d` using C23 `factorials`;
  materialize `tailCoeffs_i=1/i!` using charged reads/divisions.
- Compute `clipped=1/2^T/2` by charged power/divisions.
- Compute midpoint by the exact `bounds (-1) T d` dispatch: if `T<=1`, return
  the already computed clipped scalar; otherwise return the finite rational
  sum `sum i=0..d, (-1)^i/i!`, using the returned factorial table, charged
  powers/reads/divisions/additions. The active radius cancels in the midpoint;
  this algebraic simplification needs a value theorem, not a new assumption.
  It is valid for all rational delta, not only positive delta.

The resulting setup cost is retained as the exact expression
`total (rightSetup n R delta).cost` in the first final bound. It is not zero,
not a supplied premise, not absorbed into the C23 bound, and not yet promised
polynomial in bit input size. This keeps the phase-2 integration target small
without pretending it closes the last complete runtime obligation.

`Nat.ceil`, `Nat.floor`, `Nat.clog`, natural casts/large integer arithmetic and
all loop-index/control work are explicit residual machine-cost operations.
Their evaluation is not certified O(1) by this scalar/word ledger. In
particular, hiding `ceil(1/delta)` under an index-arithmetic slogan is forbidden.

### 3.3 Actual right table; no invocation of the old right callback

`rightEntry k n R delta setup middle z : Run Rat`, where
`z : FullIndex k delta`, dispatches by the five sum constructors. Each branch
evaluates exactly its two threshold accept factors, obtains its constant or
stored tail/middle scalar, and performs the two charged multiplications.

Implement `acceptRun width cut a flip` with up to three explicitly charged
comparisons for `cut=0`, `cut=2^width`, `a=0`, and a charged subtraction for
flipped acceptance. Ordinary zero/one literal returns and fixed record
projections may be pure; evaluating any old scalar callback may not.

The middle branch is exactly `.inr (.inr (.inl (a,(b,j))))`. It uses the
complement of strict-minus-one at `a`, inclusive-zero at `b`, and
`StoredGivens.read middle j`. Tail branches read `setup.tailCoeffs`; clipped
branches use `setup.clipped`. The positive clipped branch uses flipped
strict-T, and its active complement uses unflipped strict-T. Reproduce the
original nested sum order. Every branch has total charged entry cost <= 11:
two acceptors (<=6 compare + <=2 field), <=1 scalar read, two field products.
Sum-constructor dispatch/fixed projections are index/control work, not a new
free arithmetic callback.

### 3.4 One actual producer and actual returned dataflow

`produceCachedQData` must execute, in order:

```
cache <- produceSourceCache k
setup <- rightSetup n R delta
middle <- middleFromCache k setup.midpoint cache
tables <- collect q / collect a / collect j
            (the same original actualBlocksQ.kernel and fullEquiv indices)
left <- collect a (the same original actualBlocksQ.left and fullEquiv index)
right <- collect a (rightEntry ... setup middle ((fullEquiv k delta).symm a))
return the existing RationalData record
```

The old kernel/left callbacks remain **UNACCOUNTED scalar evaluation**, just
as in C22; their `pure` is storage-ledger syntax, never an O(1) claim. They do
not call source coefficients. No right callback from `actualBlocksQ` is executed
by this new program. `actualBlocksQ.right` is specification-only.

`produceCachedData` binds this returned `RationalData` to existing `castData`.
`produceCachedStored` binds that returned `RealData` to existing
`StoredMatrixProductChain.ofTable`. Do not separately rerun the old producer
for correctness, or use old tables with a cost-only dummy cache call.

## 4. Exact proposed statements and admissible binder boundary

See `statements.lean.txt` for the frozen candidate declarations without proof
bodies. All names there are proposals except explicitly imported existing
names. Before proof, the parent must type-probe definitions/signatures, bind
the exact source text/import providers, review this audit, and issue a
StatementSeal. Any signature or executable-body change invalidates that
candidate seal scope.

Binder audit:

- `k,n : Nat`, finite indices/words, `R,delta : Rat`: TYPING carrier and
  construction parameters. Source amplitude theorem's `hR : 0<R` is SOURCE,
  exactly as C21/C22; not added to value-refinement/cost roots.
- Generic `e,a,F` helper data: TYPING for internal providers only. `F`-correct
  premise of existing `chooseFrom_value` is discharged using the actual
  generated factorials; it is not exposed by any new source-facing root.
- `op : Op`: TYPING in internal counter roots; total is the fixed eight-field
  sum, not a free user cost function.
- No `correct cache`, midpoint equality, `Window`, resource bound, oracle,
  coefficient sign/nonzero, `delta>0`, `k>0`, rank or normalization premise is
  allowed on the public integration statements. These would be EXCESS.
- Existing `ofTable_refines` takes `Window`; the producer must prove that
  finite-window property internally from actual table entries, not ask for it.
- Source physical register state, global/relative phase, clean ancilla and
  approximation contracts are unchanged downstream; no new premise or claim
  about them is introduced here. Rational same-data equality alone is not a
  theorem about an emitted finite-bit quantum circuit.

Definition audit: all new definitions are literal deterministic rational
algorithms and stored arrays. Midpoint's active simplification is characterized
by a proved equality to the literal finite formula; it is not classical choice.
There is no quotient, representative selection or off-source zero fallback.
Guarded out-of-range binomial zero equals the original formula on its full
carrier and is not an invented default. Zero denominator behavior for arbitrary
input `R,delta` follows Lean's literal rational division; actual factorial
denominators are nonzero by generated-table positivity, with no assumption.

## 5. Reused exact interfaces, imports and provider requirements

Root imports for `CachedStoredProducer`: `StoredProducer`, `AccountedTraffic`,
`CacheConsumerChecks`, and the two new local modules. `CachedMiddle` imports
`ChargedSourceCache` and `ActualCoefficients`. `CachedRightSetup` imports
`RationalBlocks`, `ChargedSourceCache`, and the finite-exp sources already
reached through those imports. Existing production interfaces must not be
redefined. Full relevant signatures are in `interfaces.md`.

Provider resolution is a separate gate. Short experiment modules are not
production namespace modules. The parent must supply exact C19/C20/C21/C22/C23
and finite-exp/middle provider directories, with new private outputs ahead of
any inherited olean cache, and inspect actual `--deps` selections. Distinct
`sumEntries`, `factorials`, `read`, `chooseFrom` namespaces must be qualified.
Do not import the review consumer as a substitute for the raw C23 provider.
No current compiled provider has been selected or verified by this phase.

Reuse justification: C23 supplies exact rational source values and arithmetic;
`StoredHermiteCoefficients` supplies a reviewed design pattern and real-source
bridge only. Its Bernstein `compile` has a different output and separately
counted exponential, so it is not an eligible replacement. No new quantum
foundation, semantic state, or parallel coefficient API is proposed.

## 6. Cost model and exact remaining frontier

Proposed combined bound, on the same `produceCachedStored` run:

```
816*(k+1)^2 + total (rightSetup n R delta).cost
+ 11*D + 9*passContainers n D
+ 20*D^2 + 30*D + 5*n^2 + 7*n + 31.
```

416 is the existing C23 total bound; 400 is the new proposed middle bound.
`11*D` is the new right-entry work excluding collection overhead. The original
four collection ticks per container and five cast ticks give `9*passContainers`.
The last line is the existing actual canonical-assembly bound. All factorial,
binomial, source read, signed-power and middle-sum costs remain in the actual
middle run; all midpoint/tail/cut rational setup costs remain in the explicit
setup term. This is a **partial accounted scalar/word bound**, not a bound on
the evaluation cost of its own counter function.

Still unaccounted/open: translation-core scalar generation, all old kernel and
left-boundary scalar work, arbitrary-precision natural operations and rational
conversions/floor/ceil/log; rational numerator/denominator bitlength, GCD,
allocation/compiler evaluator/runtime; full extraction bit complexity; numerical
rounding/normalization and sequential preparation error; saved-circuit target
replay at the full required range. Existing `sourceDegree_size` is a parameter
bound, not a certificate that any of these operations is free or fast.

If the parent wants only the smallest first checkpoint, seal and implement
`middleFromCache` plus its actual-cache specialization first. That is a genuine
charged source-to-middle bridge, but it must be called an internal prerequisite,
not “C22 integrated.” Actual C22 integration requires the concrete setup and
five-branch right supplier above, not an arbitrary supplier hypothesis. Do not
weaken the final target to force this smaller checkpoint to count as integration.

## 7. Evidence layers, review and test plan

Raw source analysis preceded review intake. Afterwards the independent C23
review was read: it accepts only its bounded cache/charged-read contract and
explicitly says C22 has not been changed. Its `lookup_same_object` charges a
read of the returned cache, but rebuilding that `lookup` inside every middle
term would rebuild the entire cache. Reuse its pattern with one outer bind,
not its executable `lookup` as the inner supplier.

Source/Lean graph distinction: the source construction above is an authored
dependency sketch. Candidate Lean edges are `produceSourceCache_entry` and
`factorials_value/chooseFrom_value` -> middle value; setup value + middle value
-> right value; table/left/right value -> same RationalData -> cast window ->
`ofTable_refines` -> actualChain. Cost edges use collect/bind costs separately.
There is no current compiler-backed new edge, elaborated proof-term graph,
source-blind reconstruction, independent C145 review or Exposition Seal.

Parent-owned sequence after design approval:

1. New temporary signature/definition probe only; record exact Lean 4.33.0,
   manifest, source hashes and actual imported providers. No proof search until
   the exact Anchor/internal-provider contracts are frozen.
2. Parent-reviewed StatementSeal; if the candidate bound or setup is amended,
   version the seal before proving. No handy extra hypothesis.
3. Focused ordinary-kernel value/cost proofs and axiom inspection; retain failed
   sources/logs. Prove full `j` range and all five boundary branches.
4. Check finite fixtures only as supporting evidence: k=0, k=1, a signed middle
   example, both binomial zero guards, j=0/k/k+1/2k+1, R=0 generic equality,
   n=0 one-core assembly, T=0/T=1/active midpoint, cut=0/2^width/interior,
   both endpoint equalities -T/-1/0/T and reflected tails. Suggested exact
   middle fixtures with e=1/3: k=0 gives [1,2/3]; k=1 gives
   [1,-1,-11/3,-2]. These are manual expected fixtures, not executed results.
5. Fresh independent implementation/cost consumer tests the actual returned
   QData and StoredChain, not the joined author certificate. Review common
   blind spots: natural subtraction, signed coefficients, one outer cache bind,
   +1 read, boundary complements, n=0, setup omissions and finite-bit drift.
6. Parent serializes `lake build && lake build Tests`, then required publication
   and site gates only for a stable admission candidate. Source-blind decoder,
   distinct reviewer, publication binding and purification remain mandatory
   for a source-facing promotion. No skipped gate is treated as green.

## 8. Structured substantive-worker handoff

Objective/frontier: remove repeated actual C21 source-series evaluation from
the actual C22 supplier by consuming the one C23 returned cache throughout the
middle/right dataflow. Delta this phase: precise location of repeated work,
same-data integration algorithm, explicit charged middle provider, exact
candidate signatures and residual cost boundary. Implementation delta is zero.

Assumptions/conventions: original degree/radius/grid/cuts/five-component order,
signed monomials, all natural k,n including zero; hR only for physical-grid
amplitude interpretation. No additional quantum representation or hypothesis.

Files changed: only new files in this design directory. No historical artifact
or failure was modified. Input hashes/read extents are in `input-manifest.json`.

Reusable insight: only right-boundary coefficients need cache consumption;
kernel/left cache rewriting is unnecessary and would enlarge the proof surface.
C23 does not export factorials, so a counted second factorial pass is safer
than mutating frozen C23 or treating arbitrary binomial evaluation as free.

Failure class: NONE for the mathematical design. Two tooling incidents are
preserved here: an attempted read of `ActualDecomposition.lean` under C21 found
no file; import retrieval corrected to the actual producer directory. A
read-only PowerShell hash command failed parsing a pipe after a foreach block;
the corrected collection-then-JSON command succeeded. They were retrieval/
metadata implementation failures, not counterexamples or Lean failures.

Salvage: preserve the old C22 producer as correctness baseline and C23 reviewed
cache unchanged. No discarded mathematics, no cleanup or compiled fragment.

Process-memory IDs: `QBE-PM-LOW-TOKEN-CONTROL-PLANE`,
`QBE-PM-VERIFIER-SEMANTIC-LEVEL`; finite-verifier entries were read as part of
the small entire curated file but not used to supply mathematics. No subagent,
unbounded history ingestion or provided script execution.

Parallel admission: parent supplied this distinct mathematical integration
uncertainty, complementary to publication/runtime review. No child agents.
Common-blind-spot audit is pending, not replaced by this author's analysis.

Default verified route/comparator: unchanged C22 remains the inherited baseline;
the cache route is unverified and not selected as a verified default. No claim
of superiority in physical runtime or formalization efficiency.

Purification/Exposition Seal: NOT_STARTED. Pending genuine-consumer, duplicate
API, import-minimization and graph audits after compilation/integration.

Residual risk/confidence: high confidence in the raw source-dependent slice and
exact same-object goal; moderate confidence in proposed setup/400/11 constants
until the parent type probe and independent arithmetic audit. No Lean API or
elaboration success is asserted. Strongest dependency-ready salvage is the
generic charged middle provider plus actual-cache specialization, explicitly
short of actual C22 integration.

Recommended next action: parent reviews this freeze, chooses whole integration
or prerequisite-first checkpoint, executes the type-only probe, supplies exact
provider bindings and approves a versioned StatementSeal. Worker stops here.
