# Existing names and full relevant interfaces

These are source-transcribed types, not compiler output from this run.
Short module names below refer to experiment provider directories; namespace
names are exact. Implementation bodies/axioms were read, not merely searched.

## C23: import ChargedSourceCache / CacheConsumerChecks

Namespace `HermiteChargedSourceCache`:

```
qAdd (x y : Rat) : StoredGivens.Run Rat
qMul (x y : Rat) : StoredGivens.Run Rat
qDiv (x y : Rat) : StoredGivens.Run Rat
factorials (n : Nat) : StoredGivens.Run (FactorialTable n)
FactorialTable.values : Vector Rat (n+1)
FactorialTable.next : Rat
factorials_value (n : Nat) (i : Fin (n+1)) :
  (factorials n).value.values[i.val] = (i.val.factorial : Rat)
factorials_cost_le (n : Nat) (op : StoredGivens.Op) :
  (factorials n).cost op <= 10*(n+1)^2
chooseFrom {N : Nat} (F : Vector Rat (N+1)) (n r : Nat)
  (hr : r <= n) (hn : n <= N) : StoredGivens.Run Rat
chooseFrom_value {N : Nat} (F : Vector Rat (N+1))
  (correct : forall i : Fin (N+1), F[i.val] = (i.val.factorial : Rat))
  (n r : Nat) (hr : r <= n) (hn : n <= N) :
  (chooseFrom F n r hr hn).value = (n.choose r : Rat)
chooseFrom_cost {N : Nat} (F : Vector Rat (N+1)) (n r : Nat)
  (hr : r <= n) (hn : n <= N) (op : StoredGivens.Op) :
  (chooseFrom F n r hr hn).cost op =
    3*StoredGivens.tick .read op+2*StoredGivens.tick .field op
sumEntries : {n : Nat} -> (Fin n -> StoredGivens.Run Rat) -> StoredGivens.Run Rat
sumEntries_value {n : Nat} (f : Fin n -> StoredGivens.Run Rat) :
  (sumEntries f).value = sum i, (f i).value
produceSourceCache (k : Nat) : StoredGivens.Run (Vector Rat (k+1))
produceSourceCache_entry (k : Nat) (i : Fin (k+1)) :
  (produceSourceCache k).value[i.val] = HermitePiecewiseAssembly.sourceCoefficientQ k i.val
produceSourceCache_cost_le (k : Nat) (op : StoredGivens.Op) :
  (produceSourceCache k).cost op <= 52*(k+1)^2
produceSourceCache_actual (k : Nat) (i : Fin (k+1)) :
  (produceSourceCache k).value[i.val] = HermiteFiniteMiddleSource.coefficientQ k i.val
produceSourceCache_total_le (k : Nat) :
  StoredRectangularGivens.total (produceSourceCache k).cost <= 416*(k+1)^2
```

All bare `StoredGivens`/`StoredRectangularGivens` above are under
`QuantumBlockEncoding`. Existing helper `correct`, `hr`, `hn` are genuinely
required by those helpers; new actual producers discharge them internally.
The review's `C23InternalReview.lookup_same_object` is evidence of an actual
charged lookup pattern, not an intended runtime inner loop or imported proof.

## C21 and finite-middle: ActualCoefficients / ActualAssembly

Namespace `HermitePiecewiseAssembly`:

```
sourceCoefficientQ (k i : Nat) : Rat
sourceCoefficientQ_eq (k i : Nat) (hi : i <= k) :
  sourceCoefficientQ k i = HermiteFiniteMiddleSource.coefficientQ k i
middleCoeffQ (k : Nat) (delta : Rat) (j : Nat) : Rat
middleCoeffQ_eval (k : Nat) (delta p : Rat) :
  (sum j : Fin (2*k+1+1), middleCoeffQ k delta j.val*p^j.val) =
    HermiteFiniteMiddleSource.middleValueQ k delta p
componentSize (d : Nat) : Nat
ComponentIndex (d : Nat) := Fin 3 * (Fin 3 * Fin (d+1))
FullIndex (k : Nat) (delta : Rat) :=
  ComponentIndex 0 + (ComponentIndex (sourceDegree delta) +
    (ComponentIndex (2*k+1) + (ComponentIndex 0 + ComponentIndex (sourceDegree delta))))
assemblySize (k : Nat) (delta : Rat) : Nat
fullEquiv (k : Nat) (delta : Rat) : FullIndex k delta ≃ Fin (assemblySize k delta)
actualBlocks (k n : Nat) (R delta : Rat) : Block (FullIndex k delta)
actualChain (k n : Nat) (R delta : Rat) : TensorTrainCanonical.Chain (n+1) 1 1
actualChain_contract (k n : Nat) (R delta : Rat) (hR : 0<R)
  (x : TensorTrainCanonical.Word (n+1)) :
  TensorTrainCanonical.contract (actualChain k n R delta) x 0 0 =
    (HermitePiecewiseSourceBudget.piecewiseValue k delta
      (HermitePiecewiseSourceBudget.rationalGrid n R (wordIndex n x)) : Real)
```

`+` between types above denotes the existing nested `Sum`, not a new
arithmetic carrier; `*` between types denotes `Prod`. `sourceDegree` is
`HermiteFiniteExpDegree.sourceDegree`. C21 `Block` contains a real-valued
kernel and two real boundary functions, with no proof fields. The rational
`BlockQ` analog below has the same data-only shape.

## C22: RationalBlocks / StoredProducer / AccountedTraffic

Namespace `HermitePiecewiseStored`:

```
structure BlockQ (alpha : Type) where
  kernel : Nat -> Fin 2 -> alpha -> alpha -> Rat
  left : alpha -> Rat
  right : alpha -> Rat
actualBlocksQ (k n : Nat) (R delta : Rat) : BlockQ (FullIndex k delta)
actualBlocksQ_cast (k n : Nat) (R delta : Rat) :
  (actualBlocksQ k n R delta).cast = HermitePiecewiseAssembly.actualBlocks k n R delta
abbrev RationalCore (D : Nat) := Vector (Vector Rat (2*D)) D
structure RationalData (n D : Nat) where
  tables : Vector (RationalCore D) (n+1)
  left : Vector Rat D
  right : Vector Rat D
produceQData (k n : Nat) (R delta : Rat) :
  StoredGivens.Run (RationalData n (assemblySize k delta))
structure RealData (n D : Nat) where
  tables : Vector (StoredTensorTrain.StoredCore D D) (n+1)
  left : Vector Real D
  right : Vector Real D
castData {n D : Nat} (data : RationalData n D) : StoredGivens.Run (RealData n D)
castData_entry {n D : Nat} (data : RationalData n D) (q : Fin (n+1))
  (a : Fin D) (j : Fin (2*D)) :
  (castData data).value.tables[q.val][a.val][j.val] =
    (data.tables[q.val][a.val][j.val] : Real)
produceStored (k n : Nat) (R delta : Rat) :
  StoredGivens.Run (StoredTensorTrain.StoredChain (n+1) 1 1)
produceStored_refines (k n : Nat) (R delta : Rat) :
  StoredTensorTrain.denoteChain (produceStored k n R delta).value = actualChain k n R delta
passContainers (n D : Nat) : Nat := (n+1)*(2*D^2+D+1)+2*D
castData_traffic {n D : Nat} (data : RationalData n D) (op : StoredGivens.Op) :
  (castData data).cost op =
    passContainers n D*(3*StoredGivens.tick .read op+2*StoredGivens.tick .write op)
```

`produceQData_entry/left/right`, `produceData_window/left/right` and
`actualEntryQ_cast/actualLeftQ_cast/actualRightQ_cast` were read in full and
are the existing entrywise transport templates; the intended new value equality
allows their exact use without defining another semantic state.

## Canonical production: QuantumBlockEncoding.StoredGivens

```
inductive Op where | field | sqrt | angle | trig | compare | read | write | emit
abbrev Cost := Op -> Nat
tick (op : Op) : Cost
structure Run (alpha : Type) where
  value : alpha
  cost : Cost
Run.pure (x : alpha) : Run alpha := <x,0>
Run.bind (x : Run alpha) (f : alpha -> Run beta) : Run beta
  -- actual cost is x.cost + (f x.value).cost
charge (op : Op) (x : alpha) : Run alpha
read {n : Nat} (xs : Vector alpha n) (i : Fin n) : Run alpha
collect {n : Nat} (f : Fin n -> Run alpha) : Run (Vector alpha n)
collect_value {n : Nat} (f : Fin n -> Run alpha) (i : Fin n) :
  (collect f).value[i.val] = (f i).value
collect_cost {n : Nat} (f : Fin n -> Run alpha) (op : Op) :
  (collect f).cost op = (sum i : Fin n, (f i).cost op)+
    n*(2*tick .read op+2*tick .write op)
```

`Run`, `Cost`, `RationalData`, `RealData`, `BlockQ` are data, not contract Props;
there are no hidden correctness premises to inherit by accepting these types.
`read` is one .read; `collect` uses two actual materialized passes and charges
the full four storage ticks. Neither proves a callback's unannotated work free.

## Canonical production: stored chain

Namespace `QuantumBlockEncoding.StoredTensorTrain`:

```
StoredCore (l r : Nat) := Vector (Vector Real (2*r)) l
denoteCore {l r : Nat} (A : StoredCore l r) : TensorTrainCanonical.Core l r
StoredChain : Nat -> Nat -> Nat -> Type
  -- nil r : StoredChain 0 r r
  -- cons : StoredCore l m -> StoredChain n m r -> StoredChain (n+1) l r
denoteChain : {n l r : Nat} -> StoredChain n l r -> TensorTrainCanonical.Chain n l r
```

Namespace `QuantumBlockEncoding.StoredRectangularGivens`:

```
total (cost : StoredGivens.Cost) : Nat :=
  cost .field+cost .sqrt+cost .angle+cost .trig+
    cost .compare+cost .read+cost .write+cost .emit
```

Namespace `QuantumBlockEncoding.StoredMatrixProductChain`:

```
ofTable {n D : Nat} (tables : Vector (StoredTensorTrain.StoredCore D D) (n+1))
  (left right : Vector Real D) : StoredGivens.Run (StoredTensorTrain.StoredChain (n+1) 1 1)
Window {n D : Nat} (tables : Vector (StoredTensorTrain.StoredCore D D) (n+1))
  (K : MatrixProductChain.Kernel D) (start : Nat) : Prop :=
  forall i : Fin (n+1), StoredTensorTrain.denoteCore tables[i.val] =
    fun a out => K (start+i.val) out.1 a out.2
ofTable_refines {n D : Nat} (tables : Vector (StoredTensorTrain.StoredCore D D) (n+1))
  (left right : Vector Real D) (K : MatrixProductChain.Kernel D) (start : Nat)
  (h : Window tables K start) :
  StoredTensorTrain.denoteChain (ofTable tables left right).value =
    MatrixProductChain.ofKernel K (fun i => left[i.val]) (fun i => right[i.val]) start n
ofTable_total_cost_le {n D : Nat} (tables : Vector (StoredTensorTrain.StoredCore D D) (n+1))
  (left right : Vector Real D) :
  StoredRectangularGivens.total (ofTable tables left right).cost <=
    20*D^2+30*D+5*n^2+7*n+31
```

`MatrixProductChain.Kernel D = Nat -> Fin 2 -> Matrix (Fin D) (Fin D) Real`.
`Window` is fully expanded above; it must be produced, never publicly assumed.
The direct sum/product `fullEquiv` and all cast functions retain physical bit
order. No implicit invertibility, positivity, rank, ancilla or normalization
contract hides inside these records.
