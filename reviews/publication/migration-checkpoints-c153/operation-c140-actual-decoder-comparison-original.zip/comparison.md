# C140 actual decoder comparison

Reviewer: temporary_and_operation_statement_review_c120.
Stage: after immutable C138 own-formal reconstruction, before any runtime/compiler-output exposure.

## Finding

NO_SUBSTANTIVE_MATHEMATICAL_DISAGREEMENT_FOUND between the actual C137 blind formal-only decoder and the unchanged C138 own-formal reconstruction. Both reconstruct the same exact C136 target as an ideal finite-linear, fixed-three-wire, identity-use-only branch composition. This is a comparison finding, not a Proof Seal, successful compilation claim, physical/adaptive/Born/resource certificate, source-circuit admission or scientific SP/BE root closure.

The actual other decoder was supplied by the parent as C137, not substituted by an author's paraphrase. Its manifest SHA-256 is 2d533211f0415dc780e9e9aab222755f495eab490b3f0e4b76d4e85627abcc38 and its seal SHA-256 is a78e29126df28ce366c1c7a8048d07e9645838e1d094f3ebc807963fd9cb6d1a. All fourteen payload byte lengths/hashes were checked. Its three base64 core snapshots restore exactly the C136 bytes, all thirty inventory entries match C136, and its thirty-six lexical declaration headers match the supplied source at their stated positions. Those checks establish artifact association, not theorem acceptance or real-world independence by cryptography alone.

## Exact common mathematics

Let D=Fin2->Fin2 and W=Fin3->Fin2, with retained coordinates 0,1 and target coordinate 2. No Fin8 serialization or integer endianness is assumed. Matrices have output rows and input columns, act on column vectors, and multiply in right-to-left action order. Both readings give

    J : W by D,     zero insertion on the target;
    X_m : D by W,   identity on retained labels times H[m,target];
    C_m : D by D,   diagonal sign -1 exactly for m=a=b=1;
    U : W by W,     actual existing primitiveCCXProgram evaluation at0,1,2.

The exact H entries are s,s,s,-s with s=(sqrt(2)/2:Real) cast to Complex. The i-prefactor in its provider definition is accounted for, not discarded as global phase. m=0 is the plus bra and m=1 the minus bra. The actual CCX graph producer establishes UJ|ab>=|ab,andBit(a,b)>; that graph is not a root hypothesis or a favorable state definition.

Both readings reconstruct the same separate composition theorem to the literal helper and the same selected root

    J C_m X_m U J = s J,  for both m in Fin2.

The root is an 8-by-4 matrix equality with only m as a value binder. Its domain is the whole retained carrier D; target zero is provided by the initial J. It is not an 8-by-8 inverse or reset theorem for an arbitrary dirty work input. Arbitrary complex amplitudes are allowed. The pointwise reference carrier R is arbitrary, while Fintype R appears only in the mass sum. No factorization, normalization, reality, nonzero input, gate-correctness, favorable outcome or already-cleaned-output premise is added.

Both readings separate three all-carrier semantic validations, J^*J=I4, C_m^*C_m=I4, and sum_m X_m^*X_m=I8, from the clean-input restricted branch action. Completeness does not assert that arbitrary full-carrier inputs give a fair coin; half-mass follows for the actual UJ compute path from the branch equality. The actual mass theorem gives the explicit finite normSq output sum equal to inputMass/2. Its inherited function type is not silently called an L2 norm.

The branch is UNNORMALIZED. For normalized finite input its output mass is one half, and only a separate Born/conditioning interpretation would normalize away s. The actual root has not dropped s. Reinserting zero after contraction is a separate isometry J, not a physical reset process, arbitrary partial trace, or measurement-apparatus theorem. Only the CCX prefix is tied here to an actual PrimitiveProgram supplier; the J, X_m and C_m matrices are not supplied compiled reset/measurement/correction programs. The word compiled in theorem names does not change that scope.

No nonidentity use program appears. Neither reading claims arbitrary intervening uses preserve the graph or a wider compiler register action. The optional discard and identity-reference Kronecker corollaries are absent from the minimum target and are not required tails for its selected reset-shaped endpoint.

## Whole-target and assumption comparison

Every one of the nineteen target declarations is compared in declaration-comparison.json: twelve private and seven public, including all private sum/action/scalar helpers and their visible proof roles. The decoder's exact lexical headers agree byte-for-text with the corresponding C136 source headers, and the C138 ledger has the same declaration set and binders.

The six StatementProbe objects are the same literal carrier/program/operation definitions approved in the own source/design phases. The six helper definitions and five helper theorem headers/proofs have the same meanings in both readings. No new target definition, hidden section variable, phase quotient, choice object, restricted-support operation body or correctness-by-definition cycle is reported by either reader. The normalized helper's hypothesis inputMass alpha=1 is contextual only and is not moved into any target theorem.

C137 intentionally makes only formal typing classifications because it had no source statement. C138 also classifies source-facing data/outcome parameters against its prior source-only scope. That difference of role/labels does not create an extra formal hypothesis, source correction or disagreement. C137 makes no source-admission verdict; only this reviewer performs the later bounded source/design comparison using its own earlier freeze.

## Package AND tails versus actual proof calls

Both readings agree on the actual visible call spine: real CCX evaluation and permutation pullback produce ccx3_mulVec, then UJ graph action; literal J/X/C action plus that graph gives the helper bridge; the bridge plus actual helper phase cancellation and mulVec injectivity gives the selected root; the bridge plus native-coordinate sum and helper mass gives the finite mass consumer.

The J/C isometries and X completeness are independent semantic validation declarations. They are required AND tails for the package to be called a validated ideal operation family, but they are not explicit premises or calls of the root proof. Likewise the mass proof does not explicitly call the matrix root. Neither reconstruction falsely turns every package-acceptance tail into a direct Lean proof dependency, or makes each individual tail sufficient for the whole package. Actual elaborated/tactic-generated dependency extraction remains pending.

The internal MonomialProgram.exact certificate is concretely supplied by its read constructors/sequence proofs, not assumed from a new public root binder. The direct CCX provider is an actual gate-list construction with stored global phase, not a theorem chosen by the desired cleaned output. C137 provides a more explicit printed chronology of the middle T/Tdg/CX sequence than C138's summary; checking it against the already read full provider reveals no conflict.

## Real differences and attribution

There is no material mathematical disagreement to manufacture. The actual differences are limited and preserved:

1. Provider reading ranges differ. C138 read all of PrimitiveSemantics and PrimitiveCircuit and ComplexLCU1-195. C137 reports selected ranges in those modules, while both read the whole PrimitiveMacros, ReversibleClassical, PrimitiveRefinement, target and two immediate ambient files. provider-scope-comparison.json retains both exact range sets. All fifteen decoder provider excerpts match their C136 ranges. A hash over thirty inputs remains byte evidence, not full thirty-file semantic review.
2. C138 performed and reported an additional lexical native_decide import-closure scan. C137 does not claim such a scan or an ordinary-only root axiom set. This is additional unresolved trust information, not a contradiction or a decoder omission that invalidates its formal reconstruction. Neither reader has executed or read actual #print axioms results, and module imports cannot settle root proof-term membership.
3. C137's lexical line_count fields include an extra terminal empty split segment:253/62/69 versus252/61/68 actual numbered content lines in C138. Its prose expressly says plus terminal newline. Exact restored bytes and statement positions agree, so this is a line-count convention, not a missing declaration or changed file.
4. Names in prose differ: C137 uses beta for branchScale and B_m for xBra, C138 uses s and X_m, and the older source-only note uses M_m for the destructive row. The helper symbol T_m in the decoder is not the Toffoli T from the source-only note; U is the actual CCX. All formulas translate exactly.
5. C138 explicitly derives combined L_m=J C_m X_m completeness analytically from three suppliers, while C137 primarily states the three actual supplier declarations. No separate combined-family target theorem is claimed by either reader. This is a presentational addition, not a change in proven declaration inventory.

The first source-only derivation, proposal review, and C138 own-formal reconstruction are not amended to fit these later decoder details. The original C117 exact-API gap and later C125 supplement remain their historical facts; C137 had no access to or obligation to reconstruct that design chronology.

## Stop boundary

This comparison closes only the honest actual-decoder-versus-own-reconstruction comparison step at the static mathematical level. It does not supply compilation, the raw-to-formal runtime association, an ordinary-axiom guarantee, full source-topology closure, physical adaptation, reset hardware, resource accounting, publication admission or SP/BE closure. No C134 or other compiler output, parent verdict/report, new publication entry, additional review, network source, Git command, compiler, provided script or child agent was accessed. Stop here before runtime exposure. Any later authorized gate comparison must be a new artifact, not a rewrite of these freezes.
