# C381 — bounded historical Robin evidence reuse

## Outcome and scope

Scoped historical reuse is supported by the checks below: four original archives, their declared payloads/seal links, and all 11 original production-raw inputs match. This is a NEW bounded association/scope review, not a new whole-module reconstruction or a reissued C98/C104/C121 verdict. The C370 207-file observation does NOT establish Linux-CI raw-byte identity; its EOL boundary requires a separate corrected association. Final registry binding, executable policy, main admission and scientific ROOT are not certified here.

Reviewer: /root/hermite_allocated_degree_c147. Earlier roles include Hermite degree/value/decoder repairs, C311 partial-ledger authorship, C347/C353 suffix proofs, and C320/C330/C334 staged representation review. I did not author the Robin C98/C104/C121/C364 material. This is selective independence, not a fresh universal decoder. C361 remains frozen; C357, C380 policy/code work and other workers' current reviews were not opened. No compiler, Git, network, archived script, extraction or subagent was used.

## Governing boundary

The current publication protocol was read completely after its hash changed to 22daa5905282fbf6172a676cd8d2e0c5c4319c0f041d05a016c4ad61053040b7. AGENTS, HARNESS, substantive-worker skill and the other two protocols were previously read completely and rehashed unchanged. The skill/protocol routes this review to compatibility-only evidence, requires actor/scope preservation and forbids treating old coverage as a new semantic review. The narrow exception is Robin 4.29.1→4.33.0 maintenance, not ordinary source assimilation. Ordinary 50 records and one maintenance record remain separate.

## Original bytes and provenance

| Original archive | Members | Manifest payloads checked | Result |
| --- | ---: | ---: | --- |
| C98 initial, C109 copy | 16 | 14 | all hashes/lengths and exact allowlist match |
| C98 whole continuation, C109 copy | 20 | 18 | all hashes/lengths and exact allowlist match |
| C104 comparison, C130 copy | 23 | 21 | all hashes/lengths and exact allowlist match |
| C121 raw association, C130 copy | 25 | 23 | all hashes/lengths and exact allowlist match |

All 84 members were independently hashed in memory; the 76 noncircular declared payload bindings passed. Four copied public seals equal their archive seal bytes. Predecessor/manifest, decoder/own-identity and comparison/raw-association seal links checked match. Full archive/member hashes and precise read extents are in INPUT_MANIFEST.json. Scripts were inert hashed data, not executed or code-reviewed.

The 11 current raw inputs independently match original-formal-inputs.json production_raw_sha256: RobinMatrix, RobinHeat, GHL2025, CircuitSemantics, BlockEncoding, Circuit, Resources, Core, lean-toolchain, lakefile and lake-manifest. RobinMatrix is 1cca5119ac056fe041b25c529909b9fb6c3e4995e04ebde2f69e83fce47a0835. Raw and comment-masked formal hashes/lengths are distinct; lakefile's 22 CRLF are not silently normalized. These checks were repeated at 2026-10-19T05:40:58.8923786Z, together with governance/archive/stable review inputs: 35 checks, no mismatch. This is byte association, not a fresh mathematical reading of those production files.

The original C98 PARTIAL seal actually records /root/robin_whole_formal_decoder_c98; its whole continuation preserves the predecessor link. C104's own original formal-first seal actually records robin_independent_source_first_c104 (seal ae52f7cbdd26750a10649c1976f977f72b95d892a72368168ccb551555567e5b). C121's seal does not record an actor: UNKNOWN_C121_ACTOR_NOT_RECORDED_IN_SEAL is honest, not a missing name to invent. Historical formalizer remains UNKNOWN; current maintainer /root is a different role. Seal matching does not independently establish human identity or honesty.

## Coverage and mathematical qualifications retained

C98 initial reconstruction/read-coverage is explicitly prefix-only, lines 1–1175, with partially viewed neighbors not credited. Its later whole continuation records full target formal-text coverage (1–26985) and 688 complete commands; those are historical coverage claims, not C381 rereading. Provider coverage remains qualified: six small providers whole, GHL selected ranges, not whole GHL. Alias-shortened displays and neighboring partial ranges do not become additional whole-source coverage.

C98 reconstructs syntax Coeff without quotienting by ring identities; evaluated equalities differ from structural equalities. Obligation records/Bool fields are not discharged mathematical hypotheses. The actual max-row norm and non-modular stencil conventions matter. Cleanup is restricted to clean padding AND slot<7, not full-space unitarity; duplicate slot 7 does not disappear. The prepared object is an 8×8 seven-DIAGONAL compression, not an 8192×8192 lifted two-index sandwich.

The unrestricted old raw-entry/fold equality is refuted (a displayed counterenvironment gives 0 versus 1). This is not a theorem that every repair is impossible. Prepared compression keeps its AND-tail assumptions: all-seven-uniform behavior/HENTRY and the stated inverse/normalization equalities. Full lifted physical operator, adjoint/unitarity, normalized extraction, cleanup and resources remain open.

C104 comparison is retrospective local-source-v2 concordance, not external-paper fidelity or kernel/runtime admission. Its 677 lexical declarations (114 private/563 lexical-public), 69 structures/1950 fields and ambient binder inventory are not 677 separately reconstructed proofs. DC03 preserves fourteen where-constructor/interface overshoots; DC02 does not attribute C104's own provider read to C98. F01 derives only the stated kappa positivity; T02 distinguishes stored normalized factors from actual cosine HENTRY. Its column-collision deduction was uncompiled and is not arbitrary-encoding impossibility.

C121 records eleven raw/formal associations, 1123 comments, 1592 shields and bounded scanner fixtures. Only 159 comments were human-prose reviewed, not all 1123. The context review preserves obligation-record versus proof, provenance versus new conjunct, compressed versus lifted operator, early cleanup versus later producer frontier, and accepted/compiled prose versus actual runtime distinctions. Its scanner is bounded/fail-closed, not a general Lean parser/lexer theorem. C381 did not rerun it or reconstruct the masking transformation.

## Compatibility and recorded runtime

C364 REPORT, freeze and public privacy derivation were read. The sealed report is source-preservation ONLY: seven hunks, six theorem commands, five changed proof bodies plus one scoped elaboration option; headers/other bytes are reported preserved. Net two added native_decide proof sites are disclosed. C381 hashed the exact patch but did not repeat the old/new Git diff, prove proof-term equivalence or review the executable policy.

C364's report and freeze match; the public manifest hash 48ddadd232267d6ad1fa8aba2646647ac97489f05a1f900be9047373e6e27387 matches its privacy derivation. It is NOT the original private manifest a044acd5cdcf7be3d4c076429c434eeb521d66f7c52b8799281ab586b6442017 bound by the original seal. That original hash is preserved; C381 did not independently inspect its bytes. Thus no full private-payload closure is claimed.

The W C370 record and R public copy are byte-identical (842b36e30def4710af9ba410fccefe0160b9a113c6707b1bd8d1ca91b3eeaad2). They report official workflow 39200739299/job 117892996191, merge checkout 3285da3bbf201130502489c5fe8a8a604dc0da86, contribution 7c25a60c313a9c8103bdb14da4a71fc94be71470 and Lean 4.33.0. Selected observations report library/Tests builds, source-trust gate and 15 tests; finite replay explicitly is not a Lean certificate. C381 read the record, not the full 430968-byte CI log, remote job or loader.

At 2026-10-19T05:36:25.4191373Z all 207 listed hashes matched the observed local working-tree files. This is a timestamped mechanical observation only, not semantic reading of 207 files, all 677 declarations, completeness of the repository or raw-byte equality to Linux CI.

IMPORTANT CORRECTION: parent subsequently reports a Git-index raw-byte check found QuantumBlockEncoding.lean had 111 CR and Tests.lean 37 CR in mixed working-tree bytes, whereas their Git blobs were LF. C370's Git-filtered diff equality therefore cannot establish the same 207 raw bytes in Linux CI. C381 did not independently run Git. These two entrypoints are NOT in the historic eleven. Planned LF normalization/new raw map are outside this freeze; no final/current-after-normalization or future binding is certified. The old C370 record is retained as evidence with this explicit limitation, not silently corrected in place.

## Mutable metadata and residual uncertainty

At the timestamp above, maintenance receipts label the three historical artifacts exact-input-reuse and new_review_performed=false, retain original scopes/seals and preserve the two UNKNOWNs. The observed maintenance scientific flags are false. The captured binding 0c8572529f57affcb391d93ac9af2b1267503e852a9943348c76e8911d3b58f9 and registry raw hash e0b13adf6845b170d2a14a225752c0df276dd6b25af561489adfc1caa03f447f are snapshots only: parent is rebinding CLI/LF metadata. C381 does not certify the eventual registry, CLI ROOT import, C375/C380 policy, new receipts or final admission.

For stronger claims, separately supply/review the corrected raw-CI map/log association, C364 original private manifest bytes and any required external historical input closure. C104's 118 and C121's 155 external manifest inputs were not all revalidated here; the separate original raw-input ZIP was not reopened. These gaps do not negate the checked archive payloads/eleven-input matches, but prevent a full historical-source/loader/TCB certificate.

No new compilation, ordinary-three-axiom claim, clean/transitive TCB, per-constant export audit, full Blueprint reader gate, new source assimilation, external PDE/paper verification, physical BE/resource closure, scientific ROOT or PURIFIED conclusion follows. Frozen C381 stops at the explicitly bounded reuse/scope findings above.

