# C365 review-only exact toolchain-maintenance candidate

NOT installed, NOT an accepted maintenance record, NOT a production waiver.
Latest user direction permits choosing a strict compatibility path toward main.
Ordinary source-assimilation validate_record is unchanged. Its experimental
rejection remains mandatory. The optional SAME registry maintenance_records
collection separately labels this one exact RobinMatrix old/new source pair.

Full source/config identity and all395 experimental exports are bound. The old
decoder reviewed11 scoped inputs, not the whole current library; its immutable
formal input manifest and independently checked raw association remain distinct
from the separate full-library compiler context. Historical original author
remains UNKNOWN. Actor identity is necessary provenance, not script-proven honesty.

The validator checks artifact/receipt content identity, not scientific truth.
New policy/compatibility reviews and official source-bound Lean/Tests/trust
records are mandatory. Whole-module source-blind reconstruction, independent
comparison and raw-association packets may be reused only for identical inputs
with original scope intact. New receipt wrappers must say exact-input-reuse;
they are not invented fresh reviews. Missing/stale/mixed/self-reviewed evidence
fails. No scientific promotion, flag removal, target edit or BE claim is allowed.

Full executable, Blueprint, browser/reader and deployment gates remain mandatory
before main. This checker is not the full integration gate. A finite pass never
proves a family theorem. No historical log/proof, verifier or scoring is changed.
Rollback removes the additive lane/record and restores this small dispatcher diff.

The unit fixtures are SYNTHETIC. They mock exact-case constants and read-only
Git responses, not file/hash checks. They are NOT independent review or Lean
evidence. First test attempt hit sandbox temporary-directory permissions; the
second exposed one test-helper missing-role bug; the fixed27tests passed. All
these attempts are preserved in the parent tool transcript. No claim of a clean
first-pass test run is made. Integration/end-to-end regressions are still needed.

New review request: examine implementation and fail-closed tests skeptically,
ordinary-lane preservation, binding cycles, stale context, raw/formal reuse,
actor provenance, native trust and the no-scientific-promotion boundary. Return
frozen acceptance-for-compatibility-only or concrete required changes. Do not
manufacture real acceptance artifacts from test fixtures; no production edits.
