# C365 independent maintenance-policy implementation review

Verdict: **REQUIRES CHANGES**. Do not install or admit this frozen candidate as an accepted compatibility policy. One reproducible root-binding defect permits unreviewed historical/provenance substitutions by refreshing only one receipt. Passing the existing tests does not close this defect.

Reviewer: `/root/robin_compatibility_review_c364`, independently assigned to this separate C365 code review, not the policy author. C364 remains frozen and untouched. This is not another mathematical/full-module review. The repository AGENTS/HARNESS/three-protocol instructions already personally read in this agent's preceding assignment remain controlling context. No children were used.

Path convention: `R/` is the repository, `W/` is the task work root, and fixture-relative paths in reproduction code exist only inside automatically cleaned temporary test directories. No local absolute paths are part of this packet.

## Exact inputs and real read extent

All five candidate files under `W/c365-policy-candidate/` were read completely:

| File | Bytes | SHA256 |
| --- | ---: | --- |
| README.md | 2586 | `518697f431bb7c8f539509a097e0d3262f1e37ddd3d08596992061359f5451a3` |
| check_toolchain_maintenance.py | 12426 | `c5c37d4e829c86fb20938e7bc638bb4afff1dfa3ac18d9c0b44f1e311629c694` |
| test_toolchain_maintenance.py | 13940 | `a63f27d3d171423252fc09eb586d25755249b60d20e17f5376fe81922674a83f` |
| check_research_publications.py | 11374 | `c97f4da5fc7ca47c866ee4514a3c23e299b7117bb8993d2ad57575397aac10ad` |
| publication-integration.patch | 1934 | `912c293c8fa63d9f1142fca91ecbc0f4defdfe6fbdc07dadfbc29d60143f5029` |

Additionally, I fully read the current `R/website/scripts/check_research_publications.py` and read lines 211-325 of `R/website/scripts/test_research_atlas.py` (ordinary publication fixture/class at 227-325, with adjacent context). The latter file was whole-file hashed but only the stated ranges were model-read; only its ordinary publication class was executed in isolation. I did not import the full atlas test module or read its other test bodies. I did not read `W/test_c366_maintenance_dispatch.py`, original C98/C104 seals, any later repair candidate, real maintenance receipts, Lean sources or paper content in this assignment. Parent-reported CI, actor discoveries and proposed fixes are not independent C365 evidence.

The candidate is not installed and no genuine maintenance record was supplied. All executable checks below use temporary synthetic fixtures; they neither manufacture nor constitute real acceptance JSON, independent review evidence, official CI evidence or a production waiver.

## Required change F1: stable receipt metadata is outside the reviewed root binding

Priority P1. Location: `W/c365-policy-candidate/check_toolchain_maintenance.py:57-72`, together with validation at 123-167.

`binding_digest` binds the record context and, for each evidence role, only `path`, `artifact_path`, and `artifact_sha256`. It deliberately does not bind the outer receipt SHA because a receipt contains the root digest. Avoiding that recursive hash is reasonable. Excluding almost all other stable receipt fields, however, leaves a mutable provenance/scope envelope outside the common independent-review commitment.

For historical roles, `original_seal_path` and `original_seal_sha256` are accepted solely from that same mutable wrapper. Lines 155-157 check that a file exists and hashes to the wrapper-supplied digest, not that it is the original seal previously associated with the other evidence. A different existing file plus its newly supplied hash passes. The artifact path/hash committed in the common binding stays unchanged, so this is not an artifact replacement that the existing negative test covers.

The same omission covers the declared historical `identity`/`run_id` and runtime `workflow_run_id`, `job_id` and `native_trust_disclosure`. The code checks nonemptiness and selected predicates, but their values are not committed by the other five receipts. This is an integrity defect, not a request for the script to prove human honesty or quantum mathematics.

### Minimal independent reproduction

Use the candidate's `MaintenanceTests` temporary fixture, which mocks only the exact-case constants and read-only Git responses as documented. Load `W/c365-policy-candidate/test_toolchain_maintenance.py` with `importlib.util`; let `t` be that module. Do not modify the candidate on disk. The following is the essential performed probe:

```python
c = t.MaintenanceTests('test_synthetic_valid_integrity_only')
try:
    c.setUp()
    c.validate()                         # valid synthetic baseline
    before = c.r['binding_sha256']
    others = {
        role: (c.root / ref['path']).read_bytes()
        for role, ref in c.r['evidence'].items()
        if role != 'whole-module-review'
    }
    role = 'whole-module-review'
    e = c.receipts[role]
    e['original_seal_path'] = 'reviews/replacement-unreviewed-seal.txt'
    e['original_seal_sha256'] = c.put(
        e['original_seal_path'],
        'SYNTHETIC TAMPER: unrelated seal; no original actor or input association\n'
    )
    c.r['evidence'][role]['sha256'] = c.dump(
        c.r['evidence'][role]['path'], e
    )                                   # refresh this wrapper only
    assert t.m.binding_digest(c.root, c.r) == before
    assert all(
        (c.root / c.r['evidence'][r]['path']).read_bytes() == raw
        for r, raw in others.items()
    )
    c.validate()                         # ACTUAL: accepts; should reject
finally:
    c.doCleanups()
```

I independently ran three isolated probes, each starting from a new valid fixture. No probe called `refresh()` after tampering; only the selected wrapper and its own outer SHA were rewritten. In every probe, the root digest remained equal and the other five receipts were byte-identical:

| Probe | Tamper | Actual outcome |
| --- | --- | --- |
| F1-A | Replace only whole-module-review original seal path/hash with unrelated synthetic content | ACCEPTED_UNEXPECTEDLY |
| F1-B | Replace only whole-module-review identity and run_id with different noncolliding synthetic values | ACCEPTED_UNEXPECTEDLY |
| F1-C | Replace only compiled-runtime workflow/job identifiers and native disclosure with unreviewed values, including a synthetic ordinary-three-axiom/no-native-debt claim | ACCEPTED_UNEXPECTEDLY |

F1-C does not show any actual three-axiom proof or successful CI forgery. It shows that the trust/provenance disclosure allegedly associated with the unchanged runtime artifact and common review context can change without invalidating the other evidence. The current code requires only a truthy disclosure string, and does not inspect its mathematical truth.

Required correction: commit all stable, role-specific receipt expectations into the root binding and require exact comparison against each actual receipt. This includes actor/run provenance, historical manifest/seal paths and hashes and reuse/scope declarations, source-blind/new-review flags, runtime proof context and gate/provenance/native disclosures, review verdict/anti-anchoring, and artifact identities. Exclude only genuinely derived self-referential binding/hash fields through an explicit scheme. Reviewers must agree on these expectations before their receipts are issued; changing them must invalidate old receipts. A path/hash supplied by the receipt alone must not establish its original provenance.

Add negative regressions for F1-A/B/C that refresh only the changed wrapper's outer SHA and prove that unchanged other receipts cannot admit the substitution. Also retain a test that a real root-context change cannot be accepted merely by recomputing the root while leaving previous receipts unchanged. Any successor design, including a proposed expected-fields scheme, requires a fresh exact-code review; no proposed repair has been tested or accepted here.

## Other requested review dimensions

### Binding cycles and stale/own-refresh behavior

The intended graph is acyclic at the byte-hash level: record root -> expected artifact hashes/paths; receipts -> root; outer receipt SHA -> actual receipt. No root digest currently incorporates a receipt's own byte hash. Source/config, lesson, diff, both checker files and publication-protocol changes invalidate the current root as coded. The existing changed-result test correctly rejects replacing a receipt's artifact hash while its root-bound artifact expectation stays old. F1 concerns metadata omitted from that expectation, so the existing test's success is not contradictory.

### Whole-eleven raw/formal historical reuse

Positive boundary: the immutable original-input-manifest digest is hardcoded; historical wrappers must explicitly say `exact-input-reuse`, `new_review_performed=False`, correct target raw digest, and `original_scope_preserved=True`. The manifest must contain 11 inputs whose production raw hashes match current files. This is kept separate from `proof_context`, which enumerates the larger local Lean/config set and is also required in runtime evidence. Thus the code does not simply assert the old decoder reviewed the entire current library.

Limit: I did not read the real pinned manifest or original seals and cannot certify their schema, actor identities or raw-to-formal association. The code only follows the manifest's 11 `production_raw_sha256` entries; it does not itself reconstruct formal snapshots or semantically validate historical work. Such reuse needs the genuine unchanged historical association evidence. F1 presently permits substituting a purported original seal without renewing the other reviews, so the original raw/formal/actor association cannot be considered adequately frozen by this candidate. The right remedy is exact provenance binding, not silently relabelling old work as fresh review or extending its scope.

### Actor provenance and missing roles/files

All six role keys are required. Each wrapper and actual result artifact must exist, hash correctly, and agree with the record's artifact expectation; portable contained local paths are enforced. The maintainer, decoder, whole-module reviewer and compatibility reviewer are required to differ. The policy reviewer may coincide with the compatibility reviewer, but may not be the maintainer/decoder/whole-module reviewer. This matches one agent independently performing C364 and C365; it does not establish historical identity honesty. Runtime/raw-association identities are not part of that separation set, and there is no separately modelled policy-author identity. Those remain provenance responsibilities for a real packet, not facts demonstrated by fixture strings. In particular, claimed actor/run values must be immutable in the common root as required by F1, not freely replaceable wrapper labels.

### Native trust and scientific scope

The checker requires runtime proof-context equality, full-library-and-Tests and trust-gate flags, workflow/job identifiers, and a nonempty native disclosure. It does not perform per-constant elaborated axiom inspection, authenticate an official workflow service, parse a compiler binary or certify ordinary-three-axiom closure. Human review of exact real runtime artifacts remains necessary. Preserving the native-debt disclosure is part of the integrity contract exposed by F1-C; the disclosure cannot be silently upgraded by a wrapper edit.

All six specified scientific flags must be literally false, exact BE-only compatibility wording is required, experimental exports must remain true, and a nonempty remaining-obligation field is required. These checks do not prove the prose accurate. Maintenance therefore must remain labelled compatibility-only; no acceptance here can mean source-assimilated publication, physical BE operator/resource closure, all-paper/PDE formalization, PURIFIED status, or main admission.

### Ordinary lane and dispatcher

The candidate's code preceding `def check` is text-identical to the production checker after newline normalization; this includes the complete original `validate_record`. Raw prefixes are not byte-identical because the production file uses CRLF and the candidate uses LF. The normalized prefix SHA256 is `d1557bf078adf31d8a07d1e8748ce82463ab6867e6bc513bc0154c38e680efd2`. The two-hunk supplied integration patch reconstructs the entire candidate exactly in an LF in-memory application to the production text; no patch was installed.

The dispatcher calls the original ordinary `validate_record` for ordinary records and the maintenance validator only for separately partitioned maintenance records. Mixed lanes/duplicates fail; missing or unknown changed modules fail. Return counts distinguish source-assimilated and maintenance modules, although `accepted_module_packets` remains their generic total. Downstream consumers outside the permitted scope have not been reviewed and must not interpret that total as scientific admission.

## Executed checks, without inflated test accounting

Runtime: local Python 3.11.9, `-B`; candidate files remained read-only and no bytecode cache was emitted. Every fixture used a real `TemporaryDirectory`, real evidence files/hashes and cleanup. No temporary-directory denial occurred, so no escalation was needed.

1. Candidate's complete unit suite: **27 tests, 7.936 s, OK**. These are existing synthetic integrity tests, not 27 independent reviews or real case acceptance.
2. Production ordinary `PublicationBindingTests` class, lines 227-325, extracted and executed against the actual candidate publication module: **12 tests, 0.833 s, OK**. No full atlas-module import or broader suite is claimed.
3. Five independently authored in-memory dispatcher scenarios calling the actual candidate `check`: **5/5 passed**. Scenarios: maintenance count is compatibility=1/source_assimilated=0; missing maintenance record rejects; lane mixing rejects; unknown changed module rejects; ordinary experimental record still rejects through the actual ordinary validator. Only module inventory selection and the candidate maintenance import were substituted for the temporary fixture; the ordinary validator was not mocked.
4. Three independent own-wrapper tamper probes: **3/3 accepted unexpectedly**, with unchanged root and unchanged other five receipts. These are reproduced failures of the intended integrity invariant, not additional passing regressions.
5. Raw candidate hashes checked before and after execution; ordinary-prefix comparison and exact integration-patch reconstruction checked in memory. Exact source-file hashes and structured observations are in INPUT_MANIFEST.json.

The counts are separate suites/scenarios, not a claim of 47 distinct comprehensive tests. I did not run or incorporate the parent's reported 32-test C366 suite or any proposed successor repair.

## Stop boundary

Required change is F1 and its concrete regressions. No candidate/production/old artifact was edited. Only this new three-file review packet was authored; automatically cleaned temporary synthetic fixtures were the only execution writes outside it. No Lean, network, Git command/write/fetch, installation, real maintenance acceptance record or source proof was produced. An initial read-only PowerShell inventory command had a syntax error and was corrected before any evidence was obtained; it changed no file.

Policy verdict is REQUIRES CHANGES, not a judgment against reasonable compatibility maintenance as a direction. A repaired policy and a real fully bound case would still require separate admission/integration gates. C364's preservation finding and the old raw-fold/prepared-physical-operator scientific boundaries are not modified. STOP after this freeze.
