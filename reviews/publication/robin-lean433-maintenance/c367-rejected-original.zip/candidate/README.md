# C367 additive policy repair candidate

The C365 candidate remains immutable and NOT installed or approved. Independent
review found that one historical receipt could change its old seal/provenance
and refresh only its own file hash without invalidating other roles. This
successor binds ALL stable receipt fields via evidence.expected_fields in the
root digest; each actual receipt must exactly equal those fields except its
root binding. Old artifacts, identity/run and all runtime/native fields are
covered. Receipt file hashes are separately checked, without recursive hashing.

The new negative matrix tampers every stable field in each role, refreshes only
that receipt/file hash, and requires failure. Editing the expected metadata
without a new root/cross-role binding also fails. These are SYNTHETIC tests, not
real review/Lean evidence or proof of human honesty. All prior27tests remain.

Ordinary validate_record and the C365 dispatcher diff are unchanged. No source
target, flag, verifier, scoring, task or old log is modified. Exact compatibility
is still distinct from paper assimilation and scientific BE closure. Whole11
historical input scope is not enlarged to the full runtime context. All full
Lean/Tests/trust/executable/Blueprint/reader gates remain mandatory before main.
No real maintenance record or approved policy activation is created here.
