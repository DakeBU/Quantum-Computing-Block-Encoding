# C371 independent maintenance-policy successor review

Verdict: **REQUIRES CHANGES** for the exact `W/c367-policy-successor/` candidate. C365 F1-A/B/C are now rejected as intended, but a narrower, independently reproduced JSON-type equality bypass remains. No policy activation, real maintenance record, main admission, scientific BE closure or TCB clearance is accepted.

Reviewer: `/root/robin_compatibility_review_c364`, independent of the policy author. C364/C365 and both old candidates remain untouched. `R/` denotes the repository and `W/` the task work root. Temporary fixture-relative paths below are synthetic, automatically cleaned paths, not real review evidence. All original AGENTS/HARNESS/three-protocol boundaries remain in force.

## Inputs and actual read extent

I personally read all five successor files completely:

| Input under W/c367-policy-successor/ | Bytes | SHA256 |
| --- | ---: | --- |
| README.md | 1370 | `2fd1b88540f15501fc0267d1336b821c3c5ebf33bfabda895acb4a53dae80205` |
| check_toolchain_maintenance.py | 12995 | `4d15e80741e502ab854113348190d48939b7811875c82df4570c07c8365fdadd` |
| test_toolchain_maintenance.py | 15865 | `7930cce93c728ff65eba85c12efc51adad7d9391ad45d34eef7b415d5c8d76d5` |
| check_research_publications.py | 11374 | `c97f4da5fc7ca47c866ee4514a3c23e299b7117bb8993d2ad57575397aac10ad` |
| publication-integration.patch | 1934 | `912c293c8fa63d9f1142fca91ecbc0f4defdfe6fbdc07dadfbc29d60143f5029` |

The publication checker and integration patch have the same exact digests as their previously frozen C365 versions. They were nevertheless fully read in this assignment. I also mechanically extracted and executed `R/website/scripts/test_research_atlas.py:227-325`, the ordinary publication test class previously personally read during C365; its whole-file hash is still `cd189d96c8dbed7722cd06d1f9eb07842937a5e294abcfe6fa21f009e30582f8`, 19930 bytes. No other atlas classes or full module imports were executed. Outside that section the file was hashed, not newly read for meaning.

The previous C365 failure is prior frozen evidence and was reproduced against this successor, not assumed repaired from the parent summary. I did not read `W/test_c366_maintenance_dispatch.py`, later repair candidates, real historical seals/manifests, CI logs, Lean modules or paper sources. This is code/integrity review, not renewed mathematical review. Parent-reported passes and a proposed next repair are not acceptance evidence here.

## C365 F1 regression result: repaired for the reproduced attacks

Lines 64-69 now put each evidence reference's complete `expected_fields` into the root digest, alongside the explicit artifact path/hash. Lines 132-134 compare every parsed receipt field other than `binding_sha256` with that root-bound map. The receipt root is checked separately against the computed common digest, and the outer receipt byte SHA remains separately checked. This addresses the former missing-metadata commitment.

I independently repeated all three C365 minimal attacks on new valid temporary fixtures. Each attack refreshed only the selected wrapper's outer SHA, never the other roles or the expected metadata. Each retained the original common root and byte-identical other five receipts:

| Attack | Successor outcome |
| --- | --- |
| F1-A: replace whole-module-review original seal path/hash with an unrelated file | REJECTED: receipt semantics differ |
| F1-B: replace whole-module-review identity/run_id | REJECTED: receipt semantics differ |
| F1-C: replace runtime workflow/job/native-disclosure metadata | REJECTED: receipt semantics differ |

These are actual independent executions of the successor, not inherited C365 or parent results.

## Required change F2: Python equality is not exact JSON-field equality

Priority P2. Location: `W/c367-policy-successor/check_toolchain_maintenance.py:132-134`; relevant runtime permissiveness at 173-174; incomplete type coverage in `W/c367-policy-successor/test_toolchain_maintenance.py:250-261`.

The new check uses Python dictionary equality:

```python
stable_fields = {k: v for k, v in e.items() if k != 'binding_sha256'}
if ref.get('expected_fields') != stable_fields:
    raise ValueError(...)
```

Python considers `1 == True` and `1 == 1.0`, including recursively within dicts/lists. JSON boolean and number values are different field contents. The code has no string/type constraint for runtime workflow/job IDs; numeric IDs are currently accepted. Thus a root-bound numeric workflow ID can become a boolean in just one receipt without failing the purported exact comparison.

### Minimal independently executed reproduction

Load `W/c367-policy-successor/test_toolchain_maintenance.py` with `importlib.util`; let `t` name that loaded module. The candidate's temporary fixture mocks the exact-case constants and read-only Git responses but uses real files and hashes. All baseline preparation below happens before the frozen comparison point:

```python
c = t.MaintenanceTests('test_synthetic_valid_integrity_only')
try:
    c.setUp()
    role = 'compiled-runtime'
    c.receipts[role]['workflow_run_id'] = 1
    c.refresh()                          # legitimate complete baseline binding
    c.validate()                         # ACTUAL: numeric ID baseline accepted
    before = c.r['binding_sha256']
    others = {
        r: (c.root / ref['path']).read_bytes()
        for r, ref in c.r['evidence'].items() if r != role
    }
    c.receipts[role]['workflow_run_id'] = True
    c.r['evidence'][role]['sha256'] = c.dump(
        c.r['evidence'][role]['path'], c.receipts[role]
    )                                    # only this wrapper is refreshed
    assert t.m.binding_digest(c.root, c.r) == before
    assert all(
        (c.root / c.r['evidence'][r]['path']).read_bytes() == raw
        for r, raw in others.items()
    )
    c.validate()                         # ACTUAL: accepts JSON true for bound 1
finally:
    c.doCleanups()
```

Observed outcome: ACCEPTED, common root unchanged, other five receipts byte-identical. This differs from F1: stable metadata is now in the root, but the comparison relation admits a different JSON type. It is not evidence of an actual CI run or fabricated scientific proof. Existing strict `is True`/`is False` guards still protect their particular status flags; they do not protect the provenance ID used in this probe.

Required correction: use a type-sensitive exact JSON comparison for all stable fields, including nested values, or an equivalently strict schema plus comparison that rejects every boolean/number coercion. If serialization is used, require deterministic JSON and fail closed on non-JSON nonfinite values. Retain the existing acyclic root/receipt separation. Add regressions for `true` versus `1`, integer versus float where exact type is required, nested variants, and the original F1-A/B/C. Any repair must be independently reviewed as exact new bytes; no proposed successor has been executed or accepted in this packet.

The candidate's field mutation matrix is useful but does not expose F2: it replaces each stable field with one string (`forged-wrapper-value`). It covers 68 top-level role/field pairs, not all JSON value types or recursive substitutions. Passing 31 methods therefore does not establish the stronger exact-match invariant.

## Root updates, cycles and historical boundary

The root now commits stable expected receipt payloads; actual receipt byte hashes remain outside it because receipts themselves contain the root. This avoids a recursive digest requirement. Supplying `binding_sha256` inside `expected_fields` would not create a valid accepted cycle: it would differ from the actual stable-field map that excludes that key. Receipt root values are still individually checked.

The existing successor tests independently passed for changed expected metadata without a new root, and for a recomputed root with unchanged old receipts. Binding all stable metadata plus strict type-aware equality is the correct interface direction. The fixture helper `refresh()` deliberately simulates a complete cross-role rebinding; its ability to rewrite all synthetic wrappers is not proof that real independent reviewers reapproved a changed case. Real provenance and honesty remain external evidence obligations.

The fixed eleven-input manifest hash, 11 current production-raw digest comparisons, explicit `exact-input-reuse`/no-new-review fields and scope-preserved flag are retained. Root-binding the original seal/manifest metadata blocks the reproduced single-wrapper seal reassignment; it does not itself authenticate the real seal or reconstruct formal snapshots. The larger local `proof_context` and runtime source-context checks remain distinct from the old decoder's eleven-input scope. No claim is made that old reviewers read the full current library.

I did not inspect any real historical seal, actor or raw/formal association in this assignment. Actor labels remain mechanically checked provenance, not script-proven human independence. Role separation rules are unchanged; policy review can coincide with compatibility review but not with maintainer/decoder/whole-module review. Whole-library/Tests/trust flags, workflow/job/native disclosures and exact result artifacts remain required. F2 must be closed before claiming that all those stable values are exactly committed to the other roles' receipts.

## Ordinary lane, case sensitivity and scientific classification

The fully read ordinary `validate_record` and dispatcher have the exact previously reviewed C365 file hash. Ordinary experimental-source rejection remains in place. The dispatcher keeps the two lane maps disjoint, rejects missing/unknown modules, invokes the actual ordinary validator on ordinary records, and reports compatibility and source-assimilation counts separately. Its generic accepted-packet total must not be repurposed as a scientific-publication count. Downstream consumers were not newly reviewed.

The successor's Lean-name test preserves case-sensitive names in the inventory and rejects a lowercased declaration set; it passed. This is not a new review of the real export catalog or a fresh declaration count certification.

All scientific claims must remain literally false, the BE-only compatibility scope stays explicit, experimental flags stay true, and remaining BE obligations remain required. Native trust remains disclosed debt, not ordinary-three-axiom certification. No maintenance-code verdict can discharge the raw-fold counterexample or missing full physical prepared-operator/adjoint/unitarity/extraction/resource obligations. This assignment does not re-examine those mathematics and does not alter C364/C365.

## Executions and accounting

All executions used local Python with `-B`, real automatically cleaned temporary fixtures, and no candidate/production edits. No temporary-directory denial or escalation occurred.

- Complete successor suite: **31 tests, 17.432 s, OK**. This includes its four additional methods; the stable-field method has **68** role/field subcases (8 compatibility, 12 runtime, 8 policy, 13 raw-association, 14 decoder, 13 whole-module-review).
- Original ordinary publication class run against the actual successor publication module: **12 tests, 0.870 s, OK**. The full atlas module was not imported.
- Five independent actual-dispatcher fixture scenarios: **5/5 passed** (separate counts, missing record, lane mixture, unknown changed module, actual ordinary experimental rejection). Only fixture Git/case constants, changed-module selection and the maintenance leaf import were substituted; the ordinary validator was not mocked.
- C365 own-wrapper regression probes: **3/3 rejected**, with unchanged root and other five receipts.
- Stronger F2 probe: **1/1 accepted unexpectedly**, after an accepted numeric-ID baseline; unchanged root and other five receipts.

These are separately reported methods/scenarios/probes, not a count of independent reviews or a claim that 68 subcases are 68 test methods. Parent-reported executions and later repair code are excluded.

## Disposition and stop

Require F2 correction and exact new regression evidence before admitting this candidate. Its F1 repair is positively recorded, not erased by the new finding. No installation, real maintenance acceptance JSON, Lean/compiler run, Git command/write/fetch, network, children or production change occurred. The only authored outputs are the new three-file C371 packet; synthetic fixture writes were temporary and cleaned. Policy failure class: IMPLEMENTATION_FAILED for exact receipt comparison, not a mathematical route failure. STOP after freeze.
