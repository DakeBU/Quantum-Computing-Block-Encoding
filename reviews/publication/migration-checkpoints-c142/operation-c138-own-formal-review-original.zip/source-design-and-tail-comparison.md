# Source/design comparison and complete supplier tails

Comparison inputs are only this reviewer's immutable source-first interpretation and proposal-review, plus the new exact C136 formal packet. No actual decoder or other review was used.

## Source-to-formal scope ledger

| Source-only region / accepted design obligation | Actual text disposition |
| --- | --- |
| Page9 Eq11: true Toffoli zero-input AND compute | Actual compiled CCX macro and its eval-to-CCX provider are present; ccx3_zeroInsert_apply obtains graph support from UJ |
| Page9 Eq11: a second Toffoli returns target zero | Relevant imported CCX action is involutive; no new target two-Toffoli cleanup theorem is declared or claimed |
| Eq12 destructive X branch | StatementProbe.xBra is total 4-by-8 contraction by actual H row, independent of AND; xBra_mulVec and all-carrier xBra_complete are actual target declarations |
| Eq12 conditional CZ | Literal full-carrier phasePermutationMatrix specialization, actual private action theorem and unconditional C isometry |
| Eq12 released target versus restored zero | Removal by xBra and insertion by zeroInsert are distinct typed steps; J isometry is an explicit supplier |
| Eq12 exact complex/reference preservation | Actual bridge preserves arbitrary alpha and pointwise arbitrary R; root fixes same positive s in both outcomes; finite mass theorem has no normalization hypothesis |
| Eq12 schematic use interval | EXCLUDED from target: no use program; only identity-use local root reviewed, as expressly accepted in design |
| Eq13 phase, outcome and half-mass | AND specialization is reconstructed exactly as unnormalized branch scale and finite normSq mass; actual stochastic outcome record/Born execution not defined |
| Eq13 arbitrary Boolean f | EXCLUDED: no generic-f operation/correction implementation or theorem in this target |
| Source one-versus-two-Toffoli resource claim | EXCLUDED as a certified conclusion; actual CCX prefix exists, but measurement/control/reset/resource compiler layers are not established |
| Overall clean-output context | Reset-shaped branch output is sJ on the selected input domain, not a proof of full physical unitary or source-circuit admission |

No source correction is introduced. The explicit zero-input local branch theorem is intentionally smaller than the schematic full source use story and preserves its stated boundary.

## Required AND tails, with actual source-text producers

1. Actual compute graph producer: StatementProbe.ccx3Program literal existing macro; PrimitiveMacros.primitiveCCXProgram_eval; actual ccxBasisEquiv inverse/action definitions; ComplexLCU.equivPermutationMatrix_mul_apply; target ccx3_mulVec; target zeroInsert_mulVec; actual andBit; native decomposition. All are needed for ccx3_zeroInsert_apply's advertised meaning. The theorem does not assume U already has AND-graph action.
2. J semantic validation: literal zeroInsert entries, work/data decomposition, sum_work, finite conjugate-transpose/multiplication. Actual zeroInsert_isometry states the complete 4-by-4 identity without conditions.
3. C semantic validation: literal conditionalCZ and conditionalCZSign, actual phasePermutationMatrix identity-permutation entries, sum_data, decomposition and finite conjugates. Actual conditionalCZ_isometry covers every outcome and all retained basis rows/columns.
4. X-family semantic validation: literal full-carrier xBra, actual H entries, target hadamard_entry, star_branchScale, branchScale_mul_self, sum_data and all work-coordinate decompositions. Actual xBra_complete has full 8-by-8 output equality and sums both outcomes. No favorable graph or input normalization is a premise.
5. Operation-to-helper bridge: actual graph producer, all three literal operation mulVec action lemmas, rectangular matrix-action associativity, one-bit sum collapse and the literal separate corrected helper. Actual compiledAndBranch_eq_helper is a theorem with proof text, not a renamed definition or an assumed operation-correctness structure.
6. Selected matrix root: actual bridge, actual correctedTemporaryAndBranch_eq, matrix-action injectivity, scalar mulVec, retained decomposition and J action. Actual compiledAndCleanupKernel_eq has only m as a value binder. The Unit-indexed alpha inside its proof ranges over an arbitrary retained input vector and does not restrict the public theorem.
7. Required finite mass consumer: actual bridge, target sum_work (including target-first snoc orientation and subsequent finite-sum rearrangement), literal inputMass/branchMass, actual correctedTemporaryAndBranch_mass. Actual compiledAndBranch_mass is unconditional in alpha and has only the finite reference carrier needed for summation.

All seven package acceptance obligations have actual declarations and source proof routes in the reviewed snapshots. This is a static presence/meaning finding, not evidence of compiler acceptance. The root's textual mathematical proof uses the bridge/helper equality; J/C isometries and X completeness are separate semantic package validations, not direct root-proof premises. This distinction avoids falsely drawing every package AND-tail as a direct Lean proof dependency. No elaborated dependency graph was extracted.

## Definition and signature comparison

The four actual operation/program bodies in StatementProbe implement exactly the previously reviewed schemas: existing fixed-wire CCX, retained-identity/ket-zero insertion, retained-identity/H-row destructive contraction, and literal conditional-CZ diagonal. The two carrier aliases reuse PrimitiveBasis. None mentions the desired root, helper output, input alpha or an AND precondition. No correctness-by-definition substitution was found.

The seven public OperationBridge signatures agree with the accepted selected-root/supplier/mass interface. The generic reference is Type* in actual theorem signatures, as proposed; StatementProbe's universe-zero check expressions are only unexecuted source commands. No normalization, factorizability, reality, nonzero overlap, successful outcome, gate-correctness, measurement-correctness or final-action premise was added.

The imported helper bodies and complete headers match the later C125 exact API supplement's literal content and namespace. The helper remains an isolated TemporaryAnd module in this packet rather than a newly admitted production QuantumBlockEncoding helper. The original C117 missing-API finding is not erased merely because this later packet now contains the helper source.

No optional discard endpoint or identity-reference Kronecker theorem is implemented; their absence is not a missing required AND tail for this selected package. No additional consumer/use program is implemented. Neither optional route may be advertised as a compiled adaptive program by inference from these matrices.

## Mathematical and trust findings

No static semantic mismatch or concrete counterexample was found. The source text reconstructs the exact ideal finite-linear contract, positive scale, outcome sign cancellation, full-carrier family validation, explicit output embedding, arbitrary complex/reference slices, and finite mass agreed in the prior source/design phases.

No proof acceptance, ordinary-axiom conclusion, or no-native-dependency conclusion is made. A lexical scan is not a Lean parser or proof-term analysis. The actual root still requires compiler/gate evidence and independently compared decoder evidence in a later phase before any Proof Seal or source-facing admission. Hardware readout, adaptive feedback, resetting discarded qubits, Born interpretation, generic-f correction, whole-program cleanup, resource/precision/noise and SP/BE integration remain outside the statement.
