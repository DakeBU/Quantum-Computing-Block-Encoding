# C138 independent own-formal mathematical reconstruction

Status: OWN_FORMAL_ONLY_STATIC_TEXT_FROZEN, before actual decoder or compiler-output exposure.
Reviewer: temporary_and_operation_statement_review_c120.
Formal input: C136 packet, formal-inputs.json SHA-256 cd03e096d58323c29e993a6649536d3bd723ca11737a16569b2d9ae16739b2de.
Target: OperationBridge.lean, SHA-256 2f1150d4c6c48c24e0d62155e94316004efb72ed70ce9d69105ba1a737d64ce3, all 252 lines read, including private/public statements, proof bodies, imports, namespace, open command and ending.

This reconstruction is from the supplied formal text. It is not an author's rationale, an actual decoder reconstruction, a compilation result, a proof-term dependency extraction, or a Proof Seal. All mathematical explanations below are my reading and analytic checking of the text, not claims that Lean accepted it.

## 1. Actual ambient definitions

OperationBridge imports StatementProbe, which imports TemporaryAnd, which imports QuantumBlockEncoding.PrimitiveMacros. It additionally imports the two Mathlib Fin-equivalence modules. Its namespace is ASPBE.Uncompute.MBU.OperationBridge and it opens QuantumBlockEncoding. There are no target section variables, local assumptions, new axioms, new definitions, or new abstract correctness structures. Its operation definitions belong to the imported StatementProbe snapshot in the same namespace.

DataBasis is Fin2 -> Fin2, with two named retained coordinates. WorkBasis is Fin3 -> Fin2, with retained coordinates 0,1 and target coordinate 2. These are four- and eight-element carriers, not a silently chosen integer endianness. The private data_decompose and work_decompose prove that every native basis function is exactly a vector ![a,b] or ![a,b,t]. Matrices have output rows and input columns and act on column vectors by finite sums.

Write J for zeroInsert, X_m for xBra m, C_m for conditionalCZ m, and U for evalPrimitiveProgram ccx3Program. The supplied actual bodies are:

    J[x,y] = delta(x0=y0 and x1=y1 and x2=0),          8 by 4;
    X_m[y,x] = delta(x0=y0 and x1=y1) H[m,x2],        4 by 8;
    C_m[y,z] = delta(y=z) conditionalCZSign(m,z0,z1), 4 by 4.

The literal conditional sign is negative exactly when m=z0=z1=1. The actual H is initially defined through standard Ry, Rz, and an i-prefactor, but its actual entry theorem gives

    H = s [1  1; 1 -1],   s = (sqrt(2)/2 : Real) cast to Complex.

Thus X_0 is the retained identity times the plus bra and X_1 the retained identity times the minus bra, with a positive real scalar, not an unnormalized sign-only row and not an i-rephased row. The helper branchScale is exactly s.

ccx3Program is literally primitiveCCXProgram at fixed distinct wires 0,1,2, with the three intrinsic inequalities discharged by decide. It is not a definition of an AND-output state. The actual existing compiler macro is primitive H, then a concrete T/Tdg/CX middle program, then primitive H. Its evaluation theorem equates this real program's matrix to the permutation of ccxBasisEquiv, including global phase. The equivalence flips the target iff both retained controls equal 1 and is its own inverse. Consequently

    U |a,b,t> = |a,b,t xor (a and b)>.

The formal operation product is

    O_m = J C_m X_m U J : DataBasis -> WorkBasis.

The rightmost J first provides an actual zero target. U then computes, X_m removes the target from its output carrier, C_m corrects the retained sign, and the leftmost J inserts a zero target again. There is no intervening use operation. The last J is an ideal isometric insertion, not a hardware reset of an arbitrary old environment.

## 2. Reconstructed actual target statements

The graph producer ccx3_zeroInsert_apply is unconditional in arbitrary complex alpha:R->Fin2->Fin2->Complex and arbitrary reference label r. At each WorkBasis output x it says

    (U J alpha_r)[x]
      = alpha(r,x0,x1) if x2=andBit(x0,x1), and 0 otherwise.

Its proof rewrites through ccx3_mulVec and zeroInsert_mulVec, then exhausts the three finite bit coordinates. The graph is a conclusion obtained from the actual program; it is not an assumed support condition or a definition of the post-compute state.

The three operation-validation statements are

    J^* J = I_4;
    C_m^* C_m = I_4 for each outcome m;
    sum_(m in Fin2) X_m^* X_m = I_8.

They quantify over the whole stated carriers. The first two proofs expand actual entries and finite native sums. The third additionally exposes exact H entries, reality of s, and s*s=1/2, then checks all input/output basis bits symbolically. Completeness is not inferred from a fair-coin assertion on an already-selected graph.

The new bridge compiledAndBranch_eq_helper states, for all alpha,m,r,x,

    (O_m alpha_r)[x]
      = correctedTemporaryAndBranch(alpha,m,r,x0,x1,x2).

The helper's literal body is

    if t=0 then conditionalCZSign(m,a,b) * H[m,andBit(a,b)]
                  * alpha(r,a,b)
    else 0.

The bridge proof first forms a pointwise hgraph using the actual graph producer. It decomposes the operator action with the three private operation mulVec lemmas, splits final target-zero versus nonzero, and collapses the target-bit finite sum at andBit(x0,x1). This is a genuine operation-to-helper theorem in the source text, not a definition assigning favorable output to O_m. No old helper formula is used to define U,J,X_m,or C_m.

The helper equality, whose entire proof is also disclosed in TemporaryAnd, states

    correctedTemporaryAndBranch(alpha,m,r,a,b,t)
      = s * (alpha(r,a,b) if t=0, else 0).

Its finite-bit proof corresponds to the exact sign cancellation: H[m,andBit(a,b)] contributes (-1)^(mab), C_m contributes the same sign, so their product is s. This holds for every complex amplitude, with no reality, factorization, normalization, nonzero, or favorable-branch premise.

The selected actual root compiledAndCleanupKernel_eq is precisely

    J C_m X_m U J = s J,  for every m:Fin2.

It is an 8-by-4 matrix equality, not an 8-by-8 inverse-unitary assertion. The root proof invokes matrix-action injectivity and tests arbitrary retained coefficient vectors. It embeds an arbitrary vector v as alpha on the Unit reference, uses the actual bridge and helper equality, and recognizes zeroInsert.mulVec. No value parameter except m, no logical correctness assumption, and no normalization condition is present in its signature.

The actual finite mass consumer compiledAndBranch_mass says, for any finite reference-index type R,

    sum_r sum_(x in WorkBasis) normSq((O_m alpha_r)[x])
      = inputMass(alpha)/2,

where inputMass is sum_r sum_a sum_b normSq(alpha(r,a,b)). It uses the actual bridge, the native-coordinate sum_work equivalence, and the actual helper mass theorem. It does not use a function-space norm or create a new probability foundation.

## 3. Native sum and reference details

sum_data changes a sum over Fin2->Fin2 into sums over a,b via finTwoArrowEquiv. sum_work uses Fin.snocEquiv with pair order (target,retained tuple), identifies snoc(![a,b],t) with ![a,b,t], then explicitly commutes the finite sums to retained0,retained1,target order. Thus the mass identity has an actual coordinate-sum producer, not a guessed four/eight-element count.

The bridge and graph theorem leave R arbitrary and need no Fintype instance. Each r slice uses the same actual matrices and the same positive s. For finite reference spaces this preserves all reference-relative complex phases and hence admits the usual identity-on-reference lift by ordinary matrix algebra. However, this target does not declare a Kronecker identity-reference theorem, a density/channel theorem, or a larger compiled register program. Arbitrary infinite R is only a coefficient-index statement, not an asserted normalized Hilbert-space vector or an infinite L2 sum.

The finite mass theorem requires Fintype R only to form its sum. Classical decidability is introduced inside the proof, not as a correctness premise. The old normalized helper corollary has inputMass alpha=1 as its explicit specialization assumption; that assumption is absent from both the actual root and the raw mass consumer.

## 4. Kraus scale, normalized branches and physical boundary

This formal root is an unnormalized linear branch statement. Each outcome branch equals sJ; it does NOT equal J without a scalar. On normalized input its squared output mass is one half. Only after adopting ideal Born instrument semantics and conditioning/normalizing the branch can one remove that scalar to describe the normalized conditional output. The target itself provides no Born outcome interpreter, classical outcome register/control, or physical measurement/reset execution.

The all-carrier X family plus the C/J isometries analytically imply that L_m=J C_m X_m forms a complete ideal Kraus family on WorkBasis:

    sum_m L_m^* L_m
      = sum_m X_m^* C_m^* (J^*J) C_m X_m
      = I_8.

This combined equality is an analytic consequence of the three actual suppliers; it is not a separately named target theorem in this snapshot. Nor does X-family completeness imply uniform outcome probabilities for every arbitrary full-carrier input. Uniformity follows after the particular UJ input restriction through the actual root.

The private and public source text contains no arbitrary-use program. It therefore does not prove source use intervals preserve the current AND graph. It does not prove a discarded target is itself reset, and it never identifies a target trace-out channel with an amplitude wire-deletion map. Optional discard and reference-lift corollaries from the accepted design are not implemented here and are not needed by the selected minimum package.

## 5. Comparison outcome and trust limits

STATIC_TEXT_MATCHES_THE_FROZEN_LOCAL_CONTRACT. Every required finite-linear producer statement and an explicit proof route is present in the exact target/provider snapshots. The actual bodies agree with the approved literal schemas; no weakening, excess root premise, output-dimension substitution, phase quotient, arbitrary-use extension, or hardware/resource claim was found.

This is not a compiler verdict. I have not executed the source #check or #print axioms commands, and their presence is not evidence of any output. I do not assert that every tactic elaborates, that Lean accepted the theorem, or that its exact axiom set is ordinary. Imported Mathlib source/proof terms are not part of this 30-snapshot packet. A lexical scan found native_decide lines in six other local import-closure snapshots, but not in the target, StatementProbe, TemporaryAnd, or the directly read CCX/H chain. Module import is not proof-term dependency: this is neither proof that the root depends on native evaluation nor proof that it does not. Actual elaborated axiom/dependency evidence remains pending and withheld from this phase.

No actual decoder, author rationale, compiler result, prior review, publication record, network source, simulator, Git operation, child agent or production edit was used. The next phase may compare this frozen own-formal reading with a separately supplied actual decoder and actual gate evidence; no such comparison or final admission is made here.
