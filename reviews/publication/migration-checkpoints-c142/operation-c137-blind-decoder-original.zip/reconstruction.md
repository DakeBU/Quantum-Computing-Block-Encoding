# Formal-only reconstruction

This document decodes only the supplied formal snapshot. It does not compare a source, judge novelty, certify physical implementation or resources, or assert Lean acceptance. All theorem descriptions below mean the literal proposition and the visible proof route, not a fresh compiler result. Exact target and immediate ambient source bytes are preserved in `exact/*.base64`; `exact-declarations.json` retains lexical signatures, including private declarations.

## Carriers, directions and total formulas

Write B={0,1}=Fin 2, D=(Fin 2 → B), W=(Fin 3 → B), and identify d with (a,b)=(d 0,d 1), w with (a,b,t)=(w 0,w 1,w 2). These are function carriers of four and eight elements, not quotient states. Coordinates 0,1,2 are the only register order supplied. There is no integer endianness convention or serialization statement. Scalars are complex numbers. A matrix has output/row index first, input/column index second; (Av)(row)=Σcolumn A(row,column)v(column). Products act rightmost first. Dagger means complex-conjugate transpose.

Define q(a,b)=1 if a=b=1 and 0 otherwise. Define β=ofReal(√2/2), a real, positive complex scalar. Define s_m(a,b)=-1 exactly when m=a=b=1, and +1 on every other point of B³. Thus s_m(a,b)=(-1)^(m q(a,b)), with bits interpreted as integers only for this explanatory formula.

The Hadamard matrix H, with row and column in B, has full entries H(0,0)=H(0,1)=H(1,0)=β, H(1,1)=-β. Its literal provider definition is i times Ry(π/2)Rz(π), and `hadamardMatrix_apply` supplies these entries. Ry(θ)=[[cos(θ/2),-sin(θ/2)],[sin(θ/2),cos(θ/2)]], while Rz(θ)=diag(cos(θ/2)-i sin(θ/2),cos(θ/2)+i sin(θ/2)). The phase i is retained, not discarded modulo global phase.

The six definitions in `StatementProbe.lean` give these objects on their whole carriers:

* `DataBasis`=D; `WorkBasis`=W.
* `ccx3Program` is `primitiveCCXProgram 0 1 2` with all three distinctness proofs obtained by `decide`. Let U be its `evalPrimitiveProgram` matrix W×W. The inspected supplier proposition gives U(w,z)=1 when w=F(z), and 0 otherwise, where F(a,b,t)=(a,b,t xor q(a,b)). F is its own inverse. No unknown unitary or semantic correctness premise is a public input.
* `zeroInsert` is J:W×D, J((a,b,t),(c,d))=1 exactly when a=c, b=d, t=0, and 0 otherwise. Hence (Jv)(a,b,t)=v(a,b) if t=0 and 0 otherwise.
* `xBra m` is B_m:D×W, B_m((a,b),(c,d,t))=H(m,t) if c=a and d=b, and 0 otherwise. Hence (B_m v)(a,b)=Σt H(m,t)v(a,b,t).
* `conditionalCZ m` is C_m:D×D, C_m((a,b),(c,d))=s_m(c,d) if (a,b)=(c,d), and 0 otherwise. Hence (C_m v)(a,b)=s_m(a,b)v(a,b). Its provider uses a phase-permutation matrix with the identity equivalence. The phase is attached to the input column, though diagonal equality makes the two coordinates coincide here.

Let R be an arbitrary type and α:R→B→B→ℂ. For each r define v_r(a,b)=α(r,a,b). No finiteness, nonemptiness, norm, nonzero amplitude, separability or normalization is required for the pointwise results. The helper in `TemporaryAnd.lean` is the total function

    T_m(α)(r,a,b,t) = s_m(a,b) H(m,q(a,b)) α(r,a,b), if t=0;
                       0, otherwise.

Its separate equality theorem simplifies it to β α(r,a,b) for t=0 and zero otherwise. The helper definition does not simply define the output to be β times the input: it retains the outcome-dependent phase and Hadamard entry, whose cancellation is proved by all bit cases.

When `[Fintype R]` is present, the two real-valued total functions are

    inputMass(α) = Σr∈R Σa∈B Σb∈B |α(r,a,b)|²,
    branchMass(α,m) = Σr∈R Σa∈B Σb∈B Σt∈B |T_m(α)(r,a,b,t)|².

Here |z|² is exactly `Complex.normSq z` (the sum of squares of real and imaginary parts), not the modulus or a trace normalization.

## Exact content of all target declarations

Every name in this section is under `ASPBE.Uncompute.MBU.OperationBridge`. Exact binders and Lean conclusions are in `exact-declarations.json`; symbols in this prose are the fully expanded objects above. All seven public target theorems are unconditional equalities once their typing arguments are supplied.

1. Private `data_decompose (x : D)` asserts ∃a b:B, x=![a,b]. Its proof chooses x 0,x 1 and checks both coordinates.
2. Private `work_decompose (x : W)` asserts ∃a b t:B, x=![a,b,t]. Its proof chooses the three coordinates and checks each.
3. Private simp theorem `work_vec_two (a b t : B)` asserts (![a,b,t]:W) 2=t by reflexivity.
4. Private `sum_data {A : Type*} [AddCommMonoid A] (f : D→A)` asserts Σx∈D f(x)=Σa∈B Σb∈B f(![a,b]). It transports a finite sum through the inverse of `finTwoArrowEquiv (Fin 2)`, then expands a product sum. A is not restricted to complex numbers.
5. Private `sum_work {A : Type*} [AddCommMonoid A] (f : W→A)` asserts Σx∈W f(x)=Σa∈B Σb∈B Σt∈B f(![a,b,t]). The proof transports via `Fin.snocEquiv`, proves the snoc vector identity, invokes `sum_data`, and swaps finite sums to restore coordinate order.
6. Private `zeroInsert_mulVec (v : D→ℂ) (x : W)` gives (Jv)(x)=if x 2=0 then v(![x 0,x 1]) else 0. It decomposes x, checks all bits and expands the finite matrix-vector sum.
7. Private `conditionalCZ_mulVec (m : B) (v : D→ℂ) (y : D)` gives (C_m v)(y)=s_m(y 0,y 1)v(y). It decomposes y, checks m and both data bits, and expands the diagonal phase-permutation definition.
8. Private `xBra_mulVec (m : B) (v : W→ℂ) (y : D)` gives (B_m v)(y)=Σt∈B H(m,t)v(![y 0,y 1,t]). It expands the eight-element sum and the row-selection conditions.
9. Private `ccx3_mulVec (v : W→ℂ) (x : W)` gives (Uv)(x)=v(F(x)). The proof uses `primitiveCCXProgram_eval` and `equivPermutationMatrix_mul_apply`, with a Unit-column matrix. The latter normally pulls back through the inverse equivalence; here F is involutive, so its inverse is the same literal action. This is not a convention that arbitrary permutations act by forward pullback.
10. Public `ccx3_zeroInsert_apply {R : Type*} (alpha : R→B→B→ℂ) (r : R) (x : W)` gives ((UJ)v_r)(x)=if x 2=q(x 0,x 1) then α(r,x 0,x 1) else 0. It composes items 6 and 9, then checks the eight bit values using the actual `ccxBasisAction`, `xBasisAction`, `flipBit`, and q definitions.
11. Public `zeroInsert_isometry` has no binders and asserts J†J=I_D. It expands each entry and checks the four data bits and the sum over W. It is an isometric embedding equality, not a surjectivity assertion JJ†=I_W.
12. Public `conditionalCZ_isometry (m : B)` asserts C_m†C_m=I_D for each of the two outcomes. The proof expands entries and all outcome/data bit cases. There is no premise that C_m is unitary.
13. Private `hadamard_entry (m t : B)` gives H(m,t)=if m=1 ∧ t=1 then -β else β. It is obtained from the provider entry theorem by four cases.
14. Private `star_branchScale` has no binders and asserts conjugate(β)=β, using that β is real.
15. Private `branchScale_mul_self` has no binders and asserts ββ=(1/2:ℂ). It first proves (√2/2)²=1/2 over ℝ using `Real.sq_sqrt` and arithmetic, then transports the equality through the real-to-complex embedding.
16. Public `xBra_complete` has no binders and asserts Σm∈B B_m†B_m=I_W. Its proof checks every matrix entry using decomposition, finite sums, item 13, conjugation of β and β²=1/2. It does not say each B_m is an isometry or invertible. Each B_m maps an eight-coordinate vector to a four-coordinate vector.
17. Public `compiledAndBranch_eq_helper {R : Type*} (alpha : R→B→B→ℂ) (m : B) (r : R) (x : W)` gives ((J C_m B_m U J)v_r)(x)=T_m(α)(r,x 0,x 1,x 2). The proof derives `hgraph`, the whole vector equality for UJ, from item 10. It splits on x 2=0; in that branch it uses items 6–8 and hgraph, and collapses the sum over t to t=q(a,b). In the other branch both sides vanish. The local branch hypothesis x 2=0 is not a theorem premise.
18. Public `compiledAndCleanupKernel_eq (m : B)` asserts J C_m B_m U J=β • J as matrices W×D. By matrix-vector injectivity it suffices to test any v:D→ℂ and x:W. The proof constructs α on Unit by α((),a,b)=v(![a,b]), proves that this recovers v, applies item 17 and the helper simplification theorem, and uses item 6. Thus this is equality of full rectangular matrices, not merely an equality for normalized inputs or for a selected data subspace beyond the domain D itself.
19. Public `compiledAndBranch_mass {R : Type*} [Fintype R] (alpha : R→B→B→ℂ) (m : B)` asserts Σr∈R Σx∈W normSq(((J C_m B_m U J)v_r)(x))=inputMass(α)/2. It rewrites by item 17, uses `sum_work` to identify the sum with `branchMass`, and invokes `correctedTemporaryAndBranch_mass`. It has no normalization premise.

## Immediate ambient theorems

All these names are under `ASPBE.Uncompute.MBU`; their exact types and source bytes are preserved.

* `correctedTemporaryAndBranch_eq {R : Type*} (alpha : R→B→B→ℂ) (m : B) (r : R) (a b t : B)` asserts T_m(α)(r,a,b,t)=β (if t=0 then α(r,a,b) else 0). Its proof exhausts m,a,b,t and applies H entries. The outcome sign cancels the phase (-1)^(m q).
* `branchScale_normSq` has no binders and asserts normSq β=(1/2:ℝ). It uses normSq of a real scalar, `Real.mul_self_sqrt`, and real arithmetic.
* `correctedTemporaryAndBranch_mass {R : Type*} [Fintype R] (alpha : R→B→B→ℂ) (m : B)` asserts branchMass(α,m)=inputMass(α)/2. Its local per-(r,a,b) lemma sums t=0,1, uses the preceding two theorems and multiplicativity of normSq, then moves the factor through the finite sums.
* `outcomeMass_of_normalized {R : Type*} [Fintype R] (alpha : R→B→B→ℂ) (h : inputMass alpha=1) (m : B)` asserts branchMass(α,m)=1/2. This is the only explicitly normalized theorem in this immediate ambient file. Its `h` does not become a binder of any target theorem.
* `sum_branchMass {R : Type*} [Fintype R] (alpha : R→B→B→ℂ)` asserts Σm∈B branchMass(α,m)=inputMass(α), by adding two halves. It is contextual, not an explicit call in the target proof.

`StatementProbe.lean` contains seven `#check` commands for prospective proposition expressions. They are commands, not proofs, assumptions, axioms, or results read by this decoder. `TemporaryAnd.lean` ends with `#check` and `#print axioms` commands; no output from them was supplied or executed here.

## Algebraic construction and register meaning

For fixed r, the product gives the following exact coordinate sequence:

    v_r(a,b)
      -- J --> δ(t=0) α(r,a,b)
      -- U --> δ(t=q(a,b)) α(r,a,b)
      -- B_m --> H(m,q(a,b)) α(r,a,b)
      -- C_m --> s_m(a,b)H(m,q(a,b)) α(r,a,b)=β α(r,a,b)
      -- J --> δ(t=0) β α(r,a,b).

The data coordinates are preserved throughout this formula. The third coordinate begins in zero, holds q after U, is contracted out by B_m, and is reinserted as zero by the last J. `xBra` is the real Hadamard-row contraction, equivalently the plus/minus bra on the third coordinate; it is not the computational-basis bra. The matrix product is not an invertible operation on all W inputs: its domain is D and the initial J explicitly supplies the zero coordinate.

The outcome label m is an external Fin 2 argument, not a coherently manipulated register in these definitions. The statements retain exact phase β and prove identical branch kernels for both outcomes; they do not quotient global phases. If one separately interprets a unit-mass α as a normalized finite joint amplitude vector, each branch has squared norm 1/2. Renormalization would multiply the branch by √2 and recover Jv_r; no normalized conditional-vector definition or renormalization theorem is present in the target. Zero input is allowed and yields zero branch mass, so normalization cannot be silently performed for every public input.

R is a passive index carried unchanged in pointwise formulas, allowing arbitrary correlations of the amplitudes across r,a,b. For finite R, the summed joint-coordinate mass is included exactly. For arbitrary infinite R the pointwise statements remain meaningful but no ℓ² convergence or infinite mass theorem is asserted. There is no explicit tensor-product reference-system operator or density-matrix channel in the target; the identity action on the reference index is the pointwise content, not a separately supplied channel theorem.

Reinsertion of zero after contraction is the precise sense of cleanup here. It is not a theorem for a unitary reset gate, a trace/discard map, erasure of an arbitrary dirty ancilla, or a measurement apparatus. No post-outcome density matrix, partial trace, CPTP map, oracle contract, error tolerance or cost bound appears. C_m, B_m and J are mathematical matrices, not compiled primitive programs supplied by these files. Only U is connected here to an actual `PrimitiveProgram` supplier. The word `compiled` in theorem names does not alter this boundary.

## Visible supplier and dependency spine

The program supplier is not defined by the desired cleanup output. The inspected `primitiveCCXProgram` uses an H program, a middle program, and an H program, in that temporal order. The middle sequence, with controls a,b and target t, is

    CX(b,t), T†(t), CX(a,t), T(t), CX(b,t), T†(t), CX(a,t),
    T(b), T(t), CX(a,b), T(a), T†(b), CX(a,b).

H is represented by Rz(t,π) then Ry(t,π/2) with global phase exp(iπ/2). T is Rz(t,π/4) with phase exp(iπ/8), and T† uses both negative angles. CX has zero global phase. Program `seq` concatenates gate lists and adds stored global-phase angles. The evaluator applies a list's first gate first, with later gate matrices multiplying on the left; it multiplies the resulting circuit by exp(i times stored angle). This makes the phase-sensitive U equality substantive.

`MonomialProgram` carries a program, a basis phase, a permutation and a proof field `exact`. Constructors for CX, T and T† supply that proof from evaluation lemmas. Its `seq` constructs the composed proof using `evalPrimitiveProgram_seq` and `phasePermutationMatrix_mul`. The middle program's permutation is proved identity by bit cases; its phase is proved -1 only on a=b=t=1 and +1 elsewhere. These give `primitiveCCXMiddle_eval = cczMatrix`. The inspected supplier proves H conjugates that diagonal matrix to the CCX permutation by isolating the target bit with `splitPrimitiveWire`, using H²=I and HZH=X on each other-wire context. `primitiveCCXProgram_eval` then composes these equalities. Those are internal suppliers, not assumed public semantic certificates.

The target's visible mathematical call spine is:

    primitiveCCXProgram_eval + permutation pullback
      -> ccx3_mulVec -> ccx3_zeroInsert_apply
    zeroInsert/xBra/conditionalCZ entry sums + graph action
      -> compiledAndBranch_eq_helper
    helper finite-bit phase cancellation + helper bridge + mulVec injectivity
      -> compiledAndCleanupKernel_eq
    helper normSq factorization + finite sums + helper bridge
      -> compiledAndBranch_mass.

The J and C_m isometries and B_m completeness are independently established by finite matrix entries. They are not explicit prerequisites of the cleanup-kernel or mass proofs. Conversely the mass proof does not explicitly call the matrix cleanup-kernel theorem, although that equality also explains its mathematics. Exact proof-term dependencies, tactic-generated dependencies and all simplifier choices have not been exported. This spine records inspected explicit calls and mathematical structure only.

## Scope and unresolved trust boundaries

The target was read in full, including every proof, imports, namespace, open command and private simp annotation. The two immediate ambient files were read in full. Actual provider reading ranges and byte bindings are recorded separately. A hash inventory over the 30 supplied files is not a claim to have manually read them all. In particular the very large RobinMatrix and GHL2025 bodies and most indirect imports were not read. Mathlib source and imported tactic implementations were not read; no elaboration, build, axiom output, simulator or external result was run. No source-fidelity, publication-admission, novelty, physical-implementation, resource, or compiled-success verdict follows from this reconstruction.
