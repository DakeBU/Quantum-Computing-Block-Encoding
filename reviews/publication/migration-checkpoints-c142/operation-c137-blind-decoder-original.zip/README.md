# C137 independent formal-only decoder packet

Start with `reconstruction.md`. It reconstructs every target theorem (including private helpers), full-carrier definitions, basis/matrix/phase/register conventions, amplitude and mass meaning, and the actual explicit supplier route. `assumption-definition-audit.md` separates public binders from routine proof branches and audits literal definitions against circular desired-output definitions without using an unseen source.

`exact-declarations.json` stores lexical exact signatures for the three complete core files. `exact/OperationBridge.lean.base64`, `exact/StatementProbe.lean.base64` and `exact/TemporaryAnd.lean.base64` restore those files byte-for-byte by base64 decoding; the restored hashes are bound in the inventory and evidence. This is an exact source preservation mechanism, not a Lean executable or a claim that importing those files alone reproduces a build.

`provider-reading.md` and `provider-read-excerpts.json` distinguish actual continuous reading from static byte/import-header inventory. `input-inventory.json` hashes all 30 supplied files but does not claim full source admission. `evidence.json` records the assigned hashes and exclusions. `chronology.md` records event order. `public-safe-allowlist.json` defines release candidates only, not publication approval. `manifest.json` binds payload files, and `seal.json` binds the manifest with an explicit non-verdict boundary.

No paper/source comparison, scientific novelty judgment, physical/resource certification, compilation success, axiom-output result or publication acceptance is part of this packet. No subagent, network, Git, Lean, simulator, or provided packet script was used. Only static text/byte checks were executed.
