# Actual provider reading and dependency boundary

Line numbers below are one-based in the supplied masked formal files. The byte hashes in `input-inventory.json` bind the exact files. `provider-read-excerpts.json` stores the actual continuous ranges as normalized text; it does not contain or assert a full closure proof-term export.

| File | Continuous mathematical text read | Role |
| --- | --- | --- |
| OperationBridge.lean | whole file, lines 1–252 (plus terminal newline) | all 19 declarations/proofs and ambient scope |
| StatementProbe.lean | whole file, lines 1–61 (plus terminal newline) | all six definitions and seven check commands |
| TemporaryAnd.lean | whole file, lines 1–68 (plus terminal newline) | all six definitions, five theorem proofs and inspection commands |
| QuantumBlockEncoding/PrimitiveMacros.lean | 1–638 | all H/T/T†/CX definitions and proofs; monomial constructor proofs; complete CCX macro/evaluation spine |
| QuantumBlockEncoding/ReversibleClassical.lean | 1–83 | complete CCX action and self-inverse equivalence implementation |
| QuantumBlockEncoding/PrimitiveRefinement.lean | 1–38 | complete small import interface, including resource wrappers not used as target assumptions |
| QuantumBlockEncoding/PrimitiveSemantics.lean | 1–21; 80–82; 116–224; 238–245; 328–335; 380–404; 419–420; 445–467 | rotations, basis/actions, split/lift and entry proof, program/circuit semantics and composition law |
| QuantumBlockEncoding/PrimitiveCircuit.lean | 1–107; 207–227 | angle datatype/evaluation, gate/list/program types, program sequencing |
| QuantumBlockEncoding/Robin/ComplexLCU.lean | 1–65; 131–187 | rotation formulas; exact permutation matrix and complete multiplication-action proof |
| lean-toolchain; lakefile.lean; lake-manifest.json | complete configuration text | declared toolchain/dependency pins only, no installed-state or build claim |

The `ComplexLCU` span 131–145 is only an incidental tail of the preceding block-diagonal theorem; it is not a claim of having read that entire theorem. Likewise auxiliary unitarity material incidentally present in selected ranges does not expand the audit to every dependency of those auxiliaries.

Additional static navigation searched selected formal files for exact target/provider names and ambient/import commands. Header/name hits in `Core`, `ConcreteSemantics` and `BlockEncodingClassics` were navigation only. All 30 allowlisted files were read as bytes for SHA256 and their import headers scanned; the remaining mathematical bodies were not manually read. In particular no full reading claim covers `RobinMatrix`, `GHL2025`, `CircuitSemantics`, `BlockEncodingClassics`, `Hadamard8Verified`, or the rest of indirect imports. Mathlib, Lean core and tactic source were not inspected.

## Explicit suppliers actually traced

* `hadamardMatrix_apply` was read with its definition and proof. Its leaves include standard rotation definitions, finite matrix multiplication, trigonometric special values, complex i²=-1, and ring arithmetic. The rotation definitions themselves were read in the listed providers; Mathlib trig/proof implementations were not.
* `primitiveCCXProgram_eval` was read with the entire local chain: program constructors, `MonomialProgram.exact` construction, middle permutation and phase proofs, CCZ definition/evaluation, H² and HZH equalities, target-context block decomposition, and conjugation proof.
* The underlying `PrimitiveProgram` and `ExactAngle` definitions, program `seq`, `evalPrimitiveGate`, `evalPrimitiveCircuit`, `evalGlobalPhase`, `evalPrimitiveProgram`, circuit append proof and program sequence proof were read. Thus temporal order and stored global phase were not inferred from names alone.
* `ccxBasisAction`, its involution proof, and `ccxBasisEquiv` (both directions the same action) were read. X/CX bit actions and their involution proofs, as well as the target-wire split and lift entry formula/proof, were read.
* `equivPermutationMatrix_mul_apply` was read in full. It acts by the inverse equivalence on the row of its right factor. The target's special self-inverse CCX instantiation and Unit-column adapter were read in full.
* `phasePermutationMatrix` and its multiplication proof were read in full. The input-column phase convention is explicit.
* All five `TemporaryAnd` theorem proofs were read; only its equality and mass suppliers are explicit target calls. Its normalization theorem is a contextual corollary, not a target premise.

## External leaves not independently inspected

The target explicitly invokes standard matrix composition, injectivity, conjugate-transpose and scalar-action lemmas (`Matrix.mulVec_mulVec`, `Matrix.mulVec_injective`, `Matrix.smul_mulVec`, matrix entry formulas), finite equivalence/sum transport (`finTwoArrowEquiv`, `Fin.snocEquiv`, `sum_comp`, product sums and finite-sum commutation), and real/complex square-root, embedding and normSq identities. The proofs also use `fin_cases`, `simp`, `norm_num`, `nlinarith`, `ring`, extensionality and other tactics. Their source implementations and generated proof terms were not read. This packet reports no elaborated dependency or axiom list.

## Declared dependency context

The supplied toolchain text is `leanprover/lean4:v4.33.0`. The supplied manifest pins mathlib to `db584cd6d46c92f209a44c0f1c829460d327499d` and VersoBlueprint to `e0d667222e8222ac4bfd74780f69a2e89cd4655f`, along with its other listed packages. These are text observations only. No package installation, checkout, availability, source equivalence or successful compilation was checked.

The supplied formal mask labels itself bounded comment masking plus CRLF normalization, not a general Lean lexer. All 30 actual file hashes matched their `formal_sha256` metadata. The `raw_sha256` values for comment-bearing providers denote a different pre-mask byte object and were not substituted for the actual mathematical snapshot. The exact ZIP was hashed without extraction or execution.
