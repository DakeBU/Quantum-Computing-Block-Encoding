# Assumption and definition audit

## Ambient scope

`OperationBridge.lean` has three imports (`StatementProbe`, `Mathlib.Logic.Equiv.Fin.Basic`, `Mathlib.Data.Fin.Tuple.Basic`), a single namespace `ASPBE.Uncompute.MBU.OperationBridge`, and `open QuantumBlockEncoding`. There are no section variables, namespace-wide mathematical premises, target definitions, local notation declarations or target-level options. Its declarations are 19 theorem commands: 12 private (one private simp lemma) and seven public. `classical` appears inside proofs, not in theorem binders. Target source bytes, not an elaborated namespace expansion, govern these inventory statements.

`StatementProbe.lean` imports `TemporaryAnd`, declares the same nested namespace, defines six objects, and contains seven proposition `#check` commands. `TemporaryAnd.lean` imports `QuantumBlockEncoding.PrimitiveMacros`, declares `ASPBE.Uncompute.MBU`, defines six objects and five theorems, then has inspection commands outside the namespace. It has no hidden section variables. Exact signatures and bytes are retained in the companion artifacts.

## Public target binder expansion

| Target theorem | All mathematical/typing inputs | Logical premises |
| --- | --- | --- |
| ccx3_zeroInsert_apply | universe-polymorphic type R, arbitrary α:R→Fin 2→Fin 2→ℂ, r:R, x:WorkBasis | none |
| zeroInsert_isometry | none | none |
| conditionalCZ_isometry | m:Fin 2 | none |
| xBra_complete | none | none |
| compiledAndBranch_eq_helper | universe-polymorphic R, arbitrary α, m:Fin 2, r:R, x:WorkBasis | none |
| compiledAndCleanupKernel_eq | m:Fin 2 | none |
| compiledAndBranch_mass | universe-polymorphic R, `[Fintype R]`, arbitrary α, m:Fin 2 | finite-type structure on R, no proposition about α |

These are typing classifications within the formal text, not SOURCE/STANDING/RULED classifications against an unseen source. `[Fintype R]` supplies an actual finite enumeration for the real sums; it is not a normalization, oracle or desired-output assumption. The private generic sum lemmas take `[AddCommMonoid A]`, an algebraic structure needed for summation on arbitrary codomain A. This is internal library generality, not a public target premise.

Only the contextual `outcomeMass_of_normalized` theorem takes `h : inputMass alpha = 1`. No target theorem imports h as a binder. Fixed control-distinctness facts needed by the generic CCX supplier are proved for 0,1,2 by `decide`. The facts that 2≥0, √2 squared is 2, the branch's third coordinate is zero/nonzero, and individual bits are 0/1 are discharged internally. `hgraph`, `hv`, `hsum`, `ht`, `active`, context-equality cases, and case-split bit equations are local proof artifacts or routine branch assumptions. They are not universal public premises requiring an external supplier.

## Whole-carrier definition audit

All contract objects directly reconstructed are literal functions/structures, not characterized objects selected by existence proofs and not quotient representatives:

* Basis carriers are finite function spaces, with no omitted valid locus.
* `branchScale` is a specific real-to-complex embedding of √2/2.
* `andBit` is the total Boolean conjunction-valued function; its else value is the defined Boolean false value.
* `conditionalCZSign` is total ±1 on all m,a,b; its else branch is the specified inactive phase, not a failed-choice fallback.
* `correctedTemporaryAndBranch` is the explicitly gated phase/contraction amplitude. The t≠0 zero is its specified output support, not an unproved extension.
* `inputMass` and `branchMass` are finite real sums on their stated carriers.
* `zeroInsert` and `xBra` have literal zero entries outside their matching-coordinate conditions, so all off-support matrix entries are specified.
* `conditionalCZ` is a literal identity-permutation phase matrix, defined on all data basis pairs for both m.
* `ccx3Program` is a specific primitive-program macro with closed control inequalities; the macro expands to explicit program constructors. Its equality to a CCX matrix comes from a supplier theorem, not a definition of the evaluator in terms of the desired cleanup kernel.
* Relevant `phasePermutationMatrix`, CCX basis action/equivalence, target-wire splitting, one-qubit lifts, program sequencing and evaluation are all explicitly constructed. The equivalences contain inverse proofs, rather than an unspecified representative choice.

No direct desired-output cycle was found in the inspected definition/call spine: J,C_m,B_m use entry formulas; U is evaluated from the primitive list; T_m independently uses q, s_m and H; their equality is the target bridge; phase cancellation is a separate helper theorem. In particular `MonomialProgram.exact` is a proof field in an internal certificate structure whose actual constructors and uses were read and supply the field; no caller of a public target theorem must assume such a field. This statement is limited to the inspected spine and is not a global import-closure acyclicity/axiom audit.

No `axiom` declaration or `sorry`/`admit` proof placeholder appears in the three fully read core files. This lexical observation does not establish their elaboration or axiom dependencies. Imported Mathlib, tactics and unread provider bodies remain outside an axiom inspection claim. The literal `#print axioms` commands in the input are not axiom outputs and were not run.

## Semantic boundaries

The public equalities are exact, phase-sensitive and fixed-size; there is no approximation parameter. They apply to arbitrary complex amplitudes, not only product states, real amplitudes, normalized states or nonzero states. A reference index is passive, and the mass claim requires finite R. There is no public width parameter generalizing two data bits, no public cleanliness assumption for an arbitrary input work register (clean zero is explicitly inserted), no explicit density-channel/discard semantics, and no cost/implementation theorem for J, B_m or C_m. These exclusions come from the actual typed objects, not from an unseen natural-language goal.
