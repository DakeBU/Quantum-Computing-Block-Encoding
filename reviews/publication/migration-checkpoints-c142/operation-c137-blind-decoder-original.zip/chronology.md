# Observed work chronology

This is an ordered event log, not a fabricated wall-clock transcript. No per-event timestamps were available/recorded.

1. Received an independent formal-only decoding assignment, the two expected input hashes, an exact read/write boundary, and the prohibition on Lean/scripts/simulators/Git/network/subagents/other outputs.
2. First mathematical input read was `formal-inputs.json`. Read whole target, then immediate ambient `StatementProbe` and `TemporaryAnd`; no source statement or desired conclusion was read.
3. Read the expressly allowlisted governance documents (`AGENTS.md`, `HARNESS.md`, theorem-publication, proof-digestion, evidence-routed-memory). Combined displays initially truncated some governance output; subsequent bounded reads completed those documents. Governance was used only for process boundaries, never as mathematical evidence.
4. Checked SHA256 of the input JSON and exact ZIP. Both matched the assigned values. ZIP was not extracted or executed.
5. Used bounded exact-name static searches within the supplied formal snapshot to locate basis, matrix, evaluation and CCX suppliers. Read the continuous ranges now preserved in `provider-read-excerpts.json`, including the full `PrimitiveMacros`, `ReversibleClassical` and `PrimitiveRefinement` files. No live repository mathematical files were searched.
6. Read the three configuration files in full, as dependency context only.
7. Ran self-authored static byte/hash/import-header inventory across the 30 listed files, and a lexical declaration inventory for the three core files. All actual formal SHA256 values matched metadata. This was byte inspection, not Lean execution. Wrote only the new decoder output directory using patches.
8. One small line-count inventory command hit a PowerShell pipeline syntax error before running; it was corrected and rerun read-only. It supplied no mathematical evidence either way.
9. Wrote the reconstruction, assumption/definition audit, exact core source bytes as base64, exact lexical signature inventory, provider range excerpts, reading boundary, evidence and public-safe scope. No other agent results, author verdict, source statement seal, publication record or compiler output was consulted.
10. Performed only static artifact checks (byte hashes, base64 restoration hashes, lexical inventory counts and public-safe leakage scan). The later manifest/seal binds those already frozen artifacts. No compiler, packet script, simulator, Git command, network or subagent was run.
11. Freeze completion is a decoder artifact seal only. After sealing, stop mathematical work and report actual output hashes to the parent. There is no self-approval for publication, source correspondence or Lean acceptance.
