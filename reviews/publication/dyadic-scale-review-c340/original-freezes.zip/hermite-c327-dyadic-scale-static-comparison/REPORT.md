# C327 target-specific STATIC: C306 versus immutable C317

STATIC_MATCH at the source/statement layer only. No source mismatch or missing
mathematical case found for scaleDyadicBound. This is NOT compilation, actual
binary selection, axiom inventory, clean TCB, independent universal decoding,
producer/native/bit/quantum/scientific ROOT or publication acceptance.

## Exposure and exact comparison boundary

C317's source-first report/manifest/seal were frozen before this release and
remain unchanged. This turn read exactly the released C306
AllocatedDyadicScaleProof.lean, ExactChecks.lean and AUTHOR_FREEZE.json whole.
C306 DERIVATION and input-manifest remain UNREAD; C307 feedback/results/archives,
current worker/runtime material, C311 cost proof and C315 forensics UNREAD.
Author freeze's hashes of forbidden files are metadata only, not verified
payload reads. Verify only the two released Lean payloads against that freeze.

Retain prior same-chain supplier/cost/height authorship and old C147 lines1-32
partial-proof exposure, already disclosed and parent-acknowledged in C317.
No further C147 proof read. This is NOT fresh upstream/universal independence.
C317's historical UNREAD markers describe its earlier freeze; C306's three
allowed files are now exposed in this separately sealed static phase.

## Root, binders and literal definition audit

C306 public theorem is EXACTLY
HermiteAllocatedPolynomialCost.scaleDyadicBound : intendedScaleDyadicBound.
It unfolds that original predicate and introduces only k,n:Nat, epsilon:Rat
and hepsilon:0<epsilon. No epsilon<=1, k>0, n>0, L>0, value, degree, cost,
normalization or desired-scale premise is introduced. The local have-statements
are proved ingredients, not additional public assumptions.

The direct source import is AllocatedPolynomialCostInterface. The expected
C276 source (and C295 sealed body) defines the SAME
n+1+2*k+T(epsilon/(4*((k+1):Rat)^2)). Thus physical n_p=n+1, including n=0,
is preserved. No source definition, producer, tolerance or counter is changed.
The final right side is n+1+4*k+2+T(epsilon), not a substituted easier scale.

## Mathematical route comparison

1. hk proves k+1<=2^k by induction starting at0; the successor power rewrite
   and linear arithmetic cover k=0, not just positive k.
2. hfactor transports hk to rational casts, squares nonnegative quantities,
   multiplies by4, and uses pow_add/pow_mul to get exactly2^(2*k+2).
   The +2 is the factor4, not a dropped denominator or approximation.
3. hceil uses Nat.le_ceil and the actual max1 wrapper. hpow uses
   Nat.le_pow_clog with base2>1. hinv therefore gets 1/epsilon<=2^T(epsilon).
   This matches C317's equivalent ceil/clog-adjunction route without L>0.
4. hscaled uses the SAME rational epsilon/A, identifies its reciprocal with
   A*(1/epsilon), and applies mul_le_mul. Its two positivity subgoals concern
   reciprocal epsilon and the upper dyadic factor; they follow from hepsilon
   and base2 positivity, not a new caller promise. A=4*(k+1)^2 is also positive.
   The exact field/cast/power normalizations remain compiler obligations.
5. hcut unfolds the literal tailCutoff, applies Nat.clog_le_iff_le_pow, bounds
   the max1 by a natural power using one_le_pow₀, and bounds Nat.ceil through
   Nat.ceil_le plus the cast of hscaled. No real log, Int.ceil, floating value
   or asserted ceil-of-product equality replaces the original construction.
6. Unfold operationScale and use hcut in natural linear arithmetic. This is
   precisely C317's n_p+2*k+(2*k+2+L) <= n_p+4*k+2+L conclusion.

For epsilon>=1, L=0 remains valid: all powers and the max1 handling still work.
For k=n=0,epsilon=1, both sides are3; epsilon=4 yields1<=3. These hand checks
only discriminate seams; the quantified source argument, not examples, covers
all positive epsilon. C317's fixed-scale/unbounded-rational-height family still
prevents any inference that this scale controls native input bit height.

## Consumer, trust syntax and import boundary

ExactChecks assigns the closed original forall k/n/epsilon statement with
operationScale expanded and only0<epsilon as premise. It RETAINS tailCutoff
aliases rather than inlining Nat.ceil/clog; this is not a semantic mismatch
against the fixed literal definition, but it is not an independently inline
cutoff/TCB consumer. It also queries the original predicate type and root plus
consumer axioms. Queries are source commands, not observed axiom results.

Static text inspection finds one public theorem and no new axiom/opaque/
constant declaration, sorry/admit/unsafe/native_decide, #eval, set_option,
budget/linter/trust modification. Ordinary norm_num/gcongr/exact_mod_cast/
field_simp/positivity/ring/omega tactics discharge stated source obligations;
their actual elaboration and resulting theorem axioms are NOT checked here.

C306's direct import string does NOT identify an actual .olean. C276 in turn
imports AllocatedDegreeBudget and ExplicitFiveBlockCostProof; this static lane
does not certify their resolved binary paths or transitive closure. Expected
source pins match C317/C295; actual selection, toolchain, own-output consumer,
--deps and axiom inventory must be checked only after separate runtime release.
No C306 proof of either remaining C295 cost root is present or accepted here.

Handoff: qbe-substantive-worker; direction C295_FIRST_STATIC_ALL_POSITIVE_EPS.
Source graph matches the frozen ceil/clog/power scale spine. Lean source graph
adds one theorem and an expanded consumer; actual Lean binary graph is unknown.
Failure class NONE for STATIC source comparison; residual risk is compile/API/
actual import/axiom association, not a found mathematical counterexample.
No target change or discarded clause; prior freezes preserved. Complete protocol
intake and LOW-TOKEN-CONTROL-PLANE / VERIFIER-SEMANTIC-LEVEL retained. No parallel
route; Purification/Exposition-Seal NOT_STARTED. No compiler/lake/Python/project
script/Git/network/subagent or new proof search. Freeze and STOP before runtime
release; only the parent may authorize the next association gate.
