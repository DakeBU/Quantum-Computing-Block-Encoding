# C317 source-first baseline: scaleDyadicBound only

This is a target-specific internal source baseline, not a fresh universal
decoder, author-code review, compiler result or publication acceptance.
C306 proof/consumer/prose/manifest and C307 runtime remain UNREAD. C311 cost
proof and C315 forensics remain UNREAD. Earlier Hermite supplier/cost/height
authorship is retained. In locating C147, I read its old AllocatedDegreeBudget
lines1-32, including the beginning of tailCutoff_div_pow_two_le's proof; this
limited upstream fragment exposure was immediately disclosed and acknowledged
by the parent. No further C147 proof reading followed. No claim of blindness
to that old upstream proof; no claim of prior C306 actual-proof exposure.

## Literal target and primary semantics

C276 operationScale uses exactly A=4*((k+1):Rat)^2 and
M=n+1+2*k+T(epsilon/A), where
T(e)=Nat.clog 2 (max 1 (Nat.ceil (1/e))). The tailCutoff definition is at
FiniteExp.lean:20, not a new C147 definition. Natural ceil is NOT Int.ceil.
All k,n are naturals; only epsilon:Rat>0 is assumed; no radius R occurs.
The physical register count is n_p=n+1, including n=0 -> n_p=1.

The exact first sealed conclusion, with M expanded, is

    n+1+2*k+T(epsilon/(4*((k+1):Rat)^2))
      <= n+1+4*k+2+T(epsilon).

Other C295 roots (budget envelope and same-run ledger) are EXCLUDED here.
No degree, correctness, cost, normalization or epsilon<=1 premise is added.

Primary API facts read in raw source:
Nat.ceil_le: ceil(a)<=N iff a<=(N:Rat); Nat.le_ceil a; ceil_mono;
Nat.clog_le_iff_le_pow (1<2): clog 2 c<=u iff c<=2^u;
Nat.le_pow_clog (1<2) c; clog_one_right; clog_mono_right;
pow_succ, pow_add and pow_mul. These are exact order identities, not estimates
of executable ceil/clog/power cost. No floating/logarithm/transcendental API.

## Own reconstruction from literal definitions

Let L=T(epsilon), m=2*k+2 and P=2^(m+L):Nat. Since every power of2 is>=1,
the two ceiling/log Galois connections give, for any u:Nat,

    T(e)<=u  iff  1/e <= (2:Rat)^u.

Indeed max(1,ceil(1/e))<=2^u iff ceil(1/e)<=2^u, because 1<=2^u;
Nat.ceil_le then gives the stated rational inequality. In particular
1/epsilon <= (2:Rat)^L. No positivity of L is assumed.

For ALL k:Nat, k+1<=2^k: base0 is1<=1; the induction step is
k+2 <= 2*(k+1) <= 2*2^k = 2^(k+1), since k>=0. Squaring nonnegative
sides and multiplying by4 gives the EXACT rational-cast bound

    A=4*((k+1):Rat)^2 <= (2:Rat)^(2*k+2)=(2:Rat)^m.

A>0 and epsilon>0. Thus, with NO rounding equality assumption,

    1/(epsilon/A) = A*(1/epsilon)
      <= (2:Rat)^m*(2:Rat)^L = (2:Rat)^(m+L) = (P:Rat).

Ceil_le gives Nat.ceil(1/(epsilon/A))<=P. Also1<=P, so the actual max1
is<=P. Clog_le_iff_le_pow gives T(epsilon/A)<=m+L. Adding n+1+2*k
and reassociating natural addition yields n+1+4*k+2+L, precisely the target.
This derivation does not use the old C147 proof fragment as an inference edge.

Boundary checks by hand, NOT executed diagnostics: epsilon>=1 gives L=0,
not a negative precision. Allocation can still have nonzero cutoff: k=n=0,
epsilon=1 gives A=4, T(epsilon/A)=2 and M=3, equal to the upper bound3.
epsilon=4 gives allocated cutoff0 and M=1<=3. k=1,epsilon=1 gives A=16,
allocated cutoff4 and equality M=n+7. These are examples, not the uniform proof.

## Meaning, blind spots and next comparison contract

L is the least NONNEGATIVE dyadic exponent controlling the reciprocal tolerance.
It is not canonical Rat.num/den bit height: even size(2^r)=r+1 while clog2(2^r)=r.
For B>=1, epsilon_B=(2^B+1)/2^B>1 is reduced and has canonical height B+1,
but L=0. With k=n=0 its allocated reciprocal lies strictly between2 and4,
so allocated cutoff2 and M=3 for every B. This is a scope discriminator,
not a counterexample to the sealed scale inequality. Native input bit length,
ceil/clog/GCD temporaries, CPU, evaluator, physical sharing, synthesis, finite-SP
and the scientific ROOT are NOT certified by this parameter inequality.

After parent release, a separate STATIC comparison must check: actual A and
same M; no epsilon<=1 or L>0 restriction; k=0; n_p=n+1; exact Nat.ceil/max1;
square exponent2*k and factor4 -> +2; both positivity directions before
reciprocal multiplication; casts/power laws; and no extra value/cost premise.
C306 code and its actual type/axioms/dependency/runtime gate remain unknown here.

Handoff: qbe-substantive-worker; direction C295_FIRST_ALL_POSITIVE_EPSILON_SCALE.
Source graph is literal cutoff -> ceil/clog adjunction -> polynomial factor
dominated by a dyadic power -> same scale. No Lean implementation graph or
compiler verification claimed; source-level target is mathematically supported,
not author acceptance. Failure class NONE at this local mathematical layer.
No target change, discarded clause or alternate producer; all previous freezes
preserved. Complete protocol intake and LOW-TOKEN-CONTROL-PLANE /
VERIFIER-SEMANTIC-LEVEL retained. No parallel lane; Purification/Exposition-Seal
NOT_STARTED. No compiler/lake/Python/project script/Git/network/subagent or new
formal proof search. Freeze this baseline and STOP before author self-release.
