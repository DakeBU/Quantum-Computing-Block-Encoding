# C331: C307 recorded-runtime/source-to-binary association

RECORDED_ASSOCIATION_MATCH for the single scaleDyadicBound root. Source stage
recorded exit0/43.234s; own-output consumer exit0/40.562s; consumer stdout
prints the root and exact expanded-check signatures and ordinary three axioms
for each. This reviewer did NOT rerun Lean, wrapper, Python or any project script.
No clean-transitive-TCB, fresh universal decoder, producer/native/bit/GCD/CPU/
physical-sharing/finite-SP/scientific ROOT or publication acceptance follows.

## Inventory, inputs and immutable phase boundaries

Inventory first found actual hermite-c307-allocated-dyadic-scale-proof, WITHOUT
the initially supplied -gate suffix; parent separately confirmed this correction.
Wrapper is run-c307-allocated-dyadic-scale-proof-gate.py. No path was guessed.
Read whole plan/result, both feedback files and allowed wrapper; inspect only
PRIVATE-runtime-records.zip, in memory via read-only .NET streams, no extraction.
The two live ZIPs were inventory names only, not opened.

C317 source-first and C327 STATIC freezes stay unchanged. C306 proof/consumer/
freeze were previously source-released; C306 DERIVATION/input-manifest remain
UNREAD. Their paths/hashes in freeze and wrapper code are metadata, not payload
reads. C311/C315/other-worker packets remain UNREAD. Prior same-chain author
roles and old C147 lines1-32 partial-proof exposure remain; no further C147
proof read, no fresh upstream/universal-independence claim.

## Recorded command and dependency chain

Use aliases OWN=C307 directory, INTERFACE=C283 type-probe directory,
REPOSITORY=repository, TOOLCHAIN=recorded prefix. These are not new paths.
The current wrapper hash matches result.runner_sha256. Its exact command
construction, ZIP prefix and requested-LEAN_PATH reconstruct:

    TOOLCHAIN/bin/lean.exe --root=OWN --deps OWN/<Module>.lean
    TOOLCHAIN/bin/lean.exe -M 3072 -j 1 --root=OWN \
      -o OWN/<Module>.olean OWN/<Module>.lean

Both run with cwd=REPOSITORY and LEAN_PATH beginning OWN;INTERFACE;inherited-tail.
Wrapper uses30s deps timeout and120s/module compile timeout; available memory
must be>=5120MiB, including2048MiB reserve beyond3072MiB cap. Records report
6880/6932MiB available. These are recorded parent windows, not kernel/native
benchmarks or measured peak memory. No separate captured argv/execve log exists:
argv association comes from the hash-bound wrapper, not an independent trace.

ZIP direct deps are exactly Init.olean twice plus:

- proof -> INTERFACE/AllocatedPolynomialCostInterface.olean
- consumer -> OWN/AllocatedDyadicScaleProof.olean

Both deps stderr members are empty. Successful deps status is inferred from
the wrapper's guard plus PASS records; PASS rows do not separately store a deps
exit-code field. These short lists are DIRECT selection evidence, not a dump
of all transitive source/binary providers. The inherited path contains repeated
interface entries, older Hermite caches, repository/package/Mathlib libraries.
Nothing here rebuilt that tail or established a fresh entire TCB.

## Byte/hash and statement association

Recorded plan/result source hashes equal C306 freeze and C327 static pins, and
the current C307 staged .lean files match those exact hashes. The plan's binary
pin matches the CURRENT executable resolved from prefix.stdout. The recorded
directory names Lean4.33.0; no --version stream is present, and none was run here.

| object | recorded and current SHA256 prefix |
| --- | --- |
| lean.exe | dd86e9b24990b1da |
| selected interface | 21d6f815275211a4 |
| new proof own output | 6e7f984fc352752a |
| consumer own output | 8b9dfd7cb23509ce |

Full hashes and ZIP member byte lengths/digests are in INPUT_MANIFEST.json.
The interface hash matches C295's selected C283 output binding, which links to
C276's sealed source hash464a3aab...; it was NOT rebuilt from source here.
The proof own-output hash appears in the consumer's selected-provider row and
the recorded deps path is the OWN proof, not a historical same-name module.
ZIP contains streams/path metadata, NOT copies of source/executables/oleans;
current matching hashes are a second consistency observation, not historical
bytes freshly recreated or independent execution attestation.

All four compile stdout/stderr member hashes match proof-result. Raw stdout
lengths836/851bytes are complete; stderr is empty. Both current feedback texts
match the wrapper's sanitized streams after newline normalization. No truncated
6000-character excerpt hides a diagnostic. Source warnings retain unused/
unreachable ring and unnecessary sequencing; consumer retains defProp warning.
These are recorded warnings, not errors; no linter option was disabled here.

Consumer prints scaleDyadicBound : intendedScaleDyadicBound and, for all k/n
and epsilon, only0<epsilon -> n+1+2*k+T(epsilon/(4*(k+1)^2)) <=
n+1+4*k+2+T(epsilon). This is C317/C327's exact local scope, with T aliases
still retained. Both root and C306ExactChecks.scaleDyadicExpandedCheck print
EXACTLY {propext, Classical.choice, Quot.sound}. Independently inspect raw
names as a case-sensitive three-element set; no supplied parser execution.
Source row's axiom_reports=[] is NOT an empty-axiom proof: source emitted no
axiom queries; the consumer's two actual rows supply the evidence.

## Limits, anomalies and handoff

Legacy plan/result schema and wrapper docstring say "height" although this is
the dyadic-scale run. Resolve identity using root name, module source hashes,
direct deps and actual printed statement, not those reused descriptive labels.
No metadata or historical file was repaired. Reviewer initially compared a
locale-sorted axiom string to ordinal order and got false despite the same three
names; corrected to exact case-sensitive set membership. This was a reviewer
mechanical-check ordering issue, not a C307 failure or allowlist/verifier change.

Wrapper verify() checks many author/seal/manifest pins pre/post and result says
pins_unchanged_pre_post. This review did NOT execute verify(), read forbidden
author manifest/prose, or inspect imported transport/parser helper code. Thus
do not promote that field to an independently re-audited whole input/TCB closure.
Direct released source/output/current binary checks above are separately done.

qbe-substantive-worker handoff: C295_FIRST_RECORDED_RUNTIME_ASSOCIATION;
source/STATIC spine matches the observed local theorem consumer, but direct
binary association and transitive Lean/source graph remain distinct. Failure
class NONE for this bounded association; no missing key record, no target
weakening. Warnings/anomalies retained. Complete protocol intake and
LOW-TOKEN-CONTROL-PLANE / VERIFIER-SEMANTIC-LEVEL retained; no parallel route.
Purification/Exposition-Seal NOT_STARTED. Parent may reconcile C317/C327/C331
as local evidence only; other cost roots and scientific/native gaps stay open.
Only new review/manifest/seal via apply_patch. No compiler/lake/Python/scripts/
Git/network/subagents or ZIP extraction. Freeze and STOP.
