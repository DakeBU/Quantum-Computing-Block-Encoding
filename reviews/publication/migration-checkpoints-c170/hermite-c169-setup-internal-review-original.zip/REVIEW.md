# C169 independent setup-value static review

Classification: `INTERNAL_STATIC_REVIEW`. No mathematical mismatch or missing
premise was found in the exact C166 candidate's eight private helpers and one
public `rightSetup_values` statement. The public type matches C156 after
whitespace removal; the proof hash is the requested
`3ebf1cfe0af3cf4e64679a1f31c09bcfa3f681eb5e37b2386c81ca3792c9a298`.
This is not compilation/axiom acceptance, runtime association, a cost theorem,
Source Anchor, Proof Seal, public-source final review or scientific ROOT.

## Chronology and scope

The reviewer already has distinct C147 and C157 runtime exposure through the
earlier authorized stages. This is a new task-specific internal review, not a
fresh universal source-blind decoder. C161 and C164 remain frozen. For this
task the actual C150 executable definitions, exact sealed setup statement and
canonical target/primitives were read before the whole C166 proof. No C162
audit, C166 manifest/repair rationale, C165/C168 result/log/runner, author
consumer, PR/report or other review was opened. The filename's repair label
does not supply a prior-attempt diagnosis or minimal-repair verdict here.
No setup runtime output has been received or used.

Scope is the returned setup's four cuts, full factorial-reciprocal tail vector,
clipped scalar and midpoint only. The proof preserves arbitrary rational R and
delta, natural n, and the existing physical parameter convention n_p=n+1.
There are no positivity, caller-supplied table correctness, cutoff correctness,
desired-output, normalization or cost-bound premises.

## Derivation from literal bodies

Run.pure returns its scalar, charge returns its charged scalar, bind returns
the next Run's value at the preceding value, and collect returns each executed
entry's value. Their cost components do not alter these value equations. This
does not say those components or the executed operations cost zero.

Set

    T = tailCutoff delta = clog2(max(1,ceil_N(1/delta))),
    d = sourceDegree delta = degree T T,
    w = n+1, cap = 2^w, step = (2*R)/(2:Rat)^w.

Actual cutoffQ first returns the rational reciprocal, so its returned natural
is exactly T by unfolding. Actual gridStepRun computes the rational power via
powQ and then multiplication/division, hence returns step. qSub 0 T returns
the rational -(T:Rat), not truncated natural subtraction. Actual rightSetup
uses this same returned cutoff for its degree and later scalars.

### Four cuts, including zero/negative radius

For arbitrary natural cap and rational R,step,s, the actual helpers return

    strictCutFrom.value = min cap (ceil_N((s+R)/step)),
    inclusiveCutFrom.value = min cap
      (if (s+R)/step<0 then 0 else floor_N((s+R)/step)+1).

The inclusive helper executes a Bool `decide` comparison but retains exactly
the canonical negative-quotient branch. It does not replace the raw result by
floor_N(q)+1 for negative q. At q=0 that branch is false and raw is 1; cap=0
is also covered in the generic helper by min(0,raw)=0. The strict helper is a
literal value projection; neither helper divides inequalities by step or
assumes its sign/nonzero status.

Substituting the generated step, cap and thresholds -1,0,-T,T gives precisely
strictCut(w,R,-1), inclusiveCut(w,R,0), inclusiveCut(w,R,-T), strictCut(w,R,T),
the four sealed targets in their original order. This substitution is valid
also for negative R because it is equality of literal formulas, not a claim
that a negative grid step preserves inequality direction.

At R=0, step=0 and Lean's total rational division gives (s+R)/step=0 for every
s. Therefore the two strict outputs are 0 and the two inclusive outputs are
min(cap,1)=1 since public w=n+1>=1. The actual four outputs are 0,1,1,0. This
deliberately retains the canonical zero-radius off-positive-locus behavior;
it is not an all-grid-point threshold-count theorem at R=0. The canonical
threshold-correctness result has its own R>0 domain, which is not silently
imported into, or proved by, this unconditional value equality.

### Actual generated factorial table and full tail range

The canonical factorials producer begins with values=[1], next=1. At successor
stage r+1 it reads the previous final r!, multiplies by previous.next=r+1,
increments next to r+2, and extends the old vector by (r+1)!. The actual
factorials_next/factorials_value proofs establish these properties by induction;
their full relevant implementations were read. Thus for every i:Fin(d+1),

    (factorials d).value.values[i] = (i.val! : Rat).

Actual collect in rightSetup reads this generated vector at every such i and
executes qDiv 1 denominator, so its returned tail entry is exactly 1/i!. The
range is all 0..d, including both 0 and the last index; no prefix/last-entry
omission is hidden. The helper accepts the actual factorials-generated table,
not an arbitrary table plus an assumed `correct` predicate. No nonzero-
denominator premise is inserted: the generated factorials are positive anyway,
and the target is itself the same rational reciprocal, not a division
cancellation requiring an unproved side condition.

The source's equality hd transports Vector length from degree(cutoffQ.value,
cutoffQ.value)+1 to sourceDegree(delta)+1. Those natural lengths are
definitionally equal from the literal cutoff/degree definitions. This transport
changes neither entries nor the full range. In particular hd is an index
transport fact, not an assumed final setup-value theorem. The final source
`change` uses these same definitional reductions; actual elaboration remains
outside this static review.

### Clipped scalar and the exact midpoint branch

powQ 2 T returns 2^T. The two successive qDiv operations in clippedRun therefore
return (1/(2:Rat)^T)/2 = tailRadius(T)/2. With the generated T this is precisely
canonical clippedValue(delta); there is no new clipping threshold or fallback.

For any naturals T,d, actual midpointFrom on the actual generated factorial
table and this clipped scalar returns

    tailRadius(T)/2                    if T<=1,
    sum_{i=0}^d (-1)^i/i! = poly(-1,d)  otherwise.

The active branch computes every sign through powQ, reads every generated
factorial and divides, then uses actual sumEntries. Its induction/value theorem
and the Fin(d+1)-sum to range(d+1) identity retain the full finite range. The
generic helper works even for d=0; the public generated source degree is not
silently substituted by a desired degree.

The original bounds(-1,T,d) tail test is `(-1:Rat)<=-(T:Rat)`, exactly equivalent
to T<=1 by rational order and the natural cast. At T=1 equality belongs to the
tail branch, not the active branch. Consequently its average is

    (0+tailRadius(T))/2                if T<=1,
    ((P-radius(-1,d))+(P+radius(-1,d)))/2 = P otherwise,
    P = poly(-1,d).

The radius cancels only in the average by exact algebra; it is not removed
from the enclosure, changed to zero, or assumed small. These are definition
identities and require neither delta>0 nor an exponential error estimate.
They prove midpointFrom equals this exact bounds average. Substitution of the
generated T,d gives canonical expMidpoint(delta).

Useful exact boundary cases are:

| cutoff | generated degree | clipped | midpoint branch/value |
| --- | ---: | --- | --- |
| T=0 | 1 | 1/2 | tail, 1/2 |
| T=1 | 7 | 1/4 | tail, 1/4 |
| T>=2 | 4T^2+2T+1 | 1/(2^(T+1)) | active, poly(-1,d) |

For delta=0, total reciprocal 1/0=0 makes cutoff zero; for delta<0, natural
ceil of its negative reciprocal is zero, again cutoff zero. Thus these cases
retain degree 1, full two-entry tail [1,1], clipped=midpoint=1/2. Positive
delta>=1 also has T=0; delta=1/2 supplies a T=1 example. These statements do
not create an approximation-error guarantee for zero or negative tolerance.
No finite diagnostic was needed to establish the symbolic cases.

## All helpers, binders and topology

All eight private helpers were inspected completely:

- c162_strictCutFrom_value and c162_inclusiveCutFrom_value unfold the actual
  arithmetic/comparison Runs and preserve their literal two cut formulas.
- c162_clippedRun_value uses actual powQ_value and tailRadius.
- c162_tail_entry uses actual collect/read/div values and factorials_value,
  without arbitrary-table correctness binders.
- c162_midpointFrom_value splits T<=1, then uses actual sumEntries/powQ/read/
  factorial values and the exact Fin-to-range sum identity.
- c162_tail_test proves both directions of the natural/rational branch test.
- c162_bounds_midpoint preserves that branch test and performs exact radius
  cancellation only in the active average.
- c162_midpoint_literal composes the preceding two equal piecewise values.

The public theorem unfolds the actual returned setup, proves the seven
conjuncts using those helpers and gridStepRun_value, and substitutes the literal
clippedValue/expMidpoint definitions. The complete AND-tail is four cuts plus
tail entries plus clipped plus midpoint; no one component is treated as
sufficient for the whole setup. This is a static mathematical/reference
topology, not an elaborated dependency graph or full construction root.

Every binder is natural/rational input data, or an actual Fin index for its
generated vector. No project-owned Prop bundle, cost/correctness oracle,
positivity/normalization premise, default-target redefinition or external
choice witness is added. The imported C157 primitive values are dependencies
already independently statically derived, not new caller assumptions. Literal
arithmetic equalities at invalid scientific parameters are not promoted to
physical threshold/state correctness there.

## Limits and compact handoff

This target has no cost conclusion. The manual addition of cutoff.cost to
result.cost in rightSetup remains present in the executable body; taking
.value for this proof does not certify that cost is zero, small or native
runtime. No middle coefficient/value theorem, actual_cached_right, whole
producer/refinement/same-run result, or existing state/error-budget change is
proved. Captured actualBlocksQ construction, eager/shared evaluation, kernel/
left work, native integers/conversions/ceil/floor/clog, rational bitlength/GCD,
allocation, gates/synthesis/ancilla/cleanup/export remain outside scope.

Objective/delta: independent exact-value and binder audit of this one sealed
setup-value target and eight helpers, preserving all boundary cases.
Failure class: NONE for discovered mathematical mismatch; no claim about the
unopened runtime or earlier repair attempts. No route discarded or salvaged.
Named evidence: exact raw inputs/read extents in INPUT_MANIFEST; one public/eight
private declarations; requested source hash and sealed-type comparison; no
compiled axiom list, no independent rerun and no finite test substitute.
Process-memory: none; required substantive-worker protocols already fully read
in this worker's retained context. No other review/author explanation used.
Direction/independence: parent-authorized distinct static task after earlier
C147/C157 runtime stages; no subagents, comparator or fresh decoder claim.
Purification/Exposition Seal: not issued; internal value interface only.
Files/actions: only new C169 artifacts via apply_patch; read-only PowerShell
retrieval, region reads, hashes/text comparisons and parent messages. No
compiler/lake/provided scripts/Python/Git/network, source editing or runtime
packet access. No tooling failure occurred in this stage.
Residual risk: actual elaboration, compiled dependency association and all
resource/scientific gates unassessed. Recommended next step is separate
authorization for runtime association if desired, preserving this static
record unchanged. Stop at this freeze; C161/C164 remain byte-identical.
