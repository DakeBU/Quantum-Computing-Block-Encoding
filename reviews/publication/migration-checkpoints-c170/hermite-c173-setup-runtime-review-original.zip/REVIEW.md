# C173 separate setup runtime-association review

Classification: `INTERNAL_RUNTIME_ASSOCIATION_REVIEW`. The inspected records
consistently associate the exact C169-reviewed repaired source with C168's own
output, the unchanged consumer's full seven-conjunct type, and the actual root
axiom reports. No concrete mismatch was found in that bounded association.
This is not an independent compiler rerun, printed-definition audit, clean TCB,
Source Anchor, Proof Seal, public-source final review or scientific ROOT.

## Chronology and exact repaired-run binding

C169's static seal `7e3d83332fb37e36f11302f5a25512bc8538352c92834017507bdaa6e11394d4`
was read/verified by the parent before this separate authorization. Its seal
and two payloads remain unchanged. This same reviewer already has C147/C157
runtime exposure; new setup runtime and repair metadata were opened only in
this authorized stage. C169's mathematics is not rewritten or repeated here.

C168 staged source and its original-source ZIP member both match the reviewed
source `3ebf1cfe0af3cf4e64679a1f31c09bcfa3f681eb5e37b2386c81ca3792c9a298`.
The actual own proof output hashes to
`db76fdae3df6f48bf4e3c853691490c6275d5fc41ee1ae4c98efb8bc5ebb9610`;
the consumer output hashes to
`07cf26a46cc8565cf5dca879cde9449ab0b697d977f052e63919cec9cb6d8bd5`.
Both match the recorded outputs. The consumer source/archive member has
unchanged hash `7d256a75b58528ebecde78ff462eb5a54e69447f9e45ce1114146c69f3f736c3`.

The whole inspected C168 runner creates an exclusive stage, copies archived
sources, verifies pinned inputs, and invokes a direct pinned Lean executable
with own stage root/output, memory limit 3072, one thread and timeout 180 seconds.
Its actual hash matches the wrapper digest in the record. Raw requested paths
match its constructed order: own stage, primitive stage, typed-provider stage,
five inherited caches, project output, package path. Actual proof `--deps`
selects the hash-pinned C159 CachedPrimitivesProof.olean
`77547431cc9e4759adcd8c25f6a3e57622da492bdb31ac36f2061ab06e50d473`;
actual consumer `--deps` selects C168's own CachedSetupProof.olean. These are
checked exact provider paths, not only same leaf names. Recorded exits are
zero/no timeout (30.0 and 22.406 seconds), and actual direct stderr is empty.
Public feedback was independently reconstructed exactly from private stdout
using the runner's substitutions/newline rule, with no raw host paths copied.

The consumer uses an explicit `#check (rightSetup_values : full sealed type)`.
Its actual output retains all four cuts, the forall over Fin(sourceDegree+1)
tail entries, clippedValue and expMidpoint, with only n:Nat and R,delta:Rat.
The printed local `have s := ...` is the let-bound returned setup, not a caller
correctness premise. The ascription matches the old/new public type and C169's
sealed target. Both C168 proof and own-output consumer have exactly one actual
root row `[propext, Classical.choice, Quot.sound]`, with no sorryAx or other
added axiom. The universe-aware parser is unchanged; raw row contents were
read directly, not inferred solely from `PROOF_AND_AXIOM_PASS`.

## Original failure and exact proof-only repair

The preserved C165 source/archive matches C162 source hash
`d274c01e42e0a296257d299b890c613324f82f84e602f73c89eebcd0bfc48a54`.
Its record reports exit 1/no timeout, one failed module, no own output and zero
proved roots. The failed stage has neither proof .olean nor consumer .olean.
The raw transcript reports two errors at the inclusive-cut goals (lines 134 and
140), not a false equality or bad numerical example.

Specifically, rewriting step to gridStepQ under an `if q(step)<0` attempted to
abstract step as `_a` while keeping a Decidable argument of type
Decidable(q(step)<0). The new ite expects Decidable(q(_a)<0), so that rewrite
motive is ill-typed. This is a dependent-instance tactic/implementation failure.
The mathematical literal equality is unchanged; no R>0 or delta>0 premise
would be justified as a repair of this tactic mechanism.

Lean's diagnostic continuation prints a root axiom row containing sorryAx
after those errors. The raw submitted source contains no sorry/admit/axiom
stub. Here the sorryAx is error-recovery evidence, not an accepted theorem:
exit 1, the ordinary-axiom check is false, the gate stops, no binary is produced
and the consumer is not run. The record appropriately rejects this artifact.
Failure class is `IMPLEMENTATION_FAILED`, not REFUTED or SOURCE_INVALID.

Applying exactly the two proof replacements in the repair metadata, each
occurring once, reconstructs the entire C166 proof text from C162. At the zero
and minusT inclusive-cut goals, the pair `rw [gridStepRun_value]; rfl` becomes
`simpa only [gridStepRun_value, HermitePiecewiseUniform.inclusiveCut]`.
This lets simplification handle the dependent ite/Decidable context while
unfolding the same canonical definition. No executable definition, helper
statement, public type, guard, finite range or premise changes. Consumer bytes
are identical across C162, C166, C165 and C168. All twelve C169 raw/seal/canonical
input hashes remain unchanged; the C150 executable definitions retain their
pinned bodies. This supports a proof-only implementation repair, not a new
mathematical contract or a root correction.

The four recorded runner replacements exactly reconstruct C168 from C165:
author packet, author-manifest hash, stage and schema name only. No parser,
allowlist or ordinary-axiom acceptance rule is weakened. The preparation helper
was read but not executed. The copied audit narrative was not opened or
treated as a new runtime record; the explicit repair metadata and raw sources
were checked directly.

Warnings are preserved, not silently repaired: both old/new logs contain
unused simp arguments pure and Run.pure at line 51; the repaired log additionally
retains unnecessary-simpa style warnings at lines 134 and 139. They are warnings
in the recorded exit 0 run, not remaining proof failures or missing conjuncts.

## Assurance and resource boundary

The relevant primitive provider is still the inherited C159 binary, whose
limited C155/C156 provenance was separately reviewed in C164. This stage does
not newly rebuild or print those provider definition bodies. It also does not
print the new setup proof's bodies; the consumer gives type and axiom output.
No full transitive source-to-binary audit is implied by importing a pinned
provider. Raw preliminary Lake queries retain the verso-local-changes warning;
the direct compiler stderr is empty. Requested paths and separate direct-deps
queries are not complete transitive effective-loader traces, atomic filesystem
snapshots or signed historical-process attestations. The executable's current
hash agrees with the recorded pin; that is not a fresh execution by this reviewer.

The outcome is the same setup-value conjunction independently derived in C169,
not setup cost, captured actualBlocksQ sharing/eager-work control, middle/right
value consumers, whole-chain refinement or full same-run producer correctness.
Native integer/ceil/floor/clog, rational bitlength/GCD, allocations, synthesis,
gates, ancilla/cleanup/export and scientific error/root gates remain outside
scope. No old exact-real bond or zero captured-block cost is imported as credit.

Compact handoff: exact record association and an independently checked
proof-only failure/repair mechanism are the delta; ordinary record integrity
and inherited-dependency limits remain. Required role protocols remain in this
worker's prior context; no new process-memory items, comparator or Exposition
Seal are issued. No other review, PR or public status packet was consulted.
All actual actions were read-only PowerShell retrieval, in-memory ZIP hashing,
text/type/patch comparisons, metadata checks and parent messages, plus
apply_patch for new C173 files. No compiler/lake/provided-script/Python/Git/
network/subagents, archive copying, prior-file modification or tooling failure
occurred. Input/read-extent bindings accompany this report. Stop after the
separate freeze; stronger rebuild/publication/root evidence needs its own scope.
