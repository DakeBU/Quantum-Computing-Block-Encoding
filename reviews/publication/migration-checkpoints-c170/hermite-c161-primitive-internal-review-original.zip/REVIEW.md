# C161 cached-primitives independent internal static review

Classification: `INTERNAL_STATIC_REVIEW`, primitive value and partial-counter
slice only. This is not a source-blind external decoder, Source Anchor,
Proof Seal, source-publication final review, clean-TCB certificate, native
runtime/gate theorem, or scientific ROOT admission.

## Outcome

No mathematical mismatch was found in the seven public statements and six
private helpers in the actual C157 proof source under their stated binders.
The independent derivation below checks the exact literal C150 operations,
unchanged canonical Run/tick/read/collect/total machinery, and canonical value
specifications. All seven public statement texts match their C156 sealed
statements after whitespace removal; all three reviewed C150 definition hashes
and seven relevant canonical-source hashes match the C156 seal.

These are static mathematics/source findings, not Lean elaboration, compilation
or axiom-output findings. The `#print axioms` lines in C157 were read as command
text only. No C159 output or C160 report/status/source-binding packet was opened.
No author audit, gate-plan, manifest explanation or later consumer proof was
read. No verdict about these candidates compiling is inferred.

The principal cost statement is valid but deliberately loose. `acceptRun` has
an exact branch-dependent total of 1, 2 or 3 comparisons, plus one field tick
if flipped. An arbitrary `rightProduct` retains the coefficient Run's entire
cost and adds the two accept costs and two multiplications. Its pure/read
specializations have generic upper bounds 10/11, respectively. In the actual
five `rightEntry` branches, the flip patterns sharpen those upper bounds to
8/10/10/10/10. Thus the sealed uniform bound 11 is conservative, not a mismatch
or minimality claim.

## Role and exposure chronology

This is the same internal reviewer who authored C151 before C147 runtime
exposure, then separately performed the authorized C154 runtime-association
stage for C147. This reviewer is not fresh or generally runtime-blind. C151
and C154 retain their original classifications and are not rewritten here.
Their earlier exposure concerns a different degree-provider slice; no target
C157 runtime evidence is available in this stage.

For this distinct task, the C150 three executable modules were read whole,
then a combined C156 seal/signature/C157 proof retrieval was display-truncated
inside the seal's large inherited-binary map. The complete proof text was
visible in that result before the complete seal map was visible. This procedural
incident was promptly disclosed to the parent, not silently treated as a full
seal-first reading. The complete C156 seal was then reread in four nontruncated
chunks (1-100, 101-180, 181-260, 261-315); the complete signatures and raw proof
were reread before substantive derivation. The relevant canonical operation
definitions and target specifications were then inspected. No author rationale
or actual target runtime outputs entered the derivation.

The parent later supplied a status-only message that a previously running
aggregate Lean/Tests/baseline CI had reached success. That message arrived after
the independent branch/counter derivation had been sent to the parent. No CI
record was opened and the status is not used as evidence that this candidate
compiled, passed axioms, or reached a scientific root. C159 remains withheld.

The C156 seal itself carries earlier type-probe metadata and narrative; reading
it necessarily exposed those seal assertions, but no probe receipt, binary
audit or actual output was consumed. Its statements are not independent runtime
evidence in this packet. The seal also names prior-review files as hash entries;
those contents were not opened or consulted.

## Model reconstructed from actual canonical bodies

`Op` has exactly eight constructors: field, sqrt, angle, trig, compare, read,
write, emit. `Cost = Op -> Nat` is a nonnegative integer counter vector. For a
constructor p, `tick p` has entry 1 at p and 0 elsewhere. `total C` is the sum
of exactly these eight entries, without weighting or a hidden additional cost
counter. A Run is the literal pair `(value,cost)`.

Writing e_p for tick p, the canonical equations are

    pure(x) = (x,0),
    bind((v,C),f) = (f(v).value, C+f(v).cost),
    charge(p,x) = (x,e_p),
    read(xs,i) = (xs[i],e_read),
    qMul(x,y) = (x*y,e_field),
    qDiv(x,y) = (x/y,e_field),
    qSub(x,y) = (x-y,e_field).

The qMul/qDiv definitions are the canonical charged-cache primitives; qSub is
the literal C150 wrapper. Pure/bind/charge are not operational timing semantics
for arbitrary expression evaluation. In particular, a scalar expression
placed inside pure or charge does not thereby have zero native cost or unit
bit complexity.

For completeness, actual `collect f` first stores a vector of Runs and returns
their values with counter

    sum_i (f i).cost + length*(2*e_read+2*e_write).

Its total adds 4*length to the element totals. This is relevant to eventual
consumer composition but is not charged again inside a single `rightEntry`.
It is not an allocation, garbage-collection, bit-access or compiled evaluation-
sharing theorem. `sumEntries`, inspected in its canonical source, recursively
executes every entry and one qAdd per entry, starting from pure zero. The actual
factorial/chooseFrom cache definitions were also inspected as context for the
C150 modules; no new proof of middle/cache/setup correctness is inferred.

Since function addition of Costs is pointwise and total sums all eight entries,

    total(A+B)=total(A)+total(B),
    total(e_field)=total(e_read)=total(e_compare)=1,
    total(0)=0.

These equations are arithmetic facts of the actual bodies, not caller-supplied
oracle hypotheses. Natural counter arithmetic does not overflow mathematically;
no bound on its native integer representation or evaluation cost is proved.

## Independent value and counter derivation

### 1. powQ_value and powQ_cost

The executable recursion is

    P(x,0)=pure 1,
    P(x,m+1)=bind(P(x,m), y -> qMul(y,x)).

Thus its value V satisfies V_0=1 and V_(m+1)=V_m*x. Natural-power induction gives
V_m=x^m for every rational x and natural m. In particular x=0,m=0 returns 1
and agrees with 0^0 in this algebraic convention; x=0,m>0 returns zero.
Negative, zero and fractional x need no extra premise.

Its cost C satisfies C_0=0 and C_(m+1)=C_m+e_field. Therefore C_m=m*e_field
pointwise, exactly the sealed op-indexed formula `m*tick .field op`. The
iteration executes m charged multiplications even when x=0,1 or -1; no such
special value short-circuits this definition. All non-field counters are zero.
Natural recursion/index arithmetic, constructing the numeral 1 and counter
bookkeeping are not separately metered by this theorem.

The submitted proofs use precisely these base/successor equations, `pow_succ`
for value and distributivity for cost. There is no closed-form desired-value
callback substituted for the actual recursive producer.

### 2. cutoffQ_value

The actual Run computes one charged qDiv `1/delta` and then returns

    Nat.clog 2 (max 1 (Nat.ceil reciprocal)).

Its value is definitionally `HermiteFiniteExp.tailCutoff delta`, exactly the
unchanged canonical definition. This is why the submitted `rfl` is a meaningful
literal-body equality rather than an assumed cutoff bound. It holds for every
rational delta. At delta=0, Lean rational division is total and 1/0=0, so
ceil(0)=0, max=1 and clog2(1)=0. For negative delta the natural ceil of the
negative reciprocal is zero, giving cutoff zero as well. None of this supplies
a zero/negative-error exponential enclosure. Positivity belongs to separate
approximation-error consumers and is not missing from this equality.

The ledger cost is one field tick, although that cost equality is an independent
static consequence, not an additional public theorem proved by C157. Computing
Nat.ceil/clog/max, natural conversions and large integers remains unmetered
native work, not a unit-time logarithm oracle justified by this value lemma.

### 3. gridStepRun_value

The actual denominator Run is powQ 2 width. By the recursion above its value is
2^width. The following numerator and quotient Runs return 2*R and
`(2*R)/(2:Rat)^width`, the exact canonical `gridStepQ width R`. Natural width
zero gives denominator 1; R=0 and negative R are permitted. A rational power
with natural exponent is being used; there is no replacement of the exponent
by a rational or natural-division approximation.

The exact ledger cost is (width+2) field ticks: width multiplications in powQ,
one numerator multiplication and one division. C157 states only value equality
here, not this cost theorem or native evaluation complexity. The proof unfolds
the literal binds/primitives and uses the already derived powQ_value.

### 4. acceptRun_value and acceptRun_total_le

Let cap=2^width, always positive for natural width, and define

    b = 0                       if cut=0,
        1                       if cut=cap,
        (if a=0 then 1 else 0)   otherwise.

This is exactly the canonical literal `acceptQ`, including guard order. The
Run always charges the first comparison, charges the full-cut comparison only
if nonempty, and charges the a=0 comparison only if neither zero nor full.
Write chi(flip)=0 for false, 1 for true, and

    t(cut)=1  if cut=0,
           2  if cut=cap,
           3  otherwise.

Its value is b when flip=false and 1-b when flip=true. Its exact cost vector is

    t(cut)*e_compare + chi(flip)*e_field,

and total is t(cut)+chi(flip)<=4. The subtraction is a rational field operation,
not truncated natural subtraction, and it is charged even when its result is
0 or 1. No read or write is silently charged here; a is an input Fin3 label.

All branches are covered by the following symbolic exhaustive table:

| cut class | unflipped value | compare ticks | false total | true value | true total |
| --- | --- | ---: | ---: | --- | ---: |
| zero | 0 | 1 | 1 | 1 | 2 |
| full (=cap) | 1 | 2 | 2 | 0 | 3 |
| other, a=0 | 1 | 3 | 3 | 0 | 4 |
| other, a=1 or 2 | 0 | 3 | 3 | 1 | 4 |

For width=0, cap=1, zero and full remain distinct and there is no strict
interior natural cut; cuts>=2 still go through the literal other branch.
For width>=1, the other class includes genuine interior cuts. It also includes
cuts>cap for all widths. Since neither theorem assumes cut<=cap, that
out-of-range behavior must be included rather than silently discarded.
Equality to the same literal acceptQ does not separately prove comparison-
automaton correctness for out-of-range or otherwise invalid threshold data.

The submitted proofs split flip and each of cut=0, cut=cap, a=0. That case
partition is exhaustive; the zero/full conjunction is impossible but cannot
invalidate the forward evaluation of the first guard. Bound 4 is attainable
for an interior cut (e.g. width=1,cut=1), any a, flip=true. This is a precise
ledger bound, not a claim about bit complexity of equality or exponentiation.

### 5. Arbitrary rightProduct: exact coefficient cost is retained

For arbitrary input coefficient Run r, let A and B be its two actual acceptRun
executions and let c=r.value. The executable order is A, B, r, then qMul(B,c),
then qMul(A,inner). Therefore

    value = A.value*(B.value*c),
    cost  = A.cost+B.cost+r.cost+2*e_field,
    total = total(A.cost)+total(B.cost)+total(r.cost)+2.

No accept-value test short-circuits coefficient execution or either multiply.
Even when A.value or B.value is zero, r.cost remains in the exact sum. If r
contains arbitrarily many reads/writes/field or other ticks, they all survive.
Hence a general bound 11 for an arbitrary coefficient Run would be false;
C157 does not assert it. This exact equation is private helper
c157_rightProduct_total, with no cost-bound or correctness premise.

If r=pure c, its ledger cost is zero and the two accepts total at most 8,
giving generic bound 10 (the submitted helper states the weaker <=11). If
r=read xs i, its actual canonical cost is one read tick, giving generic
bound 11. Arbitrary coefficient magnitude does not affect these ledger counts;
that is a limitation of this scalar/word abstraction, not a finite-bit claim.
The generic read-bound 11 is attained by two interior cuts and both flips=true.

### 6. rightEntry_total_le: actual five branch costs

The actual FullIndex is the right-nested sum of five ComponentIndex types.
Each ComponentIndex is Fin3 x (Fin3 x Fin(d+1)); d is respectively 0,
sourceDegree(delta), 2k+1, 0 and sourceDegree(delta). Thus the two constant
branches have one unused j label, and the three stored branches have an actual
valid Fin index into the corresponding returned vector. There is no partial
array read at a fabricated index.

For the first and second cut costs tA,tB in each branch:

| branch, in actual order | cuts | flips | coefficient Run | exact total | upper bound |
| --- | --- | --- | --- | --- | ---: |
| left clipped constant | minusOne, minusT | false,false | pure s.clipped | tA+tB+2 | 8 |
| left tail | minusOne, minusT | false,true | read s.tailCoeffs j | tA+tB+4 | 10 |
| middle | minusOne, zero | true,false | read middle j | tA+tB+4 | 10 |
| right clipped constant | zero,T | true,true | pure s.clipped | tA+tB+4 | 10 |
| right tail | zero,T | true,false | read s.tailCoeffs j | tA+tB+4 | 10 |

Every accept endpoint branch and Bool action is already covered by the preceding
table; here tA,tB are each 1,2,or3, including arbitrary supplied cuts>cap.
Uniform <=11 follows immediately, and in fact <=10 follows for this exact
five-branch rightEntry definition. A concrete maximal partial-ledger case is
width=n+1=1 with both relevant cuts 1 in an arbitrary supplied RightSetup,
selecting the left-tail or middle branch: 3+3 comparisons, one flip field tick,
one read, two field multiplications total 10. This is a symbolic exact witness
from the definitions; no executable diagnostic was run or promoted to proof.

The submitted rightEntry proof successively cases the five nested-sum branches
and invokes the pure/read helpers with exactly these actual flip patterns and
vectors. There is no theorem here identifying the returned value with
actualBlocksQ.right; that is the distinct sealed actual_cached_right target,
not one of this file's seven declarations. Arbitrary s and middle suffice for
a cost bound without correctness invariants or normalization assumptions.

## All six private helpers and public binders

The six private helpers are all implementation arithmetic, with no added
logical premises:

1. c157_total_add: arbitrary Cost functions a,b; distribute the exact eight-term
   total over pointwise addition.
2. c157_total_field_tick: enumerate the eight distinct constructors; total of
   one field tick is 1, all other entries zero.
3. c157_read_total: arbitrary Type alpha, N, vector xs and FinN index i; unfold
   actual read/charge to obtain total one. N=0 is a vacuous quantified-index
   case, not a missing N>0 premise.
4. c157_rightProduct_total: arbitrary widths/cuts/flips/Fin3 labels and arbitrary
   coefficient Run; additive exact cost formula above. Value or cost is not
   assumed; coefficient cost is neither erased nor bounded as an oracle.
5. c157_rightProduct_pure_le: specialize to the actual pure constructor, prove
   its zero counter internally, combine the two proved accept bounds and 2.
6. c157_rightProduct_read_le: specialize to actual read, use helper 3 for its
   one counter and combine the two accept bounds and 2.

The seven public binders are data only: rational x/R/delta, natural m/width/cut/
k/n, Op, Bool, finite labels, stored RightSetup/middle vectors and FullIndex.
No SOURCE positivity or scientific promise is silently introduced, no final
cost premise/desired output/cache-correctness oracle appears, and no EXCESS
logical premise was found. For these internal arithmetic/ledger claims,
RightSetup fields are arbitrary data, not a hidden Prop bundle. Its type
parameters enforce the tail vector length but not its scalar correctness;
the theorem does not need that correctness for its stated cost conclusion.
No choice-defined target, quotient representative, default approximation,
external oracle or alternate desired-output definition is introduced by C157.

The lexical proof topology is:

    literal power recursion -> pow value and op-indexed exact cost
    literal qDiv/cutoff -> cutoff value
    pow value + literal gridStepRun/gridStepQ -> grid-step value
    literal acceptRun/acceptQ guards -> accept value and <=4 total
    literal Cost/total -> total_add and field_tick
    actual read/charge/total -> read_total
    literal rightProduct + total_add + field_tick -> exact product total
    exact product total + accept bounds + pure/read cost -> product caps
    five actual FullIndex cases + matching product caps -> rightEntry <=11.

This is a static lexical/reference and mathematical dependency reconstruction,
not an elaborated Lean proof-term graph. The source-facing construction graph
and scientific root are not replaced by this local operation spine. There are
no invented independent arrows from only one input of a multi-premise step.

## Partial counter boundary and unproved consumers

Only the supplied annotation ledger is bounded. In particular:

- `rightEntry` accepts an already built s and middle vector. The cost of
  rightSetup, cutoff/degree/factorials, tail coefficient construction, clipped
  and midpoint calculations, middle production and source-cache creation is
  absent from this per-entry bound, not proved to be zero.
- Its constant branches use pure(s.clipped), a record projection of already
  supplied data. The three other branches perform a charged read. Neither
  constructor gives free construction of the stored scalar/vector input.
- Eventual right-vector collect still contributes its actual four traffic
  ticks per entry. The seven claims do not supply an entire producer total,
  castData/ofTable cost, or a Window/refinement/source-action result.
- C150 produceCachedQData binds the C23 cache/setup/middle but also captures
  `actualBlocksQ` for kernel/left. Its kernel/left callbacks sit inside pure
  values with explicitly unaccounted scalar evaluation. Capturing the block
  does not establish that constructing or evaluating its fields is free, lazy,
  shared once, or without additional eager setup. Source-level lets, closure
  structure and shared compiled declarations cannot prove zero captured-block
  work. No native execution or sharing theorem was inspected or established.
- Natural powers, comparisons, index arithmetic, conversions, ceil/floor/clog,
  finite proof checking, vector allocation and counter metadata are not native-
  costed by this partial ledger. Rational field ticks do not bound numerator/
  denominator bitlength, GCD/normalization or multiplication/division time.
- No gate count, address/rank storage certificate, angle synthesis, ancilla
  cleanup, saved executable target replay, uniform error or scientific ROOT
  follows. n_p=n+1 remains the existing parameter convention, not a new physical
  implementation theorem or permission to reuse the exact-real 2k+6 bond.

The other ten declarations in the full seventeen-target C156 signature packet,
including middle values/cost400, setup values, actual_cached_right, QData value,
Window, stored/source/same-run conclusions and bound816, were read as sealed
targets only. This C157 file does not prove them. This review does not accept
them by import or promote an assumed type probe into proof. It also does not
assert those future goals are false; they remain outside this bounded slice.
The unchanged original state/error budget is not modified.

## Checks, incidents, handoff and stopping point

The read-only checks verify exactly seven public and six private theorem
declarations in the raw proof, zero occurrences of the banned exact tokens
sorry/admit/axiom/unsafe/native_decide, exact source hashes and the seven sealed
statement comparisons. This textual scan is not a compiled axiom audit.
No finite diagnostic was needed: the recursive induction and exhaustive
symbolic case table supply the mathematical discriminator. No Python, compiler,
lake, Git, network, supplied script, subagent or later consumer was executed.

Objective/frontier: independently review values and partial operation counters
for seven C157 public primitive/right claims and six helpers, under C156.
Mathematical delta: full exact counter derivation preserving arbitrary
coefficient work; exhaustive zero/full/other and Bool handling; sharper actual
five-branch caps; honest separation from unaccounted setup/native work.
Effect on root: supports a candidate internal scalar/counter provider only;
no Lean/runtime/publication/root admission gate is closed here.
Named evidence: three C150 raw source pins, C156 seal and all seventeen raw
signatures, whole C157 source, relevant canonical source regions and hashes;
source/target comparisons in STATIC_CHECKS.json and INPUT_MANIFEST.json.
Assumptions/conventions: exact rational values, natural exponents/counters,
literal eight-counter total, generic supplied stored data, n_p=n+1.
Files changed: new isolated C161 packet only; C151/C154 and all source remain
frozen. No production edit or local lemma implementation was made.
Reusable cross-layer insight: exact compositional Run cost must retain the
coefficient counter even on zero amplitudes; five actual flip patterns allow
a sharper bound than the generic both-flipped read specialization.
Failure class: NONE for mathematics; initial tool display truncation is a
documented read-sequencing incident, not mathematical refutation or compile
failure. Complete seal/signature/proof rereads preceded substantive derivation.
Salvage: no rejected mathematical route; preserve this static review and exact
13-declaration scope; no promotion to compiled reusable library memory.
Process-memory IDs consulted: none; protocols already fully read in C151 and
retained in this same worker context. C156 memory/review pin names do not mean
their contents were consulted.
Direction fingerprint: fresh task-specific raw-definition/exact-ledger static
audit, with explicit prior C147 runtime exposure chronology.
Expected information gain: detect dropped coefficient cost, bad endpoint/flip
branches, wrong stored-vs-pure cases, excess correctness/cost premises or a
partial-ledger-to-runtime overclaim.
Parallel admission: parent delegated this independent complementary review;
no further subagent and no other review consumed. No route-comparator or common-
blind-spot acceptance is claimed.
Default verified route/comparator: none selected; only this candidate examined.
Purification/Exposition Seal: not issued. The local operation spine is explained
but no whole construction/source/reader purification is certified.
Source/Lean expansion and boundary: actual canonical primitive bodies, three
C150 definition modules and C157 proofs; only seven C156 targets reviewed.
Typed obstruction: actual compilation/axioms, middle/setup/value consumers,
full same-run proof and all native/bit/gate/evaluation-sharing gaps withheld
or outside scope, not refuted.
Residual risk/confidence: high confidence in the elementary exact semantics
and ledger calculations; actual elaboration and inherited compiled dependency
association remain unassessed for C157.
Recommended next step: freeze this static packet first. Separately authorize
runtime association if desired, without rewriting this review after exposure.
Context digest: source proof f267071f622a45f3ed68f15cd93d5483e70bae903135ba9edb3bd86926eb737b;
C156 seal e4be7acce67f288b8b70755da16c4f0c40bba589cd40454b45111547b2c5ee5a;
sealed signatures 55c9becf19da0fde666a7c3d01e7fd72f6a027e9dd34db39bf2058b7860480b1.

All actual actions were read-only PowerShell retrieval, bounded line reads,
source-target text comparisons, hashes/regex inventories, parent coordination,
and apply_patch writes of only new C161 artifacts. No author audit/gate-plan/
manifest explanation, C159 raw/runtime result, C160 status/report/source-binding,
other review, Git/catalog/PR or prohibited network context was consumed.
Stop at this static freeze; no target runtime result association is inferred.
