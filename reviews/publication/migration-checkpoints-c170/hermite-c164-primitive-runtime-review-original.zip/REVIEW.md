# C164 separate primitive runtime-association review

Classification: `INTERNAL_RUNTIME_ASSOCIATION_REVIEW`.

The supplied records support the narrow recorded local association: the exact
C161-reviewed proof source was compiled to the recorded own output, then the
author-authored consumer selected that output and checked the seven stated
types. Both recorded runs printed the same seven ordinary-axiom reports. No
concrete source/output/type/axiom mismatch was found. This is not an independent
rerun, clean-transitive-TCB certificate, printed-definition audit, Source Anchor,
Proof Seal, public-source final review, or scientific ROOT admission.

## Chronology and exact association

C161 was frozen first, at seal
`d3ca8f0e1fe3dfa197f2b75c59b0024bae8662dabaf904f12ea68d877a15068c`.
The parent verified and read that packet before separately authorizing this
runtime stage. All three C161 payloads and its seal were rehashed unchanged.
This same reviewer already had C147 runtime exposure through C154 and is now
exposed to C159; no fresh general source-blindness is claimed. C161's original
read-sequencing disclosure and static findings remain intact.

The staged proof and original-author ZIP member both hash to
`f267071f622a45f3ed68f15cd93d5483e70bae903135ba9edb3bd86926eb737b`, exactly the
C161 source. The consumer source and its ZIP member both hash to
`1326bb9dcba2b84ce406968f5d77f631866b6c0aead979dbcc61b779f8d18c48`.
The actual staged outputs match the two recorded hashes:

| module | output SHA256 |
| --- | --- |
| CachedPrimitivesProof | 77547431cc9e4759adcd8c25f6a3e57622da492bdb31ac36f2061ab06e50d473 |
| PrimitiveProofChecks | c1d51c9fade6a0f9dd6f49c8c4dcae01e4b555870b6ba7b0cb910a2756856905 |

The whole inspected runner creates an exclusive stage, archives/extracts the
two sources, verifies pinned inputs, invokes the direct pinned Lean executable
with stage root and explicit own-output paths, 3072 memory limit, one thread and
180-second per-module timeout, then saves raw records and their hashes. Its
actual byte hash matches the wrapper hash recorded in proof-result.json.
The current addressed executable still matches
`dd86e9b24990b1da425ea4af910f016e4db8f9a25c9ddad27bc6bee3690e677f`.
No compiler or supplied script was executed by this reviewer.

The raw proof dependency query selects C155's CachedRightSetup.olean. The raw
consumer dependency query selects C159's own CachedPrimitivesProof.olean, not
an older same-named proof. Their hashes match the JSON records and staged
provider files. Both recorded compile exit codes are zero, without timeout;
recorded durations are 25.578 and 24.531 seconds. Raw direct compiler stderr is
empty. Public feedback is exactly equal to the corresponding raw stdout bytes,
not merely a paraphrase or success field. Exact bindings are in INPUT_MANIFEST.

## Seven types and seven-plus-seven actual axiom rows

The consumer source contains seven explicit `#check (theorem : stated type)`
ascriptions, not just name lookups. Its actual output prints those seven types:
powQ value, exact op-indexed powQ cost, cutoff value, grid-step value, accept
value, accept total<=4, rightEntry total<=11. They retain the C161/C156 data
binders, arbitrary rational inputs, arbitrary supplied RightSetup/middle,
literal canonical objects, Bool behavior, and numeric bounds. The printed
`if flip = true` is the elaborated Bool coercion of the source `if flip`, not
a new hypothesis or altered branch semantics. No cost/correctness premise is
added. No other ten C156 targets are printed as proved here.

Each raw stdout has exactly seven unique expected fully qualified axiom rows,
each precisely `[propext, Classical.choice, Quot.sound]`. Neither list contains
sorryAx, ofReduceBool, trustCompiler or another added axiom. The JSON sorts
these names; ordering differences are immaterial. The unchanged parser bytes
match the previously inspected universe-aware parser hash. Its complete body
and the runner's row extraction/length/expected-name-set/ordinary-allowlist logic
were read, not executed. These actual rows are plain single-line names, and a
separate read-only transcript comparison confirmed all seven exact lists in
each run. The author manifest's expected-name field was not accepted blindly:
the actual names were independently matched to C161's seven targets.

The consumer is author-authored; its compile is an own-output type/axiom gate,
not independent source reconstruction. Its output does not print proof terms
or definition bodies. The seven public axiom reports cover their recorded
transitive axiom dependencies, not a new audit of every private helper or the
entire imported environment.

## C155 provider provenance: relevant but limited

C156 binds the exact C155 receipt hash and selected outputs. The actual C155
receipt, stage source bytes and original-source archive members agree with the
C150 definition hashes already reviewed in C161. Current selected outputs match:

- CachedMiddle: `92c16c0b2607b4cb961c4ccd6ab1c0eecf91e7c6216348186dd3715b2d391785`.
- CachedRightSetup: `f07ec08da166bee291d4f47c76424a98457d4e523667182115ec628e0012131c`.

For these two modules, the C155 receipt records successful definition
typechecking and its raw stdout/stderr are empty. The raw dependency lists show
CachedMiddle selecting inherited ChargedSourceCache and ActualCoefficients,
then CachedRightSetup selecting the own C155 CachedMiddle and inherited
RationalBlocks. The three relevant inherited direct-provider binaries currently
match C156 pins. The C159 proof's own dependency query then selects this exact
C155 CachedRightSetup. These records give a specific limited recorded chain,
not just the assertion that some cache existed.

Neither C155 nor C159 here prints the loaded powQ/Run/acceptRun/rightEntry
definition bodies. This is therefore not a runtime printed-definition audit
like the earlier distinct C147 degree audit. Static source review plus typed
provider receipts must not be relabeled as such. C155's proposition-formation
status is not a proof of its seventeen candidate conclusions. This reviewer
did not audit the C155 runner or rerun its compilation, nor inspect every
transitive provider source/binary.

## Remaining assurance and cost boundaries

The recorded requested path order is own proof stage, C155 typed stage, the
five inherited cache roots, current project output, then Lake's package path.
Raw requested-path text, direct dependencies and preliminary stderr were
inspected privately. The preliminary Lake queries warn that verso has local
changes; direct compiler stderr remains empty. No clean dependency environment
is inferred, and no claim that verso actually enters this proof term is made.

Direct `--deps` queries are separate invocations, not complete effective
transitive-loader traces or immutable-filesystem/process attestations. Source
and binary pin assertions in the runner do not rebuild inherited packages or
prove all transitive source-to-binary correspondence. We verified the relevant
current files, not the entire seal's inherited binary map. The binary/parser
and writer/helper environment is not a fresh audited TCB; the private transport
helper was not inspected. Hash-consistent records support the association
under ordinary record-integrity assumptions, not cryptographic proof that an
historical process executed exactly those bytes without races.

The C161 mathematics is unchanged and not duplicated here. Its actual refined
right-entry branch caps 8/10/10/10/10 and retained arbitrary coefficient Run cost
remain partial-ledger facts. Runtime association does not account for setup,
captured actualBlocksQ eager/shared evaluation, kernel/left scalar callbacks,
native integers, ceil/floor/clog, rational bitlength/GCD, allocations, physical
gates, synthesis, cleanup, export error or scientific root closure. No zero
captured-block-work or full same-run producer conclusion follows.

## Compact handoff

Objective/delta: separately associate the C161-reviewed seven claims with
recorded exact proof/consumer outputs, types, 7+7 axiom rows and limited C155
typed-provider provenance; no new theorem or runtime experiment.
Failure class: NONE for discovered concrete mismatch. Clean-TCB/full-loader/
printed-body/native-cost evidence remains absent, not mathematically refuted.
Salvage/comparator: no failed route discarded and no alternative route selected.
Process-memory: none; previously read substantive-worker/role protocols retained.
Direction/independence: parent-authorized bounded association review after
static freeze; no other review, C160 packet or PR consulted. Parent's C160
checkpoint mention is not evidence used here. No subagents or efficiency claim.
Purification/Exposition Seal: none issued; internal evidence only.
Changed files: only this new C164 packet; C161 and all source/runtime packets
unchanged. Exact input/output manifests and seal accompany this report.
Actual actions: read-only PowerShell retrieval, whole-file/entry hashing, raw
ZIP members inspected in memory without extraction, transcript/type/name/hash
comparisons and parent coordination; apply_patch for new outputs only. No
compiler/lake/Python/provided scripts/Git/network, private-archive copy or source
edit. No tooling failure in this stage. Raw host paths stay outside public
candidate files; only logical names and hashes are retained.
Residual risk: ordinary record integrity, inherited binaries and unassessed
transitive/native behavior. Next step: use only this limited association class,
or separately authorize stronger rebuild/admission evidence. Stop at this
separate freeze; do not rewrite C161 or claim SourceAnchor/ProofSeal/ROOT.
