# Exact proposed Lean interfaces, not implementation

State: DESIGN_CANDIDATE_ONLY. Code blocks below freeze proposed source-level signatures only. No .lean file, proof, axiom, placeholder or executable declaration is created by this design packet. They have NOT been elaborated. A future signature/API correction requires a versioned candidate successor before proof work; do not silently weaken the contract.

Proposed local namespace: ASPBE.Uncompute.MBU.OperationBridge. Use existing ASPBE.Uncompute.MBU helper names; do not copy their definitions. Import actual QuantumBlockEncoding.PrimitiveMacros and Mathlib matrix APIs. The integration owner must supply the real existing helper module import because the authorized exported target disclosed its namespace, not its production import path. Do not inspect/rewrite an old author packet to invent an import in this review.

## Existing exact reuse interfaces

```lean
QuantumBlockEncoding.primitiveCCXProgram_eval
  {qubits : Nat} (a b target : Fin qubits)
  (a_ne_b : a ≠ b) (a_ne_target : a ≠ target)
  (b_ne_target : b ≠ target) :
  QuantumBlockEncoding.evalPrimitiveProgram
    (QuantumBlockEncoding.primitiveCCXProgram
      a b target a_ne_b a_ne_target b_ne_target) =
  QuantumBlockEncoding.Robin.ComplexLCU.equivPermutationMatrix
    (QuantumBlockEncoding.ccxBasisEquiv
      a b target a_ne_target b_ne_target)
```

The frozen helper equality/mass signatures remain exactly those of the previous own-formal exact-interfaces inventory; they are dependencies, not added hypotheses of the new root. Existing Mathlib Matrix.mulVecLin supplies linearity and Matrix.mulVecLin_mul supplies composition for all rectangular matrices below.

## Only local aliases/operation objects to introduce

```lean
abbrev DataBasis := QuantumBlockEncoding.PrimitiveBasis 2
abbrev WorkBasis := QuantumBlockEncoding.PrimitiveBasis 3

noncomputable def ccx3Program :
  QuantumBlockEncoding.PrimitiveProgram 3

noncomputable def zeroInsert :
  _root_.Matrix WorkBasis DataBasis ℂ

noncomputable def xBra (m : Fin 2) :
  _root_.Matrix DataBasis WorkBasis ℂ

noncomputable def conditionalCZ (m : Fin 2) :
  _root_.Matrix DataBasis DataBasis ℂ
```

Bodies must be exactly the full-carrier equations in proposed-contract.md: ccx3Program is the existing primitiveCCXProgram at0,1,2 with decidable intrinsic distinctness; J is zero insertion; K_m is the existing H row on the target and identity on retained labels; conditionalCZ is the existing phasePermutationMatrix with conditionalCZSign and identity permutation. No operation body may mention the desired final corrected branch or assume an AND input. No new state/channel/instrument structure.

## Supplier 1: actual compiled compute, not assumed graph input

```lean
theorem ccx3_zeroInsert_apply
    {R : Type*}
    (alpha : R → Fin 2 → Fin 2 → ℂ) (r : R) (x : WorkBasis) :
    ((_root_.Matrix.mulVec
      (QuantumBlockEncoding.evalPrimitiveProgram ccx3Program * zeroInsert)
      (fun y : DataBasis => alpha r (y 0) (y 1))) x) =
    if x 2 = ASPBE.Uncompute.MBU.andBit (x 0) (x 1)
      then alpha r (x 0) (x 1) else 0
```

Proof route, not proof: rewrite the real program by primitiveCCXProgram_eval; use ccxBasisEquiv's involutive basis action; collapse the finite permutation sum and zero-target insertion. Existing equivPermutationMatrix_mul_apply can be used with a one-column matrix, or the small native basis sum can be collapsed directly. Do not reprove the CCX decomposition.

## Supplier 2: all-carrier operation validation

```lean
theorem zeroInsert_isometry :
    zeroInsert.conjTranspose * zeroInsert =
      (1 : _root_.Matrix DataBasis DataBasis ℂ)

theorem conditionalCZ_isometry (m : Fin 2) :
    (conditionalCZ m).conjTranspose * conditionalCZ m =
      (1 : _root_.Matrix DataBasis DataBasis ℂ)

theorem xBra_complete :
    (∑ m : Fin 2, (xBra m).conjTranspose * xBra m) =
      (1 : _root_.Matrix WorkBasis WorkBasis ℂ)
```

These are producers of finite-linear semantic facts, not public correctness assumptions. Use native coordinate equality, the actual H entries/H square, and finite sum lemmas. xBra_complete is all-carrier; it is not merely the fair probability assertion on a previously selected AND graph. If these are not proved, the result must not be advertised as a validated ideal destructive-X family.

## Supplier 3: explicit operation-to-helper composition

```lean
theorem compiledAndBranch_eq_helper
    {R : Type*}
    (alpha : R → Fin 2 → Fin 2 → ℂ)
    (m : Fin 2) (r : R) (x : WorkBasis) :
    ((_root_.Matrix.mulVec
      (zeroInsert * conditionalCZ m * xBra m *
        QuantumBlockEncoding.evalPrimitiveProgram ccx3Program * zeroInsert)
      (fun y : DataBasis => alpha r (y 0) (y 1))) x) =
    ASPBE.Uncompute.MBU.correctedTemporaryAndBranch
      alpha m r (x 0) (x 1) (x 2)
```

This is the missing bridge to implement, not a definition. Full matrix action must pass through ccx3_zeroInsert_apply, then the AND-independent xBra, conditionalCZ and zeroInsert definitions. Matrix.mulVec_mulVec or mulVecLin_mul controls associativity. Reference r remains arbitrary and the same alpha coefficients are used throughout.

## Selected unconditional operator root

```lean
theorem compiledAndCleanupKernel_eq (m : Fin 2) :
    zeroInsert * conditionalCZ m * xBra m *
      QuantumBlockEncoding.evalPrimitiveProgram ccx3Program * zeroInsert =
    ASPBE.Uncompute.MBU.branchScale • zeroInsert
```

Use compiledAndBranch_eq_helper plus the existing correctedTemporaryAndBranch_eq. A matrix equality may be recovered by testing arbitrary retained coefficient vectors, or equivalently their basis columns. This root has only the outcome label as a value parameter: no normalization, gate-correctness, measurement-correctness, favorable branch or desired-action premise.

The required operation validations above remain package acceptance dependencies. An algebraic root alone must not be used to erase unvalidated operation meanings. No existing verifier/scoring/target is changed.

## One finite mass consumer, no new norm foundation

```lean
theorem compiledAndBranch_mass
    {R : Type*} [Fintype R]
    (alpha : R → Fin 2 → Fin 2 → ℂ) (m : Fin 2) :
    (∑ r : R, ∑ x : WorkBasis,
      Complex.normSq
        ((_root_.Matrix.mulVec
          (zeroInsert * conditionalCZ m * xBra m *
            QuantumBlockEncoding.evalPrimitiveProgram ccx3Program * zeroInsert)
          (fun y : DataBasis => alpha r (y 0) (y 1))) x)) =
    ASPBE.Uncompute.MBU.inputMass alpha / 2
```

This consumer uses the bridge, a narrow native-basis-to-three-coordinate sum equivalence and the existing correctedTemporaryAndBranch_mass. It does not add a probability API, normalize arbitrary input or call a function-space sup norm an L2 norm. Normalized half-mass and the two-outcome sum may reuse the existing helper corollaries through the same adapter; do not multiply wrappers for declaration count.

## Optional endpoint, not a second required successor

```lean
theorem compiledAndDiscardKernel_eq (m : Fin 2) :
    conditionalCZ m * xBra m *
      QuantumBlockEncoding.evalPrimitiveProgram ccx3Program * zeroInsert =
    ASPBE.Uncompute.MBU.branchScale •
      (1 : _root_.Matrix DataBasis DataBasis ℂ)
```

This is a separately typed discard endpoint. It can be derived using the selected reset root and zeroInsert_isometry, or proved before the reset root and then left-multiplied by zeroInsert. Choose one proof route; do not require both alternative proof orders. It is not physical reset or adaptive-program correctness.

## Reference adapter if product-carrier output is explicitly requested

```lean
theorem identity_reference_mulVec
    {R I O : Type*} [Fintype R] [DecidableEq R] [Fintype I]
    (M : _root_.Matrix O I ℂ) (v : R × I → ℂ) (r : R) (o : O) :
    (_root_.Matrix.mulVec
      (_root_.Matrix.kroneckerMap (· * ·)
        (1 : _root_.Matrix R R ℂ) M) v) (r, o) =
    (_root_.Matrix.mulVec M (fun i => v (r, i))) o
```

This is optional existing-Mathlib bookkeeping, not a new tensor/state foundation or a required delay to the pointwise-r bridge. If a compatible theorem already appears during implementation retrieval, reuse it instead of adding this general adapter. No reference-factorization hypothesis is permitted.

## Implementation owner and next gate

Exactly one successor owns these local adapters and the selected root. First independently approve and freeze this candidate's source/interface statement, resolve the existing helper import, and run a signature-only compatibility check under the pinned toolchain in a separately authorized implementation phase. No such check occurs here. Then prove the dynamic leaves and bridge; only later apply focused/repository/publication gates appropriate to the actual changed module. A source claim must retain the ideal finite-linear versus physical/adaptive/Born/resource boundary.
