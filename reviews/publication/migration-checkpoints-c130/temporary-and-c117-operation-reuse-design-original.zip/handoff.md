# C117 one-successor implementation handoff

State: DESIGN_CANDIDATE_ONLY. No implementation/proof/compilation or production edit. Previous SOURCE_ONLY, OWN_FORMAL_ONLY and THREE_WAY_TEXT_ONLY freezes remain untouched.

Concrete advance: actual local reuse audit found the real primitiveCCXProgram_eval to ccxBasisEquiv matrix semantics, exact H entries, general phasePermutationMatrix, native wire split/lift and Mathlib rectangular matrix linear/composition APIs. No new quantum foundation is needed for the next bridge. Installed L2 and complex norm-square facts also exist; do not mistake a bare coefficient-function norm for the intended L2 norm.

One successor, not a portfolio: instantiate actual CCX on native wires0,1,2, start from arbitrary retained amplitudes with target zero inserted by J, then compose full-carrier X bra K_m, conditional CZ C_m and zero insertion J. Prove actual UJ produces the AND graph, prove J C_m K_m U J alpha equals the old corrected helper, and only then reuse the old helper equality for the unconditional matrix root J C_m K_m U J = branchScale*J for both outcomes. No desired-output definition or correctness premise is allowed to replace either bridge.

Exact proposed Lean signatures, matrix dimensions and full-carrier bodies are frozen in lean-interface-plan.md and proposed-contract.md. Required operation-validation suppliers are J^dagger J=I, C_m^dagger C_m=I and sum_m K_m^dagger K_m=I. The finite mass consumer reuses old inputMass/helperMass with a native coordinate-sum adapter. Reference r remains arbitrary and coherent; a generic identity-Kronecker slice adapter is optional, not a new global state/channel structure.

Reuse classes: CCX/H/phase-permutation/Matrix are direct source-available reuse; zero-target coefficient production, rectangular X-bra/zero-insertion, conditional-CZ specialization and composition are narrow adapters; adaptive measurement/reset/Born execution, actual conditional-CZ program, concrete use preservation and resource semantics are still outside. Direct-reuse source was read and pinned, not recompiled or blanket-admitted in this run.

Endpoint: reset-shaped finite-linear output selected because the old helper retains t=0. Discard is an optional separately typed endpoint, not the same signature and not an additional required AND tail. This design claims no physical reset or outcome generation. There is no intervening concrete use program in the selected root.

Dependency readiness: the next dynamic leaf is ccx3_zeroInsert_apply once the four local operation objects are implemented exactly and the candidate is independently approved. The actual existing helper production import name must be supplied by the integration owner; only its exported namespace/signatures were authorized in the earlier formal intake. Do not duplicate/redefine helpers to evade that import step. Signature-only compatibility validation and a real Statement Seal precede proof work in a separately authorized phase.

Audit scope: targeted production queries excluded held temporary-AND/uncompute modules; installed Mathlib and local atlas/natural cards were consulted. No directly reusable destructive-X/reset API was located in that bounded retrieval. External cards are reference-only and their checkout locations were absent; no new dependency, external copy or paper was introduced. Negative search results are bounded, not global absence claims.

Failure class: NONE for the audit/design. Corrected retrieval misses are not mathematical counterexamples. Proposed interfaces are unelaborated, mathematical/source-graph/design/soundness approval is pending, and actual program/hardware/Born/resource/whole-root closure is not claimed. No verifier/scoring/target change, Git, network, child agent or compiler occurred.

Recommended next action: independently review/approve the exact candidate and endpoint, resolve the existing helper import, freeze the actual statement before proof, then implement this one finite-linear adapter package. Do not expand into a second quantum-foundation stack or silently advertise it as full adaptive/source-circuit final admission.
