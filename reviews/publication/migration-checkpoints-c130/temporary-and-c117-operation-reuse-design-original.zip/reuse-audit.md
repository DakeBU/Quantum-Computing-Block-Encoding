# C117 foundation reuse audit

State: DESIGN_CANDIDATE_ONLY. Source was inspected; no implementation, elaboration, compilation, test or acceptance was performed. Existing theorem bodies are reuse candidates, not revalidated compiler evidence in this run.

The bounded mechanism remains [arXiv:2610.22367v1, page 9, Eqs. (11)-(13)](https://arxiv.org/pdf/2610.22367v1#page=9). No additional paper was read. Earlier C110 source/formal/decoder freezes remain unchanged.

## Positive reuse, exact observed interfaces

| Existing declaration/module | Actual interface and observation | Classification for one successor |
| --- | --- | --- |
| PrimitiveSemantics: PrimitiveBasis | `PrimitiveBasis n := Fin n -> Fin 2`. | DIRECT REUSE. Keep native named-wire basis; no second qubit/state carrier. |
| ReversibleClassical: ccxBasisAction, ccxBasisEquiv, ccxBasisEquiv_apply | ccxBasisAction flips the named target exactly when both named controls are 1. ccxBasisEquiv has that action and the same inverse; its target/control distinctness inputs are intrinsic wire conditions. | DIRECT REUSE of basis semantics; narrow zero-target coefficient adapter still needed. |
| PrimitiveMacros: primitiveCCXProgram | Actual primitive program for three distinct wires, expressed using existing H and phase/CX subprograms. It is not defined as its target matrix. | DIRECT REUSE, instantiate controls 0,1 and target2 on three wires. Do not copy its gate list or reconstruct another Toffoli compiler. |
| PrimitiveMacros: primitiveCCXProgram_eval | `evalPrimitiveProgram (primitiveCCXProgram a b t hab hat hbt) = Robin.ComplexLCU.equivPermutationMatrix (ccxBasisEquiv a b t hat hbt)`. Complete displayed proof read; exact global phase is retained. | DIRECT REUSE of real program-to-matrix theorem; no new public correctness premise. |
| Robin.ComplexLCU: equivPermutationMatrix, equivPermutationMatrix_mul_apply | Matrix entry is delta(row,equiv(column)); left multiplication pulls rows back by equiv.symm. The latter acts on a matrix, not directly on a vector. | DIRECT REUSE; view a vector as a one-column matrix or use finite-sum collapse in the small adapter. No need to build a new generic permutation semantics. |
| PrimitiveSemantics: evalPrimitiveProgram, evalPrimitiveProgram_seq | Existing exact global-phase-times-circuit semantics. Chronological `seq left right` evaluates as right matrix times left matrix. | DIRECT REUSE. Proposed operator order explicitly matches this convention. |
| PrimitiveMacros: hadamardMatrix, hadamardMatrix_apply, hadamard_mul_hadamard | Concrete exact H and entries, including its i prefactor; H squared equals identity. | DIRECT REUSE for the X bra coefficients and finite completeness check. Do not invent an opaque X-phase multiplier. |
| PrimitiveMacros/PrimitiveSemantics: primitiveHProgram_eval, liftPrimitiveOneQubit_apply, splitPrimitiveWire | Existing compiled H and exact named-wire lift with equality of all other wire labels; split/reinsert basis equivalence is explicit. | DIRECT REUSE as a representation check, not a claim that the source must implement physical X readout by a counted H gate. The minimal successor need not change the gate language. |
| PrimitiveMacros: phasePermutationMatrix | For any finite decidable carrier, phase/permutation matrix has entry phase(column) when row=permutation(column), otherwise0. The multiplication theorem composes actual phases and permutations. | DIRECT REUSE for the conditional CZ matrix on the two retained native wires. New adapter is only its particular sign and coordinate action. |
| ConcreteSemantics: StateVector, applyVec | Existing Fin-indexed state functions and Mathlib mulVec action. This backend is already a thin matrix adapter. | REUSE its convention; do not add a new state/channel structure. Native PrimitiveBasis carriers can use Mathlib Matrix directly rather than introducing an unnecessary Fin8 flattening. |
| Mathlib Matrix.mulVecLin, mulVecLin_apply, mulVecLin_mul | A rectangular matrix already gives a complex-linear map; matrix multiplication is linear-map composition. | DIRECT REUSE for all proposed operations, including non-square destructive bra and zero insertion. No new LinearOperation record. |
| Mathlib Matrix.mulVec_mulVec, mulVec_add, mulVec_smul | Actual finite-sum action and composition/linearity facts. | DIRECT REUSE. Keep parenthesization explicit; no numerical evaluation. |
| Mathlib Matrix.kronecker_apply and Fintype.sum_prod_type | Existing product-carrier identity tensor action and sum rearrangement. | DIRECT REUSE plus a narrow identity-on-reference adapter if desired; main pointwise-in-reference bridge can avoid a new generic tensor API. |
| Mathlib EuclideanSpace.norm_sq_eq and Complex.normSq_eq_norm_sq | Standard L2 finite norm and complex squared-norm bridge already exist. | DIRECT REUSE only if a Hilbert norm claim is needed; do not infer that the bare function-space norm is L2. The minimal package uses existing explicit coefficient mass. |
| Frozen ASPBE.Uncompute.MBU helper interfaces | andBit, conditionalCZSign, correctedTemporaryAndBranch_eq and mass theorems are already pinned from the authorized formal input. No old author source or seal was reopened. | REUSE the exact namespace/signatures, not copied definitions. Actual existing module import name must be supplied by the integration owner; the exported formal packet did not disclose it. This is import plumbing, not a mathematical hypothesis. |

## Narrow adapters genuinely still needed

1. From the actual three-wire CCX matrix acting on a zero-target insertion to the AND graph coefficients. This must use primitiveCCXProgram_eval, not define the after-compute state as the desired graph.
2. A rectangular X-bra matrix on the full eight-dimensional input carrier, preserving the retained labels and using H[m,targetBit]. Its definition must not mention AND, alpha, the desired cleaned output, or the graph invariant.
3. Conditional CZ as the existing general phasePermutationMatrix specialized to the retained two-wire carrier. Its full-carrier sign is independent of input state and of whether the target was an AND.
4. A rectangular zero insertion on every retained two-wire vector. It is a linear isometry, not a physical reset process on an arbitrary discarded environment.
5. Matrix composition from those operations and the actual CCX/zero input to the previously proved helper; then reuse the helper identity/mass facts. No assumption that the operation already has the helper action is permitted.
6. Finite-basis sum/reference-coordinate adapters as needed. These are bookkeeping over existing matrices, not new quantum foundations.

## Not found / not directly available in the bounded retrieval

Declaration-focused production queries, excluding held temporary-AND/uncompute modules, did not locate a directly reusable destructive-X instrument, reset/reallocation API, or named conditional-CZ program. Existing cczMatrix and phasePermutationMatrix are concrete diagonal-matrix substrate, not a destructive instrument. This is a bounded search result, not a global theorem of absence.

PrimitiveGate was inspected: its constructors are X, RY, RZ and CX. PrimitiveProgram has unitary matrix semantics and global phase. It is therefore not an existing adaptive measurement/reset instruction language. Do not put a nonunitary branch into PrimitiveProgramRefinement and pretend its program field executes a measurement.

Installed Mathlib targeted searches in linear algebra/analysis/probability found no directly named Kraus/quantum-instrument/quantum-measurement surface to import. Generic matrix/linear/L2 APIs were positively found. No claim is made about every possible differently named Mathlib construction.

The local atlas family `family:matrix-contract` explicitly prefers dimensions/basis/entry contracts and warns that proposition-valued structures are interfaces rather than unconditional construction theorems. Attributed library cards identify Lean-QuantumInfo, lean-quantum and quantum-computing-lean as reference-only, not imported local foundations. Their recorded checkout locations and the documented sibling checkout convention were absent. No external code or paper was fetched, copied or audited. The quantum-computing-lean card also records a license boundary; there is no reason to bypass it for these small Mathlib adapters.

## Recommended reuse decision

Implement one successor only: a native-three-wire **ideal finite-linear operation bridge** from the existing compiled CCX prefix and zero input, through full-carrier X bra / conditional CZ / zero insertion, to the frozen helper and scaled identity. Keep current Mathlib matrices and existing ASPBE program semantics. Do not begin a general channel library, adaptive interpreter, hardware reset/Born model, generic-f correction compiler, or resource theorem in this successor.

The proof-DAG/source-audit skills determine this decomposition: actual suppliers remain dependency edges and complete AND tails, not convenience binders. The design itself is pending independent statement/interface approval and has not been soundness-approved by its author.
