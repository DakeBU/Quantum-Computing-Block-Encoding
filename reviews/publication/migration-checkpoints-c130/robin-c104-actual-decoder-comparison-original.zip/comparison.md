# Actual three-way mathematical comparison

Verdict: the precise local source-v2 mathematics, my previously frozen whole-formal interpretation, and the released actual whole decoder are concordant at their stated contracts. This is not a raw/Lean/kernel/publication or main/root admission. One precision finding affects my earlier interface segmentation, not a mathematical theorem.

The comparison uses the entire source (113 lines,47 regions), all677 target declarations (114 private,563 public),69 structures/1950 individual fields,11 ambient regions and the relevant provider chains. The decoder's exact target and all seven provider inventories independently recompose the eight permitted formal snapshots byte for byte. Every955 leading-binder group and every returned-type boundary was independently text-checked. These checks support identity and coverage, not comprehension or proof acceptance.

## What actually agrees

For arbitrary rational environment e, the actual selected grouped entry is f*u*c. The grouped col0 path is killed through both exact function zeros; a separate identity-seeded active-fold support proof gives eval(A00)=0. All six nonselected diagonal contributions vanish, so the seven-slot fold evaluates to C2. The actual decoder reconstructs each repeated private support family, not just the finite path probes. The individual declaration crosswalk retains my own distinct pre-release interpretations; the family crosswalk states the actual decoder's semantic schemas. I do not invent677 independent decoder prose summaries.

Consequently Fold(e) iff eval(C2)=0. The actual four-symbol counterenvironment gives C2=1 and A00=0. Exact raw backend expansion, projection summation and raw A00=fold are genuinely refuted propositions, not merely false status flags. Later implications assuming that exact expansion have a refuted antecedent. Equality in one chosen environment is not equality of free syntax; the counterenvironment need not satisfy inverse laws to refute the unrestricted syntactic target.

The prepared object is different: K(H) is a seven-DIAGONAL compression, not a full lifted two-index sandwich. A new singleton gate is assigned this8x8 matrix with a unitary status record, not a unitary certificate. Its fold agrees with K00 after evaluation. Under all seven raw Uniform column equations it evaluates to the diagonal fold. This does not identify the unchanged active seven-gate entry with the prepared entry.

The positive scalar theorem retains the full AND-tail: arbitrary H,e; all-seven Uniform; HENTRY identifying the actual cosine value; hND; hNF; hkappa; hSquare. Complete selected-support, all-six-zero reduction, singleton evaluation and target/normalizer definitions remain providers. No OR alternative or dropped supplier is credited.

Source-v2 WF-SCALAR/WA4 instead names the literal ALREADY normalized stored factor. Two-law cancellation for that stored factor does not need HENTRY; the actual cosine-bearing entry does. WA13 retains HENTRY and SELECTED along with the other complete tails. This matches the actual decoder and preserves the T02 source correction.

## Data, hypotheses and genuine certificates

Every1950 field has an exact literal owner/body match and its own frozen typed disposition in the field crosswalk. There are27 genuine stored equality certificates,42 proposition/predicate-valued data fields,829 Bool fields,219 semantic-status records,366 Strings,196 Nats,114 coefficient data,5 matrix data,42 finite-index/list/function data and110 nested typed records. These are lexical field roles, not1950 independent mathematical theorems. Nested records preserve their genuine local proof fields; they are not promoted wholesale.

A p:Prop field stores a proposition, not hp:p. Likewise .proved=false does not negate a proposition, and .proved=true does not prove it. CircuitMatrixSemantics really certifies list alignment and pointwise fold coherence; it does not certify unitarity. The actual negation theorems are separately identified above. Exact types and all leading assumptions remain available per declaration, including result-local lets and conjunctions.

## Qualifications and differences

DC03:14 of my earlier exact-interface fragments for where-constructor definitions extend into the first field name before its :=. The actual decoder has the more precise where/header/body boundary. The69 structure fragments merely include their where delimiter;594 other headers coincide after trailing whitespace. All old fragments are literal source prefixes and all fields/bodies were read. I preserve every old byte and document the14 exact differences rather than silently repairing my freeze.

The decoder reads GHL only in its listed exact ranges; I previously read all1..8474. Full decoder inventory does not enlarge its human reading claim. Its selected cleanup/injectivity/swap/function and local finite-fold providers support the roles it actually asserts. Additional own U/S permutation-provider reading is not automatically attributed to the decoder. Active uniqueness always retains clean padding AND slot<7, and its competing source remains active. Broader candidate existence is not broader uniqueness.

My additional deductions remain my own, not alleged decoder omissions or contradictions. The inverse/square laws imply q=kappa_inv>0,z=kappa>0,a!=0 over Q, but not positivity of other normalizer pairs; source-v2 F01 now says exactly this. HENTRY and the laws also give Fold iff f*d=0 (a genuine factor-zero OR, not a route OR). The conditional laws are jointly realizable with interpreted kappa1; adding interpreted kappa7 makes the rational square/inverse requirements inconsistent, but that extra assignment is not an actual theorem binder and says nothing against real/complex quantum possibility.

The actual n3 B columns32 and112 coincide: slot2 and excluded fallback slot7 both have offset0 and equal low/high/system bits, hence image0. The difference of their basis vectors is a nonzero kernel vector in a faithful characteristic-zero matrix interpretation. This literal full B is therefore not full-space unitary, while active-only injectivity is unaffected. A separate extension could alter excluded columns. This is an uncompiled mathematical deduction, not a Lean theorem or simulation; the decoder's explicit slot7 duplicate observation is compatible with it.

## Coverage and residual scope

source-threeway-crosswalk.json preserves all47 regions and16 typed source AND edges, including the future WA15 supplier schema as UNACHIEVED, not an achieved conditional closure. There are no source OR edges. The earlier original-source findings, amended source wording, own source-first topology and full-formal freeze remain intact.

The actual decoder progress log's initial INCOMPLETE markers are chronological and explicitly superseded by its EOF/seal; I do not read the old partial package. Current raw hashes establish these released bytes, not historical author identity or the parent's reported archive comparison. Historical formalizer remains UNKNOWN.

Remaining gates are precise: raw/comment-mask faithfulness, Lean/kernel/TCB, generated public exports, external paper/history, and a separately typed full physical prepared operator with off-diagonal/unused-sector reduction, adjoint/unitary semantics, full normalized extraction and resources. The correction status record is not even a typed full-operator equation. A missing interpretation is not a mathematical impossibility. Nothing here closes publication/main/root admission. Stop after this comparison freeze.
