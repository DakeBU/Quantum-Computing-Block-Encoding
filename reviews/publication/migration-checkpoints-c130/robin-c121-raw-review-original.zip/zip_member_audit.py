"""Read-only C121 exact ZIP member association; never extracts or executes."""
import argparse,hashlib,json,pathlib,zipfile
def sha(b):return hashlib.sha256(b).hexdigest()
p=argparse.ArgumentParser();p.add_argument("--archive",required=True);p.add_argument("--release-root",required=True);a=p.parse_args()
z=pathlib.Path(a.archive);root=pathlib.Path(a.release_root)
if sha(z.read_bytes())!="4e0c0bd6fe387f199b2e35d21f0c3e4d580ddb474d33e2acd382788f0d9e18e7":raise ValueError("ZIP pin")
release=(root/"release.json").read_bytes()
if sha(release)!="51bda91b6d7cd4bd1a840aa80c025478565e268fb9c49a0154016f142001fe6e":raise ValueError("release pin")
rel=json.loads(release)
expected={x["path"]:(x["bytes"],x["raw_sha256"]) for x in rel["inputs"]}
expected["release.json"]=(len(release),sha(release))
expected[rel["redaction_method"]["path"]]=(2718,rel["redaction_method"]["sha256"])
records=[]
with zipfile.ZipFile(z,"r") as f:
    infos=f.infolist();names=[x.filename for x in infos]
    if len(names)!=13 or len(set(n.casefold() for n in names))!=13 or set(names)!=set(expected):raise ValueError("ZIP exact membership")
    for i in infos:
        size,pin=expected[i.filename]
        if i.is_dir() or i.flag_bits&1 or i.file_size!=size:raise ValueError("ZIP unsupported entry")
        member=f.read(i);direct=(root/i.filename).read_bytes()
        if member!=direct or sha(member)!=pin:raise ValueError("ZIP member bytes")
        records.append({"path":i.filename,"bytes":len(member),"sha256":sha(member),"zip_member_equals_released_file":True})
print(json.dumps({"schema":"C121_EXACT_ZIP_MEMBER_CHECK","zip_logical_path":"W/robin-c121-raw-input-exact.zip","zip_sha256":sha(z.read_bytes()),"zip_bytes":z.stat().st_size,"members":records,"all13_exact":True,"extraction":False,"execution":False}))
