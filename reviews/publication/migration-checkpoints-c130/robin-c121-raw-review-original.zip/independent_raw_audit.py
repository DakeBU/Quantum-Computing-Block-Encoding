"""C121 independent, bounded per-instance text audit. No compiler or parent code execution.
Only release.json, its exact eleven paths, and the earlier formal-input manifest
are read. All reports go to stdout; artifact writes are handled separately.
This is not a general Lean lexer, parser, semantic-equivalence or TCB proof.
"""
import argparse, bisect, hashlib, json, pathlib, re, unicodedata
EXPECTED = (
 "QuantumBlockEncoding/RobinMatrix.lean", "QuantumBlockEncoding/Examples/RobinHeat.lean",
 "QuantumBlockEncoding/GHL2025.lean", "QuantumBlockEncoding/CircuitSemantics.lean",
 "QuantumBlockEncoding/BlockEncoding.lean", "QuantumBlockEncoding/Circuit.lean",
 "QuantumBlockEncoding/Resources.lean", "QuantumBlockEncoding/Core.lean",
 "lean-toolchain", "lakefile.lean", "lake-manifest.json")
RELEASE_SHA = "51bda91b6d7cd4bd1a840aa80c025478565e268fb9c49a0154016f142001fe6e"
FORMAL_MANIFEST_SHA = "1e9753617607d960798a6161dcb5b3f0d338524fae3885d1a22d6200b8b7dbf5"
def sha(b): return hashlib.sha256(b).hexdigest()
def idchar(c): return c == "_" or c == "'" or unicodedata.category(c)[0] in "LNM"
def bounded_scan(data):
    if data.startswith(b"\xef\xbb\xbf"): raise ValueError("BOM unsupported, not silently discarded")
    text = data.decode("utf-8", errors="strict")
    if "\r" in text.replace("\r\n", ""): raise ValueError("bare CR unsupported")
    bytepos, n = [0], len(text)
    for c in text: bytepos.append(bytepos[-1] + len(c.encode("utf-8")))
    starts = [0] + [i+1 for i,c in enumerate(text) if c == "\n"]
    pieces, spans, comments, shields, tokens = [], [], [], [], []
    i, outbyte = 0, 0
    def append(a,b,kind,replacement=None,extra=None):
        nonlocal outbyte
        raw = text[a:b]
        out = (raw if replacement is None else replacement).replace("\r\n","\n")
        record = {"kind":kind,"raw_bytes":[bytepos[a],bytepos[b]],
          "formal_bytes":[outbyte,outbyte+len(out.encode("utf-8"))],
          "raw_lines":[bisect.bisect_right(starts,a),bisect.bisect_right(starts,max(a,b-1))],
          "raw_sha256":sha(raw.encode("utf-8")),"formal_sha256":sha(out.encode("utf-8"))}
        if extra: record.update(extra)
        spans.append(record);pieces.append(out);outbyte=record["formal_bytes"][1]
        return record
    while i < n:
        a=i
        if text.startswith("--",i):
            i += 2
            while i<n and text[i] not in "\r\n": i+=1
            raw=text[a:i]
            mask="".join(c if c in "\r\n" else " "*(2 if ord(c)>65535 else 1) for c in raw)
            r=append(a,i,"line_comment",mask)
            comments.append((r,raw));continue
        if text.startswith("/-",i):
            i+=2;depth=1;peak=1
            while i<n and depth:
                if text.startswith("/-",i):depth+=1;peak=max(peak,depth);i+=2
                elif text.startswith("-/",i):depth-=1;i+=2
                else:i+=1
            if depth:raise ValueError("unterminated nested comment")
            raw=text[a:i]
            mask="".join(c if c in "\r\n" else " "*(2 if ord(c)>65535 else 1) for c in raw)
            r=append(a,i,"block_comment",mask,{"max_depth":peak,"doc_comment":raw.startswith(("/--","/-!"))})
            comments.append((r,raw));continue
        if text.startswith("-/",i):raise ValueError("closing comment delimiter in code")
        if text[i]=='"':
            if text.startswith('"""',i):raise ValueError("triple quote form unsupported")
            prefix = text[max(0,i-2):i]
            interpolated = prefix=="s!"
            version_literal = prefix=="v!"
            if i and text[i-1]=="!" and not (interpolated or version_literal):raise ValueError("unknown literal/interpolation prefix")
            if i and text[i-1]=="r":raise ValueError("raw string unsupported")
            i+=1
            while i<n:
                if text[i]=="\\": i+=2
                elif text[i]=='"':i+=1;break
                else:i+=1
            else:raise ValueError("unterminated ordinary string")
            if i>n:raise ValueError("incomplete escape")
            raw=text[a:i];fields=[]
            if version_literal and not re.fullmatch(r'"[0-9]+(?:\.[0-9]+)*"',raw):
                raise ValueError("unsupported Lake version literal body")
            if interpolated:
                # Supported actual cases only: no nested expression quotation,
                # no comments or string literals inside an interpolation field.
                body=raw[1:-1]
                if "{{" in body or "}}" in body:raise ValueError("escaped interpolation brace unsupported")
                cursor=0
                while cursor<len(body):
                    if body[cursor]=="}":raise ValueError("unmatched interpolation close")
                    if body[cursor]!="{":cursor+=1;continue
                    end=body.find("}",cursor+1)
                    if end<0:raise ValueError("unclosed interpolation")
                    field=body[cursor+1:end]
                    if not field or not re.fullmatch(r"[A-Za-z0-9_.' +*/%()\\-]+",field):
                        raise ValueError("unsupported interpolation expression")
                    if "--" in field or "/-" in field:raise ValueError("interpolation comment unsupported")
                    fields.append(field);cursor=end+1
            kind="interpolated_string" if interpolated else ("lake_version_literal" if version_literal else "ordinary_string")
            r=append(a,i,kind,extra={"interpolation_fields":fields})
            shields.append(r);continue
        if text[i]=="«":
            i=text.find("»",i+1)
            if i<0:raise ValueError("unterminated quoted identifier")
            i+=1
            if "\n" in text[a:i] or "\\" in text[a:i]:raise ValueError("unsupported quoted identifier form")
            r=append(a,i,"quoted_identifier");shields.append(r);continue
        if text[i]=="`":
            m=re.match(r"`[A-Za-z_][A-Za-z0-9_\']*(?:\.[A-Za-z_][A-Za-z0-9_\']*)*",text[i:])
            if not m:raise ValueError("non-name quotation syntax unsupported")
            i+=len(m.group());r=append(a,i,"simple_quoted_name");shields.append(r);continue
        if text[i]=="'":raise ValueError("standalone character/quotation syntax unsupported")
        if text[i].isalpha() or text[i]=="_":
            i+=1
            while i<n and idchar(text[i]):i+=1
            word=text[a:i]
            if word=="r" and i<n and text[i] in '#"':raise ValueError("raw string prefix unsupported")
            tokens.append({"word":word,"line":bisect.bisect_right(starts,a)})
            append(a,i,"identifier");continue
        # Group punctuation/whitespace, stopping at lexical boundaries.
        i+=1
        while i<n and not(text.startswith(("--","/-","-/"),i) or text[i] in '"«\'`' or text[i].isalpha() or text[i]=="_"):
            i+=1
        append(a,i,"code")
    transformed="".join(pieces).encode("utf-8")
    return text,transformed,spans,comments,shields,tokens
def main():
    p=argparse.ArgumentParser()
    p.add_argument("--release-root",required=True);p.add_argument("--formal-root",required=True)
    p.add_argument("--comments",choices=EXPECTED);p.add_argument("--start",type=int,default=0);p.add_argument("--count",type=int,default=40)
    p.add_argument("--overview",action="store_true")
    p.add_argument("--selected-indices",default="")
    args=p.parse_args()
    rr,fr=pathlib.Path(args.release_root),pathlib.Path(args.formal_root)
    rb=(rr/"release.json").read_bytes()
    if sha(rb)!=RELEASE_SHA:raise ValueError("release pin mismatch")
    rel=json.loads(rb)
    if [x["path"] for x in rel["inputs"]]!=list(EXPECTED):raise ValueError("release member set/order unsupported")
    fb=(fr/"formal-inputs.json").read_bytes()
    if sha(fb)!=FORMAL_MANIFEST_SHA:raise ValueError("formal inventory pin mismatch")
    old={x["path"]:x for x in json.loads(fb)["inputs"]}
    evidence=[]
    for item in rel["inputs"]:
        name=item["path"]
        if args.comments and name!=args.comments:continue
        raw=(rr/name).read_bytes();formal=(fr/name).read_bytes()
        if len(raw)!=item["bytes"] or sha(raw)!=item["raw_sha256"]:raise ValueError("raw pin mismatch "+name)
        if sha(formal)!=item["prior_formal_sha256"] or sha(formal)!=old[name]["formal_snapshot_sha256"] or sha(raw)!=old[name]["production_raw_sha256"]:raise ValueError("association mismatch "+name)
        if name.endswith(".lean"):
            text,out,spans,comments,shields,tokens=bounded_scan(raw)
            if args.comments:
                selected=[int(x) for x in args.selected_indices.split(",") if x] if args.selected_indices else list(range(args.start,min(args.start+args.count,len(comments))))
                if any(k<0 or k>=len(comments) for k in selected):raise ValueError("comment selection out of bounds")
                for k in selected:
                    r,body=comments[k]
                    if args.overview:
                        clean=re.sub(r"\s+"," ",re.sub(r"^/[-!*]+|[-]+/$","",body)).strip()
                        flags=sorted(set(re.findall(r"(?i)\b(?:prove[ds]?|compiled|accepted|paper|source|unitary|normaliz\w*|gap|false|missing|open|refut\w*|counter\w*)\b",clean)))
                        print(json.dumps({"index":k,"lines":r["raw_lines"],"first_180_characters":clean[:180],"lexical_keyword_flags":flags},ensure_ascii=False))
                    else:
                        print(json.dumps({"index":k,"lines":r["raw_lines"],"text":body},ensure_ascii=False))
                return
            if out!=formal:raise ValueError("independent transform mismatch "+name)
            if "bounded_comment_regions" in old[name] and len(comments)!=old[name]["bounded_comment_regions"]:raise ValueError("comment count mismatch "+name)
            control=[t for t in tokens if t["word"] in {"import","set_option","macro","macro_rules","syntax","declare_syntax_cat","elab","elab_rules","initialize","run_cmd","unsafe","axiom","sorry","admit","native_decide","implemented_by","extern","include","omit","variable","variables","universe","universes"}]
            custom=[t for t in control if t["word"] in {"macro","macro_rules","syntax","declare_syntax_cat","elab","elab_rules","initialize","run_cmd","axiom","sorry","admit"}]
            if custom:raise ValueError("custom syntax/elaboration/proof placeholder requires separate interpretation "+str(custom))
            evidence.append({"path":name,"raw_sha256":sha(raw),"raw_bytes":len(raw),"formal_sha256":sha(formal),"formal_bytes":len(formal),"raw_to_formal_exact":True,"raw_CRLF":raw.count(b"\r\n"),"raw_BOM":False,"comments":len(comments),"comment_utf8_bytes":sum(r["raw_bytes"][1]-r["raw_bytes"][0] for r,b in comments),"line_comments":sum(r["kind"]=="line_comment" for r,b in comments),"block_comments":sum(r["kind"]=="block_comment" for r,b in comments),"max_nested_depth":max([r.get("max_depth",0) for r,b in comments]+[0]),"doc_comments":sum(r.get("doc_comment",False) for r,b in comments),"shields":shields,"control_tokens":control,"changed_comment_spans":[r for r,b in comments],"comment_text_emitted":False,"noncomment_segment_digest_checks":all(r["raw_sha256"]==r["formal_sha256"] for r in spans if r["kind"] not in {"line_comment","block_comment"} and "\r\n" not in raw[r["raw_bytes"][0]:r["raw_bytes"][1]].decode("utf-8")),"segment_counts":{k:sum(r["kind"]==k for r in spans) for k in sorted(set(r["kind"] for r in spans))}})
        else:
            if raw!=formal:raise ValueError("non-Lean config not byte identical "+name)
            evidence.append({"path":name,"raw_sha256":sha(raw),"raw_bytes":len(raw),"formal_sha256":sha(formal),"formal_bytes":len(formal),"byte_identical":True})
    print(json.dumps({"schema":"C121_INDEPENDENT_BOUNDED_INSTANCE_AUDIT","all11_associations_passed":len(evidence)==11,"general_Lean_lexer_proof":False,"parent_method_executed":False,"files":evidence},ensure_ascii=False))
if __name__=="__main__":main()
