"""Deterministic bounded lexer tests, not Lean execution or a general proof."""
import importlib.util, json, pathlib
p=pathlib.Path(__file__).with_name("independent_raw_audit.py")
s=importlib.util.spec_from_file_location("c121_own_scanner",p)
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
cases=[
 ("ordinary_literal_shields_comments",'"x /- y -- z \\\" end"', '"x /- y -- z \\\" end"'),
 ("quoted_identifier_shields_comments","«/-x--»","«/-x--»"),
 ("nested_comment","a/-x/-y-/z-/b","a"+" "*11+"b"),
 ("CRLF_code_and_comment","a\r\n/-x\r\ny-/\r\nb","a\n   \n   \nb"),
 ("line_comment","a--x\r\nb","a   \nb"),
 ("astral_comment_utf16_width","/-😀-/"," "*6),
 ("identifier_prime","def x' := 1","def x' := 1"),
 ("simple_interpolation",'s!"name_{p.n}_{row}"','s!"name_{p.n}_{row}"'),
 ("Lake_version",'v!"0.1.0"','v!"0.1.0"'),
 ("simple_name_quote","`ABEISTests.Basic","`ABEISTests.Basic"),
]
rejects=[
 ("raw_string",'r"/-not comment-/"'),
 ("hash_raw_string",'r#"x"#'),
 ("character_literal","'a'"),
 ("bare_CR","a\rb"),
 ("BOM","\ufeffa"),
 ("unclosed_block","/-x"),
 ("unclosed_string",'"x'),
 ("unclosed_quoted_identifier","«x"),
 ("stray_close","-/"),
 ("unknown_interpolation",'m!"x"'),
 ("nested_quotation","`(term|x)"),
 ("complex_interpolation",'s!"{x/-y-/}"'),
 ("quoted_identifier_escape","«x\\y»"),
 ("triple_quote",'\"\"\"x\"\"\"'),
]
out=[]
for name,raw,want in cases:
    got=m.bounded_scan(raw.encode("utf-8"))[1].decode("utf-8")
    out.append({"name":name,"expected":"ACCEPT_EXACT_TRANSFORMATION","pass":got==want})
for name,raw in rejects:
    try:m.bounded_scan(raw.encode("utf-8"));ok=False
    except ValueError:ok=True
    out.append({"name":name,"expected":"REJECT_UNSUPPORTED_OR_MALFORMED","pass":ok})
print(json.dumps({"schema":"C121_OWN_SYNTHETIC_TEXT_TESTS","tests":out,"all_pass":all(x["pass"] for x in out),"not_a_general_Lean_lexer_proof":True}))
