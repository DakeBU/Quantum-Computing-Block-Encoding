# Statement, definition, phase and reference audit

## Typed correspondence to the immutable source-only contract

| Own source-only name | Candidate name or expression | Type / meaning |
| --- | --- | --- |
| J | zeroInsert | WorkBasis by DataBasis, 8 by 4, target zero inserted |
| T | evalPrimitiveProgram ccx3Program = U | WorkBasis by WorkBasis, 8 by 8, actual CCX program semantics |
| V=TJ | U zeroInsert | 8 by 4, graph produced rather than assumed |
| M_m | xBra m = K_m | DataBasis by WorkBasis, 4 by 8, target removed |
| C_m | conditionalCZ m | 4 by 4, diag(1,1,1,(-1)^m) |
| K_m=C_m M_m | conditionalCZ m * xBra m | 4 by 8, corrected destructive branch |
| Q_m=J C_m M_m | zeroInsert * conditionalCZ m * xBra m | 8 by 8, reset-shaped linear branch |
| Q_m V | proposed selected operator product | 8 by 4, exactly branchScale times J |

The candidate calls its uncorrected X bra K_m, whereas my source-only notes call that map M_m. This is a naming translation, not an operator mismatch. Native carriers are functions Fin2 -> Fin2 and Fin3 -> Fin2. The retained coordinates are 0,1 and the target is 2. No implicit little-endian flattening is needed or licensed.

Every product is right-to-left. J C K U J first inserts a zero target, then runs the actual program, then destructively removes the target, then corrects the retained phase, then reinserts target zero. Its final output has eight coordinates and its input has four. The optional C K U J output has four coordinates and satisfies a separately typed scaled-identity equation. It cannot replace the selected reset-shaped signature without changing the codomain.

## Literal bodies

zeroInsert is an identity on the retained coordinates and a ket-zero on the target. It has no alpha, m, AND graph, old helper, or final-action dependence. It is defined on every retained vector. Its left-isometry identity is a supplier, not a theorem premise.

xBra uses H[m,x 2] times the delta matching the retained coordinates. Its full input carrier is all eight basis states, not a support-restricted graph. It mentions neither AND nor alpha nor desired output. Static reading of actual H entries verifies that m=0 gives the plus bra and m=1 gives the minus bra, with the chosen positive real scale. This prevents a phase convention from being guessed from H squared alone: H squared would also hold for -H, which would not give the requested exact positive scalar.

conditionalCZ specializes the actual phasePermutationMatrix with identity permutation. That matrix uses phase(column), but on an identity diagonal row=column, so it is exactly the required conditional sign. C125 supplies the literal sign definition: negative exactly for m=a=b=1. There is no state- or measurement-distribution assumption. This remains an ideal matrix, not a newly compiled conditional-CZ program.

ccx3Program is constrained to the existing primitiveCCXProgram at the three distinct fixed wires. Static reading confirms the actual definition composes primitive H and a phase/CX middle program rather than declaring its target matrix to be CCX. The source theorem primitiveCCXProgram_eval matches the proposed API, including global phase, and uses ccxBasisEquiv with the stated target-distinctness arguments. I did not audit its full implementation proof graph or compile it.

The old correctedTemporaryAndBranch is a literal coefficient formula with t=0 support. That is appropriate as the separately named algebraic helper. The successor does not call that formula an executed program; it requires a new theorem connecting actual UJ and full-carrier K,C,J to the helper before invoking the old equality. No circular desired-output definition was found.

All definitions are literal, not choice/characterization/phase-quotient definitions. No off-graph fallback manufactures semantics: K,C,J already have their intended meaning on the full carrier; the computed graph is established by UJ. Input target zero is represented by the explicit rightmost J, not a hidden clean-ancilla binder.

## Complete families and exact branch scale

The proposed validations J^*J=I_4, C_m^*C_m=I_4, and sum_m K_m^*K_m=I_8 are correctly typed. For L_m=J C_m K_m, associativity gives

    sum_m L_m^*L_m
      = sum_m K_m^* C_m^* (J^*J) C_m K_m
      = sum_m K_m^*K_m = I_8.

Thus the required three validation suppliers also justify full-carrier completeness of the ideal reset-shaped family; a further foundation or new correctness premise is not required. The package must not advertise validated ideal operations if those suppliers remain unproved.

Uniform half-mass follows only after actual clean-input compute and corrected branch action. It is not inferred from full-carrier completeness. For a general full-carrier input, an X outcome need not have probability one half. The candidate does not make that erroneous generalization. On retained input, the root yields each branch sJ, with s=sqrt(2)/2=1/sqrt(2)>0. Hence each branch mass is half of input mass and the sum of the two corrected branch masses equals input mass. No scalar or outcome-relative phase is discarded.

The retained input is arbitrary complex data. Slice-wise alpha:R->Fin2->Fin2->Complex is sufficient for all finite-reference entanglement after explicit reindexing between (D,R) and (R,D). The candidate's optional tensor convention is reference-first, I_R tensor O_m, while my source-only explanatory order was D,t,R. These are explicitly related by the coordinate swap, not treated as definitionally equal carriers. The optional identity-reference formula is correct by summing the identity delta over the reference index; it requires finite R only for the matrix sum, not for the pointwise-r theorem. Its output-index type O need not be finite because mulVec sums only input indices.

The candidate makes no l2 or density assertion for an infinite arbitrary R. For finite R, the explicit normSq sums agree after the native coordinate-sum adapter. The supplied finTwoArrowEquiv maps the two retained coordinates to a pair. Fin.snocEquiv maps (target,retained tuple) to WorkBasis, with inverse (last coordinate,Fin.init); the sum adapter must include this order and any finite-sum commutations. The root does not require normalization. The optional normalized corollary's inputMass alpha=1 is a premise only of that explicitly specialized corollary, not a new root premise or a disguised half-mass assumption.

## Source-use boundary

The selected theorem has no use program, so it proves compute immediately followed by cleanup, equivalently identity use. Source equations (11)-(12) include a use interval schematically; this narrower local successor is honestly advertised and does not claim the full source consumer. A future nonidentity use requires its own graph-preservation producer on current retained labels and all relevant workspace. Adding arbitrary use without that producer would require a new reviewed statement and is not covered by this approval.

Destructive removal plus zero insertion is explicit. No discarded environmental state is silently reset, no physical live-wire reset is asserted, and no density partial trace is identified with an amplitude map. Adaptive outcome generation, Born interpretation, classical record/control, hardware readout/reallocation, gate/depth/connectivity/finite-bit resource claims and source-circuit or SP/BE admission all remain excluded.
