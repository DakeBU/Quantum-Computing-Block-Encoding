# Independent operation-statement review

Reviewer: temporary_and_operation_statement_review_c120.
Review stage: proposal comparison after immutable SOURCE_ONLY derivation.

## Precise verdict

APPROVED_TO_SIGNATURE_ONLY_COMPATIBILITY_PROBE for the composite C117.native3.finite-linear.reset.v1 design plus additive C125.v1 exact dependency-interface supplement. No concrete unacceptable definition or proposed signature was found and no mathematical correction is required before that isolated probe. After the probe validates the exact bodies/imports/signatures, the parent may establish the actual Statement Seal and enter a separately authorized proof phase. This is approval of the bounded mathematical design and proposed interface, not an accepted Lean proof, compiled signature, actual Statement Seal already issued, production admission, physical/adaptive/Born semantics, resource certificate, source-circuit admission, or SP/BE root closure.

The unchanged C117 packet ALONE had a real exact-dependency-API gap. It named the helper declarations but referred to a prior own-formal interface inventory not present among its twelve files. I found and reported this gap after reading the complete actual candidate. The parent then separately authorized C125.v1, whose six literal definitions, five complete theorem headers, ambient import/namespace information, and binding document close this review-input gap. This later disclosure is not treated as having been present in C117 at first exposure. No C117 file or source-only file was changed.

No mathematical correction to the selected finite-linear root is required. The composite root is exactly

    J C_m K_m U J = branchScale * J,  m in Fin 2,

where U is the evaluated actual existing CCX program on named wires 0,1,2, not an AND-state definition; J inserts target zero; K_m is the full-carrier retained-identity times row m of the actual Hadamard matrix; C_m is the full-carrier outcome-dependent CZ sign. It starts with a zero target and has NO intervening use program. It does not certify arbitrary use intervals.

## Comparison with my prior independent source interpretation

The source-only contract fixed target-last tensor order, positive scale s=1/sqrt(2), and X outcome 0=plus, 1=minus. The candidate's native function carriers are equivalent by the explicit coordinate map x -> (x 0,x 1,x 2), not by a guessed Fin8 memory order. Static reading of hadamardMatrix_apply gives the real entries sqrt(2)/2, sqrt(2)/2, sqrt(2)/2, -sqrt(2)/2. Thus its defining i-prefactor is already accounted for; no residual i or branch-global phase remains. Its branchScale is precisely the same positive s.

For each retained basis label ab, the actual CCX semantics sends J|ab> to |ab,andBit(a,b)>. The full-carrier destructive row then contributes H[m,andBit(a,b)]; the diagonal correction contributes conditionalCZSign m a b. Their product is branchScale in all eight combinations of m,a,b. The final J places this amplitude only at target zero. This is a direct basis derivation, extended by complex linearity, not a numerical experiment or proof-assistant execution.

The new composition theorem must establish equality with the old corrected helper FROM these operations. The helper's zero-output definition is not a substitute for this bridge. The dependency chain retains actual graph production before helper reuse, so the proposal does not make correctness true merely by assigning the desired output to U or K_m.

## Mandatory pre-proof pending steps

1. Stage/import the exact experimental helper as isolated module TemporaryAnd, pinned to raw SHA-256 26d7ed676f345a671d020e76078b0b866ff4364ca1632698d22027d3a9695be4. This is the parent's later resolved integration fact, also confirmed in C125. C117's references to a pending or production helper import are stale plumbing prose, not evidence of an admitted production QuantumBlockEncoding helper. No source was opened or compiled here to validate that import.
2. Bind the actual new four definition bodies and proposed theorem signatures to a versioned source artifact and the exact dependency/toolchain context before proof work. Their bodies must literally implement the entrywise schema already approved here; semantic changes or a necessary signature correction require a versioned successor and renewed relevant review, not silent weakening.
3. In a separately authorized phase, perform signature-only elaboration/import compatibility checks and issue the actual Statement Seal. The proposed signatures have only been read statically in this review. Do not call them elaborated on the basis of mathematical plausibility.
4. Later prove every required supplier and the selected root, with actual focused/repository gates and publication gates appropriate to the eventual module. The existing helper theorem headers are dependency-API evidence here, not revalidated proof bodies, fresh compiler results, or a substitute for these gates.

These pending steps do not add hypotheses to the root. They are evidence and implementation obligations outside this design-only review.

## Findings summary

PASS: full-carrier literal definitions; dimensions and multiplication order; exact outcome-dependent phase and scale; arbitrary complex amplitudes and pointwise arbitrary reference labels; only intrinsic type/carrier/wire inputs; actual CCX graph producer; distinct helper-composition producer; complete required operation-validation AND tails; explicitly typed reset/discard alternatives; finite normSq mass rather than an illicit function-space L2 identification.

CLOSED_BY_ADDITIVE_SUPPLEMENT: exact helper API/ambient gap discovered in the original C117 packet.

PENDING_NOT_TESTED: actual body text, signature elaboration, exact staged import execution, proofs, compiler acceptance, and all higher semantic/resource/publication gates.

No source error, extra logical correctness hypothesis, silent discard/reset substitution, arbitrary-use claim, or desired-output operation definition was found in the composite design. The proof strategy is plausible and mathematically consistent with the source-only derivation; no claim of proof completion follows.
