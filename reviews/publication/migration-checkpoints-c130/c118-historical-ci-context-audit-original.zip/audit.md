# Independent bounded audit of frozen optional diagnostic context debt

## Finding

The red frozen-source checks are valid refusals of different bytes, not evidence that the migrated theorems are false. No source hash exception should be waived. No old profile, fixture, generated expectation, validator, score, source target or historical observation should be edited to make the current checkout green.

Two scientific objects must remain distinct: the historical baseline and the proof-only candidate derived from it. Several jobs are transformation/reproduction experiments rather than arbitrary current-checkout scanners. At present their unchanged entrypoints require the old source as baseline, while production already contains their new candidate. Their names containing “native” mean actual host Lean runtime observation, not a requirement to retain native_decide proofs or a grant of native-axiom policy acceptance.

## Own measured facts

I read the actual1b072e87f59a6825597e4b6d49cd3b3ac4f1c9fb diff, whose parent is1a4d0522f1f76ba26bd7a1fa20b9fb2bb4cf6fe4. It changes three CAP proof tokens and nine CSP proof-body sites, no declaration signatures/import/data-definition bytes. CAP replaces three native_decide tokens by decide +kernel, retaining +revert. CSP makes eight decide +kernel substitutions and one exact Rat.sub_self substitution. These are proof-body changes, not a state/operator/resource-contract repair. This static statement does not claim a new kernel compilation, operational speed or TCB equivalence.

| Module | Frozen baseline SHA256 | Current installed/candidate SHA256 |
| --- | --- | --- |
| CubicAmplitudePrimitive |48c9a4a1c47c925c93493eede21eb7b492d23d2cb7dadf254782e4485c349cb3|952e2b359796ef695a1b1c1a376d40a80affbc679f503f94227ea0c775a6cd48|
| CubicStatePreparation |d125f8c239bca1c15e6e4fa6e788df6dd8984394630cb2dcc9be8946c4cbcb55|6ee53311b5d6e18c46afb3e068341689acb86f1bdbc425e774705e81c9142f44|

The current committed blobs equal the exact post-migration blobs. CAP is9513 rather than9510 bytes; CSP is166496 rather than166483. Both current local raw files equal their committed blobs with zero CRLF.

I independently hashed precisely the C34ci5 ZIP's220 authorized candidate paths against git show HEAD blobs, without inferring extra source membership from directory traversal. Exactly218 still equal the frozen vector; exactly the above two differ. This independently agrees with the earlier C112 diagnostic, rather than assuming its expected result. Hashing was sequential, not an atomic global checkout lock or semantic read of all220 files.

Ten other local files are CRLF raw spellings different from their committed Linux blobs; all220 local/newline-normalized contents equal the corresponding normalized committed content. Their two raw SHA values and lengths are preserved separately. Normalization is not used as raw byte equality or a new acceptance rule. Exact current toolchain/manifest/lakefile local and committed hashes agree respectively:
302cd63c54178885b89e669f33b38f12f4dd7ae7e5cac537b3203e3768d8fb2b,
510171e8214a2ac5e00f16c1bf92ad474d2de42c4cd2dc2b3d411272f7b58763,
f6637c3a2467fdeee6b2de72505d0581c4a49793388197bd8e9e7df3f5817fc1.

Five independently compared profile vectors establish:
- Original C31v1:31 inputs, two current mismatches; all CI2/3/4 resource wrappers retain that original vector.
- CAP-only kernel-derived profile:31 inputs, one current CSP-provider mismatch.
- Joint entry's original31:two current mismatches.
- Existing joint-derived c31-profile.json SHA955a1300915eff199d59d9d0bb864090ae398fa1560548f397d621e4f3cb6943:all31 exactly match current committed AND local bytes.
- Original C29 diagnostic nine-input vector:one current CSP mismatch.

The joint-derived match is useful reuse evidence, not permission to run its original-baseline setup on current files or call an old success current-head acceptance.

## Actual code causes and job scopes

R/tools/cubic_c29_diagnostic/runner.py:331 checks frozen projectInputs before native calls;:335-338 retains the old generated expectation;:388 separates a genuine legacy API fixture from Cubic evidence. The original target diagnostic has319 source roots/50private, original generated-field expectations and two supplemental complete types. Its unmodified old pin is deliberately not a universal current-source validator. A raw source update can change generated native/auxiliary declarations even when theorem statements are unchanged.

C31v1 runner.py:109 and:166 check all31 source/config inputs. Its collector/validator covers87 roots including8private plus every actually owned generated constant; it observes kernel/types/universes/unsafe/value availability and recursive axioms. Values are unrequested; no axiom whitelist, source agreement, scientific acceptance, nativeAccepted or full trust closure is granted. CI4 runner:27 loads the immutable CI3 package; CI3:33 loads CI2; CI2:44 loads v1 and:202 rechecks original31. Changing a top-level hash alone cannot fix this nested old-profile/code-manifest chain. Resource/mount/namespace corrections were separate instrumented experiments, not current-source reapproval.

C29 kernel-only runtime in the10-member ZIP statically verifies exact old CSPd125 and its nine substitutions, then verifies originalProjectInputs before compiling candidate6ee. The two-types supplement calls that prior execute first and later rechecks its original vector. It requires the same fresh artifact and cannot reuse a type stream from a different source/cohort.

C31 proof_patch.py:42-43 explicitly rejects any starting bytes except CAP48c9; runtime.py:66 calls that transformation, and:149 rechecks original31. The v2 executing-file and v3 shadow-helper guards do not relax source pins. Candidate952e is already production, but current CSP6ee is not the original inherited CSPd125. The correct setup is therefore historical-baseline transformation, not a fresh scan of the installed pair.

Joint entry.py:68-95 requires original31 and verifies both exact proof candidates;:82 and:193 enforce the original baseline repeatedly. Its candidate view uses the current pair and removes CSP from inherited providers, compiling CSP before PrimitiveMacros/UCRy/CAP in one cohort. Its full CSP probe and two-type supplement must resolve the same fresh CSP artifact used by consumers.24 other project providers remain inherited. Dynamic generated rows and strict per-row signature/axiom relations must remain, not be replaced by fixed guessed counts.

C34ci5 launch.py:14 binds ZIP97bfea091bf49cc17790aa52a3dab0f5e1d8316f2cef129e1989e5159ec35578 and seal27e4809bb7ec98fe0d3872ae314353f11e6dc1f75dda4f6a4d9d4b460edc8e24. ZIP discovery.check_candidates checks every220 candidate path/byte before compiler import discovery. The candidate universe is not a proven provider closure; actual Lean.Elab.parseImports records derive the closure later, preserving import flags and rejecting missing project imports/cycles/order errors. Dropping the two changed files merely because they might not be imported would weaken this exact-universe promise.

The C34 target vector remains57 roots/4private in RealAmplitudePreparation, RealIsometryCompletion and ConstructiveIsometryLocal; none of those three source/root vectors is changed by the two Cubic proof edits. This is not a claim that its runtime-derived provider closure is already known in this audit. All generated ownership remains observed dynamically. C34 validator counts unsafe/self-axiom and kernel/elaboration differences as observations, not an axiom-policy success. Its NO_ACCEPT fields must remain false/null after a successful stream.

C34 test_discovery.test_current_complete_candidate_set_is_frozen_not_a_closure calls the exact candidate byte guard. test_serial_policy.test_serial_flag_and_immutable_scientific_inputs also independently hardcodes old candidate SHAab18ce50206601436fdc5b2e8bbff2450375333894f37b4129c7a63c724eaa22 and profile SHAde5a1ebb544315a081c6f07953acd40c8ba12db8abc3f88a3d07e85d817ecb78. Updating only the candidate JSON leaves that fixture honestly incompatible. Editing its expected constants in place is not a valid solution.

## A further historical transport distinction

C34ci1's candidate manifest is476c639f25c4044df46140b6decc13a7031d352a8aeece3f1b02792b8303397d, notab18... . It binds the ten Blueprint/root files' original Windows CRLF raw bytes, exactly the ten spellings observed locally now. C34ci3,ci4,ci5 instead share the committed-LF ab18 vector. ci1's profile remains the earlier3072 envelope; ci5's active envelope is5120 with2048 reserve and7168 measured headroom.

Thus one ordinary historical Linux Git checkout cannot be assumed to satisfy every older version's raw snapshot. ci1 requires its authentic exact raw snapshot, or honest reproduction of its known transport refusal. Do not normalize its old hash, retrospectively reinterpret it as LF, or change its fixture to conceal that failure. Later versions already encode a separate versioned transport correction; keep both histories.

## Existing scientific and runtime evidence is not zero

I projected only the two allowed publication records and read their four actual role wrappers. Their directly named packet/artifact hashes match. Both records say ACCEPTED_LOCAL_SOURCE_CURRENT_CONTEXT_FULL_INTEGRATION_PENDING and bind the actual new source pair. Existing distinct reviewers/decoders report earlier actual isolated/joint candidate observations, ordinary propext/Classical.choice/Quot.sound, exact proof-only lineage and limited source alignment. The CAP evidence explicitly refers to a previous same-cohort joint vector; CSP retains319 signature and449 generated observations plus96 ordinary generated value omissions.

I did not newly execute those observations or recursively reread their external evidence trees. Their accepted limited source/candidate assessment is not erased by an old profile's current failure. Conversely it does not certify a new installed-head optional CI job, full current repository/Tests, clean-transitive/native TCB, all proof-body text, normalized SP, finite-bit quantum resources, family ROOT or PURIFIED. Publication source fidelity, actual focused kernel compilation and native diagnostic stream completeness are distinct evidence layers.

C102's actual prior C31 failure and C112's C34 failure are other-producer log observations: source-pin mismatch, with no Lean launched by the failed C34 Python step. I did not fetch network logs or rerun those suites. C116 reports scoped HBI installation and no full repository/site gate, not a cure of Cubic diagnostic contexts. Branch-protection/required-check settings were not read; optional WIP wording in these workflows and NO_ACCEPT code does not prove what a maintainer configured as required.

## Current debt and correct red-light disposition

The active current-checkout invocations remain unsatisfied and should remain red/pending until an explicitly reviewed route runs in its actual scope. It is scientifically correct to retain that state now. Do not use continue-on-error, skip/xfail, trigger filtering, forged historical/current source hashes, restored old production proofs or a renamed green badge to hide it.

Historical reproduction can legitimately become green only as historical reproduction on exact historical inputs. A separately bound current successor or current-candidate association may discharge a narrow current diagnostic obligation after actual matching observations and independent review. No automatic source/publication/TCB approval follows. The separate installed-lean433-full workflow's real library+Tests commands remain independent; optional red-pin observations are neither mathematical counterexamples nor a replacement for those commands.

