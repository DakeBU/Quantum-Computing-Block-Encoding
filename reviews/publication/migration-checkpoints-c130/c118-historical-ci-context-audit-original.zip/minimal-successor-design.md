# Minimal non-weakening design — not implemented or accepted

## Zero-change immediate decision

Keep every old profile, test, fixture, source, archive, validator, score and observed failure byte unchanged. Do not revert installed952e/6ee proofs. This packet diagnoses the debt; it does not make any old job green or authorize Lean execution.

A small additive source-context/transport/test release is preferable to a controller refactor or another agent layer. There are two different interfaces, not one “hash refresh” switch.

## Lane H: genuine historical reproduction

Add one opt-in historical replay descriptor, not a source-acceptance record. It pins:
1. Source checkout candidate1a4d0522f1f76ba26bd7a1fa20b9fb2bb4cf6fe4, exact selected old9/31/220 source-vector identities and ALL three config hashes.
2. Independently pinned immutable runtime-tool/package release, archives, exact members, manifests, tests, helper/collector/parser/validator/resource code. It may be a later transport release containing unchanged older packages; never claim that all code came from the historical source commit.
3. Actual platform/toolchain binary version/digest, inherited provider origins/bytes, effective search order, finite caps and new exclusive output root.

The source-commit candidate is not certified by this audit as a complete historical checkout. A future run must fail before tests/Lean unless every applicable frozen vector and config matches. If the commit lacks needed files, locate an actual matching snapshot under separate read authority; do not invent it or overlay old hashes into current R. Historical source and execution-release directories are physically separate, source copies have honest origin/copy receipts, and production R is never mutated. No project-target cache may leak from the installed current checkout into a claimed historical/fresh cohort.

Run all selected original Python suites unchanged in their own original package+source context; then only separately authorized native execution with unchanged guards. ci1's CRLF snapshot is a different historical source object from ci3/4/5's committed-LF snapshot. An unavailable raw snapshot is an ENV/context blockage or a reproducible known failure, not permission to rewrite expectations.

Any green status names the historical source/config/tool release, not the PR HEAD. The original current-invocation failure remains preserved. Routing a historical lane does not remove a still-required current diagnostic lane. Do not change trigger paths merely to avoid observing source drift.

## Smallest C29/C31 reuse: current association, not another proof candidate

The existing joint-derived31 vector already equals current blobs in all31 entries. CAP952e and CSP6ee need not be generated or proved again by another mutation design.

If independently reviewed actual joint receipts are available, add ONE current-context association record (and its tests) binding:
- historical original source vector and unchanged experiment/validator versions;
- exact current31 source/config vector and complete candidate31 equality;
- actual four fresh target source/copy hashes and ordered cohort;
- CSP artifact hash/path actually used by both CSP probes and all consumers;
- real compiler binary/version, PID/exits/timeouts, provider and absent-root inventories, search precedence and before/after hashes;
- the original actual stream/relational comparator verdicts and genuine independent assessment;
- current-association scope, inherited-provider limits and every NO_ACCEPT flag.

This is a point-in-time artifact/source-context association. Source/config equality alone does not re-date an old run or establish current installed-head/global acceptance. If later actual evidence is required by integration policy, replay the unchanged joint experiment in Lane H, then independently bind the resulting current candidate bytes. No comparison algorithm changes, source inverse patch in production, profile replacement or new mathematical candidate is needed. This option reuses the exact stronger four-target cohort; separate candidate successes must not be substituted for joint evidence.

Where the objective specifically requires a new direct current-checkout C31 three-target diagnostic, a small separate current-input-view entrypoint is possible, but not a one-field edit:
- New sealed profile contains exact current31 data: CAP module+input952e and CSP provider6ee; roots87/private8/options/structure vectors and generated-baseline nulls unchanged.
- Reuse byte-identical v1 collector/validator/orchestrator and CI4 resource/CI2 receipt APIs, loaded from their original pinned technical packages. Verify all old CODE manifests; do not call the old transformation runtime's old-source guard and then pretend it accepted current source.
- Build one exclusive REAL current31 filesystem view plus exact shared-helper copy and new profile/driver manifest, then let unchanged base.run validate that new view. The profile is explicitly NEW_CURRENT_RUNTIME_INPUT_VIEW, never the original v1 seal.
- Keep every source/copy/provider/entry/revalidation and target-cache/search gate. The plain three-target lane still inherits CSP and cannot claim joint-fresh CSP; use the joint option if that stronger obligation is wanted.
- New current-context tests and independent entrypoint review are mandatory. The old original-source suites remain unchanged in Lane H.

This is a bounded new adapter/data release, not a waiver of the old experiment or broad refactor. Until reviewed and actually run, it is pending.

## Lane C34: new context data under unchanged verification algorithms

The latest ci5 core already accepts a separately approved sealed package. A current-source successor can retain exact runner.py, bindings.py, discovery.py, validator.py, Parser.lean, Collector.lean, pending drivers, resource_adapter.py and all three pinned resource-vendor algorithms. Keep profile/root vectors and its5120/2048/7168/thread1/timeouts/target-only Elab.async=false/no-retry envelope byte-identical if their fields remain valid.

Make only additive new release objects, for example tools/real_preparation_native_c34_current_context_v1/:
- New candidate-source vector: same ordered220 paths/module identities and raw current committed-blob hashes/lengths; currently exactly the two Cubic rows differ. This is a reviewed new source context, not an edited old vector.
- New runtime manifest/seal/archive binding changed DATA plus exact unchanged algorithm hashes and an explicit predecessor/delta. Use byte-preserving transport and verify commit/archive/raw member bytes.
- One tiny launcher/transport selector with separately reviewed new release ID, archive/member/seal pins and exclusive release/workspace routing; no verifier/scoring/resource/source-policy change.
- One new current-context test suite/association file and clear provenance/remaining boundary.

Do not copy a stale “35 passed” result into the new release. The old35 suite, including hardcodedab18/de5a assertions, continues to run UNCHANGED against the old ci5 archive in Lane H. A new current runtime-only transport may reference the old fixture archive without treating its historical data constants as current fixtures; omission from runtime payload is not a skipped scientific check, and must not be represented as that old suite passing. New tests exercise the new data+unchanged algorithms and the full negative obligations in test-plan.json; any reduction in actual guarded behavior fails review. If the maintainer requires the old suite to pass in the current source context specifically, that demand is currently inconsistent with its frozen byte assertions: preserve red rather than suppress tests.

The actual current successor must still run complete candidate membership/byte checks, real compiler-derived import closure, reject target inheritance/fallbacks, freshly compile all three targets and collect all57 roots plus dynamic generated rows. No supplied provider JSON, guessed closure, guessed generated count or hash-only success substitutes for those actions. Whether Cubic is actually in the discovered provider closure is left to the real parser observation; all220 candidate pins are required regardless.

Keep fixed OUT_RELs separated by genuinely fresh workspaces if code remains byte-identical. Do not rewrite an old output directory, reuse receipts, or monkeypatch sha/path names. A rollback removes only new release/selector/association paths and returns to the documented old behavior, possibly the known red state.

## Minimal integration delta and promotion conditions

The immediate implementation diff is ZERO. A later authorized implementation should add only the chosen descriptor/release/tests and, after independent acceptance, narrowly change the optional workflow selector and truthful labels to that new current release. Retain original test invocations in their explicit historical lane, not hidden filters. No source/checker/scoring changes, no new agent/task layer, no broad process refactor.

Before changing any active selector:
- Independent technical reviewer verifies code-byte identity, the complete new raw source/config vector, any adapter's actual entry/import identity, untouched historical fixtures and a truthful old/new scope map.
- Run synthetic/negative transport/context tests and original historical suites in correct contexts, preserving actual failing observations. Test success is not Lean evidence.
- Obtain separate finite hosted-CI execution authority. Actual memory/namespace conditions, real exits, timeout and completeness decide results; success is not predicted.
- Independently review actual new source/artifact/cohort association and record its limited runtime scope. Existing source/semantic publication reviews may be reused only with exact current bindings; a new success is not automatically scientific admission.
- Keep repository library+Tests, site/publication/integration, clean-TCB, finite-bit quantum/family and PURIFIED gates separate.

A proposal seal or this design's positive feasibility assessment is not acceptance of any future successor.

