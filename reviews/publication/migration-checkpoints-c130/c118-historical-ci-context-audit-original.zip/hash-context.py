"""Bounded read-only hashing. Never imports/executes an audited package."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import zipfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git_blob(repo, rev, path):
    return subprocess.check_output(["git", "show", rev + ":" + path], cwd=repo)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True)
    args = parser.parse_args()
    repo = Path(args.repo)
    arc = repo / "tools/real_preparation_native_c34_ci5/public-runtime-package.zip"
    raw = arc.read_bytes()
    assert digest(raw) == "97bfea091bf49cc17790aa52a3dab0f5e1d8316f2cef129e1989e5159ec35578"
    with zipfile.ZipFile(arc) as z:
        names = z.namelist()
        assert len(names) == len(set(names)) == 31
        vector_bytes = z.read("candidate-sources.json")
        vector = json.loads(vector_bytes)
        members = [{"name": n, "bytes": len(z.read(n)), "sha256": digest(z.read(n))} for n in names]
    rows = []
    exact_paths = [r["relativePath"] for r in vector["files"]]
    assert len(exact_paths) == len(set(exact_paths)) == 220
    for row in vector["files"]:
        name = row["relativePath"]
        path = PurePosixPath(name)
        assert not path.is_absolute() and ".." not in path.parts and "\\" not in name and ":" not in name
        local = (repo / name).read_bytes()
        committed = git_blob(repo, "HEAD", name)
        rows.append({"path": "R/" + name, "frozen_sha256": row["sha256"], "frozen_bytes": row["bytes"],
                     "local_raw_sha256": digest(local), "local_bytes": len(local),
                     "HEAD_blob_sha256": digest(committed), "HEAD_blob_bytes": len(committed),
                     "HEAD_matches_frozen": digest(committed) == row["sha256"] and len(committed) == row["bytes"],
                     "local_matches_HEAD_raw": local == committed,
                     "local_CRLF_pairs": local.count(b"\r\n"),
                     "local_newline_normalized_equals_HEAD": local.replace(b"\r\n", b"\n") == committed.replace(b"\r\n", b"\n")})
    config = []
    for name in ("lean-toolchain", "lake-manifest.json", "lakefile.lean"):
        local = (repo / name).read_bytes()
        committed = git_blob(repo, "HEAD", name)
        config.append({"path": "R/" + name, "local_sha256": digest(local), "local_bytes": len(local),
                       "HEAD_blob_sha256": digest(committed), "HEAD_blob_bytes": len(committed),
                       "raw_equal": local == committed,
                       "newline_normalized_equal": local.replace(b"\r\n", b"\n") == committed.replace(b"\r\n", b"\n")})
    migration = "1b072e87f59a6825597e4b6d49cd3b3ac4f1c9fb"
    proof_pairs = []
    for name in ("QuantumBlockEncoding/CubicAmplitudePrimitive.lean", "QuantumBlockEncoding/CubicStatePreparation.lean"):
        old, new = git_blob(repo, migration + "^", name), git_blob(repo, migration, name)
        current = git_blob(repo, "HEAD", name)
        proof_pairs.append({"path": "R/" + name, "old_sha256": digest(old), "old_bytes": len(old),
                            "migration_sha256": digest(new), "migration_bytes": len(new),
                            "HEAD_blob_sha256": digest(current), "HEAD_equals_migration": current == new})
    diff = subprocess.check_output(["git", "diff", migration + "^", migration, "--",
        "QuantumBlockEncoding/CubicAmplitudePrimitive.lean", "QuantumBlockEncoding/CubicStatePreparation.lean"], cwd=repo)
    print(json.dumps({"schema": "C118_EXACT_FROZEN_CONTEXT_HASH_AUDIT_V1",
        "candidate_archive": "R/tools/real_preparation_native_c34_ci5/public-runtime-package.zip",
        "candidate_archive_sha256": digest(raw), "candidate_vector_sha256": digest(vector_bytes),
        "archive_members": members, "frozen_vector_paths": 220,
        "row_encoding": "path, frozenSHA, frozenBytes, localSHA('=' means frozen), localBytes, HEAD_SHA('=' means frozen), HEAD_bytes, localCRLF, normalizedEqual",
        "encoded_rows": [[r["path"], r["frozen_sha256"], r["frozen_bytes"],
                          "=" if r["local_raw_sha256"] == r["frozen_sha256"] else r["local_raw_sha256"], r["local_bytes"],
                          "=" if r["HEAD_blob_sha256"] == r["frozen_sha256"] else r["HEAD_blob_sha256"], r["HEAD_blob_bytes"],
                          r["local_CRLF_pairs"], r["local_newline_normalized_equals_HEAD"]] for r in rows],
        "HEAD_drift": [r for r in rows if not r["HEAD_matches_frozen"]],
        "local_raw_vs_HEAD_difference_count": sum(not r["local_matches_HEAD_raw"] for r in rows),
        "newline_normalized_content_difference_count": sum(not r["local_newline_normalized_equals_HEAD"] for r in rows),
        "configs": config, "migration_commit": migration, "proof_pairs": proof_pairs,
        "exact_authorized_diff_sha256": digest(diff), "exact_authorized_diff": diff.decode(),
        "committed_blob_authority": "git show HEAD bytes; raw local bytes are independently reported, never silently normalized as the binding",
        "current_directory_membership_enumerated": False, "semantic_or_compiler_acceptance": False,
        "audited_archive_code_executed": False}, ensure_ascii=False, separators=(",", ":")))


if __name__ == "__main__":
    main()

