# SOURCE_ONLY: temporary AND, destructive X, conditional CZ

Stage: source-first pre-proof interpretation, version 1.
Reviewer identity: temporary_and_operation_statement_review_c120.
Source: P, SHA-256 `3607f457c3349db74e10b131abadef23a4a2dea0fefa0cf6ac6d0ed9f37fdfd9`, physical and printed page 9, Methods, equations (11)-(13) and same-page context.
This is an independently derived mathematical contract, not a Lean certificate, candidate-design review, source approval, hardware certificate, or SP/BE root-closure claim.

## 1. What the source actually says

Equation (11) uses a Toffoli to compute the product of two bits into a zero target, permits a use of that product, and uses another Toffoli to return the target to zero. Equation (12) replaces the second Toffoli with destructive X-basis measurement and a CZ on the retained two bits when the measurement result is 1. The text says that the result is uniformly random, the ancilla is released and can be restored to zero, and the argument extends by linearity to retained superpositions. Equation (13) records the general Boolean-function phase update and appends the measurement result to an earlier classical record.

The source's measurement arrow does not display a Kraus normalization coefficient. It is appropriate as a normalized conditional-state/sign transcript, not literally an unnormalized linear Kraus map. The normalized branch state in (12) and the branch probability in (13) must be separated in an exact matrix interface.

The same page distinguishes reversible gates, diagonal sign gates, and destructive X measurements. Equation (10) supplies a clean-ancilla output specification for the overall task; it does not turn a destructive measurement into a unitary on the original three-qubit carrier. Its prose about unitary evolution is not a proof of reset hardware or adaptive-control implementation.

The displayed use step in (11)-(12) does not specify a separate unitary. The interface needed immediately before measurement is that the target still contains the Boolean function of the current retained basis label. A use that changes that relation is outside the displayed derivation. A safe generalization permits all other retained workspace/reference data in the retained label; it does not silently assume that every possible intervening gate preserves the relation.

## 2. Frozen finite-linear convention

All scalars are complex. Let B = {0,1}, with integer product uv and XOR denoted xor. Retained space H_D = C^(B x B) has ordered basis 00,01,10,11. Target H_t = C^B has basis 0,1. Full space H = H_D tensor H_t has basis 000,001,010,011,100,101,110,111, with target last and fastest varying. Matrices act on column vectors; in AB, B acts first. Write s = 1/sqrt(2), positive real, so s^2 = 1/2.

Definitions are literal matrices, not choices up to global phase or characterized objects. The chosen X eigenbras are <x_r| = s(<0| + (-1)^r <1|), with r=0 for + and r=1 for -. This fixes the branch phase convention exactly. Rephasing an outcome bra would change its Kraus representative and must not be silently absorbed in an entrywise theorem.

Zero insertion J: H_D -> H is J|uv> = |uv0>. Thus J^*J = I_4 and JJ^* is projection onto the zero-target subspace, not I_8.

The actual full-carrier Toffoli T: H -> H is

    T|uvt> = |uv, t xor uv>.

It fixes basis indices 0 through 5 and swaps 6 with 7. Hence T is an 8-by-8 permutation matrix, T^*=T, and T^2=I_8. The computed embedding V = TJ is an 8-by-4 matrix with its four columns e_0,e_2,e_4,e_7. It satisfies V|uv> = |uv,uv> and V^*V=I_4. Replacing T by V would lose the full-carrier gate semantics.

The destructive X branch M_r: H -> H_D is

    M_r = I_4 tensor <x_r|,
    M_r|uvt> = s (-1)^(rt) |uv>.

The conditional phase correction C_r: H_D -> H_D is

    C_r|uv> = (-1)^(ruv)|uv>,
    C_0=I_4, C_1=CZ=diag(1,1,1,-1).

The corrected destructive branch K_r = C_r M_r has type H -> H_D. Zero-output restoration is a distinct composition Q_r = J K_r: H -> H. Neither K_r nor Q_r is a unitary inverse of Toffoli.

## 3. Explicit matrices and exact branch equations

In the basis orders above,

    M_0 = s [1  1  0  0  0  0  0  0
             0  0  1  1  0  0  0  0
             0  0  0  0  1  1  0  0
             0  0  0  0  0  0  1  1]

    M_1 = s [1 -1  0  0  0  0  0  0
             0  0  1 -1  0  0  0  0
             0  0  0  0  1 -1  0  0
             0  0  0  0  0  0  1 -1]

    K_0 = M_0

    K_1 = s [1 -1  0  0  0  0  0  0
             0  0  1 -1  0  0  0  0
             0  0  0  0  1 -1  0  0
             0  0  0  0  0  0 -1  1].

Directly on each |uv>,

    M_r V |uv> = s (-1)^(ruv)|uv> = s C_r|uv>,
    K_r V |uv> = s (-1)^(ruv)(-1)^(ruv)|uv> = s |uv>.

The sign cancels because ruv is an integer and (-1)^(2ruv)=1. Thus the precise equations for each r in B are

    M_r T J = s C_r,
    C_r M_r T J = s I_4,
    J C_r M_r T J = s J.

Both outcomes have the same positive scalar s and no residual relative or global phase with the chosen eigenbras. These are rectangular-matrix equalities, not identities after dropping a scalar. The unitary alternative obeys T T J=J and uses two occurrences of T; the measurement route uses one T but has the additional operations shown above.

There is also a useful whole-carrier identity, derived without restricting t:

    K_r T |uvt>
      = s (-1)^[r(t xor uv)] (-1)^(ruv) |uv>
      = s (-1)^(rt)|uv>
      = M_r|uvt>.

Consequently K_r T=M_r and Q_r T=J M_r on all of H. This does NOT assert Q_r T=s I_8. Its output forgets the old target; on clean target inputs it specializes to the desired sJ identity.

## 4. Complete-family equations

The X eigenvectors are orthonormal: <x_r|x_q>=delta_(r,q), and their rank-one projectors sum to I_2. Therefore

    M_0^* M_0 + M_1^* M_1 = I_8.

C_r is unitary for each r, so on the entire input carrier

    K_r^* K_r = M_r^* M_r,
    K_0^* K_0 + K_1^* K_1 = I_8.

Since J^*J=I_4, the restored branches also form a complete family:

    Q_0^* Q_0 + Q_1^* Q_1 = I_8.

In contrast, a single branch has K_r^*K_r=I_4 tensor |x_r><x_r|, not I_8/2. Uniform outcomes are not a whole-carrier property. For example, |00> tensor |+> gives r=0 with certainty before any compute. The uniformity follows from the computed clean-input subspace:

    B_r := K_r V = s I_4,
    B_r^* B_r = I_4/2,
    sum_r B_r^* B_r=I_4.

For restored clean-output branches A_r := Q_r V=sJ, likewise A_r^*A_r=I_4/2 and their sum is I_4. A family-completeness theorem and a branch-action theorem are separate obligations; neither should be a premise assumed instead of proved from the displayed operations.

## 5. Arbitrary complex amplitudes and reference correlations

For arbitrary complex coefficients a_uv, no normalization is needed for the linear identity:

    K_r V sum_(uv) a_uv |uv> = s sum_(uv) a_uv |uv>.

Let H_R be any finite-dimensional reference space. Every vector in H_D tensor H_R can be written Psi=sum_(uv) |uv> tensor eta_uv, for arbitrary reference vectors eta_uv that need not be orthogonal or normalized. Use the explicit register order D,t,R. Compute V on D and insert t before R; destructive branches act on D,t and identity on R. Then

    (K_r tensor I_R)(V tensor I_R) Psi = s Psi,
    (Q_r tensor I_R)(V tensor I_R) Psi = s (J tensor I_R) Psi.

This follows by expansion in the D basis, without supposing the reference is unentangled or that the amplitudes are real. For any joint density matrix rho_DR, linearity on matrix units consequently gives

    (B_r tensor I_R) rho_DR (B_r^* tensor I_R) = rho_DR/2,
    sum_r (B_r tensor I_R) rho_DR (B_r^* tensor I_R) = rho_DR.

With reset, replace rho_DR on the right by (J tensor I_R)rho_DR(J^* tensor I_R). Under ideal Born instrument semantics, each branch has probability trace(rho_DR)/2; for a normalized input it is 1/2. The retained conditional density matrix equals rho_DR after normalization. The corrected classical-record state is (|0><0|+|1><1|)/2 tensor rho_DR, in record,D,R order, so the newly produced result is independent of retained data and reference on this input subspace.

These density/Born conclusions are mathematical consequences under the standard ideal instrument interpretation. They are not a new formalization or hardware verification of Born's rule or adaptive execution. Earlier classical measurement records can be treated blockwise: if each earlier-record block satisfies the Boolean-function relation, the new result is conditionally uniform in each block. No coherent identification of a classical outcome register with a quantum control is being assumed.

## 6. Boolean-function and use-step boundary

For a finite retained label set Y and Boolean f:Y->B, define V_f|y>=|y,f(y)> and D_(r,f)|y>=(-1)^[r f(y)]|y>. The same componentwise derivation gives

    (I_Y tensor <x_r|) V_f = s D_(r,f),
    D_(r,f) (I_Y tensor <x_r|) V_f = s I_Y.

Completeness of the destructive branches holds on C^Y tensor C^B, not only the graph subspace. Uniformity, cancellation, and preservation of arbitrary reference correlations follow on the graph subspace. For temporary AND, f(u,v)=uv and D_(1,f)=CZ. For general f, the source's sign update alone does not supply an inexpensive physical implementation of D_(1,f).

An intervening use may entangle additional retained workspace with uv, provided the final state before erasure still has support in the graph t=uv of the current controls. It is insufficient merely to say that the target started clean or once contained AND. For example, computing uv and then flipping u without modifying t can break that graph relation, so correcting by CZ on the new controls need not cancel the measurement phase. This is a boundary observation, not a claim that the source proposes that invalid use.

## 7. Discard, measurement, and reset are not interchangeable

The destructive branch M_r has four output rows; it removes the target from its output carrier. It does not produce a live qubit in state zero. J explicitly inserts a fresh zero target, so Q_r=JK_r is a separate eight-output-row ideal map. J is an isometry and not its own inverse. The partial trace operation is a channel on density matrices, not a single amplitude map which simply deletes a wire.

In particular, discarding the computed target before measurement/correction gives

    Tr_t(V rho V^*)_(uv,u'v')
      = rho_(uv,u'v') if uv=u'v', and 0 otherwise.

It generally destroys coherence between f=0 and f=1 sectors. The input (|00>+|11>)/sqrt(2) becomes the corresponding incoherent mixture after tracing out its AND target. Forgetting the uncorrected X measurement result has the same dephasing effect: sum_r s^2 C_r rho C_r^*=(rho+CZ rho CZ)/2. Applying the result-dependent correction first gives rho exactly instead. Recording both outcomes but failing to apply the correction is not the corrected complete instrument.

A putative single amplitude map |uvt> -> |uv> for both t values is M_0/s. It is not a deterministic normalized physical discard map: its adjoint product is not I_8 and superpositions can change norm. Similarly, a normalized conditional-state map for arbitrary full-carrier states is generally nonlinear because its branch normalization depends on the input. The clean computed-input subspace is precisely what makes the normalized corrected branches act identically.

## 8. Evidence classes and open boundaries

SOURCE_EXPLICIT: the displayed compute/uncompute and measurement/correction narratives (11)-(12), result sign update and claimed uniformity (13), same-page gate classes, clean-ancilla contract (10), and the source's one-versus-two-Toffoli accounting.

REVIEWER_DERIVED: literal finite matrices, branch factor s, exact phase convention, full-carrier equations and completeness, clean-subspace restriction for uniformity, reference-extension identities, density-matrix consequences, and the discard/reset distinction above. These are analytic derivations from the pinned page, not existing implementation results and not a machine-checked proof.

SOURCE_GAP / OUTSIDE_STAGE: explicit local Lean definitions and compiled proofs; verified operation-to-primitive bridges; physical destructive-X measurement, outcome encoding, adaptive conditional-CZ execution and timing; ancilla release/reset hardware; full Born/channel semantics adapters; fault tolerance; connectivity/depth/classical-feedback costs; claimed Clifford/resource classifications as certified local theorems; finite-bit synthesis; any SP/BE consumer/root integration. The source's one-Toffoli count does not certify any of these omitted costs.

No definition or theorem from an existing temporary-AND author, decoder, reviewer, implementation, proposal, or result package was read in this stage. No candidate acceptance verdict is issued. Stage completion means only that this source-only interpretation has been frozen for subsequent comparison.
