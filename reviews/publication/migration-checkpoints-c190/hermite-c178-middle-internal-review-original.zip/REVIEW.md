# C178 independent cached-middle VALUE review

Classification: `INTERNAL_STATIC_REVIEW`. No mathematical mismatch or missing
premise was found in the exact C167 candidate's two public VALUE roots and
five private helpers. Both public types match C156 after whitespace removal;
the whole raw proof matches requested SHA256
`8d804b12efeb2ce55193d18df301288f8c2038ad2f45e9dc2d7984f1a55d2a25`.
This is not compilation/axiom acceptance, source-publication review, a cost400
or full-chain theorem, native/finite-bit resource evidence or scientific ROOT.

## Independence and scope

This reviewer has prior runtime exposure for distinct C147, C157 and setup
slices. No fresh universal decoder status is claimed. C169 and C173 are
preserved. For this task, actual C150 CachedMiddle, canonical Run/read/collect,
full C23 cache implementation, exact C156 types and C21 ActualCoefficients
were read before the entire candidate proof. Author audit/manifest/consumer,
C174 runtime records, C172 finite discriminator, C175 public metadata,
PR/reports and other reviews were not opened. `#print axioms` source commands
were read as text only; no middle runtime output was received or inferred.

Scope is literal stored-entry value equality for arbitrary rational e and
vector a, followed by substitution of the actual C23 generated cache and
literal expMidpoint(delta). No sign, positivity, normalization, caller table
correctness, desired-output or cost-bound premise is introduced.

## Independent construction derivation

Write W=k+1. Inputs a have W entries indexed 0<=i<=k, and the returned middle
has 2W entries indexed 0<=j<=2k+1. Canonical Run.bind passes its returned value,
read returns the actual vector entry, collect returns each executed entry's
value, and sumEntries recursively returns the sum of all its entry values.
These are projection identities, not assertions that the operations have no
cost. Actual powQ multiplies recursively, so its value at (-1,m) is (-1)^m.

The actual weightedSources computation therefore returns two separate vectors

    u_i = e*a_i*(-1)^W,
    v_i = a_i*(-1)^i.

The first computes sigma once as powQ(-1,W), reads a_i, multiplies by e then
sigma. The second independently reads a_i and computes its sign by powQ. These
equalities hold for all signed/zero e and a_i, with no absolute-value or
nonnegative replacement. The second vector's value is independent of e; that
does not prove the executed first-vector work can be omitted or is free.

The middle producer separately builds the actual factorial table at N=2k+1.
Its canonical factorials recurrence starts at 0!=1 and appends (r+1)*r!, with
next=r+1 at stage r. The actual factorials_value proof yields F_t=t! over the
entire generated range 0..N. For r<=n<=N, actual chooseFrom reads F_n,F_r,F_(n-r),
multiplies the latter two and divides. Thus its value is

    n!/(r!*(n-r)!) = (Nat.choose n r : Rat).

All factorials are nonzero by construction. The helper supplies this fact via
the actual factorials_value dependency, not a caller's correctness oracle.
The hr/hn proof binders type finite accesses and express the ordinary binomial
domain only; they are not hypotheses in either public root. Actual Mathlib
choose recursion and choose_eq_zero_of_lt were also inspected: choose(n,0)=1,
and choose(n,r)=0 whenever n<r.

## Primary guards versus secondary zero guards

The first actual term executes only when W<=j AND j-W<=i; the second only when
i<=j AND j-i<=W. Here subtraction is natural truncated subtraction.

| term | primary guard | secondary guard | failure semantics |
| --- | --- | --- | --- |
| first | W<=j | j-W<=i | primary false: absent shifted monomial; primary true/secondary false: choose(i,j-W)=0 |
| second | i<=j | j-i<=W | primary false: absent shifted monomial; primary true/secondary false: choose(W,j-i)=0 |

The primary guards cannot be dropped using binomial-zero reasoning. If j<W,
then j-W=0, and choose(i,0)=1 rather than zero. For example k=0,j=0,u_0=1 gives
actual first-term value 0 but an unguarded product 1. Similarly if j<i then
j-i=0 and choose(W,0)=1: k=1,i=1,j=0,v_1=1 gives actual second-term value 0
but an unguarded product 1. These are directly derived algebraic witnesses,
not imported finite-check results or executed tests.

By contrast, after the primary guard holds, a failed secondary guard means
the binomial lower index is strictly greater than the upper one. That natural
binomial and its rational cast are zero, so the omitted product is zero for
arbitrary signed u_i/v_i. The secondary guard is therefore compatible with
removing it from the value specification while remaining essential to safe
execution of the factorial-quotient primitive. No out-of-range chooseFrom is
called and no arbitrary table callback supplies its result.

On the executed first branch n=i<=k<=2k+1 and r=j-W<=i. On the executed second
branch n=W=k+1<=2k+1, valid even at k=0, and r=j-i<=W. Thus all three factorial
reads are valid in the generated table; no k>=1 condition is missing.

Consequently the actual term values are exactly

    first(i,j) = if W<=j then u_i*choose(i,j-W) else 0,
    second(i,j) = if i<=j then v_i*choose(W,j-i) else 0.

This is precisely the two private term helpers' three-case reasoning: primary
false, primary true/secondary true, primary true/secondary false. They do not
confuse a truncated subtraction case with an out-of-range binomial case.

## Generic middle and actual C23 cache substitution

Actual middleFromCache collects every j in Fin(2k+2), sums all W first terms
and all W second terms, then qAdds those sums. Substituting the two weighted
vectors gives

    sum_{i=0}^k [if W<=j then e*a_i*(-1)^W*choose(i,j-W) else 0]
    + sum_{i=0}^k [if i<=j then a_i*(-1)^i*choose(W,j-i) else 0],

with each choose cast to Rat. This is exactly literal middleExpr, proving the
first public statement over every admissible k,e,a,j. It is also the coefficient
formula of

    sum_i (e*a_i*(-1)^W)*X^W*(X+1)^i
    + sum_i (a_i*(-1)^i)*X^i*(X+1)^W.

This polynomial interpretation explains the guards but is not a new evaluation,
state-action or minimal-degree theorem claimed for this packet.

The C23 cache is an actual Run: it generates factorials(2k+1), computes every
sourceEntry, and materializes sources by collect. For source index i<=k, its
inner r runs over 0..i and computes

    choose(k+i-r,k)/r!.

Here k<=k+i-r<=2k and r<=i, so all typed factorial accesses are valid, including
k=0. The actual sourceEntry_value and produceSourceCache_entry proofs supply

    cache_i = sourceCoefficientQ(k,i)
            = sum_{r=0}^i choose(k+i-r,k)/r!.

These implementation/value dependencies were read completely. The source cache
does not call the desired middle expression to obtain its result. Substituting
these returned entries and e=expMidpoint(delta) into the first root, then
converting Fin(W) sums to range(W) sums, gives the literal C21 middleCoeffQ
definition with exactly the same two primary guards, signs, casts and ranges.
That is the second public root actual_cache_middle. It uses no cache-correctness
premise or free source oracle. Delta is any rational; this equality says nothing
about the separate approximation-error guarantees at invalid tolerances.

The middle pass makes its own factorials(2k+1), because the C23 cache returns
only the scalar vector, not its private factorial table. Value composition
does not establish zero or shared factorial setup work.

## Full-range and signed boundary checks

Symbolic boundary values of the generic returned array are

- j=0: a_0; only second i=0 contributes.
- j=2k+1: (-1)^k*a_k*(1-e); only i=k survives in both sums.
- k=0: the complete two-entry vector is [a_0,a_0*(1-e)].

At j=W the first primary guard begins at equality, with lower choose index 0
for every i. The second primary guard likewise includes equality i=j. The
secondary guards include r=n, yielding choose(n,n)=1, and reject r>n, not r=n.
All zero, negative and mixed-sign coefficients are covered by the same algebra.
For e=1 the top coefficient can cancel, so stored length 2k+2 is not asserted
to be minimal polynomial degree or a minimal-rank representation. No output
entry outside the returned Fin range is fabricated or claimed.

## Five helpers, binders and dependency boundary

All five private helpers were read and checked:
c167_weighted_first/second give the two actual stored weight values;
c167_generated_choose supplies generated-table correctness internally;
c167_first_term/second_term preserve primary guards while discharging only
secondary failures by binomial zero. The generic public proof composes these
with actual collect/sum/add value semantics. The cache-specific proof composes
that result with actual C23 entry values and exact finite-sum reindexing.
This is a mathematical/static reference topology, not an elaborated proof-term
graph or whole-source publication audit of C21/C23.

Public binders are k:Nat, e/delta:Rat, stored vector a and valid finite j.
Helper u/v and finite i are arbitrary signed stored data. No EXCESS logical
premise, normalization convention, nonnegative-coefficient promise or new
target definition appears. Literal middleExpr is a specification; production
executes reads, generated factorial quotients, multiplications and summations,
not that specification as a desired-output callback.

There is no cost400 statement in this candidate, no right-value or full chain
claim, and no native/bit/GCD/evaluation-sharing/rank/gate/scientific ROOT credit.
Projecting .value does not erase actual Run.cost, certify free construction of
inputs or captured blocks, or prove a producer's full runtime. The original
state/error contract is unchanged. Actual C21 polynomial evaluation/degree
proofs and C23 cost proofs were visible in full canonical files, but no broader
acceptance of those layers is conferred by this bounded new review.

Compact handoff: two VALUE roots/five helpers are the reviewed delta; no
mathematical obstruction found. Failure class NONE; no route discarded,
salvage promotion, comparator or Exposition Seal. Required role protocols remain
in the retained worker context; no process-memory record or other review used.
Exact input/read extents, type/hash checks and freeze bindings accompany this
report. Only new C178 files were written via apply_patch; actual other actions
were read-only retrieval/hash/regex comparisons and parent messages. No finite
diagnostic, compiler/lake/provided script/Python/Git/network/subagent execution,
source edits, forbidden packet access or tooling failure occurred. Actual
compilation/axioms and inherited binary association remain unassessed for this
candidate. Stop at this static freeze before any middle runtime release;
separate authorization is required for a later association stage.
