# C184 separate middle runtime association

Classification: `INTERNAL_RUNTIME_ASSOCIATION_REVIEW`.

The inspected records consistently associate the unchanged C167/C178-reviewed
source with C174's own proof output, its consumer's exact two VALUE types and
the actual 2+2 ordinary-axiom reports. No concrete association mismatch was
found. This is recorded local evidence under inherited dependencies, not an
independent rerun, printed-definition audit, clean TCB, Source Anchor, Proof
Seal, main/publication admission, whole-chain or scientific ROOT closure.

C178 was frozen at `e8478c293e4a2123ca5399aa42a83e83afb85c2b23271d869b6ba2a1e3b7d8ae`
and read/verified by the parent before this separate authorization. Its seal,
both payloads and all eight input hashes remain unchanged. This reviewer has
prior distinct-slice runtime exposure and now C174 exposure; no fresh universal
decoder claim or retroactive change to C178's chronology is made.

The original C167 source, staged proof and source-ZIP member all have hash
`8d804b12efeb2ce55193d18df301288f8c2038ad2f45e9dc2d7984f1a55d2a25`.
The original/staged/ZIP consumer hash is
`292eeb6d21b4aef8f12367e01d86782445efe4fb57cc7aef41a96762c06ed993`.
Actual staged proof output matches recorded hash
`9e413aa7571ba03963be8d7cb5f375f53c1fc3b9853b3c6ed33a5aa4d00b8ee6`;
the checker output matches
`9e91d84a6bb37cd654bb8f071fe18bb2a7c65663010bca8375b8437576aa9855`.

The whole inspected runner creates a fresh exclusive stage, pins/copies exact
sources, invokes the pinned direct executable with own output paths and stage
root, memory limit 3072, one thread and timeout 180 seconds, and archives raw
feedback/dependency/path records. Its actual hash equals the record's wrapper
hash. Its documented template substitutions and field rename independently
reconstruct the exact runner text, without changing the ordinary-axiom
allowlist. The universe-aware parser's current hash is unchanged from the
previously inspected parser; no script/parser was executed by this reviewer.

Raw proof `--deps` selects the exact C159 primitive output pinned at
`77547431cc9e4759adcd8c25f6a3e57622da492bdb31ac36f2061ab06e50d473`.
Raw checker `--deps` selects C174's own CachedMiddleValueProof.olean, not a
same-named older proof. Current provider bytes match. Both raw stdout streams
exactly equal their public feedback bytes. Direct stderr is empty. Recorded
compile exits are zero without timeout (24.688 and 25.062 seconds); these are
recorded process results, not this reviewer's execution measurements.

The author-authored checker has two explicit sealed-type ascriptions, not just
name lookups. Its full actual printed types retain arbitrary rational e/a,
all k and Fin(2k+2) indices for middleFromCache_entry; actual_cache_middle uses
the literal expMidpoint(delta), actual produceSourceCache value and canonical
middleCoeffQ for arbitrary rational delta. Both ascriptions independently
match the sealed types after whitespace removal. No positivity, caller cache
correctness, cost oracle, range restriction or weakened conclusion appears.

Each raw run prints exactly the two expected unique fully qualified public
names. Each list is exactly `[propext, Classical.choice, Quot.sound]`, without
sorryAx, ofReduceBool, trustCompiler or another added axiom. These literal
rows, source identities, output hashes and direct selections were checked
instead of accepting only `PROOF_AND_AXIOM_PASS` booleans. The checker is not
an independent source-publication decoder, and no helper or loaded definition
body printout is supplied by this sequence.

The recorded requested path was independently reconstructed: own stage,
primitive stage, C155 typed stage, five inherited caches, project output, then
package path. It matches the private transcript. The actual preliminary Lake
stderr retains the dirty-verso warning, even though direct compiler stderr is
empty. The current executable matches the recorded binary hash. None of this
rebuilds every inherited source/binary, pins every transitive package, traces
all effective runtime module loading, or supplies immutable filesystem/process
attestation. C155/C156 provider provenance remains inherited at the limited
level already reviewed in earlier packets; no new printed-body audit is claimed.

C178's signed-value/primary-versus-secondary-guard derivation is preserved,
not duplicated or reclassified here. Parametric VALUE identities do not prove
cost400, minimal storage/rank, actual right value, same-chain composition,
producer/native/bit/GCD/evaluation-sharing/gate/synthesis/cleanup/export costs
or scientific ROOT. C172 finite evidence was not opened or used as proof or
an endpoint. C177/C180 same-chain packets and public metadata/PRs/other reviews
were not opened. Parent branch-head notices were not independently checked and
are not evidence for these checks. Main/publication/root gaps remain.

Compact handoff: objective/delta is narrow exact local runtime association;
failure class NONE for discovered mismatch. No route discarded, comparator,
salvage promotion or Exposition Seal. Required protocols remain in the retained
worker context; no process-memory record consulted. Only new C184 files were
written via apply_patch. Other actions were read-only retrieval, in-memory ZIP
hashing, exact text/type/path/hash comparisons and parent messages. No compiler,
lake, provided-script/Python/Git/network/subagent execution, archive copying,
source/prior-packet edit or tooling failure occurred. Raw host paths remain
private; exact logical bindings and read extents accompany this report. Stop
after this separate association freeze; stronger admission requires its own
remaining gates.
