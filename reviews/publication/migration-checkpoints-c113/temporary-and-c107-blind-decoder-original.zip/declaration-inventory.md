# Exhaustive declaration and context inventory

This inventory covers all of INPUT/target.lean and all formal_text in the five INPUT/providers.json regions. T1-T11 are in namespace ASPBE.Uncompute.MBU. B abbreviates Fin 2 only in prose; the actual signatures use Fin 2. Braces indicate an implicit leading parameter, brackets a typeclass parameter, and parentheses an explicit leading parameter only when before the declaration's result colon. No source-relative assumption classes are assigned.

## Target ambient commands

- Line 1: import QuantumBlockEncoding.PrimitiveMacros. This is a module import, not a proof-premise binder or proof of every imported declaration's use.
- Line 3: namespace ASPBE.Uncompute.MBU. Naming context only; no section variables, variable commands, local notation, open command, or universe declaration appears in the target.
- Line 62: end ASPBE.Uncompute.MBU.
- Lines 64-65: #check the fully qualified correctedTemporaryAndBranch_eq and correctedTemporaryAndBranch_mass names.
- Lines 66-68: #print axioms for correctedTemporaryAndBranch_eq, correctedTemporaryAndBranch_mass, and sum_branchMass, in that order. These source commands create no mathematical declaration or assumption. Their output was not supplied or generated.

## T1: branchScale (line 5)

- Header: noncomputable def branchScale : complex. No leading binders, no ambient parameters.
- Body: ((Real.sqrt 2 / 2 : real) : complex). Both parenthesized annotations belong to the value expression, not the declaration's leading binder list.
- Body binders: none. Dependency: Real.sqrt and numeric coercion/arithmetic.

## T2: andBit (line 7)

- Header binders: (a b : Fin 2). Result: Fin 2.
- Body: if a = 1 AND b = 1 then 1 else 0. No body binder or premise requiring the conjunction; it is the tested condition.

## T3: conditionalCZSign (lines 9-10)

- Header binders: (m a b : Fin 2). Result: complex.
- Body: if m = 1 AND a = 1 AND b = 1 then -1 else 1. The condition is part of the definition, not a caller-supplied proof parameter. No body binders.

## T4: correctedTemporaryAndBranch (lines 12-15)

- Header binders in order: {R : Type*}; (alpha : R -> Fin 2 -> Fin 2 -> complex); (m : Fin 2); (r : R); (a b t : Fin 2). Result: complex. Noncomputable definition.
- Body: if t = 0 then conditionalCZSign m a b * QuantumBlockEncoding.hadamardMatrix m (andBit a b) * alpha r a b else 0.
- No proof-valued leading binder, no Fintype requirement, no normalization, no circuit object. No body lambda/sum binder. Dependencies: T2, T3, provider hadamardMatrix.

## T5: correctedTemporaryAndBranch_eq (lines 17-23)

- Header binders exactly as T4, including explicit t and m; result is equality between T4 and branchScale * (if t = 0 then alpha r a b else 0).
- No hypothesis about alpha. Parentheses in the right-hand expression group the piecewise value; they are conclusion syntax, not leading binders.
- Body: fin_cases m, a, b, t; simplify using T4, T3, T2, hadamardMatrix_apply, T1.
- Body introduces finite case contexts for four bit parameters, not additional public assumptions. No local have binder. alpha and r remain arbitrary.

## T6: branchScale_normSq (lines 25-28)

- Header: no leading binders; result Complex.normSq branchScale = (1 / 2 : real).
- Body: rewrite T1 and Complex.normSq_ofReal; have h : sqrt(2)*sqrt(2)=2 from Real.mul_self_sqrt with a norm_num proof of nonnegativity; finish nlinarith.
- h is a local proved fact. The numeral type annotations and the result parentheses are not leading binders.

## T7: inputMass (lines 30-32)

- Header binders: {R : Type*}; [Fintype R]; (alpha : R -> Fin 2 -> Fin 2 -> complex). Result: real. Noncomputable definition.
- Body: sum r, sum a, sum b, Complex.normSq (alpha r a b).
- Body-bound sum indices: r : R, a : Fin 2, b : Fin 2. They are not extra header parameters. No normalization premise.

## T8: branchMass (lines 34-36)

- Header binders: {R : Type*}; [Fintype R]; (alpha : R -> Fin 2 -> Fin 2 -> complex); (m : Fin 2). Result: real. Noncomputable definition.
- Body: sum r, sum a, sum b, sum t, Complex.normSq (T4 alpha m r a b t).
- Body-bound sum indices: r : R; a,b,t : Fin 2. m remains the explicit public argument. Dependencies: T4 and squared norm/finite sums.

## T9: correctedTemporaryAndBranch_mass (lines 38-49)

- Header binders: {R : Type*}; [Fintype R]; (alpha : R -> Fin 2 -> Fin 2 -> complex); (m : Fin 2).
- Result: branchMass alpha m = inputMass alpha / 2. No normalization, state-action, measurement, or mass theorem is assumed as a leading premise.
- Body local declaration: have per (r : R) (a b : Fin 2) : (sum t : Fin 2, Complex.normSq (T4 alpha m r a b t)) = (1 / 2 : real) * Complex.normSq (alpha r a b).
- per's r,a,b are local function binders; t is its local sum index. The (1/2 : real) annotation and sum parentheses are in the local result, not leading public binders.
- per proof simplifies with T5, Fin.sum_univ_two, Complex.normSq_mul, T6. Then unfold T8/T7; simp_rw [per]; simp_rw [reverse Finset.mul_sum]; ring. alpha,m and the finite instance are captured by per.

## T10: outcomeMass_of_normalized (lines 51-54)

- Header binders in order: {R : Type*}; [Fintype R]; (alpha : R -> Fin 2 -> Fin 2 -> complex); (h : inputMass alpha = 1); (m : Fin 2).
- h is the one explicit mathematical proof premise beyond the finite indexing structure. Result: branchMass alpha m = (1 / 2 : real).
- Body: rewrite T9 and h. The conclusion parentheses are not binders. No body-local parameter or helper.

## T11: sum_branchMass (lines 56-60)

- Header binders: {R : Type*}; [Fintype R]; (alpha : R -> Fin 2 -> Fin 2 -> complex).
- Result: (sum m : Fin 2, branchMass alpha m) = inputMass alpha. m is bound inside the conclusion sum, not in the leading signature; neither that sum's outer parentheses nor its type annotation constitutes a public binder.
- Body: simp only [Fin.sum_univ_two, T9]; ring. No normalization premise or local have.

Target totals: six definitions, five theorems, one import, one namespace start/end pair, two #check commands, and three #print axioms commands. No target structure, class, inductive, axiom, opaque, instance, abbreviation, notation, section-variable command, or additional declaration is present. This is a textual inventory, not an elaboration or imported-axiom audit.

## Provider regions and all their declarations

Region identifiers below are logical provenance labels inside INPUT/providers.json, not files opened separately. The [start,end) notation below is a conventional display of the supplied start_character/end_character pairs; their indexing convention and raw-file boundaries were not independently audited.

### P1: PrimitiveMacros region [0,1367)

Supplied naming context: namespace QuantumBlockEncoding; open QuantumBlockEncoding.Robin.ComplexLCU. Text includes imports QuantumBlockEncoding.ReversibleClassical and Mathlib.Tactic, followed by whitespace where comments were masked. There are exactly three declarations in this bounded region:

1. noncomputable def hadamardMatrix : Matrix (Fin 2) (Fin 2) complex. No leading binders. Body: Complex.I scalar-multiplies standardRyMatrix (Real.pi / 2) * standardRzMatrix Real.pi. Matrix index parentheses are type arguments, not value binders. Dependencies P2/P3.
2. noncomputable def phaseMatrix (theta : Real) : Matrix (Fin 2) (Fin 2) complex. One explicit real angle binder. Body: Complex.exp (((theta/2 : Real) : complex) * Complex.I) scalar-multiplies standardRzMatrix theta. No body binder. Not referenced by target proofs.
3. theorem hadamardMatrix_apply (row column : Fin 2) : hadamardMatrix row column = let scale : complex := (Real.sqrt 2 / 2 : Real); match row.val,column.val with (0,0),(0,1),(1,0) => scale | _,_ => -scale. row,column are the only leading binders. scale is a let-bound value inside the conclusion, not an assumed argument. Pattern wildcards bind no named mathematical input. Body-local half proves (pi/2)/2 = pi/4 by ring. Body then fin_cases row,column; simp expands hadamardMatrix, P2/P3/P5/P4, Matrix.mul_apply, Fin.sum_univ_two, half, cos_pi_div_four, sin_pi_div_four, cos_pi_div_two, sin_pi_div_two; rewrite associativity/commutativity and Complex.I_mul_I; ring. Matrix multiplication's expansion introduces its finite summation index internally, not as a public premise.

### P2: PrimitiveSemantics region [493,612)

Supplied namespace QuantumBlockEncoding with the ComplexLCU open context. One declaration: noncomputable def standardRyMatrix (theta : Real) : Matrix (Fin 2) (Fin 2) complex := realRotation (theta/2). theta is the only leading binder. No lambda, premise, or local proof. Dependency P5.

### P3: PrimitiveSemantics region [9540,9859)

Same supplied namespace/open context. One declaration: noncomputable def standardRzMatrix (theta : Real) : Matrix (Fin 2) (Fin 2) complex := fun row column => if row = column then (if row = 0 then cos(theta/2) - sin(theta/2)*i else cos(theta/2) + sin(theta/2)*i) else 0, with real trig values coerced to complex.

theta is the only leading binder. row,column are body-lambda binders inferred as Fin 2 from the matrix result type. The equality tests are conditions, not hypotheses. No proof is supplied or required for this literal definition body.

### P4: ComplexLCU region [788,1040)

Supplied namespace QuantumBlockEncoding.Robin.ComplexLCU. One declaration: noncomputable def realOrthogonalRotation (cosine sine : Real) : Matrix (Fin 2) (Fin 2) complex := fun row column => match row.val,column.val with 0,0 => cosine | 0,_ => -sine | _,0 => sine | _,_ => cosine, with complex coercions.

cosine,sine are the two explicit leading binders. There is no leading cosine^2+sine^2=1 assumption, so the name does not itself certify orthogonality for arbitrary arguments. row,column are body-lambda binders; wildcard cases introduce no named parameter. No unitarity theorem is supplied in this region.

### P5: ComplexLCU region [2290,2437)

Same supplied namespace. One declaration: noncomputable def realRotation (angle : Real) : Matrix (Fin 2) (Fin 2) complex := realOrthogonalRotation (Real.cos angle) (Real.sin angle). angle is the only leading binder; no body binder. Dependency P4.

Provider totals: six definitions and one theorem. All seven complete supplied declaration bodies were read. Only P1 includes actual import/open/namespace text; P2-P5 use the contextual metadata for namespaces/open context and do not provide surrounding whole-module scope. These excerpts do not assert an exhaustive imported declaration inventory.
