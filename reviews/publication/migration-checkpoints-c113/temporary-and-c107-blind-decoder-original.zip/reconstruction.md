# Frozen formal-only reconstruction

## Status and scope

This is an independent, source-blind reading of INPUT/target.lean in its entirety and all five formal regions in INPUT/providers.json, with INPUT/context.json. It is a mathematical reconstruction, not an accepted publication record, compiler certificate, axiom report, source-fidelity judgment, scientific verdict, or full external trusted-computing-base audit. The only mathematics inspected was in those three inputs. Relevant process guidance was read under GOVERNANCE; no neighboring mathematical files were opened.

All three actual input byte hashes match the supplied pins; details, provider-region checks, and governance pins are in OUTPUT/evidence.json. OUTPUT/declaration-inventory.md inventories every target declaration, its leading binders, result, body, local binders, ambient context, and terminal commands, and every supplied provider declaration. No conclusion parentheses are treated as leading binders.

## Actual mathematical objects

Write B = Fin 2 = {0,1}, and let c = (sqrt(2)/2 : real), viewed in the complex numbers when multiplying amplitudes. The target namespace is ASPBE.Uncompute.MBU. It defines:

1. branchScale = c, with no arguments.
2. andBit(a,b) = 1 exactly when a = b = 1, and 0 otherwise, for a,b in B.
3. conditionalCZSign(m,a,b) = -1 exactly when m = a = b = 1, and +1 otherwise, for m,a,b in B.
4. correctedTemporaryAndBranch(alpha,m,r,a,b,t), an amplitude-valued function, for any type R and any alpha : R -> B -> B -> complex. Its value is zero unless t = 0; at t = 0 it is

       conditionalCZSign(m,a,b) * H[m,andBit(a,b)] * alpha(r,a,b).

   Here H is the supplied hadamardMatrix, and the multiplication order is the one displayed. This is a literal piecewise formula; zeroing the t != 0 sector is built into the definition, not derived from an independently defined reset operation.
5. inputMass(alpha) = sum over r,a,b of |alpha(r,a,b)|^2, for finite R.
6. branchMass(alpha,m) = sum over r,a,b,t of |correctedTemporaryAndBranch(alpha,m,r,a,b,t)|^2, again for finite R.

The scalar definitions are exact real/complex mathematics. The noncomputable modifiers do not supply a numerical algorithm or resource bound. No choice of a representative, quotient, or characterized object occurs in these target bodies. This observation about the literal code does not classify fidelity to a withheld natural source.

R is arbitrary in the pointwise branch definition and identity. It need not be finite or inhabited. The mass definitions and theorems add a Fintype instance for R, so their sums are finite. R can be empty; normalization would then be impossible, but the other mass identities remain meaningful. There is no normalized-state premise except in outcomeMass_of_normalized. There are no target-level section variables, standing hypotheses, imported project-specific contract bundles in the signatures, or implicit circuit/oracle/resource assumptions. Type* permits a universe-polymorphic R. Fin 2 and the complex/real number systems use the standard imported Lean/Mathlib infrastructure, whose implementations are not provided here.

## What the bounded providers say

The matrix convention is row index first and column index second. Thus H[m,andBit(a,b)] uses m as the row and the AND bit as the column. The five regions supply seven declarations:

- realOrthogonalRotation(x,y) is the complex matrix [[x,-y],[y,x]], with real entries coerced to complex.
- realRotation(theta) substitutes x = cos(theta), y = sin(theta).
- standardRyMatrix(theta) = realRotation(theta/2).
- standardRzMatrix(theta) is diagonal, with entries cos(theta/2) - i sin(theta/2) at 0 and cos(theta/2) + i sin(theta/2) at 1; off-diagonal entries are zero.
- hadamardMatrix = i times the matrix product standardRyMatrix(pi/2) * standardRzMatrix(pi). The scalar i multiplies the whole matrix.
- phaseMatrix(theta) = exp(i theta/2) times standardRzMatrix(theta). It is present in the supplied region, but is not referenced by any target body or the supplied Hadamard-entry proof. Its displayed definition corresponds to diagonal entries 1 and exp(i theta); no such simplification theorem is supplied or needed for this target.
- hadamardMatrix_apply gives H = c [[1,1],[1,-1]], exactly, including its chosen phase, not merely up to global phase.

The Hadamard-entry proof introduces (pi/2)/2 = pi/4 by ring arithmetic; exhausts the two row and two column cases; expands the matrix product and the rotation definitions; uses exact sine and cosine values at pi/4 and pi/2; rearranges scalar products; uses i*i = -1; and finishes by ring arithmetic. The supplied primitive region imports ReversibleClassical and Mathlib.Tactic and opens QuantumBlockEncoding.Robin.ComplexLCU. The other regions are accompanied by namespace/open context, not their complete module headers. Nothing here independently audits the transitive import path that makes these names available.

## The five target theorems, in full mathematical content

### 1. correctedTemporaryAndBranch_eq

For every type R, every alpha : R -> B -> B -> complex, every m in B, r in R, and a,b,t in B,

    correctedTemporaryAndBranch(alpha,m,r,a,b,t)
      = c * (alpha(r,a,b) if t = 0, else 0).

This is the strongest stated amplitude result: the same positive real scalar c works for both branch labels m and every a,b,r, with exact complex equality. In particular it preserves all relative amplitude phases across the r,a,b labels after removing the common branch scale.

Proof: H[m,x] is c except for m = x = 1, where it is -c. At x = andBit(a,b), that exceptional sign occurs exactly when m = a = b = 1, precisely where conditionalCZSign is -1. The two minus signs cancel; otherwise both signs are positive. At t = 1 both sides are zero. The actual proof exhausts m,a,b,t (sixteen bit assignments) and simplifies using the four target formulas plus the provider entry theorem. It does not exhaust r or alpha, so the result remains fully parametric in them.

### 2. branchScale_normSq

    |c|^2 = 1/2.

There are no leading binders or premises. The proof reduces the squared complex norm of a real coercion to the real square, establishes sqrt(2)*sqrt(2) = 2 from the square-root lemma and 0 <= 2, and closes by nonlinear real arithmetic. The local h is a proved fact inside the body, not a public premise. The parentheses around (1/2 : real) in the result are a type ascription, not a binder.

### 3. correctedTemporaryAndBranch_mass

For finite R, every alpha and every m in B,

    branchMass(alpha,m) = inputMass(alpha)/2.

No normalization premise is used. At fixed r,a,b, the sum over t has one nonzero term, at t = 0. The pointwise identity, multiplicativity of squared complex norm, and |c|^2 = 1/2 give that inner sum as (1/2)|alpha(r,a,b)|^2. The proof names this local fact per, unfolds both mass definitions, rewrites each inner sum, pulls the same real factor outside all three remaining finite sums using Finset.mul_sum, and uses ring arithmetic to identify multiplication by 1/2 with division by 2. The local parameters of per and its inner sum index are body binders, not extra public hypotheses.

### 4. outcomeMass_of_normalized

For finite R, every alpha with the explicit premise inputMass(alpha) = 1, and each m in B,

    branchMass(alpha,m) = 1/2.

The proof rewrites the general branch-mass identity and then the normalization premise. Normalization is an input here and nowhere proved for arbitrary alpha. Both branch labels therefore have equal mass 1/2 when normalized. Calling these outcome probabilities requires the usual squared-amplitude measurement interpretation; the target itself defines and proves real mass equalities, not a probability-space or measurement-instrument theorem.

### 5. sum_branchMass

For finite R and every alpha,

    sum over m in B of branchMass(alpha,m) = inputMass(alpha).

The proof replaces the two-element sum by its two terms, substitutes inputMass/2 for both terms, and closes by ring arithmetic. The m inside the conclusion is a bound sum index, not a leading theorem parameter. The result holds without normalization and describes total mass across two separately indexed branches; it does not assert a coherent unitary operation on a branch register.

## Dependency reconstruction

These are references observed in complete supplied bodies and a mathematical proof explanation, not a compiler-exported proof-term dependency graph.

    realOrthogonalRotation -> realRotation -> standardRyMatrix
    {standardRyMatrix, standardRzMatrix} -> hadamardMatrix
    {hadamardMatrix, rotation definitions, trig identities, matrix sums,
     complex i^2 identity, ring arithmetic} -> hadamardMatrix_apply
    {correctedTemporaryAndBranch, conditionalCZSign, andBit,
     hadamardMatrix_apply, branchScale, finite bit cases}
       -> correctedTemporaryAndBranch_eq
    {branchScale, normSq_ofReal, mul_self_sqrt, real arithmetic}
       -> branchScale_normSq
    {correctedTemporaryAndBranch_eq, branchScale_normSq, normSq_mul,
     two-element sum expansion, finite-sum factorization, mass definitions}
       -> correctedTemporaryAndBranch_mass
    {correctedTemporaryAndBranch_mass, normalization premise}
       -> outcomeMass_of_normalized
    {correctedTemporaryAndBranch_mass, two-element sum expansion, arithmetic}
       -> sum_branchMass

Each braced tail is conjunctive evidence for that step, not several independently sufficient arrows. phaseMatrix is not on the target proof spine. The direct target import is PrimitiveMacros; no claim is made that every imported declaration is used.

## Interpretation and uncovered boundaries

One possible operational reading is: alpha describes the residual/data amplitudes; a temporary bit initially carries a AND b; a Hadamard matrix entry produces outcome m; an outcome-conditioned controlled-Z sign cancels the outcome-dependent phase; and the output temporary bit is fixed to zero. The pointwise formula supports this reading algebraically, including arbitrary correlations represented by alpha. However, the code does not define an initial vector with t = a AND b and derive the branch from a composed operation on it. It directly defines the corrected branch by the desired matrix entry and t = 0 support.

Accordingly, this packet does not by itself establish a physical measurement/reset implementation, a concrete temporary-AND producer or uncompute circuit, a gate decomposition/count, T-count, depth, clean/dirty workspace guarantees for a real circuit, classical feed-forward realization, a finite-bit approximation bound, a density-matrix/channel law, or a resource advantage. It also contains no theorem about arbitrary dirty initial temporary-bit states. No source-relative verdict can be drawn because the natural source and desired statement were withheld.

The five provider regions cover all supplied project-defined scalar/matrix ingredients used by the visible branch proof, including the Hadamard-entry proof. They do not cover whole imported modules, ReversibleClassical, full PrimitiveSemantics or ComplexLCU, Mathlib theorem/tactic implementations, Lean's kernel/toolchain, dependency manifests, imported axioms, or possible additional ambient syntax outside the excerpts. The context's toolchain string is supplied metadata, not an execution result. Raw-provider/module digests and offsets are supplied metadata; only the three actual input files and the five supplied formal_text strings were byte-hashed here. No raw external provider file was opened to independently verify its raw-region or whole-module hash. No lexical mask correctness proof is claimed.

The final #check and #print axioms commands were read as source text only. They ask Lean to report types/axioms; their presence is not evidence that they ran, what they returned, or that the module compiles. No compiler, Lean, native evaluation, numerical simulation, Git operation, network request, or child agent was used in this decoding task.

## Blindness chronology and freeze

1. Received only the fresh bounded assignment, exact input names/pins, allowed governance locations, and output scope; did not inspect parent history or another worker's findings.
2. Read the six allowed governance documents. Combined tool output was truncated in places, so affected governance content was re-read with overlapping coverage through end of file. No referenced mathematical/source files were followed.
3. Read all of INPUT/context.json and INPUT/target.lean, then all of INPUT/providers.json. Confirmed all three input hashes; independently recomputed each supplied formal_text hash. Re-read the full target with line numbers for inventory.
4. Reconstructed the formulas, every theorem/proof, binder distinctions, provider scope, and limitations without source title, desired source conclusion, statement seal, author classifications, experiment/compile/axiom results, prior verdict, or source-relative comparison.
5. Wrote the three payload files; the manifest binds their bytes; the content seal binds that manifest. This packet is frozen at that point. Any later source/result disclosure requires a separate successor artifact and must not silently rewrite this frozen reconstruction.

The recorded chronology is ordinal; no fabricated wall-clock timestamps, run telemetry, or compilation records are supplied.

## Exact public-safe allowlist

The input allowlist is exactly INPUT/target.lean, INPUT/providers.json, INPUT/context.json. The new output allowlist is exactly OUTPUT/reconstruction.md, OUTPUT/declaration-inventory.md, OUTPUT/evidence.json, OUTPUT/manifest.json, OUTPUT/content-seal.json. GOVERNANCE paths are logical evidence references to the six named guidance files only; no permission to copy unrelated governance/source material is implied. No host paths, credentials, or neighboring-file names are included in this packet.

## Structured handoff

- Objective/frontier: independent whole-target formal decoding, not proof production or source admission.
- Mathematical delta: exact amplitude cancellation, its finite-mass corollaries, and a complete distinction between public assumptions, body facts, output indices, and absent operational semantics.
- Named evidence: the eleven target declarations and seven bounded provider declarations inventoried in OUTPUT/declaration-inventory.md; actual byte bindings in OUTPUT/evidence.json.
- Effect on root frontier: gives a frozen reconstruction for a future distinct source comparison; does not advance a compiler or source-closure gate.
- Failure class: NONE for the bounded reading. Unprovided source/compiler/TCB coverage is a scope limitation, not a refutation or implementation failure.
- Salvage: algebraic proof spine and binder inventory preserved as reading evidence only; no compiled fragment promoted.
- Process-memory IDs consulted: none; outside allowed scope.
- Direction fingerprint: independent formal-only full-body-and-provider decoding; expected information gain is unanchored reconstruction of actual semantics and hidden-premise boundaries.
- Parallel admission: assignment explicitly states authorization for a small independent uncertainty. No child agents spawned. Cross-route/common-blind-spot review is not performed here.
- Default verified route/comparator: not selected; no verified alternatives compared.
- Purification/Exposition Seal: not asserted. This is not a publication wrapper or acceptance record.
- Files changed: only the five new OUTPUT files on the exact allowlist.
- Residual risk: static reading without elaboration; uninspected external implementations and no source comparison. High confidence in the displayed algebraic reconstruction, no claimed compilation confidence.
- Recommended next step: preserve the frozen bytes, then let a distinct authorized reviewer compare against a separately pinned source and actual execution evidence, if supplied later.
