# Temporary AND: independent source-only derivation

State: SOURCE_ONLY. This is an independently derived mathematical reading, not an implementation review, source-topology approval, Proof Seal, or admission decision.

Primary anchor: [arXiv:2610.22367v1, physical page 9, Methods, Eqs. (11)-(13)](https://arxiv.org/pdf/2610.22367v1#page=9). Source SHA-256: `3607f457c3349db74e10b131abadef23a4a2dea0fefa0cf6ac6d0ed9f37fdfd9`. Complete page 9 was extracted and visually inspected. Reference 29 on physical page 12 was read only for attribution; its paper was not read.

## 1. Precise local input and order

Let Y have computational basis |y>, let A be the temporary qubit, and let E be any untouched reference/work system. Fixed input order is Y,A,E; discarded output order is Y,E; reset output order is Y,A,E. A classical Boolean function f:Y->{0,1} gives the graph encoding

    E_f (|y> tensor |e>) = |y> tensor |f(y)> tensor |e>.

The local state at cleanup is

    |Psi_f> = sum_y |y>|f(y)>|eta_y>,
    |psi>   = sum_y |y>|eta_y>,
    M       = sum_y <eta_y|eta_y> = ||psi||^2 = ||Psi_f||^2.

The vectors eta_y are arbitrary complex vectors, not assumed normalized, mutually orthogonal, real, positive, or separable from the retained bits. This includes arbitrary retained complex amplitudes and reference correlations. The graph encoding is the substantive local invariant; the qubit A is not arbitrary garbage.

For the source temporary AND, y=(u,v), f(y)=uv with bits interpreted as 0 or 1. A Toffoli acting on A initially in |0> supplies E_AND. The unspecified use interval may change E and hence eta_uv, but the cleanup input must still have A=uv for the currently retained controls. If the use changes u/v without maintaining that relation, the displayed cleanup cannot simply be applied. No arbitrary-use theorem is implicit here.

## 2. Destructive X measurement, both branches

Use |chi_r>=(|0>+(-1)^r|1>)/sqrt(2), with r=0 for + and r=1 for -. Destructive measurement has branch map B_r=I_Y tensor <chi_r|_A tensor I_E. This removes A. Define D_f|y>=(-1)^{f(y)}|y> on Y. Direct expansion gives

    <chi_r|f(y)> = (-1)^{r f(y)}/sqrt(2),
    B_r |Psi_f> = (D_f^r tensor I_E)|psi>/sqrt(2).

Thus r=0 produces psi/sqrt(2); r=1 produces D_f psi/sqrt(2). The factor 1/sqrt(2) belongs to the unnormalized Kraus branch and cannot be omitted from a mass-preserving linear statement.

Because different retained basis labels y are orthogonal, even when eta_y are not,

    ||B_r Psi_f||^2 = (1/2) sum_y ||eta_y||^2 = M/2.

For M=1, each outcome has probability 1/2. For M>0 the normalized conditional retained state is D_f^r psi/sqrt(M), while the normalized input is Psi_f/sqrt(M). For M=0 both branches are zero and normalized conditional states are undefined. These facts do not depend on phase patterns or correlations in E.

## 3. Correction and reset are actual operations

Apply outcome-dependent C_r=D_f^r to Y. Since (D_f)^2=I,

    (C_r tensor I_E) B_r E_f = I_(Y,E)/sqrt(2).

This is a composition identity on the graph-encoded input, not a definition of B_r or of a complete cleanup circuit. A reset output needs an additional insertion J_0(|y>|e>)=|y>|0>|e>. The full branch is

    L_r = J_0 (C_r tensor I_E) B_r,
    L_r E_f psi = J_0 psi/sqrt(2).

The discarded and reset statements have different codomains. A destructive measurement alone releases/removes the wire; the source's output |0> in Eq. (12) uses its stated ability to restore it. A nondestructive X measurement instead leaves |chi_r> on A, and needs a further outcome-dependent operation taking that known state to |0>; it is not literally the displayed destructive/reset map. No hardware reset synthesis or timing is supplied by writing J_0.

For AND, D_AND=CZ on the ordered retained controls (u,v). The exact two branches are:

| r | Raw discarded branch | Feedforward | Corrected reset branch |
| --- | --- | --- | --- |
| 0 | psi/sqrt(2) | I | J_0 psi/sqrt(2) |
| 1 | CZ psi/sqrt(2) | CZ | J_0 psi/sqrt(2) |

The two r cases are exhaustive cases required by deterministic cleanup, not alternative constructions from which one may choose a favorable outcome. Exact cancellation is pointwise, including the uv=1 component; it preserves relative phases, not merely basis probabilities or states modulo an uncontrolled input-dependent sign.

## 4. Mixed states, classical outcomes, and no postselection

For any retained-reference density operator rho (or subnormalized positive operator of trace M), input E_f rho E_f^dagger gives corrected reset branch

    L_r E_f rho E_f^dagger L_r^dagger = J_0 rho J_0^dagger / 2.

Summing both branches yields J_0 rho J_0^dagger exactly, with total mass M. Keeping a classical outcome register R gives

    sum_r |r><r|_R tensor (J_0 rho J_0^dagger/2).

For normalized rho, R is a fair bit independent of the restored quantum system, including its reference. This is not postselection: no branch is rejected and no success amplification is needed. If earlier classical history is m, apply this reasoning to each conditional branch on which the graph invariant holds. Then Pr(m,r)=Pr(m)/2; m is appended with r as in Eq. (13). This is a statement about classical recorded histories, not a claim that an arbitrary coherent history register is measured without disturbance.

The source's unitary-target convention in Eq. (10) does not make measurement/reset a unitary operation on the complete physical system. The corrected effective data channel on this invariant subspace is the desired identity; a classical outcome/environment remains. Globally, the instrument is not an invertible map on arbitrary Y,A inputs.

## 5. Why phase-only and reset-only are insufficient

Without feedforward, ignoring r leaves

    rho -> (rho + D_f rho D_f)/2.

This removes coherence between the f=0 and f=1 sectors. Tracing out A directly has the same retained effect on graph-encoded inputs. Simply resetting A after tracing it out cannot recover lost coherence.

For an exact illustrative calculation, take trivial E and psi=(|00>+i|11>)/sqrt(2). The AND graph state is (|00>|0>+i|11>|1>)/sqrt(2). The minus outcome changes i to -i; CZ is needed to recover the original relative phase. Ignoring the outcome instead gives an equal incoherent mixture of |00> and |11>. This algebra is an explanation, not simulation, compiler evidence, or an independent proof gate.

The graph invariant is necessary for the asserted general uniformity: with retained data |00> but A=|+>, the X outcome is deterministically +. That state is outside the AND graph subspace. The page does not promise fair outcomes for arbitrary ancillas.

## 6. What Eq. (13) does and does not give

For a basis label with existing sign (-1)^phi, multiplying by (-1)^{r f(y)} updates phi to phi XOR (r AND f(y)), exactly the source simulator transition. It also appends the classical r and removes the measured ancilla. The 1/2 outcome mass is separate from this normalized signed-branch bookkeeping.

The arbitrary-complex/reference-correlated extension above is a derived quantum semantics for this local Boolean-graph relation. Eq. (13) itself is not a specification of arbitrary complex simulator amplitudes, a generic cleanup synthesis algorithm, or a gate decomposition for D_f. It does not say a general f has a free/Clifford phase correction. For AND, Eq. (12) explicitly identifies CZ; for arbitrary f, an actual correction realization and its cost remain suppliers. The identity D_f^2=I alone is not that realization.

The relation also does not supply the earlier reversible computation of f, a maintained invariant through arbitrary use, a composition theorem for multiple measurements, an adaptive-circuit semantics, arbitrary-width resource scaling, finite-bit compilation, or whole-program correctness.

## 7. Direct-uncompute OR route and resource boundary

On the same graph subspace, the second Toffoli maps |u,v>|uv> to |u,v>|0> coherently. This is the Eq. (11) direct-uncompute route. Eq. (12) offers the measurement/feedforward route instead. They are OR alternatives for the local cleanup goal, not simultaneous prerequisites.

Source-local count: including the initial computation, the direct route has two Toffolis; the MBU route has one Toffoli plus destructive X measurement, conditional CZ, and the zero-restoration convention. The page classifies CZ as Clifford. This is a logical Toffoli-count comparison, not a full latency, connectivity, physical reset, total gate, peak-space, or finite-bit resource certificate, and it does not make a generic Boolean f cheap.

## 8. Frozen conclusion and boundary

The source supports exact AND cleanup for both outcomes on a maintained AND-graph input. The independently derived branch meaning is corrected identity times 1/sqrt(2), with mass 1/2 for normalized inputs and exact retained/reference restoration after summing outcomes. Discard and reset require explicit type/convention adapters. Eq. (13) supports local Boolean-graph phase bookkeeping, not generic circuit closure. Actual operation denotations, gate placement, maintained-use invariants, reset, feedforward composition and broader resource claims must be supplied and independently checked before any implementation-level conclusion.
