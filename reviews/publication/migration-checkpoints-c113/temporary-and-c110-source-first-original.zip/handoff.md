# C110 source-only handoff

Objective/frontier: independent mathematical/source reconstruction for the temporary-AND cleanup at [arXiv:2610.22367v1, page 9, Eqs. (11)-(13)](https://arxiv.org/pdf/2610.22367v1#page=9), before formal exposure.

Mathematical delta: an explicit instrument-level meaning for arbitrary complex retained/reference states. On an f-graph input, destructive X branch r gives D_f^r psi/sqrt(2). For AND, conditional CZ cancels that phase for both outcomes. Corrected reset branch is J_0 psi/sqrt(2), has half the input mass, and the sum of branches restores the retained/reference density operator exactly with A=0. Eq. (13) is Boolean-graph phase/history bookkeeping; it is not generic correction synthesis.

Effect on root frontier: source semantics and bounded topology are frozen independently. No implementation or program root is accepted; actual supplier status is uninspected. Direct Toffoli and measurement/CZ are distinct OR routes. Both measurement outcomes are AND requirements of the MBU route. Discard/reset and conditional/Kraus conventions are explicit, not silently identified.

Named evidence: source-derivation.md; source-coverage.md; source-topology.json; assumption-supplier-audit.md; supplied PDF SHA-256 `3607f457c3349db74e10b131abadef23a4a2dea0fefa0cf6ac6d0ed9f37fdfd9`; private full-page render digest in manifest. No Lean root/test or simulator witness exists in this phase. Packet checks are mechanical only.

Remaining suppliers: actual ordered Toffoli action; maintained predicate through concrete use; destructive X Kraus/Born semantics; CZ on the same retained controls; classical outcome-selected feedforward; reset/reallocation or explicit discard endpoint; actual program composition and reference extension; mass adapter between conditional and unnormalized semantics; declared logical resource accounting. Generic f additionally requires a real D_f implementation and resource/coherent-access contract before corrected generic cleanup is claimed.

Assumptions/conventions: finite computational retained labels, one Boolean-valued graph ancilla, untouched arbitrary reference, r=0 for + and r=1 for -, reset order Y,A,E, exact vector phase, branch mass M/2, classical history. No generic ancilla garbage, arbitrary-use mutation, or general free phase oracle is assumed.

Files changed: only new files in this isolated packet; see manifest. No production Lean, website, registry, Git state, or remote artifact was changed.

Reusable insight: exact branch identity yields complete reference-preserving channel identity once actual operation composition is supplied; a phase-cancellation definition alone does not establish that bridge. The local graph invariant can be a legitimate conditional-library input but must be produced by a whole compute/use/cleanup theorem.

Failure class: NONE for the source-local mechanism under its stated invariant. Broader operation/implementation evidence is OPEN/NOT_INSPECTED, not a source-refutation, API-failure or implementation-failure finding.

Salvage: derivation and supplier interfaces are candidates for later independent review; no fragment is promoted to a canonical compiled node here. No process-memory IDs were consulted. Direction/expected information gain are in input-chronology.md. No child agents were spawned. Parent-level parallel work was authorized for independent objectives; no other worker result was ingested. Any common-blind-spot comparison remains a later distinct review.

Default route/comparator: none selected as an implementation winner. Both source alternatives remain visible; no global cost comparison beyond the source-local Toffoli count is asserted.

Purification/Exposition Seal: not reached and not self-approved. Independent mathematics/topology review, formal decoder/comparison, exact operation suppliers, focused/repository gates and reader-facing integration remain outside this frozen phase. Source and implementation dependency graphs have not been conflated.

Confidence and residual risk: high confidence in the displayed local algebra; source topology is an extractor proposal awaiting a distinct reviewer. Whole-program correctness, resource scaling, adaptive scheduling, finite-bit compilation and actual implementation fidelity are deliberately unassessed.

Recommended next step: retain the SOURCE_ONLY seal unchanged; if authorized, release a separately pinned formal/decoder packet and compare its exact carriers, operations, branches, mass and composition with this independent result. That comparison must report actual evidence, not infer a verdict from this handoff.
