# Exhaustive bounded source coverage

State: SOURCE_ONLY; extractor proposal, independent topology review pending. Scope is the complete [physical page 9](https://arxiv.org/pdf/2610.22367v1#page=9), not the whole paper. Physical page 12 reference 29 was used solely as attribution provenance. No source text beyond those bounds was mathematically ingested.

Every substantive page-9 region is disposed below. Equations are split where distinct operations or conventions matter. A NODE designation records a source claim or derived interpretation; it does not say a formal supplier is discharged.

| ID | Region in reading order | Disposition | Node or reason |
| --- | --- | --- | --- |
| P9-01 | Methods heading | EXCLUDED | Navigation only. |
| P9-02 | Opening reversible embedding formula | NODE | CTX_EMBED: contextual motivation; not a proof of the temporary-AND circuit. |
| P9-03 | Kickmix introduction and citation 8 | NODE | CTX_MODEL, external model attribution; cited work not read. |
| P9-04 | Efficient simulation/coherent-action testing assertion | EXCLUDED | Global simulation/testing claim outside this one-local-primitive review; no certification inferred. |
| P9-05 | Toffoli/peak-qubit cost proxies, citations 24-26 | EXCLUDED | Global motivation only; bibliography and external resource results not ingested. |
| P9-06 | Space/recomputation trade-off and TQ product | EXCLUDED | Global optimization objective, not a local cleanup proof. |
| P9-07 | LLM evolutionary search and citations 20,27,28 | EXCLUDED | Search methodology outside local semantics. |
| P9-08 | Circuit-model heading | EXCLUDED | Navigation only. |
| P9-09 | Permutation, Boolean target phase, clean ancilla prose | NODE | CTX_TARGET. |
| P9-10 | Eq. (10), full clean-ancilla state relation | NODE | CTX_TARGET; contextual target, not measurement-is-unitary evidence. |
| P9-11 | Return-to-zero/unitarity justification sentence | NODE | CTX_ZERO; interpreted as interface requirement, not literal unitarity of destructive measurement. |
| P9-12 | Approximation interface and exact phase/cleanup clause | NODE | CTX_EXACT: local review remains exact; no approximation theorem supplied. |
| P9-13 | Failure budget/distribution allowance | EXCLUDED | No failures are used in the exact local cleanup; no global failure-budget claim made. |
| P9-14 | Operation-model introduction and citation 8 | NODE | CTX_MODEL; attribution only. |
| P9-15 | List item 1: X,CNOT,Toffoli,swap | NODE | MODEL_REV; local Toffoli is the relevant operation. |
| P9-16 | List item 2: Z,CZ,CCZ,global sign | NODE | MODEL_PHASE; CZ sign denotation is a required supplier. |
| P9-17 | List item 3: destructive X measurement | NODE | MODEL_X; relevant primitive and discard convention. |
| P9-18 | Basis/sign evolution before measurement and simulator representation | NODE | BASIS_SIGN; basis bookkeeping only, not a quantum correctness certificate. |
| P9-19 | Kickback/mixing naming clause | EXCLUDED | Terminology, no additional proof obligation. |
| P9-20 | Temporary AND setup and clean target | NODE | AND_ENCODING. |
| P9-21 | Eq. (11), initial Toffoli | NODE | AND_ENCODING; must be an actual operation, not assigned desired action. |
| P9-22 | Eq. (11), use interval | NODE | USE_INVARIANT; source displays unchanged control/predicate relation; arbitrary uses not specified. |
| P9-23 | Eq. (11), second Toffoli and final zero | NODE | DIRECT_ROUTE. |
| P9-24 | Two-Toffoli accounting sentence | NODE | COUNT_DIRECT. |
| P9-25 | MBU replacement and Gidney citation 29 | NODE | MBU_PROVENANCE; attribution only. |
| P9-26 | Uniform r, released ancilla, possible restoration | NODE | X_BRANCH, RESET_CONVENTION, MASS. |
| P9-27 | Eq. (12), initial Toffoli and use | NODE | AND_ENCODING, USE_INVARIANT; same local setup as Eq. (11). |
| P9-28 | Eq. (12), X-measure-r and phase (-1)^(ruv) | NODE | X_BRANCH, AND_RAW; unnormalized quantum branch requires 1/sqrt(2). |
| P9-29 | Eq. (12), displayed zero after measurement | NODE | RESET_CONVENTION; distinguish destructive discard from re-prepared wire. |
| P9-30 | Eq. (12), CZ iff r=1 and final retained state | NODE | AND_CORRECTED, MBU_ROUTE; both outcomes required. |
| P9-31 | Clifford CZ and one-Toffoli sentence | NODE | COUNT_MBU; local logical count only. |
| P9-32 | Linearity extension sentence | NODE | COHERENT_EXTENSION; derived with arbitrary eta_y, including reference correlations. |
| P9-33 | General Boolean f(y), retained data, earlier outcomes m | NODE | BOOLEAN_GRAPH, HISTORY; maintained deterministic function relation is part of scope. |
| P9-34 | Eq. (13), removal, history append, XOR phase | NODE | BOOLEAN_RELATION; no correction circuit given. |
| P9-35 | Eq. (13), both probabilities 1/2 | NODE | MASS; normalized/unnormalized distinction explicit in derivation. |
| P12-29 | Bibliographic entry 29 | NODE | MBU_PROVENANCE only: C. Gidney, Quantum 2,74 (2018), arXiv:1709.06648. No mathematical result imported. |

## Source omissions made explicit

The source uses named Toffoli, destructive X measurement and CZ, but does not on this page give their operator/Kraus denotations, register insertion/destruction machinery, or a formal composition system. Those are GAP_TOFFOLI, GAP_X, GAP_CZ, GAP_RESET and GAP_COMPOSE in the topology. These are semantic-realization obligations relative to stricter circuit certification, not assertions that an unseen implementation lacks them.

The use arrow is schematic. A concrete consumer must supply GAP_USE: after the use interval the temporary target is still the indicated function of the retained controls. For general f, the local relation has no supplied D_f gate realization or resource bound: GAP_GENERIC_CORRECTION. This is not needed to state Eq. (13), but is needed to promote it to a generic corrected-cleanup circuit.

## Coverage completion boundary

All page-9 prose paragraphs, displayed formulas, operation-list entries and citation clusters have a disposition. The only page-12 intake is reference 29. Excluded regions are not silently promoted into local prerequisites or accepted global theorems. There is no claim of coverage of other pages, cited works, implementation topology, or whole-paper root closure.
