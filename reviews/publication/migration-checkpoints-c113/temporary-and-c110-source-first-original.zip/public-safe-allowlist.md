# Public-safe boundary

State: SOURCE_ONLY, not approved for publication. This allowlist concerns privacy/content hygiene only; it is not mathematical admission.

Potentially shareable after independent review: source-derivation.md, source-coverage.md, assumption-supplier-audit.md, source-topology.json, input-chronology.md, public-safe-allowlist.md, handoff.md, structural-checks.json, manifest.json, SOURCE_ONLY.seal.json. These files use packet-relative filenames, stable arXiv anchors, input hashes and abstract role identities. They contain no host absolute path.

Private and excluded from publication: the entire `_private/` subtree, especially the source-page PNG. Do not inline or distribute the source render. The manifest may record its digest using a relative name for private reproducibility, but the image bytes are not a public output. No unchanged source PDF is distributed.

Primary mathematical citation: [arXiv:2610.22367v1, physical page 9, Methods, Eqs. (11)-(13)](https://arxiv.org/pdf/2610.22367v1#page=9). Provenance only: [physical page 12, reference 29](https://arxiv.org/pdf/2610.22367v1#page=12), identifying [Gidney, arXiv:1709.06648](https://arxiv.org/abs/1709.06648); that external work was not mathematically ingested.

No public claim may upgrade this packet to PROOF_SEALED, SOURCE_TOPOLOGY_REVIEWED, compiled circuit correctness, generic-f correction synthesis, full-resource closure, novelty, production integration, PURIFIED or final admission. The appropriate public status, if retained, is source-only proposal with operation suppliers and independent review pending.
