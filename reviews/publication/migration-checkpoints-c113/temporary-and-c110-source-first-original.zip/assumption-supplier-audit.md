# Assumptions, definition audit, and remaining suppliers

State: SOURCE_ONLY. No implementation declaration, catalog, theorem type or proof was read. Therefore this document identifies what an implementation would have to supply; it does not pronounce any actual unseen definition circular or any actual theorem deficient.

Source: [arXiv:2610.22367v1, page 9, Eqs. (11)-(13)](https://arxiv.org/pdf/2610.22367v1#page=9).

## Public contract versus internal dependencies

| Input or condition | Source-level classification | Correct treatment |
| --- | --- | --- |
| Bits u,v and Boolean f(y) | SOURCE/TYPING | Finite retained computational labels and ordinary Boolean function. |
| Complex scalar/reference space | TYPING, generalization | Mathematical extension of the stated superposition claim, not extra computational access. |
| Target qubit initially zero for compute | SOURCE | Eq. (11)/(12) input promise. |
| Cleanup input A=f(y) | SOURCE | Eq. (13) premise and local invariant; a whole compute/use/cleanup theorem must produce it. |
| Arbitrary eta_y and mass M | TYPING, generalization | Encodes arbitrary retained/reference state; M=1 is needed only when calling M/2 a probability. |
| Outcome convention r=0:+, r=1:- | STANDING, source-implicit | Forced by displayed (-1)^(rf(y)); make explicit. |
| Toffoli/CZ/X measurement correctness | Dependency edge | Must follow from actual primitive semantics, not be convenient public theorem assumptions. |
| Maintained predicate through a concrete use | Dependency edge for full composition | The source schematic does not permit arbitrary unspecified mutation of controls. |
| Outcome-conditioned phase correction identity | Dependency edge | Prove from actual CZ/phase operation and placement. |
| Released-wire reset to zero | Dependency edge/convention | Specify discard endpoint or real preparation/reset; do not silently identify codomains. |
| Instrument mass and coherent/reference extension | Dependency edge | Derive from branch operators; do not assume fair probabilities for arbitrary garbage. |
| Classical history | SOURCE | Eq. (13) records past outcomes; apply conditional-state semantics. |
| A generic efficient D_f operation | EXCESS if smuggled into generic source claim | Not supplied by Eq. (13); needs a separately proved construction and explicit resource model. |

No human-approved correction was supplied; RULED is empty. No source theorem should acquire new hypotheses saying the constructed circuit already has the desired state action, normalized branch action, or feedforward correctness. A conditional library lemma may legitimately accept a graph-state input, but cannot alone certify the earlier compute/use sequence.

## Definition-kind audit without implementation exposure

Literal mathematical objects used in the independent derivation are E_f, the X bras, D_f and J_0, each with its displayed action on its full stated carrier. They are not a characterization by the desired cleanup conclusion and involve no choice or quotient representative. The measurement phase uses an explicit representative convention; we preserve exact vectors, with density-state/global-phase interpretations stated separately.

If a later definition makes `cleanup` *equal by definition* to the corrected target branch, expanding that definition establishes only a target relation, not that destructive X measurement followed by real conditional CZ implements it. If it defines the branch multiplier as (-1)^(r f(y)), proving that the same multiplier squares to one proves phase cancellation within the model, but still needs an X-basis measurement denotation and circuit composition bridge. If it defines zero insertion J_0, it still needs an implementation of reset/reallocation when the interface retains that wire. These are prospective audit tests, not findings about unread code.

## Exact supplier interfaces still requiring implementation evidence

| Supplier | Required semantic content | Why not eliminated by the local identity |
| --- | --- | --- |
| OP-TOFFOLI | Actual ordered controls/target gate acts ket(u,v,a) -> ket(u,v,a XOR uv) and extends by identity on E. | Computes the graph invariant and supplies the direct OR route. |
| OP-USE | Concrete use preserves A=uv relative to the retained current controls; effects on E may be arbitrary. | The source has only a schematic use arrow. |
| OP-X | Actual destructive X instrument has branches <chi_r|, outcome labels, Born masses and correct retained-wire order. | Assigning a phase update is not deriving it from measurement. |
| OP-CZ | Actual CZ acts (-1)^(uv) on the same retained control wires and trivially on E. | A diagonal target formula is not gate placement/composition evidence. |
| OP-FEEDFORWARD | Recorded r selects I or CZ after measurement; composes with OP-X on each branch. | An isolated cancellation equation does not certify an adaptive circuit. |
| OP-RESET | Removed wire is omitted at endpoint, OR an explicit fresh-zero/reset operation gives order Y,A,E. | Discard and retained-zero output are different typed contracts. |
| OP-COMPOSE | The concrete compute/use/measure/correct/reset program refines the composed denotations and all branches. | A correct branch helper does not imply program/root closure. |
| MASS-ADAPTER | Kraus branch = target/sqrt(2), normalized conditional branch = target, sum of branch masses = input mass. | A normalized simulator branch can hide the 1/2 mass. |
| RESOURCE-LOCAL | Count actual Toffolis for the two exact routes; state whether measurement, CZ, reset and classical control are charged. | One symbolic sign identity is not a resource theorem. |
| GENERIC-D_f | If general corrected cleanup is claimed, construct D_f with compatible coherent access/cost. | Eq. (13) gives no such generic operation. |

These are *remaining evidence suppliers*, not claims of source falsity or claims they are absent in the repository. No implementation-level proof was attempted, so no API_BLOCKED or IMPLEMENTATION_FAILED finding exists. The source-local AND mechanism is coherent under its explicit invariant. Missing broader suppliers remain scoped open obligations rather than a rejected source theorem.

## Failure boundaries that a later decoder/reviewer must preserve

Do not identify conditional and unnormalized branches; do not certify both outcomes by proving only r=1 or only r=0; do not discard the uncorrected outcome; do not treat classical sign tracking as arbitrary-amplitude simulation; do not infer generic f correction from AND's CZ; do not generalize from graph-encoded ancillas to arbitrary garbage; do not infer gate-level composition or all-program resource closure from local phase algebra. Never turn the source's explanatory zero requirement into a claim that destructive measurement/reset is itself unitary.
