# C104 phase2: independent source-topology comparison

Status: QUALIFIED_SOURCE_TOPOLOGY_COMPARISON_ONLY. No source acceptance, production association, formal correspondence, implementation approval, physical certificate, or admission is made.

## Frozen baseline and newly released inputs

My independent source-only packet remains unchanged at `W/hermite-export-work/robin-c104-source-first-review/`.
Its source-only seal SHA256 is `d6ebed055db7f9cbe45df89d10b99e98b58feaf6a9f8084c03d91033e2568607`; manifest SHA256 is `434381ea678f3fd17801ae4889803cbcce20a940a0657453dcee6c84de8e3c7f`.
The mathematical natural source is unchanged, SHA256 `cb03ed58d466811608efad4424a11cd954c71ae6d28cf33175cb0d81b1b891c0`.

Only these three additional files were released, all under `W/hermite-export-work/robin-matrix-c76-whole-source-author-continuation/`:

- `whole-source-graph.json`: `abbee19398cc4523b8bfaa57cb4b8350c9dc6da0c7f4cc6b16d87d8d4745cf91`
- `whole-source-coverage.json`: `02db5d83ba73600af553810344042b95d289ce85cbebe4b5ca9d7a86bea77f52`
- `whole-source-only-isolation.md`: `abaf52a28a61288d5aa670d9e98fd914f9cd174582630688ab9f41dc046205be`

The boundary file was read; its broader references do not authorize other files. The graph was read completely. The coverage is an 869174-byte metadata inventory: the initial raw display truncated, so I subsequently parsed all688 records and inspected the complete field schema, every distinct disposition/provenance/semantic-role class, all grouping/binding classes, and exhaustive region-level structural data. I do NOT claim to have read 688 implementation bodies, exact formal statements, or every repeated metadata string individually as a mathematical proof.

## Comparison verdict

The author graph broadly agrees with the independent natural mechanism topology. It has32 nodes,16 AND edges and no OR edges. The core distinctions survive:

- Active seven-gate semantics, ten-label transcript, and one-label diagonal compression remain different objects.
- Raw syntax equality is not evaluated equality.
- Both active-domain restrictions and n>=3 remain visible.
- All six nonselected evaluated-zero feeders remain required before fold collapse.
- The exact raw fold target is REFUTED, not an unresolved plausible operator supplier.
- Uniform(H), coefficient identification and all four inverse/square laws remain a complete AND-tail in WA13.
- Full-space preparation/lift, physical semantics and all-entry/family/cost results remain unsupplied.
- Equivalent caches are not OR constructions, and the different compressed object is not a winner for the old active target.

No false completed same-contract OR construction or achieved physical closure was found in the released author topology. This is a qualified comparison, not a certificate that all source-asserted support facts or every declaration binding is correct.

## Material qualifications

### T01 — Preserve the source-wording finding F01

W7 line103's unqualified claim that positivity does not follow is too broad. From a^2=q and q*z=1 over Q, a!=0, q>0 and z>0 follow. Positivity of N_D, N_f, the target, or a itself does not follow. The graph's WF-LAWS retains the equations but does not resolve this prose issue. No source byte or graph contract has been silently repaired.

The source successor, if separately authorized, should qualify that sentence narrowly. Neither the conditional scalar theorem nor the exact raw refutation needs to be discarded.

### T02 — WA4 needs an explicit object distinction, not an automatic added premise

My baseline N18 follows the actual selected cosine-bearing entry through its coefficient-identification premise. Author WF-SCALAR/WA4 instead names a stored branch product and gives only stencil, normalizer, laws and coefficient algebra as suppliers.

Two readings must be distinguished:

1. A literal stored normalized factor f*NF_inv*(Dslot2*ND_inv) with amplitude-square factors: the four laws suffice for its normalization. No cosine-identification premise is needed.
2. The actual selected matrix entry f*NF_inv*cos_symbol with amplitude-square factors: coefficient identification WF-HENTRY and the selected-entry evaluator are needed before normalization.

The source and graph do not give an explicit object formula in the WF-SCALAR contract that completely disambiguates these readings. This is a local natural-interface underdescription, not proof of a false theorem or permission to insert a new final hypothesis. WA13 DOES explicitly include WF-HENTRY and WF-SELECTED, so its full prepared-entry conclusion does not silently omit them. Later formal release may resolve which stored object WA4 actually denotes; until then this exact distinction remains qualified.

### T03 — Coverage is complete metadata navigation, not independent semantic disposition

The released coverage internally enumerates688 unique regions:677 declaration records and11 ambient records;114 private and563 lexical public declarations;69 structure records. Region line intervals and character intervals are contiguous as metadata. This does not validate them against the unread module. The claimed1950 lexical fields are a header count, not1950 individually present field dispositions in this released coverage.

All456 theorem records share the broad semantic label “actual local proof, conditional transport, data transcript or refutation; exact obligation below.” Their bindings use seven broad multi-node bundles. A binding that includes WF-REFUTED does not mean that every theorem in the bundle is a refutation, and a binding including WF-SELECTED does not prove a selected-entry theorem.

My region crosswalk therefore marks each of the688 records METADATA_NAVIGATION_ONLY, preserving exact IDs, supplied region hashes and mappings. It does not authenticate author reading, bodies, per-declaration propositions, or compiler results. A whole-module semantic disposition needs later authorized evidence; its absence here is an evidence boundary, not mathematical impossibility.

### T04 — Natural-source coverage and module navigation are different units

My frozen baseline has47 dispositions partitioning113 natural-source lines. Author coverage has688 module regions; it is not a direct natural-paragraph coverage inventory. The new natural-coverage crosswalk maps every baseline disposition to the author mechanism nodes or explicitly retains administrative/provenance/reviewer-only material outside the author mechanism graph.

The graph has no dedicated W0-provenance or W8-provenance node. Those are retained in the source/coverage metadata and in this comparison as context, not silently promoted to mathematical evidence. No additional mathematical theorem omission was established by the difference in inventory units.

### T05 — Future AND-edge is not an achieved implication

WA15 explicitly calls itself proposed future obligations. Its suppliers include several unsupplied gaps, an all-entry/family obligation, a conditional single-entry theorem and a contract audit. It may be retained as a planning hyperedge ONLY with those open roles and with no claim that the existing prepared scalar theorem yields the final operator.

WF-ALLENTRIES additionally mentions an intended arbitrary-n family. The natural source directly proves neither that family nor its full contract. Here it is classified as prospective unsupplied scope, not a recovered arbitrary-n source theorem or an authorized change to the scientific target.

### T06 — Pins identify two different subjects

The author graph and coverage's field named source_sha256 contains `1cca5119ac056fe041b25c529909b9fb6c3e4995e04ebde2f69e83fce47a0835`, the unread raw implementation subject reported by W0, not the natural-source digest. This is consistent with a module navigation inventory, but should not be mistaken for a binding of the natural prose. This comparison's manifest explicitly pins both the actual natural input and the released graph/coverage bytes. It does not authenticate the implementation bytes.

## Independent deductions preserved, not imposed as author claims

The phase1 findings remain unchanged:

- Under all five scalar laws, Fold(e) iff the selected target evaluates zero.
- A law-satisfying rational environment exists at interpreted kappa=1, with target1, active entry0 and compressed prepared entry1.
- Additionally requiring interpreted kappa=7 makes the rational inverse/square laws inconsistent, by 7a^2=1. This is a proved rational-carrier obstruction, not a global physical impossibility.
- Those independent deductions were frozen BEFORE author-graph release. Their absence as explicit author nodes is not itself an author topology error.

The original source’s e* countermodel remains valid for its unconditional raw target even though e* violates inverse laws.

## Exact crosswalk and checks

`node-crosswalk.json` covers all32 author nodes and all45 frozen baseline nodes in both directions, including reviewer additions and provenance context.
`edge-crosswalk.json` assesses all16 author AND edges with their literal tails, semantic roles, local conditions and strength boundaries.
`natural-coverage-crosswalk.json` covers all47 baseline source dispositions.
`author-region-crosswalk.json` accounts for all688 released metadata regions without inventing formal statements.

Structural checks are consistency checks only. Acyclicity, inventories, hashes and path-hygiene scans do not establish mathematical completeness, truth, reviewer independence in the world or correspondence with unread Lean.

## Residuals and stop condition

No implementation, formal signature, formal audit, metadata/handoff/rationale outside the allowlist, author seal, other decoder/review, compiler/CI artifact, Git/network command or child agent was read/run. No production or source bytes were changed.

Residuals: T01 source wording; T02 stored-factor versus actual-entry disambiguation; full gate/support derivations; exact cache/predicate/formal interfaces; transitive provider digestion; physical lift and off-diagonal/unused-sector control; preparation/adjoint/inverse/cleanup and analytic interpretation; all-entry block/extraction/coherent-control; resource and TCB gates; attribution and publication binding. These remain at their exact evidence layers.

The packet freezes SOURCE_TOPOLOGY_COMPARISON_ONLY and stops. A source successor or further formal/decoder release requires separate authorization.

