# Source-wording disposition — no edits authorized or performed

Original mathematical source remains exactly SHA256 `cb03ed58d466811608efad4424a11cd954c71ae6d28cf33175cb0d81b1b891c0`.
Neither the phase1 source packet nor any author input is changed by this comparison.

## F01 / T01 — required narrow qualification

Anchor: W7 line103.

Original relevant sentence: “The five scalar equations are independent local hypotheses; e(kappa)=7, positivity and analytic trig relations do not follow.”

Disposition: QUALIFICATION_NEEDED. “Positivity” read without restriction is too broad. Let a=e(sqrt_kappa_inv), q=e(kappa_inv), z=e(kappa). The source assumes a*a=q and q*z=1. Then a is nonzero, q=a^2>0 and z=1/q>0 in Q. The source does not force a positive sign for a, N_D or N_f, or positivity of all coefficients.

A narrowly scoped possible successor wording, NOT applied or approved here:

“The five scalar equations are independent local hypotheses. They do not assert e(kappa)=7, general positivity of the other normalizers or coefficients, or analytic trigonometric relations. They do imply e(kappa_inv)>0 and e(kappa)>0 under the rational interpretation.”

This changes neither a theorem's hypothesis set nor its scalar conclusion. A future source successor still needs its own exact digest and review binding.

## T02 — scalar object must be made explicit before semantic approval

Anchor: author WF-SCALAR / WA4 versus natural W4 and baseline N18.

Disposition: OBJECT_UNDERDESCRIPTION, not a proven missing hypothesis in an unread formal theorem.

- If the scalar theorem is about the literal normalized stored factor, its contract should explicitly identify that factor. The four inverse/square laws suffice for cancellation.
- If it is about the actual selected cosine-bearing matrix entry, coefficient identification and the selected-entry evaluation must be supplied. They must not be omitted.
- WA13 already includes WF-HENTRY and WF-SELECTED, so no corresponding omission is found in its prepared selected-entry AND-tail.

Do not choose between these meanings from an implementation name. Do not add a new final physical premise as a repair. A later precisely scoped release may determine the exact stored object.

## F02 — restricted rational realization boundary

Disposition: INDEPENDENT_DEDUCTION_PRESERVED, not a source error or global impossibility.

The four inverse/square laws plus the additional e(kappa)=7 imply 7a^2=1 and have no rational solution. The extra equality is not a source premise. The existing conditional scalar theorem is not vacuous in general: a law-satisfying kappa=1 environment is explicitly given in the frozen review. Real/complex interpretation and physical preparation remain separate questions.

## F04 — law-satisfying evaluated counterexample

Disposition: INDEPENDENT_DEDUCTION_PRESERVED.

Set e(A1*dx)=3/2 and all displayed selected/normalizer/inverse/amplitude symbols to1. Then Dslot2=1 and all five scalar equations hold, while active0 differs from selected/prepared1. This has interpreted kappa=1 and does not claim H is unitary. It does not refute a separately specified real physical model.

## T03/T04/T05/T06 — presentation and evidence roles

- Coverage region counts and author read labels remain claims, not independent proof of reading.
- Seven broad mechanism bundles are navigation, not exact per-declaration theorem dependencies.
- The natural-source disposition inventory and implementation-region inventory remain different units.
- WA15 remains a proposed open hyperedge; arbitrary-n is prospective unsupplied scope.
- The author source_sha256 field identifies its reported implementation subject, not the pinned natural source.
- The refuted raw supplier is not reclassified as an open physical repair.
- No new source or admission wrapper is created.

No source/admission acceptance is returned by this wording-disposition file.

