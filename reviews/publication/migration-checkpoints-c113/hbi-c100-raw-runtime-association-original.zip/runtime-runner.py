"""One bounded Lean invocation in an already-established lake environment.

All generated records and compiler outputs stay under the supplied stage.
Private records may contain host paths; stdout is a path-safe derivative.
This is not a repository builder or transitive-cache verifier.
"""
import argparse
import ctypes
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time


def sha_bytes(value):
    return hashlib.sha256(value).hexdigest()


def sha_file(path):
    return sha_bytes(Path(path).read_bytes())


def memory_status():
    u64 = ctypes.c_ulonglong
    class Status(ctypes.Structure):
        _fields_ = [("length", ctypes.c_ulong), ("load", ctypes.c_ulong),
                    ("total_phys", u64), ("avail_phys", u64),
                    ("total_page", u64), ("avail_page", u64),
                    ("total_virtual", u64), ("avail_virtual", u64),
                    ("avail_extended", u64)]
    value = Status()
    value.length = ctypes.sizeof(Status)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(value)):
        raise RuntimeError("GlobalMemoryStatusEx failed; no Lean launch permitted")
    return {"method": "GlobalMemoryStatusEx",
            "available_MiB": value.avail_phys // 1048576,
            "total_MiB": value.total_phys // 1048576,
            "memory_load_percent": value.load}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True)
    parser.add_argument("--stage", required=True)
    parser.add_argument("--release", required=True)
    parser.add_argument("--mode", choices=["compile", "audit"], required=True)
    args = parser.parse_args()
    repo, stage = Path(args.repo).resolve(), Path(args.stage).resolve()
    private = stage / "PRIVATE"
    private.mkdir(parents=True, exist_ok=True)
    record_path = private / (args.mode + ".record.json")
    if record_path.exists():
        raise RuntimeError("Record already exists; do not repeat a bounded launch")
    release_path = Path(args.release)
    if sha_file(release_path) != "544ee581c9b0a3d059b931258d8a0c7a39744fca8ba5d8c4cee6f2fc626b9dc2":
        raise RuntimeError("Release pin mismatch")
    release = json.loads(release_path.read_text(encoding="utf-8-sig"))
    raw_entries = [entry for entry in release["allowed_read_files"]
                   if entry["logical_path"].startswith("R/") and "formal_path" in entry]
    if len(raw_entries) != 33:
        raise RuntimeError("Expected precisely 33 released source/config entries")
    input_root = private / "input-context"
    context = []
    for entry in raw_entries:
        name = entry["logical_path"][2:]
        original, copied = repo / name, input_root / name
        value = original.read_bytes()
        if sha_bytes(value) != entry["sha256"]:
            raise RuntimeError("Released raw input changed: " + entry["logical_path"])
        if copied.exists():
            if copied.read_bytes() != value:
                raise RuntimeError("Existing private input copy differs")
        else:
            if args.mode != "compile":
                raise RuntimeError("Audit cannot invent a missing compiled-input context")
            copied.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(original, copied)
        context.append({"path": entry["logical_path"], "sha256_before": sha_bytes(value),
                        "copied_sha256": sha_file(copied), "bytes": len(value)})
    lean = shutil.which("lean")
    if lean is None:
        raise RuntimeError("No Lean executable in the actual lake environment")
    lean = str(Path(lean).resolve())
    version = subprocess.run([lean, "--version"], capture_output=True,
                             text=True, timeout=10, creationflags=subprocess.CREATE_NO_WINDOW)
    if version.returncode != 0:
        raise RuntimeError("Lean version observation failed")
    binary_digest = sha_file(lean)
    library = private / "lib" / "lean"
    own_olean = library / "QuantumBlockEncoding" / "HermiteBoundaryInjection.olean"
    env = dict(os.environ)
    inherited_path = env.get("LEAN_PATH", "")
    if args.mode == "compile":
        own_olean.parent.mkdir(parents=True, exist_ok=True)
        if own_olean.exists():
            raise RuntimeError("Own output already exists; no overwrite/recompile")
        target = input_root / "QuantumBlockEncoding" / "HermiteBoundaryInjection.lean"
        output = own_olean
        root = input_root
    else:
        if not own_olean.exists():
            raise RuntimeError("Separate audit requires the own compiled target olean")
        compiled_record = json.loads((private / "compile.record.json").read_text(encoding="utf-8"))
        if compiled_record.get("exit_code") != 0 or compiled_record.get("timeout"):
            raise RuntimeError("Own compile was not successful")
        if sha_file(own_olean) != compiled_record.get("output_sha256"):
            raise RuntimeError("Own target olean drift")
        env["LEAN_PATH"] = str(library) + os.pathsep + inherited_path
        target = stage / "RootAudit.lean"
        output = private / "RootAudit.olean"
        root = stage
    if output.exists():
        raise RuntimeError("Runtime output exists; no overwrite")
    command = [lean, "-j", "1", "-M", "3072", "--root=" + str(root),
               "-o", str(output), str(target)]
    before_memory = memory_status()
    record = {"mode": args.mode, "command_actual": command, "cwd_actual": str(repo),
              "resolved_lean_actual": lean, "resolved_lean_sha256": binary_digest,
              "lean_version": version.stdout.strip(), "lean_version_stderr": version.stderr,
              "inherited_LEAN_PATH_actual": inherited_path,
              "effective_LEAN_PATH_actual": env.get("LEAN_PATH", ""),
              "own_library_first_for_audit": args.mode == "audit",
              "context_before": context, "prelaunch_memory": before_memory,
              "cap_MiB": 3072, "reserve_MiB": 2048, "threshold_MiB": 5120,
              "wall_timeout_seconds": 180, "dependency_scope": "inherited current R lake dependencies, not clean rebuilt TCB",
              "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "launched": False}
    if before_memory["available_MiB"] < 5120:
        record.update({"blocked": "INSUFFICIENT_AVAILABLE_MEMORY", "exit_code": None})
    else:
        stdout_path, stderr_path = private / (args.mode + ".stdout.log"), private / (args.mode + ".stderr.log")
        start = time.monotonic()
        minimum_available = before_memory["available_MiB"]
        with stdout_path.open("xb") as out, stderr_path.open("xb") as err:
            process = subprocess.Popen(command, cwd=repo, env=env, stdout=out, stderr=err,
                                       creationflags=subprocess.CREATE_NO_WINDOW)
            record["launched"] = True
            record["pid_private"] = process.pid
            timeout = False
            reserve_stop = False
            while process.poll() is None:
                elapsed = time.monotonic() - start
                available = memory_status()["available_MiB"]
                minimum_available = min(minimum_available, available)
                if elapsed >= 180 or available < 2048:
                    timeout = elapsed >= 180
                    reserve_stop = available < 2048
                    process.kill()
                    break
                time.sleep(0.25)
            process.wait()
        record.update({"exit_code": process.returncode, "seconds": round(time.monotonic() - start, 3),
                       "timeout": timeout, "reserve_stop": reserve_stop,
                       "minimum_available_MiB_observed": minimum_available,
                       "stdout_sha256": sha_file(stdout_path), "stderr_sha256": sha_file(stderr_path),
                       "output_sha256": sha_file(output) if output.exists() else None})
    record["context_after"] = []
    for item in context:
        name = item["path"][2:]
        record["context_after"].append({"path": item["path"],
                                        "sha256_after": sha_file(repo / name),
                                        "copied_sha256_after": sha_file(input_root / name),
                                        "unchanged": sha_file(repo / name) == item["sha256_before"]
                                        and sha_file(input_root / name) == item["sha256_before"]})
    record["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    record_path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    safe = {key: record.get(key) for key in ["mode", "launched", "blocked", "lean_version",
             "resolved_lean_sha256", "prelaunch_memory", "cap_MiB", "reserve_MiB", "threshold_MiB",
             "seconds", "timeout", "reserve_stop", "exit_code", "minimum_available_MiB_observed",
             "stdout_sha256", "stderr_sha256", "output_sha256"]}
    safe["all_33_source_and_private_copy_bytes_unchanged"] = all(item["unchanged"] for item in record["context_after"])
    safe["dependency_scope"] = record["dependency_scope"]
    print(json.dumps(safe, ensure_ascii=False))


if __name__ == "__main__":
    main()
