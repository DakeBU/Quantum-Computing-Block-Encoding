"""Copy only explicitly authorized local provider artifact paths, without rebuilding."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True)
    parser.add_argument("--stage", required=True)
    parser.add_argument("--release", required=True)
    args = parser.parse_args()
    repo, stage = Path(args.repo).resolve(), Path(args.stage).resolve()
    private = stage / "PRIVATE"
    library = private / "attempt2" / "PRIVATE" / "lib" / "lean"
    output_record = private / "inherited-provider-artifacts.record.json"
    if output_record.exists():
        raise RuntimeError("Provider staging record already exists")
    release_path = Path(args.release)
    if digest(release_path) != "544ee581c9b0a3d059b931258d8a0c7a39744fca8ba5d8c4cee6f2fc626b9dc2":
        raise RuntimeError("Release pin mismatch")
    release = json.loads(release_path.read_text(encoding="utf-8-sig"))
    providers = [item for item in release["allowed_read_files"]
                 if "formal_path" in item and item["logical_path"].startswith("R/")
                 and item["logical_path"].endswith(".lean")
                 and item["logical_path"] not in ["R/lakefile.lean", "R/QuantumBlockEncoding/HermiteBoundaryInjection.lean"]]
    target = library / "QuantumBlockEncoding" / "HermiteBoundaryInjection.olean"
    target_expected = "2af96b0846227cecbb021130f047619a3a8332d71d8f05f38d7ec86fbc690b65"
    if digest(target) != target_expected:
        raise RuntimeError("Own target output pin mismatch")
    plans, absent = [], []
    for item in providers:
        name = item["logical_path"][2:]
        if digest(repo / name) != item["sha256"]:
            raise RuntimeError("Authorized provider source changed")
        stem = name[:-5]
        for suffix in [".olean", ".olean.private", ".olean.server", ".ir"]:
            source = repo / ".lake" / "build" / "lib" / "lean" / (stem + suffix)
            destination = library / (stem + suffix)
            if not source.exists():
                if suffix == ".olean":
                    raise RuntimeError("Missing mandatory inherited provider olean: " + stem)
                absent.append("R/.lake/build/lib/lean/" + stem + suffix)
                continue
            if destination.exists():
                raise RuntimeError("Destination collision; no overwrite: " + stem + suffix)
            plans.append((source, destination, "R/.lake/build/lib/lean/" + stem + suffix, digest(source)))
    rows = []
    for source, destination, logical, before in plans:
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
        copied, after = digest(destination), digest(source)
        if before != copied or before != after:
            raise RuntimeError("Inherited artifact copy drift")
        rows.append({"source_logical": logical, "source_actual": str(source),
                     "copied_actual": str(destination), "sha256_before": before,
                     "sha256_copy": copied, "sha256_after": after,
                     "bytes": source.stat().st_size})
    if digest(target) != target_expected:
        raise RuntimeError("Own target output changed during provider staging")
    record = {"scope": "inherited current R artifacts only; not freshly compiled or fully TCB audited",
              "provider_modules": len(providers), "artifact_files": rows,
              "optional_absent_exact_paths": absent,
              "own_target_olean_sha256_before_and_after": target_expected,
              "repository_cache_written_or_built": False}
    output_record.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"provider_modules": len(providers), "copied_artifact_files": len(rows),
                      "optional_absent": len(absent), "all_before_copy_after_hashes_equal": True,
                      "own_target_olean_unchanged": True, "provider_scope": record["scope"]}))


if __name__ == "__main__":
    main()
