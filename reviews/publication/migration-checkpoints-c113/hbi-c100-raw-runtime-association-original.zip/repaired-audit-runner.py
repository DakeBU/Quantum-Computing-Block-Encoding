"""One separately authorized additional audit after inherited-provider staging."""
import argparse
import datetime
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True)
    parser.add_argument("--stage", required=True)
    args = parser.parse_args()
    repo, stage = Path(args.repo).resolve(), Path(args.stage).resolve()
    spec = importlib.util.spec_from_file_location("bounded_runtime_helpers", stage / "runtime-runner.py")
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    private = stage / "PRIVATE"
    record_path = private / "repaired-audit.record.json"
    if record_path.exists():
        raise RuntimeError("Additional audit record already exists; no repeated launch")
    provider_record = json.loads((private / "inherited-provider-artifacts.record.json").read_text(encoding="utf-8"))
    for artifact in provider_record["artifact_files"]:
        if helper.sha_file(artifact["source_actual"]) != artifact["sha256_before"] or helper.sha_file(artifact["copied_actual"]) != artifact["sha256_before"]:
            raise RuntimeError("Inherited provider source/copy drift before audit")
    library = private / "attempt2" / "PRIVATE" / "lib" / "lean"
    own_target = library / "QuantumBlockEncoding" / "HermiteBoundaryInjection.olean"
    target_pin = "2af96b0846227cecbb021130f047619a3a8332d71d8f05f38d7ec86fbc690b65"
    if helper.sha_file(own_target) != target_pin:
        raise RuntimeError("Own target olean changed")
    lean = str(Path(shutil.which("lean")).resolve())
    version = subprocess.run([lean, "--version"], capture_output=True, text=True, timeout=10,
                             creationflags=subprocess.CREATE_NO_WINDOW)
    if version.returncode != 0:
        raise RuntimeError("Version observation failed")
    env = dict(os.environ)
    inherited = env.get("LEAN_PATH", "")
    env["LEAN_PATH"] = str(library) + os.pathsep + inherited
    target, output = stage / "RootAudit.lean", private / "repaired-audit.olean"
    if output.exists():
        raise RuntimeError("Additional audit output already exists")
    command = [lean, "-j", "1", "-M", "3072", "--root=" + str(stage),
               "-o", str(output), str(target)]
    memory = helper.memory_status()
    record = {"mode": "repaired-audit", "separate_additional_authorization": True,
              "command_actual": command, "cwd_actual": str(repo),
              "resolved_lean_actual": lean, "resolved_lean_sha256": helper.sha_file(lean),
              "lean_version": version.stdout.strip(), "inherited_LEAN_PATH_actual": inherited,
              "effective_LEAN_PATH_actual": env["LEAN_PATH"], "own_library_first": True,
              "own_target_olean_sha256_before": target_pin, "audit_source_sha256": helper.sha_file(target),
              "prelaunch_memory": memory, "cap_MiB": 3072, "reserve_MiB": 2048,
              "threshold_MiB": 5120, "wall_timeout_seconds": 180,
              "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "launched": False}
    if memory["available_MiB"] < 5120:
        record.update({"blocked": "INSUFFICIENT_AVAILABLE_MEMORY", "exit_code": None})
    else:
        out_path, err_path = private / "repaired-audit.stdout.log", private / "repaired-audit.stderr.log"
        start, minimum = time.monotonic(), memory["available_MiB"]
        with out_path.open("xb") as stdout, err_path.open("xb") as stderr:
            process = subprocess.Popen(command, cwd=repo, env=env, stdout=stdout, stderr=stderr,
                                       creationflags=subprocess.CREATE_NO_WINDOW)
            record["launched"], record["pid_private"] = True, process.pid
            timeout, reserve_stop = False, False
            while process.poll() is None:
                elapsed = time.monotonic() - start
                available = helper.memory_status()["available_MiB"]
                minimum = min(minimum, available)
                if elapsed >= 180 or available < 2048:
                    timeout, reserve_stop = elapsed >= 180, available < 2048
                    process.kill()
                    break
                time.sleep(0.25)
            process.wait()
        record.update({"exit_code": process.returncode, "seconds": round(time.monotonic() - start, 3),
                       "timeout": timeout, "reserve_stop": reserve_stop,
                       "minimum_available_MiB_observed": minimum,
                       "stdout_sha256": helper.sha_file(out_path), "stderr_sha256": helper.sha_file(err_path),
                       "output_sha256": helper.sha_file(output) if output.exists() else None})
    record["provider_after_checks"] = []
    for artifact in provider_record["artifact_files"]:
        source_after = helper.sha_file(artifact["source_actual"])
        copy_after = helper.sha_file(artifact["copied_actual"])
        record["provider_after_checks"].append({"source_logical": artifact["source_logical"],
                                               "sha256_source_after": source_after,
                                               "sha256_copy_after": copy_after,
                                               "unchanged": source_after == artifact["sha256_before"] == copy_after})
    record["own_target_olean_sha256_after"] = helper.sha_file(own_target)
    record["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    record_path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    safe = {key: record.get(key) for key in ["mode", "launched", "blocked", "lean_version",
            "resolved_lean_sha256", "prelaunch_memory", "cap_MiB", "reserve_MiB", "threshold_MiB",
            "seconds", "timeout", "reserve_stop", "exit_code", "minimum_available_MiB_observed",
            "stdout_sha256", "stderr_sha256", "output_sha256"]}
    safe["all_provider_bytes_unchanged"] = all(row["unchanged"] for row in record["provider_after_checks"])
    safe["own_target_olean_unchanged"] = record["own_target_olean_sha256_after"] == target_pin
    print(json.dumps(safe, ensure_ascii=False))


if __name__ == "__main__":
    main()
