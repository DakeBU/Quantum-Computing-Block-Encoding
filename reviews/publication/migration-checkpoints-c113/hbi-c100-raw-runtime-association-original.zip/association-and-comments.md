# Independent association and scope assessment

## Inputs and chronology

The natural-source SHA256 is 69f7b917b21e70ca98285530571b11668ea69333f8fdcc0cfca43b19cf898018. The source-only seal 7cbe100506b3e59f235edaba56fe15e4367aad23a3ee997732ba3ad3bf5282cd preceded formal release; own-formal seal 2329c8d87cf95c396cee9f207abbeb3e163788317e86834fdcd11f42be657445 preceded actual decoder release; comparison seal 62b5ba50d4f0f3ee1d78550ec09b5cc5cda13b95c1ba61a22a95fd59e96f1f6a preceded this 44-file release. None was rewritten. Independent source semantics remain those frozen before the later disclosures, not conclusions inferred from successful compiler output.

This stage read exactly the newly allowed 33 raw/config objects, two C101 public observations, two bounded-checker files, C74 corrected source graph/coverage and five C62 source-only topology-stage3 files. It did not follow references to unreleased files, old formal/decoder reviews, author auxiliary rationales or final admission metadata. The later proposal mentioned by the parent has not been read.

## Raw-to-formal transport

All 33 pairs match the released pins. There are 31 Lean text objects including lakefile, and two non-Lean configuration identities. The current whole target raw SHA256 is 7b16e1ee4b88b9e775cee1a63482c60df2121ce88ad43f10e72ca2e88c6d472c; its formal snapshot SHA256 is cf4fcd8e410b4c103e8e45a569e878404de64e1f2d3775dad0a99004990627f1. Both have 55086 bytes. They are not asserted byte-identical.

The complete reviewed comment checker preserves strings/quoted identifiers, masks nested comments with UTF-16-width spaces and normalizes line endings; recognized raw-string/character cases are rejected. Nine synthetic tests passed. Its exact output equals every admitted formal snapshot. This is a bounded lexical association, not a general Lean lexer correctness proof or a semantic noninterference/TCB theorem. The previous whole-target interpretation covered all 125 declarations, including private helper, anonymous instances and unused EOF carrier declarations; no EOF orphan is erased by raw association.

All 56 current target comments were read completely and assessed against the earlier derivation. No theorem-level mismatch was found. Descriptive cautions are explicit in comment-assessment.json: historical prototype triangular wording does not change actual row-oriented S0 upper/S1 lower matrices or establish prototype history; the generic boundary adapter needs ScheduleValid AND root Partial, not merely the condition highlighted by its comment; “upper-half interval” must not obscure that M is the aligned upper endpoint while the middle sits below the whole-grid midpoint; bounded factors are not a numerical-stability theorem; the center's right assignment is justified by P(0)=1; polynomial address count in k,n is not a runtime/precision/epsilon claim. No production comment was edited.

## Released topology identity and role

The accepted C74 graph is exactly SHA256 c0e6f83e2eb402836a325810bf3ad3c78cee18f4e871f6d1dc426ade3b859aa0; its coverage is 95b198eaf46578ccbf83c154647a8020bbb36d1c8dda2f0712849a60ad6c5021. It has 28 nodes and 20 AND hyperedges, not implementation-topology edges or algorithmic OR routes. The 86 coverage blocks reproduce allowed SOURCE text exactly: 305 node lines, 14 excluded nonmathematical lines and 85 empty separators account for all 404 lines; all nodes are assigned.

Its distinctions agree with the independent frozen derivation: generic finite Q versus specialized guarded cQ=P; total literal injected row/traversal versus interpreted polynomial values; matrix/traversal agreement requiring schedule plus partial root but not nonzero origin; all-real grid/right algebra versus positive-L cut/support statements; three additive branch suppliers at the exact root; and carrier-only address count independent of numerical correctness. topology-association.json maps every released node to the reviewer's already-frozen source facets, preserving AND roles and intermediate suppliers.

C62 seal 90e75997bc0c555a0363efea1e943b60908222fe9f326306bea7d860f6799a10 says ACCEPT_SOURCE_TOPOLOGY_SUCCESSOR_ONLY for those exact source/graph/coverage identities. Only five released C62 files were read, and only released payload members of its manifest were checked. No claim is made to have verified all unreleased C62 payloads. This is not C62 formal/decoder exposure, not compilation or publication approval, and does not retroactively approve the different 45-node C100 source extraction.

## Other-producer observations and actual own execution

The two C101 public observations bind the same current raw/config inputs and report positive bounded compile/import results. Their reported 63.532-second compile and 28.375-second audit are other-producer observations, not executions performed by this reviewer; unreleased private originals were not opened.

Actual own commands and resolved binary identity, dates, true exits, logical LEAN_PATH order, output digests and before/copy/after source/artifact records are in runtime-observations.json. Launchers used the actual R lake environment and cwd R; they did not run a repository build or rebuild R caches. Logical launcher forms were:
- lake env python -B OUTPUT/runtime-runner.py --repo R --stage OUTPUT --release INPUT --mode compile (memory non-launch).
- lake env python -B OUTPUT/runtime-runner.py --repo R --stage OUTPUT/PRIVATE/attempt2 --release INPUT --mode compile.
- lake env python -B OUTPUT/runtime-runner.py --repo R --stage OUTPUT/PRIVATE/attempt2 --release INPUT --mode audit.
- provider staging via OUTPUT/stage-inherited-providers.py, then lake env python -B OUTPUT/repaired-audit-runner.py --repo R --stage OUTPUT.

These abbreviate logical path roots only; the exact resolved Lean argument arrays and raw original records are separately bound. The actual binary is Lean 4.33.0, commit d8b18978322de05a8f3dba51ef03cf5461676c17, SHA256 dd86e9b24990b1da425ea4af910f016e4db8f9a25c9ddad27bc6bee3690e677f.

Every launched command had -j 1, -M 3072 and a 180-second wall timeout. GlobalMemoryStatusEx checked actual available memory immediately before launch against 5120 MiB. A polling reserve guard (2048 MiB, 0.25-second observations) supplemented Lean's allocation limit; this is not an OS job-object RSS cap or continuous-memory guarantee. CIM/performance-counter unavailability was an environment diagnostic only. The initial 5045-MiB preflight launched no theorem compiler and produced no object, regardless of successful launcher exit.

The actual whole-target compile exited 0 in 44.468 seconds, prelaunch 5309 MiB, observed minimum 3759 MiB, no timeout/reserve stop. Its newly compiled object SHA256 is 2af96b0846227cecbb021130f047619a3a8332d71d8f05f38d7ec86fbc690b65. Three unnecessarySeqFocus linter warnings are not proof failures. All 33 original/copy input bytes were unchanged.

The first separate audit exited 1 in 2.297 seconds, prelaunch 5394 MiB. The prefixed isolated QuantumBlockEncoding package root lacked HermiteBernstein.olean, so import stopped before any root output. This preserved ENV_BLOCKED record is not mathematical impossibility and is not relabeled as success.

After separate bounded repair authorization, only the exact 29 allowed local production provider modules (excluding target/lakefile) contributed inherited .olean files. All mandatory artifacts existed, 87 optional .olean.private/.olean.server/.ir files were absent, and no collision/drift occurred. Source, copied and after hashes are recorded. These binaries were not freshly rebuilt from the allowed Lean sources. Own HBI was never overwritten.

The ONE additional import/type/axiom audit exited 0 in 33.390 seconds, prelaunch 5287 MiB, observed minimum 2687 MiB; no timeout/reserve stop. Own HBI and all 29 providers remained unchanged. Its own package root is first in LEAN_PATH, containing newly compiled HBI plus staged inherited providers, then inherited package/standard-library context. Missing-package fall-through is no longer the earlier audit's gap. Lake launcher warnings about local package changes remain private and prevent any clean-dependency/clean-TCB claim.

The actual printed sample root quantifies k,n, real L, hL : 0<L, bits and hbits : length=n+1, with the literal Hermite kernel/initial/terminal contraction equated to sampledAmplitude k (n+1) L at wordSampleIndex. The actual storage theorem is Fintype.card HermiteCoreAddress k n = 2*(n+1)*(2*k+6)^2. Each reports exactly [propext, Classical.choice, Quot.sound]. InjectionBond and MiddleBond card checks both print 2*k+3. Exact stdout is preserved publicly and its private original hash is bound. This corroborates the earlier interpretation rather than defining source semantics.

## Stop and residual boundary

No new mathematical/source mismatch or root hypothesis was discovered. Historical environment gaps are disclosed and the import gap is now resolved under the staged inherited-provider context. No full-project build, clean/transitive TCB rebuild, simulator, finite-bit validation, normalization/circuit/resource theorem or registry/schema/admission action occurred. This stage does not authorize any of those conclusions. Final metadata binding requires a separately authorized review and final decision. Stop at RAW_RUNTIME_ASSOCIATION_FROZEN.

