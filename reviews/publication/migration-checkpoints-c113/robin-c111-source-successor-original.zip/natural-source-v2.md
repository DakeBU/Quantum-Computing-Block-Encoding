# RobinMatrix: finite symbolic backend, preparation interfaces, and their exact limits

LOCAL retrospective source, whole explicit-module AUTHOR proposal. This is not independent review, compiler evidence, publication acceptance or PURIFIED exposition. The older bounded checkpoints remain historical, unchanged artifacts; their unread markers are superseded only by the complete distributed coverage recorded here.

## W0. Provenance and semantic carriers

This is retrospective LOCAL mathematical source recovered from an existing implementation, not a prior source, original-paper proof, independent review or new quantum algorithm. Historical formalizer identity is UNKNOWN. The immutable raw subject is `R/QuantumBlockEncoding/RobinMatrix.lean`, SHA256 `1cca5119ac056fe041b25c529909b9fb6c3e4995e04ebde2f69e83fce47a0835`. The original author personally read lines1–16034, including343 complete declarations; distinct C78 AUTHOR read all334 remaining complete bodies and both namespace ends. The original author then read and integrated C78's complete natural chapter, contract expansions, typed non-status fields and conditional-binder families, and mechanically joined all body/definition/field bindings. The original author does not claim personal raw-tail reading. All677 explicit declarations,114 private declarations,69 structures,1950 lexical fields and11 ambient regions have collectively documented AUTHOR dispositions. Neither inventory retention nor a successful build establishes that reading or any independent acceptance.

Coefficients are free syntax: rational literals, named symbols, addition, multiplication and negation. A rational environment assigns a value to every String symbol and recursively evaluates this syntax. It does not silently impose inverse, square-root, trigonometric, positivity or normalization identities. Structural coefficient equality and equality after rational evaluation are different contracts. In particular, the source symbol `A1*dx` is one literal identifier, not a product of separately interpreted A1 and dx.

A matrix is a function on finite labels. Its product is a literal increasing-label fold of products, starting at coefficient zero. Chronological gate evaluation left-multiplies each new gate and starts from a literal identity. Zero and identity nodes therefore survive in the expression tree. Provider lemmas justify evaluated all-path-zero, unique-path and two-path reductions under explicit finite support conditions. They do not assert raw associativity or physical complex-unitary semantics for these coefficient matrices.

## W1. Robin stencil, scaling, widths and costs

Put N=2^n. Stencil lookup keeps entries with signed equality i+offset=j, with no modular wrap; no matches gives literal zero and multiple matches are combined by a nonempty fold. Row selection tests the left boundary first (`i<2`), then right (`i>N-3`), then bulk; natural subtraction and missing-row fallback make the definitions total even for small n without asserting a valid small-grid discretization.

The bulk stencil at offsets -2,-1,0,1,2 is -1/12,4/3,-5/2,4/3,-1/12. With a the literal symbol `A1*dx` and b the literal symbol `B1*dx`, the four boundary stencils are:

| row | offsets | coefficients |
| --- | --- | --- |
| 0 | 0,1,2 | -5/2+(7/3)a, 8/3, -1/6 |
| 1 | -1,0,1,2 | 4/3-a/6, -31/12, 4/3, -1/12 |
| N-2 | -2,-1,0,1 | -1/12, 4/3, -31/12, 4/3+b/6 |
| N-1 | -2,-1,0 | -1/6, 8/3, -5/2-(7/3)b |

These data define D; Ak[i,j]=f(n,i)*D[i,j] is ROW scaling. At n=3, target(0,0), the actual local theorem identifies Ak with f(3,0) times global sparse slot2,row0. Unfolding that provider value gives `f_3_0 * (-5/2+(7/3)*symbol("A1*dx"))`. The implemented target field transports this coefficient through its cache definitions. Source Strings naming the formula are not its proof. No PDE consistency, stability, convergence or paper-fidelity theorem is inferred from the stencil data.

The function named `matrixOneNorm` takes the MAXIMUM ABSOLUTE ROW SUM, not the standard maximum-column-sum 1-norm. The numeric normalizer multiplies that quantity by nF and k; its bound check is Boolean. The symbolic normalizer is `(N_D*N_f)*kappa` and error data is zero. Resource records carry `polynomialDegreeCost*n*clog2(n)+kappa*n`, pure ancilla count2n, and a derivative count n-1 with natural subtraction. They are formulas/cache equalities, not physical return-of-workspace or expanded gate-count proofs.

The fixed one-term parameters have sparse cardinality7, one function piece and polynomial-degree-cost1. Function-work width is `clog2(n)+clog2(1)+3`; then come indicator1, sparse3, padding n-3, system n, ancilla1. The effective signal includes ALL non-system wires. Dimension proofs establish signal-times-system dimension factorization via powers of two; zero-signal projection selects compound labels i,j, not doubled labels2i,2j. Visible padded work n-clog2(kappa)+1, stored theorem budgets and any expanded physical gate counts remain distinct quantities.

## W2. Actual gates, active source domain, and restricted cleanup

The active backend is the seven chronological gates indicator U, sparse-amplitude T, boundary R, sparse image B, function F, SWAP S and transpose-style sparse image Bt. A separate ten-label theorem transcript includes preparation/unpreparation and other labels; it is data and does not replace the actual seven-gate product. Bool unitary flags, source Strings and `SemanticObligation.proved` defaults are not mathematical proof fields. Cache equality certificates in constructors are genuine equalities, but they certify their exact stored objects rather than a separate normalized block assertion.

The basis label has trailing ancilla bit0, n system bits, then n sparse-address bits, then high function/indicator bits. The active sparse SOURCE domain is BOTH clean padding AND slot<kappa; at kappa7 the eighth encoded slot is excluded. Zero-amplitude boundary slots are retained in this index domain. Global slot offsets modulo N are N-2,N-1,0,1,2,N-3,3. The forward image replaces the address block by `(offset(s)+row) mod N`, preserving low and high bits; matrix B is its image indicator. Bt is the transposed indicator, not a proved full-space inverse.

SWAP exchanges the two n-bit blocks through their XOR difference and preserves everything else. The candidate post-SWAP preimage restores clean padding and the inverse slot table4,3,2,1,0,6,5 (fallback2). For n>=3 and an active source, the route assembles the actual finite post/pre labels, image equality, clean/range certificates, dagger-entry-one, register preservation and uniqueness AMONG ACTIVE SOURCES. Its dagger-column indicator formula is restricted to this domain. It neither supplies all dirty rows nor a full unitary extension. The consumed published GHL lesson is supplied mathematical memory, not our independent review of every transitive provider proof; exact provider-read extents and remaining context gates stay in the input audit.

Actual gate branches also have guards. The derivative rotation is identity when the indicator is0 and otherwise a signed pair `(c,-s;s,c)` preserving non-ancilla bits. The boundary rotation is identity when indicator1 and otherwise the corresponding ancilla pair. The function clean-input branch has its named normalized coefficient at its specified output, literal zeros for other clean function outputs, and arbitrary completion entries elsewhere; dirty inputs are not silently identity or system-preserving. Standalone clean branch entry lemmas do not connect independent row/column binders into one coherent chronology or prove analytic unitary completion.

## W3. Concrete branch support and the actual H-free entry

At n3, boundary(0,0) uses global slot2, whose full source/target is32. The surviving factor ledger path is32,32,32,32,0,0,0,32, with boundary-rotation companion33. The bulk(2,5) slot5 path90,218,218,218,170,170,212,228 retains indicator1. Thus earlier comparison to clean boundary endpoint84 is a boundary-versus-bulk mismatch, not a general unwanted indicator reset. That reclassification changes interpretation, not the exact finite path facts and not the final projection theorem.

Write the grouped matrices `P=B*(R*(T*U))`, `Q=Bt*(S*F)`, `M=Q*P`. For column32, complete private support lemmas show P is evaluated-zero outside rows0,1; Q row32 vanishes at1. The all-path argument kills all intermediate labels except0 and the remaining entries evaluate to

`eval_e(M[32,32])=(e(f_3_0)*e(N_f_inv))*e(boundary_cos_half_0_2)`.

For column0, prefix support is96,97. Dagger row0 permits only96, SWAP row96 only12, and F[12,96]=F[12,97]=literal0. Hence `eval_e(M[0,0])=0` for EVERY environment. A separate actual active gate-fold proof handles its literal identity initialization and proves its `(0,0)` entry evaluates zero too. The bridge equates evaluated entries because both are zero; it does not identify raw free-syntax matrices by reassociation.

## W4. Coefficient normalization is conditional algebra, not preparation

The corrected-angle decision records input-angle text2arccos(D/ND), but it neither changes the actual free cosine symbol matrix nor proves trigonometry. Replacing the selected evaluated entry by its normalized coefficient needs the explicit hypothesis `e(boundary_cos_half_0_2)=eval_e(boundaryNormalizedCoefficient(p3,0,2))`. Then the selected product evaluates as B=(f*N_f_inv)*(Dslot2*N_D_inv).

To normalize B by ND*NF, the actual theorem assumes BOTH `e(N_D_inv)*e(N_D)=1` and `e(N_f_inv)*e(N_f)=1`. Including the stored kappa factor additionally needs `e(kappa_inv)*e(kappa)=1`; replacing kappa_inv by the two literal half factors additionally needs `e(sqrt_kappa_inv)^2=e(kappa_inv)`. These laws are not implied by a symbol name or by the parameter kappa7; no hypothesis here asserts e(kappa)=7. The proof expands the stored coefficient/normalizer and uses rational multiplication laws and each supplied inverse law. It proves no environment realization or factor-to-operator bridge.

The local preparation interface takes arbitrary8x8 H and asks H[2,0]=the sqrt symbol. For arbitrary proposed Hdagger a separate equality Hdagger[0,2]=H[2,0] is needed; choosing literal transpose makes that equality definitional. There is no complex conjugation, orthogonality or physical H construction. The strongest prefix product-under-contracts theorem combines the transpose-entry fact with the stored factor-normalization identity under the uniform entry and all four environment laws. Its second conjunct does not use H to prove a full sandwich identity. Finite matrices appearing only as interface tests are not unitary preparation witnesses.

## W5. Seven-slot diagonal fold and the missing operator supplier

Let b(s)=16s for s:Fin7, `a=symbol("sqrt_kappa_inv")`, w=a*a, and `C_s=M[b(s),b(s)]*w`. The exact backend predicate requires BOTH C2=selectedContribution AND the raw signal block entry equals the literal left fold L(C) over `List.finRange7` from coefficient0. It has no additional formal provenance conjunct. A placeholder family with the selected value at2 and an opaque other-branch symbol elsewhere proves only its selected equality.

C78 supplies actual complete finite support, not just the prefix's clean-path probes. Slots1,3,4,5,6 have full input x=16,48,64,80,96; two prefix outputs(112,113),(16,17),(32,33),(80,81),(48,49); and SWAP preimages14,2,4,10,6. For each, gate support confines the prefix to its pair and the exact function zeros plus dagger/SWAP row support kill both suffix values. Exhaustive intermediate-index cases prove the diagonal evaluates0. Slot0 uses the preceding grouped `(0,0)` theorem. All six evaluated vanish feeders hold for arbitrary environments without normalization laws. Evaluating the literal fold and removing six rational zeros gives `eval_e(L(C))=eval_e(C2)`. It does NOT prove raw L(C)=C2.

Target cache and entry bridges make expansion, projection summation, blockEntry=L(C), and raw signal full-entry A=L(C) equivalent syntactic propositions. Conditional wrappers transport the same missing proposition; they are not different completed OR proofs. Membership of2 in the fold is insufficient to identify an operator entry.

For arbitrary8x8 H define Uniform(H) by all seven raw equalities H[s,0]=a, leaving row7 and other columns unconstrained. Literal transpose and those equalities identify the diagonal contributions `D_s(H)=M[b(s),b(s)]*(H[s,0]*transpose(H)[0,s])` with C_s; whole-family equality then gives Dcal(H)=L(C) syntactically. But the theorem concluding A=L(C) still assumes BOTH Uniform(H) AND A=Dcal(H). Dcal is a diagonal fold, not the full double sum of a lifted preparation sandwich. This supplier must not be silently dropped.

## W6. The defined prepared matrix and the exact raw-target refutation

The later source defines an8x8 matrix K(H) for arbitrary8x8 H by

`K(H)[r,c] = L_s( M[b(s),b(s)] * (H[s,c] * transpose(H)[r,s]) )`,

where s ranges over Fin7 and its value embeds into Fin8. Multiplication order and parentheses are literal. This is diagonal compression of seven selected backend diagonals. Its clean entry K(H)[0,0] is definitionally Dcal(H). Seven equal clean-column entries of H and J suffice to equate their clean K entries; no other entries are needed. This does not identify K(H) with a full-space lifted H-transpose*M*H double sum, which would involve off-diagonal and unused-slot contributions.

K(H) is assigned to a single `GateMatrix Coeff 3` carrying one composite preparation/backend/unpreparation label. Its unitary field is a false-default semantic-status record. The singleton circuit and label-match certificate construct genuine `CircuitMatrixSemantics` with the supplied matrix, but the generic type requires label matching and product evaluation, not unitary synthesis. Because evaluation starts at literal identity, the singleton clean entry P(H) equals K(H)[0,0] AFTER rational evaluation, not by a raw AST identity. Uniform(H) therefore gives `eval_e(P(H))=eval_e(L(C))=eval_e(C2)`.

Let A now denote the exact active seven-gate matrix's clean entry, including its identity seed. Cache, zero-index and dimension-cast proofs identify this A with the focused signal entry; they do not replace it by differently grouped M in coefficient syntax. The active list lacks both preparation-side labels, and its seven labels differ from the one-label compressed singleton. Generic `PreparedCircuitEntryTarget` equality is only its selected cached-entry equality, equivalently the selected backing matrix-entry equality, not full matrix equality. Raw A=K(H)[0,0], under Uniform(H), is equivalent to raw A=L(C). Evaluated and uncast variants remove only their stated caches/casts; raw equality implies evaluated equality, not conversely.

For each fixed environment define Fold(e) by `eval_e(A)=eval_e(L(C))`. The actual active zero theorem and all six vanish feeders give the exact normal form

`Fold(e) iff eval_e(C2)=0`.

Clean-column congruence transports an ALREADY SUPPLIED active/prepared equality for J to H; matching columns alone does not supply it. The diagnostic theorem separately requires both active-versus-grouped evaluated equality and active-versus-selected evaluated equality before concluding selected evaluation zero. The later direct active/prepared consumer requires BOTH Uniform(H) and an active/prepared evaluated proof to conclude the same zero. Their conditional signatures are not unconditional constructions.

The source chooses e* assigning1 to exactly `f_3_0`, `N_f_inv`, `boundary_cos_half_0_2`, `sqrt_kappa_inv`, and0 to all other symbols. The selected raw evaluator from W3 and the squared amplitude factor give `eval_e*(C2)=1`; the active clean entry still evaluates0. A hypothetical raw A=L(C) would preserve equality under every interpretation, giving0=1 at e*. This proves the exact raw backend-expansion and projection-summation propositions false, and A unequal to L(C) in coefficient syntax. It is not merely a floating-point test. For an arbitrary fixed environment Fold(e) can hold when C2 evaluates0; the source does NOT prove failure for every environment.

The witness does not satisfy the later inverse laws: e*(N_f_inv)=1 but e*(N_f)=0. That does not weaken refutation of the unconditional symbolic target, whose statement has no such restrictions. It also does not refute a separately stated normalized physical model, actual prepared operator, PDE result or quantum-algorithm possibility. Under Uniform(H), raw active/prepared equality would imply the refuted raw fold and is therefore not a viable supplier for this fixed contract. The separately defined compressed prepared-side identity is a different object, not an OR winner for the old raw target.

## W7. Conditional prepared-entry normalization and the remaining source gap

The actual prepared scalar theorem quantifies arbitrary H and rational environment e and retains the COMPLETE AND-tail:

- all seven syntactic equalities Uniform(H);
- the exact coefficient-identification equation `e(boundary_cos_half_0_2)=eval_e(Dslot2*N_D_inv)`;
- `e(N_D_inv)*e(N_D)=1`;
- `e(N_f_inv)*e(N_f)=1`;
- `e(kappa_inv)*e(kappa)=1`;
- `e(sqrt_kappa_inv)*e(sqrt_kappa_inv)=e(kappa_inv)`.

The data binders are not physical certificates. The five scalar equations are independent local hypotheses. They do not assert e(kappa)=7, general positivity of the other normalizers or coefficients, or analytic trigonometric relations. They do imply e(kappa_inv)>0 and e(kappa)>0 under the rational interpretation. The proof specializes the prepared clean entry to the fold, collapses it to C2, applies the coefficient-identification equation, uses slot2 of Uniform(H) in the prefix factor evaluator, and cancels the four inverse/square products. Its head is precisely `eval_e(P(H))*eval_e((N_D*N_f)*kappa)=eval_e(Ak3[0,0])`. Later interfaces substitute the finite contract's definitionally matching normalizer. This is one selected compressed prepared entry, not full normalized block equality and not equality of the unchanged active matrix with a prepared circuit.

The actual finite contract still refers to the active seven-gate semantics. Its theorem-facing transcript has ten labels: preparation, indicator, derivative rotation, boundary rotation, pre-SWAP transposed sparse access, indicator dagger, function, SWAP, sparse dagger, unpreparation. The active list instead uses ordinary forward sparse access, omits explicit indicator dagger and omits both preparation sides. Both printed SWAP labels are `Gate.swap 0 0`, whereas the supplied matrix acts on two n-bit blocks; label matching does not synthesize that full-space oracle. Seven labels, ten labels and one composite label are structural counts, not resource bounds.

The correction interface's `correctedFiniteBlockProjectionEquality` remains a SemanticObligation description/Bool, not even a fully typed equation specifying a corrected physical operator. The source gap therefore includes a separately stated full-space prepared operator and register lift; proof of its reduction to K(H) controlling off-diagonal/unused sectors; physical preparation/unpreparation and adjoint/inverse semantics; oracle amplitude/bound and indicator/garbage correctness; analytic real phase/trig/reciprocal interpretations; full normalized block equality, extraction and coherent control; declared query/logical/physical/finite-bit resource bounds. No default-zero completion, new final hypothesis or algorithmic repair has been invented. The refuted old raw fold is a refuted-contract node, not an open plausible supplier. Phase information is only the literal signs and named entries in coefficient matrices, not an established phase-equivalence theorem.

## W8. Full declaration disposition and future gates

The full677-declaration lossless inventory is a join key, not by itself a proof of reading. The complete distributed dispositions account for all bodies, including repeated private support arguments and long record/transcript proofs, rather than claiming every long conjunction is a new mathematical mechanism. The69 structures'1950 lexical fields/defaults retain literal bindings; actual nested target certificates are distinguished from Prop-valued data, Bool status and descriptive Strings. The11 ambient regions include namespace commands, the local recursion-depth option and both final closes, with no hidden ambient hypothesis introduced. Source-level binder classification retains data parameters, local support exclusions, exact conditional equations and internal proof ingredients; SOURCE means a literal local implementation antecedent, not an authenticated external-paper premise. Grouped matrix binders such as H,K remain data even where a predecessor's name extractor omitted them; their full signatures are authoritative.

The obligation map retains all563 lexical public declarations and114 private helpers. Generated recursors/projections/deriving exports are not an elaborated public inventory and remain a distinct gate. Source/construction AND topology is distinct from the three-module import graph and from elaborated proof terms. Equivalent wrappers and a different prepared object are not genuine same-contract OR alternatives. Independent whole-source review, formal decoding, transitive provider digestion, generated exports, compilation/TCB, historical attribution and publication bindings remain unassessed. There is no admission or PURIFIED claim.
