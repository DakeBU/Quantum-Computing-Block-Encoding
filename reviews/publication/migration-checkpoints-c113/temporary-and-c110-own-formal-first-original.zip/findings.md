# Independent findings and exact remaining interfaces

State: OWN_FORMAL_ONLY. Findings are independently reached from the permitted target/providers/context, compared with the prior SOURCE_ONLY record. No decoder, author characterization, compilation/test output, production raw source, or other review was ingested.

## F1. The literal helper mathematics matches the ideal local source branch

The five displayed theorem statements are mathematically consistent with the supplied literal definitions and Hadamard entries. The corrected coefficient is c times the zero-target embedding of alpha for both outcomes, c=sqrt(2)/2. Its branch norm-square is half the input coefficient norm-square, and the two branch masses sum to the input mass. The coefficient identity retains arbitrary complex relative phases and reference indices. This is a substantive local algebraic result, not merely a basis-probability assertion.

This finding is an independent mathematical reading, not evidence of successful Lean elaboration or proof-term/axiom auditing. No counterexample to any displayed helper statement was found by the exact hand derivation; no finite simulation was run.

## F2. No observed circular correctness hypothesis; literal branch specification is not operation realization

The only non-typing logical binder is inputMass(alpha)=1 in the explicitly normalized mass theorem. It is appropriate there. The branch identity and general half-mass theorem have no hidden supplied correctness premise. The six definitions are literal formulas, not choice/characterization objects or propositions asserting that a circuit already meets its goal.

At the same time, the corrected branch is specified directly as a sign times a matrix entry times alpha, with output t=0. Proving the formula simplifies correctly does not prove a concrete measurement/CZ/reset program denotes it. It would be inaccurate to call the helper itself circular; it would also be inaccurate to promote it, without a bridge, to actual source-circuit correctness.

## F3. The concrete Hadamard provider matters, but has a precise ceiling

The provider gives H=i Ry(pi/2) Rz(pi), not just an uninterpreted desired sign. Its supplied entry theorem and literal dependencies yield exactly the real Hadamard matrix, including the global-phase factor. This supports the helper's phase and scale calculation. However, a matrix row is not a destructive measurement instrument by declaration. It needs identification with the X outcome bra and appropriate Born/state-update and tensor-wire semantics.

The source kickmix model need not be extended with physical Hadamard/Ry/Rz gate operations merely because this mathematical representation uses H's row. A bra representation of measurement and a compiled gate implementation are different claims. The target does not prove either full operational interpretation.

## F4. Both outcomes and branch mass are preserved, with a finite-reference limit

Universal m covers both outcomes and the proof's finite cases cover all control/target labels. The 1/sqrt(2) factor has not been silently discarded. For finite R the exact mass equality includes arbitrary entangled finite reference states when interpreted in an orthonormal basis. The target also handles zero input, and normalized-mass specialization does not need nonzero division.

For arbitrary infinite R the coefficient identity is only pointwise; no physical state norm is defined. There is no target theorem for mixed density operators, independent classical outcome records, arbitrary adaptive histories, or partial trace. These may be mathematically transported from the stronger coefficient identity once explicit state/operator adapters are supplied; they are not already declared results in this packet.

## F5. Actual operations/composition remain unshown in the bounded inputs

The supplied target and provider regions contain no Toffoli action, use-preservation theorem, destructive-measurement instrument, actual CZ placement, reset operation, or adaptive program-composition theorem. This is a bounded-input observation, not a claim that such objects do not exist elsewhere. No new reading of raw modules was authorized to resolve them.

The following interfaces make the residual exact. They are mathematical supplier specifications, not proposed additional public hypotheses on a source-complete theorem:

1. **AND compute/use input.** Define the actual encoded input coefficients beta_alpha(r,a,b,s)=alpha(r,a,b) when s=andBit(a,b), otherwise zero. Prove the actual initial-zero Toffoli and concrete use interval reach that input form, allowing arbitrary effects on untouched/reference work while maintaining the predicate on retained controls.
2. **Destructive X branch.** For an arbitrary input table beta, identify the actual outcome-m branch on the retained registers with `sum_s H[m,s] beta(r,a,b,s)`, using the correct r/a/b wire order, outcome convention and Born masses. The current target only substitutes s=andBit(a,b) into a matrix entry; it does not prove this instrument formula.
3. **Actual conditional CZ.** Prove the actual gate/program selected by m multiplies retained amplitudes by conditionalCZSign(m,a,b), acts trivially on the reference, and is placed on the same controls. The literal sign definition is not the producer.
4. **Reset or discard endpoint.** Prove the actual zero-reallocation/reset sends a retained branch gamma to the table with gamma at t=0 and zero at t=1, OR state a different explicit discarded-wire endpoint. The current t-test specifies the former table but does not realize it physically.
5. **Program refinement/composition.** Combine the actual compute/use/X/conditional-CZ/reset denotations and register adapters to prove the actual branch equals correctedTemporaryAndBranch. Only then can correctedTemporaryAndBranch_eq discharge the corresponding source-circuit state-action obligation.
6. **State/mass/channel adapters.** Connect inputMass and branchMass with actual Hilbert norms and outcome probabilities, transport the pointwise identity through tensor-order/reference identifications, and if claimed derive the density-channel and independent-outcome-record statements. This should preserve the mass factor rather than replace Kraus branches by normalized states invisibly.
7. **Resource supplier.** If source-local one-Toffoli/Clifford cleanup is claimed, count the actual operation sequence and state how X measurement, CZ, classical control and reset are charged. No resource count follows from the displayed mass or coefficient theorems.

For a generic-f claim, additionally replace the AND column with a justified f-graph encoding and supply a real D_f correction and access/resource contract. That is not required to make this narrower AND helper true, and no generic-f theorem is claimed by the target. Earlier-history source m is likewise not formal m.

## F6. Provider and compiler trust boundaries remain intact

Five exact embedded formal regions were read, including the unused phaseMatrix definition, and their formal_text hashes were checked. Full raw provider files, original raw-region hashes, transitive imports and the mask's general correctness were not checked. The reported toolchain string is input metadata, not observed execution. The final #check/#print commands are not results and cannot establish compilation or axiom cleanliness.

## Scoped conclusion

The formal helper layer faithfully realizes the *ideal coefficient formula* in the frozen source mathematics, with correct scale, both outcomes and finite-reference mass accounting. The actual operation/composition layer needed to conclude the source's physical/circuit cleanup is not furnished by the authorized bounded material. No source error, defective literal helper, circular hypothesis, generic-f theorem, whole-program correctness or compiler acceptance is inferred. Independent topology review and final admission remain separate and ungranted.
