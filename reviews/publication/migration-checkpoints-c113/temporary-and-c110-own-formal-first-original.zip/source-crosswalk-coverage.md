# Exact formal/source crosswalk and bounded coverage

State: OWN_FORMAL_ONLY. Compare with the frozen SOURCE_ONLY derivation, manifest `a9642375a43c2b8698e60def51fbca7f47958479cc75306f8f60fa1e7f1cadd9`, seal `dddfc589403e962639008468f253c39dfb5cc5a7bf49b5a2d6c74dda13b28e47`. That packet is unchanged. Source anchor: [arXiv:2610.22367v1, physical page 9, Methods, Eqs. (11)-(13)](https://arxiv.org/pdf/2610.22367v1#page=9).

## All eleven target declarations

Names in this table use the common namespace ASPBE.Uncompute.MBU. Exact source signatures and line starts are in exact-interfaces.json.

| Declaration | Source/independent-math crosswalk | Exact boundary |
| --- | --- | --- |
| branchScale | The Kraus factor 1/sqrt(2) in the frozen derivation; the source's displayed arrows show conditional states. | This is sqrt(2)/2, not a normalized conditional-branch factor of 1. |
| andBit | The uv function in Eq. (11)/(12). | A literal function on labels, not a Toffoli gate or its execution. |
| conditionalCZSign | The sign (-1)^(new-outcome * uv) for the conditional CZ. | Literal sign formula, not an actual CZ denotation/placement theorem. |
| correctedTemporaryAndBranch | Desired corrected/reset branch on the AND-graph subspace: output coefficient is sign times X bra coefficient times alpha at t=0. | Contains no general input ancilla amplitude or actual measure/correct/reset composition. |
| correctedTemporaryAndBranch_eq | Exactly the frozen local identity L_outcome E_AND psi=J0 psi/sqrt(2), interpreted coefficientwise. | The target equates a specified coefficient formula with its simplification; identifying it with L_outcome and E_AND is an additional operation bridge. |
| branchScale_normSq | The factor yielding half input mass. | Scalar theorem, not a Born-rule theorem. |
| inputMass | Finite coefficient norm of the retained/reference state. | No physical-state datatype, normalization except when separately assumed, or infinite-reference norm. |
| branchMass | Squared norm of the specified corrected/reset output table. | Not a measurement instrument's probability unless that table is first identified with the actual branch. |
| correctedTemporaryAndBranch_mass | Every outcome has M/2 mass, matching the independent branch calculation. | Corrected branch norm only; no uncorrected measurement branch is separately defined in target. |
| outcomeMass_of_normalized | Source fair outcomes for normalized graph input. | The normalization binder is legitimate for this conditional mass conclusion; the physical-probability interpretation still needs the measurement bridge. |
| sum_branchMass | Both outcomes sum to the original mass, matching no-postselection cleanup. | Completeness on the alpha graph-input parametrization, not a channel theorem on arbitrary input ancillas. |

The target has six definitions and five theorem declarations. All are covered; no target declaration is discarded as irrelevant merely because it is not the final equality. The import, namespace delimiters and five final commands are separately covered in exact-interfaces.json. The final commands supply no outputs.

## Five provider regions, seven declarations

| Region | All declarations present | Interpretation/use |
| --- | --- | --- |
| PrimitiveMacros characters 0-1367 | hadamardMatrix; phaseMatrix; hadamardMatrix_apply | Hadamard concrete matrix and four-entry theorem matter to the target. phaseMatrix is completely read but unused by the target. The import/open lines give bounded ambient context only. |
| PrimitiveSemantics characters 493-612 | standardRyMatrix | Half-angle real rotation used in the concrete Hadamard definition. |
| PrimitiveSemantics characters 9540-9859 | standardRzMatrix | Half-angle complex diagonal rotation used in the Hadamard definition. |
| Robin/ComplexLCU characters 788-1040 | realOrthogonalRotation | Literal cosine/sine matrix with signs specified. |
| Robin/ComplexLCU characters 2290-2437 | realRotation | Inserts cosine/sine into the preceding literal matrix. |

All embedded formal_text hashes were recomputed and matched. The current_raw_sha256 and exact_raw_region_sha256 values are metadata only; the corresponding full raw files and original raw regions were not read or independently verified. Thus this crosswalk does not convert a masked region into a whole-module or imported-TCB audit.

## Complete bounded primary-source disposition relative to this target

The original source coverage has 35 page-9 regions and one reference-29 provenance row. They remain frozen. This table disposes all those IDs relative to the authorized formal material; it does not reclassify the source topology.

| Frozen source IDs | Formal disposition |
| --- | --- |
| P9-01,P9-08 | Headings only; not formal obligations. |
| P9-02 | General reversible embedding not implemented by this target. The andBit lookup is not that reversible embedding. |
| P9-03,P9-14 | Kickmix model attribution is context; no model-wide simulation/validity theorem in target. |
| P9-04 | Global coherent-action testing/simulation claim remains excluded from this local review. |
| P9-05,P9-06,P9-07 | Global cost proxies/TQ/search methodology remain excluded; no new resource result from these helper masses. |
| P9-09,P9-10 | Eq. (10)'s full permutation/phase/clean-ancilla V contract is not a target statement. |
| P9-11 | Output t=0 is built into the branch table, but zero-restoration as a physical operation is not proved. No measurement-is-unitary claim follows. |
| P9-12 | Target algebra is exact; no approximation theorem supplied. |
| P9-13 | No failure-budget or input-distribution theorem supplied; exact local helpers do not need failure allowances. |
| P9-15 | Toffoli label operation not present; andBit alone does not supply it. Other reversible gates are outside target. |
| P9-16 | Conditional CZ sign is present literally; an actual CZ gate object and composition bridge are not. Other sign gates are outside target. |
| P9-17 | A Hadamard row coefficient is present; destructive X instrument and wire destruction are not declared. |
| P9-18 | Arbitrary complex alpha generalizes basis-sign data mathematically; no classical simulator correctness theorem supplied. |
| P9-19 | Naming only; no formal obligation. |
| P9-20,P9-21,P9-27 | AND graph is implicit in H's andBit column; no computation from an initially zero target by actual Toffoli is proved. |
| P9-22 | No concrete use interval or maintained-use theorem exists in the bounded target/providers. |
| P9-23 | Direct second-Toffoli OR route is not implemented here. Its exclusion is scope, not a refutation. |
| P9-24 | No direct-route two-Toffoli resource count is proved. |
| P9-25,P12-29 | MBU/Gidney attribution is source provenance only; target formal input is not an external-paper proof. |
| P9-26,P9-35 | Defined branch masses are exactly half for normalized alpha; actual outcome/Born and released-wire restoration bridges remain. |
| P9-28 | The Hadamard matrix entry carries the right X-measurement phase and scale; no separate destructive instrument realization. |
| P9-29 | Zero sector is literal in F_m; actual reset/reallocation is not supplied. |
| P9-30 | Both conditional CZ sign cases cancel exactly in the helper equality; actual feedforward/CZ program composition remains. |
| P9-31 | No Clifford classification or one-Toffoli circuit count theorem is present. The local coefficient proof cannot discharge that resource claim. |
| P9-32 | Pointwise equality allows arbitrary complex reference-indexed coefficients. Finite mass sums retain finite reference correlations; no declared density/channel/tensor adapter. |
| P9-33,P9-34 | Target specializes to AND; arbitrary f, earlier history, and a general simulator relation are not target declarations. |

## Both-outcome and zero-sector checks

The equality and mass theorem universally quantify m:Fin 2, so they cover m=0 and m=1 without favorable-outcome selection. Both t=0 and t=1 are covered; t=1 vanishes. The final mass sum uses both outcomes. There is no dropped 1/sqrt(2), no extra normalization condition on the main identity, and no need for alpha to be real or factorized.

The target's representation is the unnormalized reset-branch table. The source's conditional branch arrows are compatible only after the mass/normalization interpretation is made explicit. Neither a tensor-order mapping nor a change from reset to discard is an invisible type equality: syntactically the target indexes reference,a,b,t, whereas the frozen source convention uses a,b,target,reference. A circuit-level adapter must fix physical tensor order.
