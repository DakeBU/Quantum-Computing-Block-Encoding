# C110 independent whole-formal interpretation

State: OWN_FORMAL_ONLY, before decoder exposure. This review was derived directly from the complete authorized target and five supplied formal provider regions, then compared with the reviewer's already frozen SOURCE_ONLY mathematics. It is not a blind decoder, compiler result, independent topology approval, or admission decision.

Target SHA-256: `26d7ed676f345a671d020e76078b0b866ff4364ca1632698d22027d3a9695be4`. Provider packet SHA-256: `44949d3be90570ef14296be294cb1062a2d8fda78b89b609a40dad3ee8a30ef3`. Context SHA-256: `249522b116ab0609b095c85b59f0bb5c720fbfd45b72910ca7ad5b2647ab4007`.

## 1. Ambient carriers and variable meanings

All eleven declarations are in `ASPBE.Uncompute.MBU`. Scalars are complex numbers. `Fin 2` has the two labels 0 and 1. `R : Type*` is an arbitrary reference-index carrier; the pointwise definitions/equality do not require it finite, inhabited, normed, or a Hilbert space. The three mass theorems and two mass definitions require `[Fintype R]`, meaning a finite enumeration for the coefficient sums. The code does not install a tensor/Hilbert/channel interpretation for these functions.

`alpha : R -> Fin 2 -> Fin 2 -> C` is an arbitrary complex coefficient table. The formal `r : R` is a reference index, NOT the new source measurement outcome. The formal `m : Fin 2` is the new measurement branch label, corresponding to source Eq. (12)'s r. Source Eq. (13)'s m is earlier classical history; this target has no earlier-history register. The formal a,b correspond to source u,v. The formal t indexes the OUTPUT zero-restored temporary qubit, not an arbitrary input target value.

If one supplies a finite orthonormal basis of a reference system, alpha can encode any pure state on reference,a,b, including arbitrary entanglement and complex relative phases. This reading is an external coefficient-space interpretation, not a target declaration. With infinite R, the pointwise theorem still holds for arbitrary functions, but no square-summability or normalized-state meaning follows.

## 2. Literal definitions

Write c=sqrt(2)/2, as a real coerced into C; q(a,b)=1 exactly when a=b=1, otherwise 0; and s_m(a,b)=-1 exactly when m=a=b=1, otherwise +1.

The output coefficient table is defined literally by

    F_m(alpha)(r,a,b,t)
      = if t=0 then s_m(a,b) H[m,q(a,b)] alpha(r,a,b) else 0.

This is a formula for an already corrected, zero-target branch. It does not accept a general input coefficient table indexed by the temporary qubit; no input-to-output measurement operation is defined here. The AND-graph input is selected through the column q(a,b), and the zero output is built into the t test. Neither property is established by a target theorem about a preceding compute/use program.

The two masses are literal finite sums:

    inputMass(alpha) = sum_(r,a,b) normSq(alpha(r,a,b)),
    branchMass(alpha,m) = sum_(r,a,b,t) normSq(F_m(alpha)(r,a,b,t)).

They are squared coefficient norms, not a reference to a measurement API or a separately declared Born-rule operator.

## 3. Supplied matrix meanings, independently expanded

Let O(cosine,sine) be the matrix with rows (cosine,-sine) and (sine,cosine). The supplied `realOrthogonalRotation` has exactly that entry definition. `realRotation(angle)` substitutes cos(angle),sin(angle). `standardRyMatrix(theta)` is realRotation(theta/2). `standardRzMatrix(theta)` is diagonal with cos(theta/2)-i sin(theta/2) on label 0 and cos(theta/2)+i sin(theta/2) on label 1.

The supplied Hadamard definition is

    H = i * (Ry(pi/2) Rz(pi)).

Writing c=sqrt(2)/2 gives Ry(pi/2)=((c,-c),(c,c)), Rz(pi)=diag(-i,i), and therefore H=((c,c),(c,-c)). The leading i is important: it removes the product's -i global factor and gives the exact real entries used by the target. The supplied `hadamardMatrix_apply` states these four entries and proves them by finite row/column cases, expansion, exact trigonometric values and i*i=-1.

This supplies a genuine concrete 2-by-2 matrix and its entry lemma. It does not supply a destructive X instrument, a qubit-reset operation, a tensor-wire placement or a circuit-composition theorem. Hadamard row m is mathematically the bra coefficient for the conventional X outcome m because its entries are real, but that operation interpretation remains a bridge.

The first provider region also includes `phaseMatrix(theta)=exp(i theta/2) * Rz(theta)`. It is diagonal by the supplied Rz definition, with entries given by the scalar factor times the two displayed Rz diagonal entries. Under the usual exponential/trigonometric identity these are 1 and exp(i theta). The target does not use phaseMatrix; neither its presence in a shared snippet nor a shared import makes it a target proof dependency.

There are five provider regions and seven provider declarations: realOrthogonalRotation, realRotation, standardRyMatrix, standardRzMatrix, hadamardMatrix, phaseMatrix and hadamardMatrix_apply. Only the masked formal regions were inspected. Full raw-provider hashes and raw-region hashes are packet metadata, not independently checked raw bytes. Every embedded formal_text hash was independently checked against its formal_region_sha256.

## 4. The five theorem meanings and proofs

### correctedTemporaryAndBranch_eq

For every R, alpha, m, r, a,b,t, the theorem states

    F_m(alpha)(r,a,b,t) = c * (if t=0 then alpha(r,a,b) else 0).

For t=1 both sides vanish. For t=0 and q=0, H[m,0]=c and s_m=+1. For t=0 and q=1, m=0 has H[0,1]=c,s_0=+1, while m=1 has H[1,1]=-c,s_1=-1. Thus both outcomes give c alpha. This is real sign cancellation using the supplied matrix-entry fact, not a premise that a circuit already acts correctly. The proof script enumerates the sixteen possibilities of m,a,b,t and simplifies; r and alpha remain arbitrary. No normalization premise is used.

### branchScale_normSq

The theorem states normSq(c)=1/2. The script reduces complex norm-square of a real coercion to its real square, obtains sqrt(2)*sqrt(2)=2 from nonnegativity of 2, and closes the polynomial equality. It does not establish any measurement rule on its own.

### correctedTemporaryAndBranch_mass

For all finite R, arbitrary alpha and both m,

    branchMass(alpha,m) = inputMass(alpha)/2.

The proof first sums over t. The equality theorem leaves only t=0, multiplicativity of norm-square separates c and alpha, and branchScale_normSq gives one half of each coefficient's norm-square. Factoring that scalar through the finite sums proves the result. This is uniform over the reference label and controls and includes zero tables and empty R. No extra correctness or normalization premise is used.

### outcomeMass_of_normalized

For finite R, arbitrary alpha satisfying h:inputMass(alpha)=1 and either m, the branchMass is 1/2. The proof substitutes the preceding mass theorem and h. The h binder is an explicit legitimate condition for a normalized mass statement, not an assumed implementation-correctness result. With empty R the premise cannot hold; no hidden nonempty assumption is present. Calling this a physical probability requires the operation/Born bridge, which is not a theorem here.

### sum_branchMass

For finite R and every alpha, the sum of branchMass over m=0,1 equals inputMass. The script expands the two-element sum, substitutes the half-mass theorem, and uses real arithmetic. This proves completeness of the two *defined coefficient branches* on the alpha carrier. It is not a trace-preservation theorem on arbitrary states of the retained controls plus an arbitrary target qubit.

## 5. Binding and proof-dependency audit

`R` and finite indexing are TYPING data; alpha is arbitrary mathematical input; Fin-2 indices are universal values. The normalized theorem's h is the precise SOURCE/TYPING-style normalization condition needed for that conditional mass conclusion. No declaration takes a Toffoli correctness theorem, measurement correctness theorem, phase-cancellation result, or reset/program-correctness proposition as a logical binder. There is no observed EXCESS correctness premise in these helper interfaces.

The main equality uses the literal four definitions and hadamardMatrix_apply. The mass theorem uses that equality, norm-square multiplicativity, the scalar norm fact and finite-sum arithmetic. The normalized and total-mass theorems use the mass theorem. These are explicit source-level proof references, not an elaborated compiler proof-term dependency graph. The mathematical evaluation is favorable for these literal helper statements; no compiler acceptance is asserted.

The definitions are literal, not characterized by a desired correctness property, choice-based objects or quotient representatives. Defining F_m as a particular corrected branch formula is legitimate. The absent step is a realization theorem identifying a concrete source operation sequence with F_m; it must not be manufactured by renaming F_m as a circuit semantics without justification.

## 6. Exact limit of the result

The supplied material supports an independently intelligible, source-compatible local coefficient helper and exact branch-mass algebra for AND. It has more content than a normalized phase-only truth table: it keeps the positive factor c, both outcomes, arbitrary complex reference-indexed coefficients, the zero output sector, and total mass.

However, no actual Toffoli compute, maintained-use invariant, destructive measurement instrument, CZ gate denotation/placement, conditional-control program, reset/reallocation operation, channel/density theorem or program-resource count appears in the target or five supplied regions. Their existence elsewhere is unassessed. Therefore the packet alone does not establish the actual operation/composition suppliers required by the frozen source reconstruction. The target also does not claim or prove generic-f Eq. (13), earlier-history behavior or a general Boolean correction oracle.

The final #check/#print axioms lines are source commands, not supplied outputs. The context reports a Lean toolchain string, but no toolchain execution or imported-module/TCB audit was authorized. This review cannot certify successful compilation, elaborated theorem types, inferred universe details beyond the displayed syntax, or an axiom inventory.
