# Phase 4: actual-decoder concordance with the already sealed own phase 2

## Result

CONCORDANT at the released mathematical and diagnostic scope. The same original formal-only decoder's actual addendum agrees with this reviewer's independently sealed phase-2 reconstruction of all 57 source roots, all 47 actual generated constants, their 104-owned partition, the source premises and seven semantic slots. No new root identity/privacy/universe/binder/phase/register/column/resource mismatch was found. This is not a final sourceAgreement/publication binding; updated v3 metadata has not been released in this stage.

Chronology is material. Own phase 2 was frozen at SHA `cc4a8c14af38f8bfccc8e600f37823e5e1147838675caa42bf27ffcc9ff344fc` before this actual-decoder release. Own phase 3 Rz repair review was then frozen at SHA `230065d2fec79f823c89ee466a1018cef50c3571caa8b9e0de7c74ab19280498` **before any file in this actual-decoder directory was opened**. That repair review is explicitly formal-exposed retrospective review, not a newly blind pre-proof source. Neither older review nor source-gap history was edited.

## Exact release and independent replay

The 19-file decoder allowlist is content eligibility, not a source/publication verdict. Its SHA is `e5bcbdb1bc94a1827b6e60b6e8565c14ef680ff44fa8ee31f8cde01390647d4c`; the decoder seal SHA is `88ea35b944e858606089cd725c8bd9bb8f6cfb7923bd2af8dc83b0bb8b7bb122`; its manifest SHA is `601648008ad676637dd0ddcdd04c9b760245f96ccfcc7be02bc8d7afc32a1a00`. All 16 manifest payload byte counts/digests were independently checked, and payload names plus manifest/seal/freeze equal the exact 19-name allowlist. No file outside that allowlist was opened in the decoder directory.

The decoder identifies itself as `real-preparation-decoder-c32-5d05b95f-26db-4691-ab3b-5aae22195a3f`, logical agent `/root/real_preparation_formal_decoder_c32`, consistent with the parent release of the same original decoder. Its source-blindness and no-execution history are recorded claims, not mechanically proven by identity strings or this content manifest. This reviewer does not impersonate that decoder or retrospectively certify real-world independence from a filename.

The full actual addendum, identity/count/source-context records and relevant technical material were read; the root/generated/Pi/cohort/resource/receipt JSON data were parsed and compared directly. Readable type-aid rewrites were not used as evidence in place of exact actual type text. Released decoder/runner/validator code was **not executed**. The reviewer-owned `phase4_audit.py` is a bounded read-only checker, using only the exact allowed decoder files and the same released raw/static/runtime ZIPs already inspected in phase 2. It performs no extraction, writes, Lean/native execution, Git, network or child delegation.

| Independent replay check | Result |
| --- | --- |
| Decoder root observations versus original C34_ROOT_JSON records, with static statement association | All 57 corresponding fields match; original static statements match inventory exactly. |
| Decoder generated observations versus original C34_GENERATED_JSON records | All 47 corresponding fields match. No suffix-predicted set substitutes for actual ownership. |
| Root Pi segments/conclusions | All 57 reproduced by balanced-delimiter top-level splitting after whitespace/universe-display normalization. Lexical, not a kernel Pi extractor. |
| Root universe vectors | All 57 empty vectors, as directly observed. Does not erase polymorphic imported applications. |
| Generated universe vectors | 26 empty; 17 `[u_1]`; 3 `[u]`; 1 seven-parameter vector `[u_3,u_9,u_10,u_11,u_15,u_16,u_17]`. |
| Privacy | 4 private source roots, 16 private generated constants, exact raw actual names/API user mappings retained. |
| Ownership/counts | 85/11/8 owned constants for A/E/G, hence 57+47=104; no local structures or hidden target fields. |
| Actual parser candidate headers | 220 unique rows, matching candidate path/source byte count/SHA fields without parse errors. |
| Independently traversed project import closure | 37 modules = 3 targets + 34 inherited project providers, same postorder and full external import records as decoder. |
| Provider-copy receipts | Exact inherited-provider set, equal source/destination hash receipts before/after, and matching absent-sidecar records. Not provider byte rehash/rebuild. |
| Child processes and resources | 10 distinct child PIDs, correct commands/caps/serial flags, no overlapping child execution intervals, 20 pre/post resource snapshots matching raw data. |
| Technical receipt objects | All 9 decoder technical receipt objects equal their corresponding sanitized raw JSON objects. |

The new decoder gives additional *diagnostic detail*, not a conflicting mathematical reconstruction. In particular, its exact Pi/private/universe records refine the earlier static source-only observation layer. This review independently confirms that refinement against the original raw stream rather than trusting the decoder's own `comparisons` booleans.

## Mathematical concordance and common-blind-spot audit

The following findings are compared against this reviewer's own already sealed source/formal analysis, not inferred from a parent aggregate acceptance result:

- Actual RAP firstColumn retains all-width pointwise nonnegativity and positive actual square sum. Its separate normalization lemma requires only positive square sum; flat wrappers retain strict pointwise positivity. The total circuit and unitary/count definitions do not silently acquire normalized action for zero or negative singleton tables. The zero-width exact-phase signed strengthening remains REFUTED, not a newly supplied decoder theorem.
- Actual RY uses the physical half angle, signed splitAngle has a radius-zero branch and the b-sign arccos branch, and old-wire lifting preserves wire labels. The generation of a rational-zero angle versus a real zero is not a different matrix action. No phase quotient, relative-sign deletion or probability-only substitution appears.
- Actual E completion remains an existential O/SO statement for arbitrary injective physical positions with the stated isometry/spare conditions. Its proof-local zero extension is not a zero-filled output completion; it does not assert uniqueness or arithmetic cost.
- Actual G completion remains a fixed exact-real matrix producer on supplied real chain data. Recursive RightCanonical is actual local row orthonormality; maxBond includes boundaries; t<n remains substantive; only occupied clean input columns are promised, and every output bond label is covered. The conclusion is the original complex paddedAt entry after exact embedding, not an unexplained real-part surrogate or whole-state success assumption.
- F's elimination/permutation producer and E's basis-extension existence are alternative sufficient completion routes, not a false conjunction or interchangeable algorithm certificates. Imported existential circuit bounds do not automatically give a gate list/resource theorem for the particular G producer, and local correctness is not global physical placement.
- The natural H0 inverse-ell direction matches actual localIndex pointwise; the fresh-zero numerical clean-column substitution remains correct. This is coordinate reindexing, not a SWAP instruction, free routing or the missing assembly use-site/global placement proof.

Seven-slot agreement: normalized target contracts match; real/complex carriers, dimensions and endian/output-row/input-column order match; access/inverse/control promises are not strengthened; ancillas/workspace/clean and passive sectors remain separate; exact signs and global-phase boundaries match; exact error/success tier has no new postselection loss or numerical guarantee; reference syntactic resource counts remain distinct from exact-real producer evaluation and finite-bit/global gate costs.

The v3 Rz clarification was independently accepted in phase 3 before this decoder reading. It defines the already released formal minus/plus-i-sin diagonal convention explicitly without changing code or the RY/CX tree. The decoder remained a formal-only reader and did not independently approve the natural v3 repair. Its mathematical Rz interpretation is compatible, but this stage does not pretend the decoder read the repaired source or supplied a fresh v3 source verdict.

Common blind spots were explicitly checked: a shared implicit endian conversion, moving a proof ingredient into a public theorem premise, using inactive/dirty inputs as if clean, dropping a negative amplitude/global phase, treating spare columns as free ancillas, assigning the imported existential cubic bound to the chosen producer, and treating query count zero as free preprocessing. None was discovered as a new actual source/formal mismatch. The two readers still share the same raw collector/toolchain/provider trust boundary; agreement is not an independent all-TCB audit or novelty result.

## Resource/process and context concordance

The actual child PIDs are `[10860,10864,10975,10989,11004,11017,11036,11051,11062,11069]`, all under recorded wrapper PID 10859. Every native child exits 0 without timeout, uses `--threads=1 --memory=5120`, and only the three target compiles add `-DElab.async=false`. Direct stage-time parsing confirms preflight end <= child start <= child end <= postflight start and nonoverlapping child intervals. The first child start to last child end is 832.206680 seconds; it is not the sum of native child wall times and is not global host exclusivity.

All 20 snapshots record the same current run/job context, 5120 MiB budget plus 2048 MiB reserve and threshold 7,516,192,768 bytes. The independently recomputed minimum effective headroom is 15,279,939,584 bytes. Both nonroot cgroups are explicitly observed `max`, not silently assumed unlimited from missing files; their recorded events are zero. The recognized true root's memory interfaces are separately recorded as documented not applicable, no requested read/value/unlimited observation. PID1 was explicitly not requested. These distinctions agree with the decoder and preserve the inherited self-namespace recognition/procfs assumptions.

Neither reader claims an OS-enforced per-process 5120 MiB limit, continuously reserved headroom, PID-attributed OOM proof, kernel binary attestation or complete remote filesystem/mount reconstruction from redacted paths. The current finite Lean memory flag and measured boundary snapshots are the evidence, not a stronger hidden policy.

Runtime context remains `a12a5eb7fe33514a63f04ed3372ee03f0ee9e145`; the API/head `f0d67e84a6a66766d360e21ff6cf97469819af67` is different and parent-attributed. The merge-parent/tree explanation is retained as attributed metadata, not an own API/Git query, executed-checkout attestation or dynamic-load trace. Original raw-stream and sanitized-member hashes remain distinct; neither reader rehashed unavailable original private raw bytes. Fresh target `.olean` paths/receipts do not mean those remote `.olean` bytes are embedded in the public ZIP for a new local rehash. The 34 providers remain inherited, not freshly compiled in this target cohort.

## Residual gaps, outcome and stop

The only source-gap status changed in phase 3 is `RZ-NATURAL-SPEC`: resolved in v3's natural text, with earlier records unchanged. Phase 4 discovers no new contradictory mathematical target or excess public assumption. The signed-all-width route remains REFUTED; all other genuine structured/boundary/local-compilation/global-placement/finite-bit-cost suppliers remain OPEN. Actual ordinary value text was not requested; explicit pp types/Pi text are not lossless Expr serialization; collectAxioms/ConstantInfo metadata and inherited compiled providers do not constitute all imported/native TCB proof-body review. No such closure or ordinary-body printing is added by decoder concordance.

Failure class for this bounded phase-4 comparison: NONE. The earlier sharply typed negative witness and source-to-formal mappings are preserved. The packet merits the limited judgment **mathematical and actual-diagnostic concordance**, not final accepted publication/source binding, native/scientific root acceptance, main admission, Exposition Seal or PURIFIED.

The next authorized boundary is an independently reviewed v3 metadata/final-comparison release if the parent requests it. This stage must not manufacture that metadata or an acceptance wrapper. Freeze the new phase-3/4 allowlist and seal, preserve every prior artifact, and STOP.
