"""Read-only comparison of the released decoder packet with raw observations.

No released decoder/runner code is executed; no file is written. CLI arguments
are decoder directory, actual ZIP, static ZIP, runtime ZIP, in that order.
"""
import collections
import datetime
import hashlib
import json
import pathlib
import sys
import zipfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def when(text):
    return datetime.datetime.fromisoformat(text.replace("Z", "+00:00"))


def squash_universes(text):
    result = []
    i = 0
    while i < len(text):
        if text.startswith(".{", i):
            depth = 1
            i += 2
            while depth:
                if text[i] == "{":
                    depth += 1
                elif text[i] == "}":
                    depth -= 1
                i += 1
        else:
            result.append(text[i])
            i += 1
    return " ".join("".join(result).split())


def pi_segments(text):
    text = squash_universes(text)
    stack = []
    start = 0
    parts = []
    for i, char in enumerate(text):
        if char in "([{":
            stack.append(char)
        elif char in ")]}":
            assert stack.pop() == {")": "(", "]": "[", "}": "{"}[char]
        elif not stack and char in "→,":
            parts.append(text[start:i].strip())
            start = i + 1
    assert not stack
    return parts, text[start:].strip()


def main():
    directory = pathlib.Path(sys.argv[1])
    allowed_bytes = (directory / "publicsafe-allowlist.json").read_bytes()
    allowed = json.loads(allowed_bytes)["allowed"]
    assert len(allowed) == len(set(allowed)) == 19
    assert all(pathlib.Path(name).name == name for name in allowed)

    def data(name):
        assert name in allowed
        return (directory / name).read_bytes()

    def doc(name):
        return json.loads(data(name))

    manifest_bytes = data("hashmanifest.json")
    assert sha(manifest_bytes) == "601648008ad676637dd0ddcdd04c9b760245f96ccfcc7be02bc8d7afc32a1a00"
    assert sha(data("seal.json")) == "88ea35b944e858606089cd725c8bd9bb8f6cfb7923bd2af8dc83b0bb8b7bb122"
    manifest = json.loads(manifest_bytes)
    for row in manifest["files"]:
        payload = data(row["path"])
        assert len(payload) == row["bytes"] and sha(payload) == row["sha256"]
    assert set(allowed) == {row["path"] for row in manifest["files"]} | {"hashmanifest.json", "seal.json", "freeze.json"}

    with zipfile.ZipFile(sys.argv[2]) as actual, zipfile.ZipFile(sys.argv[3]) as static, zipfile.ZipFile(sys.argv[4]) as runtime:
        def raw(name):
            matches = [member for member in actual.namelist() if member.endswith("/" + name)]
            assert len(matches) == 1
            return actual.read(matches[0])

        def remote(name):
            return json.loads(raw(name))

        def events(name):
            found = collections.defaultdict(list)
            for line in raw(name).decode().splitlines():
                tag, content = line.split(" ", 1)
                found[tag].append(json.loads(content))
            return found

        stream = events("30-observe.stdout.raw.sanitized.txt")
        inventory = {row["id"]: row for row in json.loads(static.read("inventory.json"))}
        roots = doc("actual-roots.json")
        generated = doc("actual-generated.json")
        ignored_acceptance = {"nativeAccepted", "sourceAgreement", "publicationBinding", "scientificAcceptance", "axiomPolicyPass", "trustClosure"}
        for output, original, root in ((roots, stream["C34_ROOT_JSON"], True), (generated, stream["C34_GENERATED_JSON"], False)):
            assert len(output) == len(original)
            for new, observed in zip(output, original):
                expected = {key: value for key, value in observed.items() if key not in ignored_acceptance}
                assert all(new[key] == value for key, value in expected.items())
                if root:
                    assert new["static_source_statement"] == inventory[new["sourceUserName"]]["statement_source"]
                    assert new["static_semantic_record"] == inventory[new["sourceUserName"]]["semantic_record"]
        spines = doc("actual-pi-spines.json")
        assert len(roots) == len(spines) == 57 and len(generated) == 47
        for root, spine in zip(roots, spines):
            parts, conclusion = pi_segments(root["typePrettyExplicit"])
            assert root["sourceUserName"] == spine["source_name"]
            assert root["universeParameters"] == spine["universe_parameters"] == []
            assert parts == spine["leading_pi_segments"] and conclusion == spine["conclusion_text"]
        counts = doc("observed-counts.json")
        assert counts["tags"] == {key: len(value) for key, value in stream.items()}
        universe_histogram = dict(collections.Counter(str(row["universeParameters"]) for row in generated))
        assert universe_histogram == counts["generated_universe_counts"]
        assert sum(row["actualPrivate"] for row in roots) == 4
        assert sum(row["actualPrivate"] for row in generated) == 16
        assert all(row["userNameViaActualAPI"] == row["sourceUserName"] for row in roots)

        imports = events("04-parser-observe.stdout.raw.sanitized.txt")["C34_IMPORTS_JSON"]
        import_map = {row["module"]: row for row in imports}
        assert len(import_map) == len(imports) == 220
        candidate_map = {row["module"]: row for row in json.loads(runtime.read("candidate-sources.json"))["files"]}
        assert set(candidate_map) == set(import_map)
        for name, row in import_map.items():
            assert all(row[key] == candidate_map[name][key] for key in ("relativePath", "sha256", "bytes"))
            assert not row["hasParseErrors"] and row["parseMessages"] == 0
        targets = [row["module"] for row in stream["C34_BINDING_JSON"]]
        postorder, busy = [], set()

        def visit(name):
            if name in postorder:
                return
            assert name not in busy
            busy.add(name)
            for edge in import_map[name]["imports"]:
                if edge["module"] in import_map:
                    visit(edge["module"])
            busy.remove(name)
            postorder.append(name)

        for target in targets:
            visit(target)
        providers = [name for name in postorder if name not in targets]
        cohort = doc("independent-import-cohort.json")
        assert postorder == cohort["project_closure"] and providers == cohort["providers"]
        assert len(providers) == cohort["provider_count"] == 34
        assert cohort["parser_source_bindings"] == [{"module": name, "sha256": import_map[name]["sha256"]} for name in postorder]
        assert cohort["external_import_edges"] == [{"owner": name, "imports": [edge for edge in import_map[name]["imports"] if edge["module"] not in import_map]} for name in postorder]
        copies = remote("provider-copies.json")
        for observed, decoded in zip(copies["files"], cohort["provider_copy_checks"]):
            assert observed["sourceRealPath"] == decoded["source"] and observed["destinationRealPath"] == decoded["destination"]
            assert observed["sha256"] == decoded["sha256"]
            assert all(observed[key] == observed["sha256"] for key in ("sourceSHA256Before", "sourceSHA256After", "destinationSHA256Before", "destinationSHA256After"))
        assert len(copies["files"]) == len(cohort["provider_copy_checks"])
        assert copies["absentSidecars"] == cohort["absent_sidecars"]
        copied_names = {row["destinationRealPath"].split("/cohort/")[1][:-6].replace("/", ".") for row in copies["files"] if row["destinationRealPath"].endswith(".olean")}
        assert copied_names == set(providers)

        resource_packet = doc("independent-resource-processes.json")
        all_headrooms, pids, previous_end = [], [], None
        first_start = None
        for stage in resource_packet["stages"]:
            name = stage["label"]
            invocation = remote(name + "-invocation.json")
            setup = remote(name + ".setup.json")
            result = remote(name + ".result.json")
            started = remote(name + ".started.json")
            observation = remote("ci2-" + name + ".observation.json")
            assert stage["argv"] == invocation["argv"] == setup["argv"] == observation["requestedArgv"] == observation["actualArgv"]
            assert stage["pid"] == result["PID"] == started["PID"]
            assert result["exitCode"] == 0 and not result["timedOut"]
            assert stage["wrapper_pid"] == invocation["wrapperPID"] == 10859
            assert when(stage["result"]["startedUTC"]) == when(result["startedUTC"])
            assert when(stage["result"]["finishedUTC"]) == when(result["finishedUTC"])
            assert stage["result"]["wallSeconds"] == result["wallSeconds"]
            assert stage["timeout_seconds"] == invocation["timeoutSeconds"] == setup["timeoutSeconds"] <= stage["cap_seconds"]
            assert invocation["argv"].count("--memory=5120") == invocation["argv"].count("--threads=1") == 1
            assert invocation["argv"].count("-DElab.async=false") == int(name in ("11-target", "12-target", "13-target"))
            for which, suffix in (("pre", "preflight"), ("post", "postflight")):
                snapshot = remote("ci2-" + name + "." + suffix + ".json")
                decoded = stage[which]
                assert snapshot["observationComplete"] and snapshot["gatePassed"]
                assert decoded["effective_headroom"] == snapshot["effectiveHeadroomBytes"]
                values = [snapshot["memAvailableBytes"]]
                for group, exported in zip(snapshot["cgroups"], decoded["cgroups"]):
                    assert exported["logical_path"] == group["logicalPath"]
                    assert exported["limit_raw"] == group["memoryMaxRaw"]
                    assert exported["current"] == group["memoryCurrentBytes"]
                    assert exported["headroom"] == group["headroomBytes"]
                    assert exported["events"] == group["memoryEvents"]
                    assert all(value == 0 for value in group["memoryEvents"].values())
                    if not group["limitUnlimited"]:
                        values.append(group["memoryMaxBytes"] - group["memoryCurrentBytes"])
                assert min(values) == snapshot["effectiveHeadroomBytes"] >= 7168 * 1024 ** 2
                assert decoded["namespace"] == snapshot["namespaceObservation"]
                assert not decoded["namespace"]["pid1Observation"]["readRequested"]
                assert decoded["observed_context"] == snapshot["context"]
                assert decoded["root_memory_interface_state"] == snapshot["rootObservation"]["type"] == "DOCUMENTED_TRUE_ROOT_NOT_APPLICABLE_NOT_UNLIMITED"
                assert all(not item["readRequested"] and not item["unlimitedObserved"] for item in snapshot["rootObservation"]["memoryInterfaces"].values())
                all_headrooms.append(snapshot["effectiveHeadroomBytes"])
            assert when(stage["pre"]["finished_utc"]) <= when(result["startedUTC"]) <= when(result["finishedUTC"]) <= when(stage["post"]["started_utc"])
            assert previous_end is None or previous_end <= when(result["startedUTC"])
            previous_end = when(result["finishedUTC"])
            if first_start is None:
                first_start = when(result["startedUTC"])
            pids.append(result["PID"])
        assert len(set(pids)) == len(pids) == 10 and len(all_headrooms) == 20
        technical = doc("technical-receipts.json")
        assert all(content == remote(name) for name, content in technical.items())
        result = {
            "decoderPayloadManifestChecks": 16,
            "decoderAllowedFiles": 19,
            "rootsEqualActualRawRecordsPlusMatchingStaticStatements": 57,
            "generatedEqualActualRawRecords": 47,
            "lexicalPiSpinesReproduced": 57,
            "rootUniverseVectors": "57 empty vectors",
            "generatedUniverseVectors": universe_histogram,
            "privateRoots": 4,
            "privateGenerated": 16,
            "candidateHeaders": 220,
            "targetPlusProjectProviderClosure": len(postorder),
            "inheritedProjectProviders": len(providers),
            "tenUniqueChildPIDs": pids,
            "prePostSnapshotsChecked": len(all_headrooms),
            "minimumObservedHeadroomBytes": min(all_headrooms),
            "firstStartToLastEndSeconds": (previous_end - first_start).total_seconds(),
            "technicalReceiptObjectsEqualRaw": len(technical),
            "runtimeSHA": "a12a5eb7fe33514a63f04ed3372ee03f0ee9e145",
            "ordinaryValueTextOrCompleteTCBAdded": False,
            "sourceAgreement": None,
            "publicationBinding": None,
        }
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
