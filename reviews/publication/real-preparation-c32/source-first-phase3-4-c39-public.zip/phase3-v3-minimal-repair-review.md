# Phase 3: independent minimal natural-source repair review

## Judgment and chronology

ACCEPT the exact-scope v3 Rz clarification as a necessary convention clarification for the named four-kind instruction language and a sufficient minimal repair of `RZ-NATURAL-SPEC`. It does not repair a false amplitude-tree theorem: the generic one-qubit lifting argument and the RY/CX-only tree were already valid without specifying this Rz convention.

This reviewer has already seen the released formal context in sealed phase 2. Consequently this is a **formal-exposed retrospective repair review**, not a new blind/source-first extraction, historical pre-proof source, independent historical account, or final source/formal publication binding. The source author is `/root`; historical formalizer remains UNKNOWN. The old natural sources, phase-1/v2 reviews, and phase-2 gap records are immutable history, not silently rewritten.

This phase is sealed **before reading the newly released actual-decoder addendum**. Only the three allowed v3 files, the preceding v2 natural source for literal comparison, and this reviewer's already-held mathematical/formal knowledge were used. No actual-decoder addendum, author classification graph/registry/private coverage, new native execution, Git, network, or subagent was used in phase 3.

## Bound inputs and exact difference

| Input | SHA-256 |
| --- | --- |
| `clarification-v3/source-effective-v3.md` | `dba646110300c6a8e9f8b275eeb0dba2140add2a9f0096934f03a51e886da6cd` |
| `clarification-v3/source-change-record-v3.json` | `2e5757956c688e25145f839224d6db0d6a81f817ebbf2ab8a0abc7753450fd0c` |
| `clarification-v3/author-seal-v3.json` | `0fe8eca0428fc4bfe8c39d932fe77a14a9ced5387346b6bf91bfa1bf55926df7` |
| preceding `clarification-v2/source-effective-v2.md` | `936020bf35582267a8149ed49addd9a9b106c23512205acaf49e9a3febaa6d80` |
| this reviewer's preceding phase-2 seal | `cc4a8c14af38f8bfccc8e600f37823e5e1147838675caa42bf27ffcc9ff344fc` |

All three v3 inputs were fully read and their digests checked. A read-only ordinal text check found exactly one occurrence of the declared `before` paragraph; applying the declared replacement to v2 gave the complete v3 text exactly. Thus all old A2 prose and all of A1/B/C/D/E/F/G/H/I are unchanged. The actual added material is only one A2 Rz matrix/convention paragraph and its displayed formula. Assertions inside the author's change record were not treated as proof of production-code or private-record immutability.

## Independent mathematical derivation

For real theta put c=cos(theta/2), s=sin(theta/2). The new source defines the literal complex matrix

\[
R_z(\theta)=\begin{pmatrix}c-is&0\\0&c+is\end{pmatrix}.
\]

It is total for every real angle. Since c,s are real and c²+s²=1, conjugating either diagonal entry changes its sine sign, and each squared modulus is one. Thus Rz dagger times Rz is I. Its determinant is (c-is)(c+is)=c²+s²=1. Its inverse is Rz(-theta), with the same ordered basis labels. There is no quotient or representative choice hidden in these literal entries.

Euler's elementary identity gives the equivalent diagonal exp(-i theta/2),exp(+i theta/2). The sign order is important: output/input bit zero gets the minus sign and bit one the plus sign. The off-diagonal-zero statement excludes mixing the two basis bits. The source's angle remains the physical theta, not theta/2 stored as a new instruction parameter. Both matrix axes remain output-row/input-column, and no transposition or complex conjugation is applied by instruction lifting.

For named target wire t, the ordinary one-qubit kernel is

\[
\delta_{\operatorname{context}_t(x),\operatorname{context}_t(y)}
 (R_z(\theta))_{x_t,y_t}.
\]

Appending an untouched highest wire conjoins equality of that wire to the old context equality. This is precisely the preceding arbitrary one-qubit matrix lifting proof. Substituting this Rz matrix requires no new theorem premise, clean ancilla, oracle access, sign assumption, or resource result. In the already released formal source, `standardRzMatrix` has these same ordered cos-minus/plus-i-sin entries and zero off-diagonal entries; `liftGate` keeps the same angle, and `lift_oneQubit` works for arbitrary complex 2-by-2 matrices. The comparison is based on that prior formal exposure, explicitly not a claim that the newly completed natural convention was historically independent of it.

### Exact discriminators

- theta=0 gives I, so the added convention has the expected identity case.
- theta=pi gives diag(-i,+i), while diag(1,exp(i pi))=diag(1,-1). These matrices differ by the nontrivial scalar i and are **not equal entrywise**. Therefore the source's warning against silently replacing the former by the latter is mathematically justified.
- theta=2pi gives Rz=-I, while diag(1,exp(i 2pi))=I. This is a direct exact-phase counterexample to treating the two conventions as interchangeable or reducing the literal matrix angle modulo 2pi without tracking phase.
- Reversing the sine signs gives Rz(-theta). At theta=pi/2 its diagonal ratio is the inverse of the intended relative phase, so even equality merely up to a common phase would generally fail. The source has the correct direction relative to the already released formal definition.

No counterexample to the actual proposed formula or its lifting claim was found. The counterexamples refute the tempting alternative conventions, not the v3 repair or any original principal theorem.

## Necessity, sufficiency and minimality

Necessity is scope-specific. The word “z-rotation” alone does not mathematically force one phase convention: different parameterizations and global-phase variants exist. A literal whole-language source contract must therefore choose its matrix, or explicitly declare an equivalence relation. The original source declares exact phase and includes Rz among lifted instructions but did not choose that formula. Specifying it removes that underdetermination. Such a clarification was not needed to prove the arbitrary-matrix lifting identity or the RY/CX-only amplitude tree.

The new formula is sufficient: both diagonal entries, both zero off-diagonal entries, angle meaning, exact-versus-global-phase boundary, and unchanged-target lift are explicit. No additional assumptions on theta are required. It agrees with the already released formal convention without changing the underlying formal code or asking the source theorem to assume a desired implementation result.

The repair is semantically minimal, not a claim of shortest prose or a uniquely possible repair. It inserts the missing standing convention and explanatory exclusions only. It does not alter any D/E/F/G theorem binder, target, phase, domain, rank/column placement, angle table, instruction count, or source-construction topology. It adds no Rz instruction to `prepareCircuit`, which remains the same RY/CX recurrence. There is no new state-preparation algorithm, runtime certificate, finite-bit supplier, or repaired scientific target.

## Coverage and seven-slot delta

| New region | Disposition |
| --- | --- |
| Real-angle introduction and displayed diagonal formula | NODE V3-A2-RZ-LITERAL: literal total complex matrix, ordered minus/plus signs. |
| Off-diagonal-zero and exact-phase exclusion | NODE V3-A2-RZ-PHASE: full entry definition and distinction from diag(1,exp(i theta)). |
| Same-angle/old-target instruction lift and generic-matrix application | NODE V3-A2-RZ-LIFT: instance of the existing context-preserving one-qubit lifting node. |
| No Rz added to the later tree | NODE V3-A2-RZ-NONUSE: unchanged construction alphabet and count frontier. |
| Formula delimiters/blank lines | EXCLUDED: formatting only. |

Seven-slot effect: targets/normalization unchanged; dimensions/basis/order unchanged; oracle/access/control unchanged; ancillas/workspace unchanged; **only the previously unspecified auxiliary Rz phase convention is made literal**; error/success unchanged; resources unchanged. Exact phase as a global policy is retained, not weakened. The Rz entry definition is a STANDING language convention and literal definition, not an extra public theorem assumption or unique-characterization/choice construction.

`RZ-NATURAL-SPEC` is resolved **for v3's natural source**. Its historical v1/v2/phase-2 appearances are not erased. H0 assembly use-site/physical global placement, boundary preparation, structured function-to-chain and approximation suppliers, finite-bit angle/zero-sign/cost/readout issues, inherited providers, absent ordinary-value text, nonlossless pretty Expr and incomplete native TCB/procfs audit all remain. The unchanged signed all-width strengthening remains REFUTED at width zero. No sourceAgreement, native acceptance, publication binding, main admission or PURIFIED state is supplied by this repair.

Current repair-review failure class: NONE. The exact alternative-convention witnesses are salvageable phase discriminators; no original mathematical route is retired. This phase emits only a source-repair judgment and its seal. Phase 4 may start only after that seal is written and hashed; any final v3 publication binding remains a later authorized stage.
