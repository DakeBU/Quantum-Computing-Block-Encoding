"""Read-only ZIP discriminator for this independent phase-2 review.

Arguments identify the released static, runtime and actual ZIPs. No ZIP member
is extracted, imported, executed or written. This is not a Lean verifier.
"""
import collections
import hashlib
import json
import re
import sys
import zipfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def get_member(archive, suffix):
    matches = [name for name in archive.namelist() if name.endswith(suffix)]
    assert len(matches) == 1, (suffix, len(matches))
    return archive.read(matches[0])


def main():
    static_path, runtime_path, actual_path = sys.argv[1:4]
    out = {"scope": "read-only syntax, bytes, and raw-observation consistency; not native execution"}
    for label, path in zip(("static", "runtime", "actual"), sys.argv[1:4]):
        with open(path, "rb") as handle:
            out[label + "ZipSHA256"] = digest(handle.read())
    with zipfile.ZipFile(static_path) as static, zipfile.ZipFile(runtime_path) as runtime, zipfile.ZipFile(actual_path) as actual:
        out["actualMemberCount"] = len(actual.namelist())
        out["inputMembers"] = {}
        for archive, member in ((static, "formal-context.md"), (static, "supplemental-formal-context.md"),
                                (static, "inventory.json"), (static, "reconstruction.md"),
                                (runtime, "Collector.lean"), (runtime, "profile.json"),
                                (runtime, "pending-drivers/Profile.lean")):
            out["inputMembers"][member] = digest(archive.read(member))
        formal = static.read("formal-context.md").decode("utf-8").replace("\r\n", "\n")
        inventory = json.loads(static.read("inventory.json"))
        profile = json.loads(runtime.read("profile.json"))
        roots_key = next(key for key, value in profile.items() if isinstance(value, list) and len(value) == 57)
        profile_roots = profile[roots_key]
        assert {row["id"] for row in inventory} == {row["sourceUserName"] for row in profile_roots}
        parsed = []
        modules = []
        for item in profile["modules"]:
            module = item["module"]
            path = module.replace(".", "/") + ".lean"
            section = formal.split("## " + path + "\n", 1)[1].split("\n## ", 1)[0]
            code = section.split("```lean\n", 1)[1].split("\n```", 1)[0]
            hash_matches = [variant for variant in (code, code + "\n", code + "\n\n")
                            if digest(variant.encode()) == item["rawSHA256"]]
            assert len(hash_matches) == 1, path
            code = hash_matches[0]
            declaration_pattern = r"(?m)^(?:@\[[^\n]*\]\s*)?(private\s+)?(?:noncomputable\s+)?(def|theorem)\s+([A-Za-z_][A-Za-z0-9_]*)"
            declarations = list(re.finditer(declaration_pattern, code))
            for declaration in declarations:
                parsed.append({"id": module + "." + declaration[3], "private": bool(declaration[1]), "kind": declaration[2]})
            modules.append({"module": module, "sourceSHA256": item["rawSHA256"], "sourceRoots": len(declarations),
                            "privateRoots": sum(bool(declaration[1]) for declaration in declarations)})
        assert {row["id"] for row in parsed} == {row["id"] for row in inventory}
        raw = get_member(actual, "/30-observe.stdout.raw.sanitized.txt")
        events = collections.defaultdict(list)
        for line in raw.decode().splitlines():
            tag, content = line.split(" ", 1)
            assert tag.startswith("C34_") and tag.endswith("_JSON")
            events[tag].append(json.loads(content))
        bindings = events["C34_BINDING_JSON"]
        roots = events["C34_ROOT_JSON"]
        generated = events["C34_GENERATED_JSON"]
        assert len(roots) == 57 and len(generated) == 47 and len(bindings) == 3
        assert {row["sourceUserName"] for row in roots} == {row["id"] for row in parsed}
        source_by_id = {row["id"]: row for row in parsed}
        assert all(row["actualPrivate"] == source_by_id[row["sourceUserName"]]["private"] for row in roots)
        assert all(row["actualKind"] == ("defnInfo" if source_by_id[row["sourceUserName"]]["kind"] == "def" else "thmInfo") for row in roots)
        all_constants = roots + generated
        names = [row["actualName"] for row in all_constants]
        assert len(set(names)) == len(names)
        for binding in bindings:
            owned = {row["actualName"] for row in all_constants if row["module"] == binding["module"]}
            assert owned == set(binding["ownedNames"])
            assert len(owned) == binding["ownedCount"]
            assert all(row["ownerModuleIndex"] == binding["ownerModuleIndex"] for row in all_constants if row["module"] == binding["module"])
        assert all(row["observationSource"] == "KERNEL_CONSTANT_INFO" for row in all_constants)
        assert all(row["kernelTypeAndUniversesAgree"] and row["kernelElaborationValueExprAgree"] for row in all_constants)
        assert all(not row["isUnsafe"] and not row["actualAxiomInfo"] and not row["actualOpaqueInfo"] and not row["selfOccursInAxioms"] for row in all_constants)
        assert all(row["actualHasValueAllowOpaque"] and not row["valueTextRequested"] and row["valuePrettyExplicitAllowOpaque"] is None for row in all_constants)
        assert all("…" not in row["typePrettyExplicit"] and "⋯" not in row["typePrettyExplicit"] for row in all_constants)
        assert all(binding["profileSHA256"] == digest(runtime.read("profile.json")) for binding in bindings)
        out["modules"] = modules
        parser_rows = {}
        parser_raw = get_member(actual, "/04-parser-observe.stdout.raw.sanitized.txt")
        for line in parser_raw.decode().splitlines():
            tag, content = line.split(" ", 1)
            if tag == "C34_IMPORTS_JSON":
                record = json.loads(content)
                parser_rows[record["module"]] = record
        for module in modules:
            record = parser_rows[module["module"]]
            assert record["sha256"] == module["sourceSHA256"]
            assert not record["hasParseErrors"]
            assert record["profileSHA256"] == digest(runtime.read("profile.json"))
        out["targetSourcePinsAgreeWithActualParserRows"] = True
        out["eventCounts"] = {key: len(value) for key, value in events.items()}
        out["ownership"] = [{"module": row["module"], "ownerIndex": row["ownerModuleIndex"], "owned": row["ownedCount"], "roots": row["expectedRoots"], "structures": len(row["structures"])} for row in bindings]
        out["rootKinds"] = dict(collections.Counter(row["actualKind"] for row in roots))
        out["generatedKinds"] = dict(collections.Counter(row["actualKind"] for row in generated))
        out["axiomUnion"] = sorted({name for row in all_constants for name in row["axioms"]})
        out["all104MetadataChecks"] = "PASS"
        out["observeSanitizedStreamSHA256"] = digest(raw)
        out["generated"] = [{"name": row["actualName"], "module": row["module"], "kind": row["actualKind"],
                             "typePrettySHA256": digest(row["typePrettyExplicit"].encode()), "typeChars": len(row["typePrettyExplicit"])} for row in generated]
        out["stages"] = []
        for stage in ("01-prefix", "02-help", "03-parser-compile", "04-parser-observe", "11-target", "12-target", "13-target", "21-driver", "22-driver", "30-observe"):
            result = json.loads(get_member(actual, "/" + stage + ".result.json"))
            observation = json.loads(get_member(actual, "/ci2-" + stage + ".observation.json"))
            preflight = json.loads(get_member(actual, "/ci2-" + stage + ".preflight.json"))
            postflight = json.loads(get_member(actual, "/ci2-" + stage + ".postflight.json"))
            assert result["exitCode"] == 0 and not result["timedOut"]
            assert observation["actualStreamHashesMatch"] and observation["actualPIDResultReceiptsMatch"]
            assert preflight["observationComplete"] and preflight["gatePassed"]
            assert postflight["observationComplete"]
            out["stages"].append({"stage": stage, "exitCode": result["exitCode"], "timedOut": result["timedOut"],
                                  "wallSeconds": result["wallSeconds"], "preflightEffectiveHeadroomBytes": preflight["effectiveHeadroomBytes"]})
        out["runtimeGITHUBSHA"] = preflight["context"]["GITHUB_SHA"]
        out["limitations"] = ["sanitized public stream hashes are not original unsanitized stdout hashes", "no proof-body text requested", "no lossless Expr serialization", "no independent Lean execution", "not all native TCB or provider bodies audited"]
        print(json.dumps(out, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
