# Independent source-first phase-2 comparison, frozen before a new actual decoder

## Result and authority boundary

The three complete target modules reconstruct to the principal contracts independently derived from the pinned natural v2 source. No material target, normalization, exact-sign, endian, occupied-column, assumption, or resource-tier mismatch was found in those 57 source declarations. This is a reviewer-owned mathematical comparison, not a final publication binding or an unconditional SOURCE_AGREEMENT acceptance wrapper. The latter remains unset until the separately authorized exact metadata/new-decoder stage.

The mathematical conclusion is deliberately narrower than whole-system closure. The local matrix producer is not a primitive global state-preparation circuit; the full-table tree is exponential in wire count; the existential completion is not an evaluation algorithm; actual compiler success is not proof of source fidelity or complete trust closure. The exact unchanged-tree signed all-width strengthening remains REFUTED at n=0,f=-1.

This is the SAME reviewer who sealed the source-first mathematical reconstruction and v2 natural addendum before seeing any formal source. Those original artifacts are not edited, copied into the public allowlist, or retroactively reclassified. The source remains implementation-informed retrospective mathematics; historical formalizer UNKNOWN. The v2 clarification was authored by the parent, not represented as historical pre-proof work.

No new actual-decoder result, author metadata graph/classification, publication registry, other reviewer verdict, or author private coverage was read. The original formal-only decoder's released static reconstruction/inventory was read as an additional object to compare, not adopted as a verdict. Direct complete target source/proof bodies in the released packet, the released providers, and raw actual CI streams controlled the conclusions below. No Lean, Git, network, native compiler, production edit, registry edit or child agent was invoked by this review. A small read-only Python consistency discriminator was run.

## Evidence pins and direct checks

Logical paths refer to supplied bundles, not this host's filesystem.

| Input | SHA-256 |
| --- | --- |
| natural v2 `source-effective-v2.md` | `936020bf35582267a8149ed49addd9a9b106c23512205acaf49e9a3febaa6d80` |
| `reviews/publication/real-preparation-c32/decoder-static-public-bundle.zip` | `9b559184f1187cd2b230c1aadf2bb8533d1bf345b895d426ecfc936378650767` |
| `tools/real_preparation_native_c34_ci5/public-runtime-package.zip` | `97bfea091bf49cc17790aa52a3dab0f5e1d8316f2cef129e1989e5159ec35578` |
| `reviews/publication/real-preparation-c32/c34-ci5-actual-success-public.zip` | `56e379105b69b19e42ec0a20c1567203f6cb96d1fddbe768fa0c9f4844e62492` |
| static `formal-context.md` | `16aed6ce6806d4423a421683905cead1cd2bb9818665b86594965bcae197694c` |
| static `supplemental-formal-context.md` | `457a7d3d20f4002a4c808e25ea2eb7bad46339b5529f3427223254afbf808df9` |
| static `inventory.json` | `02033a842721361ff5b9364731dceb60c72ff9a4e3fa53cf22405664c5372f6d` |
| static original `reconstruction.md` | `f51c2a5c7c1011189e5f69abfdf9f7812bff461dfcd5314bd00622bd6f69d7d7` |
| runtime `Collector.lean` | `ff56db30a919f2eef47e97146daf5f10833f553d591f35a8d29c3868feff2860` |
| runtime `profile.json` | `de5a1ebb544315a081c6f07953acd40c8ba12db8abc3f88a3d07e85d817ecb78` |
| runtime `pending-drivers/Profile.lean` | `ae22e95435002793a8766318246ca0d70890dd950f1d1603f2b17eeb51d99294` |

The complete 4,239-line initial formal packet and complete supplemental packet were read, including imports/context, all three target bodies, complete included providers, and the explicitly bounded provider excerpts. Packet truncations remain truncations; an excerpt ending within an unrelated theorem/comment was not treated as complete. Tool-output truncations during reading were reread in smaller ranges.

`audit_raw.py` independently extracts the three complete target code blocks, reproduces their byte SHA pins (with their source line endings), re-extracts declarations, compares the source inventory/profile/root sets, checks the raw stream partition and metadata, and checks target source pins against the actual import-parser rows. The checks passed. It does not prove semantic equivalence, native binary trust, or lossless equality of all printed types to source text.

| Target module under `QuantumBlockEncoding` | Complete source SHA-256 | Source roots / private | Observed owner index / owned / generated |
| --- | --- | --- | --- |
| `RealAmplitudePreparation` | `3c1c145a5262b85159bcead1997ec87875184ac06dfe4da8a6595ae063e434f7` | 45 / 4 | 4823 / 85 / 40 |
| `RealIsometryCompletion` | `e4f41db2f5e3c35f113fa4d91799316ccdfe305753f736d9f9669cda08346017` | 7 / 0 | 4889 / 11 / 4 |
| `ConstructiveIsometryLocal` | `b5792942a1fecf68991b956668775fb07330f64ddc589867f67abe83644073fe` | 5 / 0 | 4902 / 8 / 3 |

Totals are 57 explicit roots = 53 public + 4 private = 13 definitions + 44 theorems; 47 generated constants = 10 definitions + 37 theorems; 104 owned constants. These counts were derived from source and raw events rather than copied from `completeness.json` or `result.json`.

## Own reconstruction of every explicit root

In these tables A means `QuantumBlockEncoding.RealAmplitudePreparation`, E means `QuantumBlockEncoding.RealIsometryCompletion`, and G means `QuantumBlockEncoding.ConstructiveIsometryLocal`. n,N,r,q,l are natural dimensions; B_n is the named bit-word carrier; S(f)=sum f²; L is the highest-bit matrix lift; ell is little-endian indexing. Every row has a formal root and a natural-source disposition; adjacent helpers are not omitted merely because private. Private A roots resolve to the actually observed name `_private.QuantumBlockEncoding.RealAmplitudePreparation.0.` followed by their fully qualified A user name.

| A root | Reconstructed contract / natural anchor |
| --- | --- |
| `lastBasisEquiv` | Explicit B_(n+1) equivalence to (low word,last bit), inverse append; A1-WORD. |
| `lastBasisEquiv_apply` | Forward restriction/last-bit formula, no premise; A1-WORD. |
| `lastBasisEquiv_symm_apply` | Inverse pair is `Fin.snoc`; A1-WORD. |
| `basis_eq_iff` | Whole-word equality iff low and highest equalities; A1-WORD. |
| `liftLastMatrix` | Literal named-basis transport of M tensor I_2; A1-LIFT. |
| `liftLastMatrix_apply` | Entry delta on highest bits times low M entry; A1-LIFT. |
| `liftLastMatrix_one` | L(I)=I; A1-LIFT. |
| `liftLastMatrix_mul` | L(MN)=L(M)L(N) for arbitrary complex square M,N; A1-LIFT. |
| `liftGate` | Four constructors map old wires by castSucc; same angles; CX distinctness transported; A2-GATE. |
| private `split_castSucc_eq` | Equality of old-target complements splits into low complement equality and high-bit equality; A2-CONTEXT. |
| `lift_oneQubit` | Arbitrary 2-by-2 complex matrix on an old target commutes with high-wire lift; no unitarity premise; A2-GATE. |
| private `xBasis_lift` | Low restriction commutes with bit flip; A2-GATE. |
| private `cxBasis_lift` | Low restriction commutes with the total controlled-flip function; no distinctness needed for this restricted helper, unlike typed CX; A2-GATE. |
| `eval_liftGate` | Denotation of each lifted typed gate is L(old denotation); A2-GATE. |
| `eval_liftCircuit` | Denotation of mapped chronological list is L(old denotation); A2-LIST. |
| `pairNorm` | Literal sqrt(a²+b²) for all real pairs; B1-RADIUS. |
| `pairNorm_nonneg` | Radius is nonnegative; B1-RADIUS. |
| `pairNorm_sq` | Radius square equals a²+b², no nonzero premise; B1-RADIUS. |
| `splitAngle` | Zero pair radius -> rational 0; otherwise exact real twice signed arccos with sign from b<0; B2-SPLIT. |
| `splitAngle_firstColumn` | Every pair, including zero/signed entries: RY(theta)[v,0]*radius=(a or b) in complex scalars; B2-SPLIT/PROOF. |
| `marginal` | Pair radii for f(snoc low 0),f(snoc low 1); C1-TABLE. |
| `marginal_nonneg` | All marginal entries nonnegative even for signed f; C1-TABLE. |
| `normSq` | Actual finite sum of squared real entries, not a certificate flag; C1-TABLE. |
| `normSq_nonneg` | Nonnegativity of this actual sum; C1-TABLE. |
| `normSq_marginal` | Exact square-sum preservation by the explicit highest-bit equivalence; C1-NORM. |
| `prepareCircuit` | Width zero empty list; successor lifted marginal list then reference high-target controlled RY list; C3-TREE. |
| `prepareCircuit_unitary` | Arbitrary real input table gives a unitary exact circuit matrix; no positivity premise; C3-UNITARY. |
| private `last_context_eq` | Non-highest-wire equality is exactly low restriction equality; C2-BLOCK. |
| `controlledLast_apply` | Controlled highest RY has low-word delta and selected 2-by-2 entry; C2-BLOCK. |
| `controlledLast_mul_lift` | Exact zero-input column of controlled block times L(M); C2-COLUMN. |
| `prepareCircuit_firstColumn` | f>=0 and S(f)>0 imply actual circuit first column=f/sqrt(S(f)), including width zero; D1-ACTION. |
| `normalized_sum_sq` | S(f)>0 alone implies sum(f/sqrt(S))²=1, including signed f; D2-NORMAL. |
| `normSq_pos_of_positive` | Strict pointwise positivity supplies S(f)>0; D2-NORMAL. |
| `liftCircuit_ryCount` | Lifted list has unchanged RY constructor count; A2-LIST. |
| `liftCircuit_cxCount` | Lifted list has unchanged CX constructor count; A2-LIST. |
| `prepareCircuit_ryCount` | Every f, exact unoptimized RY count 2^n-1; D3-COUNTS. |
| `prepareCircuit_cxCount` | Every f, exact unoptimized CX count 2(2^n-1-n); D3-COUNTS. Nat subtraction is safe since n<2^n. |
| `prepareCircuit_oracleCalls` | Resource field is syntactically zero for this primitive-list alphabet; D3-COUNTS, not free preprocessing. |
| `primitiveBasisLE_zero` | ell(0_n) is numerical zero; D4-COORD. |
| `primitiveBasisLE_zero_symm` | inverse ell(zero)=0_n; D4-COORD. |
| `prepareMatrixLE` | Pull flat input table to named words, evaluate tree, transport both matrix axes by ell; D4-COORD/FLAT. |
| `prepareMatrixLE_unitary` | Arbitrary flat real table still gives a unitary reindexed matrix; D4-COORD. |
| `normSq_reindex` | Square sums unchanged by ell; D4-COORD. |
| `prepareMatrixLE_firstColumn` | Strictly positive flat f gives exact normalized zero-input column; D4-FLAT, stronger premise retained. |
| `normalized_sum_sq_LE` | Strictly positive flat f gives normalized squared sum; D4-FLAT, not silently weakened to positive mass. |

| E root | Reconstructed contract / natural anchor |
| --- | --- |
| `exists_orthogonal_completion` | Real V with V^TV=I and injective e has orthogonal U with U(i,e(a))=V(i,a); no r<N/prefix premise; E1-SPEC/EXTEND. |
| `signFlip` | Diagonal -1 at chosen j and +1 elsewhere; E2-FLIP. |
| `signFlip_orthogonal` | Sign matrix is orthogonal; E2-FLIP. |
| `signFlip_det` | Determinant -1; typed j excludes N=0; E2-FLIP. |
| `mul_signFlip_preserves` | Arbitrary U, a!=j -> right-product column a unchanged; E2-FLIP. |
| `exists_specialOrthogonal_completion_of_unused` | Isometry/injection plus an unused j gives SO completion preserving every active column; E3-ORIENT. |
| `exists_specialOrthogonal_completion` | r<N supplies unused column and same SO conclusion; E3-SPARE. |

| G root | Reconstructed contract / natural anchor |
| --- | --- |
| `coordinates` | Explicit localIndex followed by finProdFinEquiv: append(b,v) maps to ell(b)+2^q*v; G2-PHYSICAL. |
| `localCompletion` | For hr:r<=2^q and arbitrary real V, fixed exact-real completeNamed producer at active clean positions; no isometry premise in the definition; G2-COMPLETE. |
| `localCompletion_spec` | V^TV=I supplies orthogonality, det+1, exact matching at every active physical column; G2-COMPLETE. |
| `completeStage` | Actual chain C, maxBond bound and any t select localCompletion on activeColumns; G3-REAL. |
| `completeStage_spec` | RightCanonical C, capacity bound and t<n imply SO plus G4 equality on active clean inputs, every output bit/bond, with exact real-to-complex cast; G3-ACTION. |

These contracts follow by the mechanisms already derived in phase 1: explicit restriction/tensor bookkeeping; signed pair splitting; low-marginal induction and delta collapse; reference multiplexor recurrence; finite basis extension and spare-column determinant correction; adjacent-row elimination and greedy permutation parity; real padded-column isometry and exact clean physical positions. Direct source reading confirms these mechanisms are actually used, not merely assumed as output-correctness premises.

All 13 target definitions are literal expressions or explicit recurrences. The E completion statements are existential and nonunique, not unique-characterized chosen target definitions. Its proof-local zero extension outside range(e) is passed only as a restricted orthonormal family; no output zero-column fallback is imposed. G uses the deterministic F producer, not a chosen E completion. F shares E signFlip lemmas but does not turn the two sufficient completion methods into one false AND route.

## Actual 47 generated constants: complete non-scientific-role reconstruction

The raw stream identifies these by actual module ownership, not by namespace guessing. Abbreviations A,E,G are as above; P means the exact observed private prefix `_private.QuantumBlockEncoding.RealAmplitudePreparation.0.`. Within a P suffix, the full namespace shown is retained. Rows listing a finite suffix set cover each member separately, with explicit count; the total is 47. These are observed helper interfaces, not independently new source theorems or a claim about all generated bodies.

| Actual generated identity or exact finite family | Count | Meaning from actual types and corresponding supplied bodies |
| --- | --- | --- |
| `QuantumBlockEncoding.zeroBasisIndex.eq_1` | 1 | Definitional zero-index equation. Owned by A despite being outside A's namespace; cannot be omitted by prefix filtering. |
| A.`controlledLast_apply._simp_1` | 1 | Propositional equality for highest-wire context equality versus low init equality. |
| A.`eval_liftGate._simp_6` | 1 | Propositional equality of whole-word equality with the low/high conjunction. |
| A.`liftGate._proof_1` | 1 | castSucc equality contradicts input c!=t; typed CX proof transport. |
| A.`liftGate.eq_1`, `.eq_2`, `.eq_3`, `.eq_4` | 4 | Equations for X,RY,RZ,CX respectively; old target/control labels mapped by castSucc, angles unchanged. |
| A.`liftGate.match_1` | 1 | Four-constructor motive eliminator, not a state-preparation assumption. |
| A.`liftLastMatrix.eq_1` | 1 | Definitional reindexed M tensor I equation, with explicit finite/matrix instances. |
| A.`liftLastMatrix_mul._simp_1` | 1 | Generic commutative-semiring Kronecker-product multiplication identity; not a new quantum hypothesis. |
| A.`lift_oneQubit._simp_1` | 1 | Propositional context equality decomposed into old complement and new highest bit. |
| A.`marginal._proof_1` | 1 | NeZero evidence for the bit type size 1+1. |
| A.`marginal.eq_1` | 1 | Marginal lambda is the literal pairNorm of two appended-bit entries. |
| A.`prepareCircuit._f` | 1 | Recursor step with Nat.below data for the dependent width-indexed list producer. |
| A.`prepareCircuit._sunfold` | 1 | Smart-unfold function with the same dependent producer type; no extra semantic promise. |
| A.`prepareCircuit.eq_1` | 1 | Width-zero circuit is []. |
| A.`prepareCircuit.eq_2` | 1 | Successor is lifted marginal circuit followed by the stated reference multiplexor. |
| A.`prepareCircuit.eq_def` | 1 | Whole defining match equation for zero/successor. |
| A.`prepareCircuit.match_1` | 1 | Dependent zero/successor motive matcher, not a proof of preparation. |
| A.`prepareCircuit_cxCount._proof_1` | 1 | Nat arithmetic n<2^n used to justify subtraction/count algebra. |
| A.`prepareCircuit_ryCount._proof_1` | 1 | Positivity 0<2^n used in count arithmetic. |
| A.`splitAngle._proof_1` | 1 | Bit-size AtLeastTwo instance. |
| A.`splitAngle.eq_1` | 1 | Literal radius-zero/sign-tested angle equation. |
| P + `QuantumBlockEncoding.PrimitiveCircuit.ryCount.match_1.eq_1`, `.eq_2`, `.splitter` | 3 | RY branch, non-RY default-branch equation with branch-exclusion premise, and its motive splitter. |
| P + `QuantumBlockEncoding.PrimitiveGate.twoQubitCount.match_1.eq_1`, `.eq_2`, `.splitter` | 3 | CX branch, non-CX default-branch equation and motive splitter; CX distinctness retained. |
| P + `QuantumBlockEncoding.RealAmplitudePreparation.liftGate.match_1.eq_1`, `.eq_2`, `.eq_3`, `.eq_4`, `.splitter` | 5 | Four constructor reduction equations and their common motive splitter. |
| P + `QuantumBlockEncoding.RealAmplitudePreparation.prepareCircuit.match_1.eq_1`, `.eq_2`, `.splitter` | 3 | Dependent width-zero/successor reductions and splitter. |
| P + `QuantumBlockEncoding.PrimitiveCircuit.ryCount.match_1.splitter._sparseCasesOn_1` | 1 | Sparse eliminator for RY-vs-other cases. |
| P + `QuantumBlockEncoding.PrimitiveGate.twoQubitCount.match_1.splitter._sparseCasesOn_1` | 1 | Sparse eliminator for CX-vs-other cases. |
| E.`exists_orthogonal_completion._simp_1` | 1 | Propositional equality of subtype equality with underlying-value equality. |
| E.`exists_specialOrthogonal_completion._proof_1` | 1 | r<N and N<=r imply False; finite-cardinality contradiction. |
| E.`exists_specialOrthogonal_completion._simp_1` | 1 | Classical not-forall equals exists-not proposition. |
| E.`signFlip.eq_1` | 1 | Literal diagonal signFlip equation. |
| G.`completeStage._proof_1` | 1 | maxBond capacity implies rankAt(C,t)<=2^q. |
| G.`localCompletion._proof_1` | 1 | Arithmetic contradiction form: r<=2^q, 0<2^q and not(r<2*2^q) imply False. Those are this helper's binders, not extra localCompletion public hypotheses. |
| G.`localCompletion._proof_2` | 1 | Derived strict spare bound r<2*2^q from r<=2^q. |

The actual raw types were parsed for every root/generated constant, checked for non-ellipsized print output, and scrutinized together with complete source interfaces and selected verbose raw-type subexpressions. This is not a token-by-token proof-body audit: the collector did not request value text. `audit_raw.py` reports each generated actual identity, kind and printed-type SHA, preserving the distinction between actual generated evidence and the original static decoder, which explicitly did not observe generated declarations.

The observed partition has no owned structures, constructors or structure-field bundles. All 104 are defnInfo/thmInfo, with unsafe=false, actualAxiomInfo=false, actualOpaqueInfo=false, value availability=true, no self-occurrence in collected axioms, and reported kernel/elaboration name/type/universe/value-Expr consistency. Their collected axiom union is exactly `Classical.choice`, `Quot.sound`, `propext`. No `sorryAx` or new target axiom appears in this collected union. This is evidence about these actual records under the stated collector/Lean trust boundary, not a complete upstream/native axiom-policy or binary audit.

## Assumption and seven-slot comparison

No target contains section-variable assumptions, local notation/instances, or a target bundle hiding an output-correctness premise. The recursively relevant logical source binders are: D1 nonnegativity and positive square sum; D4 strict positivity; E real input isometry, injective placement, known unused column or strict dimension; G real chain, recursive RightCanonical, all-boundary maxBond capacity and t<n. Fin/Equiv/Embedding and typed CX retain their bounds/inverse/injection/distinctness constraints. All match the natural contracts. E's a!=j preservation lemma has its exact local exclusion premise. The G conclusion's active-label implication is a domain restriction on promised columns, not an unexplained global hypothesis.

RightCanonical expands to True at nil and AA^T=I AND RightCanonical(tail) at cons. It is local core row orthonormality, not a named global success flag. maxBond includes both boundary ranks. ActiveColumns is the real part of actual paddedAt entries under explicit localIndex; its isometry is proved from canonicality, capacity, existing-stage validity and realness. Those suppliers remain internal dependency edges in G.completeStage_spec, rather than EXCESS public binders. No source-relative EXCESS was identified in these 57 target interfaces. Generic lifting/total basis-action helpers are modest mathematical generalizations, not strengthened public preparation claims.

| Slot | Independent source/formal comparison |
| --- | --- |
| Target/normalization | D1 exactly f>=0,S>0 -> normalized first column; signed norm-only lemma separate. D4 exactly strict positivity, not silently weakened. E/G prescribe real orthonormal/local padded columns, not a named function's global state. |
| Scalars/dimensions/basis/order | Real f/core/orthogonal matrices and complex circuit embedding match. Fin n -> Fin 2 named bits, highest append, and ell weight 2^j match. `finProdFinEquiv` uses second+n*first, hence local coordinate ell(b)+B*v, not bond-major-with-bit-low. Chronological evaluation is later matrices on the left. |
| Oracle/access/control | Arbitrary supplied tables/chains/exact reals are mathematical inputs, not efficient coherent evaluation or unit-cost callbacks. Reference mux uses low controls and distinct highest target. No oracle instructions. No coherent superposition over classical C/t is claimed. |
| Ancillas/workspace | Tree has n initialized wires and no added workspace. Local stage has q bond wires/fresh highest zero bit, and only occupied clean input columns are fixed. Passive emitted wires/terminal cleanup remain conditional sequential consumer results, not G's whole-circuit conclusions. |
| Phase | Literal signed complex entries, half-angle RY, no quotient. At (-1,0), theta=2pi and Ry=-I; width-zero tree still +1. E orientation flip affects only an unused column; F parity does not alter specified columns. |
| Norm/error/success | Exact identities, no epsilon or postselection loss. Zero table has a total unitary list but no normalized target. Invalid scheduled stages do not acquire active-isometry conclusions. No arbitrary boundary normalization is inferred. |
| Resources | Exact reference counts and zero encoded query count match. PrimitiveCircuit resource literally sets oracle count to zero; it does not account for table/angle evaluation. E existence, F exact-real producer and G local matrix are distinct tiers. No finite-bit/runtime/depth/connectivity/global gate guarantee is supplied by these targets. |

## Coordinate and supplier-tail audit

The mathematical H0 map is h(v,b)=snoc(ell inverse(b),v), with inverse localIndex(z)=(highest(z),ell(low(z))). Released `localIndex` and `localIndex_snoc` give exactly that inverse coordinate pairing, and G.coordinates flattens it as b+B*v. G.activePositions maps active a to localIndex inverse(0,cast a); G.completeStage_spec proves this is snoc(ell inverse(a),0) by injectivity, not by an arbitrary basis enumeration. Thus clean substitution yields mathcal U((v,b),(0,a))=K((v,b),a) for occupied numerical a, exactly as independently proved in the natural-v2 addendum. There is no discovered reversed ell, wrong permutation side or phase change.

However no new H0-named implementation theorem or full flattening theorem is manufactured here. For the actual real matrix, numerical Stage semantics additionally uses the literal real-to-complex entry embedding and simultaneous axis transport. These operations are mathematically transparent in the released definitions; whether an eventual assembly uses the exact intended adapter remains a use-site obligation. Imported `circuitStage` transports actual primitive-circuit denotations to bit-first *named bond* coordinates; it is not itself an emitted primitive circuit for G.completeStage. Numerical-bond transport and physical global placement must not be conflated.

Complete source/implementation tails retained:

- Amplitude column = supplied table AND nonnegative/positive-mass source premises AND signed pair split AND marginal norm preservation AND lift/chronological semantics AND exact controlled compiler AND zero-width base. Norm-only and counts-only branches do not inherit unnecessary positivity/column-action dependencies.
- E's O completion = actual isometry AND injection AND basis extension. SO existence additionally needs a spare column AND determinant correction; r<N supplies the spare label. F's explicit SO completion is an OR alternative using pair elimination AND complete row sweeps AND prefix invariants AND inverse transform AND greedy placement AND parity correction. No basis-extension witness is hidden inside G's producer.
- Local stage = actual real chain AND recursive canonicality AND all-rank capacity AND in-range stage AND padded isometry AND explicit physical clean placement AND F.completeNamed supplier. The specification does not assume its own desired column equation.
- Sequential assembly = actual local occupied-column suppliers AND fresh zero inputs AND passive prior emissions AND supported boundary AND next-rank support AND exact coordinate transport AND chronological action. Terminal cleanup needs terminal rank one. Normalized full target needs normalized boundary and target-contraction match; a global primitive circuit still needs boundary loading, local compilation and physical placement.

An imported separate existential local compiler has a `6*(2^q)^3` gate bound. It is neither a target theorem of these three modules nor a certificate that the particular F/G-produced matrix has already been emitted as a primitive list here. This cannot be used to erase the chosen-producer/global supplier frontier. Existing library tools could be used in a later composition theorem; their availability is not that theorem.

## Raw native evidence and non-closure boundaries

The actual artifact has 106 members and cohort `871bfa1745f1498780a10360c71638e7`. Direct raw results show the three serial target commands exit 0 without timeout, at 12.25227249s, 3.47527659s and 3.12311736s. Target stdout contains only deprecation warnings for the first two modules and is empty for the third; stderr is empty. The observe stage exits 0 without timeout at 5.88179846s. All ten recorded parser/target/driver/observation stages have exit 0 and complete passed preflights in the bounded Python check. This is actual successful target execution evidence, not a prediction copied from an earlier profile.

The target commands use `--threads=1 --memory=5120 -DElab.async=false`; actual fresh `.olean` lookups are checked by Collector against the cohort root, with ownership determined by environment module indices. Collected current-root/private identity sets match the complete source inventory, and owned=explicit UNION generated with no duplicates. This is stronger than a namespace-prefix grep. The collector compares actual kernel and elaboration constants, invokes actual collectAxioms, and observes value availability. Its value text field is null by design; `Meta.ppExpr` is not lossless Expr serialization even with explicit/deep options and no ellipsis.

The sanitized public observe stdout has SHA `bbe160f2ecb6991bd9b125ae8ef49f51e6cdbb3680c007a311bb813adad33e2b`. The runtime receipt's original stdout SHA is `6e1c3a1b743425fbc1f33cd9e4c7133e40bc30a26af6aa65b0a9ccc09cb46bcd`. They are different evidence objects because public paths were sanitized. The latter cannot be recomputed from the former; the raw-derivation/provenance layer is inherited evidence, not reproduced original bytes in this review. The archive digest and sanitized-member digest remain directly checked.

Runtime preflight reports GITHUB_SHA `a12a5eb7fe33514a63f04ed3372ee03f0ee9e145`, not API head `f0d67e84a6a66766d360e21ff6cf97469819af67`. The optional parent-authored `c39-ci5-context-api.json` was read only with attribution: it reports an API merge commit with that head as a parent and a matching tree. This reviewer made no API/Git query and does not turn tree equality into executed-checkout or load-trace attestation. Actual source/configuration/driver/profile pins remain separate.

The resource layer records self-only procfs/cgroup observations, 5120 MiB budget plus 2048 MiB reserve, a 7168 MiB admission threshold, and namespace recognition by a reserved initial-cgroup inode fingerprint. These are bounded observations/policy assumptions, not a current-kernel binary proof or PID1/whole-system audit. Some upstream project providers are inherited copied `.olean`s; lookup/copy/source pins do not establish a new transitive clean build. Imported source excerpts and observed collectAxioms do not equal inspection of every transitive proof/native body. No all-TCB or actual OS load trace is certified.

## Typed residuals and stop packet

| ID | Type / precise retained boundary |
| --- | --- |
| RZ-NATURAL-SPEC | SOURCE_GAP, scope-limited: formal RZ is diag(exp(-i theta/2),exp(+i theta/2)); natural A2 does not fix its phase formula. Generic one-qubit lifting covers it regardless, and the actual tree uses only RY/CX, so no principal-target contradiction follows. Do not retroactively pretend the natural text specified that formula. |
| H0-ASSEMBLY-USE | OPEN use-site adapter/global-placement obligation. Mathematical coordinate direction matches actual localIndex; no chosen-producer primitive/global circuit assembly is supplied by these targets. |
| SIGNED-ALL-WIDTH | REFUTED for the unchanged exact-phase tree at width zero; no new root quietly strengthens D1. Positive-width signed extension remains a possible separate theorem, not claimed here. |
| STRUCTURED-SUPPLIERS | OPEN function-to-chain, normalized boundary/loading, approximation/rank/error, deterministic finite-bit canonicalization, local primitive compilation and global placement/cost composition. |
| FINITE-BIT-COST | OPEN numerical evaluation/rounding/conditioning/zero-sign decisions/discrete synthesis/storage/access/copying/readout; oracle=0 is insufficient. |
| ACTUAL-VALUE-TEXT | EVIDENCE_BOUNDARY: bodies available in observed ConstantInfo but value text not requested; no complete generated/native proof-body review. |
| PRETTY-EXPR | EVIDENCE_BOUNDARY: actual explicit type print is not lossless Expr serialization; no complete TCB body equality claim. |
| INHERITED-PROVIDERS | EVIDENCE_BOUNDARY: copied/transitive imports and bounded source excerpts do not certify clean transitive rebuild or minimal imports. |
| PROCFS-NATIVE-TCB | EVIDENCE_BOUNDARY: inherited instrumentation/namespace/kernel-recognition assumptions, not all native TCB/procfs/binary audit. |
| FINAL-BINDING | PROCEDURAL_PENDING: exact metadata plus a new actual decoder/comparison binding not yet released. No registry/final-binding wrapper emitted. |

Failure class for this completed comparison: NONE; no newly false principal source/formal contract found. Residual evidence/supplier gaps are not mislabeled mathematical refutations or API/environment failures. Salvage: preserve the exact width-zero counterexample, all 57 root mappings, all 47 generated-helper dispositions and the H0/source supplier-tail distinctions. No artifact was deleted or production implementation changed.

Direction fingerprint: independent source-first whole-three-module/actual-owned-constant comparison with natural-v2 coordinate and resource-boundary discrimination. Information gain: determine semantic matching directly from the released source/native material, before any new actual-decoder verdict. No process-memory records or additional agents were used. No default globally verified route, new scientific root, publication/main admission, proof/exposition seal or PURIFIED state is granted. Own phase-2 artifacts are frozen before accepting any further decoder or metadata release.
