"""Freeze this addendum only; no external commands, supplied modules or path literals."""
import argparse
import datetime
import hashlib
import json
import pathlib
import re


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main(root):
    root=pathlib.Path(root)
    if any((root/name).exists() for name in ('seal.json','freeze.json')):
        raise ValueError('immutable stage already frozen')
    def write(name,value):
        (root/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    payload=sorted(p.name for p in root.iterdir() if p.is_file())
    allowed=sorted(set(payload)|{'publicsafe-allowlist.json','hashmanifest.json','seal.json','freeze.json'})
    write('publicsafe-allowlist.json',dict(schema='exact-actual-decoder-publicsafe-v1',allowed=allowed,
          path_scope='Artifact-relative names only; repository paths and dollar-prefixed runtime coordinates are logical',
          exclusions=[],claim='Content eligibility only, not a source or publication decision'))
    rows=[]
    drive=re.compile(r'(?<![A-Za-z0-9])[A-Za-z]'+chr(58)+r'[\\/]')
    userdir=re.compile('/'+r'(?:Users|home|runner|tmp|var/tmp|opt|mnt|workspace|__w)'+'/')
    for name in sorted(set(payload)|{'publicsafe-allowlist.json'}):
        data=(root/name).read_bytes()
        text=data.decode('utf-8-sig')
        if drive.search(text) or userdir.search(text) or ('file'+chr(58)+'//') in text:
            raise ValueError('publicsafe path scanner found a nonlogical host path in '+name)
        if name.endswith('.json'): json.loads(text)
        rows.append(dict(path=name,bytes=len(data),sha256=digest(data)))
    write('hashmanifest.json',dict(schema='actual-decoder-content-hashmanifest-v1',files=rows,
          excluded_from_own_digest=['hashmanifest.json','seal.json','freeze.json']))
    manifest_bytes=(root/'hashmanifest.json').read_bytes()
    seal=dict(schema='same-decoder-actual-evidence-seal-v1',
        decoder_identity='real-preparation-decoder-c32-5d05b95f-26db-4691-ab3b-5aae22195a3f',
        stage='c39-actual-addendum',state='FROZEN_FORMAL_ACTUAL_DECODING_ONLY',
        sealed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        manifest_path='hashmanifest.json',manifest_sha256=digest(manifest_bytes),
        payload_files=len(rows),actual_source_roots=57,actual_additional_owned=47,
        actual_owned_total=104,observed_remote_native_child_records=10,
        decoder_native_invocations=0,decoder_network_calls=0,decoder_git_commands=0,
        publicsafe_scan='passed: no user-host absolute path or file URL in payload or scanner literals',
        integrity_scope='Payload content binding, not a kernel re-run, natural-source agreement, whole TCB approval, OS/load attestation or publication acceptance')
    write('seal.json',seal)
    seal_hash=digest((root/'seal.json').read_bytes())
    write('freeze.json',dict(schema='same-decoder-actual-freeze-receipt-v1',
         decoder_identity=seal['decoder_identity'],seal_path='seal.json',seal_sha256=seal_hash,
         state='FROZEN_STOP',receipt_self_hashed=False,
         next_action='STOP; require explicit authorization and a new successor packet for changes'))
    print(json.dumps(dict(state='FROZEN_STOP',seal_sha256=seal_hash,
                          manifest_sha256=digest(manifest_bytes),publicsafe_files=len(allowed))))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',required=True)
    main(parser.parse_args().root)
