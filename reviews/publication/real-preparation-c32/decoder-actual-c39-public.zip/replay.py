"""Independent bounded archive-only decoder replay. Never executes supplied code."""
import argparse
import collections
import hashlib
import json
import pathlib
import re
import zipfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def unique_pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError('duplicate JSON key')
        result[key] = value
    return result


def loads(data):
    return json.loads(data.decode('utf-8-sig') if isinstance(data, bytes) else data,
                      object_pairs_hook=unique_pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def records(text):
    rows = []
    for number, line in enumerate(text.splitlines(), 1):
        if line.startswith('C34_'):
            tag, value = line.split(' ', 1)
            rows.append((tag, loads(value), number))
        elif line.strip():
            raise ValueError('unexpected untagged output')
    return rows


def display(text):
    """Lossy reading aid only; exact pp text remains separately preserved."""
    # Keep all applications and binders intact: in particular an overloaded matrix
    # product may itself be applied to row/column arguments. Tail-argument rewrites
    # would silently change its mathematics. Only whitespace/names/universes change.
    return re.sub(r'\s+', ' ', re.sub(r'\.\{[^{}]*\}', '', text)).replace('QuantumBlockEncoding.', '').strip()


def main(args):
    out = pathlib.Path(args.out)
    if (out / 'seal.json').exists():
        raise ValueError('frozen output; successor required')
    out.mkdir(parents=True, exist_ok=True)
    actual_bytes = pathlib.Path(args.actual).read_bytes()
    assert sha(actual_bytes) == '56e379105b69b19e42ec0a20c1567203f6cb96d1fddbe768fa0c9f4844e62492'
    actual = zipfile.ZipFile(args.actual)
    runtime = zipfile.ZipFile(args.runtime)
    static = zipfile.ZipFile(args.static)
    static_seal=loads(static.read('seal.json'))
    static_freeze=loads(static.read('freeze.json'))
    assert static_freeze['seal_sha256']==sha(static.read('seal.json'))
    for row in static_seal['artifacts']:
        if row['path'] in static.namelist():
            assert sha(static.read(row['path']))==row['sha256'] and len(static.read(row['path']))==row['bytes']
    accessed = []
    def read(name):
        matches = [n for n in actual.namelist() if n.endswith('/' + name)]
        assert len(matches) == 1, name
        path = matches[0]
        data = actual.read(path)
        if path not in accessed: accessed.append(path)
        return data
    def doc(name): return loads(read(name))
    def write(name, value):
        (out / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    raw = read('30-observe.stdout.raw.sanitized.txt')
    observed = records(raw.decode())
    roots = [d for t, d, _ in observed if t == 'C34_ROOT_JSON']
    generated = [d for t, d, _ in observed if t == 'C34_GENERATED_JSON']
    bindings = [d for t, d, _ in observed if t == 'C34_BINDING_JSON']
    static_inv = loads(static.read('inventory.json'))
    static_by_name = {d['id']: d for d in static_inv}
    assert len(roots) == len(static_inv) == len(static_by_name) == 57
    assert len(generated) == 47 and len(bindings) == 3
    assert {r['sourceUserName'] for r in roots} == set(static_by_name)
    profile_bytes = runtime.read('profile.json')
    profile = loads(profile_bytes)
    profile_sha = sha(profile_bytes)
    assert all(d['profileSHA256'] == profile_sha for d in bindings)
    assert len({d['cohortID'] for d in bindings}) == 1
    all_actual = roots + generated
    names = [r['actualName'] for r in all_actual]
    assert len(names) == len(set(names)) == 104
    check_fields = ['kernelRootPresent', 'kernelTypeAndUniversesAgree',
                    'kernelElaborationUnsafeAgree', 'kernelElaborationValueAvailabilityAgree',
                    'kernelElaborationValueExprAgree']
    assert all(all(r[k] is True for k in check_fields) for r in all_actual)
    assert all(r['isUnsafe'] is False and r['selfOccursInAxioms'] is False for r in all_actual)
    assert all(r['actualKind'] in ('defnInfo','thmInfo') and r['actualHasValueAllowOpaque'] is True for r in all_actual)
    assert all(r['valueTextRequested'] is False and r['valuePrettyExplicitAllowOpaque'] is None for r in all_actual)
    assert all(not any(c in r['typePrettyExplicit'] for c in ('⋯','…')) for r in all_actual)
    assert len([t for t,d,n in observed if t=='C34_SUMMARY_JSON'])==1 and observed[-1][0]=='C34_SUMMARY_JSON'
    assert [(r['sourceUserName'],r['sourcePrivate'],r['sourceKind']) for r in roots]==[(r['sourceUserName'],r['sourcePrivate'],r['sourceKind']) for r in profile['roots']]
    position=0
    for binding in bindings:
        assert observed[position][0]=='C34_BINDING_JSON' and observed[position][1]['module']==binding['module']
        position+=1
        for r in [r for r in roots if r['module']==binding['module']]:
            assert observed[position][0]=='C34_ROOT_JSON' and observed[position][1]['actualName']==r['actualName'];position+=1
        while position<len(observed) and observed[position][0]=='C34_GENERATED_JSON':
            assert observed[position][1]['module']==binding['module'];position+=1
    assert position==len(observed)-1
    rows, discrepancies = [], []
    for r in roots:
        previous = static_by_name[r['sourceUserName']]
        checks = dict(source_kind=previous['kind'] == r['sourceKind'],
                      actual_kind=r['actualKind'] == ('defnInfo' if previous['kind'] == 'def' else 'thmInfo'),
                      privacy=(previous['visibility'].startswith('private')) == r['actualPrivate'] == r['sourcePrivate'],
                      module=previous['module'][:-5].replace('/', '.') == r['module'],
                      user_name=r['sourceUserName'] == r['userNameViaActualAPI'],
                      no_root_universes=r['universeParameters'] == [],
                      safe=r['isUnsafe'] is False,
                      no_self_axiom=r['selfOccursInAxioms'] is False,
                      kernel_elab_flags=all(r[k] is True for k in check_fields),
                      no_elided_type=not any(c in r['typePrettyExplicit'] for c in ('⋯', '…')))
        if not all(checks.values()): discrepancies.append(dict(name=r['sourceUserName'], checks=checks))
        rows.append({k: v for k, v in r.items() if k not in
                     ('nativeAccepted','sourceAgreement','publicationBinding','scientificAcceptance','axiomPolicyPass','trustClosure')}
                    | dict(static_source_statement=previous['statement_source'],
                           static_semantic_record=previous['semantic_record'], comparisons=checks,
                           readable_type_aid=display(r['typePrettyExplicit'])))
    for binding in bindings:
        module_rows = [r for r in all_actual if r['module'] == binding['module']]
        assert set(binding['ownedNames']) == {r['actualName'] for r in module_rows}
        assert binding['ownedCount'] == len(module_rows)
        assert all(r['ownerModuleIndex'] == binding['ownerModuleIndex'] for r in module_rows)
        assert binding['structures'] == []
    assert not discrepancies
    write('actual-roots.json', rows)
    spines=[]
    for r in roots:
        text=' '.join(r['typePrettyExplicit'].split())
        text=re.sub(r'\.\{[^{}]*\}','',text)
        depth,last,parts=0,0,[]
        for i,char in enumerate(text):
            if char in '({[': depth+=1
            elif char in ')}]': depth-=1
            elif depth==0 and char in '→,': parts.append(text[last:i].strip());last=i+1
        spines.append(dict(source_name=r['sourceUserName'],universe_parameters=r['universeParameters'],
                           leading_pi_segments=parts,conclusion_text=text[last:].strip(),
                           method='Lexical segments of actual pp text, NOT serialized Expr or kernel Pi extractor'))
    write('actual-pi-spines.json',spines)
    write('actual-generated.json', [{k:v for k,v in r.items() if k not in
          ('nativeAccepted','sourceAgreement','publicationBinding','scientificAcceptance','axiomPolicyPass','trustClosure')}
          for r in generated])
    readable = ['# Actual kernel type reading aid', '',
                'Exact typePrettyExplicit is retained in actual-roots.json. These are lossy display rewrites only, not Lean elaboration or an expression-equivalence decision.', '']
    for r in rows:
        readable.extend(['## '+r['sourceUserName'], '', r['readable_type_aid'], ''])
    (out / 'type-reading-aid.md').write_text('\n'.join(readable), encoding='utf-8')
    write('observed-counts.json', dict(tags=dict(collections.Counter(t for t,_,_ in observed)),
          per_module=[dict(module=b['module'], roots=len([r for r in roots if r['module']==b['module']]),
             generated=len([r for r in generated if r['module']==b['module']]),owned=b['ownedCount'],
             owner_index=b['ownerModuleIndex'],structures=b['structures'],resolved_olean=b['resolvedOleanPath']) for b in bindings],
          actual_kind_counts=dict(collections.Counter(r['actualKind'] for r in all_actual)),
          generated_universe_counts=dict(collections.Counter(str(r['universeParameters']) for r in generated)),
          axiom_union=sorted({a for r in all_actual for a in r['axioms']}),
          unsafe_names=[r['actualName'] for r in all_actual if r['isUnsafe']],
          axiom_info_names=[r['actualName'] for r in all_actual if r['actualAxiomInfo']],
          opaque_info_names=[r['actualName'] for r in all_actual if r['actualOpaqueInfo']],
          self_axiom_names=[r['actualName'] for r in all_actual if r['selfOccursInAxioms']],
          missing_value_names=[r['actualName'] for r in all_actual if not r['actualHasValueAllowOpaque']],
          value_text_requested_names=[r['actualName'] for r in all_actual if r['valueTextRequested']],
          kernel_elaboration_disagreements=[r['actualName'] for r in all_actual if not all(r[k] for k in check_fields)],
          cohort_id=bindings[0]['cohortID'],profile_sha256=profile_sha,
          independent_summary_derived_before_any_completeness_or_aggregate_result_read=True))
    package_bindings = loads(runtime.read('package-bindings.json'))
    package_checks = {n:sha(runtime.read(n)) == h for n,h in package_bindings['files'].items()}
    assert all(package_checks.values())
    sources = []
    for p,h in profile['projectInputs'].items():
        data = (pathlib.Path(args.repo) / p).read_bytes()
        assert sha(data) == h
        sources.append(dict(path=p,sha256=h,bytes=len(data)))
    write('source-context-checks.json',dict(actual_source_files=sources,profile_project_inputs=profile['projectInputs'],
          static_context_binding=loads(static.read('context-binding.json')),runtime_package_file_checks=package_checks))
    # Compiler-header closure is independently rebuilt from the raw parseImports rows.
    parser_rows = records(read('04-parser-observe.stdout.raw.sanitized.txt').decode())
    imports = [d for t,d,_ in parser_rows if t=='C34_IMPORTS_JSON']
    candidate = loads(runtime.read('candidate-sources.json'))
    candidates={d['module']:d for d in candidate['files']}
    parsed={d['module']:d for d in imports}
    assert set(parsed)==set(candidates) and len(imports)==len(parsed)==220
    assert all(all(parsed[m][k]==candidates[m][k] for k in ('relativePath','sha256','bytes')) for m in parsed)
    assert all(r['parseMessages']==0 and r['hasParseErrors'] is False for r in imports)
    order, visiting = [], set()
    def visit(m):
        if m in order: return
        assert m not in visiting
        visiting.add(m)
        for imp in parsed[m]['imports']:
            if imp['module'] in parsed: visit(imp['module'])
            else: assert imp['module'].split('.',1)[0] not in candidate['scopes']['directoryRoots']
        visiting.remove(m);order.append(m)
    for module in [b['module'] for b in bindings]: visit(module)
    providers=[m for m in order if m not in {b['module'] for b in bindings}]
    copies=doc('provider-copies.json')
    copychecks=[dict(source=r['sourceRealPath'],destination=r['destinationRealPath'],sha256=r['sha256'],
                    all_recorded_hashes_agree=all(r[k]==r['sha256'] for k in ('sourceSHA256Before','sourceSHA256After','destinationSHA256Before','destinationSHA256After'))) for r in copies['files']]
    copied_modules={r['destination'].split('/cohort/')[1].removesuffix('.olean') .replace('/','.') for r in copychecks if r['destination'].endswith('.olean')}
    assert set(providers)==copied_modules and all(r['all_recorded_hashes_agree'] for r in copychecks)
    write('independent-import-cohort.json',dict(candidate_count=len(imports),project_closure=order,providers=providers,
          provider_count=len(providers),parser_source_bindings=[dict(module=m,sha256=parsed[m]['sha256']) for m in order],
          external_import_edges=[dict(owner=m,imports=[d for d in parsed[m]['imports'] if d['module'] not in parsed]) for m in order],
          provider_copy_checks=copychecks,absent_sidecars=copies['absentSidecars'],
          boundary='Inherited project olean receipts, not independent rebuilding or actual dynamic-load trace'))
    # No vendor validators or callbacks are executed; inspect all ten receipt sets ourselves.
    labels=['01-prefix','02-help','03-parser-compile','04-parser-observe','11-target','12-target','13-target','21-driver','22-driver','30-observe']
    caps=[30,30,120,30,600,600,600,120,120,300]
    stages=[]
    for label,cap in zip(labels,caps):
        invocation=doc(label+'-invocation.json');setup=doc(label+'.setup.json');started=doc(label+'.started.json');result=doc(label+'.result.json')
        pre=doc('ci2-'+label+'.preflight.json');post=doc('ci2-'+label+'.postflight.json');observation=doc('ci2-'+label+'.observation.json')
        argv=invocation['argv']
        assert argv==setup['argv']==observation['actualArgv']==observation['requestedArgv']
        assert argv.count('--memory=5120')==argv.count('--threads=1')==1
        assert [v for v in argv if v.startswith('--memory')]==['--memory=5120']
        assert argv.count('-DElab.async=false') == int(label in ['11-target','12-target','13-target'])
        assert result['PID']==started['PID']==post['childPID']==observation['nativeResult']['PID']
        assert result['exitCode']==0 and result['timedOut'] is False
        assert 0<invocation['timeoutSeconds']<=cap and setup['timeoutSeconds']==invocation['timeoutSeconds']
        def resource(r):
            headroom=[r['memAvailableBytes']]+[g['headroomBytes'] for g in r['cgroups'] if not g['limitUnlimited']]
            assert min(headroom)==r['effectiveHeadroomBytes']>=7168*1024**2
            assert r['budgetMiB']==5120 and r['reserveMiB']==2048 and r['requiredHeadroomBytes']==7168*1024**2
            assert r['observationComplete'] is True and r['gatePassed'] is True
            assert r['context']['GITHUB_RUN_ID']=='38996381936'
            assert r['namespaceObservation']['pid1Observation']['readRequested'] is False
            assert r['rootObservation']['type']=='DOCUMENTED_TRUE_ROOT_NOT_APPLICABLE_NOT_UNLIMITED'
            assert all(not v['readRequested'] and not v['unlimitedObserved'] for v in r['rootObservation']['memoryInterfaces'].values())
            logicals={'$PROC/meminfo','$PROC/self/cgroup','$PROC/self/mountinfo',
                      '$CGROUP_REAL_ROOT/cgroup.controllers','$CGROUP_REAL_ROOT/cgroup.procs'}
            for g in r['cgroups']:
                logicals.update(g['logicalPath']+'/'+v for v in ('memory.max','memory.current','memory.events'))
            assert len(r['fileReads'])==len(logicals) and {v['logicalPath'] for v in r['fileReads']}==logicals
            assert len(r['namespaceReads'])==1 and r['namespaceReads'][0]['logicalPath']=='$PROC/self/ns/cgroup'
            assert len(r['readAttempts'])==len(r['fileReads'])+len(r['namespaceReads'])
            for receipt in r['fileReads']+r['namespaceReads']:
                attempts=[v for v in r['readAttempts'] if v['logicalPath']==receipt['logicalPath']]
                assert len(attempts)==1 and attempts[0]['status']=='READ_OK'
                assert all(attempts[0][k]==receipt[k] for k in ('sha256','bytes','atVerifiedMountRoot'))
            namespace_bytes=('cgroup:['+str(r['namespaceObservation']['selfInode'])+']').encode()
            assert r['namespaceReads'][0]['sha256']==sha(namespace_bytes)
            assert not any('/memory.' in v['logicalPath'] and v['atVerifiedMountRoot'] is True for v in r['fileReads'])
            return dict(mem_available=r['memAvailableBytes'],effective_headroom=r['effectiveHeadroomBytes'],
                        cgroups=[dict(logical_path=g['logicalPath'],limit_raw=g['memoryMaxRaw'],current=g['memoryCurrentBytes'],headroom=g['headroomBytes'],events=g['memoryEvents']) for g in r['cgroups']],
                        namespace=r['namespaceObservation'],root_memory_interface_state=r['rootObservation']['type'],
                        observed_context=r['context'],started_utc=r['startedUTC'],finished_utc=r['finishedUTC'])
        stages.append(dict(label=label,pid=result['PID'],wrapper_pid=invocation['wrapperPID'],argv=argv,cwd=invocation['cwd'],
                    cap_seconds=cap,timeout_seconds=invocation['timeoutSeconds'],result=result,
                    pre=resource(pre),post=resource(post),
                    chronology=(pre['finishedUTC']<=result['startedUTC']<=result['finishedUTC']<=post['startedUTC']),
                    observation_native_result_equal=result==observation['nativeResult']))
    assert len({s['pid'] for s in stages})==10
    assert all(s['chronology'] and s['observation_native_result_equal'] for s in stages)
    assert all(stages[i]['result']['finishedUTC']<=stages[i+1]['result']['startedUTC'] for i in range(9))
    write('independent-resource-processes.json',dict(stages=stages,serial_unique_pids=True,
         whole_native_interval_seconds=None,operating_system_memory_limit_claim=False,
         boundary='Lean --memory flag plus self-namespace headroom receipts, not an OS-enforced 5120 MiB cap or host binary attestation'))
    # Bind implementation and runtime receipts without relying on their aggregate verdicts.
    technical_names=['entry-bindings.json','target-cohort.json','driver-artifacts.json','driver-source-copy-bindings.json',
                     'runtime-environment.json','resource-gate-bindings.json','parser-provenance.json','parser-request.json',
                     'raw-derivation-receipts.json']
    technical={n:doc(n) for n in technical_names}
    for row in technical['entry-bindings.json']['entry']['loadedModules']:
        assert sha(runtime.read(row['path'].split('$PROFILE_PACKAGE/')[1]))==row['sha256']
    assert technical['entry-bindings.json']['entry']['actualEntrySHA256']==sha(runtime.read('runner.py'))
    assert technical['entry-bindings.json']['entry']['packageManifestSHA256']==sha(runtime.read('package-bindings.json'))
    assert sha(runtime.read('packet-seal.json')) in technical['entry-bindings.json']['entry']['argv']
    assert technical['parser-provenance.json']['parserSourceSHA256']==sha(runtime.read('Parser.lean'))
    for row in technical['driver-source-copy-bindings.json']['files']:
        assert sha(runtime.read(row['sourceRealPath'].split('$PROFILE_PACKAGE/')[1]))==row['sha256']
        assert all(row[k]==row['sha256'] for k in ('sourceSHA256Before','sourceSHA256After','destinationSHA256Before','destinationSHA256After'))
    for binding in bindings:
        target=next(t for t in technical['target-cohort.json']['targets'] if t['module']==binding['module'])
        assert target['artifacts'][0]['realPath']==binding['resolvedOleanPath']
        assert target['nativeResult']==next(s for s in stages if s['pid']==target['nativeResult']['PID'])['result']
    assert technical['runtime-environment.json']['C34_PROFILE_SHA256']==profile_sha
    assert technical['runtime-environment.json']['C34_COHORT_ID']==bindings[0]['cohortID']
    resource_binding=technical['resource-gate-bindings.json']
    assert resource_binding['actualAdapter']['sha256']==sha(runtime.read('resource_adapter.py'))
    for row in resource_binding['binding']['loadedModules']:
        assert sha(runtime.read(row['path'].split('$PROFILE_PACKAGE/')[1]))==row['sha256']
    derivations=technical['raw-derivation-receipts.json']['files']
    exported={row['publicRelativePath']:row for row in derivations}
    assert technical['parser-provenance.json']['requestSHA256']==exported['parser-request.json']['rawSHA256']
    assert technical['parser-provenance.json']['rawObservationSHA256']==exported['04-parser-observe.stdout.raw.sanitized.txt']['rawSHA256']
    for path in list(accessed):
        relative=path.rsplit('/',1)[1]
        if relative in exported: assert sha(actual.read(path))==exported[relative]['publicSHA256']
    for s in stages:
        for stream in ('stdout','stderr'):
            relative=s['label']+'.'+stream+'.raw.sanitized.txt'
            streambytes=read(relative)
            assert sha(streambytes)==exported[relative]['publicSHA256']
            assert exported[relative]['rawSHA256']==s['result'][stream+'SHA256']
        for phase in ('preflight','postflight'):
            relative='ci2-'+s['label']+'.'+phase+'.json'
            assert exported[relative]['rawSHA256']==doc('ci2-'+s['label']+'.observation.json')[phase+'SHA256']
    write('technical-receipts.json',technical)
    if args.parent_context:
        parent_bytes=pathlib.Path(args.parent_context).read_bytes()
        write('parent-attributed-context.json',dict(logical_name='c39-ci5-context-api.json',sha256=sha(parent_bytes),
              provenance='Parent-supplied API/local-tree metadata only; decoder performed no Git/API query or executed-checkout attestation',
              metadata=loads(parent_bytes)))
    write('input-bindings.json',dict(actual_archive=dict(logical_path='c34-ci5-actual-success-public.zip',sha256=sha(actual_bytes),members=len(actual.namelist())),
          static_archive=dict(logical_path='decoder-static-public-bundle.zip',sha256=sha(pathlib.Path(args.static).read_bytes()),members=len(static.namelist())),
          runtime_archive=dict(logical_path='tools/real_preparation_native_c34_ci5/public-runtime-package.zip',sha256=sha(pathlib.Path(args.runtime).read_bytes()),members=len(runtime.namelist())),
          runtime_member_hashes={n:sha(runtime.read(n)) for n in runtime.namelist()},
          accessed_actual_members=[dict(path=n,sha256=sha(actual.read(n)),bytes=len(actual.read(n))) for n in accessed],
          manually_inspected_non_authoritative_technical_summaries=[dict(path=n,sha256=sha(actual.read(n))) for n in actual.namelist() if n.endswith('/compiler-discovery.json') or n.endswith('/provider-inventory.json')],
          deliberately_unread_actual_aggregate_members=[n for n in actual.namelist() if n.endswith('/completeness.json') or n.endswith('/result.json')],
          no_supplied_code_executed=True))
    print(json.dumps(dict(roots=len(roots),generated=len(generated),owned=len(names),providers=len(providers),
                         process_pids=[s['pid'] for s in stages],source_mismatches=discrepancies,
                         runtime_context_shas=sorted({s['pre']['observed_context']['GITHUB_SHA'] for s in stages}))))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    for key in ('actual','runtime','static','repo','out'): parser.add_argument('--'+key,required=True)
    parser.add_argument('--parent-context')
    main(parser.parse_args())
