# Formal context packet

Packet purpose: reconstruct the mathematical meaning of the exact supplied formal material. No natural-source lesson, author assumption ledger, expected decision, external source title, or previous decision is included. This is a static source snapshot, not a compilation transcript. Complete target modules occur first; imported providers follow as complete files or explicitly bounded excerpts. Unexpanded imports remain visible. Do not infer elaborated dependency closure from file inclusion.

## QuantumBlockEncoding/RealAmplitudePreparation.lean

Raw-file SHA256: 3c1c145a5262b85159bcead1997ec87875184ac06dfe4da8a6595ae063e434f7

```lean
import QuantumBlockEncoding.UniformlyControlledRy
import QuantumBlockEncoding.PrimitiveBasisLE
import QuantumBlockEncoding.StatePreparation

/-!
# Constructive preparation of finite real amplitude tables

Wires are ordered little-endian. The recursive construction prepares the
low-wire marginal norms first, then splits each marginal with a uniformly
controlled rotation on the new highest wire. The angles are exact real
expressions; finite numerical export is a separate evaluation obligation.
-/

namespace QuantumBlockEncoding.RealAmplitudePreparation

open Robin.ComplexLCU
open scoped Kronecker

/-- Adjoin a most-significant bit; existing wire numbers do not change. -/
def lastBasisEquiv (n : Nat) : PrimitiveBasis (n + 1) ≃ PrimitiveBasis n × Fin 2 :=
  (Fin.snocEquiv (fun _ : Fin (n + 1) => Fin 2)).symm.trans (Equiv.prodComm _ _)

@[simp] theorem lastBasisEquiv_apply {n : Nat} (b : PrimitiveBasis (n + 1)) :
    lastBasisEquiv n b = (Fin.init b, b (Fin.last n)) := rfl

@[simp] theorem lastBasisEquiv_symm_apply {n : Nat} (b : PrimitiveBasis n) (v : Fin 2) :
    (lastBasisEquiv n).symm (b, v) = Fin.snoc b v := rfl

theorem basis_eq_iff {n : Nat} (a b : PrimitiveBasis (n + 1)) :
    a = b ↔ Fin.init a = Fin.init b ∧ a (Fin.last n) = b (Fin.last n) := by
  rw [← (lastBasisEquiv n).injective.eq_iff]
  simp

/-- Tensor a circuit matrix with an untouched highest wire. -/
noncomputable def liftLastMatrix {n : Nat}
    (M : _root_.Matrix (PrimitiveBasis n) (PrimitiveBasis n) ℂ) :
    _root_.Matrix (PrimitiveBasis (n + 1)) (PrimitiveBasis (n + 1)) ℂ :=
  _root_.Matrix.reindexAlgEquiv ℂ ℂ (lastBasisEquiv n).symm
    (M ⊗ₖ (1 : _root_.Matrix (Fin 2) (Fin 2) ℂ))

@[simp] theorem liftLastMatrix_apply {n : Nat}
    (M : _root_.Matrix (PrimitiveBasis n) (PrimitiveBasis n) ℂ)
    (a b : PrimitiveBasis (n + 1)) :
    liftLastMatrix M a b =
      if a (Fin.last n) = b (Fin.last n) then M (Fin.init a) (Fin.init b) else 0 := by
  simp [liftLastMatrix, _root_.Matrix.reindexAlgEquiv_apply,
    _root_.Matrix.reindex_apply, _root_.Matrix.submatrix_apply,
    _root_.Matrix.one_apply, mul_ite]

@[simp] theorem liftLastMatrix_one (n : Nat) :
    liftLastMatrix (1 : _root_.Matrix (PrimitiveBasis n) (PrimitiveBasis n) ℂ) = 1 := by
  simp [liftLastMatrix]

theorem liftLastMatrix_mul {n : Nat}
    (M N : _root_.Matrix (PrimitiveBasis n) (PrimitiveBasis n) ℂ) :
    liftLastMatrix (M * N) = liftLastMatrix M * liftLastMatrix N := by
  simp [liftLastMatrix, ← _root_.Matrix.mul_kronecker_mul]

/-- Embed every instruction without changing its original wire number. -/
def liftGate {n : Nat} : PrimitiveGate n → PrimitiveGate (n + 1)
  | .x t => .x t.castSucc
  | .ry t a => .ry t.castSucc a
  | .rz t a => .rz t.castSucc a
  | .cx c t h => .cx c.castSucc t.castSucc (fun e => h (Fin.castSucc_injective _ e))

private theorem split_castSucc_eq {n : Nat} (t : Fin n)
    (a b : PrimitiveBasis (n + 1)) :
    (splitPrimitiveWire t.castSucc a).2 = (splitPrimitiveWire t.castSucc b).2 ↔
      (splitPrimitiveWire t (Fin.init a)).2 = (splitPrimitiveWire t (Fin.init b)).2 ∧
      a (Fin.last n) = b (Fin.last n) := by
  constructor
  · intro h
    constructor
    · funext w
      exact congrFun h ⟨w.1.castSucc, by simpa using w.2⟩
    · exact congrFun h ⟨Fin.last n, Ne.symm (Fin.castSucc_ne_last t)⟩
  · rintro ⟨h, hl⟩
    funext w
    obtain ⟨w, hw⟩ := w
    change a w = b w
    revert hw
    refine Fin.lastCases ?_ (fun i => ?_) w
    · intro _; exact hl
    · intro hi
      exact congrFun h ⟨i, by simpa using hi⟩

theorem lift_oneQubit {n : Nat} (t : Fin n)
    (M : _root_.Matrix (Fin 2) (Fin 2) ℂ) :
    liftPrimitiveOneQubit t.castSucc M = liftLastMatrix (liftPrimitiveOneQubit t M) := by
  ext a b
  simp only [liftPrimitiveOneQubit_apply, liftLastMatrix_apply, split_castSucc_eq]
  by_cases hc : (splitPrimitiveWire t (Fin.init a)).2 =
      (splitPrimitiveWire t (Fin.init b)).2 <;>
    by_cases hl : a (Fin.last n) = b (Fin.last n) <;>
    simp [hc, hl, Fin.init]

private theorem xBasis_lift {n : Nat} (t : Fin n) (b : PrimitiveBasis (n + 1)) :
    Fin.init (xBasisAction t.castSucc b) = xBasisAction t (Fin.init b) := by
  funext i
  simp [xBasisAction, Fin.init, Function.update_apply]

private theorem cxBasis_lift {n : Nat} (c t : Fin n) (b : PrimitiveBasis (n + 1)) :
    Fin.init (cxBasisAction c.castSucc t.castSucc b) =
      cxBasisAction c t (Fin.init b) := by
  by_cases h : b c.castSucc = 0 <;>
    simp [cxBasisAction, h, Fin.init, xBasis_lift]

theorem eval_liftGate {n : Nat} (g : PrimitiveGate n) :
    evalPrimitiveGate (liftGate g) = liftLastMatrix (evalPrimitiveGate g) := by
  cases g with
  | ry t a => exact lift_oneQubit t _
  | rz t a => exact lift_oneQubit t _
  | x t =>
    ext a b
    simp only [liftGate, evalPrimitiveGate, equivPermutationMatrix, liftLastMatrix_apply]
    change (if a = xBasisAction t.castSucc b then 1 else 0) =
      if a (Fin.last n) = b (Fin.last n) then
        if Fin.init a = xBasisAction t (Fin.init b) then 1 else 0 else 0
    have hl : xBasisAction t.castSucc b (Fin.last n) = b (Fin.last n) := by
      simp [xBasisAction, Ne.symm (Fin.castSucc_ne_last t)]
    simp only [basis_eq_iff, xBasis_lift, hl]
    by_cases h : a (Fin.last n) = b (Fin.last n) <;> simp [h]
  | cx c t h =>
    ext a b
    simp only [liftGate, evalPrimitiveGate, equivPermutationMatrix, liftLastMatrix_apply]
    change (if a = cxBasisAction c.castSucc t.castSucc b then 1 else 0) =
      if a (Fin.last n) = b (Fin.last n) then
        if Fin.init a = cxBasisAction c t (Fin.init b) then 1 else 0 else 0
    have hl : cxBasisAction c.castSucc t.castSucc b (Fin.last n) = b (Fin.last n) := by
      by_cases hc : b c.castSucc = 0 <;>
        simp [cxBasisAction, hc, xBasisAction, Ne.symm (Fin.castSucc_ne_last t)]
    simp only [basis_eq_iff, cxBasis_lift, hl]
    by_cases h : a (Fin.last n) = b (Fin.last n) <;> simp [h]

theorem eval_liftCircuit {n : Nat} (c : PrimitiveCircuit n) :
    evalPrimitiveCircuit (c.map liftGate) = liftLastMatrix (evalPrimitiveCircuit c) := by
  induction c with
  | nil => simp [evalPrimitiveCircuit]
  | cons g c ih =>
    simp only [List.map_cons, evalPrimitiveCircuit, ih, eval_liftGate, liftLastMatrix_mul]

/-- Euclidean mass at one binary split. -/
noncomputable def pairNorm (a b : ℝ) : ℝ := Real.sqrt (a ^ 2 + b ^ 2)

theorem pairNorm_nonneg (a b : ℝ) : 0 ≤ pairNorm a b := Real.sqrt_nonneg _

theorem pairNorm_sq (a b : ℝ) : pairNorm a b ^ 2 = a ^ 2 + b ^ 2 := by
  exact Real.sq_sqrt (add_nonneg (sq_nonneg a) (sq_nonneg b))

/-- Twice the signed polar angle, with the zero subtree assigned angle zero.
The arccos formula avoids an unverified numerical `atan2` primitive. -/
noncomputable def splitAngle (a b : ℝ) : ExactAngle :=
  if pairNorm a b = 0 then .rational 0 else
    .real (2 * if b < 0 then -Real.arccos (a / pairNorm a b)
      else Real.arccos (a / pairNorm a b))

theorem splitAngle_firstColumn (a b : ℝ) (v : Fin 2) :
    standardRyMatrix (splitAngle a b).eval v 0 * (pairNorm a b : ℂ) =
      if v = 0 then (a : ℂ) else (b : ℂ) := by
  have hr := pairNorm_nonneg a b
  have hr2 := pairNorm_sq a b
  by_cases hz : pairNorm a b = 0
  · have ha : a = 0 := by nlinarith [sq_nonneg b]
    have hb : b = 0 := by nlinarith [sq_nonneg a]
    rw [hz, Complex.ofReal_zero, mul_zero]
    simp [ha, hb]
  · have hp : 0 < pairNorm a b := lt_of_le_of_ne hr (Ne.symm hz)
    have ha : -pairNorm a b ≤ a ∧ a ≤ pairNorm a b := by
      constructor <;> nlinarith [sq_nonneg b]
    have lower : -1 ≤ a / pairNorm a b := (le_div_iff₀ hp).2 (by linarith)
    have upper : a / pairNorm a b ≤ 1 := (div_le_iff₀ hp).2 (by linarith)
    have hc : Real.cos (Real.arccos (a / pairNorm a b)) * pairNorm a b = a := by
      rw [Real.cos_arccos lower upper, div_mul_cancel₀ _ hz]
    have hs : 0 ≤ Real.sin (Real.arccos (a / pairNorm a b)) * pairNorm a b :=
      mul_nonneg (Real.sin_nonneg_of_nonneg_of_le_pi
        (Real.arccos_nonneg _) (Real.arccos_le_pi _)) hr
    have hs2 : (Real.sin (Real.arccos (a / pairNorm a b)) * pairNorm a b) ^ 2 = b ^ 2 := by
      have h := congrArg (fun x : ℝ => x * pairNorm a b ^ 2)
        (Real.sin_sq_add_cos_sq (Real.arccos (a / pairNorm a b)))
      nlinarith [sq_nonneg (Real.sin (Real.arccos (a / pairNorm a b)) * pairNorm a b)]
    have hangle : (2 * (if b < 0 then -Real.arccos (a / pairNorm a b)
        else Real.arccos (a / pairNorm a b))) / 2 =
        if b < 0 then -Real.arccos (a / pairNorm a b) else Real.arccos (a / pairNorm a b) := by
      ring
    simp only [splitAngle, if_neg hz, ExactAngle.eval, standardRyMatrix]
    rw [hangle]
    fin_cases v
    · change realRotation (if b < 0 then -Real.arccos (a / pairNorm a b)
          else Real.arccos (a / pairNorm a b)) 0 0 * (pairNorm a b : ℂ) = (a : ℂ)
      rw [realRotation_zero_zero]
      by_cases hb : b < 0
      · simpa only [if_pos hb, Real.cos_neg, Complex.ofReal_mul] using
          congrArg Complex.ofReal hc
      · simpa only [if_neg hb, Complex.ofReal_mul] using congrArg Complex.ofReal hc
    · change realRotation (if b < 0 then -Real.arccos (a / pairNorm a b)
          else Real.arccos (a / pairNorm a b)) 1 0 * (pairNorm a b : ℂ) = (b : ℂ)
      rw [realRotation_one_zero]
      by_cases hb : b < 0
      · have he : -(Real.sin (Real.arccos (a / pairNorm a b)) * pairNorm a b) = b := by
          nlinarith
        simpa only [if_pos hb, Real.sin_neg, Complex.ofReal_neg, Complex.ofReal_mul,
          neg_mul] using congrArg Complex.ofReal he
      · have he : Real.sin (Real.arccos (a / pairNorm a b)) * pairNorm a b = b := by
          nlinarith
        simpa only [if_neg hb, Complex.ofReal_mul] using congrArg Complex.ofReal he

/-- Marginal amplitudes on all but the highest wire. -/
noncomputable def marginal {n : Nat} (f : PrimitiveBasis (n + 1) → ℝ) :
    PrimitiveBasis n → ℝ := fun b => pairNorm (f (Fin.snoc b 0)) (f (Fin.snoc b 1))

theorem marginal_nonneg {n : Nat} (f : PrimitiveBasis (n + 1) → ℝ) (b : PrimitiveBasis n) :
    0 ≤ marginal f b := pairNorm_nonneg _ _

/-- True squared Euclidean norm of the complete amplitude table. -/
noncomputable def normSq {n : Nat} (f : PrimitiveBasis n → ℝ) : ℝ := ∑ b, f b ^ 2

theorem normSq_nonneg {n : Nat} (f : PrimitiveBasis n → ℝ) : 0 ≤ normSq f :=
  Finset.sum_nonneg (fun _ _ => sq_nonneg _)

theorem normSq_marginal {n : Nat} (f : PrimitiveBasis (n + 1) → ℝ) :
    normSq (marginal f) = normSq f := by
  unfold normSq
  simp only [marginal, pairNorm_sq]
  rw [← (lastBasisEquiv n).symm.sum_comp]
  simp [Fintype.sum_prod_type, Fin.sum_univ_two]

/-- Chronological low-bit-first binary tree, compiled entirely to RY and CX. -/
noncomputable def prepareCircuit : (n : Nat) → (PrimitiveBasis n → ℝ) → PrimitiveCircuit n
  | 0, _ => []
  | n + 1, f =>
    (prepareCircuit n (marginal f)).map liftGate ++
      compileUniformlyControlledRy n Fin.castSucc (Fin.last n) Fin.castSucc_ne_last
        (fun b => splitAngle (f (Fin.snoc b 0)) (f (Fin.snoc b 1)))

theorem prepareCircuit_unitary {n : Nat} (f : PrimitiveBasis n → ℝ) :
    evalPrimitiveCircuit (prepareCircuit n f) ∈
      _root_.Matrix.unitaryGroup (PrimitiveBasis n) ℂ :=
  evalPrimitiveCircuit_unitary _

private theorem last_context_eq {n : Nat} (a b : PrimitiveBasis (n + 1)) :
    (splitPrimitiveWire (Fin.last n) a).2 = (splitPrimitiveWire (Fin.last n) b).2 ↔
      Fin.init a = Fin.init b := by
  constructor
  · intro h
    funext i
    exact congrFun h ⟨i.castSucc, Fin.castSucc_ne_last i⟩
  · intro h
    funext w
    obtain ⟨w, hw⟩ := w
    change a w = b w
    revert hw
    refine Fin.lastCases ?_ (fun i => ?_) w
    · intro h; exact (h rfl).elim
    · intro _; exact congrFun h i

theorem controlledLast_apply {n : Nat} (angles : PrimitiveBasis n → ExactAngle)
    (a b : PrimitiveBasis (n + 1)) :
    controlledRyBlockMatrix Fin.castSucc (Fin.last n) Fin.castSucc_ne_last angles a b =
      if Fin.init a = Fin.init b then
        standardRyMatrix (angles (Fin.init a)).eval (a (Fin.last n)) (b (Fin.last n))
      else 0 := by
  simp only [controlledRyBlockMatrix_apply, last_context_eq]
  rfl

theorem controlledLast_mul_lift {n : Nat} (angles : PrimitiveBasis n → ExactAngle)
    (M : _root_.Matrix (PrimitiveBasis n) (PrimitiveBasis n) ℂ)
    (a : PrimitiveBasis (n + 1)) :
    (controlledRyBlockMatrix Fin.castSucc (Fin.last n) Fin.castSucc_ne_last angles *
        liftLastMatrix M) a (fun _ => 0) =
      standardRyMatrix (angles (Fin.init a)).eval (a (Fin.last n)) 0 *
        M (Fin.init a) (fun _ => 0) := by
  rw [_root_.Matrix.mul_apply, ← (lastBasisEquiv n).symm.sum_comp]
  simp only [controlledLast_apply, liftLastMatrix_apply]
  simp [Fintype.sum_prod_type]
  exact Or.inl rfl

/-- The compiled first column is the normalized input table. This version
also covers the zero-qubit register, whose sole amplitude must be nonnegative. -/
theorem prepareCircuit_firstColumn {n : Nat} (f : PrimitiveBasis n → ℝ)
    (nonneg : ∀ b, 0 ≤ f b) (positive : 0 < normSq f) (b : PrimitiveBasis n) :
    evalPrimitiveCircuit (prepareCircuit n f) b (fun _ => 0) =
      ((f b / Real.sqrt (normSq f) : ℝ) : ℂ) := by
  induction n with
  | zero =>
    have heq : b = (fun _ => 0) := Subsingleton.elim _ _
    have hnorm : normSq f = f b ^ 2 := by
      calc
        normSq f = ∑ _x : PrimitiveBasis 0, f b ^ 2 :=
          Finset.sum_congr rfl (fun x _ => congrArg (fun x => f x ^ 2) (Subsingleton.elim x b))
        _ = f b ^ 2 := by simp
    have hf : 0 < f b := by have := nonneg b; rw [hnorm] at positive; nlinarith
    rw [hnorm, Real.sqrt_sq (le_of_lt hf), div_self (ne_of_gt hf)]
    simp [prepareCircuit, evalPrimitiveCircuit, heq]
  | succ n ih =>
    simp only [prepareCircuit, evalPrimitiveCircuit_append, eval_liftCircuit,
      compileUniformlyControlledRy_eval_controlledRyBlockMatrix]
    rw [controlledLast_mul_lift]
    rw [ih (marginal f) (marginal_nonneg f) (by simpa [normSq_marginal] using positive)]
    rw [normSq_marginal]
    push_cast
    rw [← mul_div_assoc]
    change
      (standardRyMatrix
        (splitAngle (f (Fin.snoc (Fin.init b) 0)) (f (Fin.snoc (Fin.init b) 1))).eval
          (b (Fin.last n)) 0 *
        (pairNorm (f (Fin.snoc (Fin.init b) 0)) (f (Fin.snoc (Fin.init b) 1)) : ℂ)) /
          (Real.sqrt (normSq f) : ℂ) = _
    rw [splitAngle_firstColumn]
    congr 1
    have hs : Fin.snoc (Fin.init b) (b (Fin.last n)) = b := Fin.snoc_init_self b
    generalize hv : b (Fin.last n) = v at *
    fin_cases v <;> simp_all

/-- Normalization is the actual sum of squared amplitudes, not a certificate flag. -/
theorem normalized_sum_sq {n : Nat} (f : PrimitiveBasis n → ℝ)
    (positive : 0 < normSq f) :
    (∑ b, (f b / Real.sqrt (normSq f)) ^ 2) = 1 := by
  simp_rw [div_pow]
  rw [← Finset.sum_div]
  change normSq f / Real.sqrt (normSq f) ^ 2 = 1
  rw [Real.sq_sqrt (normSq_nonneg f), div_self (ne_of_gt positive)]

theorem normSq_pos_of_positive {n : Nat} (f : PrimitiveBasis n → ℝ)
    (positive : ∀ b, 0 < f b) : 0 < normSq f := by
  apply Finset.sum_pos
  · intro b _; exact sq_pos_of_pos (positive b)
  · exact Finset.univ_nonempty

theorem liftCircuit_ryCount {n : Nat} (c : PrimitiveCircuit n) :
    PrimitiveCircuit.ryCount (c.map liftGate) = c.ryCount := by
  induction c with
  | nil => rfl
  | cons g c ih =>
    cases g <;> simp_all [PrimitiveCircuit.ryCount, liftGate]

theorem liftCircuit_cxCount {n : Nat} (c : PrimitiveCircuit n) :
    PrimitiveCircuit.cxCount (c.map liftGate) = c.cxCount := by
  induction c with
  | nil => rfl
  | cons g c ih =>
    cases g <;> simp_all [PrimitiveCircuit.cxCount, liftGate]

/-- The unoptimized reference tree uses exactly one RY per internal tree node. -/
theorem prepareCircuit_ryCount {n : Nat} (f : PrimitiveBasis n → ℝ) :
    (prepareCircuit n f).ryCount = 2 ^ n - 1 := by
  induction n with
  | zero => rfl
  | succ n ih =>
    simp only [prepareCircuit, PrimitiveCircuit.ryCount_append, liftCircuit_ryCount,
      compileUniformlyControlledRy_ryCount, ih, pow_succ]
    have hp : 0 < 2 ^ n := pow_pos (by decide) _
    omega

/-- CX count for the recursive reference multiplexor, without Gray-code optimization. -/
theorem prepareCircuit_cxCount {n : Nat} (f : PrimitiveBasis n → ℝ) :
    (prepareCircuit n f).cxCount = 2 * (2 ^ n - 1 - n) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    simp only [prepareCircuit, PrimitiveCircuit.cxCount_append, liftCircuit_cxCount,
      compileUniformlyControlledRy_cxCount, ih, pow_succ]
    have hp : n < 2 ^ n := Nat.lt_two_pow_self
    omega

theorem prepareCircuit_oracleCalls {n : Nat} (f : PrimitiveBasis n → ℝ) :
    (prepareCircuit n f).resource.oracleCalls = 0 :=
  PrimitiveCircuit.resource_oracleCalls_eq_zero _

@[simp] theorem primitiveBasisLE_zero (n : Nat) :
    primitiveBasisLEEquiv n (fun _ => 0) = zeroBasisIndex n := by
  apply Fin.ext
  induction n with
  | zero => rfl
  | succ n ih =>
    change 0 + 2 * (primitiveBasisLEEquiv n (fun _ => 0)).val = 0
    have ihVal : (primitiveBasisLEEquiv n (fun _ => 0)).val = 0 := by
      simpa [zeroBasisIndex] using ih
    simp [ihVal]

@[simp] theorem primitiveBasisLE_zero_symm (n : Nat) :
    (primitiveBasisLEEquiv n).symm (zeroBasisIndex n) = (fun _ => 0) := by
  apply (primitiveBasisLEEquiv n).injective
  simp

/-- The same circuit matrix on flat little-endian integer indices. -/
noncomputable def prepareMatrixLE {n : Nat} (f : Fin (gridSize n) → ℝ) :
    _root_.Matrix (Fin (gridSize n)) (Fin (gridSize n)) ℂ :=
  _root_.Matrix.reindexAlgEquiv ℂ ℂ (primitiveBasisLEEquiv n)
    (evalPrimitiveCircuit (prepareCircuit n (fun b => f (primitiveBasisLEEquiv n b))))

theorem prepareMatrixLE_unitary {n : Nat} (f : Fin (gridSize n) → ℝ) :
    prepareMatrixLE f ∈ _root_.Matrix.unitaryGroup (Fin (gridSize n)) ℂ :=
  reindex_unitary _ _ (prepareCircuit_unitary _)

theorem normSq_reindex {n : Nat} (f : Fin (gridSize n) → ℝ) :
    normSq (fun b => f (primitiveBasisLEEquiv n b)) = ∑ j, f j ^ 2 := by
  exact (primitiveBasisLEEquiv n).sum_comp (fun j => f j ^ 2)

theorem prepareMatrixLE_firstColumn {n : Nat} (f : Fin (gridSize n) → ℝ)
    (positive : ∀ j, 0 < f j) (j : Fin (gridSize n)) :
    prepareMatrixLE f j (zeroBasisIndex n) =
      ((f j / Real.sqrt (∑ i, f i ^ 2) : ℝ) : ℂ) := by
  unfold prepareMatrixLE
  simp only [_root_.Matrix.reindexAlgEquiv_apply, _root_.Matrix.reindex_apply,
    _root_.Matrix.submatrix_apply, primitiveBasisLE_zero_symm]
  rw [prepareCircuit_firstColumn _ (fun b => le_of_lt (positive _))
    (normSq_pos_of_positive _ (fun b => positive _)), normSq_reindex]
  simp

theorem normalized_sum_sq_LE {n : Nat} (f : Fin (gridSize n) → ℝ)
    (positive : ∀ j, 0 < f j) :
    (∑ j, (f j / Real.sqrt (∑ i, f i ^ 2)) ^ 2) = 1 := by
  have h := normalized_sum_sq (fun b => f (primitiveBasisLEEquiv n b))
    (normSq_pos_of_positive _ (fun b => positive _))
  rw [normSq_reindex] at h
  calc
    _ = ∑ b, (f (primitiveBasisLEEquiv n b) / Real.sqrt (∑ i, f i ^ 2)) ^ 2 :=
      ((primitiveBasisLEEquiv n).sum_comp _).symm
    _ = 1 := h

end QuantumBlockEncoding.RealAmplitudePreparation
```

## QuantumBlockEncoding/RealIsometryCompletion.lean

Raw-file SHA256: e4f41db2f5e3c35f113fa4d91799316ccdfe305753f736d9f9669cda08346017

```lean
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic

/-!
# Prescribed real isometry columns and special-orthogonal completion

An orthonormal family can be placed at arbitrary distinct matrix columns and
completed to an orthogonal matrix. With one unused column, the orientation can
be corrected without modifying any prescribed column. These are classical
existence theorems, not arithmetic algorithms or preprocessing-cost bounds.
-/

namespace QuantumBlockEncoding.RealIsometryCompletion

open scoped BigOperators
open InnerProductSpace

/-- An arbitrary injection specifies the physical positions of the active
columns, so no assumption that they form a prefix is needed. -/
theorem exists_orthogonal_completion {N r : ℕ}
    (V : _root_.Matrix (Fin N) (Fin r) ℝ) (e : Fin r ↪ Fin N)
    (hV : V.transpose * V = 1) :
    ∃ U : _root_.Matrix (Fin N) (Fin N) ℝ,
      U.transpose * U = 1 ∧ ∀ i a, U i (e a) = V i a := by
  classical
  let col : Fin r → EuclideanSpace ℝ (Fin N) := fun a => WithLp.toLp 2 (fun i => V i a)
  have hc : Orthonormal ℝ col := by
    rw [orthonormal_iff_ite]
    intro a b
    have h := congrFun (congrFun hV a) b
    simp only [col, PiLp.inner_apply]
    change (∑ i, V i b * V i a) = if a = b then (1 : ℝ) else 0
    simpa [_root_.Matrix.mul_apply,
      _root_.Matrix.transpose_apply, _root_.Matrix.one_apply, mul_comm] using h
  let f : Fin N → EuclideanSpace ℝ (Fin N) := fun j =>
    if h : ∃ a, e a = j then col h.choose else 0
  have hf (a : Fin r) : f (e a) = col a := by
    dsimp [f]
    split_ifs with h
    · exact congrArg col (e.injective h.choose_spec)
    · exact False.elim (h ⟨a, rfl⟩)
  have ho : Orthonormal ℝ ((Set.range e).restrict f) := by
    rw [orthonormal_iff_ite]
    rintro ⟨i, a, rfl⟩ ⟨j, b, rfl⟩
    change ⟪f (e a), f (e b)⟫_ℝ =
      if (⟨e a, ⟨a, rfl⟩⟩ : Set.range e) = ⟨e b, ⟨b, rfl⟩⟩ then 1 else 0
    rw [hf, hf]
    simpa [Subtype.ext_iff, e.injective.eq_iff] using
      (orthonormal_iff_ite.mp hc a b)
  have hd : Module.finrank ℝ (EuclideanSpace ℝ (Fin N)) = Fintype.card (Fin N) := by simp
  obtain ⟨basis, hb⟩ := ho.exists_orthonormalBasis_extension_of_card_eq hd
  let U : _root_.Matrix (Fin N) (Fin N) ℝ := fun i j => basis j i
  refine ⟨U, ?_, ?_⟩
  · ext a b
    have h := basis.inner_eq_ite a b
    simp only [PiLp.inner_apply] at h
    rw [_root_.Matrix.mul_apply]
    change (∑ i, basis a i * basis b i) = if a = b then (1 : ℝ) else 0
    simpa [mul_comm] using h
  · intro i a
    change basis (e a) i = V i a
    rw [hb (e a) ⟨a, rfl⟩, hf]

/-- Change the sign of one chosen column; every other column is unchanged. -/
def signFlip {N : ℕ} (j : Fin N) : _root_.Matrix (Fin N) (Fin N) ℝ :=
  _root_.Matrix.diagonal (fun i => if i = j then -1 else 1)

theorem signFlip_orthogonal {N : ℕ} (j : Fin N) :
    (signFlip j).transpose * signFlip j = 1 := by
  rw [signFlip, _root_.Matrix.diagonal_transpose, _root_.Matrix.diagonal_mul_diagonal]
  convert (_root_.Matrix.diagonal_one :
    _root_.Matrix.diagonal (1 : Fin N → ℝ) = 1) using 1
  congr 1
  funext i
  by_cases hi : i = j <;> simp [hi]

theorem signFlip_det {N : ℕ} (j : Fin N) : (signFlip j).det = -1 := by
  simp [signFlip, _root_.Matrix.det_diagonal]

theorem mul_signFlip_preserves {N : ℕ} (U : _root_.Matrix (Fin N) (Fin N) ℝ)
    (j i a : Fin N) (ha : a ≠ j) : (U * signFlip j) i a = U i a := by
  simp [signFlip, _root_.Matrix.mul_diagonal, ha]

/-- Correct a negative determinant using a known unused column. All active
columns remain exact, and the result lies in SO(N), not merely O(N). -/
theorem exists_specialOrthogonal_completion_of_unused {N r : ℕ}
    (V : _root_.Matrix (Fin N) (Fin r) ℝ) (e : Fin r ↪ Fin N)
    (hV : V.transpose * V = 1) (unused : Fin N) (hu : ∀ a, e a ≠ unused) :
    ∃ U : _root_.Matrix (Fin N) (Fin N) ℝ,
      U.transpose * U = 1 ∧ U.det = 1 ∧ ∀ i a, U i (e a) = V i a := by
  obtain ⟨U, hU, hc⟩ := exists_orthogonal_completion V e hV
  have hd : U.det * U.det = 1 := by
    have h := congrArg _root_.Matrix.det hU
    simpa [_root_.Matrix.det_mul, _root_.Matrix.det_transpose] using h
  by_cases hpos : U.det = 1
  · exact ⟨U, hU, hpos, hc⟩
  · have hneg : U.det = -1 := (mul_self_eq_one_iff.mp hd).resolve_left hpos
    refine ⟨U * signFlip unused, ?_, ?_, ?_⟩
    · rw [_root_.Matrix.transpose_mul]
      calc
        _ = (signFlip unused).transpose * (U.transpose * U) * signFlip unused := by
          simp only [_root_.Matrix.mul_assoc]
        _ = 1 := by rw [hU, _root_.Matrix.mul_one, signFlip_orthogonal]
    · rw [_root_.Matrix.det_mul, signFlip_det, hneg]
      norm_num
    · intro i a
      rw [mul_signFlip_preserves U unused i (e a) (hu a), hc]

/-- A strict active-dimension bound guarantees a spare orientation column. -/
theorem exists_specialOrthogonal_completion {N r : ℕ} (hr : r < N)
    (V : _root_.Matrix (Fin N) (Fin r) ℝ) (e : Fin r ↪ Fin N)
    (hV : V.transpose * V = 1) :
    ∃ U : _root_.Matrix (Fin N) (Fin N) ℝ,
      U.transpose * U = 1 ∧ U.det = 1 ∧ ∀ i a, U i (e a) = V i a := by
  have hn : ¬ Function.Surjective e := by
    intro hs
    have hcard := Fintype.card_le_of_surjective e hs
    simp only [Fintype.card_fin] at hcard
    omega
  simp only [Function.Surjective, not_forall] at hn
  obtain ⟨unused, hu⟩ := hn
  apply exists_specialOrthogonal_completion_of_unused V e hV unused
  intro a ha
  exact hu ⟨a, ha⟩

end QuantumBlockEncoding.RealIsometryCompletion
```

## QuantumBlockEncoding/ConstructiveIsometryLocal.lean

Raw-file SHA256: b5792942a1fecf68991b956668775fb07330f64ddc589867f67abe83644073fe

```lean
import QuantumBlockEncoding.ConstructiveIsometryCompletion
import QuantumBlockEncoding.TensorTrainLocalCompiler

/-! Deterministic SO completion at the actual local primitive-basis positions.
The old local module is used only for its explicit coordinates, active columns,
and their isometry theorem; none of its existential completion APIs is called.
No arithmetic evaluation-cost bound is asserted. -/

namespace QuantumBlockEncoding.ConstructiveIsometryLocal

open TensorTrainCanonical TensorTrainSchedule TensorTrainLocalCompiler
open ConstructiveIsometryCompletion

/-- Low bond wires, highest emitted bit, with an explicit finite coordinate map. -/
def coordinates (q : ℕ) : PrimitiveBasis (q + 1) ≃ Fin (2 * 2 ^ q) :=
  (localIndex q).trans finProdFinEquiv

noncomputable def localCompletion {q r : ℕ} (hr : r ≤ 2 ^ q)
    (V : _root_.Matrix (PrimitiveBasis (q + 1)) (Fin r) ℝ) :
    _root_.Matrix (PrimitiveBasis (q + 1)) (PrimitiveBasis (q + 1)) ℝ :=
  completeNamed (coordinates q) (by
    have : 0 < 2 ^ q := by positivity
    omega)
    V (activePositions hr)

theorem localCompletion_spec {q r : ℕ} (hr : r ≤ 2 ^ q)
    (V : _root_.Matrix (PrimitiveBasis (q + 1)) (Fin r) ℝ) (hV : V.transpose * V = 1) :
    (localCompletion hr V).transpose * localCompletion hr V = 1 ∧
    (localCompletion hr V).det = 1 ∧
    ∀ row a, localCompletion hr V row (activePositions hr a) = V row a :=
  completeNamed_spec (coordinates q) _ V (activePositions hr) hV

/-- Actual stage matrix derived from the chain's real occupied columns. -/
noncomputable def completeStage {n l r q : ℕ} (C : Chain n l r)
    (hB : maxBond C ≤ 2 ^ q) (t : ℕ) :
    _root_.Matrix (PrimitiveBasis (q + 1)) (PrimitiveBasis (q + 1)) ℝ :=
  localCompletion ((rankAt_le_maxBond C t).trans hB) (activeColumns C t hB)

theorem completeStage_spec {n l r q : ℕ} (C : Chain n l r)
    (hC : RightCanonical C) (hB : maxBond C ≤ 2 ^ q) (t : ℕ) (ht : t < n) :
    (completeStage C hB t).transpose * completeStage C hB t = 1 ∧
    (completeStage C hB t).det = 1 ∧
    ∀ (bit : Fin 2) (b a : PrimitiveBasis q),
      (primitiveBasisLEEquiv q a).val < rankAt C t →
      (completeStage C hB t (Fin.snoc b bit) (Fin.snoc a 0) : ℂ) =
        paddedAt C t (bit, primitiveBasisLEEquiv q b) (primitiveBasisLEEquiv q a) := by
  have hl : rankAt C t ≤ 2 ^ q := (rankAt_le_maxBond C t).trans hB
  obtain ⟨ho, hd, hc⟩ := localCompletion_spec hl (activeColumns C t hB)
    (activeColumns_isometry C hC hB t ht)
  refine ⟨ho, hd, ?_⟩
  intro bit b a ha
  let aa : Fin (rankAt C t) := ⟨(primitiveBasisLEEquiv q a).val, ha⟩
  have hcast : Fin.castLE hl aa = primitiveBasisLEEquiv q a := Fin.ext rfl
  have he : activePositions hl aa = Fin.snoc a 0 := by
    apply (localIndex q).injective
    change localIndex q ((localIndex q).symm (0, Fin.castLE hl aa)) =
      localIndex q (Fin.snoc a 0)
    rw [Equiv.apply_symm_apply, localIndex_snoc, hcast]
    rfl
  change (localCompletion hl (activeColumns C t hB) _ _ : ℂ) = _
  rw [← he, hc]
  change ((paddedAt C t (localIndex q (Fin.snoc b bit)) (Fin.castLE hl aa)).re : ℂ) = _
  rw [localIndex_snoc, hcast]
  exact paddedAt_real C t (bit, primitiveBasisLEEquiv q b) (primitiveBasisLEEquiv q a)

end QuantumBlockEncoding.ConstructiveIsometryLocal
```

## lean-toolchain

Raw-file SHA256: 302cd63c54178885b89e669f33b38f12f4dd7ae7e5cac537b3203e3768d8fb2b

```text
leanprover/lean4:v4.33.0
```

## lakefile.lean

Raw-file SHA256: f6637c3a2467fdeee6b2de72505d0581c4a49793388197bd8e9e7df3f5817fc1

```lean
import Lake
open Lake DSL

package aspbe where
  version := v!"0.1.0"

require VersoBlueprint from git
  "https://github.com/leanprover/verso-blueprint" @ "v4.33.0"

-- Keep Mathlib last so that its pins win when transitive dependencies overlap.
require mathlib from git
  "https://github.com/leanprover-community/mathlib4.git" @ "v4.33.0"

@[default_target]
lean_lib QuantumBlockEncoding

lean_lib Tests where
  roots := #[`Tests, `ABEISTests.Basic, `ABEISTests.QBenchIntegration,
    `ABEISTests.GHLHamiltonian]
  globs := #[.one `Tests, .submodules `ABEISTests]

lean_lib ABEISBlueprint

lean_exe blueprintGen where
  root := `ABEISBlueprintMain
  supportInterpreter := true
```

## lake-manifest.json

Raw-file SHA256: 510171e8214a2ac5e00f16c1bf92ad474d2de42c4cd2dc2b3d411272f7b58763

```json
{"version": "1.2.0",
 "packagesDir": ".lake/packages",
 "packages":
 [{"url": "https://github.com/leanprover-community/mathlib4.git",
   "type": "git",
   "subDir": null,
   "scope": "",
   "rev": "db584cd6d46c92f209a44c0f1c829460d327499d",
   "name": "mathlib",
   "manifestFile": "lake-manifest.json",
   "inputRev": "v4.33.0",
   "inherited": false,
   "configFile": "lakefile.lean"},
  {"url": "https://github.com/leanprover/verso-blueprint",
   "type": "git",
   "subDir": null,
   "scope": "",
   "rev": "e0d667222e8222ac4bfd74780f69a2e89cd4655f",
   "name": "VersoBlueprint",
   "manifestFile": "lake-manifest.json",
   "inputRev": "v4.33.0",
   "inherited": false,
   "configFile": "lakefile.lean"},
  {"url": "https://github.com/leanprover-community/plausible",
   "type": "git",
   "subDir": null,
   "scope": "leanprover-community",
   "rev": "b7eb3304aeae834b12dda98993a37f6a41f6f0bb",
   "name": "plausible",
   "manifestFile": "lake-manifest.json",
   "inputRev": "main",
   "inherited": true,
   "configFile": "lakefile.toml"},
  {"url": "https://github.com/leanprover-community/LeanSearchClient",
   "type": "git",
   "subDir": null,
   "scope": "leanprover-community",
   "rev": "5f4d51b81cbd3f6b32b156bfad9056621a040404",
   "name": "LeanSearchClient",
   "manifestFile": "lake-manifest.json",
   "inputRev": "main",
   "inherited": true,
   "configFile": "lakefile.toml"},
  {"url": "https://github.com/leanprover-community/import-graph",
   "type": "git",
   "subDir": null,
   "scope": "leanprover-community",
   "rev": "16f02aa7642864af59f1ff0e384a015994db9118",
   "name": "importGraph",
   "manifestFile": "lake-manifest.json",
   "inputRev": "main",
   "inherited": true,
   "configFile": "lakefile.toml"},
  {"url": "https://github.com/leanprover-community/ProofWidgets4",
   "type": "git",
   "subDir": null,
   "scope": "leanprover-community",
   "rev": "4be2e3d5087eeb272cf5a8853b8f9dd025ef5957",
   "name": "proofwidgets",
   "manifestFile": "lake-manifest.json",
   "inputRev": "main",
   "inherited": true,
   "configFile": "lakefile.lean"},
  {"url": "https://github.com/leanprover-community/aesop",
   "type": "git",
   "subDir": null,
   "scope": "leanprover-community",
   "rev": "3448c0bcc5ce01b2d1546e483ec3620e32df3d0e",
   "name": "aesop",
   "manifestFile": "lake-manifest.json",
   "inputRev": "master",
   "inherited": true,
   "configFile": "lakefile.toml"},
  {"url": "https://github.com/leanprover-community/quote4",
   "type": "git",
   "subDir": null,
   "scope": "leanprover-community",
   "rev": "92c15be17b7caf78c2ad767ec40f89052d908d81",
   "name": "Qq",
   "manifestFile": "lake-manifest.json",
   "inputRev": "master",
   "inherited": true,
   "configFile": "lakefile.toml"},
  {"url": "https://github.com/leanprover-community/batteries",
   "type": "git",
   "subDir": null,
   "scope": "leanprover-community",
   "rev": "4488d40d070b9700d4d5a6aa342f0d40c31b2a2d",
   "name": "batteries",
   "manifestFile": "lake-manifest.json",
   "inputRev": "main",
   "inherited": true,
   "configFile": "lakefile.toml"},
  {"url": "https://github.com/leanprover/verso-slides",
   "type": "git",
   "subDir": null,
   "scope": "",
   "rev": "ddea15f92035c6de1d76e3afa5476f7ab3de955d",
   "name": "«verso-slides»",
   "manifestFile": "lake-manifest.json",
   "inputRev": "v4.33.0",
   "inherited": true,
   "configFile": "lakefile.lean"},
  {"url": "https://github.com/leanprover/verso",
   "type": "git",
   "subDir": null,
   "scope": "",
   "rev": "36664a0ebe032ef3f9e72a8ed0d7be9b14af17d2",
   "name": "verso",
   "manifestFile": "lake-manifest.json",
   "inputRev": "36664a0ebe032ef3f9e72a8ed0d7be9b14af17d2",
   "inherited": true,
   "configFile": "lakefile.lean"},
  {"url": "https://github.com/leanprover/lean4-cli",
   "type": "git",
   "subDir": null,
   "scope": "leanprover",
   "rev": "6130a47896ce867c6a4a55373441e59e565bad0f",
   "name": "Cli",
   "manifestFile": "lake-manifest.json",
   "inputRev": "v4.33.0",
   "inherited": true,
   "configFile": "lakefile.toml"},
  {"url": "https://github.com/leanprover/illuminate",
   "type": "git",
   "subDir": null,
   "scope": "",
   "rev": "6bc815869cba1f19515715dc6b47795acd521f1c",
   "name": "illuminate",
   "manifestFile": "lake-manifest.json",
   "inputRev": "main",
   "inherited": true,
   "configFile": "lakefile.lean"},
  {"url": "https://github.com/acmepjz/md4lean",
   "type": "git",
   "subDir": null,
   "scope": "",
   "rev": "31907cc18f48a95384f99cee5582c00fb39e0f67",
   "name": "MD4Lean",
   "manifestFile": "lake-manifest.json",
   "inputRev": "main",
   "inherited": true,
   "configFile": "lakefile.lean"},
  {"url": "https://github.com/leanprover/subverso",
   "type": "git",
   "subDir": null,
   "scope": "",
   "rev": "3a75ede05278806fd3249bb0c97a6fb5777a4f7d",
   "name": "subverso",
   "manifestFile": "lake-manifest.json",
   "inputRev": "main",
   "inherited": true,
   "configFile": "lakefile.lean"}],
 "name": "aspbe",
 "lakeDir": ".lake",
 "fixedToolchain": false}
```

## QuantumBlockEncoding/ConstructiveIsometryCompletion.lean

Raw-file SHA256: 1b61cbc9ad587cc2ae2a7cdc7bacd3b7d39fb05274833a3fea5dbb4dff69678c

```lean
import QuantumBlockEncoding.AdjacentGivens
import QuantumBlockEncoding.RealIsometryCompletion
import QuantumBlockEncoding.RectangularGivens

/-!+# Deterministic completion of prescribed real isometry columns

The producers in this module use explicit finite rotations and permutations,
not orthonormal-basis extension or an existential matrix witness. The exact
real formulas are noncomputable Lean definitions; no classical evaluation-cost
bound is asserted here.
-/

namespace QuantumBlockEncoding.ConstructiveIsometryCompletion

open scoped BigOperators
open AdjacentGivens

/-- The first `k` rectangular columns are their corresponding coordinate vectors. -/
def PrefixColumns {N r : ℕ} (V : _root_.Matrix (Fin N) (Fin r) ℝ)
    (hr : r ≤ N) (k : ℕ) : Prop :=
  ∀ col : Fin r, col.val < k → ∀ row : Fin N,
    V row col = if row = Fin.castLE hr col then 1 else 0

theorem rotateRows_isometry {N r : ℕ} (V : _root_.Matrix (Fin N) (Fin r) ℝ)
    (hV : V.transpose * V = 1) (i j : Fin N) (hij : i ≠ j) (theta : ℝ) :
    (rotateRows V i j theta).transpose * rotateRows V i j theta = 1 := by
  rw [← planeMatrix_mul, _root_.Matrix.transpose_mul]
  calc
    _ = V.transpose * ((planeMatrix i j theta).transpose * planeMatrix i j theta) * V := by
      simp only [_root_.Matrix.mul_assoc]
    _ = 1 := by rw [planeMatrix_orthogonal i j hij, _root_.Matrix.mul_one, hV]

theorem columnSweep_isometry {N r : ℕ} (V : _root_.Matrix (Fin N) (Fin r) ℝ)
    (hV : V.transpose * V = 1) (col : Fin r) (lo count : ℕ) (bound : lo + count < N) :
    (columnSweep V col lo count bound).transpose * columnSweep V col lo count bound = 1 := by
  induction count generalizing V with
  | zero => exact hV
  | succ count ih =>
    rw [columnSweep]
    apply ih
    apply rotateRows_isometry V hV
    intro equal
    have := congrArg Fin.val equal
    change lo + count = lo + count + 1 at this
    omega

theorem zero_of_fixed_column {N r : ℕ} (V : _root_.Matrix (Fin N) (Fin r) ℝ)
    (hr : r ≤ N) (hV : V.transpose * V = 1) (old col : Fin r) (different : old ≠ col)
    (fixed : ∀ row, V row old = if row = Fin.castLE hr old then 1 else 0) :
    V (Fin.castLE hr old) col = 0 := by
  have entry := congrFun (congrFun hV old) col
  simpa [_root_.Matrix.mul_apply, _root_.Matrix.transpose_apply,
    fixed, _root_.Matrix.one_apply, different] using entry

theorem columnSweep_prefix {N r : ℕ} (V : _root_.Matrix (Fin N) (Fin r) ℝ)
    (hr : r ≤ N) (col : Fin r) (count : ℕ) (bound : col.val + count < N)
    (fixed : PrefixColumns V hr col.val) :
    PrefixColumns (columnSweep V col col.val count bound) hr col.val := by
  intro old oldLt row
  rw [columnSweep_preserves_zero_column]
  · exact fixed old oldLt row
  · intro i lower upper
    rw [fixed old oldLt i, if_neg]
    intro equal
    have := congrArg Fin.val equal
    change i.val = old.val at this
    omega

theorem supported_column_sq {N r : ℕ} (V : _root_.Matrix (Fin N) (Fin r) ℝ)
    (hr : r ≤ N) (hV : V.transpose * V = 1) (col : Fin r)
    (support : ∀ row, row ≠ Fin.castLE hr col → V row col = 0) :
    V (Fin.castLE hr col) col ^ 2 = 1 := by
  have entry := congrFun (congrFun hV col) col
  have collapse : (∑ row, V row col * V row col) =
      V (Fin.castLE hr col) col * V (Fin.castLE hr col) col := by
    apply Finset.sum_eq_single (Fin.castLE hr col)
    · intro row _ different
      rw [support row different]
      simp
    · intro missing
      exact False.elim (missing (Finset.mem_univ _))
  simp only [_root_.Matrix.mul_apply, _root_.Matrix.transpose_apply,
    _root_.Matrix.one_apply_eq] at entry
  rw [collapse] at entry
  simpa [sq] using entry

/-- A nonfinal rectangular isometry column is swept to a positive unit pivot. -/
theorem columnSweep_prefix_succ {N r : ℕ} (V : _root_.Matrix (Fin N) (Fin r) ℝ)
    (hr : r ≤ N) (hV : V.transpose * V = 1) (col : Fin r) (count : ℕ)
    (dimension : col.val + count + 1 = N) (positive : 0 < count)
    (fixed : PrefixColumns V hr col.val) :
    PrefixColumns (columnSweep V col col.val count (by omega)) hr (col.val + 1) := by
  let W := columnSweep V col col.val count (by omega)
  have hW : W.transpose * W = 1 := columnSweep_isometry V hV _ _ _ _
  have prefixW : PrefixColumns W hr col.val := columnSweep_prefix V hr col count _ fixed
  have support (row : Fin N) (different : row ≠ Fin.castLE hr col) : W row col = 0 := by
    by_cases below : col.val < row.val
    · exact columnSweep_zeroed V col col.val count _ row below (by omega)
    · have above : row.val < col.val := by
        have notEqual : row.val ≠ col.val := fun equal => different (Fin.ext equal)
        omega
      let old : Fin r := ⟨row.val, lt_trans above col.isLt⟩
      have oldLt : old.val < col.val := above
      have distinct : old ≠ col := by
        intro equal
        have := congrArg Fin.val equal
        omega
      have castOld : Fin.castLE hr old = row := Fin.ext rfl
      rw [← castOld]
      exact zero_of_fixed_column W hr hW old col distinct (prefixW old oldLt)
  have normSq := supported_column_sq W hr hW col support
  have nonneg : 0 ≤ W (Fin.castLE hr col) col :=
    columnSweep_pivot_nonneg V col col.val count _ positive
  have pivot : W (Fin.castLE hr col) col = 1 := by nlinarith
  intro old oldLt row
  by_cases same : old = col
  · subst old
    by_cases hit : row = Fin.castLE hr col
    · simpa [hit] using pivot
    · simpa [hit] using support row hit
  · exact prefixW old (by
      have notEqual : old.val ≠ col.val := fun equal => same (Fin.ext equal)
      omega) row

/-- The shared rectangular sweep fixes every processed isometry column. -/
theorem sweep_prefix {N r : ℕ} (V : _root_.Matrix (Fin N) (Fin r) ℝ)
    (hr : r < N) (hV : V.transpose * V = 1)
    (k remaining : ℕ) (columns : k + remaining ≤ r) (fixed : PrefixColumns V hr.le k) :
    PrefixColumns (RectangularGivens.sweep V k remaining columns) hr.le (k + remaining) := by
  induction remaining generalizing V k with
  | zero => simpa [RectangularGivens.sweep] using fixed
  | succ remaining ih =>
    have hk : k < N := by omega
    rw [RectangularGivens.sweep, dif_pos hk]
    have next := columnSweep_prefix_succ V hr.le hV ⟨k, by omega⟩ (N - 1 - k)
      (by change k + (N - 1 - k) + 1 = N; omega) (by omega) fixed
    have result := ih _ (columnSweep_isometry V hV _ _ _ _) (k + 1) (by omega) next
    simpa only [Nat.add_assoc, Nat.add_left_comm, Nat.add_comm] using result

theorem reduced_prefix {N r : ℕ} (V : _root_.Matrix (Fin N) (Fin r) ℝ)
    (hr : r < N) (hV : V.transpose * V = 1) :
    PrefixColumns (RectangularGivens.reduced V) hr.le r := by
  simpa [RectangularGivens.reduced] using
    sweep_prefix V hr hV 0 r (by omega) (by intro col impossible; omega)

/-- Inverse of the explicitly computed row rotations; no matrix witness is chosen. -/
noncomputable def prefixCompletion {N r : ℕ} (V : _root_.Matrix (Fin N) (Fin r) ℝ) :
    _root_.Matrix (Fin N) (Fin N) ℝ := (RectangularGivens.transform V).transpose

theorem prefixCompletion_orthogonal {N r : ℕ} (V : _root_.Matrix (Fin N) (Fin r) ℝ) :
    (prefixCompletion V).transpose * prefixCompletion V = 1 := by
  simp only [prefixCompletion, _root_.Matrix.transpose_transpose]
  exact mul_eq_one_comm.mp (RectangularGivens.transform_orthogonal V)

theorem prefixCompletion_det {N r : ℕ} (V : _root_.Matrix (Fin N) (Fin r) ℝ) :
    (prefixCompletion V).det = 1 := by
  rw [prefixCompletion, _root_.Matrix.det_transpose, RectangularGivens.transform_det]

theorem prefixCompletion_columns {N r : ℕ} (V : _root_.Matrix (Fin N) (Fin r) ℝ)
    (hr : r < N) (hV : V.transpose * V = 1) (row : Fin N) (col : Fin r) :
    prefixCompletion V row (Fin.castLE hr.le col) = V row col := by
  have h := congrFun (congrFun (RectangularGivens.exact_recovery V) row) col
  have hc := reduced_prefix V hr hV col col.isLt
  simpa [prefixCompletion, _root_.Matrix.mul_apply, hc] using h

/-- Greedy swaps deterministically extend a finite prefix injection. -/
def extendPrefix {N r : ℕ} (hr : r ≤ N) (e : Fin r ↪ Fin N) :
    (k : ℕ) → k ≤ r → Equiv.Perm (Fin N)
  | 0, _ => Equiv.refl _
  | k + 1, hk =>
      let p := extendPrefix hr e k (by omega)
      p.trans (Equiv.swap (p ⟨k, by omega⟩) (e ⟨k, by omega⟩))

theorem extendPrefix_agrees {N r : ℕ} (hr : r ≤ N) (e : Fin r ↪ Fin N)
    (k : ℕ) (hk : k ≤ r) (a : Fin r) (ha : a.val < k) :
    extendPrefix hr e k hk (Fin.castLE hr a) = e a := by
  induction k with
  | zero => omega
  | succ k ih =>
    simp only [extendPrefix, Equiv.trans_apply]
    by_cases last : a.val = k
    · have ea : (⟨k, by omega⟩ : Fin r) = a := Fin.ext last.symm
      have ia : (⟨k, by omega⟩ : Fin N) = Fin.castLE hr a := Fin.ext last.symm
      rw [ea, ia, Equiv.swap_apply_left]
    · have early : a.val < k := by omega
      have agree := ih (by omega) early
      rw [Equiv.swap_apply_of_ne_of_ne, agree]
      · intro equal
        have same := (extendPrefix hr e k (by omega)).injective equal
        have := congrArg Fin.val same
        change a.val = k at this
        omega
      · intro equal
        rw [agree] at equal
        have same := e.injective equal
        have := congrArg Fin.val same
        change a.val = k at this
        omega

/-- The first unused original coordinate is carried to an unused physical label. -/
def unusedPosition {N r : ℕ} (hr : r < N) (e : Fin r ↪ Fin N) : Fin N :=
  extendPrefix hr.le e r le_rfl ⟨r, hr⟩

theorem unusedPosition_ne {N r : ℕ} (hr : r < N) (e : Fin r ↪ Fin N) (a : Fin r) :
    e a ≠ unusedPosition hr e := by
  rw [← extendPrefix_agrees hr.le e r le_rfl a a.isLt]
  intro equal
  have same := (extendPrefix hr.le e r le_rfl).injective equal
  have := congrArg Fin.val same
  change a.val = r at this
  omega

/-- Send original column `a` to physical column `p a`. -/
def permuteColumns {N : ℕ} (U : _root_.Matrix (Fin N) (Fin N) ℝ)
    (p : Equiv.Perm (Fin N)) : _root_.Matrix (Fin N) (Fin N) ℝ :=
  U.submatrix id p.symm

@[simp] theorem permuteColumns_apply {N : ℕ} (U : _root_.Matrix (Fin N) (Fin N) ℝ)
    (p : Equiv.Perm (Fin N)) (row col : Fin N) :
    permuteColumns U p row (p col) = U row col := by
  simp [permuteColumns, _root_.Matrix.submatrix_apply]

theorem permuteColumns_orthogonal {N : ℕ} (U : _root_.Matrix (Fin N) (Fin N) ℝ)
    (hU : U.transpose * U = 1) (p : Equiv.Perm (Fin N)) :
    (permuteColumns U p).transpose * permuteColumns U p = 1 := by
  ext i j
  have h := congrFun (congrFun hU (p.symm i)) (p.symm j)
  simpa [permuteColumns, _root_.Matrix.submatrix_apply, _root_.Matrix.mul_apply,
    _root_.Matrix.transpose_apply, _root_.Matrix.one_apply] using h

theorem permuteColumns_det {N : ℕ} (U : _root_.Matrix (Fin N) (Fin N) ℝ)
    (p : Equiv.Perm (Fin N)) :
    (permuteColumns U p).det = (Equiv.Perm.sign p : ℤ) * U.det := by
  simpa [permuteColumns] using _root_.Matrix.det_permute' p.symm U

/-- Correct only an unused column, using finite permutation parity, not a determinant test. -/
noncomputable def orientColumns {N : ℕ} (U : _root_.Matrix (Fin N) (Fin N) ℝ)
    (p : Equiv.Perm (Fin N)) (unused : Fin N) : _root_.Matrix (Fin N) (Fin N) ℝ :=
  if Equiv.Perm.sign p = 1 then permuteColumns U p
  else permuteColumns U p * RealIsometryCompletion.signFlip unused

theorem orientColumns_orthogonal {N : ℕ} (U : _root_.Matrix (Fin N) (Fin N) ℝ)
    (hU : U.transpose * U = 1) (p : Equiv.Perm (Fin N)) (unused : Fin N) :
    (orientColumns U p unused).transpose * orientColumns U p unused = 1 := by
  unfold orientColumns
  split_ifs
  · exact permuteColumns_orthogonal U hU p
  · rw [_root_.Matrix.transpose_mul]
    calc
      _ = (RealIsometryCompletion.signFlip unused).transpose *
          ((permuteColumns U p).transpose * permuteColumns U p) *
          RealIsometryCompletion.signFlip unused := by simp only [_root_.Matrix.mul_assoc]
      _ = 1 := by rw [permuteColumns_orthogonal U hU p, _root_.Matrix.mul_one,
        RealIsometryCompletion.signFlip_orthogonal]

theorem orientColumns_det {N : ℕ} (U : _root_.Matrix (Fin N) (Fin N) ℝ)
    (hU : U.det = 1) (p : Equiv.Perm (Fin N)) (unused : Fin N) :
    (orientColumns U p unused).det = 1 := by
  unfold orientColumns
  split_ifs with positive
  · rw [permuteColumns_det, hU, positive]
    norm_num
  · have negative : Equiv.Perm.sign p = -1 :=
      (Int.units_eq_one_or (Equiv.Perm.sign p)).resolve_left positive
    rw [_root_.Matrix.det_mul, permuteColumns_det, RealIsometryCompletion.signFlip_det,
      hU, negative]
    norm_num

theorem orientColumns_preserves {N : ℕ} (U : _root_.Matrix (Fin N) (Fin N) ℝ)
    (p : Equiv.Perm (Fin N)) (unused row col : Fin N) (hcol : p col ≠ unused) :
    orientColumns U p unused row (p col) = U row col := by
  unfold orientColumns
  split_ifs
  · exact permuteColumns_apply U p row col
  · rw [RealIsometryCompletion.mul_signFlip_preserves _ _ _ _ hcol,
      permuteColumns_apply]

/-- Explicit physical-column placement of a prefix SO completion. -/
noncomputable def placeColumns {N r : ℕ} (hr : r < N) (e : Fin r ↪ Fin N)
    (U : _root_.Matrix (Fin N) (Fin N) ℝ) : _root_.Matrix (Fin N) (Fin N) ℝ :=
  orientColumns U (extendPrefix hr.le e r le_rfl) (unusedPosition hr e)

theorem placeColumns_spec {N r : ℕ} (hr : r < N) (e : Fin r ↪ Fin N)
    (U : _root_.Matrix (Fin N) (Fin N) ℝ) (hU : U.transpose * U = 1) (hd : U.det = 1) :
    (placeColumns hr e U).transpose * placeColumns hr e U = 1 ∧
    (placeColumns hr e U).det = 1 ∧
    ∀ row a, placeColumns hr e U row (e a) = U row (Fin.castLE hr.le a) := by
  refine ⟨orientColumns_orthogonal U hU _ _, orientColumns_det U hd _ _, ?_⟩
  intro row a
  have agree := extendPrefix_agrees hr.le e r le_rfl a a.isLt
  change orientColumns U _ _ row (e a) = _
  rw [← agree]
  apply orientColumns_preserves
  rw [agree]
  exact unusedPosition_ne hr e a

/-- Actual deterministic SO matrix with columns at the prescribed physical positions. -/
noncomputable def complete {N r : ℕ} (hr : r < N)
    (V : _root_.Matrix (Fin N) (Fin r) ℝ) (e : Fin r ↪ Fin N) :
    _root_.Matrix (Fin N) (Fin N) ℝ := placeColumns hr e (prefixCompletion V)

/-- The supplied hypothesis is only the input column isometry; the returned
matrix is computed by the named producer, not supplied or selected existentially. -/
theorem complete_spec {N r : ℕ} (hr : r < N)
    (V : _root_.Matrix (Fin N) (Fin r) ℝ) (e : Fin r ↪ Fin N)
    (hV : V.transpose * V = 1) :
    (complete hr V e).transpose * complete hr V e = 1 ∧
    (complete hr V e).det = 1 ∧ ∀ row a, complete hr V e row (e a) = V row a := by
  obtain ⟨ho, hd, hc⟩ := placeColumns_spec hr e (prefixCompletion V)
    (prefixCompletion_orthogonal V) (prefixCompletion_det V)
  refine ⟨ho, hd, ?_⟩
  intro row a
  exact (hc row a).trans (prefixCompletion_columns V hr hV row a)

/-- Transport using a supplied explicit coordinate equivalence, not an arbitrary
enumeration chosen for the named basis. -/
noncomputable def completeNamed {I : Type*} [Fintype I] [DecidableEq I] {N r : ℕ}
    (coordinates : I ≃ Fin N) (hr : r < N)
    (V : _root_.Matrix I (Fin r) ℝ) (e : Fin r ↪ I) : _root_.Matrix I I ℝ :=
  _root_.Matrix.reindex coordinates.symm coordinates.symm
    (complete hr (V.submatrix coordinates.symm id) (e.trans coordinates.toEmbedding))

theorem completeNamed_spec {I : Type*} [Fintype I] [DecidableEq I] {N r : ℕ}
    (coordinates : I ≃ Fin N) (hr : r < N)
    (V : _root_.Matrix I (Fin r) ℝ) (e : Fin r ↪ I) (hV : V.transpose * V = 1) :
    (completeNamed coordinates hr V e).transpose * completeNamed coordinates hr V e = 1 ∧
    (completeNamed coordinates hr V e).det = 1 ∧
    ∀ row a, completeNamed coordinates hr V e row (e a) = V row a := by
  let W := V.submatrix coordinates.symm id
  have hW : W.transpose * W = 1 := by
    ext a b
    have h := congrFun (congrFun hV a) b
    simp only [_root_.Matrix.mul_apply, _root_.Matrix.transpose_apply] at h ⊢
    exact ((coordinates.symm).sum_comp (fun i => V i a * V i b)).trans h
  let U := complete hr W (e.trans coordinates.toEmbedding)
  obtain ⟨ho, hd, hc⟩ := complete_spec hr W (e.trans coordinates.toEmbedding) hW
  let tr := _root_.Matrix.reindexAlgEquiv ℝ ℝ coordinates.symm
  change (tr U).transpose * tr U = 1 ∧ (tr U).det = 1 ∧
    ∀ row a, tr U row (e a) = V row a
  refine ⟨?_, ?_, ?_⟩
  · change tr U.transpose * tr U = 1
    rw [← map_mul, ho, map_one]
  · simpa [tr, _root_.Matrix.reindexAlgEquiv_apply] using hd
  · intro row a
    simpa [tr, U, W, _root_.Matrix.reindexAlgEquiv_apply,
      _root_.Matrix.reindex_apply, _root_.Matrix.submatrix_apply] using hc (coordinates row) a

end QuantumBlockEncoding.ConstructiveIsometryCompletion
```

## QuantumBlockEncoding/TensorTrainLocalCompiler.lean

Raw-file SHA256: ba397af87d9faf52be581f4d87e414c50821fa438541f7fbc6ef801e6acb88e2

```lean
import QuantumBlockEncoding.TensorTrainSchedule
import QuantumBlockEncoding.RealIsometryCompletion
import QuantumBlockEncoding.GrayGivensCompiler

namespace QuantumBlockEncoding.TensorTrainLocalCompiler

open scoped BigOperators
open TensorTrainCanonical TensorTrainSchedule SequentialBondPreparation

/-- Coordinate adapter for special-orthogonal completion on any finite
named basis, with prescribed columns at arbitrary physical labels. -/
theorem exists_SO_named {I : Type*} [Fintype I] [DecidableEq I] {r : ℕ}
    (hr : r < Fintype.card I) (V : _root_.Matrix I (Fin r) ℝ) (e : Fin r ↪ I)
    (hV : V.transpose * V = 1) :
    ∃ U : _root_.Matrix I I ℝ, U.transpose * U = 1 ∧ U.det = 1 ∧
      ∀ i a, U i (e a) = V i a := by
  classical
  let f := Fintype.equivFin I
  let W : _root_.Matrix (Fin (Fintype.card I)) (Fin r) ℝ := fun i a => V (f.symm i) a
  have hW : W.transpose * W = 1 := by
    ext a b
    have h := congrFun (congrFun hV a) b
    simp only [_root_.Matrix.mul_apply, _root_.Matrix.transpose_apply] at h ⊢
    exact ((f.symm).sum_comp (fun i => V i a * V i b)).trans h
  obtain ⟨U, hU, hd, hc⟩ := RealIsometryCompletion.exists_specialOrthogonal_completion
    hr W (e.trans f.toEmbedding) hW
  let tr := _root_.Matrix.reindexAlgEquiv ℝ ℝ f.symm
  refine ⟨tr U, ?_, ?_, ?_⟩
  · change tr U.transpose * tr U = 1
    rw [← map_mul, hU, map_one]
  · simpa [tr, _root_.Matrix.reindexAlgEquiv_apply] using hd
  · intro i a
    simpa [tr, W, _root_.Matrix.reindexAlgEquiv_apply, _root_.Matrix.reindex_apply] using hc (f i) a

/-- The bit is the highest local physical wire; the bond uses low wires. -/
def localIndex (q : ℕ) : PrimitiveBasis (q + 1) ≃ Fin 2 × Fin (2 ^ q) :=
  (localBasisEquiv q).trans (Equiv.prodCongr (Equiv.refl _) (primitiveBasisLEEquiv q))

@[simp] theorem localIndex_snoc (q : ℕ) (b : PrimitiveBasis q) (bit : Fin 2) :
    localIndex q (Fin.snoc b bit) = (bit, primitiveBasisLEEquiv q b) := by
  simp [localIndex, localBasisEquiv, RealAmplitudePreparation.lastBasisEquiv]
  rfl

theorem paddedAt_real {n l r B : ℕ} (C : Chain n l r) (t : ℕ)
    (out : Fin 2 × Fin B) (a : Fin B) :
    ((paddedAt C t out a).re : ℂ) = paddedAt C t out a := by
  induction C generalizing t with
  | nil _ => simp [paddedAt]
  | cons A C ih =>
    cases t with
    | zero =>
      simp only [paddedAt, paddedCore]
      split_ifs <;> simp
    | succ t => exact ih t

theorem paddedAt_im_zero {n l r B : ℕ} (C : Chain n l r) (t : ℕ)
    (out : Fin 2 × Fin B) (a : Fin B) : (paddedAt C t out a).im = 0 := by
  have h := congrArg Complex.im (paddedAt_real C t out a)
  simpa only [Complex.ofReal_im] using h.symm

def activePositions {q l : ℕ} (hl : l ≤ 2 ^ q) : Fin l ↪ PrimitiveBasis (q + 1) where
  toFun a := (localIndex q).symm (0, Fin.castLE hl a)
  inj' a b h := by
    have he := congrArg (fun x => ((localIndex q) x).2.val) h
    apply Fin.ext
    simpa only [Equiv.apply_symm_apply, Fin.castLE] using he

/-- The occupied real columns of a padded core, in physical named-wire order. -/
def activeColumns {n l r q : ℕ} (C : Chain n l r) (t : ℕ)
    (hB : maxBond C ≤ 2 ^ q) :
    _root_.Matrix (PrimitiveBasis (q + 1)) (Fin (rankAt C t)) ℝ :=
  fun row a => (paddedAt C t (localIndex q row)
    (Fin.castLE ((rankAt_le_maxBond C t).trans hB) a)).re

/-- Exact real orthonormality is extracted from the proved complex padded-core
semantics; no ambient matrix or desired circuit action is assumed. -/
theorem activeColumns_isometry {n l r q : ℕ} (C : Chain n l r)
    (hC : RightCanonical C) (hB : maxBond C ≤ 2 ^ q) (t : ℕ) (ht : t < n) :
    (activeColumns C t hB).transpose * activeColumns C t hB = 1 := by
  classical
  ext a c
  have h := congrArg Complex.re (paddedAt_active_isometry C hC hB t ht a c)
  have hr : (∑ out : Fin 2 × Fin (2 ^ q),
      (paddedAt C t out (Fin.castLE ((rankAt_le_maxBond C t).trans hB) a)).re *
        (paddedAt C t out (Fin.castLE ((rankAt_le_maxBond C t).trans hB) c)).re) =
      if a = c then 1 else 0 := by
    by_cases hac : a = c <;>
      simpa [hac, map_sum, Complex.mul_re, Complex.star_def, paddedAt_im_zero] using h
  simp only [_root_.Matrix.mul_apply, _root_.Matrix.transpose_apply,
    _root_.Matrix.one_apply, activeColumns]
  exact ((localIndex q).sum_comp (fun out =>
    (paddedAt C t out (Fin.castLE ((rankAt_le_maxBond C t).trans hB) a)).re *
      (paddedAt C t out (Fin.castLE ((rankAt_le_maxBond C t).trans hB) c)).re)).trans hr

/-- Every actual canonical stage has an exact primitive implementation on the
`q` low bond wires and one highest output wire. Completion has a spare column
because the active rank is at most half the physical dimension. The existence
proof uses exact real choices and is not a classical preprocessing-cost bound. -/
theorem exists_local_circuit_with_resources {n l r q : ℕ} (C : Chain n l r)
    (hC : RightCanonical C) (hB : maxBond C ≤ 2 ^ q) (t : ℕ) (ht : t < n) :
    ∃ c : PrimitiveCircuit (q + 1),
      c.gateCount ≤ 6 * (2 ^ q) ^ 3 ∧ c.resource.oracleCalls = 0 ∧
      ∀ (bit : Fin 2) (b a : PrimitiveBasis q),
        (primitiveBasisLEEquiv q a).val < rankAt C t →
        evalPrimitiveCircuit c (Fin.snoc b bit) (Fin.snoc a 0) =
          paddedAt C t (bit, primitiveBasisLEEquiv q b) (primitiveBasisLEEquiv q a) := by
  classical
  have hl : rankAt C t ≤ 2 ^ q := (rankAt_le_maxBond C t).trans hB
  have hs : rankAt C t < Fintype.card (PrimitiveBasis (q + 1)) := by
    have hp : 0 < 2 ^ q := by positivity
    have hc : Fintype.card (PrimitiveBasis (q + 1)) = 2 ^ q * 2 := by
      simp [PrimitiveBasis, pow_succ]
    rw [hc]
    omega
  obtain ⟨U, hU, hd, columns⟩ := exists_SO_named hs (activeColumns C t hB)
    (activePositions hl) (activeColumns_isometry C hC hB t ht)
  refine ⟨GrayGivensCompiler.compileSO U,
    (GrayGivensCompiler.compileSO_cubic_bound U).1,
    (GrayGivensCompiler.compileSO_cubic_bound U).2, ?_⟩
  intro bit b a ha
  let aa : Fin (rankAt C t) := ⟨(primitiveBasisLEEquiv q a).val, ha⟩
  have hcast : Fin.castLE hl aa = primitiveBasisLEEquiv q a := by
    apply Fin.ext
    rfl
  have he : activePositions hl aa = Fin.snoc a 0 := by
    apply (localIndex q).injective
    change localIndex q ((localIndex q).symm (0, Fin.castLE hl aa)) =
      localIndex q (Fin.snoc a 0)
    rw [Equiv.apply_symm_apply, localIndex_snoc, hcast]
    rfl
  rw [GrayGivensCompiler.compileSO_eval U hU hd]
  change (U (Fin.snoc b bit) (Fin.snoc a 0) : ℂ) = _
  rw [← he, columns]
  change ((paddedAt C t (localIndex q (Fin.snoc b bit)) (Fin.castLE hl aa)).re : ℂ) = _
  rw [localIndex_snoc, hcast]
  exact paddedAt_real C t (bit, primitiveBasisLEEquiv q b) (primitiveBasisLEEquiv q a)

/-- Minimal local-column interface for sequential tensor-train assembly. -/
theorem exists_local_circuit {n l r q : ℕ} (C : Chain n l r)
    (hC : RightCanonical C) (hB : maxBond C ≤ 2 ^ q) (t : ℕ) (ht : t < n) :
    ∃ c : PrimitiveCircuit (q + 1), c.gateCount ≤ 6 * (2 ^ q) ^ 3 ∧
      ∀ (bit : Fin 2) (b a : PrimitiveBasis q),
        (primitiveBasisLEEquiv q a).val < rankAt C t →
        evalPrimitiveCircuit c (Fin.snoc b bit) (Fin.snoc a 0) =
          paddedAt C t (bit, primitiveBasisLEEquiv q b) (primitiveBasisLEEquiv q a) := by
  obtain ⟨c, hc, _, columns⟩ := exists_local_circuit_with_resources C hC hB t ht
  exact ⟨c, hc, columns⟩

end QuantumBlockEncoding.TensorTrainLocalCompiler
```

## QuantumBlockEncoding/TensorTrainSchedule.lean

Raw-file SHA256: 2cd10d741a8655132286cbba741293b6ab2a89c713d8553beebd2820b0aab8e3

```lean
import QuantumBlockEncoding.TensorTrainCanonical

/-!
# Dependent tensor trains in a fixed padded sequential register

Extract the actual active ranks and local padded cores from a dependent chain.
Bits are emitted in increasing wire order. Theorems below concern exact matrix
action; local primitive synthesis and global wire placement are separate.
-/

namespace QuantumBlockEncoding.TensorTrainSchedule

open scoped BigOperators
open TensorTrainCanonical
open SequentialBondPreparation

/-- Convert increasing-wire basis labels to the head-first chain word. -/
def wordOfBasis : {n : ℕ} → PrimitiveBasis n → Word n
  | 0, _ => ()
  | _ + 1, x => (x 0, wordOfBasis (Fin.tail x))

/-- Active rank before stage `t`; after the chain it is the terminal rank. -/
def rankAt : {n l r : ℕ} → Chain n l r → ℕ → ℕ
  | _, _, _, .nil r, _ => r
  | _, l, _, .cons _ _, 0 => l
  | _, _, _, .cons _ C, t + 1 => rankAt C t

@[simp] theorem rankAt_zero {n l r : ℕ} (C : Chain n l r) : rankAt C 0 = l := by
  cases C <;> rfl

@[simp] theorem rankAt_length {n l r : ℕ} (C : Chain n l r) : rankAt C n = r := by
  induction C with
  | nil _ => rfl
  | cons _ _ ih => exact ih

/-- The finite schedule, zero after the final core. Later stages are never
used by the bounded run theorem. -/
def paddedAt {B : ℕ} : {n l r : ℕ} → Chain n l r → ℕ →
    SequentialBondPreparation.Core (Fin B)
  | _, _, _, .nil _, _ => 0
  | _, _, _, .cons A _, 0 => paddedCore A
  | _, _, _, .cons _ C, t + 1 => paddedAt C t

theorem rankAt_le_maxBond {n l r : ℕ} (C : Chain n l r) (t : ℕ) :
    rankAt C t ≤ maxBond C := by
  induction C generalizing t with
  | nil _ => exact le_rfl
  | @cons n l m r A C ih =>
    cases t with
    | zero => exact le_max_left _ _
    | succ t => exact (ih t).trans (le_max_right _ _)

/-- Zero amplitude outside the next actual rank, for the extracted schedule. -/
theorem paddedAt_supported {n l r B : ℕ} (C : Chain n l r) (t : ℕ)
    (bit : Fin 2) (b a : Fin B) (hb : rankAt C (t + 1) ≤ b.val) :
    paddedAt C t (bit, b) a = 0 := by
  induction C generalizing t with
  | nil _ => rfl
  | @cons n l m r A C ih =>
    cases t with
    | zero =>
      apply paddedCore_inactive_output
      simpa only [rankAt, rankAt_zero] using hb
    | succ t => exact ih t hb

/-- Rewrite chronological transfer in first-bit order, matching `Chain.cons`.
The algebra still multiplies the last emitted matrix on the left. -/
theorem transfer_shift {B : Type*} [Fintype B] [DecidableEq B]
    (K : ℕ → SequentialBondPreparation.Core B) (n : ℕ)
    (x : PrimitiveBasis (n + 1)) :
    transfer K (n + 1) x =
      transfer (fun t => K (t + 1)) n (Fin.tail x) * coreSlice (K 0) (x 0) := by
  induction n with
  | zero => simp [transfer]
  | succ n ih =>
    rw [transfer, ih, transfer, _root_.Matrix.mul_assoc]
    simp [Fin.tail_init_eq_init_tail, Fin.tail, Fin.init]

/-- One extracted core slice acts as its exact real row-vector contraction,
with zero padding on the old and new bond labels. -/
theorem paddedSlice_mulVec {l r B : ℕ} (hl : l ≤ B) (A : TensorTrainCanonical.Core l r)
    (bit : Fin 2) (v : Fin l → ℝ) :
    (coreSlice (paddedCore A : SequentialBondPreparation.Core (Fin B)) bit).mulVec
      (padVector (fun a => (v a : ℂ))) =
      padVector (fun b => ((_root_.Matrix.vecMul v (slice A bit)) b : ℂ)) := by
  funext b
  change (∑ a : Fin B, paddedCore A (bit, b) a * padVector (fun a => (v a : ℂ)) a) = _
  rw [sum_padVector hl]
  by_cases hb : b.val < r
  · simp [paddedCore, padVector, hb, _root_.Matrix.vecMul, dotProduct, slice,
      Complex.ofReal_sum, Complex.ofReal_mul, mul_comm]
  · simp [paddedCore, padVector, hb]

/-- All-length transfer equals the original chain contraction at every
padded output label, not just after projection onto its active subspace. -/
theorem transfer_padded {n l r B : ℕ} (C : Chain n l r) (hB : maxBond C ≤ B)
    (v : Fin l → ℝ) (x : PrimitiveBasis n) (b : Fin B) :
    (transfer (paddedAt C) n x).mulVec (padVector (fun a => (v a : ℂ))) b =
      padVector (fun c => ((_root_.Matrix.vecMul v (contract C (wordOfBasis x))) c : ℂ)) b := by
  induction C with
  | nil r => simp [transfer, contract]
  | @cons n l m r A C ih =>
    have hl : l ≤ B := (le_max_left l (maxBond C)).trans hB
    have ht : maxBond C ≤ B := (le_max_right l (maxBond C)).trans hB
    rw [transfer_shift, ← _root_.Matrix.mulVec_mulVec]
    change (transfer (paddedAt C) n (Fin.tail x)).mulVec
      ((coreSlice (paddedCore A) (x 0)).mulVec (padVector (fun a => (v a : ℂ)))) b = _
    rw [paddedSlice_mulVec hl, ih ht]
    simp only [contract, wordOfBasis, _root_.Matrix.vecMul_vecMul]

/-- A bounded version of the sequential local-column theorem: unused later
stages need not implement the zero cores after the end of the schedule. -/
theorem run_eq_transfer_bounded {B : Type*} [Fintype B] [DecidableEq B]
    (U : ℕ → Stage B) (K : ℕ → SequentialBondPreparation.Core B)
    (active : ℕ → B → Prop) (boundary : B → ℂ)
    (initialSupport : ∀ b, ¬ active 0 b → boundary b = 0)
    (coreSupport : ∀ t bit b a, ¬ active (t + 1) b → K t (bit, b) a = 0)
    (n : ℕ)
    (columns : ∀ t, t < n → ∀ bit b a, active t a → U t (bit, b) (0, a) = K t (bit, b) a)
    (x : PrimitiveBasis n) (b : B) :
    run U boundary n (x, b) = (transfer K n x).mulVec boundary b := by
  classical
  induction n generalizing b with
  | zero => simp [run, transfer]
  | succ n ih =>
    rw [run, step_apply, transfer, ← _root_.Matrix.mulVec_mulVec]
    simp only [_root_.Matrix.mulVec, dotProduct, coreSlice]
    apply Finset.sum_congr rfl
    intro a _
    have hc : ∀ t, t < n → ∀ bit b a, active t a →
        U t (bit, b) (0, a) = K t (bit, b) a :=
      fun t ht => columns t (Nat.lt_succ_of_lt ht)
    rw [ih hc]
    by_cases ha : active n a
    · rw [columns n (Nat.lt_succ_self n) _ b a ha]
      rfl
    · have hz := transfer_boundary_supported K active boundary initialSupport coreSupport
        n (Fin.init x) a ha
      change _ * (transfer K n (Fin.init x)).mulVec boundary a =
        _ * (transfer K n (Fin.init x)).mulVec boundary a
      rw [hz, mul_zero, mul_zero]

/-- Exact complete sequential action of the schedule extracted from an
actual dependent train. Only its first `n` local active columns are premises. -/
theorem run_padded {n l r B : ℕ} (C : Chain n l r) (hB : maxBond C ≤ B)
    (U : ℕ → Stage (Fin B))
    (columns : ∀ t, t < n → ∀ bit b a, a.val < rankAt C t →
      U t (bit, b) (0, a) = paddedAt C t (bit, b) a)
    (v : Fin l → ℝ) (x : PrimitiveBasis n) (b : Fin B) :
    run U (padVector (fun a => (v a : ℂ))) n (x, b) =
      padVector (fun c => ((_root_.Matrix.vecMul v (contract C (wordOfBasis x))) c : ℂ)) b := by
  rw [run_eq_transfer_bounded U (paddedAt C) (fun t a => a.val < rankAt C t)
    (padVector (fun a => (v a : ℂ)))
    (fun b hb => by
      simp only [rankAt_zero] at hb
      simp [padVector, hb])
    (fun t bit b a hb => paddedAt_supported C t bit b a (Nat.le_of_not_gt hb))
    n columns]
  exact transfer_padded C hB v x b

/-- Terminal dimension one gives whole-state cleanup at physical label zero.
The amplitude at every other padded label is exactly zero. -/
theorem run_terminal_clean {n l B : ℕ} (C : Chain n l 1) (hB : maxBond C ≤ B)
    (U : ℕ → Stage (Fin B))
    (columns : ∀ t, t < n → ∀ bit b a, a.val < rankAt C t →
      U t (bit, b) (0, a) = paddedAt C t (bit, b) a)
    (v : Fin l → ℝ) (x : PrimitiveBasis n) (b : Fin B) :
    run U (padVector (fun a => (v a : ℂ))) n (x, b) =
      if b.val = 0 then
        ((_root_.Matrix.vecMul v (contract C (wordOfBasis x))) 0 : ℂ) else 0 := by
  rw [run_padded C hB U columns v x b]
  by_cases hb : b.val = 0
  · simp [padVector, hb]
  · have hb1 : ¬ b.val < 1 := by omega
    simp [padVector, hb, hb1]

/-- Every extracted stage of a canonical chain has orthonormal occupied
columns in the one fixed physical register. -/
theorem paddedAt_active_isometry {n l r B : ℕ} (C : Chain n l r)
    (hC : RightCanonical C) (hB : maxBond C ≤ B) (t : ℕ) (ht : t < n)
    (a c : Fin (rankAt C t)) :
    (∑ out : Fin 2 × Fin B,
      star (paddedAt C t out (Fin.castLE ((rankAt_le_maxBond C t).trans hB) a)) *
        paddedAt C t out (Fin.castLE ((rankAt_le_maxBond C t).trans hB) c)) =
      if a = c then 1 else 0 := by
  induction C generalizing t with
  | nil _ => omega
  | @cons n l m r A C ih =>
    have hl : l ≤ B := (le_max_left l (maxBond C)).trans hB
    have htail : maxBond C ≤ B := (le_max_right l (maxBond C)).trans hB
    have hm : m ≤ B := by simpa using (rankAt_le_maxBond C 0).trans htail
    cases t with
    | zero => exact paddedCore_active_isometry hl hm A hC.1 a c
    | succ t => exact ih hC.2 htail t (by omega) a c

/-- A normalized scalar-boundary source train has a bounded canonical
schedule with exact whole-state source action whenever its *local occupied
columns* are implemented. No source-state oracle or global-action hypothesis
occurs in the premises. -/
theorem exists_normalized_preparation_schedule {n B : ℕ} (C : Chain n 1 1)
    (hB : maxBond C ≤ B)
    (hNorm : (∑ x : Word n, (contract C x 0 0) ^ 2) = 1) :
    ∃ (l' : ℕ) (u : Fin l' → ℝ) (D : Chain n l' 1),
      RightCanonical D ∧ RankReduced C D ∧ mass u = 1 ∧ maxBond D ≤ B ∧
      ∀ (U : ℕ → Stage (Fin B)),
        (∀ t, t < n → ∀ bit b a, a.val < rankAt D t →
          U t (bit, b) (0, a) = paddedAt D t (bit, b) a) →
        ∀ (x : PrimitiveBasis n) (b : Fin B),
          run U (padVector (fun a => (u a : ℂ))) n (x, b) =
            if b.val = 0 then (contract C (wordOfBasis x) 0 0 : ℂ) else 0 := by
  obtain ⟨l', u, D, hD, hRanks, hu, hAmplitude⟩ := exists_normalized_state C hNorm
  have hDB : maxBond D ≤ B := hRanks.maxBond_le.trans hB
  refine ⟨l', u, D, hD, hRanks, hu, hDB, ?_⟩
  intro U columns x b
  rw [run_terminal_clean D hDB U columns u x b]
  simp only [_root_.Matrix.vecMul, dotProduct]
  rw [← hAmplitude]

end QuantumBlockEncoding.TensorTrainSchedule
```

## QuantumBlockEncoding/TensorTrainCanonical.lean

Raw-file SHA256: 0b51ec0335aaf6248f40b3f8dcf6014172c231b9ae512bf5bb09d84ebf66f808

```lean
import QuantumBlockEncoding.ThinLQ
import QuantumBlockEncoding.SequentialBondPreparation

/-!
# Exact right-canonicalization of finite real tensor trains

Bond dimensions are dependent indices, not padded columns. Canonicalization
proceeds from the terminal bond to the initial bond, absorbing each residual
matrix into the preceding core. All input ranks, including zero and deficient
ones, are allowed. The orthonormal completions use classical choice: these
theorems do not certify an arithmetic algorithm or a preprocessing cost.
-/

namespace QuantumBlockEncoding.TensorTrainCanonical

open scoped BigOperators

abbrev Core (l r : ℕ) := _root_.Matrix (Fin l) (Fin 2 × Fin r) ℝ

def slice {l r : ℕ} (A : Core l r) (bit : Fin 2) :
    _root_.Matrix (Fin l) (Fin r) ℝ := fun a b => A a (bit, b)

/-- The first core emits the first bit. The terminal bond is explicit. -/
inductive Chain : ℕ → ℕ → ℕ → Type
  | nil (r : ℕ) : Chain 0 r r
  | cons {n l m r : ℕ} (head : Core l m) (tail : Chain n m r) : Chain (n + 1) l r

/-- Bit words indexed recursively in the same order as the cores. -/
def Word : ℕ → Type
  | 0 => Unit
  | n + 1 => Fin 2 × Word n

instance wordFintype (n : ℕ) : Fintype (Word n) := by
  induction n with
  | zero => exact inferInstanceAs (Fintype Unit)
  | succ n ih => exact inferInstanceAs (Fintype (Fin 2 × Word n))

/-- Matrix of bond-to-bond amplitudes for one fixed emitted word. -/
noncomputable def contract : {n l r : ℕ} → Chain n l r → Word n →
    _root_.Matrix (Fin l) (Fin r) ℝ
  | _, _, _, .nil _, _ => 1
  | _, _, _, .cons A C, x => slice A x.1 * contract C x.2

/-- Right-canonical means orthonormal rows at every individual core. -/
def RightCanonical : {n l r : ℕ} → Chain n l r → Prop
  | _, _, _, .nil _ => True
  | _, _, _, .cons A C => A * A.transpose = 1 ∧ RightCanonical C

/-- The active ranks satisfy the exact backward `min` recurrence, with an
unchanged terminal bond. This is a relation on actual core chains. -/
inductive RankReduced : {n l l' r : ℕ} → Chain n l r → Chain n l' r → Prop
  | nil (r : ℕ) : RankReduced (.nil r) (.nil r)
  | cons {n l m r m' : ℕ} {A : Core l m} {C : Chain n m r}
      {Q : Core (min l (2 * m')) m'} {D : Chain n m' r}
      (tail : RankReduced C D) : RankReduced (.cons A C) (.cons Q D)

/-- Multiply a residual into the right bond without mixing the emitted bit. -/
noncomputable def absorb {l m r : ℕ} (A : Core l m)
    (R : _root_.Matrix (Fin m) (Fin r) ℝ) : Core l r :=
  fun a x => ∑ b, A a (x.1, b) * R b x.2

theorem absorb_slice {l m r : ℕ} (A : Core l m)
    (R : _root_.Matrix (Fin m) (Fin r) ℝ) (bit : Fin 2) :
    slice (absorb A R) bit = slice A bit * R := rfl

/-- Thin LQ with the physical bit/right-bond product index made explicit. -/
theorem exists_core_lq {l r : ℕ} (A : Core l r) :
    ∃ (R : _root_.Matrix (Fin l) (Fin (min l (2 * r))) ℝ)
      (Q : Core (min l (2 * r)) r), A = R * Q ∧ Q * Q.transpose = 1 := by
  classical
  let e : Fin 2 × Fin r ≃ Fin (2 * r) := finProdFinEquiv
  obtain ⟨R, Q, hA, hQ⟩ := ThinLQ.exists_thin_lq (fun a j => A a (e.symm j))
  refine ⟨R, fun a j => Q a (e j), ?_, ?_⟩
  · ext a j
    change A a j = ∑ b, R a b * Q b (e j)
    simpa only [Equiv.symm_apply_apply, _root_.Matrix.mul_apply] using
      congrFun (congrFun hA a) (e j)
  · ext a b
    have h := congrFun (congrFun hQ a) b
    simp only [_root_.Matrix.mul_apply, _root_.Matrix.transpose_apply] at h ⊢
    exact (e.sum_comp (fun j => Q a j * Q b j)).trans h

/-- Exact all-length right-canonicalization, preserving every amplitude.
No full-rank assumption or global state-action hypothesis is used. -/
theorem exists_rightCanonical {n l r : ℕ} (C : Chain n l r) :
    ∃ (l' : ℕ) (R : _root_.Matrix (Fin l) (Fin l') ℝ) (D : Chain n l' r),
      RightCanonical D ∧ RankReduced C D ∧ ∀ x, contract C x = R * contract D x := by
  induction C with
  | nil r =>
    exact ⟨r, 1, .nil r, trivial, .nil r, fun x => by simp [contract]⟩
  | @cons n l m r A C ih =>
    obtain ⟨m', S, D, hD, hRanks, hC⟩ := ih
    obtain ⟨R, Q, hA, hQ⟩ := exists_core_lq (absorb A S)
    refine ⟨min l (2 * m'), R, .cons Q D, ⟨hQ, hD⟩, .cons hRanks, ?_⟩
    intro x
    change slice A x.1 * contract C x.2 = R * (slice Q x.1 * contract D x.2)
    rw [hC, ← _root_.Matrix.mul_assoc, ← absorb_slice]
    have hs : slice (absorb A S) x.1 = R * slice Q x.1 := by
      ext a b
      exact congrFun (congrFun hA a) (x.1, b)
    rw [hs, _root_.Matrix.mul_assoc]

/-- Every nonempty canonicalized train has a left rank bounded by the
original left rank and by twice its next active rank. -/
theorem RankReduced.head_bound {n l l' r : ℕ} {C : Chain (n + 1) l r}
    {D : Chain (n + 1) l' r} (h : RankReduced C D) :
    l' ≤ l ∧ ∃ m', ∃ (Q : Core l' m') (tail : Chain n m' r),
      D = .cons Q tail ∧ l' ≤ 2 * m' := by
  cases h with
  | @cons _ _ _ _ m' A C Q D h =>
    exact ⟨min_le_left _ _, m', Q, D, rfl, min_le_right _ _⟩

/-- In particular, the penultimate active bond has dimension at most two. -/
theorem RankReduced.last_bond_le_two {l l' : ℕ} {C : Chain 1 l 1}
    {D : Chain 1 l' 1} (h : RankReduced C D) : l' ≤ 2 := by
  obtain ⟨_, m', Q, tail, _, hb⟩ := h.head_bound
  cases tail
  simpa using hb

/-- Squared Euclidean mass for an arbitrary finite real boundary. -/
noncomputable def mass {I : Type*} [Fintype I] (v : I → ℝ) : ℝ := ∑ i, v i ^ 2

/-- An orthonormal-row matrix acts isometrically on row-vector boundaries. -/
theorem mass_vecMul {I J : Type*} [Fintype I] [Fintype J] [DecidableEq I]
    (A : _root_.Matrix I J ℝ) (hA : A * A.transpose = 1) (v : I → ℝ) :
    mass (_root_.Matrix.vecMul v A) = mass v := by
  change (∑ j, (_root_.Matrix.vecMul v A) j ^ 2) = ∑ i, v i ^ 2
  simp only [pow_two]
  change dotProduct (_root_.Matrix.vecMul v A) (_root_.Matrix.vecMul v A) =
    dotProduct v v
  calc
    _ = dotProduct (_root_.Matrix.vecMul v A) (A.transpose.mulVec v) := by
      rw [_root_.Matrix.mulVec_transpose]
    _ = dotProduct (_root_.Matrix.vecMul (_root_.Matrix.vecMul v A) A.transpose) v :=
      _root_.Matrix.dotProduct_mulVec _ _ _
    _ = _ := by rw [_root_.Matrix.vecMul_vecMul, hA, _root_.Matrix.vecMul_one]

/-- Total mass of all emitted amplitudes, including the terminal bond. -/
noncomputable def chainMass {n l r : ℕ} (C : Chain n l r) (v : Fin l → ℝ) : ℝ :=
  ∑ x : Word n, mass (_root_.Matrix.vecMul v (contract C x))

/-- Local row-isometries compose to an all-length mass-preserving state map. -/
theorem chainMass_eq {n l r : ℕ} (C : Chain n l r) (hC : RightCanonical C)
    (v : Fin l → ℝ) : chainMass C v = mass v := by
  induction C with
  | nil r =>
    change (∑ _ : Unit, mass (_root_.Matrix.vecMul v (1 : _root_.Matrix (Fin r) (Fin r) ℝ))) = mass v
    simp
  | @cons n l m r A C ih =>
    obtain ⟨hA, hC⟩ := hC
    change (∑ x : Fin 2 × Word n,
      mass (_root_.Matrix.vecMul v (slice A x.1 * contract C x.2))) = mass v
    rw [Fintype.sum_prod_type]
    simp_rw [← _root_.Matrix.vecMul_vecMul]
    change (∑ bit : Fin 2, chainMass C (_root_.Matrix.vecMul v (slice A bit))) = mass v
    simp_rw [ih hC]
    have he : (∑ bit : Fin 2, mass (_root_.Matrix.vecMul v (slice A bit))) =
        mass (_root_.Matrix.vecMul v A) := by
      simp only [mass, Fintype.sum_prod_type, _root_.Matrix.vecMul, slice]
    rw [he, mass_vecMul A hA]

/-- Factorization preserves total mass, and canonicality identifies it with
the mass of the new initial boundary. -/
theorem residual_mass {n l l' r : ℕ} (C : Chain n l r) (D : Chain n l' r)
    (R : _root_.Matrix (Fin l) (Fin l') ℝ) (hD : RightCanonical D)
    (h : ∀ x, contract C x = R * contract D x) (v : Fin l → ℝ) :
    chainMass C v = mass (_root_.Matrix.vecMul v R) := by
  calc
    _ = chainMass D (_root_.Matrix.vecMul v R) := by
      simp only [chainMass, h, _root_.Matrix.vecMul_vecMul]
    _ = _ := chainMass_eq D hD _

/-- A normalized input train has a normalized residual initial boundary.
The terminal bond remains exactly dimension one. -/
theorem exists_rightCanonical_normalized {n l : ℕ} (C : Chain n l 1)
    (v : Fin l → ℝ) (hv : chainMass C v = 1) :
    ∃ (l' : ℕ) (R : _root_.Matrix (Fin l) (Fin l') ℝ) (D : Chain n l' 1),
      RightCanonical D ∧ RankReduced C D ∧
      (∀ x, contract C x = R * contract D x) ∧ mass (_root_.Matrix.vecMul v R) = 1 := by
  obtain ⟨l', R, D, hD, hRanks, h⟩ := exists_rightCanonical C
  exact ⟨l', R, D, hD, hRanks, h, (residual_mass C D R hD h v).symm.trans hv⟩

/-- Scalar-boundary state version: the new initial vector is normalized and
every individual target amplitude is recovered by contracting it with the
right-canonical train. No target-state equality is a hypothesis. -/
theorem exists_normalized_state {n : ℕ} (C : Chain n 1 1)
    (hC : (∑ x : Word n, (contract C x 0 0) ^ 2) = 1) :
    ∃ (l' : ℕ) (u : Fin l' → ℝ) (D : Chain n l' 1),
      RightCanonical D ∧ RankReduced C D ∧ mass u = 1 ∧
      ∀ x, contract C x 0 0 = ∑ a, u a * contract D x a 0 := by
  have hv : chainMass C (fun _ => 1) = 1 := by
    simpa [chainMass, mass, _root_.Matrix.vecMul, dotProduct] using hC
  obtain ⟨l', R, D, hD, hRanks, h, hu⟩ :=
    exists_rightCanonical_normalized C (fun _ => 1) hv
  refine ⟨l', _root_.Matrix.vecMul (fun _ => 1) R, D, hD, hRanks, hu, ?_⟩
  intro x
  have hx := congrFun (congrFun (h x) 0) 0
  simpa [_root_.Matrix.mul_apply, _root_.Matrix.vecMul, dotProduct] using hx

/-- Largest actual bond in a chain, including both boundaries. -/
def maxBond : {n l r : ℕ} → Chain n l r → ℕ
  | _, _, _, .nil r => r
  | _, l, _, .cons _ C => max l (maxBond C)

/-- Backward canonicalization never enlarges any maximal bond dimension. -/
theorem RankReduced.maxBond_le {n l l' r : ℕ} {C : Chain n l r}
    {D : Chain n l' r} (h : RankReduced C D) : maxBond D ≤ maxBond C := by
  induction h with
  | nil r => exact le_rfl
  | cons _ ih => exact max_le_max (min_le_left _ _) ih

/-- In circuit convention the emitted bit/new bond are output rows, and
the old bond is the input column. Real amplitudes embed into complex ones. -/
def complexCore {l r : ℕ} (A : Core l r) :
    _root_.Matrix (Fin 2 × Fin r) (Fin l) ℂ := fun out a => (A a out : ℂ)

/-- Right-canonical rows are exactly orthonormal circuit input columns. -/
theorem complexCore_isometry {l r : ℕ} (A : Core l r)
    (hA : A * A.transpose = 1) :
    (complexCore A).conjTranspose * complexCore A = 1 := by
  ext a b
  have h := congrFun (congrFun hA a) b
  simp only [_root_.Matrix.mul_apply, _root_.Matrix.transpose_apply,
    _root_.Matrix.one_apply] at h
  apply Complex.ext
  · simpa [complexCore, _root_.Matrix.mul_apply, _root_.Matrix.conjTranspose_apply,
      _root_.Matrix.one_apply, Complex.mul_re, apply_ite] using h
  · simp [complexCore, _root_.Matrix.mul_apply, _root_.Matrix.conjTranspose_apply,
      _root_.Matrix.one_apply, apply_ite]

/-- Equal-rank specialization lands literally in the existing sequential
preparation core type; padding varying ranks is a separate register embedding. -/
def sequentialCore {r : ℕ} (A : Core r r) : SequentialBondPreparation.Core (Fin r) :=
  complexCore A

/-- Exact clean-column semantic adapter, in output-row/input-column order.
This premise concerns one local stage, not the target state or full run. -/
theorem sequential_step {n r : ℕ} (A : Core r r)
    (U : SequentialBondPreparation.Stage (Fin r))
    (hU : ∀ bit b a, U (bit, b) (0, a) = complexCore A (bit, b) a)
    (v : SequentialBondPreparation.BondState n (Fin r))
    (x : PrimitiveBasis (n + 1)) (b : Fin r) :
    SequentialBondPreparation.step U v (x, b) =
      ∑ a, (A a (x (Fin.last n), b) : ℂ) * v (Fin.init x, a) := by
  rw [SequentialBondPreparation.step_apply]
  simp_rw [hU, complexCore]

/-- Embed a varying active bond into a fixed physical register by zero fill. -/
def padVector {d B : ℕ} (v : Fin d → ℂ) (b : Fin B) : ℂ :=
  if h : b.val < d then v ⟨b.val, h⟩ else 0

@[simp] theorem padVector_active {d B : ℕ} (hd : d ≤ B) (v : Fin d → ℂ)
    (a : Fin d) : padVector v (Fin.castLE hd a) = v a := by
  simp [padVector, a.isLt]

/-- Padded matrix has zero output outside the next active rank and specifies
only the active clean-input columns; other completion columns stay free. -/
def paddedCore {l r B : ℕ} (A : Core l r) : SequentialBondPreparation.Core (Fin B) :=
  fun out a => if ha : a.val < l then
    if hb : out.2.val < r then (A ⟨a.val, ha⟩ (out.1, ⟨out.2.val, hb⟩) : ℂ) else 0
    else 0

theorem paddedCore_inactive_output {l r B : ℕ} (A : Core l r)
    (bit : Fin 2) (b a : Fin B) (hb : r ≤ b.val) : paddedCore A (bit, b) a = 0 := by
  simp [paddedCore, Nat.not_lt.mpr hb]

theorem sum_padVector {d B : ℕ} (hd : d ≤ B) (f : Fin B → ℂ) (v : Fin d → ℂ) :
    (∑ a : Fin B, f a * padVector v a) =
      ∑ a : Fin d, f (Fin.castLE hd a) * v a := by
  symm
  simpa only [padVector_active] using ThinLQ.sum_prefix_of_zero hd
    (fun a => f a * padVector v a)
    (fun a ha => by simp [padVector, Nat.not_lt.mpr ha])

/-- Rank-changing local action in the existing sequential semantics. The
only circuit premise is equality on active clean-input columns. The output
is the zero-padded exact core contraction, including every inactive label. -/
theorem sequential_step_padded {n l r B : ℕ} (hl : l ≤ B) (A : Core l r)
    (U : SequentialBondPreparation.Stage (Fin B))
    (columns : ∀ bit b (a : Fin l),
      U (bit, b) (0, Fin.castLE hl a) = paddedCore A (bit, b) (Fin.castLE hl a))
    (v : PrimitiveBasis n × Fin l → ℂ) (x : PrimitiveBasis (n + 1)) (b : Fin B) :
    SequentialBondPreparation.step U
      (fun z => padVector (fun a => v (z.1, a)) z.2) (x, b) =
      padVector (fun c : Fin r =>
        ∑ a : Fin l, (A a (x (Fin.last n), c) : ℂ) * v (Fin.init x, a)) b := by
  rw [SequentialBondPreparation.step_apply]
  change (∑ a, U (x (Fin.last n), b) (0, a) *
    padVector (fun a => v (Fin.init x, a)) a) = _
  rw [sum_padVector hl]
  simp_rw [columns]
  by_cases hb : b.val < r
  · simp [paddedCore, padVector, hb]
  · simp [paddedCore, padVector, hb]

/-- Active columns of a right-canonical core remain orthonormal after
embedding the output into a larger physical register. -/
theorem paddedCore_active_isometry {l r B : ℕ} (hl : l ≤ B) (hr : r ≤ B)
    (A : Core l r) (hA : A * A.transpose = 1) (a c : Fin l) :
    (∑ out : Fin 2 × Fin B,
      star (paddedCore A out (Fin.castLE hl a)) *
        paddedCore A out (Fin.castLE hl c)) = if a = c then 1 else 0 := by
  have h := congrFun (congrFun (complexCore_isometry A hA) a) c
  simp only [_root_.Matrix.mul_apply, _root_.Matrix.conjTranspose_apply,
    _root_.Matrix.one_apply] at h
  rw [Fintype.sum_prod_type]
  have he (bit : Fin 2) :
      (∑ b : Fin B, star (paddedCore A (bit, b) (Fin.castLE hl a)) *
        paddedCore A (bit, b) (Fin.castLE hl c)) =
      ∑ b : Fin r, star (complexCore A (bit, b) a) * complexCore A (bit, b) c := by
    symm
    have hs := ThinLQ.sum_prefix_of_zero hr
      (fun b => star (paddedCore A (bit, b) (Fin.castLE hl a)) *
        paddedCore A (bit, b) (Fin.castLE hl c))
      (fun b hb => by simp [paddedCore, Nat.not_lt.mpr hb])
    simpa [paddedCore, complexCore] using hs
  simp_rw [he]
  simpa only [Fintype.sum_prod_type] using h

end QuantumBlockEncoding.TensorTrainCanonical
```

## QuantumBlockEncoding/UniformlyControlledRy.lean

Raw-file SHA256: 78d1aed9bb4068bcee138b665bd93a389463bbb591108837758a6d80752a1cf1

```lean
import QuantumBlockEncoding.PrimitiveSemantics

/-!
# Reference compiler for uniformly controlled RY

This is the deliberately simple recursive compiler used before any Gray-code
optimization.  With `n` controls it emits `2^n` RY gates and
`2 * (2^n - 1)` CX gates.
-/

namespace QuantumBlockEncoding

open Robin.ComplexLCU
open scoped Kronecker

private def prependControlBit {n : Nat} (bit : Fin 2)
    (tail : PrimitiveBasis n) : PrimitiveBasis (n + 1) :=
  Fin.cons bit tail

private def halfAddAngles {n : Nat}
    (angles : PrimitiveBasis (n + 1) → ExactAngle) :
    PrimitiveBasis n → ExactAngle := fun tail =>
  ExactAngle.halfAdd
    (angles (prependControlBit 0 tail))
    (angles (prependControlBit 1 tail))

private def halfSubAngles {n : Nat}
    (angles : PrimitiveBasis (n + 1) → ExactAngle) :
    PrimitiveBasis n → ExactAngle := fun tail =>
  ExactAngle.halfSub
    (angles (prependControlBit 0 tail))
    (angles (prependControlBit 1 tail))

def primitiveControlAssignment {qubits controls : Nat}
    (wires : Fin controls → Fin qubits) (target : Fin qubits)
    (distinct : ∀ control, wires control ≠ target)
    (context : OtherPrimitiveWires target → Fin 2) : PrimitiveBasis controls :=
  fun control => context ⟨wires control, distinct control⟩

/-- Backend-independent specification: each fixed assignment of the non-target
wires owns one exact two-dimensional RY block selected by the control bits. -/
noncomputable def controlledRyBlockMatrix {qubits controls : Nat}
    (wires : Fin controls → Fin qubits) (target : Fin qubits)
    (distinct : ∀ control, wires control ≠ target)
    (angles : PrimitiveBasis controls → ExactAngle) :
    _root_.Matrix (PrimitiveBasis qubits) (PrimitiveBasis qubits) ℂ :=
  _root_.Matrix.reindexAlgEquiv ℂ ℂ (splitPrimitiveWire target).symm
    (_root_.Matrix.blockDiagonal fun context =>
      standardRyMatrix (angles (primitiveControlAssignment wires target distinct context)).eval)

@[simp] theorem controlledRyBlockMatrix_apply {qubits controls : Nat}
    (wires : Fin controls → Fin qubits) (target : Fin qubits)
    (distinct : ∀ control, wires control ≠ target)
    (angles : PrimitiveBasis controls → ExactAngle)
    (row column : PrimitiveBasis qubits) :
    controlledRyBlockMatrix wires target distinct angles row column =
      if (splitPrimitiveWire target row).2 =
          (splitPrimitiveWire target column).2 then
        standardRyMatrix
          (angles (primitiveControlAssignment wires target distinct
            (splitPrimitiveWire target row).2)).eval
          (row target) (column target)
      else 0 := by
  simp [controlledRyBlockMatrix, _root_.Matrix.blockDiagonal_apply,
    splitPrimitiveWire]

private theorem kronecker_one_eq_blockDiagonal
    {context : Type*} [Fintype context] [DecidableEq context]
    (gate : _root_.Matrix (Fin 2) (Fin 2) ℂ) :
    gate ⊗ₖ (1 : _root_.Matrix context context ℂ) =
      _root_.Matrix.blockDiagonal (fun _ : context => gate) := by
  ext ⟨row, rowContext⟩ ⟨column, columnContext⟩
  by_cases equal : rowContext = columnContext
  · subst columnContext
    simp [_root_.Matrix.blockDiagonal_apply]
  · simp [_root_.Matrix.blockDiagonal_apply, equal]

private theorem evalPrimitiveRy_eq_controlledRyBlockMatrix_zero
    {qubits : Nat} (target : Fin qubits) (angle : ExactAngle) :
    evalPrimitiveGate (.ry target angle) =
      controlledRyBlockMatrix (fun index : Fin 0 => Fin.elim0 index)
        target (fun index => Fin.elim0 index) (fun _ => angle) := by
  change
    _root_.Matrix.reindexAlgEquiv ℂ ℂ (splitPrimitiveWire target).symm
        (standardRyMatrix angle.eval ⊗ₖ
          (1 : _root_.Matrix (OtherPrimitiveWires target → Fin 2)
            (OtherPrimitiveWires target → Fin 2) ℂ)) = _
  unfold controlledRyBlockMatrix
  congr 1
  rw [kronecker_one_eq_blockDiagonal]

private def controlledXBlock {qubits : Nat} (control target : Fin qubits)
    (distinct : control ≠ target) (context : OtherPrimitiveWires target → Fin 2) :
    _root_.Matrix (Fin 2) (Fin 2) ℂ :=
  if context ⟨control, distinct⟩ = 0 then 1 else xMatrix

private theorem xMatrix_flipBit (bit : Fin 2) :
    xMatrix (flipBit bit) bit = 1 := by
  fin_cases bit <;> rfl

private theorem evalPrimitiveCx_eq_controlledXBlock
    {qubits : Nat} (control target : Fin qubits)
    (distinct : control ≠ target) :
    evalPrimitiveGate (.cx control target distinct) =
      _root_.Matrix.reindexAlgEquiv ℂ ℂ (splitPrimitiveWire target).symm
        (_root_.Matrix.blockDiagonal
          (controlledXBlock control target distinct)) := by
  ext row column
  simp only [evalPrimitiveGate, equivPermutationMatrix,
    _root_.Matrix.reindexAlgEquiv_apply, _root_.Matrix.reindex_apply,
    _root_.Matrix.submatrix_apply, _root_.Matrix.blockDiagonal_apply,
    cxBasisEquiv_apply, Equiv.symm_symm]
  by_cases contextsEqual :
      (splitPrimitiveWire target row).2 = (splitPrimitiveWire target column).2
  · have controlEqual : row control = column control := by
      simpa [splitPrimitiveWire, distinct] using
        congrFun contextsEqual ⟨control, distinct⟩
    have contextFunctionsEqual :
        (fun wire : OtherPrimitiveWires target => row wire.1) =
          fun wire => column wire.1 := by
      simpa [splitPrimitiveWire] using contextsEqual
    by_cases controlZero : column control = 0
    · have rowControlZero : row control = 0 := by simpa [controlEqual]
      have rowEq : row = column ↔ row target = column target := by
        constructor
        · intro equality
          exact congrFun equality target
        · intro targetEqual
          apply (splitPrimitiveWire target).injective
          apply Prod.ext
          · simpa [splitPrimitiveWire]
          · exact contextsEqual
      simp [controlledXBlock, contextsEqual, controlZero, rowControlZero,
        cxBasisAction, splitPrimitiveWire, rowEq,
        contextFunctionsEqual, Equiv.symm_symm]
      change (if row target = column target then 1 else 0) =
        if row target = column target then 1 else 0
      rfl
    · have rowControlNonzero : row control ≠ 0 := by simpa [controlEqual]
      by_cases targetFlipped : row target = flipBit (column target)
      · have action : row = cxBasisAction control target column := by
          funext wire
          by_cases wireTarget : wire = target
          · subst wire
            simpa [cxBasisAction, controlZero, xBasisAction] using targetFlipped
          · have outside := congrFun contextsEqual ⟨wire, wireTarget⟩
            simpa [cxBasisAction, controlZero, xBasisAction, splitPrimitiveWire,
              wireTarget] using outside
        have xContext :
            (fun wire : OtherPrimitiveWires target =>
              xBasisAction target column wire.1) =
              fun wire => column wire.1 := by
          funext wire
          simp [xBasisAction, wire.property]
        have xControl :
            xBasisAction target column control = column control := by
          simp [xBasisAction, distinct]
        have xTargetNe :
            xBasisAction target column target ≠ column target := by
          have flipNeAll : ∀ bit : Fin 2, flipBit bit ≠ bit := by decide
          have flipNe := flipNeAll (column target)
          simpa [xBasisAction] using flipNe
        simp [controlledXBlock, contextsEqual, controlZero,
          action, cxBasisAction, xMatrix, splitPrimitiveWire,
          contextFunctionsEqual, targetFlipped, xContext, xControl,
          xMatrix_flipBit, Equiv.symm_symm, xTargetNe]
      · have actionMiss : row ≠ cxBasisAction control target column := by
          intro action
          apply targetFlipped
          have := congrFun action target
          simpa [cxBasisAction, controlZero, xBasisAction] using this
        have bitComplement : ∀ left right : Fin 2,
            left ≠ flipBit right → left = right := by decide
        have targetEqual : row target = column target :=
          bitComplement _ _ targetFlipped
        simp [controlledXBlock, contextsEqual, controlZero, rowControlNonzero,
          actionMiss, xMatrix, splitPrimitiveWire, targetFlipped,
          targetEqual, contextFunctionsEqual, Equiv.symm_symm]
  · have actionMiss : row ≠ cxBasisAction control target column := by
      intro action
      apply contextsEqual
      funext wire
      have actionWire := congrFun action wire.1
      have unchanged :
          cxBasisAction control target column wire.1 = column wire.1 := by
        by_cases controlZero : column control = 0 <;>
          simp [cxBasisAction, controlZero, xBasisAction, wire.property]
      simpa [splitPrimitiveWire, unchanged] using actionWire
    simp [contextsEqual, actionMiss]

/-- Reference recursive compiler.  Controls are consumed from low to high in
the supplied control tuple; circuit execution remains chronological. -/
def compileUniformlyControlledRy {qubits : Nat} :
    (controls : Nat) →
    (wires : Fin controls → Fin qubits) →
    (target : Fin qubits) →
    (∀ control, wires control ≠ target) →
    (PrimitiveBasis controls → ExactAngle) →
    PrimitiveCircuit qubits
  | 0, _, target, _, angles =>
      [.ry target (angles fun index => Fin.elim0 index)]
  | controls + 1, wires, target, distinct, angles =>
      let head := wires 0
      let tailWires : Fin controls → Fin qubits := fun index => wires index.succ
      let tailDistinct : ∀ control, tailWires control ≠ target :=
        fun control => distinct control.succ
      let controlled := PrimitiveGate.cx head target (distinct 0)
      compileUniformlyControlledRy controls tailWires target tailDistinct
          (halfAddAngles angles) ++
        [controlled] ++
        compileUniformlyControlledRy controls tailWires target tailDistinct
          (halfSubAngles angles) ++
        [controlled]

/-- Recursive matrix specification corresponding to the standard multiplexor
identity.  This definition is backend-independent and mentions only exact
primitive matrix semantics. -/
noncomputable def uniformlyControlledRyMatrix {qubits : Nat} :
    (controls : Nat) →
    (wires : Fin controls → Fin qubits) →
    (target : Fin qubits) →
    (∀ control, wires control ≠ target) →
    (PrimitiveBasis controls → ExactAngle) →
    _root_.Matrix (PrimitiveBasis qubits) (PrimitiveBasis qubits) ℂ
  | 0, _, target, _, angles =>
      evalPrimitiveGate (.ry target (angles fun index => Fin.elim0 index))
  | controls + 1, wires, target, distinct, angles =>
      let head := wires 0
      let tailWires : Fin controls → Fin qubits := fun index => wires index.succ
      let tailDistinct : ∀ control, tailWires control ≠ target :=
        fun control => distinct control.succ
      let controlled := evalPrimitiveGate
        (PrimitiveGate.cx head target (distinct 0))
      controlled *
        uniformlyControlledRyMatrix controls tailWires target tailDistinct
          (halfSubAngles angles) *
        controlled *
        uniformlyControlledRyMatrix controls tailWires target tailDistinct
          (halfAddAngles angles)

theorem compileUniformlyControlledRy_eval {qubits controls : Nat}
    (wires : Fin controls → Fin qubits) (target : Fin qubits)
    (distinct : ∀ control, wires control ≠ target)
    (angles : PrimitiveBasis controls → ExactAngle) :
    evalPrimitiveCircuit
        (compileUniformlyControlledRy controls wires target distinct angles) =
      uniformlyControlledRyMatrix controls wires target distinct angles := by
  induction controls with
  | zero =>
      simp [compileUniformlyControlledRy, uniformlyControlledRyMatrix,
        evalPrimitiveCircuit]
  | succ controls induction =>
      simp only [compileUniformlyControlledRy, uniformlyControlledRyMatrix,
        evalPrimitiveCircuit_append, evalPrimitiveCircuit]
      rw [induction, induction]
      simp [mul_assoc]

/-- The recursive compiler satisfies the independent block-diagonal
specification selected by the computational-basis controls. -/
theorem compileUniformlyControlledRy_eval_controlledRyBlockMatrix
    {qubits controls : Nat}
    (wires : Fin controls → Fin qubits) (target : Fin qubits)
    (distinct : ∀ control, wires control ≠ target)
    (angles : PrimitiveBasis controls → ExactAngle) :
    evalPrimitiveCircuit
        (compileUniformlyControlledRy controls wires target distinct angles) =
      controlledRyBlockMatrix wires target distinct angles := by
  induction controls with
  | zero =>
      have wiresEq : wires = fun index : Fin 0 => Fin.elim0 index := by
        funext index
        exact Fin.elim0 index
      have anglesEq : angles = fun _ => angles (fun index => Fin.elim0 index) := by
        funext bits
        congr 1
        funext index
        exact Fin.elim0 index
      subst wires
      rw [anglesEq]
      simpa [compileUniformlyControlledRy, evalPrimitiveCircuit] using
        evalPrimitiveRy_eq_controlledRyBlockMatrix_zero target
          (angles fun index => Fin.elim0 index)
  | succ controls induction =>
      simp only [compileUniformlyControlledRy, evalPrimitiveCircuit_append,
        evalPrimitiveCircuit]
      rw [induction, induction,
        evalPrimitiveCx_eq_controlledXBlock]
      unfold controlledRyBlockMatrix
      simp only [_root_.Matrix.one_mul, ← mul_assoc]
      rw [← _root_.Matrix.reindexAlgEquiv_mul,
        ← _root_.Matrix.reindexAlgEquiv_mul,
        ← _root_.Matrix.reindexAlgEquiv_mul]
      apply_fun (_root_.Matrix.reindexAlgEquiv ℂ ℂ
        (splitPrimitiveWire target).symm).symm
      simp only [AlgEquiv.symm_apply_apply]
      rw [← _root_.Matrix.blockDiagonal_mul,
        ← _root_.Matrix.blockDiagonal_mul,
        ← _root_.Matrix.blockDiagonal_mul]
      congr 1
      funext context
      let tailBits : PrimitiveBasis controls :=
        primitiveControlAssignment (fun index => wires index.succ) target
          (fun index => distinct index.succ) context
      by_cases headZero : context ⟨wires 0, distinct 0⟩ = 0
      · have assignmentZero' :
            prependControlBit 0 tailBits =
              primitiveControlAssignment wires target distinct context := by
          funext index
          refine Fin.cases ?_ ?_ index
          · exact headZero.symm
          · intro tail
            rfl
        simp only [controlledXBlock, headZero, if_pos, one_mul, mul_one]
        change
          standardRyMatrix (halfSubAngles angles tailBits).eval *
              standardRyMatrix (halfAddAngles angles tailBits).eval =
            standardRyMatrix
              (angles (primitiveControlAssignment wires target distinct context)).eval
        rw [show
          standardRyMatrix
                ((halfSubAngles angles tailBits).eval) *
              standardRyMatrix ((halfAddAngles angles tailBits).eval) =
            standardRyMatrix
              ((halfAddAngles angles tailBits).eval +
                (halfSubAngles angles tailBits).eval) by
              rw [standardRyMatrix_add]]
        congr 2
        simp only [halfAddAngles, halfSubAngles, ExactAngle.eval_half_add,
          ExactAngle.eval_half_sub]
        rw [assignmentZero']
        ring
      · have headOne : context ⟨wires 0, distinct 0⟩ = 1 := by
          have nonzeroIsOne : ∀ bit : Fin 2, bit ≠ 0 → bit = 1 := by decide
          exact nonzeroIsOne _ headZero
        have assignmentOne' :
            prependControlBit 1 tailBits =
              primitiveControlAssignment wires target distinct context := by
          funext index
          refine Fin.cases ?_ ?_ index
          · exact headOne.symm
          · intro tail
            rfl
        simp only [controlledXBlock, headZero, if_neg]
        change
          (xMatrix * standardRyMatrix (halfSubAngles angles tailBits).eval *
              xMatrix) *
              standardRyMatrix (halfAddAngles angles tailBits).eval =
            standardRyMatrix
              (angles (primitiveControlAssignment wires target distinct context)).eval
        rw [show
          xMatrix * standardRyMatrix (halfSubAngles angles tailBits).eval *
                xMatrix =
              standardRyMatrix (-(halfSubAngles angles tailBits).eval) by
            exact xMatrix_conjugates_standardRy _]
        rw [show
          standardRyMatrix (-(halfSubAngles angles tailBits).eval) *
              standardRyMatrix (halfAddAngles angles tailBits).eval =
            standardRyMatrix
              ((halfAddAngles angles tailBits).eval -
                (halfSubAngles angles tailBits).eval) by
              simpa [sub_eq_add_neg] using
                (standardRyMatrix_add
                  (halfAddAngles angles tailBits).eval
                  (-(halfSubAngles angles tailBits).eval)).symm]
        congr 2
        simp only [halfAddAngles, halfSubAngles, ExactAngle.eval_half_add,
          ExactAngle.eval_half_sub]
        rw [assignmentOne']
        ring

theorem compileUniformlyControlledRy_ryCount {qubits controls : Nat}
    (wires : Fin controls → Fin qubits) (target : Fin qubits)
    (distinct : ∀ control, wires control ≠ target)
    (angles : PrimitiveBasis controls → ExactAngle) :
    (compileUniformlyControlledRy controls wires target distinct angles).ryCount =
      2 ^ controls := by
  induction controls with
  | zero => simp [compileUniformlyControlledRy, PrimitiveCircuit.ryCount]
  | succ controls induction =>
      simp only [compileUniformlyControlledRy,
        PrimitiveCircuit.ryCount_append,
        PrimitiveCircuit.ryCount_singleton_cx, Nat.add_zero]
      rw [induction, induction]
      simp [pow_succ]
      omega

theorem compileUniformlyControlledRy_cxCount {qubits controls : Nat}
    (wires : Fin controls → Fin qubits) (target : Fin qubits)
    (distinct : ∀ control, wires control ≠ target)
    (angles : PrimitiveBasis controls → ExactAngle) :
    (compileUniformlyControlledRy controls wires target distinct angles).cxCount =
      2 * (2 ^ controls - 1) := by
  induction controls with
  | zero => simp [compileUniformlyControlledRy, PrimitiveCircuit.cxCount]
  | succ controls induction =>
      simp only [compileUniformlyControlledRy,
        PrimitiveCircuit.cxCount_append,
        PrimitiveCircuit.cxCount_singleton_cx]
      rw [induction, induction]
      rw [pow_succ]
      have powerPositive : 0 < 2 ^ controls := pow_pos (by decide) _
      omega

theorem compileUniformlyControlledRy_oracleCalls_eq_zero
    {qubits controls : Nat} (wires : Fin controls → Fin qubits)
    (target : Fin qubits) (distinct : ∀ control, wires control ≠ target)
    (angles : PrimitiveBasis controls → ExactAngle) :
    (compileUniformlyControlledRy controls wires target distinct angles).resource.oracleCalls = 0 :=
  PrimitiveCircuit.resource_oracleCalls_eq_zero _

/-- Frozen Robin reference count: five controls require 32 RY and 62 CX. -/
theorem compileUniformlyControlledRy_five_control_counts
    {qubits : Nat} (wires : Fin 5 → Fin qubits) (target : Fin qubits)
    (distinct : ∀ control, wires control ≠ target)
    (angles : PrimitiveBasis 5 → ExactAngle) :
    (compileUniformlyControlledRy 5 wires target distinct angles).ryCount = 32 ∧
    (compileUniformlyControlledRy 5 wires target distinct angles).cxCount = 62 := by
  constructor
  · simpa using compileUniformlyControlledRy_ryCount wires target distinct angles
  · simpa using compileUniformlyControlledRy_cxCount wires target distinct angles

end QuantumBlockEncoding
```

## QuantumBlockEncoding/PrimitiveBasisLE.lean

Raw-file SHA256: 00672a2bc6aab0861bf9dfed3eab651d3b649d3c5386d6f6ca8374e012e366ed

```lean
import QuantumBlockEncoding.PrimitiveSemantics

/-!
# Little-endian primitive basis indexing

The primitive circuit semantics names qubits by `Fin q`.  This file fixes the
conversion to flat matrix indices: wire zero is the least-significant bit.
Keeping this equivalence explicit prevents executable backends from silently
choosing a different register order.
-/

namespace QuantumBlockEncoding

/-- Convert named primitive bits to a flat little-endian matrix index. -/
def primitiveBasisLEEquiv : (q : Nat) -> PrimitiveBasis q ≃ Fin (gridSize q)
  | 0 =>
      { toFun := fun _ => ⟨0, by decide⟩
        invFun := fun _ => Fin.elim0
        left_inv := fun bits => funext fun wire => Fin.elim0 wire
        right_inv := fun index => by fin_cases index; rfl }
  | q + 1 =>
      (Fin.consEquiv (fun _ : Fin (q + 1) => Fin 2)).symm
        |>.trans (Equiv.prodCongr (Equiv.refl (Fin 2)) (primitiveBasisLEEquiv q))
        |>.trans (Equiv.prodComm (Fin 2) (Fin (gridSize q)))
        |>.trans finProdFinEquiv
        |>.trans (finCongr (by simp [gridSize, pow_succ]))

@[simp] theorem primitiveBasisLEEquiv_zero_apply (bits : PrimitiveBasis 0) :
    (primitiveBasisLEEquiv 0 bits).val = 0 := by
  rfl

/-- The recursive equation makes the little-endian convention inspectable. -/
theorem primitiveBasisLEEquiv_succ_value (q : Nat)
    (bits : PrimitiveBasis (q + 1)) :
    (primitiveBasisLEEquiv (q + 1) bits).val =
      (bits 0).val + 2 *
        (primitiveBasisLEEquiv q (fun wire => bits wire.succ)).val := by
  rfl

/-- Six-wire expansion used by the fixed Robin executable benchmark. -/
theorem primitiveBasisLEEquiv_six_value (bits : PrimitiveBasis 6) :
    (primitiveBasisLEEquiv 6 bits).val =
      (bits 0).val + 2 * (bits 1).val + 4 * (bits 2).val +
      8 * (bits 3).val + 16 * (bits 4).val + 32 * (bits 5).val := by
  native_decide +revert

/-- Explicit inverse used by finite two-wire state-preparation proofs. -/
def primitiveBits2LE (index : Fin 4) : PrimitiveBasis 2
  | 0 => ⟨index.val % 2, by omega⟩
  | _ => ⟨(index.val / 2) % 2, by omega⟩

@[simp] theorem primitiveBasisLEEquiv_two_symm (index : Fin 4) :
    (primitiveBasisLEEquiv 2).symm index = primitiveBits2LE index := by
  fin_cases index <;> native_decide

/-- Fixed-width coordinate reductions whose domain exactly matches the
`gridSize`-indexed finite matrix backend. -/
@[simp] theorem primitiveBasisLEEquiv_two_symm_wire_zero
    (index : Fin (gridSize 2)) :
    ((primitiveBasisLEEquiv 2).symm index) (0 : Fin 2) =
      ⟨index.val % 2, by omega⟩ := by
  native_decide +revert

@[simp] theorem primitiveBasisLEEquiv_two_symm_wire_one
    (index : Fin (gridSize 2)) :
    ((primitiveBasisLEEquiv 2).symm index) (1 : Fin 2) =
      ⟨(index.val / 2) % 2, by omega⟩ := by
  native_decide +revert

/-- Concrete inverse images used after `fin_cases`; these avoid relying on type
normalization between `Fin (gridSize 2)` and `Fin 4`. -/
@[simp] theorem primitiveBasisLEEquiv_two_symm_0 :
    (primitiveBasisLEEquiv 2).symm
        (⟨0, by norm_num [gridSize]⟩ : Fin (gridSize 2)) =
      primitiveBits2LE (0 : Fin 4) := by native_decide
@[simp] theorem primitiveBasisLEEquiv_two_symm_1 :
    (primitiveBasisLEEquiv 2).symm
        (⟨1, by norm_num [gridSize]⟩ : Fin (gridSize 2)) =
      primitiveBits2LE (1 : Fin 4) := by native_decide
@[simp] theorem primitiveBasisLEEquiv_two_symm_2 :
    (primitiveBasisLEEquiv 2).symm
        (⟨2, by norm_num [gridSize]⟩ : Fin (gridSize 2)) =
      primitiveBits2LE (2 : Fin 4) := by native_decide
@[simp] theorem primitiveBasisLEEquiv_two_symm_3 :
    (primitiveBasisLEEquiv 2).symm
        (⟨3, by norm_num [gridSize]⟩ : Fin (gridSize 2)) =
      primitiveBits2LE (3 : Fin 4) := by native_decide

/-- Encode the non-target wire of a two-qubit little-endian basis state. -/
def primitiveBits2LEWithout (target : Fin 2) (index : Fin 4) : Nat :=
  match target.val with
  | 0 => index.val / 2
  | _ => index.val % 2

/-- Same context code, but with the unreduced `gridSize` domain used by the
concrete matrix semantics. -/
def primitiveBits2LEGridWithout
    (target : Fin 2) (index : Fin (gridSize 2)) : Nat :=
  match target.val with
  | 0 => index.val / 2
  | _ => index.val % 2

@[simp] theorem splitPrimitiveWire_primitiveBits2LE_context_eq
    (target : Fin 2) (left right : Fin 4) :
    (splitPrimitiveWire target (primitiveBits2LE left)).2 =
        (splitPrimitiveWire target (primitiveBits2LE right)).2 ↔
      primitiveBits2LEWithout target left =
        primitiveBits2LEWithout target right := by
  native_decide +revert

@[simp] theorem splitPrimitiveWire_primitiveBasisLEEquiv_two_symm_context_eq
    (target : Fin 2) (left right : Fin (gridSize 2)) :
    (splitPrimitiveWire target ((primitiveBasisLEEquiv 2).symm left)).2 =
        (splitPrimitiveWire target ((primitiveBasisLEEquiv 2).symm right)).2 ↔
      primitiveBits2LEGridWithout target left =
        primitiveBits2LEGridWithout target right := by
  native_decide +revert

/-- Explicit inverse used by finite three-wire compiler proofs. -/
def primitiveBits3LE (index : Fin 8) : PrimitiveBasis 3
  | 0 => ⟨index.val % 2, by omega⟩
  | 1 => ⟨(index.val / 2) % 2, by omega⟩
  | _ => ⟨(index.val / 4) % 2, by omega⟩

@[simp] theorem primitiveBasisLEEquiv_three_symm (index : Fin 8) :
    (primitiveBasisLEEquiv 3).symm index = primitiveBits3LE index := by
  fin_cases index <;> native_decide

@[simp] theorem primitiveBasisLEEquiv_three_symm_wire_zero
    (index : Fin (gridSize 3)) :
    ((primitiveBasisLEEquiv 3).symm index) (0 : Fin 3) =
      ⟨index.val % 2, by omega⟩ := by
  native_decide +revert

@[simp] theorem primitiveBasisLEEquiv_three_symm_wire_one
    (index : Fin (gridSize 3)) :
    ((primitiveBasisLEEquiv 3).symm index) (1 : Fin 3) =
      ⟨(index.val / 2) % 2, by omega⟩ := by
  native_decide +revert

@[simp] theorem primitiveBasisLEEquiv_three_symm_wire_two
    (index : Fin (gridSize 3)) :
    ((primitiveBasisLEEquiv 3).symm index) (2 : Fin 3) =
      ⟨(index.val / 4) % 2, by omega⟩ := by
  native_decide +revert

/-- Concrete inverse images for all eight three-qubit basis states. -/
@[simp] theorem primitiveBasisLEEquiv_three_symm_0 :
    (primitiveBasisLEEquiv 3).symm
        (⟨0, by norm_num [gridSize]⟩ : Fin (gridSize 3)) =
      primitiveBits3LE (0 : Fin 8) := by native_decide
@[simp] theorem primitiveBasisLEEquiv_three_symm_1 :
    (primitiveBasisLEEquiv 3).symm
        (⟨1, by norm_num [gridSize]⟩ : Fin (gridSize 3)) =
      primitiveBits3LE (1 : Fin 8) := by native_decide
@[simp] theorem primitiveBasisLEEquiv_three_symm_2 :
    (primitiveBasisLEEquiv 3).symm
        (⟨2, by norm_num [gridSize]⟩ : Fin (gridSize 3)) =
      primitiveBits3LE (2 : Fin 8) := by native_decide
@[simp] theorem primitiveBasisLEEquiv_three_symm_3 :
    (primitiveBasisLEEquiv 3).symm
        (⟨3, by norm_num [gridSize]⟩ : Fin (gridSize 3)) =
      primitiveBits3LE (3 : Fin 8) := by native_decide
@[simp] theorem primitiveBasisLEEquiv_three_symm_4 :
    (primitiveBasisLEEquiv 3).symm
        (⟨4, by norm_num [gridSize]⟩ : Fin (gridSize 3)) =
      primitiveBits3LE (4 : Fin 8) := by native_decide
@[simp] theorem primitiveBasisLEEquiv_three_symm_5 :
    (primitiveBasisLEEquiv 3).symm
        (⟨5, by norm_num [gridSize]⟩ : Fin (gridSize 3)) =
      primitiveBits3LE (5 : Fin 8) := by native_decide
@[simp] theorem primitiveBasisLEEquiv_three_symm_6 :
    (primitiveBasisLEEquiv 3).symm
        (⟨6, by norm_num [gridSize]⟩ : Fin (gridSize 3)) =
      primitiveBits3LE (6 : Fin 8) := by native_decide
@[simp] theorem primitiveBasisLEEquiv_three_symm_7 :
    (primitiveBasisLEEquiv 3).symm
        (⟨7, by norm_num [gridSize]⟩ : Fin (gridSize 3)) =
      primitiveBits3LE (7 : Fin 8) := by native_decide

def primitiveBits3LEWithout (target : Fin 3) (index : Fin 8) : Nat :=
  match target.val with
  | 0 => index.val / 2
  | 1 => index.val % 2 + 2 * (index.val / 4)
  | _ => index.val % 4

/-- Grid-sized companion of `primitiveBits3LEWithout`, used before the type
normalizer has turned `Fin (gridSize 3)` into `Fin 8`. -/
def primitiveBits3LEGridWithout
    (target : Fin 3) (index : Fin (gridSize 3)) : Nat :=
  match target.val with
  | 0 => index.val / 2
  | 1 => index.val % 2 + 2 * (index.val / 4)
  | _ => index.val % 4

@[simp] theorem splitPrimitiveWire_primitiveBits3LE_context_eq
    (target : Fin 3) (left right : Fin 8) :
    (splitPrimitiveWire target (primitiveBits3LE left)).2 =
        (splitPrimitiveWire target (primitiveBits3LE right)).2 ↔
      primitiveBits3LEWithout target left =
        primitiveBits3LEWithout target right := by
  native_decide +revert

@[simp] theorem splitPrimitiveWire_primitiveBasisLEEquiv_three_symm_context_eq
    (target : Fin 3) (left right : Fin (gridSize 3)) :
    (splitPrimitiveWire target ((primitiveBasisLEEquiv 3).symm left)).2 =
        (splitPrimitiveWire target ((primitiveBasisLEEquiv 3).symm right)).2 ↔
      primitiveBits3LEGridWithout target left =
        primitiveBits3LEGridWithout target right := by
  native_decide +revert

end QuantumBlockEncoding
```

## QuantumBlockEncoding/PrimitiveSemantics.lean

Raw-file SHA256: a68955f9dbe0e951c2751fcd14c535c28da7c8bcac75787b0005808b951f28de

```lean
import QuantumBlockEncoding.PrimitiveCircuit
import QuantumBlockEncoding.Robin.Hadamard8Verified
import Mathlib.Tactic

/-!
# Exact matrix semantics for the primitive basis

The standard `RY` convention uses a half angle.  The bridge theorem below is
the convention check needed by every Robin coefficient loader.
-/

namespace QuantumBlockEncoding

open QuantumBlockEncoding.Robin.ComplexLCU
open scoped Kronecker

/-- Standard `RY(theta)` in the convention used by Qiskit and OpenQASM 3. -/
noncomputable def standardRyMatrix (theta : Real) :
    _root_.Matrix (Fin 2) (Fin 2) ℂ :=
  realRotation (theta / 2)

@[simp] theorem standardRyMatrix_zero : standardRyMatrix 0 = 1 := by
  ext row column
  fin_cases row <;> fin_cases column <;>
    simp [standardRyMatrix, realRotation, realOrthogonalRotation]

/-- Standard rotations compose by adding their physical angles. -/
theorem standardRyMatrix_add (left right : Real) :
    standardRyMatrix (left + right) =
      standardRyMatrix right * standardRyMatrix left := by
  have halfAdd : (left + right) / 2 = left / 2 + right / 2 := by ring
  rw [standardRyMatrix, halfAdd]
  ext row column
  fin_cases row <;> fin_cases column <;>
    simp [standardRyMatrix, realRotation, realOrthogonalRotation,
      _root_.Matrix.mul_apply, Fin.sum_univ_two,
      Real.sin_add, Real.cos_add] <;> ring

@[simp] theorem star_complex_cos_ofReal (theta : Real) :
    star (Complex.cos (theta : ℂ)) = Complex.cos (theta : ℂ) := by
  rw [← Complex.ofReal_cos, Complex.star_def, Complex.conj_ofReal]

@[simp] theorem conj_complex_cos_ofReal (theta : Real) :
    (starRingEnd ℂ) (Complex.cos (theta : ℂ)) =
      Complex.cos (theta : ℂ) := by
  rw [← Complex.ofReal_cos, Complex.conj_ofReal]

@[simp] theorem star_complex_sin_ofReal (theta : Real) :
    star (Complex.sin (theta : ℂ)) = Complex.sin (theta : ℂ) := by
  rw [← Complex.ofReal_sin, Complex.star_def, Complex.conj_ofReal]

@[simp] theorem conj_complex_sin_ofReal (theta : Real) :
    (starRingEnd ℂ) (Complex.sin (theta : ℂ)) =
      Complex.sin (theta : ℂ) := by
  rw [← Complex.ofReal_sin, Complex.conj_ofReal]

theorem complex_ofReal_div_two (theta : Real) :
    (theta : ℂ) / 2 = ((theta / 2 : Real) : ℂ) := by
  norm_num

@[simp] theorem conj_complex_cos_ofReal_div_two (theta : Real) :
    (starRingEnd ℂ) (Complex.cos ((theta : ℂ) / 2)) =
      Complex.cos ((theta : ℂ) / 2) := by
  rw [complex_ofReal_div_two, ← Complex.ofReal_cos, Complex.conj_ofReal]

@[simp] theorem conj_complex_sin_ofReal_div_two (theta : Real) :
    (starRingEnd ℂ) (Complex.sin ((theta : ℂ) / 2)) =
      Complex.sin ((theta : ℂ) / 2) := by
  rw [complex_ofReal_div_two, ← Complex.ofReal_sin, Complex.conj_ofReal]

@[simp] theorem standardRyMatrix_neg (theta : Real) :
    standardRyMatrix (-theta) = star (standardRyMatrix theta) := by
  change realRotation (-theta / 2) = star (realRotation (theta / 2))
  rw [show -theta / 2 = -(theta / 2) by ring]
  ext row column
  fin_cases row <;> fin_cases column <;>
    simp [realRotation, realOrthogonalRotation]

/-- Pauli X in the same two-dimensional basis as `standardRyMatrix`. -/
def xMatrix : _root_.Matrix (Fin 2) (Fin 2) ℂ := fun row column =>
  if row = column then 0 else 1

theorem xMatrix_conjugates_standardRy (theta : Real) :
    xMatrix * standardRyMatrix theta * xMatrix = standardRyMatrix (-theta) := by
  rw [standardRyMatrix_neg]
  ext row column
  fin_cases row <;> fin_cases column <;>
    simp [xMatrix, standardRyMatrix, realRotation, realOrthogonalRotation,
      _root_.Matrix.mul_apply, Fin.sum_univ_two]

theorem standardRyMatrix_unitary (theta : Real) :
    standardRyMatrix theta ∈ _root_.Matrix.unitaryGroup (Fin 2) ℂ :=
  realRotation_unitary _

/-- The exact half-angle correction from standard `RY` to the logical loader. -/
theorem standardRyMatrix_two_arccos_eq_amplitudeRotation
    (coefficient : Real) (_lower : -1 ≤ coefficient)
    (_upper : coefficient ≤ 1) :
    standardRyMatrix (2 * Real.arccos coefficient) =
      amplitudeRotation coefficient := by
  unfold standardRyMatrix amplitudeRotation
  congr 1
  ring

/-- The symmetry PREPARE is exactly a standard `RY(pi/2)`, not an opaque H. -/
theorem standardRyMatrix_pi_div_two_eq_warmRobinUniformBitPrepare :
    standardRyMatrix (Real.pi / 2) =
      QuantumBlockEncoding.Robin.warmRobinUniformBitPrepare := by
  have half : (Real.pi / 2) / 2 = Real.pi / 4 := by ring
  unfold standardRyMatrix
  rw [half]
  unfold realRotation QuantumBlockEncoding.Robin.warmRobinUniformBitPrepare
  rw [Real.cos_pi_div_four, Real.sin_pi_div_four]

/-- Computational-basis bit strings with one named coordinate per qubit. -/
abbrev PrimitiveBasis (qubits : Nat) := Fin qubits → Fin 2

def flipBit (bit : Fin 2) : Fin 2 := if bit = 0 then 1 else 0

@[simp] theorem flipBit_flipBit (bit : Fin 2) : flipBit (flipBit bit) = bit := by
  fin_cases bit <;> rfl

def xBasisAction {qubits : Nat} (target : Fin qubits)
    (state : PrimitiveBasis qubits) : PrimitiveBasis qubits :=
  Function.update state target (flipBit (state target))

theorem xBasisAction_involutive {qubits : Nat} (target : Fin qubits) :
    Function.Involutive (xBasisAction target) := by
  intro state
  funext wire
  by_cases same : wire = target
  · subst wire
    simp [xBasisAction]
  · simp [xBasisAction, same]

def xBasisEquiv {qubits : Nat} (target : Fin qubits) :
    PrimitiveBasis qubits ≃ PrimitiveBasis qubits where
  toFun := xBasisAction target
  invFun := xBasisAction target
  left_inv := xBasisAction_involutive target
  right_inv := xBasisAction_involutive target

def cxBasisAction {qubits : Nat} (control target : Fin qubits)
    (state : PrimitiveBasis qubits) : PrimitiveBasis qubits :=
  if state control = 0 then state else xBasisAction target state

theorem cxBasisAction_involutive {qubits : Nat}
    (control target : Fin qubits) (distinct : control ≠ target) :
    Function.Involutive (cxBasisAction control target) := by
  intro state
  by_cases controlZero : state control = 0
  · simp [cxBasisAction, controlZero]
  · have controlUnchanged : xBasisAction target state control = state control := by
      simp [xBasisAction, distinct]
    simp [cxBasisAction, controlZero, controlUnchanged,
      xBasisAction_involutive target state]

def cxBasisEquiv {qubits : Nat} (control target : Fin qubits)
    (distinct : control ≠ target) :
    PrimitiveBasis qubits ≃ PrimitiveBasis qubits where
  toFun := cxBasisAction control target
  invFun := cxBasisAction control target
  left_inv := cxBasisAction_involutive control target distinct
  right_inv := cxBasisAction_involutive control target distinct

@[simp] theorem cxBasisEquiv_apply {qubits : Nat}
    (control target : Fin qubits) (distinct : control ≠ target)
    (state : PrimitiveBasis qubits) :
    cxBasisEquiv control target distinct state =
      cxBasisAction control target state := rfl

abbrev OtherPrimitiveWires {qubits : Nat} (target : Fin qubits) :=
  {wire : Fin qubits // wire ≠ target}

def splitPrimitiveWire {qubits : Nat} (target : Fin qubits) :
    PrimitiveBasis qubits ≃
      Fin 2 × (OtherPrimitiveWires target → Fin 2) where
  toFun state := (state target, fun wire => state wire.1)
  invFun pair wire :=
    if same : wire = target then pair.1 else pair.2 ⟨wire, same⟩
  left_inv state := by
    funext wire
    by_cases same : wire = target
    · subst wire
      simp
    · simp [same]
  right_inv pair := by
    rcases pair with ⟨targetBit, otherBits⟩
    apply Prod.ext
    · simp
    · funext wire
      simp [wire.property]

theorem splitPrimitiveWire_other_apply {qubits : Nat}
    (target : Fin qubits) (state : PrimitiveBasis qubits)
    (wire : OtherPrimitiveWires target) :
    (splitPrimitiveWire target state).2 wire = state wire.1 := rfl

/-- Lift a one-qubit matrix to a named wire, leaving every other wire fixed. -/
noncomputable def liftPrimitiveOneQubit {qubits : Nat} (target : Fin qubits)
    (gate : _root_.Matrix (Fin 2) (Fin 2) ℂ) :
    _root_.Matrix (PrimitiveBasis qubits) (PrimitiveBasis qubits) ℂ :=
  _root_.Matrix.reindexAlgEquiv ℂ ℂ (splitPrimitiveWire target).symm
    (gate ⊗ₖ (1 : _root_.Matrix
      (OtherPrimitiveWires target → Fin 2)
      (OtherPrimitiveWires target → Fin 2) ℂ))

@[simp] theorem liftPrimitiveOneQubit_apply {qubits : Nat}
    (target : Fin qubits) (gate : _root_.Matrix (Fin 2) (Fin 2) ℂ)
    (row column : PrimitiveBasis qubits) :
    liftPrimitiveOneQubit target gate row column =
      if (splitPrimitiveWire target row).2 =
          (splitPrimitiveWire target column).2 then
        gate (row target) (column target)
      else 0 := by
  simp only [liftPrimitiveOneQubit, _root_.Matrix.reindexAlgEquiv_apply,
    _root_.Matrix.reindex_apply, _root_.Matrix.submatrix_apply,
    _root_.Matrix.kroneckerMap_apply, _root_.Matrix.one_apply,
    Equiv.symm_symm]
  by_cases contextsEqual :
      (splitPrimitiveWire target row).2 =
        (splitPrimitiveWire target column).2
  · simp [contextsEqual, splitPrimitiveWire]
  · simp [contextsEqual, splitPrimitiveWire]

theorem liftPrimitiveOneQubit_unitary {qubits : Nat} (target : Fin qubits)
    (gate : _root_.Matrix (Fin 2) (Fin 2) ℂ)
    (unitary : gate ∈ _root_.Matrix.unitaryGroup (Fin 2) ℂ) :
    liftPrimitiveOneQubit target gate ∈
      _root_.Matrix.unitaryGroup (PrimitiveBasis qubits) ℂ := by
  apply reindex_unitary
  apply _root_.Matrix.kronecker_mem_unitary
  · exact unitary
  · exact (_root_.Matrix.unitaryGroup
      (OtherPrimitiveWires target → Fin 2) ℂ).one_mem

/-- Standard exact `RZ(theta)` matrix, including its phase convention. -/
noncomputable def standardRzMatrix (theta : Real) :
    _root_.Matrix (Fin 2) (Fin 2) ℂ := fun row column =>
  if row = column then
    if row = 0 then
      (Real.cos (theta / 2) : ℂ) - (Real.sin (theta / 2) : ℂ) * Complex.I
    else
      (Real.cos (theta / 2) : ℂ) + (Real.sin (theta / 2) : ℂ) * Complex.I
  else 0

theorem standardRzMatrix_unitary (theta : Real) :
    standardRzMatrix theta ∈ _root_.Matrix.unitaryGroup (Fin 2) ℂ := by
  let c := Real.cos (theta / 2)
  let s := Real.sin (theta / 2)
  have trig : s ^ 2 + c ^ 2 = 1 := by
    simp [c, s, Real.sin_sq_add_cos_sq]
  have minusNorm :
      star ((c : ℂ) - (s : ℂ) * Complex.I) *
          ((c : ℂ) - (s : ℂ) * Complex.I) = 1 := by
    apply Complex.ext <;> simp <;> nlinarith
  have plusNorm :
      star ((c : ℂ) + (s : ℂ) * Complex.I) *
          ((c : ℂ) + (s : ℂ) * Complex.I) = 1 := by
    apply Complex.ext <;> simp <;> nlinarith
  rw [_root_.Matrix.mem_unitaryGroup_iff']
  ext row column
  fin_cases row <;> fin_cases column
  · simpa [standardRzMatrix, _root_.Matrix.mul_apply, c, s] using minusNorm
  · simp [standardRzMatrix, _root_.Matrix.mul_apply]
  · simp [standardRzMatrix, _root_.Matrix.mul_apply]
  · simpa [standardRzMatrix, _root_.Matrix.mul_apply, c, s] using plusNorm

@[simp] theorem standardRzMatrix_neg (theta : Real) :
    standardRzMatrix (-theta) = star (standardRzMatrix theta) := by
  ext row column
  fin_cases row <;> fin_cases column
  · change
      (Real.cos (-theta / 2) : ℂ) -
          (Real.sin (-theta / 2) : ℂ) * Complex.I =
        star ((Real.cos (theta / 2) : ℂ) -
          (Real.sin (theta / 2) : ℂ) * Complex.I)
    rw [show -theta / 2 = -(theta / 2) by ring,
      Real.cos_neg, Real.sin_neg]
    simp
  · simp [standardRzMatrix, _root_.Matrix.star_apply]
  · simp [standardRzMatrix, _root_.Matrix.star_apply]
  · change
      (Real.cos (-theta / 2) : ℂ) +
          (Real.sin (-theta / 2) : ℂ) * Complex.I =
        star ((Real.cos (theta / 2) : ℂ) +
          (Real.sin (theta / 2) : ℂ) * Complex.I)
    rw [show -theta / 2 = -(theta / 2) by ring,
      Real.cos_neg, Real.sin_neg]
    simp

theorem star_equivPermutationMatrix
    {index : Type*} [Fintype index] [DecidableEq index]
    (equiv : index ≃ index) :
    star (equivPermutationMatrix equiv) =
      equivPermutationMatrix equiv.symm := by
  ext row column
  rw [_root_.Matrix.star_apply]
  simp only [equivPermutationMatrix]
  by_cases hit : column = equiv row
  · have reverseHit : row = equiv.symm column := by
      simpa using (congrArg equiv.symm hit).symm
    rw [if_pos hit, if_pos reverseHit]
    exact star_one ℂ
  · have reverseMiss : row ≠ equiv.symm column := by
      intro reverseHit
      apply hit
      simpa using (congrArg equiv reverseHit).symm
    rw [if_neg hit, if_neg reverseMiss]
    exact star_zero ℂ

theorem star_liftPrimitiveOneQubit {qubits : Nat} (target : Fin qubits)
    (gate : _root_.Matrix (Fin 2) (Fin 2) ℂ) :
    star (liftPrimitiveOneQubit target gate) =
      liftPrimitiveOneQubit target (star gate) := by
  ext row column
  simp only [liftPrimitiveOneQubit, _root_.Matrix.reindexAlgEquiv_apply,
    _root_.Matrix.reindex_apply, _root_.Matrix.submatrix_apply,
    _root_.Matrix.star_apply, _root_.Matrix.kroneckerMap_apply,
    _root_.Matrix.one_apply, Equiv.symm_symm]
  by_cases otherEqual :
      (splitPrimitiveWire target row).2 = (splitPrimitiveWire target column).2
  · rw [if_pos otherEqual.symm, if_pos otherEqual, StarMul.star_mul,
      star_one, one_mul, mul_one]
  · rw [if_neg (Ne.symm otherEqual), if_neg otherEqual, mul_zero,
      star_zero, mul_zero]

/-- Exact matrix denotation of one primitive instruction. -/
noncomputable def evalPrimitiveGate {qubits : Nat} : PrimitiveGate qubits →
    _root_.Matrix (PrimitiveBasis qubits) (PrimitiveBasis qubits) ℂ
  | .x target => equivPermutationMatrix (xBasisEquiv target)
  | .ry target angle => liftPrimitiveOneQubit target (standardRyMatrix angle.eval)
  | .rz target angle => liftPrimitiveOneQubit target (standardRzMatrix angle.eval)
  | .cx control target distinct =>
      equivPermutationMatrix (cxBasisEquiv control target distinct)

theorem evalPrimitiveGate_unitary {qubits : Nat} (gate : PrimitiveGate qubits) :
    evalPrimitiveGate gate ∈
      _root_.Matrix.unitaryGroup (PrimitiveBasis qubits) ℂ := by
  cases gate with
  | x target => exact equivPermutationMatrix_unitary _
  | ry target angle =>
      exact liftPrimitiveOneQubit_unitary target _ (standardRyMatrix_unitary _)
  | rz target angle =>
      exact liftPrimitiveOneQubit_unitary target _ (standardRzMatrix_unitary _)
  | cx control target distinct => exact equivPermutationMatrix_unitary _

theorem xBasisEquiv_symm {qubits : Nat} (target : Fin qubits) :
    (xBasisEquiv target).symm = xBasisEquiv target := by
  rfl

theorem cxBasisEquiv_symm {qubits : Nat} (control target : Fin qubits)
    (distinct : control ≠ target) :
    (cxBasisEquiv control target distinct).symm =
      cxBasisEquiv control target distinct := by
  rfl

theorem evalPrimitiveGate_dagger {qubits : Nat}
    (gate : PrimitiveGate qubits) :
    evalPrimitiveGate gate.dagger = star (evalPrimitiveGate gate) := by
  cases gate with
  | x target =>
      rw [evalPrimitiveGate, PrimitiveGate.dagger,
        star_equivPermutationMatrix, xBasisEquiv_symm]
      rfl
  | ry target angle =>
      simp only [PrimitiveGate.dagger, evalPrimitiveGate, ExactAngle.eval_neg,
        standardRyMatrix_neg]
      rw [star_liftPrimitiveOneQubit]
  | rz target angle =>
      simp only [PrimitiveGate.dagger, evalPrimitiveGate, ExactAngle.eval_neg,
        standardRzMatrix_neg]
      rw [star_liftPrimitiveOneQubit]
  | cx control target distinct =>
      rw [evalPrimitiveGate, PrimitiveGate.dagger,
        star_equivPermutationMatrix, cxBasisEquiv_symm]
      rfl

/-- Chronological circuit evaluation: later instructions multiply on the left. -/
noncomputable def evalPrimitiveCircuit {qubits : Nat} : PrimitiveCircuit qubits →
    _root_.Matrix (PrimitiveBasis qubits) (PrimitiveBasis qubits) ℂ
  | [] => 1
  | gate :: rest => evalPrimitiveCircuit rest * evalPrimitiveGate gate

theorem evalPrimitiveCircuit_unitary {qubits : Nat}
    (circuit : PrimitiveCircuit qubits) :
    evalPrimitiveCircuit circuit ∈
      _root_.Matrix.unitaryGroup (PrimitiveBasis qubits) ℂ := by
  induction circuit with
  | nil => exact (_root_.Matrix.unitaryGroup (PrimitiveBasis qubits) ℂ).one_mem
  | cons gate rest induction =>
      exact (_root_.Matrix.unitaryGroup (PrimitiveBasis qubits) ℂ).mul_mem
        induction (evalPrimitiveGate_unitary gate)

theorem evalPrimitiveCircuit_append {qubits : Nat}
    (left right : PrimitiveCircuit qubits) :
    evalPrimitiveCircuit (left ++ right) =
      evalPrimitiveCircuit right * evalPrimitiveCircuit left := by
  induction left with
  | nil => simp [evalPrimitiveCircuit]
  | cons gate rest induction =>
      simp only [List.cons_append, evalPrimitiveCircuit]
      rw [induction]
      simp [mul_assoc]

theorem evalPrimitiveCircuit_dagger {qubits : Nat}
    (circuit : PrimitiveCircuit qubits) :
    evalPrimitiveCircuit (circuit.reverse.map PrimitiveGate.dagger) =
      star (evalPrimitiveCircuit circuit) := by
  induction circuit with
  | nil => simp [evalPrimitiveCircuit]
  | cons gate rest induction =>
      simp only [List.reverse_cons, List.map_append, List.map_singleton,
        evalPrimitiveCircuit_append, evalPrimitiveCircuit]
      rw [induction, evalPrimitiveGate_dagger]
      simp

/-- Unit-modulus scalar represented by an exact global phase. -/
noncomputable def evalGlobalPhase (angle : ExactAngle) : ℂ :=
  Complex.exp ((angle.eval : ℂ) * Complex.I)

theorem evalGlobalPhase_unitary (angle : ExactAngle) :
    evalGlobalPhase angle ∈ unitary ℂ := by
  unfold evalGlobalPhase
  rw [Unitary.mem_iff]
  constructor
  · change (starRingEnd ℂ)
        (Complex.exp ((angle.eval : ℂ) * Complex.I)) * _ = 1
    rw [← Complex.exp_conj, ← Complex.exp_add]
    simp
  · change _ * (starRingEnd ℂ)
        (Complex.exp ((angle.eval : ℂ) * Complex.I)) = 1
    rw [← Complex.exp_conj, ← Complex.exp_add]
    simp

@[simp] theorem evalGlobalPhase_neg (angle : ExactAngle) :
    evalGlobalPhase (.neg angle) = star (evalGlobalPhase angle) := by
  unfold evalGlobalPhase
  rw [ExactAngle.eval_neg, Complex.star_def, ← Complex.exp_conj]
  congr 2
  simp

/-- Exact program semantics, with the same `exp(i phase)` convention used by
Qiskit and OpenQASM 3. -/
noncomputable def evalPrimitiveProgram {qubits : Nat}
    (program : PrimitiveProgram qubits) :
    _root_.Matrix (PrimitiveBasis qubits) (PrimitiveBasis qubits) ℂ :=
  evalGlobalPhase program.globalPhase • evalPrimitiveCircuit program.circuit

@[simp] theorem evalPrimitiveProgram_identity (qubits : Nat) :
    evalPrimitiveProgram (PrimitiveProgram.identity qubits) = 1 := by
  simp [evalPrimitiveProgram, evalGlobalPhase, PrimitiveProgram.identity,
    evalPrimitiveCircuit, ExactAngle.eval]

theorem evalPrimitiveProgram_seq {qubits : Nat}
    (left right : PrimitiveProgram qubits) :
    evalPrimitiveProgram (PrimitiveProgram.seq left right) =
      evalPrimitiveProgram right * evalPrimitiveProgram left := by
  simp only [evalPrimitiveProgram, PrimitiveProgram.seq,
    ExactAngle.eval_add, evalPrimitiveCircuit_append, evalGlobalPhase]
  rw [Complex.ofReal_add, add_mul, Complex.exp_add]
  ext row column
  simp only [_root_.Matrix.smul_apply, _root_.Matrix.mul_apply, smul_eq_mul]
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro wire _
  ring

theorem evalPrimitiveProgram_unitary {qubits : Nat}
    (program : PrimitiveProgram qubits) :
    evalPrimitiveProgram program ∈
      _root_.Matrix.unitaryGroup (PrimitiveBasis qubits) ℂ := by
  exact Unitary.smul_mem_of_mem (evalGlobalPhase_unitary program.globalPhase)
    (evalPrimitiveCircuit_unitary program.circuit)

theorem evalPrimitiveProgram_dagger {qubits : Nat}
    (program : PrimitiveProgram qubits) :
    evalPrimitiveProgram program.dagger = star (evalPrimitiveProgram program) := by
  change evalGlobalPhase (.neg program.globalPhase) •
      evalPrimitiveCircuit
        (program.circuit.reverse.map PrimitiveGate.dagger) =
    star (evalGlobalPhase program.globalPhase •
      evalPrimitiveCircuit program.circuit)
  rw [evalGlobalPhase_neg, evalPrimitiveCircuit_dagger]
  simp

/-- A typed primitive refinement records exact equality, not equality up to phase. -/
structure PrimitiveRefinement (qubits : Nat) where
  circuit : PrimitiveCircuit qubits
  target : _root_.Matrix (PrimitiveBasis qubits) (PrimitiveBasis qubits) ℂ
  exact : evalPrimitiveCircuit circuit = target

end QuantumBlockEncoding
```

## QuantumBlockEncoding/StatePreparation.lean

Raw-file SHA256: 2585a3b5ef2a58a0f7fb33664552e9166373cec2815eddf2542c9db66cb5f52f

```lean
import QuantumBlockEncoding.BlockEncoding

/-!
# State-preparation certificates

State preparation is the first ABEIS application surface.  A target is a
normalized amplitude vector, and a candidate is a unitary whose first
computational-basis column equals that vector.  The analytic backend supplies
the concrete normalization, unitarity, and approximation predicates.
-/

namespace QuantumBlockEncoding

/-- The computational all-zero basis index in an `n`-qubit register. -/
def zeroBasisIndex (n : Nat) : Fin (gridSize n) :=
  ⟨0, Nat.pow_pos (by decide)⟩

/-- A normalized state requested by the user. -/
structure StatePreparationTarget (α : Type u) (qubits : Nat) where
  amplitudes : Fin (gridSize qubits) → α
  normalization : Prop
  source : String := ""

/-- The matrix-level first-column acceptance predicate. -/
def FirstColumnMatches {α : Type u} {qubits : Nat}
    (unitary : Matrix (gridSize qubits) (gridSize qubits) α)
    (target : StatePreparationTarget α qubits) : Prop :=
  ∀ row, unitary row (zeroBasisIndex qubits) = target.amplitudes row

/-- A state-preparation candidate before semantic proofs are attached. -/
structure StatePreparationCandidate (α : Type u) (qubits : Nat) where
  target : StatePreparationTarget α qubits
  unitary : Matrix (gridSize qubits) (gridSize qubits) α
  circuit : Circuit
  schedule : LayeredCircuit := []
  resource : Resource
  auxiliaryQubits : Nat := 0
  isUnitary : Prop

namespace StatePreparationCandidate

/-- The candidate's fixed semantic target; callers cannot replace it by a flag. -/
def preparesTarget (candidate : StatePreparationCandidate α qubits) : Prop :=
  FirstColumnMatches candidate.unitary candidate.target

/-- Reuse the block-encoding resource order for state-preparation candidates. -/
def cost (candidate : StatePreparationCandidate α qubits) : BlockEncodingCost :=
  {
    auxiliaryQubits := candidate.auxiliaryQubits
    gateCount := candidate.resource.gates
    depth := candidate.resource.depth
    oracleCalls := candidate.resource.oracleCalls
  }

end StatePreparationCandidate

/-- A candidate promoted by proofs of normalization, unitarity, and state action. -/
structure VerifiedStatePreparation (α : Type u) (qubits : Nat) where
  candidate : StatePreparationCandidate α qubits
  normalizationProof : candidate.target.normalization
  unitaryProof : candidate.isUnitary
  preparationProof : candidate.preparesTarget

/-- An approximate candidate with a backend-specific state-error predicate. -/
structure ApproximateStatePreparationCandidate
    (α : Type u) (qubits : Nat) where
  candidate : StatePreparationCandidate α qubits
  epsilon : α
  approximationBound : Prop

/-- A verified approximate state-preparation certificate. -/
structure VerifiedApproximateStatePreparation
    (α : Type u) (qubits : Nat) where
  approxCandidate : ApproximateStatePreparationCandidate α qubits
  normalizationProof : approxCandidate.candidate.target.normalization
  unitaryProof : approxCandidate.candidate.isUnitary
  approximationProof : approxCandidate.approximationBound

namespace VerifiedStatePreparation

/--
Package an exact state-preparation certificate as a zero-error approximate
certificate when the backend uses the exact first-column predicate as its
zero-error proposition.
-/
def asZeroErrorApprox [OfNat α 0]
    (verified : VerifiedStatePreparation α qubits) :
    VerifiedApproximateStatePreparation α qubits where
  approxCandidate := {
    candidate := verified.candidate
    epsilon := 0
    approximationBound := verified.candidate.preparesTarget
  }
  normalizationProof := verified.normalizationProof
  unitaryProof := verified.unitaryProof
  approximationProof := verified.preparationProof

theorem firstColumn
    (verified : VerifiedStatePreparation α qubits) :
    verified.candidate.preparesTarget :=
  verified.preparationProof

end VerifiedStatePreparation

end QuantumBlockEncoding
```

## QuantumBlockEncoding/RectangularGivens.lean

Raw-file SHA256: aa4b908e26c0e0b0bccc05034b839f170fb4a2641d96b713ff8d3fac731bcb52

```lean
import QuantumBlockEncoding.AdjacentGivens

/-!
# Deterministic rectangular adjacent-row elimination

The recurrence processes each column in order, with a bottom-up adjacent
Givens sweep when the pivot row exists. It returns its actual rotation list
and an upper-trapezoidal residual, with an exact orthogonal recovery map.
This is exact-real semantics, not an arithmetic evaluation cost theorem.
-/

namespace QuantumBlockEncoding.RectangularGivens

open AdjacentGivens

noncomputable def sweep {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (k : ℕ) : (remaining : ℕ) → k + remaining ≤ M →
      _root_.Matrix (Fin N) (Fin M) ℝ
  | 0, _ => A
  | remaining + 1, columns =>
      if h : k < N then
        sweep (columnSweep A ⟨k, by omega⟩ k (N - 1 - k) (by omega))
          (k + 1) remaining (by omega)
      else sweep A (k + 1) remaining (by omega)

noncomputable def sweepSteps {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (k : ℕ) : (remaining : ℕ) → k + remaining ≤ M → List (Step N)
  | 0, _ => []
  | remaining + 1, columns =>
      if h : k < N then
        columnSweepSteps A ⟨k, by omega⟩ k (N - 1 - k) (by omega) ++
          sweepSteps (columnSweep A ⟨k, by omega⟩ k (N - 1 - k) (by omega))
            (k + 1) remaining (by omega)
      else sweepSteps A (k + 1) remaining (by omega)

theorem sweepSteps_action {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (k remaining : ℕ) (columns : k + remaining ≤ M) :
    applySteps (sweepSteps A k remaining columns) A = sweep A k remaining columns := by
  induction remaining generalizing A k with
  | zero => rfl
  | succ remaining ih =>
      by_cases h : k < N
      · simp only [sweepSteps, sweep, dif_pos h, applySteps_append, columnSweepSteps_action]
        exact ih _ _ _
      · simp only [sweepSteps, sweep, dif_neg h]
        exact ih _ _ _

/-- Previously eliminated columns vanish strictly below their diagonal. -/
def UpperPrefix {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ) (k : ℕ) : Prop :=
  ∀ col : Fin M, col.val < k → ∀ row : Fin N, col.val < row.val → A row col = 0

theorem columnSweep_upperPrefix {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (col : Fin M) (h : col.val < N) (fixedPrefix : UpperPrefix A col.val) :
    UpperPrefix (columnSweep A col col.val (N - 1 - col.val) (by omega)) (col.val + 1) := by
  intro old oldLt row below
  by_cases same : old = col
  · subst old
    exact columnSweep_zeroed A col col.val _ _ row below (by omega)
  · have oldEarlier : old.val < col.val := by
      have unequal : old.val ≠ col.val := fun eq => same (Fin.ext eq)
      omega
    rw [columnSweep_preserves_zero_column]
    · exact fixedPrefix old oldEarlier row below
    · intro r lower upper
      exact fixedPrefix old oldEarlier r (by omega)

theorem sweep_upperPrefix {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (k remaining : ℕ) (columns : k + remaining ≤ M) (fixedPrefix : UpperPrefix A k) :
    UpperPrefix (sweep A k remaining columns) (k + remaining) := by
  induction remaining generalizing A k with
  | zero => simpa [sweep] using fixedPrefix
  | succ remaining ih =>
      by_cases h : k < N
      · rw [sweep, dif_pos h]
        have result := ih _ (k + 1) (by omega)
          (columnSweep_upperPrefix A ⟨k, by omega⟩ h fixedPrefix)
        simpa only [Nat.add_assoc, Nat.add_left_comm, Nat.add_comm] using result
      · rw [sweep, dif_neg h]
        have next : UpperPrefix A (k + 1) := by
          intro col oldLt row below
          exact fixedPrefix col (by omega) row below
        have result := ih A (k + 1) (by omega) next
        simpa only [Nat.add_assoc, Nat.add_left_comm, Nat.add_comm] using result

theorem sweepSteps_length_le {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (k remaining : ℕ) (columns : k + remaining ≤ M) :
    (sweepSteps A k remaining columns).length ≤ N * remaining := by
  induction remaining generalizing A k with
  | zero => simp [sweepSteps]
  | succ remaining ih =>
      by_cases h : k < N
      · simp only [sweepSteps, dif_pos h, List.length_append, columnSweepSteps_length]
        have next := ih (columnSweep A ⟨k, by omega⟩ k (N - 1 - k) (by omega))
          (k + 1) (by omega)
        rw [Nat.mul_succ]
        omega
      · simp only [sweepSteps, dif_neg h]
        exact (ih A (k + 1) (by omega)).trans (Nat.mul_le_mul_left N (by omega))

theorem stepsMatrix_orthogonal {N : ℕ} (steps : List (Step N)) :
    (stepsMatrix steps).transpose * stepsMatrix steps = 1 := by
  induction steps with
  | nil => simp [stepsMatrix]
  | cons step rest ih =>
      simp only [stepsMatrix, _root_.Matrix.transpose_mul, _root_.Matrix.mul_assoc]
      rw [← _root_.Matrix.mul_assoc (stepsMatrix rest).transpose, ih,
        _root_.Matrix.one_mul]
      exact planeMatrix_orthogonal _ _ step.distinct _

theorem stepsMatrix_det {N : ℕ} (steps : List (Step N)) :
    (stepsMatrix steps).det = 1 := by
  induction steps with
  | nil => simp [stepsMatrix]
  | cons step rest ih =>
      rw [stepsMatrix, _root_.Matrix.det_mul, ih]
      rw [one_mul]
      change (planeMatrix step.first step.second step.angle).det = 1
      exact planeMatrix_det _ _ step.distinct step.angle

noncomputable def decompose {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ) :
    List (Step N) := sweepSteps A 0 M (by omega)

noncomputable def reduced {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ) :
    _root_.Matrix (Fin N) (Fin M) ℝ := sweep A 0 M (by omega)

noncomputable def transform {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ) :
    _root_.Matrix (Fin N) (Fin N) ℝ := stepsMatrix (decompose A)

theorem decompose_action {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ) :
    applySteps (decompose A) A = reduced A := sweepSteps_action A 0 M _

theorem transform_mul {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ) :
    transform A * A = reduced A := by
  rw [← decompose_action, applySteps_eq_matrix_mul]
  rfl

theorem reduced_zero_below {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (row : Fin N) (col : Fin M) (below : col.val < row.val) :
    reduced A row col = 0 := by
  exact sweep_upperPrefix A 0 M (by omega) (by intro col impossible; omega)
    col (by simpa using col.isLt) row below

theorem decompose_length_le {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ) :
    (decompose A).length ≤ N * M := sweepSteps_length_le A 0 M _

theorem transform_orthogonal {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ) :
    (transform A).transpose * transform A = 1 := stepsMatrix_orthogonal _

theorem transform_det {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ) :
    (transform A).det = 1 := stepsMatrix_det _

theorem exact_recovery {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ) :
    (transform A).transpose * reduced A = A := by
  rw [← transform_mul, ← _root_.Matrix.mul_assoc, transform_orthogonal,
    _root_.Matrix.one_mul]

end QuantumBlockEncoding.RectangularGivens
```

## QuantumBlockEncoding/AdjacentGivens.lean, lines 1–442 only

Raw-file SHA256: a43c3b4f543738cb317be01fa664fd466bfa28e21c33d10c7a90e74037a58d9c. This is a bounded excerpt, not a claim that every transitive provider has been expanded.

```lean
import QuantumBlockEncoding.RealAmplitudePreparation
import QuantumBlockEncoding.SelectedRyPlane

/-!
# Exact adjacent-row Givens decomposition of real SO matrices

The ordered plane `(i,j)` uses the standard RY convention. Elimination uses
the negative of the exact signed preparation angle. Zero pivots are assigned
angle zero. The computed bottom-up passes preserve earlier standard-basis
columns, orthogonality, and determinant. The final sign follows from determinant
one, yielding an exact list of `N*(N-1)/2` adjacent rotations for every real SO
matrix, including dimensions zero and one. Relabeling these numerical indices
by Gray code and compiling the resulting qubit edges is a separate interface.
-/

namespace QuantumBlockEncoding.AdjacentGivens

open RealAmplitudePreparation

noncomputable def rotateRows {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (i j : Fin N) (theta : ℝ) : _root_.Matrix (Fin N) (Fin M) ℝ :=
  fun row col =>
    if row = i then Real.cos (theta / 2) * A i col - Real.sin (theta / 2) * A j col
    else if row = j then Real.sin (theta / 2) * A i col + Real.cos (theta / 2) * A j col
    else A row col

noncomputable def planeMatrix {N : ℕ} (i j : Fin N) (theta : ℝ) :
    _root_.Matrix (Fin N) (Fin N) ℝ := rotateRows 1 i j theta

theorem planeMatrix_mul {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (i j : Fin N) (theta : ℝ) : planeMatrix i j theta * A = rotateRows A i j theta := by
  ext row col
  simp only [_root_.Matrix.mul_apply, planeMatrix, rotateRows]
  by_cases hi : row = i
  · subst row
    simp [Finset.sum_sub_distrib, sub_mul, _root_.Matrix.one_apply]
  · by_cases hj : row = j
    · subst row
      simp [hi, Finset.sum_add_distrib, add_mul, _root_.Matrix.one_apply]
    · simp [hi, hj, _root_.Matrix.one_apply]

theorem rotateRows_inverse {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (i j : Fin N) (distinct : i ≠ j) (theta : ℝ) :
    rotateRows (rotateRows A i j theta) i j (-theta) = A := by
  ext row col
  have circle := Real.sin_sq_add_cos_sq (theta / 2)
  by_cases hi : row = i
  · subst row
    simp [rotateRows, distinct.symm, neg_div, Real.cos_neg, Real.sin_neg]
    nlinarith [congrArg (fun x : ℝ => x * A i col) circle]
  · by_cases hj : row = j
    · subst row
      simp [rotateRows, distinct.symm, neg_div, Real.cos_neg, Real.sin_neg]
      nlinarith [congrArg (fun x : ℝ => x * A j col) circle]
    · simp [rotateRows, hi, hj]

theorem planeMatrix_inverse {N : ℕ} (i j : Fin N) (distinct : i ≠ j) (theta : ℝ) :
    planeMatrix i j (-theta) * planeMatrix i j theta = 1 := by
  rw [planeMatrix_mul]
  exact rotateRows_inverse 1 i j distinct theta

theorem planeMatrix_transpose {N : ℕ} (i j : Fin N) (distinct : i ≠ j) (theta : ℝ) :
    (planeMatrix i j theta).transpose = planeMatrix i j (-theta) := by
  ext row col
  by_cases ri : row = i <;> by_cases rj : row = j <;>
    by_cases ci : col = i <;> by_cases cj : col = j <;>
    simp_all [planeMatrix, rotateRows, _root_.Matrix.transpose_apply, _root_.Matrix.one_apply,
      neg_div, Real.cos_neg, Real.sin_neg, eq_comm]

theorem planeMatrix_orthogonal {N : ℕ} (i j : Fin N) (distinct : i ≠ j) (theta : ℝ) :
    (planeMatrix i j theta).transpose * planeMatrix i j theta = 1 := by
  rw [planeMatrix_transpose i j distinct, planeMatrix_inverse i j distinct]

theorem rotateRows_preserves_orthogonal {N : ℕ} (A : _root_.Matrix (Fin N) (Fin N) ℝ)
    (orthogonal : A.transpose * A = 1) (i j : Fin N) (distinct : i ≠ j) (theta : ℝ) :
    (rotateRows A i j theta).transpose * rotateRows A i j theta = 1 := by
  rw [← planeMatrix_mul, _root_.Matrix.transpose_mul]
  calc
    (A.transpose * (planeMatrix i j theta).transpose) * (planeMatrix i j theta * A) =
        A.transpose * ((planeMatrix i j theta).transpose * planeMatrix i j theta) * A := by
      simp only [_root_.Matrix.mul_assoc]
    _ = 1 := by rw [planeMatrix_orthogonal i j distinct, _root_.Matrix.mul_one, orthogonal]

theorem splitAngle_real_firstColumn (x y : ℝ) :
    Real.cos ((splitAngle x y).eval / 2) * pairNorm x y = x ∧
    Real.sin ((splitAngle x y).eval / 2) * pairNorm x y = y := by
  have first := congrArg Complex.re (splitAngle_firstColumn x y 0)
  have second := congrArg Complex.re (splitAngle_firstColumn x y 1)
  rw [standardRyMatrix_eq_realRyPlaneBlock] at first second
  change Complex.re ((Real.cos ((splitAngle x y).eval / 2) : ℂ) *
    (pairNorm x y : ℂ)) = x at first
  change Complex.re ((Real.sin ((splitAngle x y).eval / 2) : ℂ) *
    (pairNorm x y : ℂ)) = y at second
  rw [← Complex.ofReal_mul, Complex.ofReal_re] at first second
  constructor
  · exact first
  · exact second

noncomputable def eliminationAngle (x y : ℝ) : ℝ := -(splitAngle x y).eval

@[simp] theorem eliminationAngle_zero : eliminationAngle 0 0 = 0 := by
  simp [eliminationAngle, splitAngle, pairNorm, ExactAngle.eval]

theorem eliminate_pair (x y : ℝ) :
    Real.cos (eliminationAngle x y / 2) * x -
        Real.sin (eliminationAngle x y / 2) * y = pairNorm x y ∧
    Real.sin (eliminationAngle x y / 2) * x +
        Real.cos (eliminationAngle x y / 2) * y = 0 := by
  obtain ⟨hx, hy⟩ := splitAngle_real_firstColumn x y
  have circle := Real.sin_sq_add_cos_sq ((splitAngle x y).eval / 2)
  simp only [eliminationAngle, neg_div, Real.cos_neg, Real.sin_neg]
  generalize (splitAngle x y).eval / 2 = a at *
  generalize pairNorm x y = r at *
  constructor
  · calc
      _ = (Real.sin a ^ 2 + Real.cos a ^ 2) * r := by rw [← hx, ← hy]; ring
      _ = r := by rw [circle, one_mul]
  · rw [← hx, ← hy]
    ring

theorem pairNorm_eq_zero_iff (x y : ℝ) : pairNorm x y = 0 ↔ x = 0 ∧ y = 0 := by
  constructor
  · intro zero
    have square := pairNorm_sq x y
    rw [zero] at square
    constructor <;> nlinarith [sq_nonneg x, sq_nonneg y]
  · rintro ⟨rfl, rfl⟩
    simp [pairNorm]

theorem pairNorm_pos_of_nonzero (x y : ℝ) (nonzero : x ≠ 0 ∨ y ≠ 0) :
    0 < pairNorm x y := by
  have nonneg := pairNorm_nonneg x y
  have notZero : pairNorm x y ≠ 0 := by
    intro zero
    obtain ⟨hx, hy⟩ := (pairNorm_eq_zero_iff x y).mp zero
    rcases nonzero with hx' | hy'
    · exact hx' hx
    · exact hy' hy
  exact lt_of_le_of_ne nonneg (Ne.symm notZero)

noncomputable def eliminateEntry {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (i j : Fin N) (col : Fin M) : _root_.Matrix (Fin N) (Fin M) ℝ :=
  rotateRows A i j (eliminationAngle (A i col) (A j col))

theorem eliminateEntry_pivot {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (i j : Fin N) (distinct : i ≠ j) (col : Fin M) :
    eliminateEntry A i j col i col = pairNorm (A i col) (A j col) ∧
    eliminateEntry A i j col j col = 0 := by
  simpa [eliminateEntry, rotateRows, distinct.symm] using eliminate_pair (A i col) (A j col)

theorem eliminateEntry_unchanged {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (i j row : Fin N) (col otherCol : Fin M) (hi : row ≠ i) (hj : row ≠ j) :
    eliminateEntry A i j col row otherCol = A row otherCol := by
  simp [eliminateEntry, rotateRows, hi, hj]

theorem eliminateEntry_preserves_zero_column {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (i j : Fin N) (col oldCol : Fin M) (hi : A i oldCol = 0) (hj : A j oldCol = 0)
    (row : Fin N) : eliminateEntry A i j col row oldCol = A row oldCol := by
  by_cases ri : row = i <;> by_cases rj : row = j <;>
    simp_all [eliminateEntry, rotateRows]

theorem eliminateEntry_preserves_orthogonal {N : ℕ} (A : _root_.Matrix (Fin N) (Fin N) ℝ)
    (orthogonal : A.transpose * A = 1) (i j : Fin N) (distinct : i ≠ j) (col : Fin N) :
    (eliminateEntry A i j col).transpose * eliminateEntry A i j col = 1 :=
  rotateRows_preserves_orthogonal A orthogonal i j distinct _

/-- A zero pair produces an actual identity step, without division by zero. -/
theorem eliminateEntry_zero_pair {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (i j : Fin N) (col : Fin M) (firstZero : A i col = 0) (secondZero : A j col = 0) :
    eliminateEntry A i j col = A := by
  ext row otherCol
  by_cases hi : row = i <;> by_cases hj : row = j <;>
    simp_all [eliminateEntry, rotateRows]

/-- An actual adjacent-row rotation, carrying the precise ordered support. -/
structure Step (N : ℕ) where
  first : Fin N
  second : Fin N
  adjacent : first.val + 1 = second.val
  angle : ℝ

theorem Step.distinct {N : ℕ} (step : Step N) : step.first ≠ step.second := by
  intro equal
  have same := congrArg Fin.val equal
  have adjacent := step.adjacent
  omega

noncomputable def Step.matrix {N : ℕ} (step : Step N) :
    _root_.Matrix (Fin N) (Fin N) ℝ := planeMatrix step.first step.second step.angle

/-- Chronological action: the first listed matrix acts first. -/
noncomputable def applySteps {N M : ℕ} : List (Step N) →
    _root_.Matrix (Fin N) (Fin M) ℝ → _root_.Matrix (Fin N) (Fin M) ℝ
  | [], A => A
  | step :: rest, A => applySteps rest (step.matrix * A)

noncomputable def Step.inverse {N : ℕ} (step : Step N) : Step N :=
  { step with angle := -step.angle }

theorem applySteps_append {N M : ℕ} (left right : List (Step N))
    (A : _root_.Matrix (Fin N) (Fin M) ℝ) :
    applySteps (left ++ right) A = applySteps right (applySteps left A) := by
  induction left generalizing A with
  | nil => rfl
  | cons step rest ih => exact ih _

/-- Reversing the chronological list and negating every angle exactly undoes it. -/
theorem applySteps_reverse_inverse {N M : ℕ} (steps : List (Step N))
    (A : _root_.Matrix (Fin N) (Fin M) ℝ) :
    applySteps (steps.reverse.map Step.inverse) (applySteps steps A) = A := by
  induction steps generalizing A with
  | nil => rfl
  | cons step rest ih =>
      simp only [List.reverse_cons, List.map_append, List.map_cons, List.map_nil,
        applySteps_append, applySteps]
      rw [ih]
      change planeMatrix step.first step.second (-step.angle) *
        (planeMatrix step.first step.second step.angle * A) = A
      rw [← _root_.Matrix.mul_assoc, planeMatrix_inverse _ _ step.distinct,
        _root_.Matrix.one_mul]

noncomputable def columnSweep {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (col : Fin M) (lo : ℕ) : (count : ℕ) → lo + count < N →
    _root_.Matrix (Fin N) (Fin M) ℝ
  | 0, _ => A
  | count + 1, bound =>
      columnSweep (eliminateEntry A ⟨lo + count, by omega⟩
        ⟨lo + count + 1, by omega⟩ col) col lo count (by omega)

/-- The list is computed from the changing matrix, not supplied as a certificate. -/
noncomputable def columnSweepSteps {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (col : Fin M) (lo : ℕ) : (count : ℕ) → lo + count < N → List (Step N)
  | 0, _ => []
  | count + 1, bound =>
      let first : Fin N := ⟨lo + count, by omega⟩
      let second : Fin N := ⟨lo + count + 1, by omega⟩
      { first := first, second := second, adjacent := rfl,
        angle := eliminationAngle (A first col) (A second col) } ::
        columnSweepSteps (eliminateEntry A first second col) col lo count (by omega)

theorem columnSweepSteps_length {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (col : Fin M) (lo count : ℕ) (bound : lo + count < N) :
    (columnSweepSteps A col lo count bound).length = count := by
  induction count generalizing A with
  | zero => rfl
  | succ count ih => simp only [columnSweepSteps, List.length_cons, ih]

theorem columnSweepSteps_action {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (col : Fin M) (lo count : ℕ) (bound : lo + count < N) :
    applySteps (columnSweepSteps A col lo count bound) A = columnSweep A col lo count bound := by
  induction count generalizing A with
  | zero => rfl
  | succ count ih =>
      simp only [columnSweepSteps, applySteps, Step.matrix, planeMatrix_mul]
      exact ih _ _

/-- The original matrix is recovered from the computed residual. No identity
or full-decomposition assumption is hidden in this statement. -/
theorem columnSweep_exact_recovery {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (col : Fin M) (lo count : ℕ) (bound : lo + count < N) :
    applySteps ((columnSweepSteps A col lo count bound).reverse.map Step.inverse)
      (columnSweep A col lo count bound) = A := by
  rw [← columnSweepSteps_action, applySteps_reverse_inverse]

theorem columnSweep_outside {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (col : Fin M) (lo count : ℕ) (bound : lo + count < N)
    (row : Fin N) (otherCol : Fin M) (outside : row.val < lo ∨ lo + count < row.val) :
    columnSweep A col lo count bound row otherCol = A row otherCol := by
  induction count generalizing A with
  | zero => rfl
  | succ count ih =>
      rw [columnSweep, ih _ (by omega) (by omega)]
      apply eliminateEntry_unchanged
      · intro equal
        have := congrArg Fin.val equal
        change row.val = lo + count at this
        omega
      · intro equal
        have := congrArg Fin.val equal
        change row.val = lo + count + 1 at this
        omega

theorem columnSweep_zeroed {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (col : Fin M) (lo count : ℕ) (bound : lo + count < N)
    (row : Fin N) (lower : lo < row.val) (upper : row.val ≤ lo + count) :
    columnSweep A col lo count bound row col = 0 := by
  induction count generalizing A with
  | zero => omega
  | succ count ih =>
      rw [columnSweep]
      by_cases inner : row.val ≤ lo + count
      · exact ih _ (by omega) inner
      · rw [columnSweep_outside _ _ _ _ _ _ _ (by omega)]
        have equal : row = (⟨lo + count + 1, by omega⟩ : Fin N) := by
          apply Fin.ext
          change row.val = lo + count + 1
          omega
        rw [equal]
        exact (eliminateEntry_pivot _ _ _ (by
          intro equal
          have := congrArg Fin.val equal
          change lo + count = lo + count + 1 at this
          omega) _).2

theorem columnSweep_preserves_zero_column {N M : ℕ}
    (A : _root_.Matrix (Fin N) (Fin M) ℝ) (col oldCol : Fin M)
    (lo count : ℕ) (bound : lo + count < N)
    (zeros : ∀ row : Fin N, lo ≤ row.val → row.val ≤ lo + count → A row oldCol = 0)
    (row : Fin N) : columnSweep A col lo count bound row oldCol = A row oldCol := by
  induction count generalizing A with
  | zero => rfl
  | succ count ih =>
      let first : Fin N := ⟨lo + count, by omega⟩
      let second : Fin N := ⟨lo + count + 1, by omega⟩
      have unchanged (r : Fin N) : eliminateEntry A first second col r oldCol = A r oldCol :=
        eliminateEntry_preserves_zero_column A first second col oldCol
          (zeros first (by dsimp [first]; omega) (by dsimp [first]; omega))
          (zeros second (by dsimp [second]; omega) (by dsimp [second]; omega)) r
      change columnSweep (eliminateEntry A first second col) col lo count _ row oldCol = _
      rw [ih _ (by omega) (by
        intro r lower upper
        rw [unchanged]
        exact zeros r lower (by omega)), unchanged]

theorem columnSweep_preserves_orthogonal {N : ℕ}
    (A : _root_.Matrix (Fin N) (Fin N) ℝ) (orthogonal : A.transpose * A = 1)
    (col : Fin N) (lo count : ℕ) (bound : lo + count < N) :
    (columnSweep A col lo count bound).transpose * columnSweep A col lo count bound = 1 := by
  induction count generalizing A with
  | zero => exact orthogonal
  | succ count ih =>
      rw [columnSweep]
      apply ih
      exact eliminateEntry_preserves_orthogonal A orthogonal _ _ (by
        intro equal
        have := congrArg Fin.val equal
        change lo + count = lo + count + 1 at this
        omega) col


theorem det_two_row_mix {N : ℕ} (A : _root_.Matrix (Fin N) (Fin N) ℝ)
    (i j : Fin N) (distinct : i ≠ j) (a b c d : ℝ) :
    (((A.updateRow i (a • A i + b • A j)).updateRow j (c • A i + d • A j))).det =
      (a * d - b * c) * A.det := by
  have sameI : ((A.updateRow j (A i)).updateRow i (A i)).det = 0 := by
    apply _root_.Matrix.det_zero_of_row_eq distinct
    simp [distinct.symm]
  have sameJ : ((A.updateRow j (A j)).updateRow i (A j)).det = 0 := by
    apply _root_.Matrix.det_zero_of_row_eq distinct
    simp [distinct.symm]
  have original : (A.updateRow j (A j)).updateRow i (A i) = A := by simp
  have swapEq : (A.updateRow j (A i)).updateRow i (A j) =
      A.submatrix (Equiv.swap i j) id := by
    ext row col
    by_cases hi : row = i <;> by_cases hj : row = j <;>
      simp_all [_root_.Matrix.updateRow_apply, _root_.Matrix.submatrix_apply,
        Equiv.swap_apply_def]
  have swapDet : ((A.updateRow j (A i)).updateRow i (A j)).det = -A.det := by
    rw [swapEq, _root_.Matrix.det_permute, Equiv.Perm.sign_swap distinct]
    simp
  simp only [_root_.Matrix.det_updateRow_add, _root_.Matrix.det_updateRow_smul]
  rw [_root_.Matrix.updateRow_comm A distinct, _root_.Matrix.updateRow_comm A distinct]
  simp only [_root_.Matrix.det_updateRow_add, _root_.Matrix.det_updateRow_smul,
    sameI, sameJ, original, swapDet]
  ring

theorem rotateRows_det {N : ℕ} (A : _root_.Matrix (Fin N) (Fin N) ℝ)
    (i j : Fin N) (distinct : i ≠ j) (theta : ℝ) :
    (rotateRows A i j theta).det = A.det := by
  have eqRows : rotateRows A i j theta =
      (A.updateRow i (Real.cos (theta / 2) • A i + (-Real.sin (theta / 2)) • A j)).updateRow j
        (Real.sin (theta / 2) • A i + Real.cos (theta / 2) • A j) := by
    ext row col
    by_cases hi : row = i <;> by_cases hj : row = j <;>
      simp_all [rotateRows, _root_.Matrix.updateRow_apply, sub_eq_add_neg]
  rw [eqRows, det_two_row_mix A i j distinct]
  have circle := Real.sin_sq_add_cos_sq (theta / 2)
  nlinarith [congrArg (fun t : ℝ => t * A.det) circle]


theorem planeMatrix_det {N : ℕ} (i j : Fin N) (distinct : i ≠ j) (theta : ℝ) :
    (planeMatrix i j theta).det = 1 := by
  rw [planeMatrix, rotateRows_det _ i j distinct, _root_.Matrix.det_one]

theorem columnSweep_preserves_det {N : ℕ}
    (A : _root_.Matrix (Fin N) (Fin N) ℝ) (col : Fin N)
    (lo count : ℕ) (bound : lo + count < N) :
    (columnSweep A col lo count bound).det = A.det := by
  induction count generalizing A with
  | zero => rfl
  | succ count ih =>
      rw [columnSweep, ih]
      apply rotateRows_det
      intro equal
      have := congrArg Fin.val equal
      change lo + count = lo + count + 1 at this
      omega


def PrefixIdentity {N : ℕ} (A : _root_.Matrix (Fin N) (Fin N) ℝ) (k : ℕ) : Prop :=
  ∀ col : Fin N, col.val < k → ∀ row : Fin N, A row col = if row = col then 1 else 0

theorem orthogonal_zero_of_fixed_column {N : ℕ} (A : _root_.Matrix (Fin N) (Fin N) ℝ)
    (orthogonal : A.transpose * A = 1) (old col : Fin N) (distinct : old ≠ col)
    (fixed : ∀ row : Fin N, A row old = if row = old then 1 else 0) : A old col = 0 := by
  have entry := congrFun (congrFun orthogonal old) col
  simpa [_root_.Matrix.mul_apply, _root_.Matrix.transpose_apply,
    fixed, _root_.Matrix.one_apply, distinct] using entry

theorem columnSweep_prefix {N : ℕ} (A : _root_.Matrix (Fin N) (Fin N) ℝ)
    (col : Fin N) (count : ℕ) (bound : col.val + count < N)
    (fixedPrefix : PrefixIdentity A col.val) : PrefixIdentity (columnSweep A col col.val count bound) col.val := by
  intro old oldLt row
  rw [columnSweep_preserves_zero_column]
  · exact fixedPrefix old oldLt row
  · intro r lower upper
    rw [fixedPrefix old oldLt r, if_neg]
    intro equal
    have same := congrArg Fin.val equal
    omega

theorem columnSweep_pivot_nonneg {N M : ℕ} (A : _root_.Matrix (Fin N) (Fin M) ℝ)
    (col : Fin M) (lo count : ℕ) (bound : lo + count < N) (positive : 0 < count) :
    0 ≤ columnSweep A col lo count bound ⟨lo, by omega⟩ col := by
  induction count generalizing A with
  | zero => omega
  | succ count ih =>
      rw [columnSweep]
      by_cases zero : count = 0
      · subst count
        rw [columnSweep]
        simp only [Nat.add_zero] at *
        rw [(eliminateEntry_pivot A ⟨lo, by omega⟩ ⟨lo + 1, by omega⟩ (by
          intro equal
          have same := congrArg Fin.val equal
          change lo = lo + 1 at same
          omega) _).1]
        exact RealAmplitudePreparation.pairNorm_nonneg _ _
      · exact ih _ (by omega) (by omega)

theorem orthogonal_supported_column_sq {N : ℕ} (A : _root_.Matrix (Fin N) (Fin N) ℝ)
    (orthogonal : A.transpose * A = 1) (col : Fin N)
```

## QuantumBlockEncoding/PrimitiveCircuit.lean, lines 1–210 only

Raw-file SHA256: d5019ef58ce1ce65664d2a40979cdd652ca691c94743532c59dfe18cf2036d4c. This is a bounded excerpt, not a claim that every transitive provider has been expanded.

```lean
import QuantumBlockEncoding.Resources
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Inverse
import Mathlib.Data.Rat.Defs
import Mathlib.Data.Real.Basic
import Mathlib.Data.Finset.Lattice.Fold

/-!
# Typed exact primitive circuits

This is the proof-bearing circuit language.  Unlike the older presentation
`Gate`, rotation angles are typed expressions with exact real semantics.
Only the frozen Robin T3 basis `{X, RY, RZ, CX}` is admitted.
-/

namespace QuantumBlockEncoding

inductive ExactAngle where
  | rational (value : Rat)
  | piRational (value : Rat)
  | twiceArccosRational (value : Rat)
      (bounded : |(value : Real)| ≤ 1)
  | twiceArccosSqrtRational (value : Rat)
      (bounded : 0 ≤ (value : Real) ∧ (value : Real) ≤ 1)
  /-- An exact real angle in the mathematical circuit. This constructor does
  not promise a computable decimal export; exporters must supply and audit
  their own numerical evaluation of the defining real expression. -/
  | real (value : Real)
  | add (left right : ExactAngle)
  | neg (value : ExactAngle)
  | scale (factor : Rat) (value : ExactAngle)

private def exactAngleRepr : ExactAngle → Nat → Std.Format
  | .rational value, p => reprPrec value p
  | .piRational value, p => "pi * " ++ reprPrec value p
  | .twiceArccosRational value _, p => "2 * arccos " ++ reprPrec value p
  | .twiceArccosSqrtRational value _, p => "2 * arccos sqrt " ++ reprPrec value p
  | .real _, _ => "<exact real angle; numerical export required>"
  | .add left right, p => "(" ++ exactAngleRepr left p ++ " + " ++ exactAngleRepr right p ++ ")"
  | .neg value, p => "-(" ++ exactAngleRepr value p ++ ")"
  | .scale factor value, p => reprPrec factor p ++ " * (" ++ exactAngleRepr value p ++ ")"

instance : Repr ExactAngle := ⟨exactAngleRepr⟩

namespace ExactAngle

noncomputable def eval : ExactAngle → Real
  | .rational value => (value : Real)
  | .piRational value => Real.pi * (value : Real)
  | .twiceArccosRational value _ => 2 * Real.arccos (value : Real)
  | .twiceArccosSqrtRational value _ =>
      2 * Real.arccos (Real.sqrt (value : Real))
  | .real value => value
  | .add left right => left.eval + right.eval
  | .neg value => -value.eval
  | .scale factor value => (factor : Real) * value.eval

@[simp] theorem eval_add (left right : ExactAngle) :
    (add left right).eval = left.eval + right.eval := rfl

@[simp] theorem eval_neg (value : ExactAngle) :
    (neg value).eval = -value.eval := rfl

@[simp] theorem eval_scale (factor : Rat) (value : ExactAngle) :
    (scale factor value).eval = (factor : Real) * value.eval := rfl

def sub (left right : ExactAngle) : ExactAngle :=
  add left (neg right)

def halfAdd (left right : ExactAngle) : ExactAngle :=
  scale (1 / 2) (add left right)

def halfSub (left right : ExactAngle) : ExactAngle :=
  scale (1 / 2) (sub left right)

@[simp] theorem eval_sub (left right : ExactAngle) :
    (sub left right).eval = left.eval - right.eval := by
  simp [sub, sub_eq_add_neg]

@[simp] theorem eval_half_add (left right : ExactAngle) :
    (halfAdd left right).eval = (left.eval + right.eval) / 2 := by
  simp only [halfAdd, eval_scale, eval_add]
  have halfCast : (((1 / 2 : Rat) : Real)) = (1 : Real) / 2 := by norm_num
  rw [halfCast]
  ring

@[simp] theorem eval_half_sub (left right : ExactAngle) :
    (halfSub left right).eval = (left.eval - right.eval) / 2 := by
  simp only [halfSub, eval_scale, eval_sub]
  have halfCast : (((1 / 2 : Rat) : Real)) = (1 : Real) / 2 := by norm_num
  rw [halfCast]
  ring

end ExactAngle

inductive PrimitiveGate (qubits : Nat) where
  | x (target : Fin qubits)
  | ry (target : Fin qubits) (angle : ExactAngle)
  | rz (target : Fin qubits) (angle : ExactAngle)
  | cx (control target : Fin qubits) (distinct : control ≠ target)

abbrev PrimitiveCircuit (qubits : Nat) := List (PrimitiveGate qubits)

/-- A primitive circuit together with an exact global phase. -/
structure PrimitiveProgram (qubits : Nat) where
  circuit : PrimitiveCircuit qubits
  globalPhase : ExactAngle

namespace PrimitiveGate

def dagger {qubits : Nat} : PrimitiveGate qubits → PrimitiveGate qubits
  | .x target => .x target
  | .ry target angle => .ry target (.neg angle)
  | .rz target angle => .rz target (.neg angle)
  | .cx control target distinct => .cx control target distinct

def touched {qubits : Nat} : PrimitiveGate qubits → Finset (Fin qubits)
  | .x target | .ry target _ | .rz target _ => {target}
  | .cx control target _ => {control, target}

def oneQubitCount {qubits : Nat} : PrimitiveGate qubits → Nat
  | .x _ | .ry _ _ | .rz _ _ => 1
  | .cx _ _ _ => 0

def twoQubitCount {qubits : Nat} : PrimitiveGate qubits → Nat
  | .cx _ _ _ => 1
  | _ => 0

end PrimitiveGate

namespace PrimitiveCircuit

def gateCount {qubits : Nat} (circuit : PrimitiveCircuit qubits) : Nat :=
  circuit.length

def oneQubitCount {qubits : Nat} (circuit : PrimitiveCircuit qubits) : Nat :=
  circuit.foldl (fun total gate => total + gate.oneQubitCount) 0

def twoQubitCount {qubits : Nat} (circuit : PrimitiveCircuit qubits) : Nat :=
  circuit.foldl (fun total gate => total + gate.twoQubitCount) 0

def ryCount {qubits : Nat} (circuit : PrimitiveCircuit qubits) : Nat :=
  circuit.countP fun gate => match gate with
    | .ry _ _ => true
    | _ => false

def cxCount {qubits : Nat} (circuit : PrimitiveCircuit qubits) : Nat :=
  circuit.countP fun gate => match gate with
    | .cx _ _ _ => true
    | _ => false

@[simp] theorem ryCount_append {qubits : Nat}
    (left right : PrimitiveCircuit qubits) :
    (left ++ right).ryCount = left.ryCount + right.ryCount := by
  simp [ryCount]

@[simp] theorem cxCount_append {qubits : Nat}
    (left right : PrimitiveCircuit qubits) :
    (left ++ right).cxCount = left.cxCount + right.cxCount := by
  simp [cxCount]

@[simp] theorem ryCount_singleton_ry {qubits : Nat}
    (target : Fin qubits) (angle : ExactAngle) :
    ryCount ([PrimitiveGate.ry target angle] : PrimitiveCircuit qubits) = 1 := by
  rfl

@[simp] theorem ryCount_singleton_cx {qubits : Nat}
    (control target : Fin qubits) (distinct : control ≠ target) :
    ryCount ([PrimitiveGate.cx control target distinct] : PrimitiveCircuit qubits) = 0 := by
  rfl

@[simp] theorem cxCount_singleton_ry {qubits : Nat}
    (target : Fin qubits) (angle : ExactAngle) :
    cxCount ([PrimitiveGate.ry target angle] : PrimitiveCircuit qubits) = 0 := by
  rfl

@[simp] theorem cxCount_singleton_cx {qubits : Nat}
    (control target : Fin qubits) (distinct : control ≠ target) :
    cxCount ([PrimitiveGate.cx control target distinct] : PrimitiveCircuit qubits) = 1 := by
  rfl

def nextWireDepth {qubits : Nat} (depth : Fin qubits → Nat)
    (gate : PrimitiveGate qubits) : Fin qubits → Nat :=
  let layer := gate.touched.sup depth
  fun wire => if wire ∈ gate.touched then layer + 1 else depth wire

def wireDepths {qubits : Nat} (circuit : PrimitiveCircuit qubits) :
    Fin qubits → Nat :=
  circuit.foldl nextWireDepth (fun _ => 0)

def depth {qubits : Nat} (circuit : PrimitiveCircuit qubits) : Nat :=
  Finset.univ.sup circuit.wireDepths

def resource {qubits : Nat} (circuit : PrimitiveCircuit qubits) : Resource :=
  Resource.ofCountsWithDepth circuit.oneQubitCount circuit.twoQubitCount
    0 0 circuit.depth

@[simp] theorem gateCount_eq_length {qubits : Nat}
    (circuit : PrimitiveCircuit qubits) :
    circuit.gateCount = circuit.length := rfl

@[simp] theorem resource_oracleCalls_eq_zero {qubits : Nat}
    (circuit : PrimitiveCircuit qubits) :
    circuit.resource.oracleCalls = 0 := rfl

end PrimitiveCircuit

namespace PrimitiveProgram

def identity (qubits : Nat) : PrimitiveProgram qubits where
  circuit := []
```

## QuantumBlockEncoding/SequentialBondPreparation.lean, lines 1–130 only

Raw-file SHA256: ad4542b108d44f196f2a02f78e59b58f43d45b1e890709cf4c22e1222805d5c5. This is a bounded excerpt, not a claim that every transitive provider has been expanded.

```lean
import QuantumBlockEncoding.RealAmplitudePreparation

/-!
# Sequential finite-bond state action

A stage acts on a fresh zero bit and a finite, padded bond register. Previously
emitted bits are passive. The new bit is appended at the highest wire, so the
emission order is wire 0, wire 1, and so on. Matrix rows are output indices.

This module proves the finite-sum bridge from such local matrix actions to
tensor-core contraction, including exact terminal-bond cleanup. It does not
construct Hermite cores, their orthogonalization, or a primitive compiler.
The local clean-column equality required by `run_eq_transfer` remains a
separate obligation for each concrete small-isometry circuit.

`run` is recursive matrix action with fresh-zero wires. A separate wire-placement
bridge is needed to identify it with one flattened `PrimitiveCircuit (n + q)`;
no synthesis algorithm, preprocessing complexity, or gate-count claim is made here.
-/

namespace QuantumBlockEncoding.SequentialBondPreparation

open scoped Kronecker
open RealAmplitudePreparation

variable {B : Type*} [Fintype B] [DecidableEq B]

/-- A core emits one bit and changes the bond. -/
abbrev Core (B : Type*) := _root_.Matrix (Fin 2 × B) B ℂ

/-- The square, full local matrix; its nonzero-bit input columns are not
specified by a tensor core and must be supplied by an actual completion. -/
abbrev Stage (B : Type*) := _root_.Matrix (Fin 2 × B) (Fin 2 × B) ℂ

/-- State amplitudes after exactly `n` output bits have been emitted. -/
abbrev BondState (n : Nat) (B : Type*) := PrimitiveBasis n × B → ℂ

/-- Add the next output bit in zero, without changing any existing amplitude. -/
def freshZero {n : Nat} (v : BondState n B) :
    PrimitiveBasis n × (Fin 2 × B) → ℂ :=
  fun x => if x.2.1 = 0 then v (x.1, x.2.2) else 0

/-- Local stage tensored with the identity on all already emitted bits. -/
noncomputable def liftStage (n : Nat) (U : Stage B) :
    _root_.Matrix (PrimitiveBasis n × (Fin 2 × B))
      (PrimitiveBasis n × (Fin 2 × B)) ℂ :=
  (1 : _root_.Matrix (PrimitiveBasis n) (PrimitiveBasis n) ℂ) ⊗ₖ U

omit [Fintype B] [DecidableEq B] in
@[simp] theorem liftStage_apply (n : Nat) (U : Stage B)
    (r c : PrimitiveBasis n × (Fin 2 × B)) :
    liftStage n U r c = if r.1 = c.1 then U r.2 c.2 else 0 := by
  simp [liftStage, _root_.Matrix.one_apply, ite_mul]

/-- A genuine matrix-vector action followed only by a basis regrouping. -/
noncomputable def step {n : Nat} (U : Stage B) (v : BondState n B) :
    BondState (n + 1) B := fun x =>
  ((liftStage n U).mulVec (freshZero v))
    (Fin.init x.1, (x.1 (Fin.last n), x.2))

omit [DecidableEq B] in
/-- Only the clean-input columns of a local stage affect an emitted state.
The sum over passive prefixes and fresh-bit inputs collapses exactly. -/
theorem step_apply {n : Nat} (U : Stage B) (v : BondState n B)
    (x : PrimitiveBasis (n + 1)) (b : B) :
    step U v (x, b) =
      ∑ a, U (x (Fin.last n), b) (0, a) * v (Fin.init x, a) := by
  simp [step, _root_.Matrix.mulVec, dotProduct, Fintype.sum_prod_type, freshZero]

/-- Unitarity of the full local completion gives unitarity after adding
arbitrarily many passive emitted wires. -/
theorem liftStage_unitary (n : Nat) (U : Stage B)
    (hU : U ∈ _root_.Matrix.unitaryGroup (Fin 2 × B) ℂ) :
    liftStage n U ∈
      _root_.Matrix.unitaryGroup (PrimitiveBasis n × (Fin 2 × B)) ℂ := by
  apply _root_.Matrix.kronecker_mem_unitary
  · exact (_root_.Matrix.unitaryGroup (PrimitiveBasis n) ℂ).one_mem
  · exact hU

/-- Fixing an emitted bit leaves a bond-to-bond transfer matrix. -/
def coreSlice (K : Core B) (bit : Fin 2) : _root_.Matrix B B ℂ :=
  fun b a => K (bit, b) a

/-- Chronological tensor contraction. The last emitted core multiplies on
the left, in the same convention as `evalPrimitiveCircuit`. -/
noncomputable def transfer (K : Nat → Core B) :
    (n : Nat) → PrimitiveBasis n → _root_.Matrix B B ℂ
  | 0, _ => 1
  | n + 1, x => coreSlice (K n) (x (Fin.last n)) * transfer K n (Fin.init x)

/-- Explicit initial boundary, followed by sequential matrix actions.
At stage zero there are no output bits and the bond amplitude is `boundary`. -/
noncomputable def run (U : Nat → Stage B) (boundary : B → ℂ) :
    (n : Nat) → BondState n B
  | 0 => fun x => boundary x.2
  | n + 1 => step (U n) (run U boundary n)

/-- Local clean-column equalities suffice to identify the complete state
with the tensor contraction at every length; no global state action is assumed. -/
theorem run_eq_transfer (U : Nat → Stage B) (K : Nat → Core B)
    (cleanColumns : ∀ t bit b a, U t (bit, b) (0, a) = K t (bit, b) a)
    (boundary : B → ℂ) (n : Nat) (x : PrimitiveBasis n) (b : B) :
    run U boundary n (x, b) = (transfer K n x).mulVec boundary b := by
  induction n generalizing b with
  | zero => simp [run, transfer]
  | succ n ih =>
    rw [run, step_apply]
    simp_rw [cleanColumns, ih]
    rw [transfer, ← _root_.Matrix.mulVec_mulVec]
    rfl

/-- Initial computational-basis boundary for the bond. -/
def basisBoundary (initial : B) : B → ℂ := fun b => if b = initial then 1 else 0

/-- Starting from a basis boundary extracts the corresponding transfer column. -/
theorem run_basisBoundary (U : Nat → Stage B) (K : Nat → Core B)
    (cleanColumns : ∀ t bit b a, U t (bit, b) (0, a) = K t (bit, b) a)
    (initial : B) (n : Nat) (x : PrimitiveBasis n) (b : B) :
    run U (basisBoundary initial) n (x, b) = transfer K n x b initial := by
  rw [run_eq_transfer U K cleanColumns]
  simp [basisBoundary, _root_.Matrix.mulVec, dotProduct]

/-- If every core is zero outside the next active bond set, its contracted
state has that support. This allows ranks to shrink inside a fixed register. -/
theorem transfer_boundary_supported (K : Nat → Core B)
    (active : Nat → B → Prop) (boundary : B → ℂ)
    (initialSupport : ∀ b, ¬ active 0 b → boundary b = 0)
    (coreSupport : ∀ t bit b a, ¬ active (t + 1) b → K t (bit, b) a = 0)
    (n : Nat) (x : PrimitiveBasis n) (b : B) (inactive : ¬ active n b) :
    (transfer K n x).mulVec boundary b = 0 := by
```

## QuantumBlockEncoding/SequentialBondPreparation.lean, lines 241–270 only

Raw-file SHA256: ad4542b108d44f196f2a02f78e59b58f43d45b1e890709cf4c22e1222805d5c5. This is a bounded excerpt, not a claim that every transitive provider has been expanded.

```lean
    (fun p a ha => run_supported U K active boundary initialSupport coreSupport
      cleanColumns n p a ha) lastColumns]
  simp_rw [run_eq_transfer_of_supported U K active boundary initialSupport
    coreSupport cleanColumns]

/-- The local primitive circuit uses the low `q` wires for the bond and its
highest wire for the fresh emitted bit. This equivalence makes that order explicit. -/
def localBasisEquiv (q : Nat) : PrimitiveBasis (q + 1) ≃ Fin 2 × PrimitiveBasis q :=
  (lastBasisEquiv q).trans (Equiv.prodComm _ _)

/-- Exact local stage supplied by a primitive circuit, not an opaque oracle. -/
noncomputable def circuitStage {q : Nat} (c : PrimitiveCircuit (q + 1)) :
    Stage (PrimitiveBasis q) :=
  _root_.Matrix.reindexAlgEquiv ℂ ℂ (localBasisEquiv q) (evalPrimitiveCircuit c)

@[simp] theorem circuitStage_apply {q : Nat} (c : PrimitiveCircuit (q + 1))
    (bit bit' : Fin 2) (b a : PrimitiveBasis q) :
    circuitStage c (bit, b) (bit', a) =
      evalPrimitiveCircuit c (Fin.snoc b bit) (Fin.snoc a bit') := by
  rfl

/-- Primitive stages have checked full unitarity, independently of whether
their active columns implement the intended tensor cores. -/
theorem circuitStage_unitary {q : Nat} (c : PrimitiveCircuit (q + 1)) :
    circuitStage c ∈ _root_.Matrix.unitaryGroup (Fin 2 × PrimitiveBasis q) ℂ :=
  Robin.ComplexLCU.reindex_unitary _ _ (evalPrimitiveCircuit_unitary c)

/-- Direct instantiation with primitive-circuit stages. The sole compiler
alignment premise is stated on active clean-input columns, in actual
`evalPrimitiveCircuit` semantics. This does not synthesize these circuits or
```

## .lake/packages/mathlib/Mathlib/Analysis/InnerProductSpace/PiL2.lean, lines 1016–1075 only

Raw-file SHA256: 065b56124e50d1370b95c2436f2107be006d5bc82cd237d14b97bb1a7adcc1bf. This is a bounded excerpt, not a claim that every transitive provider has been expanded.

```lean
    (hV : OrthogonalFamily 𝕜 (fun i => A i) fun i => (A i).subtypeₗᵢ) [DecidableEq ι]
    (hV_sum : DirectSum.IsInternal fun i => A i) {α : ι → Type*} [∀ i, Fintype (α i)]
    (v_family : ∀ i, OrthonormalBasis (α i) 𝕜 (A i)) : OrthonormalBasis (Σ i, α i) 𝕜 E :=
  (hV_sum.collectedBasis fun i => (v_family i).toBasis).toOrthonormalBasis <| by
    simpa using
      hV.orthonormal_sigma_orthonormal (show ∀ i, Orthonormal 𝕜 (v_family i).toBasis by simp)

theorem DirectSum.IsInternal.collectedOrthonormalBasis_mem [DecidableEq ι]
    (h : DirectSum.IsInternal A) {α : ι → Type*} [∀ i, Fintype (α i)]
    (hV : OrthogonalFamily 𝕜 (fun i => A i) fun i => (A i).subtypeₗᵢ)
    (v : ∀ i, OrthonormalBasis (α i) 𝕜 (A i)) (a : Σ i, α i) :
    h.collectedOrthonormalBasis hV v a ∈ A a.1 := by
  simp [DirectSum.IsInternal.collectedOrthonormalBasis]

variable [FiniteDimensional 𝕜 E]

/-- In a finite-dimensional `InnerProductSpace`, any orthonormal subset can be extended to an
orthonormal basis. -/
theorem Orthonormal.exists_orthonormalBasis_extension (hv : Orthonormal 𝕜 ((↑) : v → E)) :
    ∃ (u : Finset E) (b : OrthonormalBasis u 𝕜 E), v ⊆ u ∧ ⇑b = ((↑) : u → E) := by
  obtain ⟨u₀, hu₀s, hu₀, hu₀_max⟩ := exists_maximal_orthonormal hv
  rw [maximal_orthonormal_iff_orthogonalComplement_eq_bot hu₀] at hu₀_max
  have hu₀_finite : u₀.Finite := hu₀.linearIndependent.setFinite
  let u : Finset E := hu₀_finite.toFinset
  let fu : ↥u ≃ ↥u₀ := hu₀_finite.subtypeEquivToFinset.symm
  have hu : Orthonormal 𝕜 ((↑) : u → E) := by simpa using! hu₀.comp _ fu.injective
  refine ⟨u, OrthonormalBasis.mkOfOrthogonalEqBot hu ?_, ?_, ?_⟩
  · simpa [u] using! hu₀_max
  · simpa [u] using! hu₀s
  · simp

theorem Orthonormal.exists_orthonormalBasis_extension_of_card_eq {ι : Type*} [Fintype ι]
    (card_ι : finrank 𝕜 E = Fintype.card ι) {v : ι → E} {s : Set ι}
    (hv : Orthonormal 𝕜 (s.domRestrict v)) :
    ∃ b : OrthonormalBasis ι 𝕜 E, ∀ i ∈ s, b i = v i := by
  have hsv : Injective (s.domRestrict v) := hv.linearIndependent.injective
  have hX : Orthonormal 𝕜 ((↑) : Set.range (s.domRestrict v) → E) := by
    rwa [orthonormal_subtype_range hsv]
  obtain ⟨Y, b₀, hX, hb₀⟩ := hX.exists_orthonormalBasis_extension
  have hιY : Fintype.card ι = Y.card := by
    refine card_ι.symm.trans ?_
    exact Module.finrank_eq_card_finset_basis b₀.toBasis
  have hvsY : s.MapsTo v Y := (s.mapsTo_image v).mono_right (by rwa [← range_domRestrict])
  have hsv' : Set.InjOn v s := by
    rw [Set.injOn_iff_injective]
    exact hsv
  obtain ⟨g, hg⟩ := hvsY.exists_equiv_extend_of_card_eq hιY hsv'
  use b₀.reindex g.symm
  intro i hi
  simp [hb₀, hg i hi]

variable (𝕜 E)

/-- A finite-dimensional inner product space admits an orthonormal basis. -/
theorem _root_.exists_orthonormalBasis :
    ∃ (w : Finset E) (b : OrthonormalBasis w 𝕜 E), ⇑b = ((↑) : w → E) :=
  let ⟨w, hw, _, hw''⟩ := (orthonormal_empty 𝕜 E).exists_orthonormalBasis_extension
  ⟨w, hw, hw''⟩

/-- A finite-dimensional `InnerProductSpace` has an orthonormal basis. -/
```


