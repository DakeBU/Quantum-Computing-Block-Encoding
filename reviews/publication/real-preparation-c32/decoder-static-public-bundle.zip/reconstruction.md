# Independent formal-only whole-module reconstruction

This is a static mathematical decoding of the supplied Lean source, not a natural-source comparison, kernel acceptance, migration success, publication approval, or new scientific result. All theorem statements below mean “the supplied source states and gives this proof,” not “this run elaborated this type.” The exact source-level interfaces and proof bodies are preserved in `inventory.json`, and the complete supplied packet is preserved byte-for-byte as `formal-context.md`. This decoder did not receive the natural source or the author's classifications.

## Scope and ambient mathematics

The whole targets are `QuantumBlockEncoding/RealAmplitudePreparation.lean`, `QuantumBlockEncoding/RealIsometryCompletion.lean`, and `QuantumBlockEncoding/ConstructiveIsometryLocal.lean`. They contain respectively 45, 7, and 5 source declarations: 57 total, of which 53 are public and 4 private; 13 definitions and 44 theorems. These counts were re-extracted from the complete target sources rather than assumed from the assignment. Generated equation lemmas, elaborator-generated instances, private kernel names, auto-implicit elaborated binders, and proof-term declarations were not extracted.

No target has a section variable, locally declared notation, local instance, or bundled target structure hiding additional premises. The ambient `open` commands affect name resolution and notation, not theorem hypotheses. The first namespace opens `Robin.ComplexLCU` and scoped `Kronecker`; the second opens scoped `BigOperators` and `InnerProductSpace`; the third opens `TensorTrainCanonical`, `TensorTrainSchedule`, `TensorTrainLocalCompiler`, and `ConstructiveIsometryCompletion`. Standard finite sums, real/complex fields, decidable finite equality, and matrix operations are supplied by imports. These are source-level observations, not an elaborated-instance report.

Write B_n = (Fin n → Fin 2). A named bit string b has flat index L_n(b) = sum over i<n of 2^i b(i); `gridSize n` is literally 2^n. Wire 0 is least significant. `Fin.init` removes the highest wire and `Fin.snoc b v` appends its bit. Matrices have output rows and input columns. Circuit lists are chronological: E([])=I, E(g::c)=E(c)E(g), and E(c++d)=E(d)E(c).

The imported gate carrier is the literal inductive language X, RY, RZ, CX. Targets and controls are `Fin n`; CX stores a proof control ≠ target. `ExactAngle.real` admits an arbitrary real number, with no numerical evaluator certificate. Angle evaluation also includes rational, pi-rational, restricted arccos constructors, sums, negation and rational scaling. RY(theta) is [[cos(theta/2), -sin(theta/2)], [sin(theta/2), cos(theta/2)]], complex-embedded. X flips the selected bit; CX flips its target exactly when the control bit is 1. RZ is diagonal with exp(-i theta/2), exp(+i theta/2). RZ and X are handled by the general lifting lemmas, but the defined preparation construction only emits RY/CX.

The target formulas assert literal matrix/vector equality. There is no quotient by global phase and no label-dependent phase freedom. Real signed entries are embedded in C without discarding their signs. No density matrices, Born samples, approximate norms, postselection or success-probability predicates occur in the target interfaces.

## Seven semantic slots

| Slot | RealAmplitudePreparation | RealIsometryCompletion | ConstructiveIsometryLocal |
| --- | --- | --- | --- |
| Target and normalization | First zero-input column is f/sqrt(sum f²), under the explicit theorem hypotheses. Squared-sum normalization is independently stated. | Prescribe all r orthonormal real columns V at labels e(a); complete the rest. No normalized state table is supplied. | Real SO local matrix agreeing exactly with the occupied padded tensor-core columns. Right-canonical rows produce column isometry. |
| Scalars/dimensions/order | n qubits, B_n or flat Fin(2^n), real input table, complex denotation; low wires preserved in embeddings, highest appended wire is split last. | Arbitrary natural N,r, real Fin N by Fin r matrix; arbitrary injection e, not necessarily prefix. | q low bond wires plus one highest emitted wire; B=2^q, physical dimension 2B, active rank ≤B. Coordinates are bond index + B*bit. |
| Oracle/access/control | Arbitrary classical mathematical table f. No coherent f-query or unit-cost table evaluation premise. Multiplexor controls are low wire bits. | No oracle, coherent parameter register, controlled completion, or circuit implementation in target statements. | A concrete chain C and stage number t are classical parameters; no superposition-over-C/t interface. |
| Ancilla/workspace | n-wire circuit on all-zero input; no extra ancilla or garbage registers. Earlier prepared bits remain controls while highest bit is updated. | Unused columns are linear-algebra degrees of freedom, not extra physical ancillas. | Fresh highest input bit is 0; active old bond inputs only. All output bond labels are covered by the equality, including zero outside next rank. Bit-1 input columns and inactive bit-0 input columns are free completion sectors. No global terminal cleanup theorem is in the targets. |
| Phase | Exact normalized real vector, including sign where stated; no “up to phase” conclusion. n=0 nonnegative restriction matters. | Prescribed columns exactly unchanged; orientation correction flips only an unused column. Nonunique completion, no canonical unitary modulo phase claim. | Exact complex cast of real entries equals paddedAt. No per-column or global phase looseness. SO orientation is exact determinant +1. |
| Error/success | Ideal exact arithmetic, no epsilon. Positive mass required for vector formula, but circuit/unitarity and counts are total even for zero f. | Exact isometry and determinant equations; no approximation, confidence or postselection. | Exact active-column equality at t<n; no success probability or error budget. |
| Resources | Exact RY=2^n-1, CX=2(2^n-1-n), natural subtraction; zero encoded oracle calls. No finite-bit, runtime, depth bound, connectivity, synthesis or readout theorem. | Classical existence only. No operation count or emitted circuit. | Named exact-real matrix producer, no target circuit or cost theorem. Imported existential local compiler has a separate bound but is not the defined completeStage circuit. |

## Complete declaration-by-declaration decoding

Each item states all mathematical inputs beyond ambient field/matrix infrastructure, describes the conclusion or defined object, and reconstructs its proof mechanism. Pure type/dimension/index data are distinguished from logical premises in the binder audit below. Short names resolve in their target namespace. Numbers are inventory order, not claims of proof-DAG ancestry.

### RealAmplitudePreparation

<a id="realamplitudepreparation-1"></a>
1. `lastBasisEquiv` (line 20, definition). For every natural n, split b∈B_(n+1) into (init b,b(n)). Its inverse is snoc. This is a literal explicit finite equivalence formed from snocEquiv and swapping product factors; no chosen basis or default branch.

<a id="realamplitudepreparation-2"></a>
2. `lastBasisEquiv_apply` (23). For n and b∈B_(n+1), the forward map has exactly the pair just stated. Definitional equality; no premise.

<a id="realamplitudepreparation-3"></a>
3. `lastBasisEquiv_symm_apply` (26). For n,b∈B_n,v∈Fin 2, inverse(b,v)=snoc b v. Definitional equality; no premise.

<a id="realamplitudepreparation-4"></a>
4. `basis_eq_iff` (29). For a,b∈B_(n+1), a=b iff init a=init b and their last bits agree. Apply injectivity of the explicit equivalence and equality of ordered pairs.

<a id="realamplitudepreparation-5"></a>
5. `liftLastMatrix` (35, noncomputable definition). For any complex B_n square matrix M, adjoin an untouched highest bit: under the explicit splitting equivalence the new matrix is M tensor I_2. “Noncomputable” here does not select an existential unitary; the matrix-entry function is a fixed expression.

<a id="realamplitudepreparation-6"></a>
6. `liftLastMatrix_apply` (41). For M,a,b, the lifted entry is M(init a,init b) if their highest bits agree, zero otherwise. Expand tensor identity and reindexing.

<a id="realamplitudepreparation-7"></a>
7. `liftLastMatrix_one` (50). For n, lifting identity gives identity. The explicit reindex/tensor expression preserves identity.

<a id="realamplitudepreparation-8"></a>
8. `liftLastMatrix_mul` (54). For arbitrary M,N, lift(MN)=lift(M)lift(N). Tensor products multiply componentwise and the basis reindexing is an algebra equivalence. This applies to all matrices, not just circuit/unitary matrices.

<a id="realamplitudepreparation-9"></a>
9. `liftGate` (60, definition). Embed each n-wire primitive instruction into n+1 wires using castSucc on every named wire. Angles are unchanged. For CX, injectivity of castSucc transports the distinctness proof. It neither renumbers the original wire values nor acts on the newly highest wire.

<a id="realamplitudepreparation-10"></a>
10. `split_castSucc_eq` (66, private). For low target t∈Fin n and a,b∈B_(n+1), equality of all n+1-wire non-target bits iff equality of all old-register non-target bits and equality of highest bits. Prove both directions coordinatewise, splitting a wire into last/castSucc cases. This is a private register-context lemma, not a new gate assumption.

<a id="realamplitudepreparation-11"></a>
11. `lift_oneQubit` (87). For low t and arbitrary 2×2 complex M, lifting M directly onto t.castSucc equals lifting the old n-wire lifted M through liftLastMatrix. Compare entries with the preceding context equivalence and split equality cases. No unitary premise needed.

<a id="realamplitudepreparation-12"></a>
12. `xBasis_lift` (97, private). For t,b, restricting the result of flipping low wire t.castSucc to old wires equals flipping t in init b. Coordinatewise Function.update arithmetic.

<a id="realamplitudepreparation-13"></a>
13. `cxBasis_lift` (102, private). For c,t∈Fin n and b, old-wire restriction commutes with the basis controlled-flip action. It has no explicit c≠t premise: this helper concerns the total basis function, not the involutive CX gate certification. Case split on control bit then use the preceding flip lemma.

<a id="realamplitudepreparation-14"></a>
14. `eval_liftGate` (108). For arbitrary typed gate g, E(liftGate g)=liftLastMatrix(E(g)). RY/RZ use one-qubit embedding; X/CX use permutation entries, the private restriction identities, highest-bit invariance, and whole-basis equality decomposition. CX distinctness is already a field of g.

<a id="realamplitudepreparation-15"></a>
15. `eval_liftCircuit` (135). For arbitrary circuit c, E(map liftGate c)=liftLastMatrix(E(c)). Induct over the chronological list; use gate equality, multiplicativity and identity lifting.

<a id="realamplitudepreparation-16"></a>
16. `pairNorm` (143, noncomputable definition). For arbitrary real a,b, rho(a,b)=sqrt(a²+b²), the nonnegative Euclidean mass root. Literal formula on all R², no invalid locus.

<a id="realamplitudepreparation-17"></a>
17. `pairNorm_nonneg` (145). For all real a,b, rho≥0 by the real square-root convention.

<a id="realamplitudepreparation-18"></a>
18. `pairNorm_sq` (147). rho²=a²+b² for all a,b. The argument is nonnegative since both squares are.

<a id="realamplitudepreparation-19"></a>
19. `splitAngle` (152, noncomputable definition). For all real a,b, return rational angle 0 if rho=0. Otherwise return the exact real angle 2*alpha, where alpha=-arccos(a/rho) if b<0, and alpha=arccos(a/rho) otherwise. This is a selected signed angle representative, not a uniqueness claim or phase quotient. The rho=0 branch is mathematically specified: both amplitudes are zero. It is not a normalized zero-state fallback. At a<0,b=0 the positive arccos branch gives a full physical RY angle 2pi, so the negative first amplitude is retained exactly.

<a id="realamplitudepreparation-20"></a>
20. `splitAngle_firstColumn` (157). For all real a,b and v∈Fin 2, RY(splitAngle.eval)[v,0]*rho equals a if v=0 and b otherwise, complex-embedded. For rho=0 both a,b vanish. For rho>0, prove -1≤a/rho≤1, cos(arccos(a/rho))*rho=a, and the nonnegative sine product has square b². The sign test b<0 selects ±|b|=b. This gives exact signed two-entry recovery without dividing the theorem conclusion by zero.

<a id="realamplitudepreparation-21"></a>
21. `marginal` (208, noncomputable definition). For real f on B_(n+1), m(b)=rho(f(snoc b 0),f(snoc b 1)). This is a table of low-bit marginal norms, not a marginal amplitude sum or probability.

<a id="realamplitudepreparation-22"></a>
22. `marginal_nonneg` (211). For all f and b∈B_n, m(b)≥0 by rho nonnegativity. The input f itself need not be nonnegative for this lemma.

<a id="realamplitudepreparation-23"></a>
23. `normSq` (215, noncomputable definition). For any real f on B_n, S(f)=sum_b f(b)². This is the actual full table mass, not an arbitrary normalization proposition.

<a id="realamplitudepreparation-24"></a>
24. `normSq_nonneg` (217). S(f)≥0 for every f because it is a finite sum of squares.

<a id="realamplitudepreparation-25"></a>
25. `normSq_marginal` (220). For every f on B_(n+1), S(marginal f)=S(f). Expand rho² and reindex the sum by snoc equivalence; sum the two highest-bit cases.

<a id="realamplitudepreparation-26"></a>
26. `prepareCircuit` (228, noncomputable recursive definition). At n=0 output []; at n+1 first recursively prepare marginal f on low wires (mapping liftGate), then append the n-control RY multiplexor targeting wire n. Its angle at low string b is splitAngle(f(b,0),f(b,1)). The recursion is literally on register size. It returns a total mathematical gate list even for zero/signed f, but a total circuit definition is not a preparation theorem for every such f.

<a id="realamplitudepreparation-27"></a>
27. `prepareCircuit_unitary` (235). For every n and arbitrary real f, its denotation is unitary. This reuses imported universal primitive-circuit unitarity; it does not assume f normalized or nonzero.

<a id="realamplitudepreparation-28"></a>
28. `last_context_eq` (240, private). For a,b∈B_(n+1), equality outside last wire iff init a=init b. Coordinatewise finite-last/castSucc split. This supplies the controlled block index calculation.

<a id="realamplitudepreparation-29"></a>
29. `controlledLast_apply` (256). For arbitrary low-bit angle table and output/input a,b, the highest-wire controlled RY block is zero unless init a=init b; otherwise it is RY(angle(init a))[a(n),b(n)]. Expand the imported block-diagonal semantics and the last-context lemma.

<a id="realamplitudepreparation-30"></a>
30. `controlledLast_mul_lift` (265). For angle table, arbitrary low-register M and output a, the zero-input column of controlledLast*lift(M) is RY(angle(init a))[a(n),0] times M[init a,0^n]. Expand matrix multiplication, reindex intermediate states as (low,high), collapse the equality deltas. No presumed state preparation is an input.

<a id="realamplitudepreparation-31"></a>
31. `prepareCircuit_firstColumn` (279). Inputs n,f, nonneg: forall b f(b)≥0, positive: S(f)>0, and b∈B_n. Conclusion E(prepareCircuit n f)[b,0^n]=(f(b)/sqrt(S(f)):C). Induct on n. At n=0 there is one basis string; positivity and nonnegativity make its sole amplitude positive, so the normalized value is +1 and [] suffices. At n+1, use the imported exact multiplexor denotation, lifted circuit denotation, previous matrix-product lemma, induction on the automatically nonnegative marginal, mass preservation, and splitAngle pair recovery. The universal source statement retains nonneg even though the successor-step proof does not use nonneg of f; this decoder does not silently replace it by a stronger signed-table theorem. In particular f=-1 on B_0 gives normalized value -1 while [] has entry +1, so n=0 requires a sign restriction for this literal construction. That observation is elementary mathematical reasoning, not a native counterexample run.

<a id="realamplitudepreparation-32"></a>
32. `normalized_sum_sq` (315). Inputs n,f and S(f)>0 only; then sum_b(f(b)/sqrt(S(f)))²=1. Rewrite square of a quotient, factor the common denominator, use sqrt(S)²=S and S≠0. No pointwise nonnegative premise. This normalization theorem applies to signed tables without certifying their circuit column.

<a id="realamplitudepreparation-33"></a>
33. `normSq_pos_of_positive` (323). Inputs n,f with forall b f(b)>0; then S(f)>0. Each square is positive and B_n is nonempty, including n=0. It is sufficient, not a statement that pointwise strict positivity is necessary for nonzero mass.

<a id="realamplitudepreparation-34"></a>
34. `liftCircuit_ryCount` (329). For any c, map liftGate preserves the number of RY constructors. Induct on the list and case split on the four gate constructors.

<a id="realamplitudepreparation-35"></a>
35. `liftCircuit_cxCount` (336). The analogous identity for CX count, same proof mechanism. Counts do not depend on distinctness-proof terms or angle values.

<a id="realamplitudepreparation-36"></a>
36. `prepareCircuit_ryCount` (344). For every n,f, exact RY count=2^n-1. Recurrence R(0)=0, R(n+1)=R(n)+2^n from the reference n-control compiler, plus preserved lifted count. Natural arithmetic gives the formula. Counts include zero/identity-angle gates; no simplification removes them.

<a id="realamplitudepreparation-37"></a>
37. `prepareCircuit_cxCount` (355). For every n,f, exact CX count=2*(2^n-1-n), with truncated Nat subtraction. Recurrence C(0)=0, C(n+1)=C(n)+2*(2^n-1). Use n<2^n to justify the natural-subtraction arithmetic. This is the recursive reference multiplexor, not a Gray-code-optimized count or finite-bit rotation synthesis count.

<a id="realamplitudepreparation-38"></a>
38. `prepareCircuit_oracleCalls` (365). For all n,f, circuit.resource.oracleCalls=0. This follows from the primitive resource definition setting the field to 0 for every primitive list. It does not prove computing f, angles or their numerical representation is free.

<a id="realamplitudepreparation-39"></a>
39. `primitiveBasisLE_zero` (369). For every n, L_n(0^n)=zeroBasisIndex n, whose value is 0. Induct using the little-endian recursion b0+2*L(tail).

<a id="realamplitudepreparation-40"></a>
40. `primitiveBasisLE_zero_symm` (380). Inverse L_n of flat zero is the all-zero string. Apply injectivity to the preceding equality.

<a id="realamplitudepreparation-41"></a>
41. `prepareMatrixLE` (386, noncomputable definition). For f:Fin(2^n)→R, pull f back along L_n, prepare the named-wire circuit, then transport the entire circuit matrix along L_n. Both input/output basis axes are reindexed. There is no new circuit or reversal of wire order.

<a id="realamplitudepreparation-42"></a>
42. `prepareMatrixLE_unitary` (391). For every n and arbitrary flat f, the reindexed matrix is unitary. Apply reindex preservation to prepareCircuit_unitary; no positivity assumption.

<a id="realamplitudepreparation-43"></a>
43. `normSq_reindex` (395). For every n,flat f, S(f∘L_n)=sum_j f(j)². A finite equivalence preserves the full sum.

<a id="realamplitudepreparation-44"></a>
44. `prepareMatrixLE_firstColumn` (399). Inputs n,flat f, forall j f(j)>0, and j. Its zero flat input column equals f(j)/sqrt(sum_i f(i)²), complex-embedded. Strict positivity supplies nonneg and positive mass for the named-basis theorem; zero inverse and mass reindexing identify the formula. The wrapper's actual premise is stronger than positive total mass plus nonneg; no weakening is made here.

<a id="realamplitudepreparation-45"></a>
45. `normalized_sum_sq_LE` (410). Inputs n,flat f and forall j f(j)>0. The normalized flat squared sum is 1. It applies normalized_sum_sq to the pulled-back table, derives positive mass, and reindexes. Again the wrapper states strict positivity although the lower theorem needs only positive mass.

### RealIsometryCompletion

<a id="realisometrycompletion-1"></a>
1. `exists_orthogonal_completion` (20). Inputs naturals N,r, V:R^(N×r), injection e:Fin r↪Fin N, hV:V^T V=I_r. There exists real U:N×N with U^T U=I_N and all U(i,e(a))=V(i,a). Convert V's columns into EuclideanSpace vectors, read hV entrywise as their orthonormality, index them at range(e), and extend this orthonormal indexed family to an orthonormal basis of R^N using the Mathlib extension theorem. The returned matrix has these basis vectors as columns. The proof-local auxiliary f(j) is a prescribed vector on range(e) and 0 outside; only its restriction is passed to extension. Those outside zeros do not constrain U. No full-rank, r<N, or prefix-placement assumption. The injection gives r≤N by finite cardinality, rather than a separate binder. Zero dimensions and empty r are allowed. This is classical existence, not a deterministic matrix definition.

<a id="realisometrycompletion-2"></a>
2. `signFlip` (65, definition). For j∈Fin N, diagonal D with D(j,j)=-1 and every other diagonal +1. Literal formula; j's type requires N>0 without a separate proposition. It is a column sign-flip when multiplied on the right.

<a id="realisometrycompletion-3"></a>
3. `signFlip_orthogonal` (68). D^T D=I. Multiply diagonals; each entry squares to 1. No other hypothesis.

<a id="realisometrycompletion-4"></a>
4. `signFlip_det` (77). det D=-1. The diagonal product has exactly one -1 factor, others +1. The index j ensures nonempty N.

<a id="realisometrycompletion-5"></a>
5. `mul_signFlip_preserves` (80). Inputs arbitrary U, j,i,a∈Fin N and a≠j. Then (UD_j)(i,a)=U(i,a). It is right multiplication by a diagonal with +1 at a. No unitary or determinant premise.

<a id="realisometrycompletion-6"></a>
6. `exists_specialOrthogonal_completion_of_unused` (86). Inputs V,e,hV as above, unused∈Fin N, and forall a e(a)≠unused. There exists U with U^TU=I, det U=1, and prescribed columns exactly V. Obtain an orthogonal completion. Its determinant d satisfies d²=1 by taking determinants; over R, d=±1. If d=1 keep it; if d=-1 right-multiply the unused-column signFlip. Orthogonality persists, determinant changes to +1, all prescribed columns stay fixed. There is no determinant-sign assumption on V, and no change to any active relative phase. The result is nonunique.

<a id="realisometrycompletion-7"></a>
7. `exists_specialOrthogonal_completion` (110). Inputs r<N, V,e,hV. Same SO conclusion. The strict inequality implies e cannot be surjective by finite cardinality, hence an unused label exists, supplying the previous theorem. The strict inequality is a sufficient spare-column condition: it is not removed when r=N. With full prescribed square matrix det=-1 no exact SO completion can exist; determinant +1 is necessary there. This elementary boundary is inferred from the displayed equations, not a run-time test.

### ConstructiveIsometryLocal

<a id="constructiveisometrylocal-1"></a>
1. `coordinates` (15, definition). For natural q, map B_(q+1) to Fin(2*2^q) by localIndex q then finProdFinEquiv. localIndex(snoc b bit)=(bit,L_q(b)); finProdFinEquiv(x,y) has value y+2^q*x. Thus coordinates(snoc b bit).val=L_q(b).val+2^q*bit.val. Explicit finite equivalence; no Fintype-chosen enumeration. This is compatible with low bond/high emitted bit placement, not an arbitrary renaming of active columns.

<a id="constructiveisometrylocal-2"></a>
2. `localCompletion` (18, noncomputable definition). Inputs q,r, hr:r≤2^q, and real V:B_(q+1)×Fin r. It calls completeNamed using coordinates q and activePositions hr; r<2*2^q follows from hr and positivity of 2^q. activePositions(a)=localIndex^-1(0,castLE hr a), equivalently snoc(L_q^-1(a),0). This names a specific exact-real matrix even for nonisometric V. No hV is stored as an input to the definition. Agreement with V is conditional on isometry in its specification. It does not choose a completion from exists_SO_named.

<a id="constructiveisometrylocal-3"></a>
3. `localCompletion_spec` (26). Inputs q,r,hr,V and hV:V^TV=I_r. The defined localCompletion is orthogonal, has det +1, and agrees with V in every row at activePositions(a). Invoke completeNamed_spec with the same explicit coordinates and injection. Full output rows are covered; other input columns are unconstrained by the column-equality conjunct but are fixed by the producer definition. This is a real matrix theorem, not an emitted primitive circuit theorem.

<a id="constructiveisometrylocal-4"></a>
4. `completeStage` (34, noncomputable definition). Inputs naturals n,l,r,q, a dependent real tensor chain C:Chain n l r, bound hB:maxBond C≤2^q, and t∈N. Define localCompletion at active rank rankAt C t with real activeColumns C t hB. The bound hr is derived from rankAt_le_maxBond and hB, not independently assumed. The definition is total at all t and all C meeting hB; it does not assert active-column isometry outside valid canonical stages.

<a id="constructiveisometrylocal-5"></a>
5. `completeStage_spec` (39). Inputs C, hC:RightCanonical C, hB, t, ht:t<n. Conclusion: completeStage^T completeStage=I, determinant +1, and for all bit∈Fin 2, b,a∈B_q with L_q(a).val<rankAt C t,

   `(completeStage C hB t (snoc b bit) (snoc a 0) : C)`

   equals `paddedAt C t (bit,L_q(b)) (L_q(a))`.

   First derive activeColumns isometry from recursive RightCanonical and valid t; apply localCompletion_spec. Package L_q(a) into Fin(rankAt C t), prove the active-position label is exactly snoc a 0, substitute the fixed-column formula, and use paddedAt_real to identify the complex cast of its real part with the original padded amplitude. The output b is arbitrary, so inactive output labels are also covered and are zero by padded-core support. No premise of desired full-state action or existing local completion matrix is present. No whole chain state, terminal rank=1, boundary normalization, primitive compileSO application, global wire placement, gate count or arithmetic runtime is concluded by this target theorem.

## Recursive binder audit: formal roles, not source author labels

Source-blindness prevents deciding SOURCE, source-wide STANDING, human-approved RULED or source-relative EXCESS. Every source-relative classification therefore remains UNDETERMINED; this is not a zero-EXCESS verdict. The following independent formal-role classification recursively expands all target logical bundles. Proof ingredients produced inside proofs are not counted as public premises. `inventory.json` preserves the exact syntactic statements including implicit braces.

Pure type/index data: n,N,r,q,l and chain lengths; arbitrary matrices M,N,U,V; angle tables; real amplitudes; circuit/gate inputs; rows, columns, wire labels and stage indices. Their carriers supply finite bounds. e:Fin r↪Fin N contains the logical condition injective(e), so it is not merely an arbitrary function; `Equiv` includes inverse identities. CX inputs contain control≠target. These are constrained mathematical data, not source-fidelity classifications. Standard Fintype/DecidableEq for finite named bases are ambient infrastructure; no theorem contains a project-defined arbitrary semantic Prop flag as normalization/unitarity.

| Target logical input / location | Recursive meaning | Formal role |
| --- | --- | --- |
| RAP firstColumn `nonneg` | forall b∈B_n, 0≤f(b) | Pointwise domain/sign restriction; needed uniformly at zero width. |
| RAP firstColumn / normalized_sum_sq `positive` | 0<sum_b f(b)² | Nonzero-mass restriction; rules out the zero normalized vector. |
| RAP normSq_pos_of_positive, LE wrappers `positive` | forall j,0<f(j) | Strict pointwise restriction; supplies sign and positive mass. |
| RIC `e` | forall a,b, e(a)=e(b) implies a=b | Distinct physical column placement constraint. |
| RIC `hV` | forall a,c, sum_i V(i,a)V(i,c)=if a=c then 1 else 0 | Input column-isometry promise, not the desired output matrix action. |
| RIC `ha` | a≠j | Exclusion of the flipped column, support-preservation condition. |
| RIC `hu` | forall a,e(a)≠unused | Known unused column promise. |
| RIC `hr` | r<N | Spare dimension promise, sufficient to derive unused label. |
| CIL `hr` | r≤2^q | Active-rank register-fit promise in definition/spec. |
| CIL `hV` | sum over every named physical row V(row,a)V(row,c)=delta(a,c) | Real input occupied-column isometry. |
| CIL `hB` | maxBond C≤2^q | All chain bonds including both boundaries fit fixed register. |
| CIL `hC` | RightCanonical(nil)=True; RightCanonical(cons A C')=(A A^T=I) and RightCanonical(C') | Per-core orthonormal real rows, recursively for the whole chain. Expanded A-row identity: sum_(bit,b) A(a,bit,b)A(c,bit,b)=delta(a,c). It is not a supplied full-run state equality. |
| CIL `ht` | t<n | Stage-validity promise. |
| CIL conclusion implication antecedent | L_q(a).val<rankAt C t | Restricts the input column where equality is asserted. This is a conclusion-domain condition, not a global theorem hypothesis about all inputs. |

All remaining target theorems have no independent logical premises beyond their typed/constrained data. In particular, unitarity of prepared circuits, scalar norm identities, lifted gate/circuit semantics and exact gate counts are conclusions without positivity assumptions. The four private lemmas add no hidden semantic premise. Type bounds in Fin, equality comparison, castSucc distinctness and finite-sum instances are retained rather than silently flattened away.

The recursive chain carrier is important: Core(l,r)=Matrix(Fin l)(Fin 2×Fin r) R; Chain.nil r has length 0 and matching initial/terminal dimension r; cons A C' has head Core(l,m), tail Chain n m r and length n+1. rankAt(nil r,t)=r, rankAt(cons A C',0)=l, rankAt(cons A C',t+1)=rankAt(C',t). maxBond(nil r)=r and maxBond(cons A C')=max(l,maxBond C'). The right boundary need not be 1. No normalization of a global tensor-train state follows from the target binders alone without selecting and normalizing an initial boundary.

paddedAt(nil,t)=0 and paddedAt(cons A C',0)=paddedCore A, with tail recursion for t+1. paddedCore A((bit,b),a) is A(a,(bit,b)) cast to C only if a<l and b<r; otherwise zero. Hence activeColumns is exactly the real part of these actual padded entries, not a surrogate matrix with a claimed isometry flag. At t≥n, rankAt stays at terminal rank but paddedAt=0; hC plus hB alone would not generally make those zero active columns orthonormal. This explains why ht is a real boundary, not decorative bookkeeping.

## Definition and representative audit

All 13 target definitions are literal source expressions or recursive producers: RAP lastBasisEquiv, liftLastMatrix, liftGate, pairNorm, splitAngle, marginal, normSq, prepareCircuit, prepareMatrixLE; RIC signFlip; CIL coordinates, localCompletion, completeStage. No target defines a uniquely characterized object by Classical.choose. No target constructs a quotient. This classification is an independent reading of bodies, not an author-supplied label.

splitAngle selects a representative of a planar angle for exact signed amplitude action; uniqueness is neither asserted nor needed. Its zero-pair branch is justified by rho²=a²+b². prepareCircuit 0 ignores f by definition; its theorem explicitly imposes the sign/mass domain required by this behavior. The zero table has a defined unitary and gate counts but no normalized first-column claim. localCompletion/completeStage produce a selected completion, not a mathematically unique completion; their columns are only specified under the appropriate isometry/canonical hypotheses.

Recursively expanding the imported constructive route gives: prefixCompletion(V)=transform(V)^T where transform is the product of explicitly generated adjacent row rotations of RectangularGivens. Each elimination angle is negative splitAngle.eval of the changing pair. Zero pairs give an identity rotation. Sweeps go bottom-up within each column and left-to-right over rectangular columns; no existential matrix witness is supplied. For r<N, every prescribed column reaches its positive unit coordinate pivot. Recovery then supplies the first r columns of transform^T. extendPrefix constructs a permutation by greedy swaps so the first r numerical labels land at e(a). unusedPosition carries original coordinate r to an unused physical column. permuteColumns U p uses p^-1 on input columns. orientColumns tests finite permutation parity; if odd, it multiplies by signFlip on that unused column. complete = placeColumns(prefixCompletion V). completeNamed transports both matrix axes with the supplied explicit coordinates. This route shares signFlip lemmas with the existential completion module, but its producer does not call exists_orthogonal_completion, exists_specialOrthogonal_completion or exists_SO_named. The existing TensorTrainLocalCompiler imported module contains existential circuit theorems, but CIL only calls its coordinates, activeColumns, activePositions, reality and isometry interfaces.

The proof-local f=0 outside range(e) in the existential theorem is a bounded scaffolding definition whose outside values are never required as columns of the returned basis. It is not an off-domain definition of the requested completion. Mathlib's orthonormal-basis extension supplies a noncanonical existence witness; no uniqueness or efficient extraction is advertised. The complete source proof bodies remain available in the formal packet.

## Static mathematical mechanism graph and reference boundary

This is a mathematical reconstruction from formal source. It is neither a natural Source Proof Graph nor an elaborated Lean proof DAG. The following AND dependencies describe the visible proof mechanism; textual references are evidence of source use only.

RAP: explicit basis split + tensor identity -> matrix lifting; gate-by-gate coordinate compatibility + chronological list multiplication -> circuit lifting. Signed pair recovery + marginal mass preservation + exact multiplexor block semantics + induction on register width -> normalized first column under its sign/mass premises. The norm-only theorem uses finite real algebra independently of the circuit. Compiler RY/CX recurrences + lift-count preservation -> exact exponential reference counts. Explicit little-endian equivalence + zero-label identity -> flat-basis transport of unitarity, first column and normalization.

RIC: V^T V=I + injective prescribed positions + finite-dimensional orthonormal basis extension -> O(N) completion. O(N) determinant ±1 + known spare column + signFlip -> SO(N) completion. r<N + injection -> existence of spare column. These tails must stay combined; “a spare column alone gives a completion” is not a valid edge.

CIL: recursively canonical chain + valid stage + register capacity -> actual real activeColumns isometry. Isometry + explicit coordinate equivalence + active-position injection + strict spare dimension (derived from half-dimension bound) + deterministic rectangular completion -> literal local SO matrix matching occupied clean-input columns. Reality of paddedAt + physical-coordinate identity -> exact complex-valued stage-column equation. This is a local linear-algebra node, not a primitive compileSO or flattened global preparation node.

Imported UniformlyControlledRy has a complete explicit multiplexor proof in the packet. With k controls it emits 2^k RY and 2(2^k-1) CX. The control tuple need not itself be injective in the imported signature, only distinct from target; the RAP instantiation uses castSucc and is injective. Recursive angle half-add/half-sub and X RY(theta) X=RY(-theta) implement each fixed control block. This is exact on every basis context, not just a distribution check.

Imported schedule/global mathematics is separate: transfer/run use fresh-zero matrix action; terminal rank 1 gives exact bond-zero cleanup when the local column interface is supplied, and canonicalization is an existence route using ThinLQ. The targets do not invoke run_padded/run_terminal_clean, do not select normalized boundary u, and do not assemble one PrimitiveCircuit(n+q). The imported existential compiler's 6*(2^q)^3 gate bound does not by itself assign a circuit or a cost to completeStage. Likewise a bound on a rotation-list length is not an exact-real arithmetic evaluation or finite-bit preprocessing theorem.

## Typed residuals and unperformed checks

- `SOURCE_COMPARISON_UNAVAILABLE`: natural-source agreement, necessity of source hypotheses, source coverage, source topology and source-relative EXCESS cannot be decided by this decoder. No source-agreement approval is emitted.
- `KERNEL_NOT_RUN`: this packet binds source-level signatures/proofs only. No elaboration, #print, #print axioms, generated constants, code-generation axiom extraction, target Lean compilation, migration test, lake build, Tests, site gate or current-commit CI was run or inspected. Native invocations in this run: 0.
- `IMPORT_CLOSURE_UNEXPANDED`: bounded and unexpanded provider regions are itemized in `dependency-scope.md`. No complete import closure, proof-term reachability, minimal imports or axiom-clean certificate is claimed.
- `SIGNED_DOMAIN_FRONTIER`: splitAngle is signed for all pairs, but the universal prepareCircuit_firstColumn source statement is nonnegative; the flat wrapper is strictly positive. A broader signed nonzero-width theorem may be derivable from the proof, but was not substituted, proved in Lean, or recorded as an existing root.
- `LOCAL_GLOBAL_BOUNDARY`: CIL is a deterministic local matrix completion. Global wire placement, preparation of an initial boundary, normalized global target, terminal cleanup, primitive circuit synthesis and resource composition require their own interfaces. Imported downstream-adjacent theorems do not alter this target conclusion.
- `EXACT_REAL_NOT_FINITE_BIT`: arbitrary real tables, sqrt, sign tests, arccos, real arithmetic, and matrix products have no stored-input lookup/runtime/precision cost contract here. Zero encoded oracle calls does not certify efficient classical data access.
- `NONUNIQUE_COMPLETION`: orthogonal/SO extension and completion free columns are not unique, even though the constructive route picks one deterministic formula relative to fixed coordinates. No basis-independent canonicality or coherent-control stability across varying inputs is proved by these targets.

No mathematical route was retired as REFUTED or SOURCE_INVALID. The limitations above are evidence-layer boundaries, not environment failures or conjectured theorem falsity. Static source scans found no sorry, admit, axiom, unsafe or native_decide token in the three target files; this is not proof-term axiom cleanliness. The included PrimitiveBasisLE provider does contain source uses of native_decide at fixed widths, which were read but not executed, and no generated axiom names were guessed.

## Handoff

Objective/frontier: independent whole-module formal-only decoding of three bound targets. Mathematical delta: 57 source roots accounted for, including private machinery, literal definitions, recursive contracts and exact-real/local-vs-global boundaries. Effect: a comparison-ready decoder packet, not increased certified proof frontier. Named evidence: `formal-context.md`, `inventory.json`, `context-binding.json`, this reconstruction, dependency scope, run identity, and content seal. Changed files: independent scratch only. Failure class: NONE for static decoding; execution acceptance intentionally not attempted. Salvage: entire static analysis retained; no production code changed. Process-memory IDs consulted: none under held-out restriction. Direction fingerprint: fresh57whole-module formal-only semantics and exact-real/local-vs-global boundary. Expected information gain: expose source-statement strength, occupied-column semantics, deterministic-vs-existential distinction and resource omissions independently of author interpretation. Parallel admission: assigned decoder uncertainty; no decoder subagents. Common-blind-spot review: not performed here. Default verified route/comparator: not selected. Purification/Exposition Seal: not granted. Recommended next stage: distinct source reviewer compares these bound source statements and reconstruction with independently pinned natural material, then authorized execution owners handle kernel/migration checks. This decoder freezes and stops until parent authorization for a new stage.
