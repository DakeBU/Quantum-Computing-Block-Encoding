# Read scope and dependency boundaries

All paths in this document are logical repository or packet paths. “Full” means complete source text was supplied and read, not that its transitive imports or elaborated dependencies were extracted. File SHA256 in the input packet binds the complete original file even when only an excerpt was supplied; it does not mean the missing text was read.

## Initial input packet coverage

The packet `formal-context.md` was read sequentially to EOF: lines 1–450, 451–970, 971–1670, 1671–2420, 2421–3220, 3221–4020, and 4021–EOF. No author-directory material other than this one initial file was opened. Complete target modules and toolchain/manifest content appear in the packet before providers.

| Packet provider | Read extent | Direct imports and unresolved scope |
| --- | --- | --- |
| ConstructiveIsometryCompletion | Full | AdjacentGivens only bounded below; RealIsometryCompletion target full; RectangularGivens full. |
| TensorTrainLocalCompiler | Full | TensorTrainSchedule full; RealIsometryCompletion full; GrayGivensCompiler not opened. Its existence statements were read, but their full synthesis proof inputs were not expanded. |
| TensorTrainSchedule | Full | TensorTrainCanonical full. |
| TensorTrainCanonical | Full | ThinLQ not opened; SequentialBondPreparation bounded below. ThinLQ existence is not used as a new target premise or a new decoder-accepted algorithm. |
| UniformlyControlledRy | Full | PrimitiveSemantics full. |
| PrimitiveBasisLE | Full | PrimitiveSemantics full. Includes fixed-width native_decide source, not executed by decoder. |
| PrimitiveSemantics | Full | PrimitiveCircuit bounded; Robin.Hadamard8Verified initially unexpanded and later only first 45 lines inspected; Mathlib.Tactic not expanded. |
| StatePreparation | Full | BlockEncoding initially unexpanded, later only first 45 lines inspected. Target RAP only needs zeroBasisIndex from this interface; arbitrary Prop certificate bundles here are not inputs to its first-column theorem. |
| RectangularGivens | Full | AdjacentGivens bounded. |
| AdjacentGivens | Lines 1–442 only | RealAmplitudePreparation full target; SelectedRyPlane not opened. The excerpt ends at the start of orthogonal_supported_column_sq; no later full-SO elimination tail was inspected. Required rectangular providers such as columnSweep_pivot_nonneg, planeMatrix_det and row-rotation equations occur in the excerpt. |
| PrimitiveCircuit | Lines 1–210 only | Resources later read full; Mathlib.Analysis.SpecialFunctions.Trigonometric.Inverse, Data.Rat.Defs, Data.Real.Basic, Data.Finset.Lattice.Fold not opened. Excerpt ends in PrimitiveProgram.identity, not complete PrimitiveProgram APIs. Target-used circuit resource and count definitions are within the excerpt. |
| SequentialBondPreparation | Lines 1–130 and 241–270 only | RealAmplitudePreparation full. First excerpt cuts at transfer_boundary_supported proof start; second begins with a tail of an earlier proof and cuts in a later comment. The intervening 131–240 and all lines beyond 270 remain unexpanded. The fresh-zero/step/run/localBasisEquiv formulas used for interpretation are visible. |
| Mathlib Analysis/InnerProductSpace/PiL2 | Lines 1016–1075 only | Full ambient namespace/typeclass context and transitive imports remain unexpanded. The named orthonormal-basis-extension theorem and proof were read in this range; no claim of full Mathlib proof closure. |

The RealIsometryCompletion direct import Mathlib.LinearAlgebra.Matrix.Determinant.Basic was not opened. Its determinant identities are explicit formal library interfaces named in the source, not newly verified facts in this run. Arbitrary imported theorem instances, simplification lemmas, tactics and upstream libraries remain outside the expanded closure unless explicitly listed above or below.

## Necessary supplemental definition reads

These were source reads to resolve exact carrier, phase, resource and finite-coordinate semantics, not access to a natural lesson or external article. Their exact text is preserved in `supplemental-formal-context.md` and byte/line/hash bindings in `supplemental-bindings.json`.

| File | Exact read extent | Reason / remaining boundary |
| --- | --- | --- |
| QuantumBlockEncoding/Resources.lean | Full | Defines Resource fields, gates and ofCountsWithDepth, confirming zero encoded oracle calls do not account for angle evaluation. Imports Core, only initial segment read below. Other resource formulas are unused context, not credited as target claims. |
| QuantumBlockEncoding/Core.lean | Lines 1–95 | Resolves gridSize=2^n and local finite matrix alias. Only its initial definitions were needed; import Std remains unexpanded. |
| QuantumBlockEncoding/Robin/Hadamard8Verified.lean | Lines 1–45 | Checks actual import edge and the specific constant referenced in PrimitiveSemantics. Imports Robin.EvolvedCandidates (unopened), Robin.ComplexLCUProjection (initial 15 lines only), Mathlib.Tactic (unexpanded). No other body was read. |
| QuantumBlockEncoding/BlockEncoding.lean | Lines 1–45 | Confirms StatePreparation import provenance and matrix/resource interface context; import Circuit remains unexpanded. |
| QuantumBlockEncoding/Robin/ComplexLCUProjection.lean | Lines 1–15 | Resolves import to ComplexLCU only; no projection theorem body read. |
| QuantumBlockEncoding/Robin/ComplexLCU.lean | Lines 15–86 plus scoped lexical search for rotation names/imports | Resolves realOrthogonalRotation entries, realRotation and elementary unitarity. ConcreteSemantics, trigonometric Mathlib, matrix Block/Kronecker/Reindex and Mathlib.Tactic imports remain unexpanded. Other declarations not opened. |
| .lake/packages/mathlib/Mathlib/Logic/Equiv/Fin/Basic.lean | Lines 321–360 plus scoped lexical search for finProdFinEquiv | Resolves pair flattening value second+n*first. Rest of file and imports remain unexpanded. |

The three target actual files were independently hashed, scanned for declarations/ambient commands and scanned for placeholder/native markers; their complete mathematical contents were read in the initial packet. The actual lean-toolchain, lakefile.lean and lake-manifest.json were hashed and their content was read in the initial packet. All six match supplied content hashes. The supplied packet itself matches its independently computed full SHA256 and byte count.

## Governance read versus mathematical input

Read fully before task actions: AGENTS.md, HARNESS.md, .agents/skills/qbe-substantive-worker/SKILL.md, docs/theorem-publication-protocol.md, docs/proof-digestion-protocol.md, docs/evidence-routed-memory-protocol.md. These controlled process only; they did not supply mathematical source hypotheses or expected decisions. No docs/lessons, reports, reviews, verdicts, siblings' decoder outputs, CI/runtime/logs, research atlas, curated process-memory file, external paper or web page was consulted. No Git command was executed. Parent-reported repository head remains parent-reported only.

## Reference signals versus dependency proofs

An import line is actual source module structure. A visible theorem name in a proof is a source reference signal. Neither establishes complete elaborated theorem/proof-term dependence. Included proof text can use implicit elaborator instances and simp lemmas not named literally; no lexical scan here is labelled a complete proof DAG. Absence of explicit axiom/sorry tokens in the targets does not certify transitive axiom cleanliness. No generated native axioms are identified without execution.

Potential downstream mathematical transports are not target conclusions: the imported compileSO/existential local-circuit resource interface, schedule whole-state action, canonicalization existence and terminal cleanup remain separate. They may provide candidate substrates for a later construction, but this formal-only decoder does not compose them into an unprovided theorem or import them into a claimed new resource result.
