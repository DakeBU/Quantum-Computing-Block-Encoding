"""Independent read-only byte, coverage and binding replay. No packet execution.

Arguments: released metadata directory, repository, schema-successor context,
released static formal ZIP. Prints public logical observations only.
"""
import hashlib
import json
import pathlib
import re
import sys
import zipfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def jbytes(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False).encode()


def main():
    meta, repo, context_path, static_path = map(pathlib.Path, sys.argv[1:5])
    load = lambda name: json.loads((meta / name).read_bytes())
    context = json.loads(context_path.read_bytes())
    checks = []

    def check(name, condition):
        if not condition:
            raise AssertionError(name)
        checks.append(name)

    allow = load("public-safe-projection-allowlist.json")
    manifest = load("manifest.json")
    freeze = load("freeze.json")
    check("released freeze SHA", sha((meta / "freeze.json").read_bytes()) ==
          "a94627897de1653754e7f496d00a2b19536bc9243fad235b15ee7693e9605e09")
    check("manifest frozen hash", sha((meta / "manifest.json").read_bytes()) == freeze["manifest_sha256"])
    names = [x["path"] for x in allow["files"]] + allow["self_and_seals"]
    check("exact 22 authorized metadata files", len(names) == len(set(names)) == 22)
    check("manifest file set", {x["path"] for x in manifest["files"]} == set(names) - {"manifest.json", "freeze.json"})
    check("allowlist payload hashes", all(sha((meta / x["path"]).read_bytes()) == x["sha256"] for x in allow["files"]))
    check("manifest payload hashes and sizes", all(sha((meta / x["path"]).read_bytes()) == x["sha256"] and
          len((meta / x["path"]).read_bytes()) == x["bytes"] for x in manifest["files"]))
    published = repo / "reviews/publication/real-preparation-c32/metadata-v3"
    check("all 22 repository metadata copies byte-identical", all((published / n).read_bytes() == (meta / n).read_bytes() for n in names))
    source_bytes = (meta / "source-effective-v3.md").read_bytes()
    source = source_bytes.decode().replace("\r\n", "\n")
    check("natural-v3 source pin", sha(source_bytes) == "dba646110300c6a8e9f8b275eeb0dba2140add2a9f0096934f03a51e886da6cd")
    lesson_path = "docs/publication-c32-v3/source-effective-v3.md"
    check("published lesson exact source bytes", (repo / lesson_path).read_bytes() == source_bytes)
    lines = source.splitlines()

    def span_text(span):
        text = "\n".join(lines[span["start_line"] - 1:span["end_line"]])
        check("source span hash", sha(text.encode()) == span["text_sha256"])
        return text

    graph = load("four-view-graph.json")
    coverage = load("source-coverage-v3.json")
    quotes = load("per-root-source-quotes.json")
    audit = load("recursive-binder-audit.json")
    inventory = load("whole-module-inventory.json")
    roots = [r for m in inventory["modules"] for r in m["declarations"]]
    by_name = {r["fullName"]: r for r in roots}
    check("57 unique roots", len(roots) == len(by_name) == 57)
    check("53 public and four private roots", sum(r["modifier"] != "private" for r in roots) == 53 and
          sum(r["modifier"] == "private" for r in roots) == 4)
    check("13 definitions and 44 theorems", sum(r["kind"] == "def" for r in roots) == 13 and
          sum(r["kind"] == "theorem" for r in roots) == 44)
    for collection in (quotes["roots"], audit["roots"], coverage["formal_root_coverage"]):
        check("all 57 roots present in metadata layer", len(collection) == 57 and
              {r["fullName"] for r in collection} == set(by_name))
    check("all binder exact signatures agree", all(r["exact_signature"] == by_name[r["fullName"]]["exact_signature"] for r in audit["roots"]))
    with zipfile.ZipFile(static_path) as archive:
        formal = archive.read("formal-context.md").decode().replace("\r\n", "\n")
        check("independently reviewed formal packet pin", sha(archive.read("formal-context.md")) ==
              "16aed6ce6806d4423a421683905cead1cd2bb9818665b86594965bcae197694c")
        static_roots = json.loads(archive.read("inventory.json"))
        check("metadata root names match independently reviewed formal inventory", set(by_name) == {r["id"] for r in static_roots})
        for module in inventory["modules"]:
            path = module["path"]
            code = formal.split("## " + path + "\n", 1)[1].split("\n## ", 1)[0].split("```lean\n", 1)[1].split("\n```", 1)[0]
            matches = [text for text in (code, code + "\n", code + "\n\n") if sha(text.encode()) == module["sha256"]]
            check("whole module exact source hash", len(matches) == 1)
            code_lines = matches[0].splitlines()
            for root in module["declarations"]:
                exact = "\n".join(code_lines[root["line"] - 1:root["end_line"]])
                check("all 57 full declaration sources agree", exact.rstrip() == root["exact_source"].rstrip())
    for root in quotes["roots"]:
        check("all 57 quotes exact spans", root["quote"] == span_text(root["source_span"]))
        check("all 57 quote hashes", sha(root["quote"].encode()) == root["quote_sha256"])
        check("all 57 source-section association", root["source_section"] == by_name[root["fullName"]]["source_section"])
    regions = graph["source_view"]["all_regions"]
    check("all 72 maximal source blocks exact", len(regions) == 72 and [r["text"] for r in regions] == source.strip().split("\n\n"))
    check("coverage and graph agree on all regions", coverage["regions"] ==
          [{k:r[k] for k in ("id", "disposition", "source_span")} for r in regions])
    for region in regions:
        check("every region exact span", region["text"] == span_text(region["source_span"]))
        if region["disposition"].startswith("EXCLUDED("):
            check("only navigation headings excluded", region["text"].startswith("#") and "\n" not in region["text"])
        else:
            check("all substantive blocks NODE", region["disposition"] == "NODE")
    for item in quotes["additional_source_context"]:
        check("H and I contextual quotes exact", item["quote"] == span_text(item["source_span"]))
    topology = load("source-change-topology.json")
    check("exact graph hash", sha((meta / "four-view-graph.json").read_bytes()) == topology["graph_sha256"])
    graph_lines = (meta / "four-view-graph.json").read_text(encoding="utf-8").splitlines()
    check("all graph line anchors exact", all(x["anchor"] in graph_lines[x["line"]-1] for x in topology["graph_line_anchors"]))
    check("Rz is sole changed subsection", all(x["content_equal"] == (x["id"] != "A2") for x in topology["section_equality"]))
    pins = load("current-pins.json")
    normalized = {}
    for pin in pins["files"]:
        data = (repo / pin["path"]).read_bytes()
        check("207 current proof-input raw pins and lengths", sha(data) == pin["sha256"] and len(data) == pin["bytes"])
        lf = sha(data.replace(b"\r\n", b"\n"))
        check("207 current LF pins", lf == pin["lf_normalized_sha256"])
        normalized[pin["path"]] = lf
    check("proof input digest", sha(json.dumps(normalized, sort_keys=True, separators=(",", ":")).encode()) == pins["proofInputsSha256"])
    check("202 Lean plus five configurations", len(pins["files"]) == 207 and
          sum(x.startswith("QuantumBlockEncoding/") for x in normalized) == 142 and
          sum(x.startswith("ABEISTests/") for x in normalized) == 60)
    checker_path = "website/scripts/check_research_publications.py"
    check("unchanged official binding algorithm bytes", sha((repo/checker_path).read_bytes()) == pins["checker_sha256"])
    selected_keys = ("module", "source_id", "source_statement", "source_anchor", "lesson_path", "declarations",
                     "obligation_map", "assumption_deltas", "graph_contribution", "formalizer", "residual_boundary")
    lean_paths = [p for directory in ("QuantumBlockEncoding", "ABEISTests") for p in sorted((repo/directory).rglob("*.lean"))]
    check("binding ambient Lean set equals pins", {p.relative_to(repo).as_posix() for p in lean_paths} ==
          {p for p in normalized if p.startswith(("QuantumBlockEncoding/", "ABEISTests/"))})

    def binding(record, row):
        digest = hashlib.sha256(jbytes({k:record.get(k) for k in selected_keys}))
        for name in (record["module"], record["lesson_path"], "lean-toolchain", "lake-manifest.json"):
            digest.update(name.encode())
            digest.update((repo/name).read_bytes())
        for path in lean_paths:
            digest.update(path.relative_to(repo).as_posix().encode())
            digest.update(path.read_bytes())
        digest.update(jbytes(row))
        return digest.hexdigest()

    old_row = load("binding-bridge.json")["own_unreviewed_source_row_candidate"]
    new_row = context["new_row"]
    check("old row preserved", old_row == context["old_row"])
    check("only url and status changed", sorted(k for k in old_row if old_row[k] != new_row[k]) == ["status", "url"] and set(old_row) == set(new_row))
    states = {"primary-metadata-checked", "primary-text-checked", "primary-source-unavailable"}
    required = ("title", "url", "status", "anchor", "scope", "formal_status")
    schema_ok = lambda row: all(row.get(k) for k in required) and row["status"] in states and row["url"].startswith("https://")
    check("old row schema actually rejected", not schema_ok(old_row) and old_row["url"] == "" and old_row["status"] not in states)
    check("successor row schema valid", schema_ok(new_row) and new_row["status"] == "primary-text-checked")
    installed_catalog = json.loads((repo/"website/research/sources.json").read_bytes())
    installed_rows = [x for x in installed_catalog["sources"] if x["id"] == new_row["id"]]
    check("current installed selected row exact successor", installed_rows == [new_row])
    records = load("prospective-publication-records.json")["records"]
    bindings = []
    for original, current in zip(records, context["records"]):
        check("all bound record fields unchanged by schema successor", all(original.get(k) == current.get(k) for k in selected_keys))
        old_digest = binding(original, old_row)
        new_digest = binding(current, new_row)
        check("old WIP digest reproduced not reusable", old_digest == original["binding_sha256"] and new_digest != old_digest)
        check("new successor digest reproduced", new_digest == current["binding_sha256"])
        module = next(m for m in inventory["modules"] if m["path"] == current["module"])
        public = [r["fullName"] for r in module["declarations"] if r["modifier"] != "private"]
        check("prospective record complete public coverage", current["declarations"] == public)
        check("one obligation map per public root", [x["declarations"][0] for x in current["obligation_map"]] == public and all(len(x["declarations"]) == 1 for x in current["obligation_map"]))
        check("unknown historical formalizer retained", current["formalizer"] == current["historical_formalizer"] == "UNKNOWN")
        bindings.append({"module":current["module"], "old_schema_invalid_wip_digest":old_digest, "current_schema_successor_digest":new_digest})
    result = {"schema":"c41-independent-phase5-byte-and-coverage-replay/v1",
              "scope":"released metadata, prior reviewed formal packet, 207 current pins and exact schema-only successor; no Lean/native execution",
              "metadataFreezeSHA256":sha((meta/"freeze.json").read_bytes()),
              "successorContextSHA256":sha(context_path.read_bytes()),
              "sourceSHA256":sha(source_bytes), "proofInputsSHA256":pins["proofInputsSha256"],
              "checks":dict.fromkeys(checks, True), "rawCheckApplications":len(checks),
              "rootCounts":{"all":57,"public":53,"private":4,"definitions":13,"theorems":44},
              "sourceBlocks":{"all":72,"NODE":sum(x["disposition"] == "NODE" for x in regions),"excludedHeading":sum(x["disposition"].startswith("EXCLUDED(") for x in regions)},
              "bindings":bindings,
              "originalRow":"REJECTED_FOR_CANONICAL_CATALOG_SCHEMA; original bytes and digest history preserved",
              "successorRow":"SCHEMA_VALID; primary-text-checked is not formal admission",
              "finalActualDecoderBindingJSON":"NOT_YET_RELEASED_TO_THIS_REVIEWER",
              "sourceAgreement":None,"publicationBinding":None,"finalAcceptedWrapper":False,
              "nativeExecutionByReviewer":False,"GitOrNetwork":False,"productionWrites":False,"children":False,
              "allTCBAudit":False,"allOrdinaryBodyPrintAudit":False,"mainAdmission":False,"PURIFIED":False}
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
