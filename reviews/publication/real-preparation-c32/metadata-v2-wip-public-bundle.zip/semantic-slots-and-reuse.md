# C32 v2 author semantic ledger

This is a versioned author-side metadata rebase, not an independent decoder or reviewer result. The natural source is the exact parent-authored clarification v2 (SHA256 936020bf35582267a8149ed49addd9a9b106c23512205acaf49e9a3febaa6d80). Its original author was real-preparation-author-c32; historical formalizer remains UNKNOWN. The source remains implementation-informed retrospective. Neither the original freeze nor this successor is a historical pre-proof Statement Seal. The parent reports the same natural-only review completed; no reviewer material was read or used here and no accepted verdict is assigned.

## Seven semantic slots

| Slot | Real-amplitude tree | Classical completion | Actual local completion / H0 consumer |
| --- | --- | --- | --- |
| target | Exact first column f/sqrt(sum f^2) of the specific recursive tree; strictly positive flat wrapper remains distinct | Real orthonormal prescribed columns at an arbitrary injection; O(N), then SO(N) with a spare column | Specific exact-real matrix from actual padded real chain columns. H0 reexpresses this matrix on numerical bit-first axes |
| normalization | Nonnegative table plus positive actual squared norm for all-width action; normalization lemma itself allows signs | V^T V=I is actual column orthonormality | Every core satisfies A A^T=I; occupied columns are derived from supplied chain data, not a whole-action premise |
| registers | Named n wires, wire 0 least significant; highest-wire append; chronological matrices act on the left | Arbitrary physical injection, not prefix placement | q low bond wires and a fresh highest bit. B=2^q; h(v,b)=(ell_q^{-1}(b),v). Both matrix axes use the same h; clean numerical column is (0,a), a<r_t |
| oracles | X/RY/RZ/CX lifting language, actual tree only RY/CX; zero oracle instructions does not cost input access | No oracle/runtime contract | Real chain and entries are supplied data. H0 neither adds coherent access nor proves an entry evaluator |
| ancillas_phases | Exactly n wires; exact equality including scalar phase; zero table has no normalized target | Spare matrix column is not an ancilla wire; existential completion noncanonical | Fresh bit exactly zero; inactive and nonzero-bit columns are fixed by the full producer but not specified as padded core action. H0 adds no sign, phase quotient, transpose of U, physical SWAP or free routing |
| error_success | Exact symbolic action; no postselection/probability loss | Exact columns and orthogonality; determinant +1 only with its stated supplier | Exact occupied columns, t<n, no approximation premise. Terminal cleanup remains a separate sequential consequence with terminal rank one |
| resources | Exactly 2^n-1 RY and 2(2^n-1-n) CX for the reference tree; exponential in wire count | Existence is not an arithmetic algorithm or runtime certificate | Actual exact-real elimination/permutation producer, not a primitive gate list or finite-bit implementation. H0 relabeling does not discharge physical wire placement or its cost |

## Exactly two source changes

H0 is a literal natural coordinate definition. With P(z,x)=delta(z,h(x)), the metadata notation is mathcalU=P^T U P. This is an explicit expression of the natural H0 simultaneous-axis transport, not a third source replacement or a physical instruction. Substitution into G4 yields mathcalU_t((v,b),(0,a))=K_t((v,b),a) for active a<r_t. Every original conditional-run tail remains, with an additional explicit coordinate-consistency tail. The implementation-adapter correspondence remains OPEN; no actual adapter or flattened circuit theorem is newly certified.

I now correctly classifies only the signed-all-width strengthening of the unchanged empty-phase tree as REFUTED: n=0 and singleton f=-1 have norm one, tree scalar +1 and target scalar -1. D1 already supplied that witness. The nonnegative all-width theorem remains intact; positive-width signed preparation is neither refuted nor established. All other source gaps and both completion/state OR-route records are retained.

## Preserved OPEN boundaries and reuse

A2 names z-rotation but does not give its exact 2-by-2 scalar/phase formula. The four-instruction lifting API therefore retains an OPEN Rz natural-scope mapping beyond the RY/CX tree. The exact formal Rz convention is visible in the unchanged formal provider; author metadata must not silently supply it as natural-source agreement. The affected lexical roots are liftGate, eval_liftGate and eval_liftCircuit; their signatures and proof premises are unchanged. This is a coverage annotation of existing scope, not a new natural-source edit.

The source gaps for weaker flat premises, function-to-chain extraction, bounded-rank approximation, deterministic finite-bit canonicalization, numerical angle evaluation, primitive local compilation, global placement, boundary loading, preprocessing, depth, connectivity, discrete synthesis and readout remain OPEN. Supplied-stage consumers are not producers. Existence-route and deterministic-route specifications remain alternatives with different producer/cost evidence. No arbitrary block encoding follows from SP alone; complete SELECT/unprepare/phase/clean-register/resource inputs remain conjunctive. The reverse transport retains its input, nonzero branch, normalization and success/amplification inputs.

No definitions or theorem interfaces changed. Literal zero-angle behavior, padding outside active ranks, empty dimensions, zero pivots, deficient rank, q=0, r=0, non-prefix placement and orientation-reversing full-column obstruction remain as in the raw baseline ledger. That complete original ledger is retained byte-identically under inherited/semantic-slots-and-reuse-v1.md. Its time-local gate/scope statements describe its original authoring stage, not new evidence.

The actual Lean view remains module imports and declaration ownership only, not an elaborated proof-term graph. Source construction, compressed conceptual spine and conditional Functor hyperedges remain distinct and author-proposed. No new foundational primitive or canonical API was introduced; all prior local/Mathlib provider reuse remains. Unknown source-to-formal mappings are OPEN, not admitted by fallback.

## Gate state

sourceAgreement=null; publicationBinding=null; axiomPolicyPass=null; nativeAccepted=false; scientific_ROOT=false; main_admission=false. The three actual prospective binding digests are content-context hashes only. Decoder/reviewer evidence remains null. There were zero Git, Lean, lake, native, network, production/canonical writes, installations or sub-agent spawns. No PROOF_SEALED, SOURCE_AGREEMENT, MAIN_ADMITTED, PURIFIED or Exposition Seal is claimed.
