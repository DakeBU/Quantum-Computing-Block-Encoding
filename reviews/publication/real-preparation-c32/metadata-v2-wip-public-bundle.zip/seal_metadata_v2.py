"""Freeze only this additive metadata packet; never publish or run a verifier.

A complete manifest excludes its own bytes and the enclosing freeze; the freeze
binds that manifest. Its external SHA256 is the handoff root. No recursive hash
or alias between old raw inputs and new derivatives is manufactured.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from rebase_metadata import HERE, BUNDLE, GATES, V1, V2, sha, read_json, emit


def entries():
    return [{"path": p.relative_to(HERE).as_posix(), "sha256": sha(p.read_bytes()), "bytes": p.stat().st_size}
            for p in sorted(HERE.rglob("*")) if p.is_file() and p.name not in ("manifest.json", "freeze.json")]


def seal():
    assert not (HERE / "freeze.json").exists(), "already frozen: STOP; additive successors only"
    receipt = read_json(HERE / "test-receipt-final-03.json")
    assert receipt["all_pass"] and receipt["strategy_accounting"]["validate_record_calls"] == 0
    assert receipt["test_script_sha256"] == sha((HERE / "test_metadata_v2.py").read_bytes())
    immutability = read_json(HERE / "input-immutability.json")
    assert all(sha((BUNDLE / row["path"]).read_bytes()) == row["sha256"] for row in immutability["files"])
    raw = read_json(HERE / "byte-preservation.json")["files"]
    by_output = {r["output"]: r for r in raw}
    derivative_pairs = [
        ("inherited/whole-module-inventory-v1.json", "whole-module-inventory.json", "Only natural-source link version and explicit source-version annotation; exact signatures and source slices unchanged"),
        ("inherited/per-root-source-quotes-v1.json", "per-root-source-quotes.json", "Source SHA/links/spans and explicit OPEN coverage annotations; each of 57 root quote contents unchanged"),
        ("inherited/recursive-binder-audit-v1.json", "recursive-binder-audit.json", "Versioned references plus natural H0 definition and retained OPEN scope; exact 57 root audits unchanged except source links"),
        ("inherited/four-view-graph-v1.json", "four-view-graph.json", "Versioned source regions, H0 transport topology, REFUTED classification and exact preserved AND/OR/Lean structure as documented"),
        ("inherited/semantic-slots-and-reuse-v1.md", "semantic-slots-and-reuse.md", "Full seven-slot successor ledger; raw original ledger preserved independently")]
    lineage = [{"raw_path": a, "raw_sha256": sha((HERE / a).read_bytes()),
                "public_derivative_path": b, "public_derivative_sha256": sha((HERE / b).read_bytes()),
                "relationship": reason, "raw_alias": False, "redaction": False} for a, b, reason in derivative_pairs]
    emit("raw-to-public-lineage.json", {"kind": "Raw byte snapshots and separate successor derivatives; no new digest aliases an old raw file",
                                         "derivatives": lineage, "raw_private_scripts": [
                                             {"input": by_output[n]["input"], "public_safe_raw_snapshot": n, "raw_sha256": by_output[n]["sha256"], "snapshot_sha256": sha((HERE / n).read_bytes()), "redaction_required": False}
                                             for n in ("inherited/compute_prospective_bindings-v1.py", "inherited/test_binding_sensitivity-v1.py")],
                                         "script_safety": "Scripts use CLI-supplied paths, not literal host locations or credentials. Safety-detector literals are patterns, not actual host paths. No script redaction was required.",
                                         "deployment_authorized": False})
    all_names = sorted({r["path"] for r in entries()} | {"raw-to-public-lineage.json", "public-safe-projection-allowlist.json", "manifest.json", "freeze.json"})
    emit("public-safe-projection-allowlist.json", {
        "policy": "Explicit deny-by-default public-safety projection eligibility only. Does not authorize release, sending restricted packets to wrong roles, source agreement, or admission.",
        "public_projection_allowlist": all_names,
        "byte_policy": "Use inherited/raw paths exactly with their raw hashes. Use successor derivatives under their own paths and hashes. Never relabel a derivative digest as an old raw alias.",
        "source_first_reader_allowlist": ["source-effective-v2.md", "source-seal-v2.json"],
        "formal_blind_decoder_allowlist": ["formal-context.md"],
        "orchestrator_only_formal_packet_hash": "formal-context-seal.json",
        "anti_anchored_whole_module_reviewer": "Separate authorized packet after distinct formal-blind decode; author coverage/graphs are proposals, never an expected verdict",
        "inherited_private_role_boundary": "Original author-private filenames remain excluded from natural-only and blind-formal stages even if text is eligible for a separately authorized public audit projection.",
        "not_allowlisted": "Any path not listed; all outside-host files; reviewer/decoder outputs not read here; credentials; canonical registration/deployment",
        "public_deployment": False, "redactions_required": [], "safety_scan_receipt": "test-receipt-final-03.json",
        "not_a_historical_preproof_seal": True, **GATES})
    rows = entries()
    emit("manifest.json", {"schema": "c32-metadata-v2-complete-manifest", "files": rows,
                           "count": len(rows), "excluded_self_and_envelope": ["manifest.json", "freeze.json"],
                           "integrity_rule": "Every other file under this new directory is exactly listed. Freeze binds this complete manifest; no files may be added or modified after freezing.", **GATES})
    bindings = read_json(HERE / "binding-bridge.json")["bridges"]
    emit("freeze.json", {"schema": "c32-versioned-metadata-v2-freeze", "status": "FROZEN_STOP_FOR_PARENT_INDEPENDENT_AUDIT",
                         "manifest": {"path": "manifest.json", "sha256": sha((HERE / "manifest.json").read_bytes())},
                         "source_v1_sha256": V1, "source_v2_sha256": V2,
                         "test_receipt": {"path": "test-receipt-final-03.json", "sha256": sha((HERE / "test-receipt-final-03.json").read_bytes()),
                                          "all_pass": True, "validate_record_calls": 0},
                         "prior_failed_attempt_preserved": ["test-receipt-attempt-01.json", "test_metadata_v2-attempt-01.py"],
                         "native_success_delta": 0, "native_calls": 0, "canonical_writes": False,
                         "binding_candidates": [{"module": r["module"], "binding_sha256": r["v2_binding"], "admissible": False} for r in bindings],
                         "historical_formalizer": "UNKNOWN", "natural_v2_author": "/root", "metadata_rebase_author": "real_preparation_metadata_v2_c32",
                         "next_action": "STOP. Parent independently inspect/test; original source-first process continues separately. No push or agent operation.", **GATES})
    print(json.dumps({"freeze_sha256": sha((HERE / "freeze.json").read_bytes()), "manifest_sha256": sha((HERE / "manifest.json").read_bytes()), "files_in_manifest": len(rows), "status": "FROZEN_STOP", "native_success_delta": 0}, indent=2))


def verify():
    freeze = read_json(HERE / "freeze.json")
    manifest = read_json(HERE / "manifest.json")
    assert sha((HERE / "manifest.json").read_bytes()) == freeze["manifest"]["sha256"]
    assert entries() == manifest["files"], "unexpected added/modified/missing packet file"
    assert all(sha((BUNDLE / row["path"]).read_bytes()) == row["sha256"] for row in read_json(HERE / "input-immutability.json")["files"])
    print(json.dumps({"frozen_manifest_verified": True, "freeze_sha256": sha((HERE / "freeze.json").read_bytes()), "files_in_manifest": len(manifest["files"]), "no_writes": True}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-only", action="store_true")
    args = parser.parse_args()
    verify() if args.verify_only else seal()
