"""Read-only virtual mutation tests for the exact publication binding function."""
from __future__ import annotations

import argparse
import copy
import importlib.util
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from compute_prospective_bindings import EXPECTED_CHECKER, OverlayPath, digest


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()
    directory = Path(__file__).resolve().parent
    bundle = directory.parent
    report = json.loads((directory / "binding-attempt-01.json").read_text(encoding="utf-8"))
    checker_path = repo / report["checker_path"]
    assert digest(checker_path.read_bytes()) == EXPECTED_CHECKER
    spec = importlib.util.spec_from_file_location("unmodified_binding_sensitivity_checker", checker_path)
    checker = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(checker)
    catalog = json.loads((repo / "website/research/sources.json").read_text(encoding="utf-8"))
    catalog["sources"].append(report["own_virtual_source_row"])
    lesson_path = report["records"][0]["lesson_path"]
    base_overrides = {
        lesson_path: (bundle / "source-only.md").read_bytes(),
        "website/research/sources.json": json.dumps(catalog, ensure_ascii=False, sort_keys=True).encode("utf-8")
    }
    base_record = report["records"][0]
    root = lambda overrides: OverlayPath(repo, directory / "logical-overlay-root", overrides)
    baseline = checker.binding_digest(root(base_overrides), base_record)
    assert baseline == base_record["binding_sha256"]
    tests = []

    def changed(name: str, override_key: str | None = None, data: bytes | None = None, field: str | None = None) -> None:
        overrides = copy.deepcopy(base_overrides)
        record = copy.deepcopy(base_record)
        if override_key is not None:
            overrides[override_key] = data if data is not None else (repo / override_key).read_bytes() + b"\n-- virtual negative byte mutation only\n"
        if field is not None:
            record[field] += " [virtual negative mutation]"
        mutated = checker.binding_digest(root(overrides), record)
        tests.append({"name": name, "baseline_sha256": baseline, "mutated_sha256": mutated, "expected": "different", "ok": mutated != baseline})

    changed("lesson byte mutation", lesson_path, base_overrides[lesson_path] + b"\nVirtual negative mutation.\n")
    target = base_record["module"]
    data = (repo / target).read_bytes()
    assert b"private theorem xBasis_lift" in data
    changed("target private helper lexical mutation", target, data.replace(b"private theorem xBasis_lift", b"private theorem xBasis_lift_virtual_mutation", 1))
    changed("target import byte mutation", target, data.replace(b"import QuantumBlockEncoding.PrimitiveBasisLE", b"import  QuantumBlockEncoding.PrimitiveBasisLE", 1))
    production = next(x["path"] for x in report["raw_ambient_context"] if x["path"].startswith("QuantumBlockEncoding/") and x["path"] != target)
    tests_path = next(x["path"] for x in report["raw_ambient_context"] if x["path"].startswith("ABEISTests/"))
    changed("ambient production module byte mutation", production)
    changed("ambient ABEISTests byte mutation", tests_path)
    changed("manifest byte mutation", "lake-manifest.json")
    changed("toolchain byte mutation", "lean-toolchain")
    changed("bound author metadata mutation", field="formalizer")
    changed_catalog = copy.deepcopy(catalog)
    changed_catalog["sources"][-1]["title"] += " [virtual mutation]"
    changed("own virtual source-row semantic metadata mutation", "website/research/sources.json", json.dumps(changed_catalog, ensure_ascii=False, sort_keys=True).encode("utf-8"))
    # Exact function deliberately does not hash unrelated catalog rows or registry bytes.
    unrelated = copy.deepcopy(catalog)
    unrelated["sources"][0]["title"] += " [unrelated virtual mutation]"
    overrides = dict(base_overrides)
    overrides["website/research/sources.json"] = json.dumps(unrelated, ensure_ascii=False, sort_keys=True).encode("utf-8")
    unrelated_digest = checker.binding_digest(root(overrides), base_record)
    tests.append({"name": "unrelated source row is not mathematical binding authority", "expected": "same", "ok": unrelated_digest == baseline})
    for record in report["records"]:
        try:
            checker.validate_record(root(base_overrides), record, {})
        except ValueError as error:
            message = str(error)
            tests.append({"name": record["module"] + " remains inadmissible without decoder", "expected": "publication lacks decoder_evidence", "actual": message, "ok": "publication lacks decoder_evidence" in message})
        else:
            tests.append({"name": record["module"] + " remains inadmissible without decoder", "ok": False})
    out = {"kind": "Unmodified actual binding_digest virtual negative/sensitivity checks, not compiler or admission", "checker_sha256": EXPECTED_CHECKER, "tests": tests, "all_pass": all(t["ok"] for t in tests), "canonical_writes": False, "mutation_scope": "in-memory bytes/record dictionaries only; frozen sources and prior attempts unchanged"}
    print(json.dumps(out, ensure_ascii=False, indent=2))
    if not out["all_pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
