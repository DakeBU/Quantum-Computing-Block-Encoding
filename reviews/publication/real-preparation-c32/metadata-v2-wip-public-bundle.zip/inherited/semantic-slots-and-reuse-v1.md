# Author semantic ledger and reuse boundary

This is an author ledger, not an independent review. All statements refer to the frozen raw sources. Historical formalizer is UNKNOWN; the current author only recovers their meaning retrospectively. No prior author/decoder/reviewer/CI/verdict was consulted. The target files contain no structures or ambient variable binders beyond namespaces and opens; all bundled inputs come from identified providers.

## Seven semantic slots

| Slot | Real-amplitude tree | Classical real completion | Actual local completion |
| --- | --- | --- | --- |
| target | Exact first column f/√Σf² of one named tree; flat-coordinate positive-table interface | Real N×r isometry at arbitrary injective physical column positions; O(N), then SO(N) with spare column | Specific matrix returned from actual occupied real padded columns of a supplied dependent chain |
| normalization | Actual finite sum of squares, not target.normalization : Prop data; zero norm excluded only from normalized-action claims | VᵀV=I means all prescribed column inner products equal delta; no amplitude normalization flag | Every actual core satisfies A Aᵀ=I; this supplies active column orthonormality, not an assumed whole-state equality |
| registers | n named wires, wire zero least significant; append highest wire; later chronological gates multiply on the left | Fin N real coordinates; arbitrary injection e, no prefix assumption | q low bond wires and highest fresh output bit; coordinate (bit,LE(bond)), flattened bit·2^q+LE(bond); clean inputs snoc(a,0), LE(a)<rankAt t |
| oracles | Literal X/RY/RZ/CX language, actual tree only RY/CX, zero oracle instructions; arbitrary table access/preprocessing not costed | No oracle model or runtime given | No oracle hypothesis; input chain and exact matrix entries are supplied data; no implied free evaluation |
| ancillas_phases | Exactly n wires in type, no additional workspace; matrix equality including global phase; n=0 nonnegative nonzero scalar needed | Unused column is a free matrix column, not an ancilla wire; orientation correction changes only it; nonunique completion, no canonical phase class | Fresh bit input is exactly zero; inactive/nonzero-bit input columns unconstrained by core contract but specified by chosen full completion. Terminal-bond cleanup is a separate composed result, not a local conclusion |
| error_success | Exact symbolic action, no postselection, no probability loss; no approximate export theorem | Exact columns and orthogonality, determinant +1 only in SO statements | Exact occupied columns, no probability or tolerance premise. t<n is necessary; padded schedule is zero beyond chain but no late-stage correctness is advertised |
| resources | Exactly 2^n−1 RY and 2(2^n−1−n) CX for reference tree. Exponential wire-count baseline. No preprocessing, finite-bit, compiled discrete gate, depth or connectivity theorem | Pure existence: neither arithmetic algorithm nor preprocessing cost | Named exact-real producer via reused rotations/permutations. No local primitive-circuit, whole flattened-circuit or numerical evaluation-cost theorem in target module |

Zero-pivot, zero input, n=0, q=0, r=0, deficient-rank, active-label and determinant-sign distinctions remain separate. The local rank bound is r≤2^q, hence strict r<2·2^q even when q=0; the arbitrary SO completion theorem instead needs an explicit unused column or strict r<N. Full-column determinant −1 is the sharp excluded case.

## Reuse audit (read-only, no new foundational API)

1. Existing local direct substrate is reused: UniformlyControlledRy supplies reference multiplexor semantics and counts; PrimitiveSemantics supplies half-angle matrices, named-wire lifts and chronological evaluation; PrimitiveBasisLE supplies the coordinate equivalence; StatePreparation contributes zeroBasisIndex only to the target. The presence of imported generic certificate structures does not convert proposition-valued data fields into proofs.
2. RealIsometryCompletion reuses Mathlib Euclidean-space orthonormal-family extension and determinant facts; the exact extension theorem in PiL2 was read. It does not implement a new foundational Gram–Schmidt procedure. Only necessary Mathlib provider ranges were read, not all imported library proofs.
3. ConstructiveIsometryCompletion supplies actual rectangular adjacent-row elimination, prefix-column preservation, explicit greedy extension of injection, unused position and parity orientation correction; RectangularGivens supplies its actual trace/transform and exact recovery. ConstructiveIsometryLocal calls this producer, not TensorTrainLocalCompiler's existential completion API. Its actual imports still include the latter module, so module-level import structure is not erased.
4. TensorTrainCanonical supplies real dependent cores and recursively right-canonical data, padding and isometry; TensorTrainSchedule supplies actual ranks and scheduled cores; TensorTrainLocalCompiler supplies explicit localIndex, activePositions, activeColumns, their realness/isometry. SequentialBondPreparation supplies the separate conditional run semantics. This is reuse, not duplication or claimed new canonicalization.
5. No external quantum library is introduced; no foundational state/channel/block-encoding primitive is added. A global external-library survey is unnecessary for this read-only recovery and was not performed. Existing production APIs are preserved.

## Definition and choice audit

All target definitions are literal exact formulas, recurrences or coordinate maps. None chooses the existential SO witness. Characterized uniqueness is not asserted. The existential orthonormal extension is noncanonical; downstream prescribed-column statements hold for any witness satisfying the specification. The deterministic local formula has one fixed output by its recurrence but is not a numerical finite-bit program merely because it avoids selecting a basis witness.

Zero-angle behavior at a zero pair is mathematically specified and proved harmless for the pair identity. A zero full table still produces a unitary list but lies outside the normalized-state claim. Zero fill outside active tensor ranks is part of the padding embedding; no identity action or desired state is manufactured in those sectors. Complete-stage specification applies only before n; defining a matrix at later t does not certify its desired action.

## Actual additional reads after source freeze

After the immutable freeze, the author read AdjacentGivens lines 386–447 to inspect the exact positive-pivot proof and a bounded definition excerpt of Mathlib finProdFinEquiv in Logic/Equiv/Fin/Basic. The latter explicitly maps (x,y) to y+n*x, confirming the source-only local flattening formula. These reads confirm provider details; they did not change the frozen mathematics. The exact formal-context excerpt of AdjacentGivens is lines 1–442 and can include the start of an unrelated next proof; its bounded status is explicit. No full transitive proof closure is claimed.

## Remaining gates and safe use

The root frontier is explanatory recovery, not new theorem closure. No native Lean replay, inherited-proof equality check, main-toolchain migration, independent decoder, anti-anchored review, common-blind-spot review, source-topology approval, publication admission or Exposition Seal was performed by this worker. No SOURCE_AGREEMENT, PROOF_SEALED, main-certified or PURIFIED label follows. A separate independent reader must decide whether the frozen lesson truly covers the complete formal contracts, without this private ledger.

Only source-only.md and the relative-path source-freeze.json are eligible for the independent natural-source-first stage. The private coverage, formal context, exact signatures/quotes, candidate bindings and author classifications must remain outside that stage. Later source-blind formal decoding receives formal-context.md alone, not this lesson or this ledger. Prospective bindings require new independent identities and artifacts; UNKNOWN is not silently replaced by the present author as historical formalizer.
