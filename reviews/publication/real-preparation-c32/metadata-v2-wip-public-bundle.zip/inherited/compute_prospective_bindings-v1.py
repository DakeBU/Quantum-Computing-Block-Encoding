"""Invoke unchanged publication binding_digest over a read-only virtual overlay.

The overlay inserts only this author's unreviewed original-source catalog row
and maps a safe relative lesson name to the immutable natural source. It never
stages a file or changes canonical source/catalog/registry contents.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import json
import os
import sys
from pathlib import Path, PurePosixPath

sys.dont_write_bytecode = True
EXPECTED_CHECKER = "f8f6d7232376b5bc19a480b7e0ef549a5fafa8d66017e07482f7e6999962f8ad"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class OverlayPath(os.PathLike):
    """Path protocol sufficient for the unchanged checker, with virtual bytes."""

    def __init__(self, repo: Path, logical_root: Path, overrides: dict[str, bytes], rel: str = ""):
        self.repo = repo
        self.logical_root = logical_root
        self.overrides = overrides
        self.rel = PurePosixPath(rel).as_posix() if rel else ""

    @property
    def logical(self) -> Path:
        return self.logical_root / self.rel

    def __fspath__(self) -> str:
        return str(self.logical)

    def __truediv__(self, child) -> "OverlayPath":
        rel = (PurePosixPath(self.rel) / PurePosixPath(str(child).replace("\\", "/"))).as_posix()
        return OverlayPath(self.repo, self.logical_root, self.overrides, rel)

    def __lt__(self, other: "OverlayPath") -> bool:
        return self.logical < other.logical

    def resolve(self) -> Path:
        return self.logical.resolve()

    def is_file(self) -> bool:
        return self.rel in self.overrides or (self.repo / self.rel).is_file()

    def read_bytes(self) -> bytes:
        return self.overrides[self.rel] if self.rel in self.overrides else (self.repo / self.rel).read_bytes()

    def read_text(self, encoding="utf-8") -> str:
        return self.read_bytes().decode(encoding)

    def relative_to(self, other) -> Path:
        return self.logical.relative_to(Path(os.fspath(other)))

    def rglob(self, pattern: str):
        for actual in (self.repo / self.rel).rglob(pattern):
            yield OverlayPath(self.repo, self.logical_root, self.overrides, actual.relative_to(self.repo).as_posix())


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()
    bundle = Path(__file__).resolve().parent.parent
    lesson = (bundle / "source-only.md").read_bytes()
    source_freeze = (bundle / "source-freeze.json").read_bytes()
    expected_source = "f6224333e40f7eea437dd4658e34f1fb3fb03378bad39e2fa19729ba694a2041"
    assert digest(lesson) == expected_source
    assert digest(source_freeze) == "c89c0e0a916c2575877a96b8bace8765b582971421c3ef65c5f18fff60195e19"
    checker_path = repo / "website/scripts/check_research_publications.py"
    checker_hash = digest(checker_path.read_bytes())
    assert checker_hash == EXPECTED_CHECKER, "checker changed: stop, do not substitute"
    source_catalog_bytes = (repo / "website/research/sources.json").read_bytes()
    registry_bytes = (repo / "website/research/publications.json").read_bytes()
    # Metadata-only parsing; no historical record/review is used as mathematics.
    catalog = json.loads(source_catalog_bytes)
    registry = json.loads(registry_bytes)
    row = {
        "id": "candidate:retrospective-real-preparation-c32",
        "title": "Exact real amplitude trees and local isometry completion",
        "authors": ["Retrospective recovery author real-preparation-author-c32; historical formalizer UNKNOWN"],
        "url": "",
        "year": 2026,
        "status": "candidate-retrospective-original-source-unreviewed",
        "anchor": "Frozen original natural source, source-only.md, SHA256 " + expected_source,
        "scope": "Implementation-informed retrospective three-whole-module mathematical recovery; no historical pre-proof or external-paper fidelity claim.",
        "formal_status": "PROSPECTIVE_ONLY; independent source/decoder/reviewer/native/main/purification gates pending",
        "source_sha256": expected_source,
        "historical_formalizer": "UNKNOWN"
    }
    assert all(old["id"] != row["id"] for old in catalog["sources"]), "candidate already canonical; stop rather than shadow"
    catalog["sources"].append(row)
    virtual_lesson = "docs/publication-c32/source-only.md"
    overrides = {
        virtual_lesson: lesson,
        "website/research/sources.json": json.dumps(catalog, ensure_ascii=False, sort_keys=True).encode("utf-8")
    }
    overlay = OverlayPath(repo, bundle / "bindings-successor" / "logical-overlay-root", overrides)
    spec = importlib.util.spec_from_file_location("exact_publication_binding_checker", checker_path)
    checker = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(checker)

    def raw_manifest():
        rows = []
        for directory in ("QuantumBlockEncoding", "ABEISTests"):
            for path in sorted((repo / directory).rglob("*.lean")):
                data = path.read_bytes()
                rows.append({"path": path.relative_to(repo).as_posix(), "sha256": digest(data), "bytes": len(data), "evidence_role": "raw machine context only; no mathematical inference"})
        return rows

    before = raw_manifest()
    originals = json.loads((bundle / "metadata-stage/prospective-publication-records.json").read_text(encoding="utf-8"))["records"]
    records = []
    replay = []
    for original in originals:
        record = copy.deepcopy(original)
        record["lesson_path"] = virtual_lesson
        record["source_statement"] = virtual_lesson
        record["source_anchor"] = "source-only.md exact subsections bound per root in metadata-stage/per-root-source-quotes.json"
        record["source_id"] = row["id"]
        record["binding_sha256"] = checker.binding_digest(overlay, record)
        again = checker.binding_digest(overlay, record)
        replay.append({"module": record["module"], "equal_replay": again == record["binding_sha256"]})
        record["publication_status"] = "PROSPECTIVE_BINDING_ONLY_NOT_ADMISSIBLE"
        record["decoder_evidence"] = None
        record["reviewer_evidence"] = None
        record["mandatory_blockers"] = [
            "Virtual source row/lesson are private overlay-only, not canonical writes or registration",
            "Historical formalizer UNKNOWN; recovery author is not a historical identity substitute",
            "Independent decoder/reviewer evidence absent and intentionally null",
            "No Lean/native/main/purification gate performed",
            "Actual admission record requires separate authorized staging, identities and independent evidence"
        ]
        # None of the fields changed after binding belong to its fixed binding key tuple.
        assert checker.binding_digest(overlay, record) == record["binding_sha256"]
        records.append(record)
    after = raw_manifest()
    catalog_after = digest((repo / "website/research/sources.json").read_bytes())
    registry_after = digest((repo / "website/research/publications.json").read_bytes())
    assert before == after, "raw context changed during binding; invalidate this attempt"
    assert catalog_after == digest(source_catalog_bytes), "canonical catalog changed during read"
    assert registry_after == digest(registry_bytes), "canonical registry changed during read"
    assert all(item["equal_replay"] for item in replay)
    report = {
        "kind": "Actual unchanged binding_digest called through read-only private overlay; prospective only",
        "authorization": "Parent expanded read-only machine pin/replay to all production/test Lean bytes and source/registry schema snapshots after source freeze",
        "checker_path": "website/scripts/check_research_publications.py",
        "checker_sha256": checker_hash,
        "overlay_path_protocol": ["__fspath__", "__truediv__", "resolve", "is_file", "read_bytes", "read_text", "relative_to", "rglob", "__lt__"],
        "canonical_writes": False,
        "virtual_overrides": [virtual_lesson, "website/research/sources.json (append own unreviewed original-source row only)"],
        "own_virtual_source_row": row,
        "metadata_snapshots": {"source_catalog_sha256": digest(source_catalog_bytes), "source_catalog_schema_version": catalog.get("schema_version"), "registry_sha256": digest(registry_bytes), "registry_schema_version": registry.get("schema_version"), "mathematical_authority": "NONE"},
        "frozen_source_sha256": expected_source,
        "frozen_source_freeze_sha256": digest(source_freeze),
        "raw_ambient_context": before,
        "raw_ambient_count": len(before),
        "unchanged_before_after": before == after,
        "bindings_replayed_equal": replay,
        "records": records,
        "not_performed": ["checker.validate_record full admission", "checker.check", "Git", "network", "Lean", "native", "independent decoder/reviewer", "source agreement", "main admission", "purification"]
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
