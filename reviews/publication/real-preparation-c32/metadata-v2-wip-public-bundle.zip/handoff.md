# C32 natural-v2 versioned metadata handoff

## Objective / frontier node

Prepare the next three-whole-module source/formal review package against natural clarification v2. This worker is an author-side metadata rebaser, not an independent reviewer or formal decoder. Only this additive metadata-v2 directory was written. Parent-reported checkout: HEAD 656a567, contribution Lean 4.33, main still Lean 4.29.1; these are parent reports, not worker Git observations. The actual toolchain/configuration bytes are pinned in current-pins.json.

Direction fingerprint: source-coordinate-and-refuted-frontier-versioned-metadata-rebase.

Expected information gain: remove source-v2 binding and graph-topology drift for the three-module review; not repeat the mathematics or claim native migration progress.

## Mathematical delta / effect on root frontier

Exactly two natural text replacements are accepted and reconstructed mechanically from the old bytes. The original source SHA256 is f6224333e40f7eea437dd4658e34f1fb3fb03378bad39e2fa19729ba694a2041; v2 is 936020bf35582267a8149ed49addd9a9b106c23512205acaf49e9a3febaa6d80. Every A-G subsection, including D/E/F/G, is unchanged. Original root quote contents and all 57 lexical signatures remain unchanged. This is a versioned metadata/source-coordinate clarification, not a new theorem, new pre-proof seal, supplier closure or semantic admission.

H0 specifies B=2^q and h(v,b)=(ell_q^{-1}(b),v), with both matrix axes transported. In metadata notation P(z,x)=delta(z,h(x)), so mathcalU=P^T U P. This P notation expresses the exact natural H0 formula; it is not a third textual source edit. G4 supplies the active numerical clean-column equality mathcalU_t((v,b),(0,a))=K_t((v,b),a), for a<r_t. Coordinate relabeling is not physical SWAP, free routing, a transpose of U, or a phase change. Agreement with an actual implementation adapter is OPEN, as are global placement and its costs.

I moves only the unchanged-empty-phase signed-all-width strengthening from misclassified OPEN to REFUTED. The D1 witness was already present: n=0, singleton f=-1, tree scalar +1, target scalar -1. The nonnegative all-width theorem is not refuted, and positive-width signed extension remains neither proved nor ruled out. No other source gap is removed.

## Named evidence / exact scope

The target raw hashes remain:

| Module | Raw SHA256 |
| --- | --- |
| RealAmplitudePreparation | 3c1c145a5262b85159bcead1997ec87875184ac06dfe4da8a6595ae063e434f7 |
| RealIsometryCompletion | e4f41db2f5e3c35f113fa4d91799316ccdfe305753f736d9f9669cda08346017 |
| ConstructiveIsometryLocal | b5792942a1fecf68991b956668775fb07330f64ddc589867f67abe83644073fe |

The raw formal-context packet is copied byte-identically, SHA256 16aed6ce6806d4423a421683905cead1cd2bb9818665b86594965bcae197694c. It retains complete three targets and the original explicitly bounded provider context. It is not an exhaustive transitive proof-term closure or an elaborated type export.

Source-level observability remains 57=53 public+4 private, 13 definitions+44 theorems. These are lexical counts, not current-kernel declarations or successes. whole-module-inventory.json versions only source links and identifies its derivative status; exact signatures/source slices remain. per-root-source-quotes.json has complete exact subsection quotes/spans for every root and separate H/I context. recursive-binder-audit.json preserves every prior root audit except versioned source links and adds the literal H0 definition audit, no new public binder. source-coverage-v2.json and four-view-graph.json retain exhaustive natural block dispositions, formal expansions and complete conditional AND/OR drilldown.

source-change-topology.json gives exact old/new source line spans, affected source-region identities, exact changed-graph line anchors plus graph hash, graph-field changes and preserved regions. The underlying Lean imports/ownership/structure are unchanged; their natural-source links alone are versioned. Source graph, actual imports/ownership, proposed compressed spine and conditional Functor view remain distinct. OR alternatives are not flattened into a false conjunction; their required AND tails and matched-contract conditions remain explicit.

## Assumptions / conventions / unresolved mappings

All seven slots are retained in semantic-slots-and-reuse.md. Exact phase, named little-endian order, active clean inputs, rank bound, t<n, actual canonicality, spare-dimension condition, noncanonical existence versus definite exact-real producer, zero behavior and resource tier remain distinct.

The Rz natural scope gap remains explicitly OPEN for liftGate/eval_liftGate/eval_liftCircuit: natural A2 names z-rotation but does not give its full scalar/phase formula. The real RY/CX tree is not broadened into an admitted four-language source contract. Its candidate record includes an unresolved author scope delta, not silent equivalence. H0 adapter agreement is OPEN. Function-to-chain extraction, approximation/error analysis, canonicalization, boundary loading, primitive compilation, global assembly, finite-bit zero/sign/angle evaluation, storage/input access/preprocessing, depth/connectivity/discrete synthesis and readout remain OPEN. Supplied-stage certificates remain consumers. No SP/BE transport is promoted without its complete conditional tails.

## Actual prospective bindings / current pins

The unchanged repository checker, SHA256 f8f6d7232376b5bc19a480b7e0ef549a5fafa8d66017e07482f7e6999962f8ad, was loaded with bytecode writing disabled. Only its binding_digest was executed through a read-only path facade. The virtual overlay supplies v2 source bytes and one explicitly unreviewed candidate source row, never a canonical write. Source row, exact record fields, current configs and all 202 raw production/test Lean files are pinned. Raw context was equal before/after; the source catalog and registry schema snapshots were unchanged and have no mathematical authority.

| Module | New actual prospective binding_digest |
| --- | --- |
| RealAmplitudePreparation | d5a8c680149f93d71dfd5280ffec3d45939faa283956f503d18e92552f2ff553 |
| RealIsometryCompletion | b9a4dc823e3efa4e2abe45ba7ea5b0e4758b87719867dfcb40215e9bf654195e |
| ConstructiveIsometryLocal | eee3980dd96c1c037c44da453d0a9693fc114ed70471ab5703d377525b244e41 |

All are unreviewed content-context candidates, not publication admission. Old v1 digests remain historical only and cannot bind v2. binding-bridge.json additionally holds isolated source-byte tests with the same v2 record/row, showing the source bytes alone change every binding. The actual checker binds toolchain and manifest, not lakefile.lean; the latter is separately pinned. It binds the selected source row, not unrelated catalog rows or registry bytes. Other author audit files are independently manifest-bound, not falsely represented as additional checker inputs.

The formalizer field remains UNKNOWN. The parent authored natural v2; this worker authored only the metadata successor. Parent reports the same natural-only review completed, but no review output, verdict or formal reconstruction was read. No independent identity or accepted status is fabricated.

## Python receipts / typed failure / salvage

test_metadata_v2.py executes integrity checks plus the inherited 13 strategies: ten actual unchanged binding-function sensitivity/scope tests and three static interpretations of the actual checker's first required-field guard. It does not call validate_record. Thus the three missing-decoder checks are explicitly static guard evidence, not new validator-run or admission receipts. Nine further actual binding tests isolate all-v1 source bytes, only H0 reverted, and only I reverted for each of the three records while keeping v2 record/row/context fixed.

The first report, test-receipt-attempt-01.json, failed one metadata-test expectation: it demanded the entire Lean-view object be identical although natural-source ownership links had correctly changed to v2. The exact first script is preserved as test_metadata_v2-attempt-01.py. The corrected check allows only that versioned link transformation and still requires exact imports/ownership/structural metadata. This is IMPLEMENTATION_FAILED test expectation, not a mathematical failure, source repair or weakened gate. test-receipt-attempt-02.json records the successful successor run; test-receipt-final-03.json adds an exact changed-graph line-anchor/hash check against the final pre-freeze packet. Failure and passing receipts remain separate. No false success is substituted.

Current package-integrity failure class: NONE once the successful receipt and manifest verification pass. Scientific gates remain incomplete deliberately. The source's signed-strengthening REFUTED node is an already-stated analytic witness, not a new kernel-checked counterexample or independent reviewer claim. No fragment is promoted into verified memory. Process-memory IDs consulted: NONE (bounded authorized read scope).

## Files / preservation / public-safe projection

Only files under this new directory changed. input-immutability.json checks the old sealed package against its existing scoped manifest; original source, freeze, metadata-stage, bindings-successor and clarification-v2 files remain untouched. byte-preservation.json identifies every exact raw snapshot. raw-to-public-lineage.json distinguishes raw and successor derivative paths and both hashes; no derivative is an old raw alias. Original private scripts contain CLI-supplied paths rather than actual host-location literals or credentials, so their public-safe raw snapshots require no redaction and preserve bytes.

public-safe-projection-allowlist.json is explicit deny-by-default text-safety eligibility, not release authorization. Anti-contamination remains separate: natural-source-first receives only the exact v2 natural source and its natural seal; formal-blind decoding receives formal-context.md alone. Author graphs, mappings, receipts and private baseline material never enter those blind stages merely because their text is safe to inspect in a separately authorized public audit. No deployment, publication or canonical registration was performed.

## Parallelism / default route / purification

No sub-agent was spawned or operated. There is no new multi-route common-blind-spot approval or comparator verdict. The reference tree and definite local producer are described at their inherited tier, not newly selected verified defaults. Existence and structured-state alternatives remain visible. Purification and Exposition Seal are NOT PERFORMED; no compiled cleanup or root closure is implied. Source/Lean drilldown, every premise and all remaining boundaries are retained.

sourceAgreement=null; publicationBinding=null; axiomPolicyPass=null; nativeAccepted=false; scientific_ROOT=false; main_admission=false. New native success count: 0. Git/Lean/lake/native/network/install/production/canonical writes: 0. No accepted publication record, PROOF_SEALED, SOURCE_AGREEMENT, MAIN_ADMITTED or PURIFIED label follows.

## Freeze / recommended next independent step

manifest.json enumerates every packet file except itself and freeze.json; freeze.json binds that complete manifest. The freeze root SHA is reported externally to avoid recursive hashing. Later modifications require an additive successor. Replays may use test_metadata_v2.py with --repo and no --receipt, then seal_metadata_v2.py --verify-only; both are read-only in that mode.

STOP after freezing. Parent independently inspect/test this package; original source-first process continues separately, then a distinct formal-blind whole-module decode and anti-anchored seven-slot/root comparison can proceed. Any actual source registration, evidence identity assignment, publication gate or main Lean migration needs separate authorization and exact fresh bindings. Residual risk is mathematical correspondence and the explicitly OPEN source mappings, not hash replay. Confidence is high only in byte/pin/topology-delta integrity after the recorded tests; no semantic acceptance is asserted.
