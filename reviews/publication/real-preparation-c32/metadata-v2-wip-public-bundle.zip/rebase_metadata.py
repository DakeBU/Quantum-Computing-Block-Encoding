"""Deterministic C32 v2 metadata packaging, never proof or publication admission.

Only generated JSON and byte-identical packet snapshots are written, beneath
this script's new directory. Authored prose and code are maintained by patches.
The repository is read-only. Use --repo with a local checkout; no host path is
stored in any artifact. A frozen package refuses regeneration.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import json
import re
import sys
from pathlib import Path, PurePosixPath

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
BUNDLE = HERE.parent
V1 = "f6224333e40f7eea437dd4658e34f1fb3fb03378bad39e2fa19729ba694a2041"
V2 = "936020bf35582267a8149ed49addd9a9b106c23512205acaf49e9a3febaa6d80"
CHECKER = "f8f6d7232376b5bc19a480b7e0ef549a5fafa8d66017e07482f7e6999962f8ad"
LESSON = "docs/publication-c32-v2/source-effective-v2.md"
SOURCE_ID = "candidate:retrospective-real-preparation-c32-v2"
GATES = {"sourceAgreement": None, "publicationBinding": None,
         "axiomPolicyPass": None, "nativeAccepted": False,
         "scientific_ROOT": False, "main_admission": False}
RZ_GAP = "Rz natural scope gap: A2 names z-rotation but does not specify its exact 2x2 entries/phase convention; the all-four-instruction lifting API remains an OPEN source-to-formal mapping beyond the RY/CX tree."
ADAPTER_GAP = "H0 implementation-adapter audit: exact equality between the numerical transported kernel and an actual implementation adapter is OPEN; coordinate relabeling is not physical SWAP/routing."
SIGNED_OLD = "signed all-width contract without base-phase change"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def emit(name: str, obj) -> None:
    path = HERE / name
    assert path.resolve().is_relative_to(HERE)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((json.dumps(obj, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))


def snapshot(source: Path, name: str) -> dict:
    data = source.read_bytes()
    target = HERE / name
    assert target.resolve().is_relative_to(HERE)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    return {"input": source.relative_to(BUNDLE).as_posix(), "output": name,
            "sha256": sha(data), "bytes": len(data), "byte_identical": True}


def span(text: str, quote: str) -> dict:
    assert text.count(quote) == 1
    start = text.index(quote)
    return {"start_line": text.count("\n", 0, start) + 1,
            "end_line": text.count("\n", 0, start + len(quote)) + 1,
            "text_sha256": sha(quote.encode("utf-8"))}


def section(text: str, label: str) -> str:
    match = re.search(r"(?m)^#{2,3} " + re.escape(label) + r"\. .*", text)
    assert match, label
    end = re.search(r"(?m)^#{2,3} ", text[match.end():])
    return text[match.start():match.end() + end.start() if end else len(text)].strip()


def replace_refs(value):
    if isinstance(value, str):
        return value.replace("../source-only.md", "source-effective-v2.md").replace(V1, V2)
    if isinstance(value, list):
        return [replace_refs(x) for x in value]
    if isinstance(value, dict):
        return {k: replace_refs(v) for k, v in value.items()}
    return value


def load_checker(repo: Path):
    path = repo / "website/scripts/check_research_publications.py"
    assert sha(path.read_bytes()) == CHECKER, "checker drift; do not substitute"
    spec = importlib.util.spec_from_file_location("c32_v2_unchanged_checker", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(module)
    return module


class OverlayPath:
    """Read-only path facade for the unchanged checker's exact digest code."""
    def __init__(self, repo: Path, overrides: dict[str, bytes], rel: str = ""):
        self.repo, self.overrides = repo, overrides
        self.rel = PurePosixPath(rel).as_posix() if rel else ""

    @property
    def logical(self):
        return HERE / "logical-overlay-not-created" / self.rel

    def __fspath__(self):
        return str(self.logical)

    def __truediv__(self, child):
        rel = (PurePosixPath(self.rel) / PurePosixPath(str(child).replace("\\", "/"))).as_posix()
        return OverlayPath(self.repo, self.overrides, rel)

    def __lt__(self, other):
        return self.logical < other.logical

    def resolve(self):
        return self.logical.resolve()

    def is_file(self):
        return self.rel in self.overrides or (self.repo / self.rel).is_file()

    def read_bytes(self):
        return self.overrides[self.rel] if self.rel in self.overrides else (self.repo / self.rel).read_bytes()

    def read_text(self, encoding="utf-8"):
        return self.read_bytes().decode(encoding)

    def relative_to(self, other):
        return self.logical.relative_to(Path(other))

    def rglob(self, pattern):
        for actual in (self.repo / self.rel).rglob(pattern):
            yield OverlayPath(self.repo, self.overrides, actual.relative_to(self.repo).as_posix())


def ambient(repo: Path):
    return [{"path": p.relative_to(repo).as_posix(), "sha256": sha(p.read_bytes()),
             "bytes": p.stat().st_size, "role": "raw binding context only, not semantic audit"}
            for directory in ("QuantumBlockEncoding", "ABEISTests")
            for p in sorted((repo / directory).rglob("*.lean"))]


def make_row():
    return {"id": SOURCE_ID, "title": "Exact real amplitude trees and local isometry completion (natural clarification v2)",
            "authors": ["Original retrospective recovery author real-preparation-author-c32; natural v2 clarification author /root; historical formalizer UNKNOWN"],
            "url": "", "year": 2026, "status": "candidate-retrospective-original-source-v2-unreviewed-formal-correspondence",
            "anchor": "source-effective-v2.md SHA256 " + V2,
            "scope": "Implementation-informed retrospective three-whole-module source with H0 coordinates and signed-all-width REFUTED classification; no new proof or preproof seal.",
            "formal_status": "PROSPECTIVE_ONLY; no independent formal decoder/reviewer/native/main/purification evidence in this package",
            "source_sha256": V2, "historical_formalizer": "UNKNOWN",
            "natural_clarification_author": "/root", "predecessor_source_sha256": V1}


def build(repo: Path):
    assert not (HERE / "freeze.json").exists(), "frozen output: create additive successor instead"
    old_source_bytes = (BUNDLE / "source-only.md").read_bytes()
    new_source_bytes = (BUNDLE / "clarification-v2/source-effective-v2.md").read_bytes()
    assert sha(old_source_bytes) == V1 and sha(new_source_bytes) == V2
    old_source, new_source = old_source_bytes.decode(), new_source_bytes.decode()
    # Normalize only for quote/source line analysis. Authoritative snapshot bytes are untouched.
    old_source = old_source.replace("\r\n", "\n")
    new_source = new_source.replace("\r\n", "\n")
    change = read_json(BUNDLE / "clarification-v2/source-change-record.json")
    reconstructed = old_source
    for item in change["exact_replacements"]:
        assert reconstructed.count(item["before"]) == 1
        reconstructed = reconstructed.replace(item["before"], item["after"], 1)
    assert reconstructed == new_source, "not exactly the two authorized replacements"
    old_freeze = read_json(BUNDLE / "source-freeze.json")
    old_scoped = read_json(BUNDLE / "metadata-stage/scoped-bindings.json")
    immutable_inputs = []
    for item in old_scoped["files"]:
        data = (BUNDLE / item["path"]).read_bytes()
        assert sha(data) == item["sha256"], "predecessor sealed file changed: " + item["path"]
        immutable_inputs.append({"path": item["path"], "sha256": sha(data), "bytes": len(data), "matches_predecessor_seal": True})
    for name in ("metadata-stage/scoped-bindings.json", "clarification-v2/source-effective-v2.md", "clarification-v2/source-change-record.json", "clarification-v2/clarification-v2-seal.json"):
        data = (BUNDLE / name).read_bytes()
        immutable_inputs.append({"path": name, "sha256": sha(data), "bytes": len(data), "role": "read-only input"})
    emit("input-immutability.json", {"files": immutable_inputs, "predecessor_files_modified": False,
                                    "claim": "Old sealed bytes checked against existing scoped manifest; v2 inputs pinned. No frozen file overwritten."})
    originals = read_json(BUNDLE / "bindings-successor/binding-attempt-01.json")
    old_graph = read_json(BUNDLE / "metadata-stage/four-view-graph.json")
    old_quotes = read_json(BUNDLE / "metadata-stage/per-root-source-quotes.json")
    old_audit = read_json(BUNDLE / "metadata-stage/recursive-binder-audit.json")
    inventory = read_json(BUNDLE / "metadata-stage/whole-module-inventory.json")
    for item in old_freeze["actual_targets"]:
        assert sha((repo / item["path"]).read_bytes()) == item["sha256"]
    copied = []
    for source, target in [
        ("clarification-v2/source-effective-v2.md", "source-effective-v2.md"),
        ("metadata-stage/formal-context.md", "formal-context.md"),
        ("metadata-stage/whole-module-inventory.json", "inherited/whole-module-inventory-v1.json"),
        ("source-only.md", "inherited/source-only-v1.md"),
        ("source-freeze.json", "inherited/source-freeze-v1.json"),
        ("clarification-v2/source-change-record.json", "inherited/natural-source-change-record-v2.json"),
        ("clarification-v2/clarification-v2-seal.json", "inherited/natural-clarification-v2-seal.json"),
        ("bindings-successor/compute_prospective_bindings.py", "inherited/compute_prospective_bindings-v1.py"),
        ("bindings-successor/test_binding_sensitivity.py", "inherited/test_binding_sensitivity-v1.py"),
        ("bindings-successor/sensitivity-attempt-01.json", "inherited/sensitivity-attempt-v1.json"),
        ("bindings-successor/binding-attempt-01.json", "inherited/binding-attempt-v1.json"),
        ("metadata-stage/recursive-binder-audit.json", "inherited/recursive-binder-audit-v1.json"),
        ("metadata-stage/four-view-graph.json", "inherited/four-view-graph-v1.json"),
        ("metadata-stage/per-root-source-quotes.json", "inherited/per-root-source-quotes-v1.json"),
        ("metadata-stage/semantic-slots-and-reuse.md", "inherited/semantic-slots-and-reuse-v1.md")]:
        copied.append(snapshot(BUNDLE / source, target))
    emit("byte-preservation.json", {"kind": "Byte-identical raw snapshots, not raw aliases for derivatives", "files": copied})
    updated_inventory = replace_refs(copy.deepcopy(inventory))
    updated_inventory["source_version"] = "natural-v2; lexical signatures/source slices unchanged; links are versioned derivatives"
    emit("whole-module-inventory.json", updated_inventory)

    quotes = replace_refs(copy.deepcopy(old_quotes))
    quotes["source_version"] = "natural-v2; retrospective correspondence remains author-proposed"
    for root in quotes["roots"]:
        assert root["quote"] == section(new_source, root["source_section"])
        root["source_span"] = span(new_source, root["quote"])
        root["quote_sha256"] = sha(root["quote"].encode())
        root["source_mapping_status"] = "AUTHOR_PROPOSED_NOT_INDEPENDENTLY_REVIEWED"
        if root["fullName"].split(".")[-1] in ("liftGate", "eval_liftGate", "eval_liftCircuit"):
            root["source_mapping_status"] = "OPEN_RZ_NATURAL_SCOPE_GAP"
            root["remaining_boundary"] = RZ_GAP
    quotes["additional_source_context"] = [
        {"source_section": label, "quote": section(new_source, label),
         "source_span": span(new_source, section(new_source, label)),
         "role": "boundary/coordinate context, not a newly assigned target theorem root"}
        for label in ("H", "I")]
    emit("per-root-source-quotes.json", quotes)

    audit = replace_refs(copy.deepcopy(old_audit))
    audit["source_sha256"] = V2
    audit["metadata_version"] = 2
    audit["statement_seal"] = "Versioned retrospective metadata only, not a new historical pre-proof Statement Seal."
    audit["source_change_effect"] = "All 57 raw target signatures, proof premises and definitions are unchanged; H0 adds a natural coordinate definition, not a new theorem binder. I retires only the unchanged-empty-phase signed-all-width strengthening."
    audit["natural_definition_addendum"] = {
        "id": "source:H0-coordinate-kernel", "kind": "literal coordinate reindexing",
        "typing_data": ["q : Nat", "B=2^q", "ell_q inverse bijection", "a,b : Fin B", "v,w : Fin 2"],
        "h": "h(v,b)=(ell_q^{-1}(b),v)",
        "formula": "mathcalU(x,y)=U(h(x),h(y)); P(z,x)=delta(z,h(x)); mathcalU=P^T U P",
        "formula_provenance": "h/P notation is an explicit metadata expression of the H0 bijection and simultaneous-axis formula; not a verbatim extra natural-source replacement",
        "occupied_column": "a<r_t implies mathcalU_t((v,b),(0,a))=K_t((v,b),a)",
        "proof_inputs_added": [], "choice_or_uniqueness": "No existential witness, choice or representative quotient added",
        "implementation_adapter": "OPEN", "physical_SWAP_or_free_routing": False}
    audit["open_source_mappings"] = [RZ_GAP, ADAPTER_GAP]
    emit("recursive-binder-audit.json", audit)

    graph = replace_refs(copy.deepcopy(old_graph))
    graph["schema"] = "aspbe-candidate-four-view-graph/v2"
    old_by_text = {r["text"]: r for r in old_graph["source_view"]["all_regions"]}
    regions = []
    changed_regions = []
    serial = 0
    for block in new_source.strip().split("\n\n"):
        if block in old_by_text:
            item = copy.deepcopy(old_by_text[block])
            item["predecessor_id"] = item["id"]
        else:
            serial += 1
            item = {"id": f"source-region:v2-changed-{serial:02d}", "text": block,
                    "disposition": "NODE", "review": "author metadata; independent formal comparison pending"}
            changed_regions.append(item["id"])
        item["source_span"] = span(new_source, block)
        regions.append(item)
    graph["source_view"]["all_regions"] = regions
    graph["source_view"]["source_gaps"] = [s for s in graph["source_view"]["source_gaps"] if s != SIGNED_OLD]
    graph["source_view"]["source_gaps"].extend([RZ_GAP, ADAPTER_GAP])
    graph["source_view"]["refuted_frontier"] = [{
        "id": "frontier:signed-all-width-unchanged-empty-phase", "status": "REFUTED",
        "previous_classification": "OPEN source gap (misclassified despite D1 witness)",
        "contract": "same empty n=0 tree, exact phase, arbitrary signed table at all widths",
        "witness": {"n": 0, "singleton_f": -1, "norm_squared": 1, "empty_tree_scalar": 1, "normalized_target_scalar": -1},
        "source_sections": ["D1", "I"], "not_refuted": ["nonnegative positive-norm theorem at every width", "possible positive-width signed extension"],
        "native_or_independent_counterexample_claim": False}]
    graph["source_view"]["coordinate_nodes"] = [audit["natural_definition_addendum"]]
    graph["source_view"]["and_hyperedges"].append({
        "id": "source:H0-numerical-clean-column-transport",
        "tails": ["G4 named occupied clean-column identity", "B=2^q", "ell_q inverse bijection", "H0 simultaneous row-and-column transport", "a<r_t"],
        "heads": ["H0 numerical occupied clean-column identity"],
        "formula": "mathcalU_t((v,b),(0,a))=K_t((v,b),a)",
        "mechanism": "Substitute named words ell_q inverse into G4 and cancel ell_q after inverse; no transpose of U or phase change.",
        "status": "NATURAL_DEFINITION_DERIVATION_AUTHOR_METADATA_ONLY",
        "boundary": ADAPTER_GAP})
    conditional = next(e for e in graph["source_view"]["and_hyperedges"] if e["id"] == "source:conditional-run")
    conditional["tails"].append("H0 consistent numerical coordinate transport for all used stages and boundary")
    conditional["mechanism"] += " G4 columns are first transported by H0; this is not physical placement."
    graph["source_view"]["status_edges"] = [
        {"from": "D1 n=0 signed counterexample", "to": "frontier:signed-all-width-unchanged-empty-phase", "relation": "REFUTES_EXACT_STRENGTHENING"},
        {"from": "source:H0-coordinate-kernel", "to": "H0 actual implementation-adapter agreement", "relation": "REQUIRES_AUDIT", "status": "OPEN"},
        {"from": "H0 actual implementation-adapter agreement", "to": "physical global wire placement", "relation": "DOES_NOT_DISCHARGE", "status": "OPEN"}]
    graph["source_view"]["or_route_and_tail_resolution"] = [
        {"or_id": "source:completion-routes", "rule": "Either alternative independently sufficient at the matched mathematical SO specification, never AND of both alternatives",
         "tail_source": "Each alternative's original explicit tails retained; E/F producer tiers differ"},
        {"or_id": "source:state-routes", "alternative": "full-table tree", "complete_and_tail_ref": "source:tree-action",
         "contract_match": ["same target", "normalization", "register order", "exact phase/error convention"]},
        {"or_id": "source:state-routes", "alternative": "structured chain/sequential", "status": "OPEN",
         "tails": ["chain for the actual target", "supplied initial boundary and its rank support", "local canonicality/rank hypotheses of the chosen supplier", "primitive local circuits matching occupied clean columns", "padded next-rank support", "H0 consistent numerical stage and boundary coordinates", "actual global placement/assembly", "matched normalization and error contract"],
         "tail_evidence": ["G1-G4", "H", "I"], "warning": "Conditional source-route conjunction only; these suppliers are not discharged by this package"}]
    graph["compressed_spine"]["nodes"].append({"id": "concept:typed-local-coordinate-transport", "expands": ["G2", "G3", "H0"], "boundary": ADAPTER_GAP})
    graph["compressed_spine"]["refuted_frontier"] = ["frontier:signed-all-width-unchanged-empty-phase"]
    graph["functor_view"]["hyperedges"].append({
        "id": "transport:named-local-to-numerical-stage",
        "tails": ["named U_t from G4", "explicit ell_q bijection", "simultaneous row/column h transport", "active input a<r_t"],
        "heads": ["numerical clean-column action mathcalU_t((v,b),(0,a))=K_t((v,b),a)"],
        "formula": audit["natural_definition_addendum"]["formula"],
        "hypothesis_map": "All tails conjunctive; no supplier action or physical routing assumed free",
        "conclusion_map": "Named output/input indices mapped by h on both axes; phases retained exactly",
        "failure": "Unknown actual implementation adapter remains OPEN; no physical global circuit follows",
        "candidate_lean_substrates": ["ConstructiveIsometryLocal.completeStage_spec", "TensorTrainLocalCompiler.localIndex_snoc", "SequentialBondPreparation.step_apply"],
        "independent_review": "pending formal comparison", "status": "NATURAL_TRANSPORT_ONLY"})
    graph["contribution"]["successor"] = {"parent_reported_head": "656a567 (not verified by this worker)", "source_version": 2,
                                               "delta": "H0 coordinate topology + signed REFUTED status, no Lean delta"}
    emit("four-view-graph.json", graph)
    emit("source-coverage-v2.json", {
        "source_sha256": V2, "method": "Every maximal blank-line-delimited natural block is NODE or EXCLUDED with reason; retained source graph is author-proposed, not independently approved here",
        "regions": [{k: r[k] for k in ("id", "disposition", "source_span")} for r in regions],
        "source_level_inventory": {"declarations": 57, "public": 53, "private": 4, "definitions": 13, "theorems": 44, "not_current_kernel_types": True},
        "formal_root_coverage": [{"fullName": r["fullName"], "source_section": r["source_section"], "source_span": r["source_span"], "status": r["source_mapping_status"]} for r in quotes["roots"]],
        "open_scope": [RZ_GAP, ADAPTER_GAP], "native_calls": 0, **GATES})
    source_changes = []
    for item in change["exact_replacements"]:
        source_changes.append({"id": item["id"], "old": span(old_source, item["before"]),
                               "new": span(new_source, item["after"]), "before": item["before"], "after": item["after"]})
    graph_text = (HERE / "four-view-graph.json").read_text(encoding="utf-8")
    graph_anchors = []
    for identity in changed_regions + ["source:conditional-run", "source:H0-numerical-clean-column-transport", "frontier:signed-all-width-unchanged-empty-phase", "source:H0-coordinate-kernel", "concept:typed-local-coordinate-transport", "transport:named-local-to-numerical-stage"]:
        anchor = '"id": "' + identity + '"'
        assert graph_text.count(anchor) == 1
        graph_anchors.append({"file": "four-view-graph.json", "id": identity,
                              "anchor": anchor, "line": graph_text.count("\n", 0, graph_text.index(anchor)) + 1})
    emit("source-change-topology.json", {
        "source_v1_sha256": V1, "source_v2_sha256": V2, "only_natural_replacements": source_changes,
        "unchanged_sections": [{"id": label, "exact_equal": section(old_source, label) == section(new_source, label),
                                  "v1": span(old_source, section(old_source, label)), "v2": span(new_source, section(new_source, label))}
                                 for label in ("A1", "A2", "B1", "B2", "C1", "C2", "C3", "D1", "D2", "D3", "D4", "E1", "E2", "E3", "F1", "F2", "G1", "G2", "G3")],
        "retired_region_ids": [r["id"] for r in old_graph["source_view"]["all_regions"] if r["text"] not in new_source],
        "changed_v2_region_ids": changed_regions,
        "graph_sha256": sha((HERE / "four-view-graph.json").read_bytes()), "graph_line_anchors": graph_anchors,
        "graph_mutations": [
            {"pointer": "/source_view/and_hyperedges/source:conditional-run/tails", "change": "Append H0 coordinate-consistency tail; original four tails intact"},
            {"pointer": "/source_view/and_hyperedges/source:H0-numerical-clean-column-transport", "change": "New complete AND transport edge, not physical implementation"},
            {"pointer": "/source_view/source_gaps", "change": "Remove only signed-all-width misclassified OPEN; preserve all other gaps; explicitly retain Rz and H0 adapter OPEN"},
            {"pointer": "/source_view/refuted_frontier", "change": "Add exact zero-width signed-strengthening REFUTED witness/status edge"},
            {"pointer": "/compressed_spine", "change": "Add H0 drilldown and named refuted frontier; no purification claim"},
            {"pointer": "/functor_view/hyperedges/transport:named-local-to-numerical-stage", "change": "Append conditional coordinate transport with complete AND tails"},
            {"pointer": "/lean_view", "change": "Imports, ownership identities and all structural metadata unchanged; ownership natural_source links versioned v1 to v2 only"},
            {"pointer": "/source_view/or_routes", "change": "NONE; preserve both full OR records"},
            {"pointer": "/source_view/or_route_and_tail_resolution", "change": "Explicit drilldown to existing full-tree AND tails and still-OPEN structured-route suppliers including H0; no new sufficient route"}],
        "root_quote_content_changes": [], "all_57_root_subsections_unchanged": True,
        "signature_and_premise_changes": [], "additional_scope_annotations": [RZ_GAP, ADAPTER_GAP],
        "annotation_provenance": "These OPEN scope annotations expose existing boundaries; they are not additional natural-source edits.", **GATES})

    checker = load_checker(repo)
    catalog_bytes = (repo / "website/research/sources.json").read_bytes()
    registry_bytes = (repo / "website/research/publications.json").read_bytes()
    catalog, registry = json.loads(catalog_bytes), json.loads(registry_bytes)
    row = make_row()
    assert all(x["id"] != SOURCE_ID for x in catalog["sources"])
    catalog["sources"].append(row)
    overrides = {LESSON: new_source_bytes,
                 "website/research/sources.json": json.dumps(catalog, ensure_ascii=False, sort_keys=True).encode()}
    overlay = OverlayPath(repo, overrides)
    before = ambient(repo)
    assert len(before) == 202, "ambient count drift: request a fresh authorized scope"
    records = []
    bridges = []
    for old in originals["records"]:
        record = replace_refs(copy.deepcopy(old))
        record.update(source_id=SOURCE_ID, lesson_path=LESSON, source_statement=LESSON,
                      source_anchor="natural-v2 exact root quotes: metadata-v2/per-root-source-quotes.json; H0/I boundary: metadata-v2/source-change-topology.json",
                      source_version=2, natural_clarification_author="/root",
                      metadata_rebase_author="real_preparation_metadata_v2_c32",
                      predecessor_binding_sha256=old["binding_sha256"], historical_formalizer="UNKNOWN", formalizer="UNKNOWN")
        for obligation in record["obligation_map"]:
            obligation["source_obligation"] = obligation["source_obligation"].replace("source-effective-v2.md", LESSON)
        record["graph_contribution"]["remaining_boundary"] += " H0 adapter/physical placement remain OPEN; signed-all-width unchanged-empty-phase strengthening is REFUTED, not a supplier. Rz natural scope gap retained."
        record["residual_boundary"] += " Source v2 natural-only review was reported completed by parent; no review artifact read or formal-equivalence result inferred."
        if record["module"].endswith("RealAmplitudePreparation.lean"):
            record["assumption_deltas"].append({"classification": "unresolved", "source": "A2 names z-rotation without a complete natural scalar/phase definition",
                                                "formal": "liftGate/eval_liftGate/eval_liftCircuit include .rz and the exact imported standardRzMatrix semantics",
                                                "explanation": RZ_GAP})
        record["decoder_evidence"], record["reviewer_evidence"] = None, None
        record["mandatory_blockers"] = ["Private virtual source/lesson only, not canonical registration", "Historical formalizer UNKNOWN", "Independent whole-module decoder and anti-anchored reviewer missing", "No new native, axiom, main or Exposition Seal evidence", RZ_GAP, ADAPTER_GAP]
        record["publication_status"] = "PROSPECTIVE_V2_BINDING_ONLY_NOT_ADMISSIBLE"
        record.update(GATES)
        record["binding_sha256"] = checker.binding_digest(overlay, record)
        assert checker.binding_digest(overlay, record) == record["binding_sha256"]
        # Isolate source bytes alone: same v2 record + row, only lesson bytes differ.
        v1_overlay = dict(overrides)
        v1_overlay[LESSON] = old_source_bytes
        source_only_v1_digest = checker.binding_digest(OverlayPath(repo, v1_overlay), record)
        assert source_only_v1_digest != record["binding_sha256"]
        bridges.append({"module": record["module"], "v1_historical_binding": old["binding_sha256"],
                        "v2_binding": record["binding_sha256"], "same_v2_record_and_row_with_v1_lesson_only": source_only_v1_digest,
                        "source_bytes_alone_invalidate_binding": True, "old_binding_reusable": False})
        records.append(record)
    after = ambient(repo)
    assert before == after
    assert sha((repo / "website/research/sources.json").read_bytes()) == sha(catalog_bytes)
    assert sha((repo / "website/research/publications.json").read_bytes()) == sha(registry_bytes)
    configs = [{"path": name, "sha256": sha((repo / name).read_bytes()), "bytes": (repo / name).stat().st_size,
                "actual_checker_bound": name in ("lean-toolchain", "lake-manifest.json")}
               for name in ("lean-toolchain", "lakefile.lean", "lake-manifest.json")]
    manifest = json.loads((repo / "lake-manifest.json").read_bytes())
    emit("current-pins.json", {"checker": {"path": "website/scripts/check_research_publications.py", "sha256": CHECKER},
                               "configs": configs, "dependency_pins": [{"name": x["name"], "rev": x.get("rev"), "inputRev": x.get("inputRev")} for x in manifest["packages"]],
                               "raw_ambient_context": before, "raw_ambient_count": len(before), "unchanged_before_after": True,
                               "source_catalog": {"sha256": sha(catalog_bytes), "schema_version": catalog.get("schema_version")},
                               "registry": {"sha256": sha(registry_bytes), "schema_version": registry.get("schema_version"), "role": "schema snapshot only; no verdict consulted"},
                               "original_pins_comparison": [{"path": x["path"], "old_sha256": x["sha256"], "current_sha256": sha((repo / x["path"]).read_bytes()), "same": sha((repo / x["path"]).read_bytes()) == x["sha256"]} for x in old_freeze["actual_config"] + old_freeze["provider_hashes"]],
                               **GATES})
    emit("prospective-publication-records.json", {"schema_version": 1, "kind": "Versioned v2 unreviewed whole-module candidates, intentionally inadmissible", "records": records, **GATES})
    emit("binding-bridge.json", {"kind": "Unchanged actual binding_digest over read-only virtual overlay, not validate_record/admission",
                                "checker_sha256": CHECKER, "own_virtual_source_row": row,
                                "virtual_lesson_path": LESSON, "virtual_lesson_sha256": V2,
                                "virtual_source_catalog_sha256": sha(overrides["website/research/sources.json"]),
                                "binding_scope": "fixed record keys; target+lesson+toolchain+manifest; all 202 production/test Lean raw bytes; selected virtual source row",
                                "not_bound_by_checker": ["lakefile.lean", "whole source catalog unrelated rows", "registry bytes", "author metadata files unless named in bound record"],
                                "bridges": bridges, "canonical_writes": False, "binding_replayed_equal": True,
                                "no_review_authority_from_digest": True, **GATES})
    emit("source-seal-v2.json", {"schema": "c32-versioned-retrospective-source-seal/v2", "source": {"path": "source-effective-v2.md", "sha256": V2},
                                 "predecessor": {"source_sha256": V1, "freeze_sha256": sha((BUNDLE / "source-freeze.json").read_bytes())},
                                 "natural_v2_author": "/root", "historical_formalizer": "UNKNOWN", "source_kind": "implementation-informed retrospective",
                                 "natural_only_review": "Parent reports same natural-only review completed; this worker read no reviewer artifacts and assigns no accepted status",
                                 "preproof_seal": False, "formal_decoder_packet": "formal-context.md (separate role only)", **GATES})
    emit("formal-context-seal.json", {"packet": "formal-context.md", "sha256": sha((HERE / "formal-context.md").read_bytes()),
                                      "byte_identical_to_v1": True, "target_raw_hashes": old_freeze["actual_targets"],
                                      "meaning": "Unchanged whole targets and prior bounded providers; not native replay, exhaustive transitive closure, or sourceAgreement", **GATES})
    print(json.dumps({"kind": "metadata generation completed, not frozen", "records": [{"module": r["module"], "binding_sha256": r["binding_sha256"]} for r in records], "ambient": len(before), "canonical_writes": False}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    build(parser.parse_args().repo.resolve())
