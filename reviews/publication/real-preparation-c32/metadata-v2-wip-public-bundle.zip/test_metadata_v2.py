"""Actual binding sensitivity and integrity tests. No admission or compiler run.

The inherited 13-test strategy is retained as ten real binding-scope tests and
three static checks of the actual checker's first missing-evidence guard.
validate_record is NEVER called. Nine additional source-isolation tests revert
v1, H0, or I bytes while holding v2 record/source-row metadata fixed.
"""
from __future__ import annotations

import argparse
import ast
import copy
import json
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from rebase_metadata import (HERE, BUNDLE, V1, V2, CHECKER, LESSON, GATES, RZ_GAP,
                             ADAPTER_GAP, OverlayPath, sha, read_json, emit,
                             ambient, load_checker, replace_refs, section, span)


def test(repo: Path, receipt: str | None):
    checker = load_checker(repo)
    records = read_json(HERE / "prospective-publication-records.json")["records"]
    bridge = read_json(HERE / "binding-bridge.json")
    pins = read_json(HERE / "current-pins.json")
    graph = read_json(HERE / "four-view-graph.json")
    old_graph = read_json(HERE / "inherited/four-view-graph-v1.json")
    quotes = read_json(HERE / "per-root-source-quotes.json")
    audit = read_json(HERE / "recursive-binder-audit.json")
    inventory = read_json(HERE / "whole-module-inventory.json")
    topology = read_json(HERE / "source-change-topology.json")
    source_bytes = (HERE / "source-effective-v2.md").read_bytes()
    old_bytes = (HERE / "inherited/source-only-v1.md").read_bytes()
    source = source_bytes.decode().replace("\r\n", "\n")
    old_source = old_bytes.decode().replace("\r\n", "\n")
    baseline_ambient = ambient(repo)
    checks, strategies, source_tests = [], [], []

    def check(name: str, ok: bool, **details):
        checks.append({"name": name, "ok": bool(ok), **details})

    check("exact raw v1 and v2 source hashes", sha(old_bytes) == V1 and sha(source_bytes) == V2)
    reconstructed = old_source
    for c in topology["only_natural_replacements"]:
        check(c["id"] + " exact v1/v2 spans", span(old_source, c["before"]) == c["old"] and span(source, c["after"]) == c["new"])
        reconstructed = reconstructed.replace(c["before"], c["after"], 1)
    check("only two authorized natural replacements", reconstructed == source and len(topology["only_natural_replacements"]) == 2)
    graph_text = (HERE / "four-view-graph.json").read_text(encoding="utf-8")
    check("exact changed graph line anchors and graph hash", sha((HERE / "four-view-graph.json").read_bytes()) == topology["graph_sha256"] and all(graph_text.splitlines()[r["line"] - 1].strip().rstrip(",") == r["anchor"] for r in topology["graph_line_anchors"]))
    check("all A-G subsections byte-text equal", all(s["exact_equal"] for s in topology["unchanged_sections"]))
    preserved = read_json(HERE / "byte-preservation.json")["files"]
    for row in preserved:
        check(row["output"] + " copied exact raw bytes", sha((HERE / row["output"]).read_bytes()) == row["sha256"] == sha((BUNDLE / row["input"]).read_bytes()))
    raw_freeze = read_json(HERE / "inherited/source-freeze-v1.json")
    for row in raw_freeze["actual_targets"]:
        check(row["path"] + " unchanged target raw hash", sha((repo / row["path"]).read_bytes()) == row["sha256"])
    formal = (HERE / "formal-context.md").read_text(encoding="utf-8")
    check("all whole target text retained in formal packet", all((repo / m["path"]).read_text(encoding="utf-8") in formal for m in inventory["modules"]))
    lexical = [d for m in inventory["modules"] for d in m["declarations"]]
    check("57=53 public+4 private, 13 defs+44 theorems (source level only)", len(lexical) == 57 and sum(d["modifier"] == "private" for d in lexical) == 4 and sum(d["kind"] == "def" for d in lexical) == 13 and sum(d["kind"] == "theorem" for d in lexical) == 44)
    check("all 57 quotes exact and source spans current", len(quotes["roots"]) == 57 and {r["fullName"] for r in quotes["roots"]} == {d["fullName"] for d in lexical} and all(r["quote"] == section(source, r["source_section"]) and r["source_span"] == span(source, r["quote"]) for r in quotes["roots"]))
    old_audit = read_json(HERE / "inherited/recursive-binder-audit-v1.json")
    check("all 57 binder/signature records unchanged except source path", audit["roots"] == replace_refs(old_audit["roots"]))
    check("recursive provider expansion and definition boundary preserved", audit["recursive_provider_expansion"] == old_audit["recursive_provider_expansion"] and audit["definition_choice_boundary"] == old_audit["definition_choice_boundary"])
    old_inventory = read_json(HERE / "inherited/whole-module-inventory-v1.json")
    check("whole-module source/signature inventory unchanged except links", inventory["modules"] == replace_refs(old_inventory["modules"]))
    check("Rz mapping exactly OPEN on lifting roots", {r["fullName"].split(".")[-1] for r in quotes["roots"] if r["source_mapping_status"] == "OPEN_RZ_NATURAL_SCOPE_GAP"} == {"liftGate", "eval_liftGate", "eval_liftCircuit"})
    check("all v2 source blocks fully covered", [r["text"] for r in graph["source_view"]["all_regions"]] == source.strip().split("\n\n") and all(r["source_span"] == span(source, r["text"]) and (r["disposition"] == "NODE" or r["disposition"].startswith("EXCLUDED(")) for r in graph["source_view"]["all_regions"]))
    check("actual Lean graph unchanged except natural-source link version", graph["lean_view"] == replace_refs(old_graph["lean_view"]))
    check("both original complete OR routes preserved", graph["source_view"]["or_routes"] == old_graph["source_view"]["or_routes"])
    check("OR alternatives retain complete AND drilldown and structured OPEN", graph["source_view"]["or_route_and_tail_resolution"][1]["complete_and_tail_ref"] == "source:tree-action" and graph["source_view"]["or_route_and_tail_resolution"][2]["status"] == "OPEN" and len(graph["source_view"]["or_route_and_tail_resolution"][2]["tails"]) == 8)
    new_edges = {x["id"]: x for x in graph["source_view"]["and_hyperedges"]}
    for edge in old_graph["source_view"]["and_hyperedges"]:
        if edge["id"] == "source:conditional-run":
            check("conditional run keeps all original AND tails", new_edges[edge["id"]]["tails"][:-1] == edge["tails"] and new_edges[edge["id"]]["heads"] == edge["heads"])
        else:
            check(edge["id"] + " exact unchanged AND edge", new_edges[edge["id"]] == edge)
    gaps = graph["source_view"]["source_gaps"]
    check("other source gaps preserved and Rz/H0 OPEN", all(x in gaps for x in old_graph["source_view"]["source_gaps"] if x != "signed all-width contract without base-phase change") and RZ_GAP in gaps and ADAPTER_GAP in gaps)
    refuted = graph["source_view"]["refuted_frontier"]
    check("signed-all-width only REFUTED, nonnegative and positive-width boundaries retained", len(refuted) == 1 and refuted[0]["status"] == "REFUTED" and refuted[0]["witness"] == {"n": 0, "singleton_f": -1, "norm_squared": 1, "empty_tree_scalar": 1, "normalized_target_scalar": -1} and len(refuted[0]["not_refuted"]) == 2)
    check("old Functor edges and complete tails retained", graph["functor_view"]["hyperedges"][:-1] == old_graph["functor_view"]["hyperedges"])
    check("13 source lexical definitions are not claimed as elaborated", read_json(HERE / "source-coverage-v2.json")["source_level_inventory"]["not_current_kernel_types"] is True)
    check("202 current raw ambient pins exactly match", baseline_ambient == pins["raw_ambient_context"] and len(baseline_ambient) == 202)
    for row in pins["configs"]:
        check(row["path"] + " current config pinned", sha((repo / row["path"]).read_bytes()) == row["sha256"])
    for name, entry in (("website/research/sources.json", pins["source_catalog"]), ("website/research/publications.json", pins["registry"])):
        check(name + " current schema snapshot hash", sha((repo / name).read_bytes()) == entry["sha256"])
    check("source and formal packet seals exact", read_json(HERE / "source-seal-v2.json")["source"]["sha256"] == sha(source_bytes) and read_json(HERE / "formal-context-seal.json")["sha256"] == sha((HERE / "formal-context.md").read_bytes()))
    check("all semantic/native/publication/ROOT gates false or null", all(all(r[k] == v for k, v in GATES.items()) and r["decoder_evidence"] is None and r["reviewer_evidence"] is None for r in records))
    check("three candidate whole-public sets and complete obligations", all(set(r["declarations"]) == {d["fullName"] for m in inventory["modules"] if m["path"] == r["module"] for d in m["declarations"] if d["modifier"] != "private"} == {n for o in r["obligation_map"] for n in o["declarations"]} for r in records))
    catalog = json.loads((repo / "website/research/sources.json").read_bytes())
    catalog["sources"].append(bridge["own_virtual_source_row"])
    overrides = {LESSON: source_bytes, "website/research/sources.json": json.dumps(catalog, ensure_ascii=False, sort_keys=True).encode()}
    root = lambda values: OverlayPath(repo, values)
    base = records[0]
    baseline = checker.binding_digest(root(overrides), base)
    check("baseline actual digest equals sealed candidate", baseline == base["binding_sha256"])

    def mutation(name, key=None, data=None, field=None, expected="different"):
        values, record = copy.deepcopy(overrides), copy.deepcopy(base)
        if key is not None:
            values[key] = data if data is not None else (repo / key).read_bytes() + b"\n-- in-memory sensitivity mutation\n"
        if field:
            record[field] += " [in-memory sensitivity mutation]"
        result = checker.binding_digest(root(values), record)
        strategies.append({"name": name, "evidence": "actual unchanged binding_digest", "expected": expected, "baseline_sha256": baseline, "mutated_sha256": result, "ok": (result != baseline) if expected == "different" else (result == baseline)})

    mutation("lesson byte mutation", LESSON, source_bytes + b"\nIn-memory negative byte.\n")
    target = base["module"]
    data = (repo / target).read_bytes()
    assert b"private theorem xBasis_lift" in data
    mutation("target private helper lexical mutation", target, data.replace(b"private theorem xBasis_lift", b"private theorem xBasis_lift_virtual_mutation", 1))
    mutation("target import byte mutation", target, data.replace(b"import QuantumBlockEncoding.PrimitiveBasisLE", b"import  QuantumBlockEncoding.PrimitiveBasisLE", 1))
    mutation("ambient production byte mutation", next(x["path"] for x in baseline_ambient if x["path"].startswith("QuantumBlockEncoding/") and x["path"] != target))
    mutation("ambient ABEISTests byte mutation", next(x["path"] for x in baseline_ambient if x["path"].startswith("ABEISTests/")))
    mutation("manifest byte mutation", "lake-manifest.json")
    mutation("toolchain byte mutation", "lean-toolchain")
    mutation("bound author metadata mutation", field="formalizer")
    changed_catalog = copy.deepcopy(catalog)
    changed_catalog["sources"][-1]["title"] += " [in-memory mutation]"
    mutation("selected virtual source-row metadata mutation", "website/research/sources.json", json.dumps(changed_catalog, ensure_ascii=False, sort_keys=True).encode())
    unrelated = copy.deepcopy(catalog)
    unrelated["sources"][0]["title"] += " [unrelated in-memory mutation]"
    mutation("unrelated source row not binding authority", "website/research/sources.json", json.dumps(unrelated, ensure_ascii=False, sort_keys=True).encode(), expected="same")
    # Read the actual validator AST, never run it, even on a negative case.
    checker_tree = ast.parse((repo / "website/scripts/check_research_publications.py").read_text(encoding="utf-8"))
    validator = next(x for x in checker_tree.body if isinstance(x, ast.FunctionDef) and x.name == "validate_record")
    required = ast.literal_eval(validator.body[0].value)
    guard = validator.body[1]
    actual_guard_shape = (isinstance(guard, ast.For) and "record[key] in (None, '')" in ast.unparse(guard) and "publication lacks" in ast.unparse(guard) and "binding_digest" not in ast.unparse(guard))
    check("actual required-field guard occurs before binding/admission", actual_guard_shape and "decoder_evidence" in required and "reviewer_evidence" in required)
    for record in records:
        missing = next((key for key in required if key not in record or record[key] in (None, "")), None)
        strategies.append({"name": record["module"] + " remains inadmissible without decoder", "evidence": "static interpretation of unchanged actual checker first required-field guard; validate_record not called", "expected": "publication lacks decoder_evidence", "actual_first_missing": missing, "ok": actual_guard_shape and missing == "decoder_evidence"})
    assert len(strategies) == 13
    for record in records:
        fresh = checker.binding_digest(root(overrides), record)
        check(record["module"] + " actual exact binding replay", fresh == record["binding_sha256"])
        variants = [("entire v1 source bytes", old_bytes)]
        for c in topology["only_natural_replacements"]:
            reverted = source.replace(c["after"], c["before"], 1).encode()
            variants.append(("revert only " + c["id"], reverted))
        for label, altered_source in variants:
            changed = dict(overrides)
            changed[LESSON] = altered_source
            mutated = checker.binding_digest(root(changed), record)
            source_tests.append({"name": record["module"] + ": " + label,
                                 "fixed": "same v2 record, source row, virtual lesson path, and current machine context",
                                 "baseline_sha256": fresh, "mutated_sha256": mutated,
                                 "mutated_lesson_sha256": sha(altered_source), "ok": fresh != mutated})
    check("all frozen originals and repository ambient unchanged after tests", all(sha((BUNDLE / r["input"]).read_bytes()) == r["sha256"] for r in preserved) and ambient(repo) == baseline_ambient)
    check("canonical source/registry snapshots unchanged after tests", sha((repo / "website/research/sources.json").read_bytes()) == pins["source_catalog"]["sha256"] and sha((repo / "website/research/publications.json").read_bytes()) == pins["registry"]["sha256"])
    # Scan parsed strings rather than JSON escapes: LaTeX e:\{ is not a host path.
    def strings(value):
        if isinstance(value, str):
            yield value
        elif isinstance(value, list):
            for x in value:
                yield from strings(x)
        elif isinstance(value, dict):
            for k, v in value.items():
                yield str(k)
                yield from strings(v)
    unsafe = re.compile(r"(?i)(?:[A-Z]:[\\/](?:Users|Documents|Windows|Program[ ]Files)[\\/]|/(?:home|Users|mnt)/[^\s]+|Bearer[ ]+[A-Za-z0-9_-]{16,}|sk-[A-Za-z0-9]{20,})")
    leaks = []
    for p in HERE.rglob("*"):
        if p.is_file() and p.suffix in (".json", ".md", ".py"):
            text = p.read_text(encoding="utf-8")
            values = strings(json.loads(text)) if p.suffix == ".json" else [text]
            if any(unsafe.search(v) for v in values):
                leaks.append(p.relative_to(HERE).as_posix())
    check("no actual host absolute path or credential pattern in projection", not leaks, affected_files=leaks)
    # Shape sensitivity does not establish independent semantics or honestly-run review.
    report = {"kind": "Actual Python integrity/binding sensitivity receipt, not mathematical/native/publication acceptance",
              "checker_sha256": CHECKER, "test_script_sha256": sha(Path(__file__).read_bytes()), "checks": checks, "inherited_13_strategies": strategies,
              "v1_v2_and_two_isolated_change_tests": source_tests,
              "strategy_accounting": {"actual_binding_strategies": 10, "static_actual_checker_missing_evidence_guards": 3,
                                       "additional_source_isolation_tests": 9, "validate_record_calls": 0},
              "all_pass": all(r["ok"] for r in checks + strategies + source_tests),
              "canonical_writes": False, "repository_writes": False, "native_calls": 0,
              "not_performed": ["validate_record", "check", "Git", "Lean", "lake", "native", "network", "independent review", "source agreement", "publication admission", "main admission", "purification"],
              **GATES}
    if receipt:
        assert not (HERE / receipt).exists(), "receipt immutable; use successor attempt name"
        emit(receipt, report)
    print(json.dumps({"all_pass": report["all_pass"], "integrity_checks": len(checks), "inherited_strategies": len(strategies), "source_isolation_tests": len(source_tests),
                      "failures": [x for x in checks + strategies + source_tests if not x["ok"]], "validate_record_calls": 0}, ensure_ascii=False, indent=2))
    if not report["all_pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--receipt", help="new bundle-relative JSON receipt; omit for read-only replay")
    args = parser.parse_args()
    test(args.repo.resolve(), args.receipt)
