# Phase2 source/formal topology reconciliation

Identity `/root/sp_foundations_source_first_c41`. This file compares the already sealed natural topology to released code only. It is not an author-graph audit, distinct topology approval or an elaborated proof-term dependency export.

## Complete AND tails kept intact

Finite concrete certificates require literal target/matrix data AND standard matrix unitarity AND target's physical norm proof AND exact first-column action. Target01 and target02 package exactly these producers. X/H generic Verified wrappers additionally carry arbitrary display/schedule/resource records; those fields do NOT supply an implication from the display circuit to that matrix or cost. The independent natural gap node for generic display refinement remains intentionally open/out-of-scope.

Primitive unitary evaluation requires gate unitarity AND finite-product closure AND LE reindex preservation. target03 evalPrimitiveCircuitLE_unitary directly invokes evalPrimitiveCircuit_unitary and reindex_unitary. Provider09 supplies unitary primitive cases through permutation/lift/RZ/RY facts and chronological products; provider07 supplies reindex preservation. No target-normalization Prop is needed for this particular unitary theorem.

The UCRY entry bridge requires typed exact angle table AND every control distinct from target AND named-bit equivalence AND split/lift context semantics AND the compiled block-matrix theorem. Provider11's whole recursive proof produces the block theorem; target03 transports it through LE reindex and controlledRyBlockMatrix_apply. Injectivity is absent both naturally and formally. No one prerequisite is represented as sufficient alone.

Factorized operator=U_P requires exact angle35 matrix AND low/high singleton lift formulas in the actual LE basis AND chronological append order AND all entries of LK=U_P. target03's body includes both local matrices and their all-entry lowEval/highEval proofs. Neither physical norm nor a distribution table proves this operator equation by itself.

Factorized preparation requires that operator equality AND B03's exact U_P first-column equation. Tree preparation additionally uses the full tree=factorized operator equality. Each Route record separately consumes the physical B03 normalization producer and the corresponding exact action producer; these are internal supplied proof dependencies, not new public fixed-target assumptions.

Literal costs require exact unsimplified instruction lists AND primitive counters AND touched-wire greedy depths AND zero oracle/aux fields. The comparison needs BOTH fixed-target route/action records AND BOTH literal cost results AND strict comparator2<5. The actual betterThan proof uses Or.inl, not an unexplained Pareto or global optimality relation.

## OR routes preserved without false AND

Natural B03 explicitly permits either tensor norm multiplicativity or direct squared-coordinate summation. The target uses direct finite summation. Natural unitary proof permits either R tensor R composition or direct column multiplication. The target uses finite Gram entries. This is a selected permitted proof route, not failure to satisfy a conjunctive tensor-and-columns obligation. The tensor identities remain valid explanatory mathematics but are not separate new parametric declarations in the targets.

Tree and factorized are alternative exact preparations of the same fixed product target. Either complete route suffices for preparation; the resource comparison needs both. The tree action proof happens to reuse factorized action after operator equality, so the Lean implementation dependency is not two independent full proofs. Retaining two construction OR nodes does not assert two independent proof implementations.

X and H prepare different one-wire states; Bell/dense/product/sparse are different fixed targets. They are collections of examples, not OR alternatives to one common target. The arithmetic f example is separate and supplies no quantum preparation edge. Angle513 is a retained, valid unconsumed branch, not a required AND leaf for product preparation. RZ is generic primitive support, not a claimed consumer in either fixed route.

## Actual versus explanatory proof topology

T X naturally and formally uses swap involution. H uses real symmetry and H squared. Bell natural text describes orthogonal supports/cancellations and symmetry; actual proof rewrites its adjoint and computes Bell squared. Dense natural text explains quaternion signed cancellations; actual proof exhausts the fixed matrix's Gram entries. Sparse natural text uses three supported columns plus complementary rows; actual proof exhausts the fixed eight-by-eight Gram matrix. These differences change implementation bookkeeping, not the pinned finite claims; the retrospective natural text is not a historical transcript claim.

The natural UCRY recursive topology is faithfully realized by provider11's split/halfAdd/halfSub lists and context-block proof, with extra implementation adapters for Kronecker=blockDiagonal and conditional-X blocks. No alternate control convention, swapped target/control, or phase-dropping bridge was found. The product local L/K matrices and all-column equality realize the natural context/lift and composition steps exactly.

## Graph and root-closure boundaries

Every substantive phase1 source region has a phase2 formal/context disposition in `semantic-comparison.md`. All103 explicit target declarations, including private5 and structure fields, have ledger entries. This establishes this reviewer's bounded coverage, not a distinct approval of its own source extraction or a compiler proof of all graph edges.

The natural SOURCE_GAP boundaries remain: arbitrary display refinement not supplied; formal/kernel acceptance not observed in this stage; general paper, finite-bit, hardware, approximation/runtime statements absent. The later formal release narrowed the earlier formal-exposure gap only enough for manual comparison; it did not discharge compilation, trust, publication or independent topology-review gates.

The editorial Bell extra-adjoint-declaration count difference is not silently erased from the source coverage. Mathematical statement and all-column proof remain present on both sides. A future source edit would require a new source digest and updated evidence rather than mutation of either sealed phase.
