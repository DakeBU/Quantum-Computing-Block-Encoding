"""Read-only decoder pin checks and optional local-evidence schema replay."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path
sha = lambda b: hashlib.sha256(b).hexdigest()
load = lambda p: json.loads(p.read_text(encoding='utf-8'))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--work', type=Path, required=True)
    ap.add_argument('--validate-local-evidence', action='store_true')
    args = ap.parse_args()
    repo, work = args.repo, args.work
    decoder = work / 'sp-foundations-c43-final-decoder'
    own = work / 'sp-foundations-c43-source-review-final'
    seal = load(decoder / 'seal.json')
    assert sha((decoder / 'seal.json').read_bytes()) == 'd5b0bf5c532d10f787603330a6e9c145fa88589305a8348e65887e9be8fee86f'
    assert sha((own / 'stage5-seal.json').read_bytes()) == 'fadf1516c07f08e4c6a8fd1cdc176fb027b86a857b44444b296d9ab58da17921'
    for pin in seal['artifacts']:
        p = work.parent / pin['path']
        data = p.read_bytes()
        assert sha(data) == pin['sha256'] and len(data) == pin['bytes']
    allow = load(decoder / 'allowlist.json')
    prior = load(work / 'sp-foundations-c42-author-successor/bounded-checks-v2.json')['raw_207_before_after']
    by_path = lambda rows: {r['path']: (r['sha256'], r['bytes']) for r in rows}
    assert by_path(allow['new_repository_hash_only_allowlist']) == by_path(prior)
    assert len(allow['new_repository_hash_only_allowlist']) == 207
    for pin in allow['archive_hash_only_allowlist']:
        data = (repo / pin['path']).read_bytes()
        assert sha(data) == pin['sha256'] and len(data) == pin['bytes']
    with zipfile.ZipFile(repo / seal['packet_path']) as archive:
        assert len(archive.namelist()) == 15
        for pin in allow['original_formal_text_allowlist']:
            member = 'formal/' + pin['path'].split('/formal/')[1]
            data = archive.read(member)
            assert sha(data) == pin['sha256'] and len(data) == pin['bytes']
            assert data == (work / pin['path']).read_bytes()
    with zipfile.ZipFile(repo / seal['artifact_path']) as archive:
        data = archive.read('reconstruction.md')
        assert sha(data) == '5554bd2ec2e51ee7e4e00466241223f88016d2579b70d3ecb9046d6ed4380991'
        assert data == (work / 'sp-foundations-c41-formal-decoder/reconstruction.md').read_bytes()
    context = load(repo / 'reviews/publication/sp-foundations-c42/final-context-c43-v3.json')
    results = []
    for record in context['records']:
        p = decoder / Path(record['decoder_evidence']).name
        evidence = load(p)
        assert evidence['identity'] == seal['identity'] == '/root/sp_foundations_formal_decoder_c41'
        assert evidence['run_id'] == seal['run_id'] == 'sp-foundations-c41-formal-decoder-20261017T035329Z'
        assert evidence['binding_sha256'] == record['binding_sha256']
        assert evidence['module'] == record['module']
        assert evidence['reconstruction_reference']['member_sha256'] == sha(data)
        assert evidence['source_blind'] and evidence['late_binding_only']
        assert evidence['chronology'] == seal['chronology']
        assert not any(evidence['read_boundary'].values())
        assert evidence['packet_path'] == seal['packet_path'] and evidence['artifact_path'] == seal['artifact_path']
        results.append({'module': record['module'], 'decoder_evidence_sha256': sha(p.read_bytes()), 'binding_sha256': record['binding_sha256'], 'original_identity_run_chronology_and_reconstruction_preserved': True})
    if args.validate_local_evidence:
        checker_path = repo / 'website/scripts/check_research_publications.py'
        assert sha(checker_path.read_bytes()) == 'f8f6d7232376b5bc19a480b7e0ef549a5fafa8d66017e07482f7e6999962f8ad'
        ns = {'__file__': str(checker_path), '__name__': 'stage6_checker'}
        exec(compile(checker_path.read_text(encoding='utf-8'), str(checker_path), 'exec'), ns)
        original = ns['local_file']
        def resolve(root, name):
            prefix = 'reviews/publication/sp-foundations-c42/final-evidence/'
            if name.startswith(prefix):
                base = name[len(prefix):]
                assert '/' not in base and '\\' not in base
                return (decoder if base.endswith('-decoder.json') else own) / base
            return original(root, name)
        ns['local_file'] = resolve
        inventory = {r['fullName']: r for r in load(repo / 'web/library/declarations.json')['declarations']}
        for record in context['records']:
            ns['validate_record'](repo, record, inventory)
    print(json.dumps({'stage': 6, 'all5_decoder_files_checked': True, 'formal15_zip_members_equal_original': True, 'original_reconstruction_bytes_unchanged': True, 'decoder207_manifest_equal_reviewer_pins': True, 'current_decoder_hashes': results, 'local_evidence_validation': 'PASS unchanged original validate_record against exact planned evidence paths via read-only local resolver; no registry mutation/admission' if args.validate_local_evidence else 'not run yet'}, indent=2))

if __name__ == '__main__':
    main()
