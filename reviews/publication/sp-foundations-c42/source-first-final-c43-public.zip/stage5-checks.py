"""Read-only exact successor diagnostics; stdout only, no decoder exposure."""
import argparse
import copy
import hashlib
import json
import zipfile
from pathlib import Path

sha = lambda data: hashlib.sha256(data).hexdigest()
load = lambda path: json.loads(path.read_text(encoding='utf-8'))

def differences(a, b, path=''):
    if isinstance(a, dict) and isinstance(b, dict):
        out = []
        for key in sorted(a.keys() | b.keys()):
            p = path + '/' + key
            out.extend(differences(a[key], b[key], p) if key in a and key in b else [p])
        return out
    if isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            return [path]
        return [p for i, (x, y) in enumerate(zip(a, b)) for p in differences(x, y, path + '/' + str(i))]
    return [] if a == b else [path]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--work', type=Path, required=True)
    args = ap.parse_args()
    repo, work = args.repo, args.work
    public = repo / 'reviews/publication/sp-foundations-c42'
    author = work / 'sp-foundations-c42-author-successor'
    graph_path = public / 'source-and-graph-v3.json'
    context_path = public / 'final-context-c43-v3.json'
    assert sha(graph_path.read_bytes()) == '017733a2f41c40b07f81a6e5d32d2bcf1cbbd69a77228173d0e55a05a8368c8e'
    assert sha(context_path.read_bytes()) == 'f312fb20ad2d1d8d99b297623a66be980aea8379801d6e363c489b49b294a605'
    graph, context = load(graph_path), load(context_path)
    old_graph = load(author / 'source-and-graph-v2.json')
    graph_diff = differences(old_graph, graph)
    assert set(graph_diff) == {'/comparison_object_separation/source', '/comparison_object_separation/discovered_mismatch', '/comparison_object_separation/proposed_repair', '/version', '/metadata_successor'}
    assert graph['version'] == 3 and len(graph['source_construction_hyperedges']) == 37
    assert graph['metadata_successor']['prior_graph_sha256'] == sha((author / 'source-and-graph-v2.json').read_bytes())
    assert graph['comparison_object_separation']['source'] == 'natural-source-v2.md'
    archive_path = repo / context['author_archive']
    assert sha(archive_path.read_bytes()) == context['author_archive_sha256'] == '3f3a4b6ef2e81053065bab9aa249347f1bb428f0f2cb7ae040388040bfb9cf65'
    resolver = context['logical_artifact_resolver']
    archive_pins = {}
    with zipfile.ZipFile(archive_path) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)) == 19
        for logical, pin in resolver.items():
            assert pin['archive'] == context['author_archive']
            name = pin['member']
            assert name in names and '/' not in name and '\\' not in name
            data = archive.read(name)
            assert sha(data) == pin['member_sha256'] == sha((author / name).read_bytes())
            assert logical == 'hermite-export-work/sp-foundations-c42-author-successor/' + name
            archive_pins[name] = sha(data)
        assert set(archive_pins) == set(names)
    old_records = load(author / 'prospective-records-v2.json')['records']
    record_diffs = []
    for old, new in zip(old_records, context['records']):
        changed = differences(old, new)
        normalized = copy.deepcopy(new)
        # The exact old payload must survive except graph-reference substitutions.
        def restore(obj):
            if isinstance(obj, dict):
                if obj.get('logical_reference') == 'reviews/publication/sp-foundations-c42/source-and-graph-v3.json':
                    obj['logical_reference'] = 'hermite-export-work/sp-foundations-c42-author-successor/source-and-graph-v2.json'
                    obj['sha256'] = sha((author / 'source-and-graph-v2.json').read_bytes())
                for value in obj.values():
                    restore(value)
            elif isinstance(obj, list):
                for value in obj:
                    restore(value)
        restore(normalized)
        for key in ('binding_sha256', 'decoder_evidence', 'reviewer_evidence', 'repair'):
            normalized[key] = old[key] if key in old else None
            if key not in old:
                normalized.pop(key)
        normalized.pop('prior_v2_graph_binding_sha256', None)
        assert normalized == old, differences(old, normalized)
        assert new['prior_v2_graph_binding_sha256'] == old['binding_sha256']
        record_diffs.append({'module': new['module'], 'exact_changed_paths': changed})
    lesson = repo / context['records'][0]['lesson_path']
    assert lesson.read_bytes() == (author / 'natural-source-v2.md').read_bytes()
    sources_path = repo / 'website/research/sources.json'
    sources = load(sources_path)['sources']
    row = next(r for r in sources if r['id'] == context['source_row']['id'])
    assert row == context['source_row'] == load(author / 'sources-overlay-v2.json')['sources'][0]
    proposal_path = public / 'editorial-proposal-v2.json'
    assert proposal_path.read_bytes() == (author / 'editorial-proposal.json').read_bytes()
    pins = load(author / 'bounded-checks-v2.json')['raw_207_before_after']
    allowed = {(repo / p['path']).resolve() for p in pins}
    assert len(allowed) == 207
    for pin in pins:
        data = (repo / pin['path']).read_bytes()
        assert sha(data) == pin['sha256'] and len(data) == pin['bytes']
    def import_exact(relative, expected, name):
        path = repo / relative
        assert sha(path.read_bytes()) == expected
        ns = {'__name__': name, '__file__': str(path)}
        exec(compile(path.read_text(encoding='utf-8'), str(path), 'exec'), ns)
        return ns
    checker = import_exact('website/scripts/check_research_publications.py', 'f8f6d7232376b5bc19a480b7e0ef549a5fafa8d66017e07482f7e6999962f8ad', 'stage5_checker')
    atlas = import_exact('website/scripts/research_atlas.py', '0fd3e0a70c1b90127972a445f6e26cb870d0a198cd21449546429b15c16ed67f', 'stage5_atlas')
    atlas['validate_catalog']({'sources': {'schema_version': 1, 'sources': [row]}, 'atlas': {'schema_version': 1, 'domains': [], 'families': [], 'hyperedges': [], 'contributions': []}, 'wiki': {'schema_version': 1, 'routes': []}})
    ambient = [p for directory in ('QuantumBlockEncoding', 'ABEISTests') for p in sorted((repo / directory).rglob('*.lean'))]
    assert len(ambient) == 202 and all(p.resolve() in allowed for p in ambient)
    inventory = load(repo / 'web/library/declarations.json')['declarations']
    frozen_inventory = load(author / 'declaration-inventory-v2.json')['declarations']
    keys = ('module', 'source_id', 'source_statement', 'source_anchor', 'lesson_path', 'declarations', 'obligation_map', 'assumption_deltas', 'graph_contribution', 'formalizer', 'residual_boundary')
    canonical = lambda obj: json.dumps(obj, sort_keys=True, ensure_ascii=False).encode()
    bindings = []
    real_read = Path.read_bytes
    trace = []
    def guarded(path):
        assert path.resolve() in allowed or path.resolve() == lesson.resolve()
        data = real_read(path)
        trace.append(sha(data))
        return data
    for record in context['records']:
        names = {r['fullName'] for r in inventory if r.get('source') == record['module']}
        assert names == set(record['declarations']) == {r['source_name'] for r in frozen_inventory if r['source'] == record['module'] and not r['private']}
        assert len(record['declarations']) == len(names)
        assert set().union(*(set(o['declarations']) for o in record['obligation_map'])) == names
        trace.clear()
        Path.read_bytes = guarded
        try:
            official = checker['binding_digest'](repo, record)
        finally:
            Path.read_bytes = real_read
        assert len(trace) == 206
        h = hashlib.sha256(canonical({k: record.get(k) for k in keys}))
        for name in (record['module'], record['lesson_path'], 'lean-toolchain', 'lake-manifest.json'):
            h.update(name.encode())
            h.update((repo / name).read_bytes())
        for path in ambient:
            h.update(path.relative_to(repo).as_posix().encode())
            h.update(path.read_bytes())
        h.update(canonical(row))
        assert official == h.hexdigest() == record['binding_sha256']
        bindings.append({'module': record['module'], 'binding_sha256': official, 'public_declarations': len(names), 'original_checker_equals_independent_replay': True, 'raw_byte_reads': len(trace)})
    for pin in pins:
        assert sha((repo / pin['path']).read_bytes()) == pin['sha256']
    print(json.dumps({'stage': 5, 'decoder_files_read': False, 'graph_exact_difference_paths': graph_diff, 'unchanged_math_edges': 37, 'unchanged_inventory_rows': 103, 'archive_exact_members_verified': len(archive_pins), 'record_metadata_differences': record_diffs, 'actual_source_catalog_rows': len(sources), 'installed_row_exact': True, 'source_catalog_sha256': sha(sources_path.read_bytes()), 'installed_lesson_sha256': sha(lesson.read_bytes()), 'proposal_sha256': sha(proposal_path.read_bytes()), 'raw207_unchanged': True, 'actual_row_schema_validation': 'PASS single-row catalog with empty other surfaces, not full catalog check', 'bindings': bindings, 'no_registry_admission_or_Lean_execution': True}, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
