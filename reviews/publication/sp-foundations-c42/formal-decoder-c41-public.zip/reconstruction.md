# Independent formal-only reconstruction

Run identity: `sp-foundations-c41-formal-decoder-20261017T035329Z`; agent identity: `/root/sp_foundations_formal_decoder_c41`.

Direction fingerprint: independent expansion of formal carriers, propositions, concrete entries, bit order, gate composition and resource recurrences, without natural-source anchoring. Expected information gain: expose hypotheses or semantics missing from superficially similar circuit/certificate claims.

This is a sealed mathematical reading, not a compilation report, source comparison, final publication wrapper, or admission verdict. All three target modules and all eleven supplied provider excerpts were read in full, including proof bodies, private helpers, structures, imports and retained strings. Imports were not followed. `extents.json` says the targets are complete modules, the providers are excerpts, and the packet does not claim standalone compilation. No Lean, native evaluator, network, Git, production or registry mutation was performed. Shell use was restricted to reading permitted files, listing declarations in those files, checking the new output path, hashing and time retrieval. All authored files are confined to this output directory.

## 1. Carriers and generic contracts

Write `D(q)=2^q`. `Fin m` is the finite set of natural numbers strictly below `m`. The foundational `QuantumBlockEncoding.Matrix rows cols α` is just a function `Fin rows → Fin cols → α`; `ConcreteSemantics.FiniteMatrix` is Mathlib's matrix on those same indices. A state vector is a function `Fin dimension → α`. A basis ket `e_i` is 1 at `i`, 0 elsewhere. `zeroBasisIndex q` is 0 in `Fin D(q)`, including q=0; `zeroKet q=e_0`. Operators act on column vectors: `(applyVec U v)(r)=Σ_c U(r,c)v(c)`.

`StatePreparationTarget α q` contains **data**, not automatic laws: amplitudes `a:Fin D(q)→α`, an arbitrary proposition `normalization:Prop`, and an arbitrary source string (default empty). Its normalization field need not assert any norm formula. `FirstColumnMatches U t` means `∀r,U(r,0)=t.amplitudes(r)`.

`StatePreparationCandidate α q` contains a target; arbitrary square matrix; a symbolic `Circuit`; a `LayeredCircuit` schedule defaulting to []; a `Resource`; an auxiliary-qubit natural number defaulting to 0; and an arbitrary proposition `isUnitary`. `preparesTarget` means first-column matching. Its `cost` copies the separately supplied auxiliary count, resource gate count, depth and oracle count. `VerifiedStatePreparation` adds proofs of the stored normalization proposition, stored isUnitary proposition and first-column matching. **At this generic level, the field called isUnitary need not be matrix unitarity**, and neither circuit denotation, schedule correctness nor accounting consistency is a field.

`ComplexUnitaryGate q` strengthens the matrix field to an actual complex unitary: membership in Mathlib's unitaryGroup. Matrix `star` is conjugate transpose; one equivalent equation used is `U†U=I`, another is `UU†=I`. `ComplexStatePreparationCertificate q` contains a target, such a gate, proof of its target's chosen normalization proposition, and equality `Ue_0=a`. It supplies real matrix unitarity and exact vector action, although its normalization proposition remains whatever the target chose.

For every certificate and **arbitrary** `circuit`, `schedule`, `resource` and auxiliary count, `candidate` copies those annotations without a relation to U. `verified` transports the certificate's actual unitarity and action to generic `VerifiedStatePreparation` using first-column equivalence. `preparesVector` merely projects the action field. Thus certificate + any annotations implies a verified wrapper for those annotations; it does not imply those annotations implement U or are correct costs.

The concrete-semantic provider proves, with no target-specific hypotheses: `basisKet_apply`; `applyVec_basisKet` (Ue_i is column i); `applyVec_twoBasisSuperposition` and its pointwise version (U(ae_l+be_r)=aU[:,l]+bU[:,r], without l≠r); `applyVec_zeroKet`; and `firstColumnMatches_iff_applyVec_zeroKet`. The generic applyVec definition needs only a nonunital nonassociative semiring; the basis-column and equivalence lemmas use a nonassociative semiring. The superposition lemmas are over ℂ. These statements do not require normalization or unitarity.

`RegisterLayout` has systemQubits, signalQubits, pureAncillas; its auxiliary count is signal+pure. `BlockEncodingSpec α rows cols` stores matrix, normalizer, error (all over arbitrary α), layout, circuit and resource, without a block-encoding correctness proposition in the supplied excerpt. `BlockEncodingCost` is four naturals: auxiliaryQubits, gateCount, depth, oracleCalls. `fromLayoutAndResource` and `fromSpec` simply project the appropriate fields. `betterThan` is strict lexicographic order **gate count first, then depth, then auxiliary count, then oracle calls**. `noWorseThan` is equality or that strict order. This is not a componentwise Pareto order.

## 2. Resource and circuit languages

`Resource` has natural fields `(oneQubit,cnot,oracleCalls,pureAncilla,depth)`, all default 0. `gates=oneQubit+cnot+oracleCalls`. `add` adds all five fields, while `parallel` adds the first three and takes maxima of ancilla and depth. `scale k` multiplies every field by k. `ofCounts a b p=(a,b,0,p,a+b)`. `ofCountsWithDepth` stores all five supplied counts. Zero and heterogeneous addition use these definitions. All `gates_eq`, zero-field and add-field lemmas are definitional projections.

The symbolic `Gate` constructors are: named one-qubit gate on a natural wire, Y/Z rotation on a natural wire with a **string** angle label, CNOT, swap, multiControlled with a list of (natural wire, Boolean) controls and a body Gate, and named oracleCall. No finite-width wire validity or control-distinctness is required in this language. `Circuit=List Gate`, `CircuitLayer=List Gate`, `LayeredCircuit=List CircuitLayer`.

The stored resource convention charges each one-qubit/rotation gate one one-qubit gate and depth 1; each CNOT one CNOT and depth 1; swap three CNOTs and depth 3; an oracle call one oracle and depth 1. A multiControlled body adds `(16k one-qubit,12k CNOT,k pure ancillas,28k depth)` for k listed controls, even for repeated controls; this is a syntactic cost formula, not a decomposition correctness proof in the packet. A Circuit sequentially sums resources. A CircuitLayer folds `parallel`, with no disjointness check. LayeredCircuit sums layer resources. Their depth functions project resource.depth. `resource_nil` and `resource_cons` unfold the recursion.

The distinct primitive language enforces wire types `Fin q`. `PrimitiveGate q` has x, ry, rz and cx; cx carries `control≠target`. `PrimitiveCircuit q` is a gate list. `PrimitiveProgram q` contains a circuit and a globalPhase ExactAngle; no evaluation of PrimitiveProgram/global phase is present in these excerpts.

`ExactAngle` is an expression datatype: rational r; piRational r; twiceArccosRational r with proof |r|≤1; twiceArccosSqrtRational r with proof 0≤r≤1; arbitrary real; addition; negation; and rational scaling. Its noncomputable eval maps these respectively to r, πr, 2 arccos r, 2 arccos sqrt r, the real itself, sum, negative and scaled value. Its private `exactAngleRepr` prints rational data and expression syntax, but prints an opaque numerical-export-required marker for arbitrary reals. Repr is not a numerical synthesis algorithm. `sub`, `halfAdd`, `halfSub` are expression constructors with evaluations a−b, (a+b)/2, (a−b)/2. All eval_add/neg/scale/sub/half_add/half_sub lemmas assert these equalities.

Primitive dagger leaves x/cx unchanged and negates ry/rz angles. `touched` is a finite set with one target or the two cx wires. `oneQubitCount` per gate is 1 except cx=0; `twoQubitCount` is 1 exactly for cx. Circuit gateCount is length; one/two-qubit counts are folds; ryCount and cxCount count the matching constructors. Their append/singleton lemmas express ordinary addition and 0/1 constructor tests. `nextWireDepth d g` sets every touched wire to `1+max_{w touched}d(w)` and leaves all others unchanged; `wireDepths` folds this from all-zero clocks; depth is the maximum final wire clock (0 for an empty wire set). This is all-to-all wire-dependency depth, not the list length. `resource` uses these one/two-qubit counts, oracle=0, pureAncilla=0 and this depth. `gateCount_eq_length` and `resource_oracleCalls_eq_zero` are definitional. No connectivity, T-count, precision or classical-runtime cost is implicit here.

## 3. Primitive semantics and bit conventions

`PrimitiveBasis q=Fin q→Fin 2` is a whole bit assignment. `flipBit` exchanges 0 and 1 and is involutive. `xBasisAction t` updates only t to its complement; its involutivity gives `xBasisEquiv`. `cxBasisAction c t` is identity if the c-bit is 0, otherwise it performs that x update; involutivity requires c≠t and supplies `cxBasisEquiv`. Its apply lemma unfolds this map. A permutation matrix for E has entry `[row=E(column)]`, so it sends e_s to e_(E(s)), not the inverse convention. The packet proves such matrices unitary and their adjoints equal the matrix of E⁻¹.

`OtherPrimitiveWires t={w:Fin q // w≠t}`. `splitPrimitiveWire t` is an equivalence between full bits and `(targetBit, allOtherBits)`; its inverse reinserts the target bit and copies the other bits. `splitPrimitiveWire_other_apply` is the projection identity. `liftPrimitiveOneQubit t G` is the reindexed `G⊗I` in this splitting. Its entry is G(row_t,column_t) if the other-bit functions agree, and 0 otherwise; its unitary theorem assumes G unitary. Its star theorem says lifting commutes with adjoint.

For real c,s, `realOrthogonalRotation c s=[[c,-s],[s,c]]` over ℂ. Its unitary theorem assumes c²+s²=1, with no separate sign condition. `realRotation φ` substitutes cosφ,sinφ. Its four entry lemmas and unconditional unitarity follow by the circle identity. `amplitudeRotation x=realRotation(arccos x)` is unitary for all real x; its 00-entry equals x only under −1≤x≤1. No clipping-free coefficient identity is available outside that interval. Reindexing any finite complex unitary along a finite-index equivalence preserves unitarity; blockDiagonal of a pointwise unitary family is unitary. These are the remaining general matrix-provider theorems.

`standardRyMatrix θ=realRotation(θ/2)`, hence

    Ry(θ) = [[cos(θ/2), -sin(θ/2)], [sin(θ/2), cos(θ/2)]].

It is the identity at 0, is unitary, obeys Ry(a+b)=Ry(b)Ry(a), and Ry(−θ)=Ry(θ)†. `xMatrix=[[0,1],[1,0]]` satisfies X Ry(θ) X=Ry(−θ). `standardRyMatrix_two_arccos_eq_amplitudeRotation` has two interval binders, but its **body only cancels the factor 2** and does not use them; the equality itself follows for all reals. The complex sin/cos conjugation lemmas assert real-valuedness for real arguments, including the half-angle casts; `complex_ofReal_div_two` identifies the cast with real division then cast.

`standardRzMatrix θ=diag(cos(θ/2)−i sin(θ/2), cos(θ/2)+i sin(θ/2))`. It is unitary and negating θ gives its adjoint. `evalPrimitiveGate` maps x/cx to the above permutation matrices, ry/rz to their one-wire lifts evaluated at the ExactAngle. Every primitive gate is unitary. `evalPrimitiveCircuit []=I`; `evalPrimitiveCircuit(g::rest)=eval(rest)eval(g)`. Therefore gates act in **list order**, and concatenation satisfies eval(left++right)=eval(right)eval(left). Circuit unitarity is proved by induction and closure under multiplication. These are exact complex matrices, with no quotient by global phase.

`primitiveBasisLEEquiv q` reindexes bit functions to `Fin D(q)`. At q=0 it maps the unique bit function to 0; at q+1 it extracts bit 0 and recursively encodes the tail, yielding `index=bit0+2*tailIndex`. In particular q=6 gives Σ_(j=0)^5 2^j bit_j. The two-wire inverse `primitiveBits2LE i` gives wire0=i mod2, wire1=floor(i/2) mod2. The two_symm, wire_zero, wire_one and four constant-index lemmas assert those exact identifications. In the display order `|wire1 wire0⟩`, flat indices 0,1,2,3 are 00,01,10,11.

`primitiveBits2LEWithout t i` and `primitiveBits2LEGridWithout t i` encode the remaining bit: floor(i/2) when t=0, i mod2 when t=1. The two context_eq theorems identify equality of split other-wire functions with equality of that remaining-bit number. The six-bit and two-bit lemmas have native_decide bodies in the supplied text; this decoder did not execute them or treat their presence as a current build result.

## 4. Uniformly controlled Ry provider, including private helpers

All widths/control counts below are natural numbers; target is in Fin q; `wires:Fin k→Fin q` only carries `∀j,wires(j)≠target`. **No injectivity of wires, no distinctness between controls, and no k≤q−1 binder is assumed.** A repeated control is a valid supplied input, with only correlated control assignments realizable.

Private `prependControlBit b tail` is Fin.cons; `halfAddAngles angles` at tail is half the sum of the angle expression at `(0,tail)` and `(1,tail)`; `halfSubAngles` is half their difference. `primitiveControlAssignment wires target distinct context` reads context at each listed physical control wire. `controlledRyBlockMatrix` splits off the target and forms a block diagonal whose context block is Ry(angle(selectedAssignment).eval). Its entry theorem preserves every other wire and selects the rotation using the **row's** context; when the contexts match this is also the column's context.

Private `kronecker_one_eq_blockDiagonal` identifies G⊗I with constant blocks. Private `evalPrimitiveRy_eq_controlledRyBlockMatrix_zero` identifies a single ry with the zero-control block matrix; there is only one empty control assignment. Private `controlledXBlock c t d context` is I when that context's control bit is 0 and X otherwise. Private `xMatrix_flipBit` says X(complement b,b)=1. Private `evalPrimitiveCx_eq_controlledXBlock` identifies cx with those context blocks: its body partitions equal/unequal other-wire contexts, then zero/nonzero control and flipped/unflipped target, proving exactly the positive-control Boolean action. It does not assume a matrix CX from outside the packet.

Let C_k(A) denote `compileUniformlyControlledRy`. Base case is one ry on the target using the sole empty-assignment angle. At k+1 let h=wires(0), remove this head control, and form A+=(A0+A1)/2 and A−=(A0−A1)/2 as expression functions on the tails. The **chronological list** is:

    C_k(A+) ; CX(h,target) ; C_k(A−) ; CX(h,target).

`uniformlyControlledRyMatrix` separately recurses to the product CX * U_k(A−) * CX * U_k(A+), with single ry at the base. `compileUniformlyControlledRy_eval` proves the list denotes that recursive product by append multiplication and induction. The stronger `compileUniformlyControlledRy_eval_controlledRyBlockMatrix` proves it equals the desired context-indexed blocks. Its induction reindexes all factors into the same block-diagonal splitting: at head bit 0, Ry(A−)Ry(A+)=Ry(A0); at head bit 1, X Ry(A−) X Ry(A+)=Ry(−A−)Ry(A+)=Ry(A1). The assignments are identified using prependControlBit and the head-bit case split. Tail controls need not be independent of the head for this pointwise proof.

As a mathematical consequence of the literal recursion (not an explicitly named resource theorem in this excerpt), an unoptimized k-control compilation has 2^k Ry gates and 2^(k+1)−2 CX gates. No zero rotations or cancelling CX gates are removed. Its depth depends on actual wire reuse and the primitive clock definition; no general depth bound is proved here.

## 5. Complete target-01 reconstruction

Names in this section are in `QuantumBlockEncoding.TextbookStatePreparation`. Every explicit declaration is accounted for below.

1. `zeroIndex` and `oneIndex` are 0 and 1 in Fin D(1)=Fin2, with finite-index bound proofs. `pauliX` is the permutation swapping them, namely X=[[0,1],[1,0]]. `pauliX_unitary` uses its real symmetric adjoint and X²=I.
2. `oneState=e_1=(0,1)`. `oneTarget` stores that vector, normalization proposition Σ_i normSq(oneState_i)=1, and exact metadata string `Pauli X textbook example`. `oneTarget_normalized` singles out the only nonzero coordinate. `pauliX_prepares_one` proves Xe_0=e_1: the swap pulls back coordinates, row0 becomes the zero coordinate at 1, and the only other row is 1 and pulls back coordinate0. Its local inequality facts distinguish 0 and 1 by Fin.val and its row classification uses the bound row<2.
3. `pauliXGate` packages X and its true unitarity proof. `pauliXCertificate` packages oneTarget, that gate, the normalization proof and the exact action proof. `pauliXCircuit` is the single symbolic gate `Gate.oneQubit "X" 0`. `pauliXVerified` calls the annotation-accepting verified constructor with that list, the singleton layer containing the same gate, and that list's resource; the auxiliary default is 0. `pauliXVerified_cost` projects the tuple `(auxiliaryQubits,gateCount,depth,oracleCalls)=(0,1,1,0)`. This is a definitional annotation cost, not an eval-of-symbolic-X theorem.
4. `invSqrtTwo` is the complex cast of sqrt(2)/2. `invSqrtTwo_mul_self` proves its ordinary square (not norm square) is 1/2 by casting the real equation and using (sqrt2)²=2. `hadamard` has every entry h=invSqrtTwo except (1,1)=−h, i.e. H=h[[1,1],[1,−1]]. `star_hadamard` proves H†=H by four real-entry cases; `hadamard_unitary` proves H²=I with those four sums and h²=1/2.
5. `plusState=(h,h)`. `plusTarget` stores that vector, Σ_i normSq(plusState_i)=1, and string `Hadamard textbook example`. `plusTarget_normalized` computes each norm square as 1/2. `hadamard_prepares_plus` extracts H's zero column and verifies both entries are h. `hadamardGate` and `hadamardCertificate` package the matrix, unitarity, target, normalization and action in the same field order as above.
6. `hadamardCircuit` is `[Gate.oneQubit "H" 0]`; `hadamardVerified` supplies its one-gate layer and its resource to verified, with auxiliary default 0. `hadamardVerified_cost` again gives (0,1,1,0), with the same annotation/denotation separation. The final `pauliXCertificate_prepares_one` and `hadamardCertificate_prepares_plus` project exact action from the two certificates; they introduce no circuit-evaluation bridge or new assumptions.

All theorems here are closed for these fixed one-qubit examples. No free normalized-vector family, synthesis algorithm, oracle, approximation or resource asymptotic is asserted. The noncomputable qualifiers attach to real square roots and dependent definitions, not to an efficient executable implementation claim.

## 6. Complete target-02 reconstruction

Names are in `QuantumBlockEncoding.StatePreparationBenchmarks`. All vectors/matrices are over ℂ, listed in increasing flat index order. The stored targets explicitly choose norm-square-sum=1, unlike the unrestricted generic target type.

### Bell family

`bellAmplitude` abbreviates target-01's h. `bellState=(h,0,0,h)` on Fin4. `bellTarget` contains it, its norm-square proposition, and string `Bell-state textbook benchmark`. `bellTarget_normalized` sums two terms of 1/2. The literal full `bellMatrix` is

    h * [[1,0,0,1],
         [0,1,1,0],
         [0,1,-1,0],
         [1,0,0,-1]].

`star_bellMatrix` establishes self-adjointness. `bellMatrix_unitary` checks every entry of its square using h²=1/2. `bellGate` packages this matrix and proof. `bellMatrix_prepares_target` extracts its first column; `bellCertificate` stores target, gate, normalization and exact action. This is not a declaration that a particular H/CNOT sequence equals this full matrix. The name/string cannot supply such a theorem.

### Dense rational family

`mottonenDenseState=(39,52,60,144)/169`; `mottonenDenseTarget` chooses its norm-square proposition and string `Möttönen-style dense two-qubit nested-Pythagorean benchmark`. `mottonenDenseTarget_normalized` is the exact identity 39²+52²+60²+144²=169². The literal `mottonenDenseMatrix` is

    (1/169) * [[39,-52,-60,-144],
               [52,39,-144,60],
               [60,144,39,-52],
               [144,-60,52,39]].

The catch-all branch is 39/169, but on Fin4×Fin4 only the (3,3) entry reaches it; it is not an extra off-carrier condition. `mottonenDenseMatrix_unitary` computes all sixteen entries of U†U=I by conjugation and rational arithmetic, using increased elaboration limits. `mottonenDenseGate` packages it. `mottonenDenseMatrix_prepares_target` matches the first column; `mottonenDenseCertificate` packages exactly those proofs and data. No arbitrary dense-state theorem or gate-list implementation is present here.

### Product rational family

`groverRudolphProductState=(9,12,12,16)/25`; `groverRudolphProductTarget` chooses its norm-square proposition and string `Grover--Rudolph structured product-distribution benchmark`. `groverRudolphProductTarget_normalized` computes 9²+12²+12²+16²=25². The full `groverRudolphProductMatrix` is

    (1/25) * [[9,-12,-12,16],
              [12,9,-16,-12],
              [12,-16,9,-12],
              [16,12,12,9]].

Again the sole unlisted Fin4×Fin4 entry is (3,3). `groverRudolphProductMatrix_unitary` computes U†U=I in sixteen cases. `groverRudolphProductGate` packages the matrix and unitary proof; `groverRudolphProductMatrix_prepares_target` is its first-column action; `groverRudolphProductCertificate` stores this target, gate, normalization and action. Its actual primitive implementation is supplied only later in target-03.

### Sparse rational family

`sparseThreeState=(3,0,4,0,12,0,0,0)/13` on Fin8. `sparseThreeTarget` stores its norm-square proposition and string `Li--Luo sparse-state finite witness of Eq. (2), n=3 and d=3`. `sparseThreeTarget_normalized` computes 3²+4²+12²=13². Nonzero entries of `sparseThreeMatrix`, with zero in all other positions, are:

    U(0,0)=3/13, U(0,1)=−4/5, U(0,2)=−36/65;
    U(2,0)=4/13, U(2,1)=3/5, U(2,2)=−48/65;
    U(4,0)=12/13, U(4,2)=25/65;
    U(1,3)=U(3,4)=U(5,5)=U(6,6)=U(7,7)=1.

The (4,1) branch is explicitly 0, agreeing with the default. For an unambiguous full description, its columns are respectively `(3e0+4e2+12e4)/13`, `(−4e0+3e2)/5`, `(−36e0−48e2+25e4)/65`, e1, e3, e5, e6, e7. `sparseThreeMatrix_unitary` computes all 64 entries of U†U, with higher elaboration limits; the first three columns are an orthonormal basis of span(e0,e2,e4), while the other five are orthogonal standard coordinates. `sparseThreeGate`, `sparseThreeMatrix_prepares_target`, and `sparseThreeCertificate` respectively package actual unitarity, extract column0, and package the four certificate fields. No gate count or sparse synthesis circuit is attached to this certificate in the target.

### Natural-number arithmetic family

`selectSwapCleanTCount (N b lambda:Nat)=4*((N+lambda−1)/lambda)+8*b*lambda`. This definition is total: natural subtraction truncates at zero; natural division by zero returns zero, so lambda=0 is not excluded and yields value 0. For positive lambda the quotient is the usual ceiling-style division of N, but no positivity binder or generic ceiling theorem is stated. The three closed theorems `selectSwapCleanTCount_16_1_1`, `selectSwapCleanTCount_16_1_4`, and `selectSwapCleanTCount_lambda4_better_lambda1` compute the values at (16,1,1) as 72, at (16,1,4) as 48, and prove 48<72, respectively. Their bodies use decide on closed arithmetic. They do not relate this formula to a circuit's actual T gates, synthesize SELECT/SWAP, prove a uniform optimization result, or supply an oracle construction. Neither the function name nor retained source strings add mathematical hypotheses or conclusions.

## 7. Complete target-03 reconstruction

Names are again in `QuantumBlockEncoding.StatePreparationBenchmarks`, except nested route methods. The full semantics here differ materially from the symbolic annotations in target-01.

### General route interface and rotation helpers

`evalPrimitiveCircuitLE {q} circuit` reindexes the primitive bit-function matrix along primitiveBasisLEEquiv q to a matrix on Fin D(q): its (r,c) entry is primitive eval at the inverse-decoded bits of r and c. `evalPrimitiveCircuitLE_unitary` follows from primitive-circuit unitarity and reindex_unitary, for every typed primitive circuit, including the empty circuit.

`ExactPrimitiveStatePreparationRoute q` has exactly four fields: target:StatePreparationTarget ℂ q; circuit:PrimitiveCircuit q; normalizationProof:target.normalization; preparationProof:evalLE(circuit)e0=target.amplitudes. There is no separate arbitrary matrix or isUnitary proposition. Its `.unitary` theorem therefore derives genuine unitarity of its actual circuit denotation for every route. Its `.cost` fixes auxiliaryQubits=0 and copies the primitive circuit's computed resource gates, depth and oracle count. The stored normalization is still an arbitrary proposition in the general interface, but the two instantiated targets use the explicit norm sum. Unlike certificate.verified, arbitrary symbolic resource labels cannot be passed into this route cost.

Private theorem `amplitudeRotation_eq_pythagorean (cosine sine:Real)` assumes −1≤cosine≤1, sine≥0, and cosine²+sine²=1, and concludes amplitudeRotation(cosine)=realOrthogonalRotation(cosine,sine). Its proof gets cos(arccos cosine)=cosine from the interval, nonnegative sin(arccos cosine) from arccos∈[0,π], and the sine's magnitude from the circle identity. Nonnegativity chooses the positive root. Thus a negative supplied sine would not be licensed merely by the squared equation.

Private rational definitions are `cosine35=3/5`, `sine35=4/5`, `cosine513=5/13`, `sine513=12/13`. `ryAngle35` is twiceArccosRational(3/5) with its norm bound proof; `ryAngle513` similarly uses 5/13. `ryAngleZero` is rational 0. The `standardRyMatrix_ryAngle35`, `_ryAngle513`, and `_ryAngleZero` theorems identify their evaluated matrices as respectively

    R = [[3/5,-4/5],[4/5,3/5]],
    S = [[5/13,-12/13],[12/13,5/13]], and I.

The full theorem names are `standardRyMatrix_ryAngle35`, `standardRyMatrix_ryAngle513`, and `standardRyMatrix_ryAngleZero`. The first two bodies first rewrite standardRy(2 arccos c) to amplitudeRotation c, then apply the private Pythagorean theorem with four rational checks. S and the 5/13 angle are defined and proved here but **not used by either concrete route in this complete target module**; they do not establish a route for the dense/sparse examples.

`primitiveLEBits q i` abbreviates the inverse little-endian basis equivalence. `evalPrimitiveCircuitLE_append` transports append multiplication to the flat carrier. For every q, target wire, ExactAngle, row and column, `evalPrimitiveCircuitLE_singleton_ry_apply` gives zero when other bits differ, otherwise Ry(angle.eval)(row_target,column_target). For every q,k,wires,target with only control/target distinctness, angle table, row and column, `evalPrimitiveCircuitLE_compileUniformlyControlledRy_apply` gives the analogous entry selected by primitiveControlAssignment on the row's other bits. These lemmas do not assume a target state, normalized amplitudes, injective controls or a clean auxiliary register. They describe the full matrix, not only its action on zero.

### Concrete circuits and full action

`groverRudolphControlWire:Fin1→Fin2` maps its sole control index to wire1. `groverRudolphControlWire_ne_target` proves it is unequal to target wire0. `groverRudolphConstantAngles` maps both one-control bit assignments to the same ryAngle35.

`groverRudolphTreeCircuit` first applies ryAngle35 to wire1, then compiles the one-control constant-angle table on wire0 controlled by wire1. Its literal chronological expansion is

    Ry_1(θ); Ry_0((θ+θ)/2); CX(1,0);
    Ry_0((θ−θ)/2); CX(1,0),       θ=2 arccos(3/5).

The half expressions remain ExactAngle syntax; they need not be definitionally identical to θ and rational0, although their real evaluations are θ and 0. `groverRudolphFactorizedCircuit` is just `[Ry_1(θ),Ry_0(θ)]` in that order. No work/signal/ancilla wire is used: both are typed on exactly two wires.

`groverRudolphConstantUcry_eval` identifies the compiled constant-control subcircuit's entire bit-basis matrix with the single Ry_0(θ) gate: every context block uses the same angle. `groverRudolphTree_eval_eq_factorized` composes this equality with the preceding Ry_1 and append multiplication. `groverRudolphTree_evalLE_eq_factorized` transports that full operator equality by reindexing. These are stronger than equality of output probability distributions or equality only on e0.

`groverRudolphFactorized_evalLE_eq_matrix` proves the factorized circuit's full flat matrix equals the product matrix in section 6, not merely that their first columns agree. Its local matrix definitions, necessary to reconstruct its body, are

    lowMatrix = (1/5)*[[3,-4,0,0],[4,3,0,0],
                       [0,0,3,-4],[0,0,4,3]],
    highMatrix = (1/5)*[[3,0,-4,0],[0,3,0,-4],
                        [4,0,3,0],[0,4,0,3]].

Its local `lowEval` and `highEval` facts evaluate the one-gate circuits on wire0 and wire1, respectively, using little-endian bits, exact Ry matrix entries and equality/inequality of contexts in all sixteen row/column cases. The proof then multiplies lowMatrix * highMatrix (high acts first) and checks all sixteen rational entries equal groverRudolphProductMatrix. A finite native_decide is present in the text for the context case decisions; it was not executed in this reconstruction.

The register-by-register action on the all-zero input, in flat index order / display order |wire1 wire0⟩, is

    e0 = |00⟩
      -- Ry on wire1 --> (3/5)|00⟩+(4/5)|10⟩
      -- Ry on wire0 --> (9|00⟩+12|01⟩+12|10⟩+16|11⟩)/25.

For the tree, the one-control compiled block has that same second arrow by ConstantUcry_eval; its internal CX flips wire0 only when wire1=1, and its final CX restores the conditional flip. Wire1 is unchanged by the whole controlled target block; both wires may be in superposition/entangled at intermediate points. There is no flag, carry, oracle register, garbage sector, postselection or approximation. Exact real matrices preserve signs/phases, not only squared amplitudes.

`groverRudolphFactorized_prepares_target` rewrites the full matrix equality then uses the product matrix's first-column theorem. `groverRudolphTree_prepares_target` uses evalLE equality with the factorized route. `groverRudolphFactorizedRoute` and `groverRudolphTreeRoute` populate all four route fields with the same product target, their respective circuit, that target's normalization proof, and the corresponding action theorem.

`groverRudolphFactorizedVerified_cost` evaluates the route cost as (0,2,1,0): one Ry on each disjoint wire, so two gates but dependency depth1. `groverRudolphTreeVerified_cost` gives (0,5,4,0): Ry on wire1 at clock1; target Ry on wire0 at clock1; first CX raises both to2; zero-angle target Ry raises wire0 to3; last CX raises both to4. The tree contains three Ry and two CX, including the semantically trivial Ry and cancelling pair; these still count. `groverRudolphFactorized_betterThan_tree` applies the first disjunct of betterThan, since 2<5. It is a comparison of these two concrete exact-real logical circuits under the supplied count model, not a uniform optimality, T-gate, finite-bit or source-algorithm complexity theorem.

## 8. Proof/body scope and boundaries

All explicit target declarations, including private constants/helper theorem, local lowMatrix/highMatrix definitions and their local evaluation facts, have a mathematical reconstruction above. Structures were expanded field-by-field. Provider definitions/theorems needed to interpret these declarations were also reconstructed, including private uniform-control helpers, representation functions, resource constructors, and generic Prop contracts. Namespace commands, open/scoped commands and elaboration settings add no mathematical hypotheses; imports are recorded by the packet, not imported or inspected by this worker.

The proof strategies are explicit: finite first-column extraction; finite rational/trigonometric unitarity calculations; exact-angle branch selection by bounds and nonnegative sine; primitive involutions/permutations; tensor and reindex transports; induction for circuit composition and uniform-control compilation; and closed resource/arithmetic evaluation. No target body was treated as an uninterpreted desired conclusion.

Remaining limits, not hidden assumptions:

- No current Lean build, axiom closure audit, dependency-manifest/toolchain validation or external theorem inspection was authorized or performed. The supplied provider excerpts are not complete imported modules. Formal theorem bodies and imported Mathlib names are read as supplied text, not as independent execution evidence.
- No natural source, theorem title outside retained formal identifiers/strings, author handoff, binder audit, source inventory, graph, trust record, raw seal or other worker output was opened. Therefore no source-hypothesis classification or natural-source equivalence verdict can honestly be inferred here.
- Target-01's symbolic circuit labels and resources are not connected to actual circuit evaluation by its verified wrappers. The actual X/H **matrices and their preparation actions** are supplied and proved in the text; the wrapper alone does not certify a labeled circuit.
- Target-02 supplies fixed exact matrices and states, plus three arithmetic facts. It does not supply general named-algorithm state-preparation theorems, primitive implementations of Bell/dense/sparse states, nor compiled SELECT/SWAP semantics. Retained names/strings do not fill these boundaries.
- Target-03 supplies full primitive semantics and exact state preparation for the two listed two-qubit **product** routes only. Its S rotation helper does not extend the result to the dense/sparse cases. Generic uniformly controlled Ry is a real parametric circuit-semantic theorem but not, by itself, a complete arbitrary-state preparation compiler.
- Costs are exact-real logical primitive counts and wire-dependency depths. No finite-bit angle approximation, Clifford+T synthesis, hardware connectivity, gate calibration, preprocessing/runtime, oracle construction, success-amplification or readout cost theorem is present.
- Generic target normalization and generic candidate unitary are arbitrary Props, whereas the concrete complex gates, explicit target norm sums and primitive unitary theorems add the actual mathematical content. Resource/layout fields in generic structures need not be internally consistent unless extra evidence is supplied.

## 9. Bounded handoff

Objective/frontier: independently decode exactly the allowed formal packet. Mathematical delta: a complete field-, body-, entry- and convention-level reconstruction, with generic implication limits separated from concrete circuit action. Evidence: only the fifteen exact pinned formal inputs in `input-pins.json`; no external source evidence. Files changed: this reconstruction, input-pins.json and seal.json, all local to the assigned output directory. Failure class: NONE for the reconstruction; compilation is explicitly unperformed, not an environmental failure or a proof success. Salvage candidates: the formal distinction between matrix certificates and typed circuit routes, and the parameterized uniformly controlled Ry block theorem; no fragment promoted by this worker. Process memory consulted: none outside the permitted governing instructions. Parallel admission: this worker was assigned a distinct formal-only direction by the parent; no child agents used. Common-blind-spot review/default-route selection: not performed or claimed. Purification/Exposition Seal: no publication lifecycle status asserted; this is only a decoder artifact. Recommended next step: independent comparison by a distinct reviewer using the frozen reconstruction and separately allowed source, without releasing that source to this decoder.
