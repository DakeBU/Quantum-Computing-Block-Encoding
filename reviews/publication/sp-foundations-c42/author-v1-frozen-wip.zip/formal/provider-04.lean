import QuantumBlockEncoding.Circuit

   
                             

                                                                               
                                                                          
                                                                               
                                                
  

namespace QuantumBlockEncoding

structure RegisterLayout where
  systemQubits : Nat
  signalQubits : Nat
  pureAncillas : Nat
deriving Repr, DecidableEq

namespace RegisterLayout

   
                                                                              
                                                                               
            
  
def auxiliaryQubits (layout : RegisterLayout) : Nat :=
  layout.signalQubits + layout.pureAncillas

end RegisterLayout

                                                                      
structure BlockEncodingSpec (α : Type u) (rows cols : Nat) where
  matrix : Matrix rows cols α
  normalizer : α
  error : α
  layout : RegisterLayout
  circuit : Circuit
  resource : Resource

   
                                                                      
                                                            

               
                         
                          
                                 
  
structure BlockEncodingCost where
  auxiliaryQubits : Nat
  gateCount : Nat
  depth : Nat
  oracleCalls : Nat
deriving Repr, DecidableEq

namespace BlockEncodingCost

def fromLayoutAndResource (layout : RegisterLayout) (resource : Resource) :
    BlockEncodingCost where
  auxiliaryQubits := layout.auxiliaryQubits
  gateCount := resource.gates
  depth := resource.depth
  oracleCalls := resource.oracleCalls

def fromSpec (spec : BlockEncodingSpec α rows cols) : BlockEncodingCost :=
  fromLayoutAndResource spec.layout spec.resource

                                                                               
def betterThan (x y : BlockEncodingCost) : Prop :=
  x.gateCount < y.gateCount ∨
  (x.gateCount = y.gateCount ∧
    (x.depth < y.depth ∨
      (x.depth = y.depth ∧
        (x.auxiliaryQubits < y.auxiliaryQubits ∨
          (x.auxiliaryQubits = y.auxiliaryQubits ∧
            x.oracleCalls < y.oracleCalls)))))

                                                                                
def noWorseThan (x y : BlockEncodingCost) : Prop :=
  x = y ∨ x.betterThan y

end BlockEncodingCost
end QuantumBlockEncoding

