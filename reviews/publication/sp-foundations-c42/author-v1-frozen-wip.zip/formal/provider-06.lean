import Mathlib.Data.Complex.Basic
import Mathlib.Data.Matrix.Mul
import Mathlib.LinearAlgebra.UnitaryGroup
import QuantumBlockEncoding.BlockEncodingClassics
import QuantumBlockEncoding.CircuitSemantics
import QuantumBlockEncoding.StatePreparation

   
                                  

                                                                            
                                                                            
                                                                          
                      

                                                                            
                                                                        
       
  

namespace QuantumBlockEncoding
namespace ConcreteSemantics

                                                                              
abbrev FiniteMatrix (rows cols : Nat) (α : Type u) :=
  _root_.Matrix (Fin rows) (Fin cols) α

                              
abbrev StateVector (dimension : Nat) (α : Type u) :=
  Fin dimension -> α

                                                                
def basisKet (dimension : Nat) {α : Type u} [Zero α] [One α]
    (index : Fin dimension) : StateVector dimension α :=
  Pi.single index 1

                                                                              
                                                                             
                              
@[simp] theorem basisKet_apply {dimension : Nat} {α : Type u}
    [Zero α] [One α] (index row : Fin dimension) :
    basisKet dimension (α := α) index row =
      if index = row then 1 else 0 := by
  by_cases hit : index = row
  · subst row
    simp [basisKet]
  · simp [basisKet, hit]

                                                                      
def zeroKet (qubits : Nat) {α : Type u} [Zero α] [One α] :
    StateVector (gridSize qubits) α :=
  basisKet (gridSize qubits) (zeroBasisIndex qubits)

                                                                 
def applyVec {rows cols : Nat} {α : Type u} [NonUnitalNonAssocSemiring α]
    (operator : FiniteMatrix rows cols α) (state : StateVector cols α) :
    StateVector rows α :=
  operator.mulVec state

   
                                                                           
                                                   
  
structure ComplexUnitaryGate (qubits : Nat) where
  matrix : FiniteMatrix (gridSize qubits) (gridSize qubits) ℂ
  unitary :
    matrix ∈ _root_.Matrix.unitaryGroup (Fin (gridSize qubits)) ℂ

                                                                     
@[simp] theorem applyVec_basisKet {rows cols : Nat} {α : Type u}
    [NonAssocSemiring α] (operator : FiniteMatrix rows cols α)
    (index : Fin cols) :
    applyVec operator (basisKet cols index) = operator.col index := by
  exact _root_.Matrix.mulVec_single_one operator index

                                                                             
                                                                            
                                                                                
theorem applyVec_twoBasisSuperposition {rows cols : Nat}
    (operator : FiniteMatrix rows cols ℂ) (a b : ℂ)
    (left right : Fin cols) :
    applyVec operator
        (a • basisKet cols left + b • basisKet cols right) =
      a • operator.col left + b • operator.col right := by
  unfold applyVec basisKet
  rw [_root_.Matrix.mulVec_add, _root_.Matrix.mulVec_smul,
    _root_.Matrix.mulVec_smul, _root_.Matrix.mulVec_single_one,
    _root_.Matrix.mulVec_single_one]

                                                                            
                                                                             
                                                    
theorem applyVec_twoBasisSuperposition_apply {rows cols : Nat}
    (operator : FiniteMatrix rows cols ℂ) (a b : ℂ)
    (left right : Fin cols) (row : Fin rows) :
    applyVec operator
        (a • basisKet cols left + b • basisKet cols right) row =
      a * operator row left + b * operator row right := by
  have h := congrFun (applyVec_twoBasisSuperposition operator a b left right) row
  simpa using h

                                                      
@[simp] theorem applyVec_zeroKet {α : Type u} [NonAssocSemiring α]
    {qubits : Nat}
    (operator : FiniteMatrix (gridSize qubits) (gridSize qubits) α) :
    applyVec operator (zeroKet qubits) =
      operator.col (zeroBasisIndex qubits) := by
  exact applyVec_basisKet operator (zeroBasisIndex qubits)

   
                                                                    
                                                        
  
theorem firstColumnMatches_iff_applyVec_zeroKet
    {α : Type u} [NonAssocSemiring α] {qubits : Nat}
    (operator : FiniteMatrix (gridSize qubits) (gridSize qubits) α)
    (target : StatePreparationTarget α qubits) :
    FirstColumnMatches operator target ↔
      applyVec operator (zeroKet qubits) = target.amplitudes := by
  constructor
  · intro firstColumn
    rw [applyVec_zeroKet]
    exact funext firstColumn
  · intro action row
    rw [applyVec_zeroKet] at action
    exact congrFun action row

   
                                                                               
                                                                              
                                                                               
  
structure ComplexStatePreparationCertificate (qubits : Nat) where
  target : StatePreparationTarget ℂ qubits
  gate : ComplexUnitaryGate qubits
  normalizationProof : target.normalization
  preparationProof :
    applyVec gate.matrix (zeroKet qubits) = target.amplitudes

namespace ComplexStatePreparationCertificate

                                                                                
def candidate (certificate : ComplexStatePreparationCertificate qubits)
    (circuit : Circuit) (schedule : LayeredCircuit) (resource : Resource)
    (auxiliaryQubits : Nat := 0) :
    StatePreparationCandidate ℂ qubits where
  target := certificate.target
  unitary := certificate.gate.matrix
  circuit := circuit
  schedule := schedule
  resource := resource
  auxiliaryQubits := auxiliaryQubits
  isUnitary :=
    certificate.gate.matrix ∈
      _root_.Matrix.unitaryGroup (Fin (gridSize qubits)) ℂ

   
                                                                             
                                                                      
                                
  
def verified (certificate : ComplexStatePreparationCertificate qubits)
    (circuit : Circuit) (schedule : LayeredCircuit) (resource : Resource)
    (auxiliaryQubits : Nat := 0) :
    VerifiedStatePreparation ℂ qubits where
  candidate :=
    certificate.candidate circuit schedule resource auxiliaryQubits
  normalizationProof := certificate.normalizationProof
  unitaryProof := certificate.gate.unitary
  preparationProof :=
    (firstColumnMatches_iff_applyVec_zeroKet
      certificate.gate.matrix certificate.target).mpr
        certificate.preparationProof

theorem preparesVector (certificate : ComplexStatePreparationCertificate qubits) :
    applyVec certificate.gate.matrix (zeroKet qubits) =
      certificate.target.amplitudes :=
  certificate.preparationProof

end ComplexStatePreparationCertificate
end ConcreteSemantics
end QuantumBlockEncoding

