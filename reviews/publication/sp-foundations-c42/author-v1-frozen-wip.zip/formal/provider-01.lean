import Std

   
                                    

                                                                              
                                                                                
                                                                               
                                                                   
  

namespace QuantumBlockEncoding

                                                  
abbrev Matrix (rows cols : Nat) (α : Type u) := Fin rows -> Fin cols -> α


                                                      
def gridSize (n : Nat) : Nat := 2 ^ n
end QuantumBlockEncoding

