import QuantumBlockEncoding.PrimitiveSemantics

   
                                        

                                                                             
                                                                          
                                                                            
                                    
  

namespace QuantumBlockEncoding

                                                                         
def primitiveBasisLEEquiv : (q : Nat) -> PrimitiveBasis q ≃ Fin (gridSize q)
  | 0 =>
      { toFun := fun _ => ⟨0, by decide⟩
        invFun := fun _ => Fin.elim0
        left_inv := fun bits => funext fun wire => Fin.elim0 wire
        right_inv := fun index => by fin_cases index; rfl }
  | q + 1 =>
      (Fin.consEquiv (fun _ : Fin (q + 1) => Fin 2)).symm
        |>.trans (Equiv.prodCongr (Equiv.refl (Fin 2)) (primitiveBasisLEEquiv q))
        |>.trans (Equiv.prodComm (Fin 2) (Fin (gridSize q)))
        |>.trans finProdFinEquiv
        |>.trans (finCongr (by simp [gridSize, pow_succ]))

@[simp] theorem primitiveBasisLEEquiv_zero_apply (bits : PrimitiveBasis 0) :
    (primitiveBasisLEEquiv 0 bits).val = 0 := by
  rfl

                                                                             
theorem primitiveBasisLEEquiv_succ_value (q : Nat)
    (bits : PrimitiveBasis (q + 1)) :
    (primitiveBasisLEEquiv (q + 1) bits).val =
      (bits 0).val + 2 *
        (primitiveBasisLEEquiv q (fun wire => bits wire.succ)).val := by
  rfl

                                                                       
theorem primitiveBasisLEEquiv_six_value (bits : PrimitiveBasis 6) :
    (primitiveBasisLEEquiv 6 bits).val =
      (bits 0).val + 2 * (bits 1).val + 4 * (bits 2).val +
      8 * (bits 3).val + 16 * (bits 4).val + 32 * (bits 5).val := by
  native_decide +revert

                                                                         
def primitiveBits2LE (index : Fin 4) : PrimitiveBasis 2
  | 0 => ⟨index.val % 2, by omega⟩
  | _ => ⟨(index.val / 2) % 2, by omega⟩

@[simp] theorem primitiveBasisLEEquiv_two_symm (index : Fin 4) :
    (primitiveBasisLEEquiv 2).symm index = primitiveBits2LE index := by
  fin_cases index <;> native_decide

                                                                      
                                            
@[simp] theorem primitiveBasisLEEquiv_two_symm_wire_zero
    (index : Fin (gridSize 2)) :
    ((primitiveBasisLEEquiv 2).symm index) (0 : Fin 2) =
      ⟨index.val % 2, by omega⟩ := by
  native_decide +revert

@[simp] theorem primitiveBasisLEEquiv_two_symm_wire_one
    (index : Fin (gridSize 2)) :
    ((primitiveBasisLEEquiv 2).symm index) (1 : Fin 2) =
      ⟨(index.val / 2) % 2, by omega⟩ := by
  native_decide +revert

                                                                               
                                                        
@[simp] theorem primitiveBasisLEEquiv_two_symm_0 :
    (primitiveBasisLEEquiv 2).symm
        (⟨0, by norm_num [gridSize]⟩ : Fin (gridSize 2)) =
      primitiveBits2LE (0 : Fin 4) := by native_decide
@[simp] theorem primitiveBasisLEEquiv_two_symm_1 :
    (primitiveBasisLEEquiv 2).symm
        (⟨1, by norm_num [gridSize]⟩ : Fin (gridSize 2)) =
      primitiveBits2LE (1 : Fin 4) := by native_decide
@[simp] theorem primitiveBasisLEEquiv_two_symm_2 :
    (primitiveBasisLEEquiv 2).symm
        (⟨2, by norm_num [gridSize]⟩ : Fin (gridSize 2)) =
      primitiveBits2LE (2 : Fin 4) := by native_decide
@[simp] theorem primitiveBasisLEEquiv_two_symm_3 :
    (primitiveBasisLEEquiv 2).symm
        (⟨3, by norm_num [gridSize]⟩ : Fin (gridSize 2)) =
      primitiveBits2LE (3 : Fin 4) := by native_decide

                                                                           
def primitiveBits2LEWithout (target : Fin 2) (index : Fin 4) : Nat :=
  match target.val with
  | 0 => index.val / 2
  | _ => index.val % 2

                                                                           
                             
def primitiveBits2LEGridWithout
    (target : Fin 2) (index : Fin (gridSize 2)) : Nat :=
  match target.val with
  | 0 => index.val / 2
  | _ => index.val % 2

@[simp] theorem splitPrimitiveWire_primitiveBits2LE_context_eq
    (target : Fin 2) (left right : Fin 4) :
    (splitPrimitiveWire target (primitiveBits2LE left)).2 =
        (splitPrimitiveWire target (primitiveBits2LE right)).2 ↔
      primitiveBits2LEWithout target left =
        primitiveBits2LEWithout target right := by
  native_decide +revert

@[simp] theorem splitPrimitiveWire_primitiveBasisLEEquiv_two_symm_context_eq
    (target : Fin 2) (left right : Fin (gridSize 2)) :
    (splitPrimitiveWire target ((primitiveBasisLEEquiv 2).symm left)).2 =
        (splitPrimitiveWire target ((primitiveBasisLEEquiv 2).symm right)).2 ↔
      primitiveBits2LEGridWithout target left =
        primitiveBits2LEGridWithout target right := by
  native_decide +revert

end QuantumBlockEncoding

