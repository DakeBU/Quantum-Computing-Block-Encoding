# Complete binder and definition audit

AUTHOR/WIP; RETROSPECTIVE_IMPLEMENTATION_INFORMED. This audits the exact current interfaces, not an earlier source seal. Source hypothesis means a premise of the new natural teaching contract, not a claim about any historical paper. Every explicit declaration is listed, with its complete source signature (or complete structure fields), in declaration-inventory.json. The 103 entries map to the anchors in natural-source.md; 98 public entries exactly match the existing checker-consumed generated source inventory and 5 private entries supplement it. There are no explicit instances in the three targets. Generated projections/recursors are not claimed as additional explicit source declarations. All original imports, options, local lets and proof text are retained in formal/target-*.lean.

## Audit rules and complete exceptions

For every entry in declaration-inventory.json, all explicit or implicit Nat dimensions, Fin indices, matrix/state/circuit/angle/table objects are TYPING formation/input data unless listed below. Constants and closed theorems have no external logical assumptions. Their stored proof fields are constructed internally, not added public hypotheses. Every source-facing object here is literal: none is characterized by choice, a quotient, an unspecified representative or an off-locus default. The inventory's exact source signature is the binder drill-down, not an elaborated signature claim. Existing global Mathlib typeclass instances supply C/R/Q algebra and finite sums; no target-level class instance is assumed as a physical certificate.

All 29 T declarations are closed. zeroIndex/oneIndex include formation proofs 0<2 and 1<2 (TYPING); the latter contains a native_decide source token. oneTarget and plusTarget's normalization fields are EXACTLY sum Complex.normSq(amplitude)=1. The source label is literal descriptive metadata with no logical force. pauliXGate/hadamardGate's unitary fields have the standard complex matrix unitaryGroup predicate. Their Certificate records supply that gate, the literal target and exact normalization/action proofs. Their verified wrappers choose the display circuit, singleton schedule, that circuit's Resource, and the default auxiliary count 0. There is no extra schedule validity, gate interpretation or resource-refinement premise or conclusion. The two cost records have exactly four fields, as displayed in T; all Nat values are literal. The two final certificate theorems are projections of preparationProof.

All 38 B declarations are closed EXCEPT selectSwapCleanTCount's three Nat arguments N,b,lambda (TYPING). That function assumes neither positivity nor power-of-two size nor bit precision; no mathematical premise is silently attached to its total Nat formula. All four Target records instantiate normalization to the actual squared-norm equation; all four Gate records supply actual complex unitarity; all four Certificate records supply the actual first-column action. bellAmplitude is a literal alias to the existing invSqrtTwo, not a separately assumed amplitude. The sparse matrix literal is the full eight-column completion of B4, not an identity extension. Matrix/state wildcard cases are exhausted by Fin 4 or Fin 8; no behavior at larger invalid indices is in the carrier.

The 36 P entries have the following exhaustive binder classes:

| Source declarations | All binders/fields and classification |
| --- | --- |
| evalPrimitiveCircuitLE; evalPrimitiveCircuitLE_unitary | implicit qubits:Nat, circuit:PrimitiveCircuit qubits: TYPING. No normalization/target hypothesis. |
| ExactPrimitiveStatePreparationRoute | qubits:Nat TYPING; target:StatePreparationTarget C qubits and circuit:PrimitiveCircuit qubits TYPING; normalizationProof:target.normalization SOURCE; preparationProof:applyVec(eval_LE circuit)(zeroKet qubits)=target.amplitudes SOURCE. These are hypotheses of the GENERIC record, not outputs of a universal compiler. |
| ExactPrimitiveStatePreparationRoute.cost; .unitary | implicit qubits:Nat TYPING; route:that complete record TYPING data whose proof fields remain SOURCE, as expanded above. Unitarity uses primitive semantics, not target.normalization. cost sets auxiliaryQubits=0 rather than reading a hidden workspace field. |
| private amplitudeRotation_eq_pythagorean | cosine,sine:R TYPING; lower:-1<=cosine SOURCE; upper:cosine<=1 SOURCE; sine_nonneg:0<=sine SOURCE; normalization:cosine*cosine+sine*sine=1 SOURCE. All four retained without weakening or erasure. |
| private cosine35,sine35,cosine513,sine513 | no binders, literal Q constants 3/5,4/5,5/13,12/13. |
| ryAngle35; ryAngle513 | closed literal ExactAngle constructors with internally supplied |r|<=1 TYPING domain witnesses; no unproved angle oracle. |
| ryAngleZero; standardRyMatrix_ryAngle35; standardRyMatrix_ryAngle513; standardRyMatrix_ryAngleZero | no binders; exact angle/matrix identities, including half-angle and sign. |
| primitiveLEBits | qubits:Nat,index:Fin(2^qubits) TYPING; inverse shared equivalence, not a new basis convention. |
| evalPrimitiveCircuitLE_append | implicit qubits:Nat,left/right:PrimitiveCircuit qubits TYPING; exact operator equality, chronological product order retained. |
| evalPrimitiveCircuitLE_singleton_ry_apply | implicit qubits:Nat,target:Fin qubits,angle:ExactAngle,row/column:Fin(2^qubits), all TYPING. No row-context equality is assumed: the conditional on it is in the conclusion. |
| evalPrimitiveCircuitLE_compileUniformlyControlledRy_apply | implicit qubits/controls:Nat,wires:Fin controls -> Fin qubits,target:Fin qubits,angles:PrimitiveBasis controls -> ExactAngle,row/column:Fin(2^qubits) TYPING; distinct:forall control,wires control != target SOURCE. No injectivity of wires is present; no context equality is a binder. |
| groverRudolphControlWire; groverRudolphControlWire_ne_target | closed map Fin 1->Fin 2 returning 1 and its theorem forall control,map(control)!=0; the control is universally quantified in the conclusion, not an external promise. |
| groverRudolphConstantAngles | assignment:PrimitiveBasis 1 TYPING, intentionally ignored; literal constant angle35. |
| groverRudolphTreeCircuit; groverRudolphFactorizedCircuit | closed typed lists; tree internally supplies the non-target theorem, not an additional source hypothesis. |
| groverRudolphConstantUcry_eval; groverRudolphTree_eval_eq_factorized; groverRudolphTree_evalLE_eq_factorized; groverRudolphFactorized_evalLE_eq_matrix | closed exact matrix equalities. The local lowMatrix/highMatrix are literal four-by-four matrices, and lowEval/highEval are internal proof ingredients, NOT public binders. |
| groverRudolphFactorized_prepares_target; groverRudolphTree_prepares_target | closed state-action equalities, supplied by operator equality AND B3's first-column theorem. |
| groverRudolphFactorizedRoute; groverRudolphTreeRoute | closed records supplying B3 normalization AND the appropriate circuit state-action theorem; their proof fields are dependencies, not extra assumptions. |
| groverRudolphFactorizedVerified_cost; groverRudolphTreeVerified_cost; groverRudolphFactorized_betterThan_tree | closed literal four-field cost equalities and strict lexicographic relation; no claim of global optimality or post-optimization cost. |

No RULED correction or EXCESS input is proposed for the new bounded original teaching contract. Historical paper premise correspondence is NOT audited or inferred from the benchmark names. STANDING conventions are finite complex matrices, the shared little-endian equivalence, the fixed half-angle RY sign convention and the literal resource accounting; they are expanded in F and Q, not hidden as additional theorem premises. A source-first reviewer must independently assess whether the natural contract and these classifications match.

## Shared API expansion, without strengthening

StatePreparationTarget(alpha,n) = {amplitudes:Fin(2^n)->alpha, normalization:Prop, source:String}. StatePreparationCandidate(alpha,n) = {target,unitary matrix,display circuit,schedule default [],resource,auxiliaryQubits default 0,isUnitary:Prop}. FirstColumnMatches(U,t) = forall row,U[row,0]=t.amplitudes[row]. preparesTarget is precisely FirstColumnMatches. VerifiedStatePreparation = {candidate,proof(candidate.target.normalization),proof(candidate.isUnitary),proof(candidate.preparesTarget)}.

ComplexUnitaryGate(n) = {matrix:Matrix Fin(2^n) Fin(2^n) C, proof(matrix in standard unitaryGroup)}. ComplexStatePreparationCertificate(n) = {target,gate,proof(target.normalization),proof(gate.matrix e0=target.amplitudes)}. Its candidate/verified methods do NOT demand a relation between their extra circuit/schedule/resource inputs and the matrix. This is an interface limitation, not an EXCESS hidden premise or a false target theorem.

ExactAngle.twiceArccosRational(r) carries |(r:R)|<=1 and evaluates to 2 arccos(r). Other constructors are rational, piRational, twiceArccosSqrtRational with 0<=r<=1, exact real, addition, negation and rational scaling. The circuit type admits only X,RY,RZ,CX; CX carries control!=target. Finitely many gate constructors and exact Real angle expressions do not supply finite-bit evaluation.

All concrete fixed examples have exact physical normalization. The generic route record retains target.normalization unchanged, even though primitive unitarity plus exact action could support an additional norm-preservation theorem; that additional theorem is not asserted as an existing target declaration.

## Typed gaps and trust boundary

G-DISPLAY: no proved display-IR evaluator/refinement connects X/H string circuits and supplied wrapper resources to their concrete matrices. This does not invalidate their matrix-action theorems.

G-SPARSE-COMMENT: sparseThreeMatrix's explanatory comment overstates identity-on-complement behavior; the exact literal column completion is retained. This is a source-comment mismatch, not a proof failure, code repair or changed target.

G-GENERAL-PAPERS: general Mottönen/Grover--Rudolph/Li--Luo/SelectSwap paper claims are outside these fixed examples and not imported as established results.

G-FINITE-BIT: angle evaluation, synthesis/rounding/error, Clifford+T, hardware connectivity, preprocessing and readout remain unproved here.

G-TRUST: lexical source tokens, imports and the supplied generated inventory are not elaborated proof terms or an axiom census. No Lean or native execution occurred in this extraction. No source token is assigned accepted=true; actual observation must be separately bound to the frozen inputs.
