# Shared finite-SP foundation packet

State: AUTHOR/WIP, frozen for independent review. Provenance: RETROSPECTIVE_IMPLEMENTATION_INFORMED. Not an accepted publication, pre-proof source seal, reviewer result, registry entry, historical paper reproduction, new theorem, or production change.

Objective / direction fingerprint: remove repeated source-context reconstruction for the actual TextbookStatePreparation -> StatePreparationBenchmarksCoreFixed -> StatePreparationPrimitiveRoutes chain by extracting one shared finite-matrix/first-column/LE primitive contract and three complete teaching lessons. Reuse the existing ConcreteSemantics, PrimitiveBasisLE and UniformlyControlledRy foundations.

Mathematical delta: a reconstructible source contract for the two one-qubit examples, four literal benchmark completions, separate total Nat count example, generic route interface, exact Pythagorean rotations, LE lift/compiler entry semantics, both product-state primitive routes and their unsimplified literal costs. No additional proof result is claimed.

Effect on root frontier: supplies bounded inputs for two genuinely independent tracks; no production, acceptance or historical audit status is advanced by this author packet.

## Exact next-track visibility

1. Source-first reconstruction/topology track: receive ONLY natural-source.md as its mathematical source. Reconstruct statements, proof/construction AND-tails, literal matrices, generic Prop limitations, OR-routes and source coverage without target Lean, the author's graph, binder classifications or this handoff. Source provenance may be stated honestly as retrospective, never pre-proof. Bind the exact natural source digest from seals.json. The intended result is independent reconstruction, not an author-desired verdict.
2. Source-blind formal-decoder track: receive ONLY the formal/ directory's fourteen Lean text files plus extents.json. Do not send natural-source.md, binder-audit.md, author inventory/classifications, graph/coverage, this handoff, trust-signals, raw-input seals, author summaries, prior verdicts or natural-source title. Do not let that worker browse the original repository, follow source links/imports into raw files, or infer a desired verdict. The folder contains original formal identifier/String literals as code; these were not renamed, elided or semantically changed. Comments were replaced by whitespace and line endings normalized. Original imports remain literal imports; provider excerpts disclose original line extents and synthetic namespace closers. This is a formal reading packet, not a new standalone Lean build.
3. A later distinct anti-anchored reviewer may compare the exact pinned natural source, independent source-first reconstruction, exact formal packet and independent formal reconstruction, without an inherited author verdict. Do not fabricate identities, acceptance JSON or registry bindings.

## Coverage and seals

Three whole targets: 196/342/316 original lines, respectively. Their exact raw hashes are recorded in raw-input-seals.json, and the complete code after comment masking is in formal/target-01.lean through target-03.lean. Bounded necessary provider context lives in formal/provider-01.lean through provider-11.lean; extents.json preserves imports, original extents and any synthetic namespace closers. Original whole supplier raw hashes are among the 207 input seals.

declaration-inventory.json contains complete lexical source signatures and structure fields for ALL explicit declarations: 29 + 38 + 36 = 103, including five private helpers. The 98 nonprivate entries agree exactly with the existing generated web/library/declarations.json source/fullName sets consumed by check_research_publications.py. No explicit target instance is omitted; none is present. This is not elaborated compiler output or an inventory of all generated kernel projections. Private source names are not represented as observed private kernel names. Source coverage is exhaustive over every maximal nonblank source block (including formulas), with declaration-to-lesson drill-down.

raw-input-seals.json pins all 142 production and 60 test raw Lean files plus lean-toolchain, lake-manifest.json, lakefile.lean, QuantumBlockEncoding.lean and Tests.lean. seals.json pins the final packet artifacts and stores separately labelled aggregate raw-input and formal-packet digests. These digests are content seals, not verifier/scoring changes or an assertion of scientific correctness.

## Preserved cautions

- Generic normalization/isUnitary Props remain actual arbitrary stored propositions; only the explicitly concrete fixed instantiations have the physical norm/unitarity meaning. The generic primitive route preserves target.normalization.
- Textbook wrappers carry concrete matrix proofs but permit unrelated display circuit/schedule/resource arguments. No string-circuit evaluator or resource refinement is asserted.
- sparseThreeMatrix has exact columns 3=e1 and 4=e3, so the explanatory "identity on complement" comment is not literal. The packet preserves the matrix and exposes the comment mismatch; no repair is proposed.
- The tree emits RY1(theta),RY0(theta),CX,RY0(0),CX. The zero rotation and cancelling CX pair remain charged. Literal costs are (0,2,1,0) and (0,5,4,0), tuple order auxiliary/gates/depth/oracles.
- Native-decision tokens are only pending-observation lexical signals; neither a kernel axiom census nor a global upstream ban follows. No accepted trust verdict is authored.
- Exact Real rotations do not establish finite-bit angle generation, Clifford+T costs, numeric error, hardware routing or general named-paper algorithm closure.

## Process and ownership

Files changed: only new private scratch files in this package. No network, Git, Lean, native execution, production/config/registry/source-catalog edits or child agents. Parent reported the synchronized contribution checkpoint and prior build history; the author performed no fresh build or inherited proof-input gate decision. The original raw inputs were hashed before/after the extraction; equality observations, not a new compilation, are recorded in seals.json.

Process-memory IDs consulted: QBE-PM-LOW-TOKEN-CONTROL-PLANE, QBE-PM-DENSE-CHECK-SMALL-INSTANCE, QBE-PM-VERIFIER-SEMANTIC-LEVEL; QBE-NK-QISKIT-ENV-PREFLIGHT was read but is not an invoked verification route.

Failure class: NONE for packet extraction. Typed residual/source gaps are G-DISPLAY, G-SPARSE-COMMENT, G-GENERAL-PAPERS, G-FINITE-BIT, G-TRUST. They do not refute the current closed formal equalities. Salvage: all 103 explicit declaration contracts retained, with shared substrate reuse; no failed proof fragment promoted or discarded.

Parallel admission: this author's direction was parent-assigned and distinct from independent source/formal tracks; no children. Common-blind-spot review: PENDING, especially bit order, half-angle sign, generic Prop normalization, sparse complementary columns, wrapper/circuit linkage and literal-versus-optimized costs.

Default reader construction: factorized product circuit is the simpler matched-target example, with fewer literal gates; this is pedagogical author guidance, NOT a fresh independently verified comparator verdict. The tree remains an explicit OR-route with its full prerequisites. The proof implementation obtains tree action through operator equality with the factorized circuit; the alternative physical circuit does not imply an independent implementation proof.

Purification/Exposition Seal: PENDING. The compressed source spine reuses existing primitives and exposes all remaining boundaries, but independent review, actual trust observation and integration gates are required before reader-facing completion.

Recommended merge: none yet. Stop at this frozen packet. Next action is independent source-first and formal-only reconstruction, then a distinct comparison. Exact safe file allowlist is in allowlist.json. No accepted reviewer, registry candidate or final publication binding is present.
