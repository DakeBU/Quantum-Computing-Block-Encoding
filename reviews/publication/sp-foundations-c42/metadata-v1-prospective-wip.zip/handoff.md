# Finite-SP prospective metadata handoff

AUTHOR/WIP_PROSPECTIVE. This is a mechanical continuation by the original sp_foundations_source_author_c40 author, not an independent source/decoder/reviewer. Historical formalizer is UNKNOWN. No independent source-first reconstruction, decoder reconstruction, reviewer output or identity was read or authored. No accepted evidence, registry/catalog edit, scientific target change or production theorem is supplied.

## Deliverables

prospective-records.json contains three whole-module prospective records: TextbookStatePreparation (29 public declarations), StatePreparationBenchmarksCoreFixed (38), StatePreparationPrimitiveRoutes (31). Every public declaration has an individual source-obligation/prerequisite mapping. The five private PrimitiveRoutes helpers remain fully audited in the frozen original author package; current records reference that exact audited material rather than repeat its formal context/history.

sources-overlay.json proposes the legal source ID aspbe-local-finite-sp-foundations-v1, official repository HTTPS URL, primary-text-checked status, and an explicit AUTHOR/WIP formal_status with independent comparison/gates PENDING. The original teaching contract is retrospective implementation-informed, not historical source-first or pre-proof work. General Mottönen/Grover--Rudolph/Li--Luo/SelectSwap algorithms are not claimed formalized.

The planned lesson path is docs/lessons/finite-sp-foundations-v1.md. It must receive the EXACT frozen bytes of the original author's natural-source.md, SHA256 7472eeb8fefe3fffdf662b38751e36401c0b2f770b25a149ae6bcc9f6bc49c79. No lesson copy was created or edited here. Original author references use the logical hermite-export-work/sp-foundations-c40-author/ prefix; those are evidence references, not a claim the files are already installed inside the production repository.

The records preserve all four graph views and point to the exact sealed author graph for complete AND-tails and OR alternatives. Module imports/ownership are not elaborated theorem dependencies; no certified categorical functor is claimed. Existing ConcreteSemantics, PrimitiveBasisLE, UniformlyControlledRy and the shared canonical SP/BE substrate are reused without a new API or foundation. No false SP-alone-to-BE implication is added.

## Actual bounded checks

compute-prospective.py is a read-only runner (stdout only; invoke with Python -B). It imported the unmodified website/scripts/check_research_publications.py and actually called its binding_digest, rather than copying old binding hashes. A two-path local_file facade maps only:

- docs/lessons/finite-sp-foundations-v1.md -> the exact frozen original natural-source.md;
- website/research/sources.json -> the proposed single-row sources-overlay.json.

Every other raw input is read from the actual checkout through the original path helper. The digest function and admission validator were NOT patched. The actual digest binds the eleven payload fields, target module raw, lesson raw, toolchain/manifest raw, all 202 production/test ambient raws and the whole selected source row with the existing algorithm. Per-record tracing observed 206 raw-byte reads (the target module is read directly and again in the ambient corpus). The three extra root inputs lakefile.lean, QuantumBlockEncoding.lean and Tests.lean are separately included in the complete 207 before/after equality pins, not misrepresented as extra direct inputs of the unchanged binding algorithm.

Actual prospective binding digests:

- TextbookStatePreparation: 1a7c30365c3233658a67dd0436ca2e755d5eecabbd6df878a40d0ce151376ce7
- StatePreparationBenchmarksCoreFixed: a39b18fec1a0e3aaa4d85a61724cca07fc675a4491da3a55f302958cd7baa8ce
- StatePreparationPrimitiveRoutes: 0797d5bf51da99ef844e01e7d2ed733258e5da42df964fb54ed6376b25b21672

The runner repeated the actual function, verified equality with the hashes in the prospective records, and verified that an in-memory change to the selected source row changes the digest. Therefore ANY later source-row change (including formal_status), payload/graph/lesson/source/context change requires recomputation and appropriately rebound independent evidence; these are not reusable final admission certificates.

The current research_atlas.validate_catalog accepted the proposed single source row inside a bounded empty-other-catalog schema fixture. Invalid underscore ID, status, HTTP URL and missing formal_status probes were rejected by that original validator. This is a source-row schema test, NOT a full production atlas/catalog integration check. No validator was weakened.

All 207 actual proof/config inputs matched the original frozen author pins before AND after. All 25 original packet files matched their frozen hashes before AND after. The existing generated declaration inventory matched all three exact public sets; private counts and audit references were retained. Source/manifest/toolchain/raw-input equality is evidence of unchanged inputs, not a fresh Lean/kernel gate. The parent supplied checkpoint label 932c109; this author did not resolve or modify Git state.

The actual unchanged validate_record rejected EACH prospective record with "publication lacks decoder_evidence" because decoder_evidence and reviewer_evidence remain null. All other independent evidence paths remain null/PENDING. This is the expected fail-closed outcome; the bounded structural checks do not replace source fidelity or independently accepted review.

## Scientific boundaries retained

The string-based X/H display Circuit, supplied schedules/resources and generic wrapper are not a proved scored-circuit refinement of their concrete matrices. Generic target.normalization/isUnitary Props retain their literal API meaning; only the explicitly concrete fixed instantiations carry physical normalization/unitarity. The sparse completion retains ALL eight columns, especially u3=e1 and u4=e3, rather than claiming literal identity on complementary input columns. The typed primitive product routes retain little-endian order, exact RY half-angle signs, chronological products, constant-table UCRY semantics and unsimplified angle syntax/instructions. Costs remain exact-real ideal-gate/depth records (factorized 2 gates/depth 1 versus tree 5/depth 4), not finite-bit preprocessing, Clifford+T, hardware routing, general-method complexity or a global optimum. Native-decision tokens remain pending actual observation, not an axiom census or blanket upstream rejection.

## Handoff status

Mathematical delta: NONE beyond the frozen author contract; this stage only adds complete prospective mappings and mechanically computed bindings. Failure class: NONE for this metadata stage; admission intentionally remains unavailable pending independent evidence. Source gaps, common-blind-spot review and purification/Exposition Seal remain exactly as in the original packet.

Safe output allowlist: allowlist.json. All new files are confined to this metadata package. No Git, network, Lean/native execution, production/config/registry/catalog writes or children. Do not merge these as accepted records. Keep the original 25 files frozen; continue independent tracks elsewhere, then reconcile exact artifacts under the unchanged publication protocol. STOP at this sealed usable metadata packet.
