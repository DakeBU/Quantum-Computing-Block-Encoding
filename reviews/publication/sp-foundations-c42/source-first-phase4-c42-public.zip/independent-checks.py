"""Read-only bounded reviewer diagnostics. No author checker scripts are executed.

Raw production Lean/config bytes are used only by hashes and the authorized
original binding algorithm; they are never decoded as additional math sources.
Header/body comparison uses the already released comment-masked formal packet.
All results go to stdout. Run with Python -B to suppress bytecode writes.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def tokens(text):
    """Independent tiny lexical normalizer for these released Lean commands."""
    out, i = [], 0
    while i < len(text):
        if text[i].isspace():
            i += 1
            continue
        if text.startswith("--", i):
            end = text.find("\n", i)
            i = len(text) if end < 0 else end + 1
            continue
        if text.startswith("/-", i):
            level, i = 1, i + 2
            while level:
                assert i < len(text), "unterminated comment"
                if text.startswith("/-", i):
                    level, i = level + 1, i + 2
                elif text.startswith("-/", i):
                    level, i = level - 1, i + 2
                else:
                    i += 1
            continue
        begin = i
        if text[i] == '"':
            i += 1
            while True:
                assert i < len(text), "unterminated string"
                if text[i] == "\\":
                    i += 2
                elif text[i] == '"':
                    i += 1
                    break
                else:
                    i += 1
        elif text[i].isalnum() or text[i] == "_":
            i += 1
            while i < len(text) and (text[i].isalnum() or text[i] in "_'."):
                i += 1
        elif text.startswith(":=", i) or text.startswith("=>", i):
            i += 2
        else:
            i += 1
        out.append((text[begin:i], begin, i))
    return out


def separator(text):
    stack, pairs = [], {"(": ")", "[": "]", "{": "}", "⟨": "⟩", "⦃": "⦄"}
    for value, begin, end in tokens(text):
        if value in pairs:
            stack.append(pairs[value])
        elif stack and value == stack[-1]:
            stack.pop()
        elif not stack and value in (":=", "where"):
            return begin, end, value
    raise AssertionError("no top-level body separator")


def import_exact(path, name):
    namespace = {"__file__": str(path), "__name__": name}
    exec(compile(path.read_text(encoding="utf-8"), str(path), "exec"), namespace)
    return namespace


def main():
    parser = argparse.ArgumentParser()
    for name in ("repo", "successor", "original", "phase2", "phase3"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--stage1-only", action="store_true")
    args = parser.parse_args()
    repo, packet = args.repo.resolve(), args.successor.resolve()
    final = load(packet / "final-seal.json")
    assert sha((packet / "final-seal.json").read_bytes()) == "ae171c7e679d3dbbfd2289dbde73c7c1aaa0feda3111b1a9bc80dc1072d2feb9"
    for pin in final["artifacts"]:
        assert sha((packet / pin["path"]).read_bytes()) == pin["sha256"]
    inv = load(packet / "declaration-inventory-v2.json")["declarations"]
    ledger = load(args.phase2 / "declaration-audit.json")
    old_inv = load(args.original / "declaration-inventory.json")["declarations"]
    diff = load(packet / "inventory-difference-map.json")["differences"]
    old_by_name = {row["source_name"]: row for row in old_inv}
    by_source = list(dict.fromkeys(row["source"] for row in inv))
    formal_lines = {module: (args.original / "formal" / f"target-{n+1:02}.lean").read_text(encoding="utf-8").splitlines()
                    for n, module in enumerate(by_source)}
    body_checks = []
    for entry in inv:
        name, command = entry["source_name"], entry["source_command_raw"]
        old = old_by_name[name]
        assert (entry["line_start"], entry["kind"], entry["private"]) == (old["line_start"], old["kind"], old["private"])
        for key, value in old.items():
            if key not in ("signature_or_structure_fields", "line_end"):
                assert entry[key] == value, "old classification/identity field changed: " + name + ":" + key
        own_module = ledger["modules"][by_source.index(entry["source"])]["rows"]
        own = next(row for row in own_module if row[0] == name.rsplit(".", 1)[-1])
        assert own[1] == entry["line_start"]
        assert command == entry["header_raw"] + entry["body_separator"] + entry["body_raw"]
        begin, end, sep = separator(command)
        assert (command[:begin], sep, command[end:]) == (entry["header_raw"], entry["body_separator"], entry["body_raw"])
        signature = command.rstrip() if entry["kind"] == "structure" else entry["header_raw"].rstrip()
        assert signature == entry["signature_or_structure_fields"]
        if entry["kind"] == "structure":
            assert entry["structure_fields_raw"] == entry["body_raw"]
        else:
            assert entry["structure_fields_raw"] is None
        selected = "\n".join(formal_lines[entry["source"]][entry["line_start"]-1:entry["line_end"]])
        assert [x[0] for x in tokens(command)] == [x[0] for x in tokens(selected)], "formal body token mismatch: " + name
        assert sha(command.encode()) == entry["source_command_raw_sha256"]
        change = next(row for row in diff if row["name"] == name)
        assert change["old_signature_or_structure_fields"] == old["signature_or_structure_fields"]
        assert change["new_signature_or_structure_fields"] == signature
        body_checks.append({"name": name, "header_separator_body_formal_tokens_equal": True})
    assert len(body_checks) == 103 and sum(row["private"] for row in inv) == 5
    frozen_raw = {pin["path"]: pin["sha256"] for pin in load(packet / "bounded-checks-v2.json")["raw_207_before_after"]}
    assert all(row["source_module_raw_sha256"] == frozen_raw[row["source"]] for row in inv)
    counts = {key: sum(row["change_class"] == key for row in diff)
              for key in ("COST_RECORD_IN_PROPOSITION", "WHERE_RECORD_HEADER_BODY_SEPARATED", "UNCHANGED_SIGNATURE")}
    assert list(counts.values()) == [4, 21, 78]
    old_source = (args.original / "natural-source.md").read_bytes()
    new_source = (packet / "natural-source-v2.md").read_bytes()
    proposal = load(packet / "editorial-proposal.json")
    finding = next(row for row in load(args.phase3 / "findings-and-erratum.json")["findings"] if row["id"] == "E-BELL-COUNT")
    assert proposal["exact_before"] == finding["exact_before"] and proposal["exact_after"] == finding["exact_after"]
    assert old_source.count(proposal["exact_before"].encode()) == 1
    assert new_source == old_source.replace(proposal["exact_before"].encode(), proposal["exact_after"].encode(), 1)
    graph = load(packet / "source-and-graph-v2.json")
    prior_graph = load(args.original / "source-and-graph.json")
    assert [n for n in graph["nodes"] if n["kind"] == "SOURCE_GAP"] == [n for n in prior_graph["nodes"] if n["kind"] == "SOURCE_GAP"]
    assert len(graph["source_construction_hyperedges"]) == 37
    coverage = load(packet / "source-coverage-v2.json")
    source_lines = new_source.decode().split("\n")
    for number, line in enumerate(source_lines, 1):
        if line.strip():
            assert sum(r["lines"][0] <= number <= r["lines"][1] for r in coverage["regions"]) == 1
    assert len(coverage["regions"]) == 41 and coverage["source_sha256"] == sha(new_source)
    if args.stage1_only:
        print(json.dumps({"scope": "Stage1-only frozen source/inventory/body recheck; no current catalog or later metadata exposure",
            "commands": len(body_checks), "private": 5, "changes": counts,
            "all_old_identity_and_binder_classification_fields_unchanged": True,
            "all_header_body_and_structure_fields_match_released_formal_tokens": True,
            "all_source_module_hash_fields_match_the_observed207_manifest": True,
            "exact_single_editorial_replacement": True, "source_regions": 41,
            "source_gap_nodes_preserved": True, "source_hyperedges": 37}, indent=2))
        return

    observed = load(packet / "bounded-checks-v2.json")
    raw_pins = observed["raw_207_before_after"]
    allowed_raw = {(repo / pin["path"]).resolve(): pin for pin in raw_pins}
    assert len(allowed_raw) == 207
    raw_before = []
    for pin in raw_pins:
        raw = (repo / pin["path"]).read_bytes()
        assert len(raw) == pin["bytes"] and sha(raw) == pin["sha256"]
        raw_before.append(pin)
    checker_path = repo / "website/scripts/check_research_publications.py"
    atlas_path = repo / "website/scripts/research_atlas.py"
    checker_hash, atlas_hash = sha(checker_path.read_bytes()), sha(atlas_path.read_bytes())
    assert checker_hash == final["actual_official_checker_sha256"]
    assert atlas_hash == final["actual_official_atlas_sha256"]
    checker = import_exact(checker_path, "phase4_original_checker")
    atlas = import_exact(atlas_path, "phase4_original_atlas")
    records = load(packet / "prospective-records-v2.json")["records"]
    overlay = load(packet / "sources-overlay-v2.json")
    source_row = overlay["sources"][0]
    current_sources_path = repo / "website/research/sources.json"
    generated_path = repo / "web/library/declarations.json"
    current_sources = load(current_sources_path)
    generated = load(generated_path)["declarations"]
    assert source_row["id"] not in {s["id"] for s in current_sources["sources"]}
    minimal = lambda s: {"sources": {"schema_version": 1, "sources": [s]},
        "atlas": {"schema_version": 1, "domains": [], "families": [], "hyperedges": [], "contributions": []},
        "wiki": {"schema_version": 1, "routes": []}}
    atlas["validate_catalog"](minimal(source_row))
    schema_negative = {}
    for label, key, value in (("bad-id", "id", "Bad_ID"), ("bad-status", "status", "accepted"),
                              ("http", "url", "http://example.invalid"), ("missing-formal-status", "formal_status", None)):
        bad = copy.deepcopy(source_row)
        bad[key] = value
        try:
            atlas["validate_catalog"](minimal(bad))
        except ValueError as error:
            schema_negative[label] = str(error)
        else:
            raise AssertionError("negative schema accepted")
    module_set = {r["module"] for r in records}
    actual_inventory = {r["fullName"]: r for r in generated if r.get("source") in module_set}
    real_local, real_load = checker["local_file"], checker["load"]
    lesson = "docs/lessons/finite-sp-foundations-v2.md"
    def virtual_local(root, name):
        assert root.resolve() == repo
        if name == lesson:
            return packet / "natural-source-v2.md"
        if name == "website/research/sources.json":
            return packet / "sources-overlay-v2.json"
        path = real_local(root, name)
        assert path.resolve() in allowed_raw, "unapproved binding read: " + name
        return path
    checker["local_file"] = virtual_local
    ambient = [path for directory in ("QuantumBlockEncoding", "ABEISTests")
               for path in sorted((repo / directory).rglob("*.lean"))]
    assert len(ambient) == 202 and all(path.resolve() in allowed_raw for path in ambient)
    keys = ("module", "source_id", "source_statement", "source_anchor", "lesson_path", "declarations", "obligation_map", "assumption_deltas", "graph_contribution", "formalizer", "residual_boundary")
    binding_results = []
    real_read_bytes = Path.read_bytes
    trace = []
    def guarded_read_bytes(path):
        resolved = path.resolve()
        assert resolved in allowed_raw or resolved == (packet / "natural-source-v2.md").resolve(), "unapproved raw binding read"
        data = real_read_bytes(path)
        trace.append((resolved, sha(data)))
        return data
    for record in records:
        actual = {name for name, row in actual_inventory.items() if row["source"] == record["module"]}
        assert set(record["declarations"]) == actual and len(record["declarations"]) == len(actual)
        assert actual == {row["source_name"] for row in inv if row["source"] == record["module"] and not row["private"]}
        assert all(not actual_inventory[name].get("openProof") and not actual_inventory[name].get("experimental") for name in actual)
        mapped = set()
        for obligation in record["obligation_map"]:
            assert obligation["kind"] in ("proof-edge", "prerequisite") and obligation["source_obligation"] and obligation["lesson_anchor"]
            assert set(obligation["declarations"]) <= actual
            mapped.update(obligation["declarations"])
        assert mapped == actual
        assert all(d["classification"] in checker["CATEGORIES"] and d["classification"] != "unresolved"
                   and all(d.get(k) for k in ("source", "formal", "explanation")) for d in record["assumption_deltas"])
        contribution = record["graph_contribution"]
        assert set(contribution["classes"]) <= checker["CLASSES"]
        assert {"declaration:" + n for n in actual} <= set(contribution["node_ids"])
        assert record["decoder_evidence"] is None and record["reviewer_evidence"] is None and record["formalizer"] == "UNKNOWN"
        def inspect_references(obj):
            if isinstance(obj, dict):
                if "logical_reference" in obj and "sha256" in obj:
                    prefix = "hermite-export-work/sp-foundations-c42-author-successor/"
                    if obj["logical_reference"].startswith(prefix):
                        relative = obj["logical_reference"][len(prefix):]
                        assert "/" not in relative and "\\" not in relative
                        assert sha((packet / relative).read_bytes()) == obj["sha256"]
                for value in obj.values():
                    inspect_references(value)
            elif isinstance(obj, list):
                for value in obj:
                    inspect_references(value)
        inspect_references(record)
        trace.clear()
        Path.read_bytes = guarded_read_bytes
        try:
            official = checker["binding_digest"](repo, record)
        finally:
            Path.read_bytes = real_read_bytes
        assert len(trace) == 206
        canonical = lambda obj: json.dumps(obj, sort_keys=True, ensure_ascii=False).encode()
        independent = hashlib.sha256(canonical({k: record.get(k) for k in keys}))
        for name in (record["module"], lesson, "lean-toolchain", "lake-manifest.json"):
            independent.update(name.encode())
            independent.update((packet / "natural-source-v2.md" if name == lesson else repo / name).read_bytes())
        for path in ambient:
            independent.update(path.relative_to(repo).as_posix().encode())
            independent.update(path.read_bytes())
        independent.update(canonical(source_row))
        assert independent.hexdigest() == official == record["binding_sha256"]
        changed_row = copy.deepcopy(source_row)
        changed_row["title"] += " [reviewer in-memory probe]"
        checker["load"] = lambda root, name: {"sources": [changed_row]} if name == "website/research/sources.json" else real_load(root, name)
        try:
            assert checker["binding_digest"](repo, record) != official
        finally:
            checker["load"] = real_load
        try:
            checker["validate_record"](repo, record, actual_inventory)
        except ValueError as error:
            rejection = str(error)
            assert "publication lacks decoder_evidence" in rejection
        else:
            raise AssertionError("pending record unexpectedly admitted")
        binding_results.append({"module": record["module"], "public_declarations": len(actual), "binding_sha256": official,
            "official_equals_independent_replay": True, "raw_reads": len(trace), "full_source_row_sensitive": True,
            "actual_admission_result": rejection})
    for pin in raw_before:
        assert sha((repo / pin["path"]).read_bytes()) == pin["sha256"]
    assert checker_hash == sha(checker_path.read_bytes()) and atlas_hash == sha(atlas_path.read_bytes())
    print(json.dumps({"scope": "Independent read-only bounded diagnostics, not Lean/compiler/TCB or publication admission",
        "author_scripts_executed": False, "successor_seal_artifacts_checked": 18,
        "headers_and_complete_bodies_checked": len(body_checks), "private": 5, "signature_changes": counts,
        "formal_token_comparison": "all103 commands match released comment-masked formal code; raw production mathematical text not decoded",
        "raw_byte_offset_limit": "Original raw module offsets not independently sliced under hash-only scope; command hashes/reassembly, formal line/token equality and current module raw hashes independently checked",
        "source_single_proposed_replacement_only": True, "source_v2_sha256": sha(new_source),
        "old_declaration_classifications_and_identity_fields_unchanged": True,
        "all_successor_logical_reference_hashes_in_records_checked": True,
        "source_regions": 41, "hyperedges": 37, "typed_gap_nodes_equal_original": True,
        "raw207_current_equal_before_after": True, "raw202_ambient_paths": len(ambient),
        "checker_sha256": checker_hash, "atlas_sha256": atlas_hash,
        "generated_inventory_sha256": sha(generated_path.read_bytes()), "current_source_catalog_sha256": sha(current_sources_path.read_bytes()),
        "single_source_row_schema": "PASS actual validate_catalog with empty other catalogs; not full catalog validation",
        "negative_schema_probes": schema_negative, "prospective_source_id_absent_current_catalog": True,
        "bindings": binding_results,
        "original_algorithm_omits_three_extra_configs": "lakefile.lean, QuantumBlockEncoding.lean, Tests.lean are in207 equality pins, not directly hashed by binding_digest",
        "new_metadata_separation_finding": graph["comparison_object_separation"],
        "per_declaration_header_body_checks": body_checks}, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
