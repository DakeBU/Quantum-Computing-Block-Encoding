# Phase4 exact successor review

Reviewer `/root/sp_foundations_source_first_c41`. This is a formal-exposed, retrospective successor review, not a new blind decoder run, historical source-first reconstruction or pre-proof seal. All v1 artifacts and the three earlier review phases remain immutable. The earlier author-evidence verdict `WITHHELD_CHANGES_REQUIRED` is not overwritten.

## Judgment

The 103-header/body repair, all mathematical source/graph repairs, full source coverage, and exact minimal Bell editorial successor pass this independent recheck. No scientific target, premise, matrix, gate order, sign, phase, state-action statement or resource tier changed.

The WHOLE frozen successor is still **CHANGES REQUIRED, limited to stale version/object-separation metadata**. In the exact graph `1f02a749ca7e3405d397ed5177b703208ee40fb343f843f862bb3f0160e90f21`, `comparison_object_separation.source` remains `natural-source.md`, while the graph's actual top-level source is `natural-source-v2.md`. Its `proposed_repair` still says `NONE; exact code unmodified...`, without identifying the explicit Bell editorial proposal and versioned graph/inventory repairs. This is not a new mathematical gap, but it fails to distinguish original source, successor source, disclosed discrepancies and exact proposed editorial repair in the required four-object provenance view. A successor should explicitly label v1 as prior, v2 as current, and reference the exact proposal; no production Lean correction is implied.

This metadata defect must not be silently fixed in place. The bound `graph_contribution` contains this graph's hash and references. A versioned correction with consistent references requires new exact prospective binding digests, then separate review of those bytes. The later parent metadata-only successor has NOT been read or approved here. The final decoder opaque binding JSON is also unreleased/unread.

## Exact input and stage order

The authorized successor final seal is `ae171c7e679d3dbbfd2289dbde73c7c1aaa0feda3111b1a9bc80dc1072d2feb9`; all 18 listed artifact bindings checked. Its earlier stage1 seal `3e06dc4059b9f7c75fc414a1640ea5a6d34bbee8702f603eb48184521cd5b7d5` binds the source/inventory/graph repair before prospective metadata. This sequencing is consistent with the two content seals, but hashes alone do not establish an externally trusted timestamp or honest independence.

The 19-file author allowlist was respected. Author diagnostic scripts were read for inspection, not executed. The reviewer independently compared the new complete commands with the previously released actual formal packet and own phase2 ledger. Parent separately authorized reading the actual publication-checker and atlas implementations, hash-only access to exactly 207 pinned raw paths, and the generated declaration inventory/source catalog needed for schema checks. No additional natural/math source content was decoded from production files.

## All 103 declarations and fields

All 29 textbook, 38 benchmark and 36 primitive-route commands, including 5 private, preserve identity/kind/privacy/start line and the earlier binder/definition classifications. Every command's header+separator+body reassembles losslessly; an independent small delimiter scanner selects the actual top-level separator, not an inner record-field `:=`. Complete command token sequences, including all proof bodies, local definitions and structure fields, agree with the previously released comment-masked formal line slices. Source-command hashes agree. The raw production module hashes also agree with the frozen current pins.

The four theorem conclusions now retain the entire four-field cost record. The 21 ordinary record-valued definitions now end their headers before top-level `where`, with the full field assignments in `body_raw`; the route structure separately retains all four structure fields. The other 78 signature strings are unchanged. Old truncated strings remain in a difference map rather than being erased. Local `lowMatrix/highMatrix`, `lowEval/highEval`, private real/rational helpers and the full sparse completion remain unchanged.

The independent check is bounded, not a general Lean parser. Under the hash-only production scope it did not slice original raw-module byte offsets to rederive the author's raw offsets. Instead it checked independent header/body splitting, command hashes/reassembly, released-formal line/token equality, exact old-ledger identity and current whole-module raw hashes. Author claims about independent scanners/fixtures remain author diagnostics, not substituted reviewer proof or elaboration.

## Source, definition, seven-slot and graph recheck

Raw v2 source bytes are EXACTLY v1 with the one independently proposed Bell count sentence replaced once; all other bytes agree. The new hash is `286c030e78ad180e74335f8c8543da2aad5dcff81a2797c92215f13773466cc0`. Therefore all previously reviewed mathematics, generic Prop limitations, literal definition carriers, sparse permutation completion, total Nat zero-division behavior, exact representatives and error/resource boundaries are preserved. The standalone exact-proposal minimality judgment is `editorial-minimality-review.json`, restricted to this editorial change and not whole-packet admission.

All 41 maximal nonblank regions still have exactly one disposition and the current source hash. All 103 declarations map to their source nodes. All five typed gap nodes are preserved literally. The prior 16 edge-review responses were independently checked against the actual 37 successor hyperedges, not accepted merely because an author response exists.

The source tensor/direct norm and unitarity alternatives are now separate complete AND routes feeding OR aggregators. Their complete tensor/column prerequisites remain visible. Tensor proofs are explicitly source mathematics, not falsely advertised as the finite Gram Lean implementation. The generic four-premise rotation identity, fixed35/fixed513 and zero-angle branches are separated; unused513/zero data are not forced into product preparation.

UCRY now exposes the zero-control singleton/lift base, exact half-angle table evaluation, rotation-addition and X-conjugation, consistent unchanged control context including repeated controls, both tail induction hypotheses, the recursive theorem, and the LE consumer transport. The factorized full operator bridge is distinct from B3 first-column/target action; tree action uses full tree=factorized operator equality AND factorized action. Each route record has its own action/circuit/target and shared norm producer. Preparation is OR; the two-record collection and cost comparison are AND. Costs preserve the zero-evaluating RY and both CXs, exact five depth updates, and first lexicographic disjunct only.

All seven quantum slots remain as previously sealed: six physical fixed targets versus arbitrary stored generic propositions; C/Fin(2^n)/LE basis; typed controls and no hidden oracle; all-zero data with no primitive-route workspace/garbage; exact phases/signs and all-column equalities; no approximate/probabilistic/postselection theorem; literal exact-real logical counts/depth with no finite-bit/runtime/hardware/optimality extrapolation. Actual complex unitarity plus exact action still entails physical norm1 for concrete certificates and primitive routes, independently of what the stored Prop says. Generic arbitrary-Prop VerifiedStatePreparation alone lacks that implication. No new contradiction was found with the previously sealed formal-only decoder.

The 37 mathematical edge judgments are individually recorded in `topology-review.json`. They pass under the stated adjoint convention (`R*R=I` means adjoint times R, not the false R squared identity). This does not waive the remaining stale object-version fields.

## Actual algorithm, current pins and prospective metadata

At the recorded observation time, all exact 207 raw Lean/config pins matched before and after the independent diagnostic. The actual checker hash was `f8f6d7232376b5bc19a480b7e0ef549a5fafa8d66017e07482f7e6999962f8ad`; atlas hash `0fd3e0a70c1b90127972a445f6e26cb870d0a198cd21449546429b15c16ed67f`. The checker was not modified on disk. Only two read-only virtual paths were used for the prospective calculation: planned v2 lesson to sealed v2 text, and catalog to the sealed one-row source overlay.

The observed binding algorithm initializes SHA256 with canonical JSON of its exact selected record keys, appends four named direct raw inputs (target module, lesson, toolchain, manifest), then the named raw corpus in its actual directory/sorted order (142 production plus 60 tests), then canonical JSON of the ENTIRE selected source row. There are 206 raw reads per binding; target module appears directly and again among the 202 ambient files. `lakefile.lean`, `QuantumBlockEncoding.lean`, and `Tests.lean` are in the separate 207 equality pins, not directly hashed by the original binding function. The algorithm was not quietly expanded.

An independent direct replay of that algorithm agreed with the actual original function and all three proposed digests:

- Textbook: `1e618ba9b7271605207d78a363184e6220afd16db9dee41ce0e352db73468373`.
- Core: `f32bf6b16b4b61d42eb016b786196011a6cde9cf1f07937634196f0fc0d80231`.
- Primitive: `d80bceb786e701e26650c7ff04fe7b2702a93927f7f02a05218f02882d33601d`.

Public declarations/obligations matched the actual generated inventory sets (29/38/31); private5 remain in the separate complete audit. Record categories, graph declaration identities, obligation coverage and pending identity fields were checked. The exact one-row source overlay passed actual `validate_catalog` under empty remaining catalogs. Invalid ID/status/http/missing-formal-status probes were rejected. A mutation of the selected row title changed each binding, confirming full-row sensitivity. This is row-schema validation, not validation of the whole production research catalog.

Actual `validate_record` rejected each prospective record with `publication lacks decoder_evidence`, as expected: decoder/reviewer evidence remain null. Matching digests are not source review, scientific correctness, kernel trust or admission. Historical formalizer remains UNKNOWN, no reviewer/decoder identity is fabricated, and baseline commit text remains parent-reported without a Git resolution in this task. The `repair` field is still null; the separately supplied exact editorial minimality review may later be wired into a correctly versioned repair chain, but it does not install or admit anything itself.

The full metadata replay was observed at `2026-10-17 06:54:02 UTC`. Parent subsequently reported installing the exact lesson/source row only and planning a separately versioned metadata-only graph correction, without registry admission. To freeze the current finding as requested, this reviewer did not inspect that later catalog state or any metadata successor. A final stage1-only recheck at `06:55:58 UTC` confirmed the same frozen source/inventory/math graph without touching current catalogs. The earlier catalog-absence observation is not asserted as true after the parent's reported installation.

## Handoff

Source/editorial, all-header/body and mathematical topology repairs: accepted within this bounded manual/diagnostic scope. Exact whole-package provenance/version metadata: further correction required. Failure class remains IMPLEMENTATION_FAILED for that evidence representation only; no mathematical route is retired.

No Lean/native/compiler/TCB evaluation, new theorem, Git/network, production/registry write, child agent, final publication wrapper or opaque decoder successor was used. No source or old review artifact was edited, moved or deleted. Preserve the old negative record, this exact new finding and all observed bindings; review any later graph/current-binding successor separately.
