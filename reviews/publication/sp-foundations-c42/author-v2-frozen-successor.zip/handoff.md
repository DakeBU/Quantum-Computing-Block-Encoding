# Exact finite-SP author successor for the same reviewer's recheck

AUTHOR/WIP_SUCCESSOR; not accepted, not a reviewer verdict, not a publication or registry update. The original author continues under identity sp_foundations_source_author_c40. Historical formalizer remains UNKNOWN. No reviewer identity has been adopted. The old phase3 verdict WITHHELD_CHANGES_REQUIRED is retained exactly and must not be changed by this package.

Only the parent's six-file phase3 release was read as independent feedback. Its phase3-seal.json SHA256 is 9cfd2ffdbed27558ce6988ec4fe16f8fb2310af8e2930e86dc9c8556194e0933. No unreleased independent reconstruction or output was opened. Original author25, prospective metadata7, and released review6 are unchanged, with complete before/after pins.

## Phase 1: sealed source, inventory and graph repairs

The first 11 artifacts were sealed before generating any prospective v2 record in stage1-seal.json, SHA256 3e06dc4059b9f7c75fc414a1640ea5a6d34bbee8702f603eb48184521cd5b7d5. Those 12 stage1 files remained unchanged during the later binding phase.

natural-source-v2.md SHA256 is 286c030e78ad180e74335f8c8543da2aad5dcff81a2797c92215f13773466cc0. It is EXACTLY original natural-source.md (7472eeb8fefe3fffdf662b38751e36401c0b2f770b25a149ae6bcc9f6bc49c79) with one occurrence of the Bell census sentence replaced by the reviewer's exact proposed wording. No terminal-LF, mathematical statement, matrix, premise, phase, dimension, target or cost change is included. editorial-proposal.json preserves exact before/after, old/new hashes and the released minimality finding. The original source stays frozen. Successor source acceptance is pending.

extract-inventory.py is a private, read-only bounded extraction repair, NOT a production parser or verifier. A token scanner and a separately implemented character-state scanner independently locate declaration command extents and top-level body delimiters for ALL 103 commands. They distinguish default-binder and record-field := from the declaration body :=, and distinguish quoted/commented where from an actual top-level record body. Every command also passes raw-byte, per-line and header+separator+body lossless reassembly checks. This is mechanical author evidence, not Lean elaboration or independent review.

declaration-inventory-v2.json separates complete raw headers, separators, complete bodies, structure fields and full commands, retaining all exact source offsets/hashes. It covers the same 29/38/36 explicit commands (98 public, 5 private). The four full cost propositions match the exact released proposed signatures. The 21 ordinary record-def headers now stop before where; their complete field bodies are separately stored. Structure fields are not erased. inventory-difference-map.json preserves the OLD erroneous strings and all 103 old-to-new mappings: exactly 4 cost repairs, 21 where repairs and 78 unchanged signatures. inventory-checks.json and stage1-checks.json give per-command checks, boundary fixtures and the limitations. No four-theorem special-case extractor replaces the general walk.

source-and-graph-v2.json responds to EACH of the 16 released edge_reviews. The old graph remains intact in the original packet; this successor is a separate proposed object:

- T-H now names literal H and plus data and their adjoint/square/norm/column derivations.
- PYTHAGOREAN is the generic four-premise identity. Fixed35, fixed513 and rational-zero branches are distinct, with rational values, domain witnesses, angle evaluation and half-angle bridge. Unused513/zero do not become product-route premises.
- UCRY exposes the zero-control singleton/lift base, both halfAdd/halfSub tail induction hypotheses, exact angle evaluation, RY addition and X conjugation, consistent head/tail non-target contexts and explicit LE entry transport. No control injectivity is inserted.
- B3 norm has tensor/direct OR proof routes; B3 unitary has separate tensor/direct OR proof routes, each with complete AND prerequisites. Direct unitary includes all four norms and six cancellations. Tensor arguments are SOURCE mathematics only; actual target Lean remains finite coordinate/Gram proofs.
- FACTORIZED-OPERATOR supplies full operator equality; FACTORIZED additionally consumes B3 target identification and its first-column action to get state action. TREE consumes full tree=factorized operator equality AND factorized action.
- Separate FACTORIZED-ROUTE-RECORD and TREE-ROUTE-RECORD each consume their own action, typed circuit/target and common B3 normalization. ROUTE-RECORDS aggregates BOTH records. SAME-TARGET-ROUTES is preparation OR; COST-COMPARE is comparison AND.

The successor has 37 hyperedges, three explicit OR aggregators and all 103 declaration mappings. Source/Lean/compressed-spine/Functor views remain distinct. All five typed gaps remain unchanged, including display-wrapper linkage, sparse historical comment mismatch, general-paper algorithms, finite-bit boundaries and actual trust observation. Structural checks are not a mathematical coverage approval: exact same-reviewer recheck remains necessary.

## Phase 2: fresh prospective v2 metadata, not final admission

sources-overlay-v2.json proposes legal ID aspbe-local-finite-sp-foundations-v2, the official repository HTTPS URL, primary-text-checked status and explicit AUTHOR/WIP/exact-recheck-pending formal_status. The planned lesson is docs/lessons/finite-sp-foundations-v2.md and must receive the exact natural-source-v2.md bytes above. Nothing was installed into production, registry or catalog.

prospective-records-v2.json binds all 29/38/31 public declarations and complete source-obligation mappings; private5 audit/definition/body evidence is referenced in the sealed successor. The graph payload references exact corrected stage1 artifacts rather than stale v1 inventory/topology hashes. Generic stored Props, wrapper-versus-typed-circuit separation, all eight sparse columns, exact representatives, unsimplified typed primitive costs, SP/BE directionality and full AND/OR boundaries remain explicit. No general algorithm, new theorem, finite-bit synthesis or tensor Lean implementation is claimed.

compute-prospective-v2.py actually called the UNCHANGED official binding_digest under a two-path read-only overlay (planned v2 lesson -> exact new source, sources catalog -> proposed single-row overlay). All 202 ambient raw Lean files, lesson, toolchain, manifest, selected source row and payload are actually consumed. Per record there are 206 raw-byte reads: target, lesson, toolchain, manifest, then all202 including the target again. The extra root lakefile.lean/QuantumBlockEncoding.lean/Tests.lean remain separately sealed among all207 pins; the official algorithm was not misrepresented as directly hashing those three.

Fresh actual v2 bindings, each repeated and checked against the saved record:

- TextbookStatePreparation: 1e618ba9b7271605207d78a363184e6220afd16db9dee41ce0e352db73468373
- StatePreparationBenchmarksCoreFixed: f32bf6b16b4b61d42eb016b786196011a6cde9cf1f07937634196f0fc0d80231
- StatePreparationPrimitiveRoutes: d80bceb786e701e26650c7ff04fe7b2702a93927f7f02a05218f02882d33601d

None reuses any v1 binding. Actual research_atlas.validate_catalog passes the bounded proposed-row fixture and rejects invalid ID/status/HTTP URL/missing formal_status probes. The full selected-row mutation sensitivity test changes the actual digest. The original validate_record FAILS CLOSED for each null decoder_evidence, as intended. All independent evidence fields remain null/PENDING. No accepted wrapper, invented identity or positive reviewer result is created. Changing any selected row field, payload/graph/lesson/raw input invalidates these prospective hashes and requires appropriately rebound evidence.

bounded-checks-v2.json records actual tests and complete pins: 207 original inputs unchanged; original author25 and metadata7 unchanged; released review6 unchanged; sealed stage1 twelve unchanged. Parent reported contribution checkpoint 30fe1d7; no Git operation or full-commit resolution occurred here.

## Exact next handoff and stop

Return this package, its final seal, source/proposal, corrected inventory/difference/checks, graph/coverage/binder addendum, and prospective records/source row/actual checks to the SAME reviewer via the parent. The original formal15 files remain unchanged and need not be duplicated. This author does not self-approve any repair and does not convert the prior CHANGES_REQUIRED into acceptance. Reviewer may use the old six-file feedback as immutable baseline, inspect exact successor bytes and issue a new distinct judgment.

Failure class retained for the original evidence defect: IMPLEMENTATION_FAILED, not a refuted mathematical route. This stage proposes its repair, not its independent resolution. Mathematical target delta: NONE; editorial source census delta only. Salvage: all original mathematical contracts and 103 identities preserved. Common-blind-spot/exact-successor/publication/kernel/integration/purification/Exposition gates remain pending at their proper scopes.

Exact safe allowlist: allowlist.json. Only this new successor directory was written using apply_patch. No original packet, released review, production/config/catalog/registry/parser/verifier edits; no Git/network/Lean/native/children. Stop after final sealing; do not continue the global goal or fabricate acceptance.
