"""Read-only exact successor checks; stdout only. No independent approval."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def pins(root, names):
    return [{"path": name, "bytes": (root / name).stat().st_size,
             "sha256": sha((root / name).read_bytes())} for name in sorted(names)]


def main():
    p = argparse.ArgumentParser()
    for name in ("repo", "author", "metadata", "review", "packet"):
        p.add_argument("--" + name, type=Path, required=True)
    a = p.parse_args()
    old_raw = read(a.author / "raw-input-seals.json")["rows"]
    raw_names = [x["path"] for x in old_raw]
    before = pins(a.repo, raw_names)
    assert len(before) == 207 and before == sorted(old_raw, key=lambda x: x["path"])
    corpus = sorted(path.relative_to(a.repo).as_posix()
                    for directory in ("QuantumBlockEncoding", "ABEISTests")
                    for path in (a.repo / directory).rglob("*.lean"))
    assert len(corpus) == 202 and set(corpus).issubset(raw_names)
    old_packets = []
    for root, seal_name, expected_seal, expected_count in (
        (a.author, "seals.json", "ca48d1dacf29ff39e3b2f035d3671a758aa168fe6548ace87065ce516d632f0c", 25),
        (a.metadata, "seals.json", "7fda32e42ff07a4c0560b7d9a287aae87220a81ce7b1ccfd268c999a1b204292", 7),
    ):
        assert sha((root / seal_name).read_bytes()) == expected_seal
        seal = read(root / seal_name)
        entries = seal.get("packet_artifacts", seal.get("artifacts"))
        for row in entries:
            assert sha((root / row["path"]).read_bytes()) == row["sha256"]
        names = [row["path"] for row in entries] + [seal_name]
        assert len(names) == expected_count
        old_packets.append((root, names, pins(root, names)))
    review_names = ["findings-and-erratum.json", "author-topology-review.json",
                    "comparison.md", "chronology.json", "allowlist.json", "phase3-seal.json"]
    review_before = pins(a.review, review_names)
    assert sha((a.review / "phase3-seal.json").read_bytes()) == "9cfd2ffdbed27558ce6988ec4fe16f8fb2310af8e2930e86dc9c8556194e0933"
    for row in read(a.review / "phase3-seal.json")["sealed_artifacts"]:
        assert sha((a.review / Path(row["path"]).name).read_bytes()) == row["sha256"]
    finding = next(x for x in read(a.review / "findings-and-erratum.json")["findings"]
                   if x["id"] == "E-BELL-COUNT")
    v1 = (a.author / "natural-source.md").read_bytes()
    v2 = (a.packet / "natural-source-v2.md").read_bytes()
    left, right = finding["exact_before"].encode(), finding["exact_after"].encode()
    assert v1.count(left) == 1 and v2 == v1.replace(left, right, 1)
    proposal = read(a.packet / "editorial-proposal.json")
    assert proposal["old_source_sha256"] == sha(v1)
    assert proposal["new_source_sha256"] == sha(v2)
    inv = read(a.packet / "declaration-inventory-v2.json")["declarations"]
    diff = read(a.packet / "inventory-difference-map.json")["differences"]
    saved_checks = read(a.packet / "inventory-checks.json")
    assert len(inv) == len(diff) == len(saved_checks["all103_checks"]) == 103
    spec = importlib.util.spec_from_file_location("c42_author_extraction", a.packet / "extract-inventory.py")
    extractor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(extractor)
    assert len(extractor.fixture_tests()) == 9
    per_module = {}
    for row in inv:
        raw = (a.repo / row["source"]).read_bytes()
        text = raw.decode("utf-8")
        start, end = row["source_command_char_offsets"]
        byte_start, byte_end = row["source_command_byte_offsets"]
        command = row["source_command_raw"]
        assert command == text[start:end]
        assert command.encode() == raw[byte_start:byte_end]
        assert sha(raw) == row["source_module_raw_sha256"]
        assert sha(command.encode()) == row["source_command_raw_sha256"]
        assert command == row["header_raw"] + row["body_separator"] + row["body_raw"]
        aa = extractor.split_a(command)
        bb = extractor.split_b(command)
        assert aa == bb
        assert command[:aa[0]] == row["header_raw"]
        assert text.count("\n", 0, start)+1 == row["line_start"]
        assert text.count("\n", 0, end)+1 == row["line_end"]
        if row["source"] not in per_module:
            assert extractor.scan_a(text) == extractor.scan_b(text)
            per_module[row["source"]] = len(extractor.scan_a(text))
    assert sorted(per_module.values()) == [29, 36, 38]
    assert sum(x["private"] for x in inv) == 5
    assert sum(x["change_class"] == "COST_RECORD_IN_PROPOSITION" for x in diff) == 4
    assert sum(x["change_class"] == "WHERE_RECORD_HEADER_BODY_SEPARATED" for x in diff) == 21
    assert sum(not x["changed"] for x in diff) == 78
    graph = read(a.packet / "source-and-graph-v2.json")
    edge_map = {x["id"]: x for x in graph["source_construction_hyperedges"]}
    assert len(edge_map) == 37
    assert {x["id"] for x in graph["source_construction_hyperedges"] if x["mode"] == "OR"} == {
        "B3-NORMALIZATION", "B3-UNITARITY", "SAME-TARGET-ROUTES"}
    assert all(len(edge_map[key]["alternative_complete_and_tails"]) == 2 for key in (
        "B3-NORMALIZATION", "B3-UNITARITY", "SAME-TARGET-ROUTES"))
    prior = read(a.review / "author-topology-review.json")
    assert graph["prior_review"]["verdict_retained"] == prior["complete_topology_approval"] == "WITHHELD_CHANGES_REQUIRED"
    assert len(graph["edge_review_responses"]) == len(prior["edge_reviews"]) == 16
    assert {x["original_edge"] for x in graph["edge_review_responses"]} == {x["id"] for x in prior["edge_reviews"]}
    assert all(set(x["successor_edges"]).issubset(edge_map) for x in graph["edge_review_responses"])
    assert graph["source_topology_independently_reviewed"] is False
    assert len(graph["explicit_declaration_coverage"]) == 103
    assert set(x["name"] for x in graph["explicit_declaration_coverage"]) == set(x["source_name"] for x in inv)
    old_graph = read(a.author / "source-and-graph.json")
    assert [x for x in graph["nodes"] if x["kind"] == "SOURCE_GAP"] == [
        x for x in old_graph["nodes"] if x["kind"] == "SOURCE_GAP"]
    assert set(graph["four_views"]) == set(old_graph["four_views"])
    cov = read(a.packet / "source-coverage-v2.json")
    assert cov["source_sha256"] == sha(v2) and len(cov["regions"]) == 41
    lines = v2.decode().split("\n")
    for i, line in enumerate(lines, 1):
        if line.strip():
            assert any(row["lines"][0] <= i <= row["lines"][1] for row in cov["regions"])
    assert pins(a.repo, raw_names) == before
    assert pins(a.review, review_names) == review_before
    for root, names, before_pins in old_packets:
        assert pins(root, names) == before_pins
    print(json.dumps({
        "status": "AUTHOR_MECHANICAL_STAGE1_CHECKS_NOT_REVIEWER_APPROVAL",
        "new_source_sha256": sha(v2), "old_source_sha256": sha(v1),
        "exact_single_editorial_replacement_only": True,
        "all103_raw_header_body_lines_and_two_scanners_rechecked": True,
        "whole_module_explicit_counts": per_module,
        "private_count": 5, "cost_signature_repairs": 4, "where_header_repairs": 21,
        "unchanged_signature_count": 78, "boundary_fixtures": 9,
        "all16_prior_edge_reviews_have_proposed_responses": True,
        "successor_edges": 37, "source_OR_routes": ["B3-NORMALIZATION", "B3-UNITARITY", "SAME-TARGET-ROUTES"],
        "tensor_source_proofs_not_claimed_Lean_implementations": True,
        "nonblank_source_coverage_regions": 41, "existing_typed_gaps_retained": True,
        "prior_CHANGES_REQUIRED_verdict_retained": True,
        "raw207_before_after": before, "raw207_equal_frozen_original": True,
        "frozen_original_25_pins": old_packets[0][2],
        "frozen_metadata_7_pins": old_packets[1][2], "released_review_6_pins": review_before,
        "all_old32_and_released6_unchanged": True,
        "successor_independent_review": None,
        "no_production_parser_verifier_Lean_native_execution": True,
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
