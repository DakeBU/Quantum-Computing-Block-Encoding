"""Bounded, read-only author evidence repair. Emits JSON on stdout only.

Not a production Lean parser, verifier, elaborator, or independent review.
Two separately implemented scanners cross-check every explicit declaration.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path


DECL_RE = re.compile(r"^(?:@\[[^\n]*?\]\s*)?(?:(?:private|noncomputable|protected)\s+)*(def|abbrev|theorem|structure|instance)\s+([^\s:({]+)")
DIRECTIVE_RE = re.compile(r"^(?:import|open|namespace|end|set_option)\b")
DECL_KINDS = {"def", "abbrev", "theorem", "structure", "instance"}
OPEN = {"(": ")", "[": "]", "{": "}", "⟨": "⟩", "⦃": "⦄"}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def lexer(text):
    """Token scanner A; comments omitted, strings/characters atomic."""
    tokens = []
    i = 0
    while i < len(text):
        if text[i].isspace():
            i += 1
            continue
        if text.startswith("--", i):
            j = text.find("\n", i)
            i = len(text) if j < 0 else j + 1
            continue
        if text.startswith("/-", i):
            depth = 1
            i += 2
            while depth:
                assert i < len(text), "unterminated nested comment"
                if text.startswith("/-", i):
                    depth += 1
                    i += 2
                elif text.startswith("-/", i):
                    depth -= 1
                    i += 2
                else:
                    i += 1
            continue
        start = i
        char_match = re.match(r"'(?:\\.|[^'\\\r\n])'", text[i:])
        if text[i] == '"' or char_match:
            quote = text[i]
            i += 1
            while i < len(text):
                if text[i] == "\\":
                    i += 2
                elif text[i] == quote:
                    i += 1
                    break
                else:
                    i += 1
            else:
                raise AssertionError("unterminated string/character")
            value = text[start:i]
        elif text.startswith(":=", i):
            value = ":="
            i += 2
        elif text[i].isalnum() or text[i] == "_":
            i += 1
            while i < len(text) and (text[i].isalnum() or text[i] in "_'."):
                i += 1
            value = text[start:i]
        else:
            value = text[i]
            i += 1
        line_start = text.rfind("\n", 0, start) + 1
        tokens.append((value, start, i, start - line_start))
    return tokens


def split_a(text):
    stack = []
    for value, start, end, _ in lexer(text):
        if value in OPEN:
            stack.append(OPEN[value])
        elif stack and value == stack[-1]:
            stack.pop()
        elif not stack and value in {":=", "where"}:
            return start, end, value
    raise AssertionError("no declaration body separator")


def significant_mask_b(text):
    """Independent character-state scanner B, not lexer A."""
    result = list(text)
    state = "code"
    nest = 0
    i = 0
    while i < len(text):
        c = text[i]
        if state == "line":
            if c in "\r\n":
                state = "code"
            else:
                result[i] = " "
            i += 1
        elif nest:
            if text[i:i+2] == "/-":
                result[i:i+2] = [" ", " "]
                nest += 1
                i += 2
            elif text[i:i+2] == "-/":
                result[i:i+2] = [" ", " "]
                nest -= 1
                i += 2
            else:
                if c not in "\r\n":
                    result[i] = " "
                i += 1
        elif state == "string":
            # Preserve one nonspace marker at both quote positions for extent.
            if c == "\\":
                result[i] = " "
                if i + 1 < len(text):
                    result[i+1] = " "
                i += 2
            elif c == '"':
                state = "code"
                i += 1
            else:
                if c not in "\r\n":
                    result[i] = " "
                i += 1
        elif text[i:i+2] == "--":
            result[i:i+2] = [" ", " "]
            state = "line"
            i += 2
        elif text[i:i+2] == "/-":
            result[i:i+2] = [" ", " "]
            nest = 1
            i += 2
        elif c == '"':
            state = "string"
            i += 1
        else:
            i += 1
    assert not nest and state != "string"
    return "".join(result)


def split_b(text):
    """Character-level independent delimiter walk, including raw strings."""
    depth = {"(": 0, "[": 0, "{": 0, "⟨": 0, "⦃": 0}
    close = {v: k for k, v in OPEN.items()}
    i = 0
    while i < len(text):
        if text.startswith("--", i):
            k = text.find("\n", i)
            i = len(text) if k < 0 else k + 1
            continue
        if text.startswith("/-", i):
            count = 1
            i += 2
            while count:
                assert i < len(text)
                if text.startswith("/-", i):
                    count += 1
                    i += 2
                elif text.startswith("-/", i):
                    count -= 1
                    i += 2
                else:
                    i += 1
            continue
        char_match = re.match(r"'(?:\\.|[^'\\\r\n])'", text[i:])
        if char_match:
            i += len(char_match.group())
            continue
        if text[i] == '"':
            i += 1
            while text[i] != '"':
                i += 2 if text[i] == "\\" else 1
            i += 1
            continue
        if text[i] in depth:
            depth[text[i]] += 1
        elif text[i] in close:
            depth[close[text[i]]] -= 1
            assert depth[close[text[i]]] >= 0
        elif not any(depth.values()):
            if text.startswith(":=", i):
                return i, i + 2, ":="
            if text.startswith("where", i):
                before = text[i-1] if i else " "
                after = text[i+5] if i+5 < len(text) else " "
                if not (before.isalnum() or before in "_'.") and not (after.isalnum() or after in "_'."):
                    return i, i + 5, "where"
        i += 1
    raise AssertionError("no declaration body separator")


def scan_a(text):
    ts = lexer(text)
    by_line = {}
    for index, token in enumerate(ts):
        if token[3] == 0:
            by_line[token[1]] = index
    boundaries = []
    for offset, index in by_line.items():
        value = ts[index][0]
        if value in {"import", "open", "namespace", "end", "set_option"}:
            boundaries.append((offset, index, None, None))
            continue
        k = index
        if value == "@":
            assert ts[k+1][0] == "["
            brackets = 1
            k += 2
            while brackets:
                brackets += (ts[k][0] == "[") - (ts[k][0] == "]")
                k += 1
        while ts[k][0] in {"private", "noncomputable", "protected"}:
            k += 1
        if ts[k][0] in DECL_KINDS:
            boundaries.append((offset, index, ts[k][0], ts[k+1][0]))
    result = []
    for j, (start, ti, kind, name) in enumerate(boundaries):
        if kind is None:
            continue
        next_index = boundaries[j+1][1] if j+1 < len(boundaries) else len(ts)
        end = ts[next_index-1][2]
        result.append((start, end, kind, name))
    return result


def scan_b(text):
    mask = significant_mask_b(text)
    boundaries = []
    offset = 0
    for line in mask.splitlines(keepends=True):
        original_line = text[offset:offset+len(line)]
        match = DECL_RE.match(original_line)
        if match and line.lstrip() == line:
            boundaries.append((offset, match.group(1), match.group(2)))
        elif DIRECTIVE_RE.match(line):
            boundaries.append((offset, None, None))
        offset += len(line)
    result = []
    for j, (start, kind, name) in enumerate(boundaries):
        if kind is None:
            continue
        stop = boundaries[j+1][0] if j+1 < len(boundaries) else len(text)
        end = start + len(mask[start:stop].rstrip())
        result.append((start, end, kind, name))
    return result


def fixture_tests():
    cases = [
        ("record theorem", "theorem t : x = { auxiliaryQubits := 0, gateCount := 1, depth := 1, oracleCalls := 0 } := by rfl", ":="),
        ("nested binder default", "def d (x : Nat := 7) : T where\n  field := x", "where"),
        ("quoted delimiter binder", 'def q (s : String := "where := {") : String := s', ":="),
        ("quoted result type", 'theorem q : ("where :=" : String) = "where :=" := by rfl', ":="),
        ("nested comments", "def d (x : Nat /- := /- where -/ -/) : Nat := x", ":="),
        ("implicit braces", "def d {x : Nat := 3} [h : C ({ f := 0 })] : Nat := x", ":="),
        ("structure fields", "structure S (n : Nat) where\n  field : Nat := n\n  proof : field = n", "where"),
        ("character bracket", "def d (c : Char := '(') : Char := c", ":="),
        ("where inside nested record", "theorem t : ({ x := 0, y := { z := 2 } } : T) = u := by rfl", ":="),
    ]
    out = []
    for label, text, separator in cases:
        a, b = split_a(text), split_b(text)
        assert a == b and a[2] == separator
        head = text[:a[0]]
        assert head + text[a[0]:a[1]] + text[a[1]:] == text
        out.append({"case": label, "A_B_equal": True, "header": head, "separator": separator})
    # The legacy first-:= rule must fail on both reported defect classes.
    assert cases[0][1].index(":=") != split_a(cases[0][1])[0]
    assert cases[1][1].index(":=") != split_a(cases[1][1])[0]
    for broken in ("def d (x : Nat := 3 : Nat := x", "def d : String := \"unterminated"):
        try:
            split_a(broken)
        except (AssertionError, IndexError):
            pass
        else:
            # An unterminated body string is intentionally beyond header split;
            # whole-command lexer must still reject it rather than silently pass.
            try:
                lexer(broken)
            except AssertionError:
                continue
            raise AssertionError("malformed delimiter fixture was accepted")
    return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--repo", type=Path, required=True)
    p.add_argument("--author", type=Path, required=True)
    p.add_argument("--review", type=Path, required=True)
    args = p.parse_args()
    old = read_json(args.author / "declaration-inventory.json")["declarations"]
    expected = {row["source_name"]: row for row in old}
    findings = read_json(args.review / "findings-and-erratum.json")
    cost = next(row for row in findings["findings"] if row["id"] == "I-COST-SIGNATURE-TRUNCATION")
    exact_cost = {row["name"]: row["complete_signature"] for row in cost["affected_and_proposed_complete_signature"]}
    declarations, changes, checks = [], [], []
    for module in dict.fromkeys(row["source"] for row in old):
        raw_bytes = (args.repo / module).read_bytes()
        text = raw_bytes.decode("utf-8")
        assert not text.startswith("\ufeff")
        a, b = scan_a(text), scan_b(text)
        assert a == b, "independent command extent scanners disagree: " + module
        stack = []
        namespace_events = []
        for line_num, line in enumerate(text.splitlines(), 1):
            match = re.match(r"^namespace\s+(\S+)", line)
            if match:
                stack.append(match.group(1))
            elif re.match(r"^end(?:\s|$)", line):
                stack.pop()
            namespace_events.append(".".join(stack))
        for start, end, kind, name in a:
            command = text[start:end]
            sep_a, sep_b = split_a(command), split_b(command)
            assert sep_a == sep_b
            hs, he, separator = sep_a
            header, body = command[:hs], command[he:]
            line_start = text.count("\n", 0, start) + 1
            line_end = text.count("\n", 0, end) + 1
            full = namespace_events[line_start-1] + "." + name
            legacy = expected[full]
            assert legacy["line_start"] == line_start
            assert legacy["kind"] == kind
            private = bool(re.search(r"\bprivate\b", header))
            assert legacy["private"] == private
            assert command == header + separator + body
            assert command.encode("utf-8") == raw_bytes[
                len(text[:start].encode("utf-8")):len(text[:end].encode("utf-8"))]
            # Third, independent per-line raw slice and token check.
            lines = text.splitlines(keepends=True)
            line_raw = "".join(lines[line_start-1:line_end])
            assert command == line_raw[:len(command)]
            assert lexer(header)[-1][0] not in {":=", "where"}
            signature = command.rstrip() if kind == "structure" else header.rstrip()
            if full in exact_cost:
                assert signature.replace("\r\n", "\n") == exact_cost[full]
            old_value = legacy["signature_or_structure_fields"]
            changed = old_value != signature.replace("\r\n", "\n")
            row = {key: value for key, value in legacy.items()
                   if key not in {"signature_or_structure_fields", "line_end"}}
            row.update({
                "line_end": line_end, "source_module_raw_sha256": digest(raw_bytes),
                "source_command_raw_sha256": digest(command.encode("utf-8")),
                "source_command_char_offsets": [start, end],
                "source_command_byte_offsets": [len(text[:start].encode("utf-8")), len(text[:end].encode("utf-8"))],
                "header_raw": header, "body_separator": separator,
                "body_raw": body, "structure_fields_raw": body if kind == "structure" else None,
                "signature_or_structure_fields": signature,
                "source_command_raw": command,
                "extraction_status": "AUTHOR_MECHANICAL_CROSSCHECKED_NOT_ELABORATED",
            })
            declarations.append(row)
            changes.append({
                "name": full, "old_signature_or_structure_fields": old_value,
                "new_signature_or_structure_fields": signature,
                "old_line_end_inclusive_claim": legacy["line_end"], "new_last_token_line": line_end,
                "changed": changed,
                "change_class": ("COST_RECORD_IN_PROPOSITION" if full in exact_cost else
                                 "WHERE_RECORD_HEADER_BODY_SEPARATED" if changed and separator == "where" and kind != "structure" else
                                 "UNCHANGED_SIGNATURE" if not changed else "OTHER_REQUIRES_INSPECTION"),
            })
            checks.append({"name": full, "source": module, "lines": [line_start, line_end],
                           "command_extents_A_B_equal": True, "body_split_A_B_equal": True,
                           "raw_byte_slice_equal": True, "per_line_slice_equal": True,
                           "name_kind_visibility_start_equal_original_ledger": True,
                           "lossless_header_separator_body_reassembly": True})
    assert len(declarations) == 103 and set(expected) == {row["source_name"] for row in declarations}
    assert sum(row["private"] for row in declarations) == 5
    changed = [row for row in changes if row["changed"]]
    assert len(changed) == 25
    assert sum(row["change_class"] == "COST_RECORD_IN_PROPOSITION" for row in changed) == 4
    assert sum(row["change_class"] == "WHERE_RECORD_HEADER_BODY_SEPARATED" for row in changed) == 21
    assert not any(row["change_class"] == "OTHER_REQUIRES_INSPECTION" for row in changes)
    print(json.dumps({
        "status": "AUTHOR/WIP_SUCCESSOR_REQUIRES_REVIEW",
        "limitations": "Bounded lexical/character scanners of these explicit commands only; no Lean parsing/elaboration, proof-term/TCB census, production parser change or independent reviewer acceptance.",
        "declarations": declarations, "legacy_difference_map_all103": changes,
        "all103_checks": checks, "negative_and_boundary_fixtures": fixture_tests(),
        "summary": {"explicit": 103, "public": 98, "private": 5,
                    "changed_signatures": 25, "cost_repairs": 4, "where_header_repairs": 21,
                    "unchanged_signatures": 78, "raw_modules_edited": False},
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
