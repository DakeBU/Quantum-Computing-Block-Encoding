"""Read-only prospective metadata checks; stdout only, no artifact/registry writes.

Invoke with Python -B and explicit --repo, --author and --packet directories.
Only the original frozen author/metadata packages, the released phase3 feedback
hashes, sealed successor stage1, official checker/schema, generated declaration
inventory, proposed metadata and raw inputs are read. No unreleased independent
reconstruction or reviewer artifact is opened; no review identity is adopted.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def import_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def pin_rows(root: Path, names: list[str]):
    return [{"path": name, "bytes": (root / name).stat().st_size,
             "sha256": sha((root / name).read_bytes())} for name in sorted(names)]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--author", type=Path, required=True)
    parser.add_argument("--packet", type=Path, required=True)
    parser.add_argument("--metadata", type=Path, required=True)
    parser.add_argument("--review", type=Path, required=True)
    args = parser.parse_args()
    repo, author, packet = args.repo.resolve(), args.author.resolve(), args.packet.resolve()
    records = read(packet / "prospective-records-v2.json")["records"]
    source_overlay = read(packet / "sources-overlay-v2.json")
    source = source_overlay["sources"][0]
    source_id = "aspbe-local-finite-sp-foundations-v2"
    lesson = "docs/lessons/finite-sp-foundations-v2.md"
    author_seals = read(author / "seals.json")
    original_inputs = read(author / "raw-input-seals.json")["rows"]
    names = [row["path"] for row in original_inputs]
    before = pin_rows(repo, names)
    assert len(before) == 207
    assert before == sorted(original_inputs, key=lambda row: row["path"])
    corpus = sorted(path.relative_to(repo).as_posix()
                    for directory in ("QuantumBlockEncoding", "ABEISTests")
                    for path in (repo / directory).rglob("*.lean"))
    assert len(corpus) == 202
    assert len([name for name in corpus if name.startswith("QuantumBlockEncoding/")]) == 142
    assert len([name for name in corpus if name.startswith("ABEISTests/")]) == 60
    assert set(corpus).issubset(names)
    author_files = read(author / "allowlist.json")["files"]
    author_before = pin_rows(author, author_files)
    assert len(author_before) == 25
    assert sha((author / "seals.json").read_bytes()) == "ca48d1dacf29ff39e3b2f035d3671a758aa168fe6548ace87065ce516d632f0c"
    assert sha((author / "natural-source.md").read_bytes()) == "7472eeb8fefe3fffdf662b38751e36401c0b2f770b25a149ae6bcc9f6bc49c79"
    for row in author_seals["packet_artifacts"]:
        assert sha((author / row["path"]).read_bytes()) == row["sha256"]
    stage1 = read(packet / "stage1-seal.json")
    assert sha((packet / "stage1-seal.json").read_bytes()) == "3e06dc4059b9f7c75fc414a1640ea5a6d34bbee8702f603eb48184521cd5b7d5"
    stage1_names = [x["path"] for x in stage1["artifacts"]] + ["stage1-seal.json"]
    for row in stage1["artifacts"]:
        assert sha((packet / row["path"]).read_bytes()) == row["sha256"]
    stage1_before = pin_rows(packet, stage1_names)
    metadata_names = read(args.metadata / "allowlist.json")["files"]
    metadata_before = pin_rows(args.metadata, metadata_names)
    assert len(metadata_before) == 7
    assert sha((args.metadata / "seals.json").read_bytes()) == "7fda32e42ff07a4c0560b7d9a287aae87220a81ce7b1ccfd268c999a1b204292"
    review_names = ["findings-and-erratum.json", "author-topology-review.json", "comparison.md", "chronology.json", "allowlist.json", "phase3-seal.json"]
    review_before = pin_rows(args.review, review_names)
    assert sha((args.review / "phase3-seal.json").read_bytes()) == "9cfd2ffdbed27558ce6988ec4fe16f8fb2310af8e2930e86dc9c8556194e0933"
    checker_path = repo / "website/scripts/check_research_publications.py"
    atlas_path = repo / "website/scripts/research_atlas.py"
    checker_sha = sha(checker_path.read_bytes())
    atlas_sha = sha(atlas_path.read_bytes())
    assert checker_sha == "f8f6d7232376b5bc19a480b7e0ef549a5fafa8d66017e07482f7e6999962f8ad"
    assert atlas_sha == "0fd3e0a70c1b90127972a445f6e26cb870d0a198cd21449546429b15c16ed67f"
    checker = import_module(checker_path, "c42_existing_publication_checker")
    atlas = import_module(atlas_path, "c42_existing_research_atlas")
    assert source["id"] == source_id
    assert source["status"] == "primary-text-checked"
    assert source["historical_formalizer"] == "UNKNOWN"
    assert source["lesson_sha256"] == sha((packet / "natural-source-v2.md").read_bytes())
    assert source["url"] == "https://github.com/DakeBU/Quantum-Computing-Block-Encoding"
    existing_source_ids = {item["id"] for item in read(repo / "website/research/sources.json")["sources"]}
    assert source_id not in existing_source_ids, "prospective source id already exists; reconcile instead of duplicating"

    def minimal_catalog(row):
        return {"sources": {"schema_version": 1, "sources": [row]},
                "atlas": {"schema_version": 1, "domains": [], "families": [],
                          "hyperedges": [], "contributions": []},
                "wiki": {"schema_version": 1, "routes": []}}

    atlas.validate_catalog(minimal_catalog(source))
    negative_schema_tests = {}
    for label, key, value in (
        ("underscore_id", "id", "aspbe_local_finite_sp_foundations_v1"),
        ("invalid_status", "status", "accepted"),
        ("insecure_url", "url", "http://example.invalid"),
        ("missing_formal_status", "formal_status", None),
    ):
        bad = copy.deepcopy(source)
        bad[key] = value
        try:
            atlas.validate_catalog(minimal_catalog(bad))
        except ValueError as error:
            negative_schema_tests[label] = str(error)
        else:
            raise AssertionError("existing validator accepted invalid source test " + label)

    inventory = {row["fullName"]: row
                 for row in read(repo / "web/library/declarations.json")["declarations"]
                 if row.get("source") in {record["module"] for record in records}}
    frozen_inventory = read(packet / "declaration-inventory-v2.json")["declarations"]
    real_local_file = checker.local_file
    real_load = checker.load
    overlays_used = []

    def overlay_local_file(root, name):
        if root.resolve() != repo:
            raise AssertionError("unexpected root for virtual overlay")
        if name == lesson:
            overlays_used.append(name)
            return packet / "natural-source-v2.md"
        if name == "website/research/sources.json":
            overlays_used.append(name)
            return packet / "sources-overlay-v2.json"
        return real_local_file(root, name)

    checker.local_file = overlay_local_file
    # binding_digest and validate_record remain the original unmodified functions.
    bindings = []
    for record, expected_count in zip(records, (29, 38, 31), strict=True):
        module = record["module"]
        actual = {name for name, row in inventory.items() if row["source"] == module}
        frozen_public = {row["source_name"] for row in frozen_inventory
                         if row["source"] == module and not row["private"]}
        assert len(actual) == expected_count and actual == frozen_public
        assert len(record["declarations"]) == expected_count
        assert actual == set(record["declarations"])
        assert all(not inventory[name].get("openProof") and not inventory[name].get("experimental")
                   for name in actual)
        mapped = set()
        for obligation in record["obligation_map"]:
            assert obligation["kind"] in {"proof-edge", "prerequisite"}
            assert obligation["source_obligation"] and obligation["lesson_anchor"]
            assert set(obligation["declarations"]).issubset(actual)
            mapped.update(obligation["declarations"])
        assert mapped == actual
        for delta in record["assumption_deltas"]:
            assert delta["classification"] in checker.CATEGORIES
            assert all(delta[key] for key in ("source", "formal", "explanation"))
        graph = record["graph_contribution"]
        assert set(graph["classes"]).issubset(checker.CLASSES)
        assert {"declaration:" + name for name in actual}.issubset(graph["node_ids"])
        assert all(graph.get(key) for key in ("baseline", "classes", "node_ids",
                                             "views", "preserved_contract", "remaining_boundary"))
        assert record["formalizer"] == "UNKNOWN"
        assert record["decoder_evidence"] is None and record["reviewer_evidence"] is None
        assert record["source_id"] == source_id and record["lesson_path"] == lesson
        raw_events = []
        original_read_bytes = Path.read_bytes

        def trace_read_bytes(path):
            data = original_read_bytes(path)
            if path.resolve().is_relative_to(repo):
                logical = path.resolve().relative_to(repo).as_posix()
            elif path.resolve() == (packet / "natural-source-v2.md").resolve():
                logical = lesson
            else:
                logical = "unexpected:" + path.name
            raw_events.append({"logical_path": logical, "bytes": len(data), "sha256": sha(data)})
            return data

        Path.read_bytes = trace_read_bytes
        try:
            digest = checker.binding_digest(repo, record)
        finally:
            Path.read_bytes = original_read_bytes
        assert len(raw_events) == 206
        assert raw_events[0]["logical_path"] == module
        assert raw_events[1]["logical_path"] == lesson
        assert [event["logical_path"] for event in raw_events[2:4]] == ["lean-toolchain", "lake-manifest.json"]
        assert sorted(event["logical_path"] for event in raw_events[4:]) == corpus
        assert sha(json.dumps(source, sort_keys=True, ensure_ascii=False).encode())
        assert checker.binding_digest(repo, record) == digest
        assert record["binding_sha256"] in (None, digest)
        assert digest not in {"1a7c30365c3233658a67dd0436ca2e755d5eecabbd6df878a40d0ce151376ce7", "a39b18fec1a0e3aaa4d85a61724cca07fc675a4491da3a55f302958cd7baa8ce", "0797d5bf51da99ef844e01e7d2ed733258e5da42df964fb54ed6376b25b21672"}
        # The real algorithm binds the ENTIRE selected row, including metadata.
        changed_source = copy.deepcopy(source)
        changed_source["title"] += " [in-memory sensitivity probe]"
        checker.load = lambda root, name: (
            {"sources": [changed_source]} if name == "website/research/sources.json"
            else real_load(root, name))
        try:
            assert checker.binding_digest(repo, record) != digest
        finally:
            checker.load = real_load
        proposed = copy.deepcopy(record)
        proposed["binding_sha256"] = digest
        try:
            checker.validate_record(repo, proposed, inventory)
        except ValueError as error:
            rejection = str(error)
            assert "publication lacks decoder_evidence" in rejection
        else:
            raise AssertionError("pending record unexpectedly passed actual admission validator")
        bindings.append({
            "module": module, "public_declarations": len(actual),
            "private_helpers_in_frozen_audit": record["private_helper_audit"]["count"],
            "actual_binding_digest": digest,
            "deterministic_repeat_equal": True,
            "full_selected_source_row_mutation_changes_digest": True,
            "raw_byte_reads": len(raw_events), "ambient_raw_files": len(corpus),
            "ambient_raw_unique_paths_match_all_202": True,
            "first_four_direct_inputs": raw_events[:4],
            "selected_source_row_canonical_json_sha256": sha(
                json.dumps(source, sort_keys=True, ensure_ascii=False).encode()),
            "unmodified_validate_record_result": rejection,
        })
    checker.local_file = real_local_file
    assert pin_rows(repo, names) == before
    assert pin_rows(author, author_files) == author_before
    assert pin_rows(packet, stage1_names) == stage1_before
    assert pin_rows(args.metadata, metadata_names) == metadata_before
    assert pin_rows(args.review, review_names) == review_before
    assert checker_sha == sha(checker_path.read_bytes())
    assert atlas_sha == sha(atlas_path.read_bytes())
    print(json.dumps({
        "status": "AUTHOR/WIP_PROSPECTIVE_NOT_ACCEPTED",
        "operation": "Original binding_digest executed via read-only two-path virtual overlay; no validator/digest-function edits",
        "overlay_paths": sorted(set(overlays_used)),
        "source_row_actual_minimal_catalog_schema_check": "passed",
        "schema_check_scope": "Proposed single row under real validate_catalog with empty remaining catalogs, not whole production catalog validation",
        "negative_source_schema_tests": negative_schema_tests,
        "source_id_not_already_in_current_catalog": True,
        "checker_sha256": checker_sha, "research_atlas_sha256": atlas_sha,
        "bindings": bindings, "raw_207_before_after": before,
        "raw_207_equal_frozen_author_pins": True,
        "frozen_author_25_before_after": author_before,
        "frozen_author_25_unchanged": True,
        "unreleased_independent_outputs_read": False, "released_phase3_feedback_used_for_repair": True, "independent_evidence": None,
        "stage1_12_before_after": stage1_before, "stage1_unchanged": True,
        "old_metadata_7_before_after": metadata_before, "old_metadata_7_unchanged": True,
        "released_review_6_before_after": review_before, "released_review_6_unchanged": True,
        "v2_bindings_differ_from_all_v1_bindings": True,
        "bindings_are_prospective_not_registry_admission": True,
        "additional_root_config_boundary": "Existing binding_digest directly hashes 202 ambient raws + lesson + toolchain + manifest and target module again. lakefile.lean, QuantumBlockEncoding.lean and Tests.lean are separately in the 207 equality seals; the original algorithm was not expanded or represented as directly hashing them.",
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
