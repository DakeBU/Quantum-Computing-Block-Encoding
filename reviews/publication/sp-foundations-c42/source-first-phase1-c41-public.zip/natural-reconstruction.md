# Independent natural-only reconstruction

Identity: `/root/sp_foundations_source_first_c41`. Direction: independent natural-math/topology audit. Evidence layer: mathematical reconstruction of the pinned natural text only; no formal decoding, author classification, implementation inspection, kernel observation, or publication verdict.

Source identity: `input/c40-author/natural-source.md`, title *Finite state preparation: matrices, certificates, and primitive routes*, SHA256 `7472eeb8fefe3fffdf662b38751e36401c0b2f770b25a149ae6bcc9f6bc49c79`, 90 source lines. Original provenance is AUTHOR/WIP and RETROSPECTIVE_IMPLEMENTATION_INFORMED. “Source-first” describes this review's order of exposure, not a historical/pre-proof origin of the source. Declaration-like names below are text anchors copied from the natural source, not verified formal declarations.

## F: carriers, contracts, basis and operations

F01, line 7. For n in Nat let N=2^n. Vectors are functions Fin(N) -> C and matrices are C-valued Fin(N) x Fin(N) arrays. Multiplication acts on column vectors: (Uv)_r=sum_c U_rc v_c. The standard ket e_j is the Kronecker delta, so Ue_j=U[:,j]. The distinguished input is e_0; adjoint means conjugate transpose. A concrete gate has an actual unitary matrix. A concrete preparation certificate contains a target, that gate, a proof of the target's stored normalization proposition, and the exact vector equation Ue_0=t.amplitudes. The proof of a stored proposition is not the definition of physical normalization.

F02, line 9. The generic target is (amplitudes, normalization:Prop, source:String). The generic candidate additionally stores a matrix, isUnitary:Prop, display circuit, layered schedule, resources and auxiliary count. A generic verified object proves its two stored propositions and the first-column equation. If both propositions are True, those fields alone say nothing about matrix unitarity or vector norm. The six particular targets in T/B instead use sum_r |v_r|^2=1. The primitive-route structure also retains the target's own proposition, but independently gets a unitary evaluated circuit and genuine state equality. Consequently its amplitude vector is mathematically normalized by unitary norm preservation, even when its stored proposition is not itself a norm equation. This consequence must not be confused with strengthening that field's type.

F03, line 11. The concrete-to-generic wrapper permits arbitrary display circuit, schedule, resource and auxiliary values. Its certified matrix and target do not thereby implement that display IR or justify a schedule/resource refinement. The X/H examples make particular display choices and compute their literal costs, but the wrapper has no universal display-soundness theorem.

F04, line 13. Named bits b:Fin(n)->Fin(2) flatten by E_n(b)=sum_i 2^i b_i; E_(n+1)(b)=b_0+2E_n(b_1,...), and E_0 is the unique empty bit assignment sent to 0. For n=2 the flat sequence 0,1,2,3 corresponds to (b_0,b_1)=(0,0),(1,0),(0,1),(1,1). Simultaneous reindexing U_LE[r,c]=U[E_n^-1(r),E_n^-1(c)] is a basis permutation conjugation, preserving products, adjoints and identity, and hence unitarity. It is not transpose and does not reverse circuit order.

F05, line 15. Define R(c,s)=[[c,-s],[s,c]], and RY(theta)=R(cos(theta/2),sin(theta/2)). Its columns are orthonormal by cos^2+sin^2=1. Lift to a chosen wire by a delta on every other wire and this 2x2 block on the chosen bit. X permutes a chosen bit; CX permutes a target conditional on a distinct control, fixing other bits. RZ(theta)=diag(exp(-i theta/2),exp(i theta/2)). X/CX are permutation unitaries and RZ has unit-modulus diagonal entries, so all typed primitives are unitary. Chronological lists obey eval([])=I and eval(g::rest)=eval(rest)eval(g); induction gives eval(L++R)=eval(R)eval(L). Existing supplier labels in the source are ConcreteSemantics, PrimitiveBasisLE, PrimitiveCircuit, PrimitiveSemantics and UniformlyControlledRy; this review has not inspected their implementations or certified reuse.

F06, line 17. Resource=(oneQubit,cnot,oracleCalls,pureAncilla,depth) consists of natural fields with zero defaults; gates=oneQubit+cnot+oracleCalls. Sequential combination adds every field; parallel combination adds counts and takes the maximum pureAncilla/depth. This literal algebra is distinct from primitive wire-depth evaluation. Primitive X/RY/RZ each contribute one one-qubit gate and CX one cnot; no primitive here consumes an oracle or pure ancilla. For each chronological instruction, assign 1+max(current depths of touched wires), updating precisely those wires. Route cost is (aux=0,gates,depth,oracles). Strict betterThan compares gates first, then depth on equal gates, then auxiliary count on preceding ties, then oracle count on all preceding ties. Auxiliary count is first in the printed record, not first in the comparison.

## T: the two one-wire certificates

T01, line 21. In Fin(2), zeroIndex=0, oneIndex=1, X=[[0,1],[1,0]], oneState=e_1=(0,1), and oneTarget stores this vector and its squared-norm equation. X*=X, X^2=I, ||e_1||^2=1, and Xe_0=(0,1). These separately establish pauliX_unitary, oneTarget_normalized and pauliX_prepares_one. pauliXGate and pauliXCertificate assemble, rather than assume, the matrix/normalization/action facts.

T02, line 23. Let a=sqrt(2)/2 with the positive real square root, embedded in C. Then a is real, a^2=1/2 and |a|^2=1/2. H=[[a,a],[a,-a]] is real symmetric, so H*=H; H^2=[[2a^2,0],[0,2a^2]]=I. plusState=(a,a) has norm squared 1 and He_0=(a,a). invSqrtTwo_mul_self, star_hadamard, hadamard_unitary, plusTarget_normalized and hadamard_prepares_plus are the respective source anchors; hadamardGate and hadamardCertificate package them. The representative is exact, not a phase class.

T03, line 25. pauliXCircuit and hadamardCircuit are singleton display gates oneQubit("X",0) and oneQubit("H",0); corresponding schedules are singleton layers. pauliXVerified/hadamardVerified combine each concrete certificate with its display data and circuit.resource. For each, the literal cost record is (aux=0,gates=1,depth=1,oracles=0), from that singleton definition and default auxiliary count. pauliXCertificate_prepares_one and hadamardCertificate_prepares_plus are projections of existing action proofs. No matrix evaluation is attached to the string "H" by this fact, and H is not an X/RY/RZ/CX constructor.

## B: literal matrices and separate arithmetic

B00, line 29. All following states/matrices are literal data, with unlisted coordinates zero and Fin(4) final cases exhaustive. Gate/Certificate packaging consumes normalization/unitarity/action facts rather than making those facts assumptions about an oracle. No characterized, choice-selected, canonical-completion or quotient object is being defined.

B01, lines 31-35. With a as above, v_B=(a,0,0,a) and

    U_B=a [[1,0,0,1],[0,1,1,0],[0,1,-1,0],[1,0,0,-1]].

Column supports are {0,3},{1,2},{1,2},{0,3}. Same-support cross products cancel; different-support products vanish. Each squared column norm is 2a^2=1. Thus U_B*U_B=I; real symmetry also gives U_B*=U_B. Its first column is v_B and ||v_B||^2=2|a|^2=1. bellAmplitude, bellState/Target/Matrix, star_bellMatrix, bellMatrix_unitary, bellMatrix_prepares_target, normalization, bellGate and bellCertificate denote those facts/data in the source. This is one Bell completion, not a derived Bell primitive circuit.

B02, lines 37-44. Put (A,B,C,D)=(39,52,60,144), L=169. The state is (A,B,C,D)/L and the matrix is

    U_D=(1/169) [[39,-52,-60,-144],
                [52,39,-144,60],
                [60,144,39,-52],
                [144,-60,52,39]].

For the real quaternion-pattern matrix, the six pairwise column dot products are -AB+AB+CD-DC, -AC-BD+AC+BD, -AD+BC-BC+AD, BC-AD+AD-BC, BD+AC-BD-AC, and CD-CD-AB+AB, all zero. Each column squared norm is A^2+B^2+C^2+D^2=1521+2704+3600+20736=28561=169^2. Hence division gives a unitary matrix and normalized first column. mottonenDenseState/Target/Matrix/Gate/Certificate, mottonenDenseTarget_normalized, mottonenDenseMatrix_unitary and mottonenDenseMatrix_prepares_target are fixed-instance names, not a general Mottonen compiler claim. The state fallback is coordinate 3, and the final matrix fallback is (3,3)=39/169 only.

B03, lines 46-53. With c=3/5,s=4/5, c^2+s^2=1. Set v_P=(9,12,12,16)/25=(c,s) tensor (c,s), using flat high/low tensor ordering. The displayed matrix is

    U_P=(1/25) [[9,-12,-12,16],
               [12,9,-16,-12],
               [12,-16,9,-12],
               [16,12,12,9]]=R(c,s) tensor R(c,s).

Tensor multiplication gives U_P*U_P=I. Its first column is v_P, and ||v_P||^2=(81+144+144+256)/625=1. The probability tuple, if interpreted through squared moduli, is (81,144,144,256)/625. groverRudolphProductState/Target/Matrix/Gate/Certificate and the normalization/unitarity/action anchors certify only these literal data. The equal tensor factors conceal some bit-order errors, so bit order must independently follow F04/P03, not be inferred merely from this symmetric target.

B04, lines 55-62. N=8 and v_S=(3e_0+4e_2+12e_4)/13. U_S has columns u0=v_S, u1=(-4e_0+3e_2)/5, u2=(-36e_0-48e_2+25e_4)/65, u3=e_1,u4=e_3,u5=e_5,u6=e_6,u7=e_7. Equivalently its rows are

    [3/13,-4/5,-36/65,0,0,0,0,0]
    [0,0,0,1,0,0,0,0]
    [4/13,3/5,-48/65,0,0,0,0,0]
    [0,0,0,0,1,0,0,0]
    [12/13,0,25/65,0,0,0,0,0]
    [0,0,0,0,0,1,0,0]
    [0,0,0,0,0,0,1,0]
    [0,0,0,0,0,0,0,1].

The first three squared norms are 169/169,25/25,4225/4225; pairwise inner-product numerators are (-12+12),(-108-192+300),(144-144). The other five columns are mutually orthonormal and disjoint from rows {0,2,4}. Thus U_S*U_S=I and its first column is normalized v_S. sparseThreeState/Target/Matrix/Gate/Certificate and normalization/unitarity/action names refer to this exact completion. It is not identity on the complement in the sense of fixing those indexed basis vectors: U_Se_3=e_1, not e_3. It supplies no parametric sparse-state compiler or sparse resource bound.

B05, line 64. For every N,b,lambda in Nat, f=4*((N+lambda-1)/lambda)+8*b*lambda, with truncated subtraction and total natural division. f(16,1,1)=4*16+8=72; f(16,1,4)=4*4+32=48 because 19 div 4=4; hence 48<72. The function is total, including lambda=0; under the stated natural-division convention N div 0=0, so f(N,b,0)=0. No positive-lambda restriction is silently added. The three selectSwapCleanTCount fact anchors are isolated arithmetic, not a SelectSwap implementation, T-decomposition or precision theorem.

## P: evaluated circuits, UCRY and two product-state routes

P01, line 68. For every n and well-typed primitive circuit, each primitive is unitary, finite chronological products are unitary, and E_n reindexing preserves unitarity. Therefore evalPrimitiveCircuitLE(C) is unitary. ExactPrimitiveStatePreparationRoute(n) stores a target, typed C, a proof of that target's particular proposition, and eval_LE(C)e_0=t.amplitudes. Its unitary projection comes from circuit semantics, not the stored normalization proposition. Its cost is literal F06 cost.

P02, line 70. amplitudeRotation(c)=R(cos(arccos c),sin(arccos c)). Under the four stated real premises -1<=c, c<=1, 0<=s, c*c+s*s=1, cos(arccos c)=c and sin(arccos c)>=0. The two sine squares agree by the circle identity, so nonnegativity gives sin(arccos c)=s. This reconstructs private amplitudeRotation_eq_pythagorean. cosine35=3/5,sine35=4/5,cosine513=5/13,sine513=12/13; ryAngle35=2 arccos(3/5), ryAngle513=2 arccos(5/13), ryAngleZero=0, with the rational-domain proofs carried by angle construction. Half-angle cancellation yields standardRyMatrix_ryAngle35=R(3/5,4/5), standardRyMatrix_ryAngle513=R(5/13,12/13), standardRyMatrix_ryAngleZero=I. The 5/13 branch is reusable data with no downstream product-route dependency. The exact source premise list is four; this is not a claim of logical irredundancy, since the real circle equation itself implies |c|<=1.

P03, line 72. primitiveLEBits(n,i)=E_n^-1(i). Reindex the chronological append law to obtain eval_LE(L++R)=eval_LE(R)eval_LE(L). A singleton RY on wire t has zero entry if any non-target row/column bit differs; otherwise its entry is RY(theta.eval)[bit_r(t),bit_c(t)]. This is a matrix-entry statement, stronger than first-column or distribution equality.

P04, lines 74-76. Let w:Fin(m)->Fin(n), t:Fin(n), with every w(k)!=t, and let A assign exact angles to all control-bit tuples. Repeated w(k) are allowed. Fix a non-target context z, which selects the consistent tuple k |-> z(w(k)). The compiled UCRY's target block is RY(A(tuple).eval) and other-context entries vanish. Necessary construction dependencies include typed angle evaluation, distinctness from target, bit/context transport, chronological composition, rotation identities, and the recursive compiler block proof; no single item implies this result.

Base compiler: zero controls gives RY(A(empty)). Recursive compiler: split A into A0,A1; alpha=(A0+A1)/2, beta=(A0-A1)/2 as tail tables; emit UCRY(alpha),CX(head,t),UCRY(beta),CX(head,t). In a context with head bit 0 the matrix product is RY(beta)RY(alpha)=RY(alpha+beta)=RY(A0). With head bit 1 it is X RY(beta) X RY(alpha)=RY(-beta)RY(alpha)=RY(alpha-beta)=RY(A1), since X RY(beta) X=RY(-beta). Tail induction works even if head/tail controls repeat: controls are never changed, so each selected tail tuple is the same consistent tuple before/after both CXs. Unreachable inconsistent tuples impose no physical block obligation. No injectivity premise is needed. This is the source's existing-supplier route; no unseen implementation theorem is claimed here.

P05, lines 78-80. For n=2, t=0,w(0)=1 with 1!=0 and theta=2 arccos(3/5), the angle table is constant theta at both control bits. Tree circuit = [RY_1(theta)] ++ UCRY_0(theta,theta). Factorized = [RY_1(theta),RY_0(theta)]. Each UCRY context has exactly the same target block; context-preserving matrix-entry equality gives groverRudolphConstantUcry_eval. Chronological composition gives groverRudolphTree_eval_eq_factorized and basis reindexing gives groverRudolphTree_evalLE_eq_factorized. All columns and relative phases agree, not just the e_0 action.

P06, line 82. Low and high lift matrices, respectively, are

    L=[[c,-s,0,0],[s,c,0,0],[0,0,c,-s],[0,0,s,c]],
    K=[[c,0,-s,0],[0,c,0,-s],[s,0,c,0],[0,s,0,c]].

The factorized chronological list applies K first and L second, so its matrix is LK, not KL by mere list convention (the two happen to commute). Multiplication gives

    LK=[[c^2,-cs,-cs,s^2],[cs,c^2,-s^2,-cs],
        [cs,-s^2,c^2,-cs],[s^2,cs,cs,c^2]]=U_P.

This reconstructs lowMatrix/highMatrix, lowEval/highEval and groverRudolphFactorized_evalLE_eq_matrix. With B03's first-column result it yields groverRudolphFactorized_prepares_target. Transfer through P05's full operator equality yields groverRudolphTree_prepares_target. Each Route additionally consumes B03 normalization and its literal typed list. These are alternative sufficient routes to the same target, not simultaneous prerequisites for preparation. A distinct comparison root uses BOTH route/action and cost records.

P07, line 84. Factorized list: RY_1(theta),RY_0(theta), wire depths (0,1),(1,1); oneQubit=2,cnot=0, depth=1, auxiliary=0,oracleCalls=0,gateCount=2. Tree list exactly: RY_1(theta),RY_0(alpha),CX(1,0),RY_0(beta),CX(1,0), where alpha=halfAdd(ryAngle35,ryAngle35) evaluates to theta and beta=halfSub(...) evaluates to zero. Wire depths are (0,1),(1,1),(2,2),(3,2),(4,4). Thus oneQubit=3,cnot=2,depth=4,auxiliary=0,oracleCalls=0,gateCount=5. No syntactic simplification removes the zero rotation or either CX. Cost records (0,2,1,0) and (0,5,4,0) compare by 2<5, with no tie-break use. The ordering establishes a fixed matched-target improvement, not global optimality or a runtime theorem.

## Q: exact scope and outstanding evidence

Q01, line 88. All equality claims fix exact complex representatives, not global-phase equivalence. Fixed primitive routes start with two all-zero DATA wires and no separate ancilla/workspace; T/B likewise have their stated all-zero data inputs. There is no measurement, accepted sector, garbage, heralding, failure branch, postselection or amplification. Exact normalized unitary action is deterministic ideal state preparation; this is not a separately supplied Born-probability theorem. No epsilon/numerical error, amplitude lower bound, finite-bit angle evaluator, rounding, Clifford+T synthesis, fault-tolerant cost, connectivity, routing, preprocessing runtime, input-oracle construction or readout theorem is present.

Q02, line 90. Literal definitions keep their whole public carriers; Fin(4) fallbacks are true final cases and B05 intentionally includes zero parameters. No characterized/quotient/choice definition is claimed. An occurrence of native_decide is merely a token to be inventoried later, not evidence of acceptance, axiom dependence or a trust violation. No such observation was performed in this natural-only stage.

## Reconstruction conclusion (not an admission verdict)

The displayed finite matrix, rotation, recursive-block and literal-count arguments are internally consistent on this read. No mathematical counterexample to their stated bounded contracts was found. Several stronger readings are false; explicit witnesses and seven semantic-slot checks are in `semantic-boundaries.md`. Source source-wide declaration-coverage assertions, existing-supplier implementation correspondence, formal theorem signatures, trust dependencies and actual acceptance remain untested. This review is an independent extraction and cannot self-approve its topology under the distinct-reviewer rule.
