# Seven semantic slots and discriminating boundaries

Natural-only identity `/root/sp_foundations_source_first_c41`; source digest `7472eeb8fefe3fffdf662b38751e36401c0b2f770b25a149ae6bcc9f6bc49c79`. These are hand-derived mathematical discriminators, not executed simulator/Lean tests or a comparison to formal targets.

## Seven slots

1. **Target and normalization.** Six concrete targets: e_1, (a,a), (a,0,0,a), (39,52,60,144)/169, (9,12,12,16)/25, and (3e_0+4e_2+12e_4)/13, each with physical squared norm 1. Generic target normalization is arbitrary Prop; generic verified candidate unitarity is arbitrary Prop. Primitive-route unitary evaluation plus exact action separately implies physical target normalization, regardless of what the stored Prop means. Do not conflate that implication with the stored-field definition.
2. **Dimensions/scalars/order/basis.** Matrices over C with real entries/angles in these examples. n=1 for T, n=2 for Bell/dense/product and both primitive routes, n=3 for sparse; generic primitive claims quantify over Nat n. Bit wire 0 is least significant. Tensor display uses high/low ordering. n=0 has one empty assignment/one basis index. No Fourier convention is involved.
3. **Oracle/access/control.** No input oracle, coherent parameter-label register, supplied inverse oracle, or black-box access is used in the fixed examples. Generic primitives include X/RY/RZ/CX. CX requires distinct control/target. UCRY requires each control different from target but does not require pairwise different controls. Exact angles are mathematical input syntax with real evaluation, not efficient data-access contracts.
4. **Ancilla/workspace/overwriting.** All data wires initially zero; they are transformed into the output state and not preserved. No separate dirty/clean ancilla or garbage sector exists for the fixed primitive routes. Display-wrapper auxiliary counts are freely supplied data, unlike a derived semantic ancilla guarantee. Display schedules have no automatically supplied validity proof.
5. **Phase.** All vector/operator equalities are representative equalities. Bell/H use positive sqrt(2)/2. RY has negative upper-right entry and half angle; RZ signs are fixed. Tree=factorized is full-operator equality, so relative phases and every input column are preserved. No quotient licenses dropping signs or parameter-dependent phases.
6. **Norm/error/success.** Exact ideal semantics, physical sum |v|^2=1 on six fixed targets. No epsilon, empirical fidelity, probabilistic confidence, measurement probability theorem, postselection success branch or amplification. Deterministic ideal preparation is a consequence of exact unitary state action, not an experimental claim.
7. **Resources/model.** Literal natural counts with greedy wire-depth for typed primitive lists and a strict lexicographic comparator. X/H display cost each (aux=0,gates=1,depth=1,oracles=0); factorized (0,2,1,0); unsimplified tree (0,5,4,0). SelectSwap-like f is total arithmetic only. No finite-bit synthesis, angle evaluation runtime, compilation runtime, connectivity, fault tolerance, general asymptotic preparation bound, classical preprocessing or readout cost.

## Concrete counterexamples to stronger interpretations

C01, generic Prop laundering. For n=1 choose U=2I, t.amplitudes=2e_0, t.normalization=True and candidate.isUnitary=True. The two stored propositions and Ue_0=t hold, but ||t||^2=4 and U*U=4I. This refutes a universal physical-soundness inference from generic VerifiedStatePreparation alone. It is NOT a counterexample to concrete gates or primitive routes, whose unitary matrices exclude 2I.

C02, display/cost laundering. Use the concrete X certificate preparing e_1 but supply an empty display circuit, empty schedule and zero resources/auxiliary count. The permitted wrapper fields still assemble; an empty interpreted circuit would be I, not X, and would prepare e_0. Therefore the wrapper cannot certify its arbitrary display circuit or count. For the actual singleton display examples, the stored literal counts are still correct as display facts.

C03, first column is not a full operator. X and X diag(1,-1) both send e_0 to e_1 but act on e_1 with opposite signs. Thus a first-column certificate alone cannot supply the P05 tree=factorized full-operator conclusion. Here that conclusion instead follows from context blocks and composition.

C04, distribution is not exact state. (a,a) and (a,-a) have identical squared-modulus tuples but are distinct vectors and not related by a global phase. Even -(a,a) is distinct under this source's exact representative equality. Distribution-only evidence cannot certify the stated vector/operator equations.

C05, LE order is substantive. Flat index 1 means wire 0=1,wire 1=0; flat index 2 means the reverse. For e_0 input, X on wire 0 gives e_1 and X on wire 1 gives e_2. This distinguishes conventions even though the symmetric product example's equal factors would mask a swap.

C06, chronology is substantive. On one wire, chronological [X,RY(pi/2)] evaluates to RY(pi/2)X, whose e_0 output is (-a,a). Reversing the matrix order gives XRY(pi/2)e_0=(a,a). The source ordering is therefore essential; disjoint factorized gates commuting is not proof that reversal is generally harmless.

C07, half angle and nonnegative sine. RY(pi)=[[0,-1],[1,0]], whereas replacing its half angle by pi would give -I. In amplitudeRotation, c=0,s=-1 satisfies c^2+s^2=1 and c's bounds but R(c,s)=[[0,1],[-1,0]] differs from amplitudeRotation(0)=R(0,1). The s>=0 premise matters. By contrast the two c bounds already follow from the real circle equation; preserve the four stated premises without asserting logical minimality.

C08, sparse complement. U_Se_3=e_1, hence U_S does not fix all complement-indexed basis vectors. Replacing its completion by a presumed identity changes the matrix. The natural text itself already warns against this stronger reading.

C09, repeated controls. Let w(0)=w(1)=1,t=0. Only control tuples (0,0) and (1,1) occur physically; entries of A at (0,1)/(1,0) are unreachable. Demanding an injective w would unnecessarily exclude this valid compiled block statement. Allowing w(k)=t, however, would make its CX illegal and the non-target-context argument fail. No claim is made for that excluded case.

C10, literal versus optimized resources. Tree alpha evaluates to theta and beta to 0. Removing RY_0(0) and cancelling the two now-adjacent CX instructions would leave the factorized action. That mathematical simplification does not change the original stored list's count 5 or depth 4. Counting only semantically nontrivial gates would use a different resource function.

C11, lexicographic is not componentwise. A cost with gateCount=1,depth=100 beats one with gateCount=2,depth=1 regardless of later fields. Thus betterThan alone does not imply improved depth, Pareto dominance, or global optimality. The particular factorized example happens to improve both gates and depth.

C12, total arithmetic zero regime. f(16,1,0)=0 by natural div-by-zero, whereas f(16,1,4)=48. Treating f on its entire public carrier as a positive physical clean-T cost or automatically rewriting its quotient as a ceiling fails at lambda=0. For positive lambda the arithmetic ceil interpretation is a separate conditional fact, not a restriction on the original total definition.

## Missing evidence versus mathematical falsity

The above refutations target explicit stronger interpretations, not the source's bounded positive statements. No implementation/formal mismatch is asserted. The six-family/data assertions, actual theorem signatures, module coverage, whole-module/toolchain binding, distinct topology review, formal decoding, semantic comparison, kernel/axiom observation and admission are pending. No failure is inferred from native_decide spelling. No alternative circuit for Bell/dense/sparse is invented to fill an absent route.

Exact-real transcendental semantics are not finite-bit algorithms. The absence of runtime/approximation theorems is an unproved boundary, not a proof that no such algorithm exists. Likewise a zero-resource generic display wrapper is not a physical zero-gate realization.
