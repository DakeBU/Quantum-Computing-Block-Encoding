# Phase3 independent comparison and distinct author-topology review

Reviewer `/root/sp_foundations_source_first_c41`. The natural-only review was sealed as `7178f0eee83f2532b2c4fe3f92f89da0b54a5e7d791a2b4d17b60edc2239ce32`; the independent full-target comparison was then sealed as `0728a606f4e7a29371c29fadccd8f08e6a0efb17c92daaa266384ddde3307224` before this decoder/author-metadata release. Neither earlier packet is modified.

## Results, separated by evidence object

The independently sealed formal decoder agrees with the bounded mathematics reconstructed in phases1/2. All six fixed target vectors, their literal full matrices, physical normalization, standard complex unitarity, first-column actions, generic interface limitations, LE bit convention, RY half angle/sign, full UCRY semantics, full tree/factorized operator equalities, and unsimplified cost tuples agree. No mathematical target mismatch was discovered on the new comparison.

Author declaration identity coverage is complete: all 103 source declarations, including 5 private, match this reviewer's independently sealed name/start-line/kind/visibility ledger; all 103 also have author graph dispositions. Author natural coverage accounts for every nonblank source line. These facts do NOT validate every author signature string or every hyperedge.

The distinct review of the author's topology and drill-down record is **CHANGES REQUIRED**, not approved as complete. The source's explicit tensor-versus-direct B3 proof alternatives are compressed away, and several operator/state dependency tails need explicit repair, notably the factorized-to-tree bridge. Four cost theorem inventory signatures are genuinely truncated inside their conclusions; another 21 record-valued definition strings end in partial body fragments. The binder audit's claim of complete signature drill-down is therefore not yet true of that inventory. These are evidence-extraction/topology defects, not evidence that the actual released Lean statements or finite mathematical contracts are false. Precise edge dispositions and proposed metadata repairs are in `author-topology-review.json` and `findings-and-erratum.json`.

The already found Bell non-data declaration count exception remains a real source-prose discrepancy. A minimal editorial correction is independently justified and recorded with exact before/after text. It does not change any mathematical statement, matrix, premise, definition, or coverage obligation. No old source or production code has been edited, and no new source digest, final publication metadata or admission status is presumed.

## Exact decoder object and comparison

The decoder identity is `/root/sp_foundations_formal_decoder_c41`, run `sp-foundations-c41-formal-decoder-20261017T035329Z`. Its exact seal hash is `c2e1a30cac9efb138879ea00acb5bbca3753a1ca33055418e9409bba4becfa42`, reconstruction hash `5554bd2ec2e51ee7e4e00466241223f88016d2579b70d3ecb9046d6ed4380991`, and input-pins hash `977434291693c8077bf82473b670c536aac437e2ac85c07178bd638fd4bcf2ad`. All 15 formal input pins agree with this reviewer's pre-decoder phase2 allowlist. The decoder states that it read formal code only, followed no imports and performed no compilation/trust execution; this is its bounded attestation, not a cryptographic proof of real-world independence.

| Decoder region | Comparison with source-first reconstruction and actual released code |
|---|---|
| 1: carriers/contracts | Same Fin(2^n), column-vector applyVec, basis kets, arbitrary generic Props, actual complex unitary certificate, unconstrained display/schedule/resource wrappers. Its ambient BlockEncodingSpec/layout remarks are provider context, not added SP/BE claims. |
| 2: resource/languages | Same distinction between untyped display Gate and typed PrimitiveGate; actual Resource arithmetic, strict comparator and touched-wire greedy depth. Extra ambient ExactAngle/PrimitiveProgram/repr details do not supply a numerical evaluator or global-phase quotient. |
| 3: primitive semantics | Same negative upper-right RY entry, half angle, positive-control CX, context-preserving lifts, permutation convention, simultaneous basis change and chronological multiplication. RZ cosine/sine form agrees mathematically with source exponential notation. The two interval binders on a provider's half-angle-cancellation theorem are unused there, but the target's private amplitude identity has the separate four stated premises. |
| 4: UCRY | Same base and halfAdd/CX/halfSub/CX recursion, exact head0/head1 block products, no control injectivity, consistent repeated-control assignments. The decoder additionally derives unoptimized Ry count 2^k and CX count 2^(k+1)-2; these follow from R0=1,C0=0,R(k+1)=2Rk,C(k+1)=2Ck+2. It explicitly labels them a mathematical consequence, not an existing compiled resource theorem. This does not enlarge the natural source's publication claim. |
| 5: target01 | All 29 declaration contents agree: exact X/H matrices and certificates, singleton display costs and projection-only final theorems. Neither party certifies the untyped string H as a primitive implementation. |
| 6: target02 | All 38 declaration contents agree: Bell, dense quaternion-pattern, product tensor matrix, exact sparse eight-column completion, total Nat arithmetic including lambda0, and no general named-paper compiler claims. Decoder's explicit Bell adjoint theorem confirms the count exception rather than contradicting it. |
| 7: target03 | All 36 declaration contents agree, including private5, unused angle513, arbitrary stored target Prop, actual unitary evaluated circuits, low/high local matrices and proofs, full operator equality, exact actions, route records, costs(0,2,1,0)/(0,5,4,0), and first lexicographic disjunct. |
| 8-9: boundaries/handoff | Same distinction between supplied theorem text and fresh compiler/kernel evidence; no transitive imports, historical-paper equivalence, finite-bit/runtime/hardware/readout claims, final publication or PURIFIED status. |

## Arbitrary stored Prop is compatible with derived physical normalization

There are three different implications, and neither reconstruction should be read as conflating them.

First, the generic VerifiedStatePreparation type proves a chosen normalization Prop, a chosen isUnitary Prop and a first-column equation. Both Props may be True. For U=2I and amplitudes2e0 all these generic fields can hold while the squared norm is4. Generic membership alone cannot imply physical normalization or unitarity.

Second, a ComplexStatePreparationCertificate really supplies a complex unitary U and exact amplitudes v=Ue0. Independently of its chosen stored normalization Prop, elementary finite-matrix algebra gives

    sum_r |v_r|^2 = v* v = e0* U* U e0 = e0* e0 = 1.

Here star denotes conjugate transpose and the middle equality uses actual unitarity; it is not inferred from a field name. The same derivation applies to the primitive route using its independently unitary evaluated matrix. Thus physical normalization follows for these stronger objects even if the stored Prop says something else. This is a mathematical consequence, not an additional target declaration or a retroactive type change.

Third, every fixed target in T/B actually chooses the physical sum-normSq equation and has its own explicit proof producer. Those field proofs remain real dependencies in packaging. Neither the decoder's description of the stored Prop nor the author's binder audit denies the norm-preservation consequence: the author expressly distinguishes it from an existing extra theorem. There is no semantic conflict to manufacture here. Arbitrary display data still do not inherit matrix-denotation/resource consistency from that consequence.

## Binder and definition audit against the independently sealed formal reading

The author's detailed binder-audit table agrees with actual code and this reviewer's prior expansion: carrier dimensions, finite indices, circuits, angle tables and objects are formation/input data; the generic route's normalization/action proof fields retain their stated propositions; the private amplitude lemma has lower,upper,sine_nonneg,normalization; UCRY requires each control unequal to target, not pairwise injective; context equality appears inside an if conclusion rather than as a convenient hypothesis. Fixed action/cost/normalization/unitarity theorems stay closed. The norm, angle, non-target, matrix-equality and first-column results are supplied internally when assembling fixed records; they are not added to fixed source-facing theorem binders.

No EXCESS logical assumption was found for the new bounded original teaching contract. This is not a historical-paper premise correspondence claim. SOURCE labels for proof-bearing fields describe the generic record interface, not a universal compiler theorem whose outputs were moved to assumptions. The classifications are acceptable with that explicit interpretation.

Definitions remain literal across their full public carriers. The dense/product Fin4 wildcards are exactly their final valid cases; sparse zeros/permutation completion are retained; total Nat f intentionally includes zero lambda. Real/arccos angle syntax and R(c,s) definitions do not introduce choice, quotient representatives, false uniqueness or a zero fallback outside a valid locus. Exact angle bounds belong to the corresponding constructor's domain witness and are supplied for rational constants. No finite-bit evaluator follows from a noncomputable marker or rational parameter.

However, accepting the classification after reading actual bodies is not the same as accepting the author's inventory completeness assertion. Four cost proposition strings stop at `{ auxiliaryQubits` and omit all values/remaining fields/closing brace. This is not a complete theorem signature. The 21 `where`-record def strings similarly include a dangling field label rather than a clean complete header or full field body. The actual formal code is available and was fully inspected, so no mathematical uncertainty is hidden from this reviewer, but future binder/signature binding cannot safely treat these strings as exact complete statements without correction.

## Source coverage and independent topology review scope

The author's 41 maximal nonblank-block regions and this reviewer's 33 coarser coverage regions describe the same natural text. The author excludes title, section headings and the provenance paragraph with reasons; this reviewer retained provenance as a process node. Both dispositions are defensible and no substantive mathematics is thereby omitted. The author's source_line_count91 versus this reviewer's90 is a terminal-LF convention: splitting raw text by LF retains one final empty segment, while Get-Content returns90 content lines. This is not an extra source paragraph or hash difference.

Every author node, all 16 hyperedges and all 103 declaration mappings were inspected. `author-topology-review.json` maps all 41 coverage regions back to the independently sealed natural identities and records each edge's full-tail/alternative-route judgment. Broad graph nodes can compress bookkeeping, but may not erase a required state-action bridge or an explicit alternative proof route. In particular TREE needs factorized action (or factorized operator=U_P plus B3 action), not merely tree=factorized and an otherwise unrelated U_P action. FACTORIZED needs its B3 target/first-column step made explicit when its head advertises both operator equality and target action.

This is an actual distinct review of the AUTHOR graph: the reviewer is not its extractor and had sealed an independent natural topology before formal/author-graph exposure. It is not self-approval of this reviewer's own phase1 graph. Because the inspected author graph requires repairs, its complete-topology approval remains withheld. A successor exact author graph/inventory must be rechecked; the current review does not magically approve future edits.

## Seven slots and shared-blind-spot check

The decoder comparison preserves all seven slots: fixed targets/physical norm versus arbitrary generic fields; C and Fin(2^n) with LE order; typed controls and no hidden oracle access; all-zero data and no extra work/garbage sectors for fixed primitive routes; exact phases/signs and all-column equalities; exact ideal action without measurement/success amplification/error theorem; literal exact-real logical counts/depth without finite-bit/hardware/runtime extrapolation.

The side-by-side route inspection found no common bit-order/half-angle/sign, dirty-ancilla, oracle-strength, relative-phase or resource-tier error in the two fixed circuits. This limited mathematical comparison does not replace actual compilation/kernel/trust or final admission gates. Both routes survive as constructions; factorized is cheaper under the frozen literal comparator. Tree's proof reuses factorized action after full operator equality, so there are not two independent whole proof implementations. Tensor/direct explanatory proof alternatives also remain source OR routes even though the actual finite Gram proof chooses one implementation path.

## Handoff and status

Failure class for the author evidence extraction is IMPLEMENTATION_FAILED: signature inventory serialization and source-topology encoding require repair. No bounded mathematical route is retired, and no compiler/trust result is asserted. The Bell count sentence has a separately justified editorial erratum, not a new mathematical premise or a secretly changed source.

Salvage: independent semantic alignment, all 103 declaration identities, exhaustive nonblank coverage, exact full sparse completion, proper generic-Prop/display boundaries, valid repeated-control semantics and exact primitive counts remain usable as manual evidence. Process-memory IDs consulted: none beyond already permitted instructions. No children, Lean/native/compiler/TCB, network/Git, production/registry writes or prospective final metadata reads occurred. Publication/current-binding checks, corrected exact author evidence and any final lifecycle status remain for a later explicit stage. Stop after sealing this packet.
