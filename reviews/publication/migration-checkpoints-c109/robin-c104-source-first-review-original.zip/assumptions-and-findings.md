# Assumption and definition audit

This is a natural-source audit, not an expanded Lean signature audit. SOURCE below means an explicit LOCAL antecedent in this retrospective source, not an authenticated external-paper premise. The source's mathematical summaries may omit implementation binders; those cannot be certified without later authorized formal inspection.

| Item | Classification | Exact role and limit |
| --- | --- | --- |
| Coeff expression type; Fin labels; natural n | TYPING / literal definition | Rational literal/symbol/add/mul/neg syntax; no semantic quotient |
| e:String -> Q | TYPING data | Total arbitrary rational interpretation, no implicit inverse or analytic identities |
| f(n,i), symbols and stencil entries | Literal source data | f is row scaling; A1*dx is one symbol; formulas fixed as printed |
| Stencil signed equality; left then right then bulk | Literal definition | No modular stencil wrap; totality does not validate small grids |
| n>=3 | SOURCE local premise | Required restricted image/preimage uniqueness; cannot drop at n=2 |
| Active source | SOURCE local premise, expanded | Clean padding AND slot<kappa; excludes encoded slot7 for kappa7, not zero-amplitude valid slots |
| Post/pre image existence, entry one, uniqueness | Proof ingredients / source support claims | Must be derived; not extra public assumptions of a hypothetical physical Anchor |
| Matrix finite-fold support exclusions | SOURCE local support premises / internal proof ingredients | All paths except specified labels zero; no global unitarity consequence |
| Selected branch evaluations and six vanishing diagonals | Source-asserted proof facts | Consequences can be derived; full gate definitions/case proofs absent here |
| Arbitrary H, J, K and proposed Hdagger | TYPING data | Matrices are not certificates of unitary preparation, coherent access, or inverse |
| Uniform(H) | SOURCE local premise, expanded | H[s,0]=a_symbol for EACH s in Fin7; all seven raw equalities, row7/other columns unrestricted |
| Hdagger[0,2]=H[2,0] | SOURCE local premise | For arbitrary proposed Hdagger; definitional if literal transpose; not physical adjoint |
| c=eval(Dslot2*N_D_inv) | SOURCE local scalar premise | Exact coefficient-identification equation; angle text alone does not prove it |
| e(N_D_inv)e(N_D)=1 | SOURCE local scalar premise | Required ND cancellation; ND and inverse nonzero, not necessarily positive |
| e(N_f_inv)e(N_f)=1 | SOURCE local scalar premise | Required NF cancellation; NF and inverse nonzero, not necessarily positive |
| e(kappa_inv)e(kappa)=1 | SOURCE local scalar premise | Required kappa cancellation; no assignment to numerical7 |
| e(sqrt_kappa_inv)^2=e(kappa_inv) | SOURCE local scalar premise | Along with previous law forces kappa_inv,kappa positive and amplitude nonzero in Q |
| A=Dcal(H), A=L(C), active/prepared entry equality | Conditional supplier / REFUTED exact raw contract | Must not be dropped from wrapper antecedents or presented as a viable unresolved same-contract supplier |
| Active-versus-grouped evaluated equality AND active-versus-selected evaluated equality | SOURCE local diagnostic premises | Both retained; diagnostic consumes them, does not construct them |
| An already supplied equality for J plus clean-column equality | SOURCE local congruence premises | Transports equality to H, not an equality constructor from columns alone |
| K(H) | Literal diagonal-compression definition | Not characterized by a unitary property, not a representative of a certified physical class |
| Singleton supplied-matrix semantics | Literal interface object | Label matching plus identity-seeded product; not a synthesis theorem |
| Normalizer (N_D*N_f)*kappa | Literal syntax | Distinct from numeric norm data, physical bound and finite-bit interpretation |
| SemanticObligation descriptions/Bool, unitary flags, error=0 | Data/status | No Prop proof of claimed physical behavior or error |
| Nested cache equality certificates | Genuine equality of stored objects, source reported | Do not infer unrelated normalized block equation |
| Resource formulas and 7/10/1 label counts | Data / context | Not expanded query, logical, finite-bit or workspace-cleanup proofs |
| Physical unitary, analytic trig, positive all normalizers | NOT SOURCE premises/results | Not silently inferred; only kappa-related positivity follows from scalar laws |
| Numerical symbol interpretation e(kappa)=7 | NOT a source premise | Adding it makes inverse/square laws inconsistent over Q; real-carrier extension is separate |

## Literal, characterized and representative objects

The coefficient constructors, stencils, row scaling, matrix folds, Uniform predicate, C family, Dcal and K are literal definitions at the described layer. None is characterized by unique physical preparation or chosen as a unitary representative. The source supplies no existence/uniqueness theorem permitting a physical object to be recovered by choice. No default-zero completion or unmentioned representative choice was introduced by this review.

## Excess-assumption check and limits

At the natural-source level the conditional scalar theorem retains all explicit antecedents; no EXCESS binder was added by this reviewer. This does not certify absence of EXCESS in actual Lean signatures, because they remain unread. Physical preparation, full lifted operator reduction, oracle/garbage correctness and costs remain obligations, not new assumptions inserted to call an Anchor complete. The refuted exact raw supplier is not repaired by assuming its conclusion.

## Findings

- F01 — W7 line103 positivity wording is too broad. The precise correction is: no general positivity or analytic relations follow, except positive interpreted kappa/kappa_inv and nonzero amplitude as consequences of the inverse/square laws. This does not damage the scalar cancellation result.
- F02 — With an additional kappa=7 interpretation, rational scalar realization is impossible by 7a^2=1. This is a proved conditional arithmetic obstruction. It is not a claim that a missing physical interpretation is impossible.
- F03 — Full private support proofs and many formal cache/predicate claims are asserted but not reproducible from the sole natural input. Their exact definitions/proofs are a later evidence gate, not a discovered counterexample.
- F04 — The law-satisfying kappa=1 rational witness demonstrates that adding the five scalar laws still does not supply active/prepared equality at nonzero target. It does not certify or refute a unitary H.
- F05 — The source correctly retires its exact raw active-fold contract. No genuine same-contract completed OR route is given; zero-factor cases are disjunctive scalar cases only.

