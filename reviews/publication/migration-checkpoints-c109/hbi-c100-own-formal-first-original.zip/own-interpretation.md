# Own interpretation of the complete formal target

This interpretation was authored after the immutable source-only derivation
and before any decoder. Source meanings below come from SOURCE_REVIEW, not
desired names, comments, compiler flags or another person's classifications.
Formal line references mean the target snapshot unless a provider is named.

## 1. Ambient context and what a declaration actually asserts

Lines 1-2 import HermiteBernstein and HermiteSampleStructure. The file opens
one noncomputable section, enters QuantumBlockEncoding.HermiteBoundaryInjection
and opens HermiteBernstein. There are no section variables, hidden ambient
hypotheses, project-owned typeclasses or local propositions carried into every
theorem. Its real scalar field, natural/Boolean types and imported arithmetic
instances are fixed. The noncomputable marker does not assert efficiency or
inefficiency, provide choice semantics, or prove a circuit.

The kernel matrices explicitly use _root_.Matrix, a function on two index
types. They do not use Core's dimension-parameterized Matrix alias. Generic
Kernel B is exactly natural level -> Boolean -> B -> B -> real. Fintype B
and Fintype C in generic sum/contraction lemmas supply finite summation data,
not normalization, unitarity or a promised physical system.

Three anonymous instances at lines 54,57,64 return Decidable Full/Outside/
Partial. They decide propositions; they do not assume or prove that any block
is full, outside or partial. Their lower/upper/first/size parameters are just
natural data. No target structure stores a desired conclusion as a proof field.

exact-interfaces.json contains all literal source interfaces. This is not an
elaborated signature inventory; abbreviations without a written result type
have their intended type reconstructed here, not falsely marked compiler-known.

## 2. Actual provider chain to the literal source target

HermitePolynomial.coefficientSeries k is exp(X)*(1-X)^(-(k+1)) in the
formal power-series ring. Its coefficient theorem (184-195) expands the
product using coefficient convolution and the exp/invOneSubPow coefficient
lemmas to the exact finite a_{k,i} sum. Independently, convolution gives
coefficient i = sum_{m=0}^i (1/m!)*binom(k+i-m,k), matching phase 1.
coefficientPolynomial truncates at k+1, so its evaluation is exactly
A_k(t), with degrees 0 through k included, not an exponential approximation
inserted into the target. endpointFactor evaluates to E_k(t).

sourceInterpolant is the Taylor shift by +1 of
exp(-1)*endpointFactor + endpointFactor composed with (1-X). Polynomial
Taylor evaluation is substitution t->p+1. Thus its evaluation is precisely
exp(-1)E_k(p+1)+E_k(-p)=P_k(p) on every real p. This literal expression,
not the alternative CRT interpolant or a uniqueness premise, supplies the
Bernstein root. Both CRT and uniqueness/jet results occur in the fully read
provider, but are not hypotheses of this target's sample theorem.

smoothInitial has cases p<-1, otherwise p<=0, otherwise: exp(p), P_k(p),
exp(-p). It matches the literal f_k including p=0. HermiteCutRank's
smoothInitial_strict (205-219) moves only p=0 to the right branch by the
right jet at j=0 giving P_k(0)=1. The provider's stronger derivative facts
are one implementation path to that endpoint equality; they are not added
source assumptions. affine_lt_cut (199-202) is positive-step real/natural
ceiling arithmetic, matching the independent phase-1 proof.

Core.gridSize n is literally 2^n. HermiteStatePreparation.gridPoint is
-pi L + j*(2pi L/2^width), and sampledAmplitude is just smoothInitial at
that grid point. It does not normalize. Its neighboring sampleNorm,
normalizedAmplitude, circuit, certificate and resource declarations do not
occur in the target root's conclusion or its explicitly referenced supplier
chain. Merely importing them supplies no boundary-injection quantum theorem.

PrimitiveSemantics.PrimitiveBasis q is Fin q -> Fin 2. The full
PrimitiveBasisLE provider defines its recursive equivalence and proves the
successor value bits(0)+2*value(tail). Hence wire zero is least significant.
The target instead defines J on MSB lists and constructs a flat Fin index
with that same integer value. There is no target theorem that maps a list
of bits onto wires or performs a permutation. Phase-1's reversal-of-position
observation is a numerical convention bridge, not a gate claim.

## 3. Restriction, core orientation and finite readout (lines 23-240)

wordValue is MSB J; wordValue_lt proves J<2^length. pathCoordinate is the
provider's nested outside-first affine coordinate. The target derives
Phi_w(0)=J/2^length, so no endian convention is assumed silently.

Bernstein.basis is a Mathlib polynomial evaluation with an explicit all-index
formula. On the used finite range it is B_i^d. sourceCoefficient is a literal
power-series coefficient, bridged to a_{k,i}; leftCoefficient is the source
double sum ell; sourceBernsteinCoefficient is exp(-1)ell_r+ell_{d-r}. All
natural subtractions are literal truncated subtractions, including beta's
nonzero extension beyond d. No finite-row zero extension is invented.

The provider's casteljauStep is the linear endomorphism z*shift+(1-z)*identity.
Its power expansion gives D_z^q. leftRestriction/rightRestriction/
restrictCoefficients match (5) exactly. The last is total at u=1 but has its
affine semantic theorem only at u!=1. Half subdivision is left for false,
right for true; subdivisionPath processes coefficient rows in list order,
while pathCoordinate nests the first digit outside the suffix. The full
proof chain was read; no polynomial/core equality is supplied as a premise.

injectedReadout uses endpoints 1+x(first) and 1+x(first+2^length), not the
last included sample. injectedReadout_eq assumes x(first)!=0, specializes
the guarded provider theorem, then substitutes J/2^length. It yields P_k
at x(first+J). This guard is a genuine leading hypothesis for the generic
lemma, and is absent from the final root only because it is proved locally.

unitCoefficient is the literal natural sequence with one at the finite input
index. sharedCore(i,j) is its half-subdivision at output j, a row-update
matrix. sharedCore_false/true derive exactly S_0/S_1 of the frozen source.
sharedCore_basis proves the finite adapter; sharedContract proves Q equals
Bernstein evaluation at Phi_w(0), even d=0 and empty words. The finite
injected readout is bridged unconditionally to the subdivision readout;
only the subsequent P interpretation needs x(first)!=0.

## 4. Generic traversal and schedule interfaces (lines 47-605)

Full is lower<=first AND first+size<=upper. Outside is first+size<=lower OR
upper<=first. Partial is NOT Full AND NOT Outside. They are total literal
predicates, not a structure containing interval validity. Reversed endpoints
and zero sizes are allowed as definitions. Traversals use positive powers
of two and inspect Full first.

boundaryReadout_eq has the real leading hypothesis
forall j, lower<=j -> j<upper -> x(j)!=0. Its result is a masked P value,
not a new prerequisite. The proof handles full/outside/partial recursion and
integer size-one arithmetic; the code does not require lower<upper.

InjectionBond k is Option(Fin(2k+2)); none is boundary, some i coefficient.
The four injectionCore clauses are exactly the triangular block (15).
injectionContract has boundary terminal zero and coefficient terminal e_0.
injectionContract_shared is unconditional no-return semantics.

ScheduleValid lower upper schedule width expands to
forall r<width, forall bit, Partial(lower,upper,selectedChild,2^r) ->
schedule(r)=selectedChild. It does not assert arbitrary target/core equality.
injectionContract_boundary genuinely takes BOTH this premise and root
Partial. Its conclusion is equality with the literal traversal, not yet a
sample theorem. The full-child proof uses the unconditional finite/literal
readout bridge, so no nonzero hypothesis is smuggled into this adapter.

boundarySchedule is 2^r*(cut/2^r) with natural division. The aligned-upper
partial-prefix proof derives first<lower<first+size and identifies the
quotient. boundarySchedule_valid concludes ScheduleValid for every natural
lower and upper 2^n at width n+1; this is a produced proposition, not an
assumed schedule. It uses r<=n to obtain upper divisibility. Prefix validity
uses its separate upper-cut bracket and works at any width.

boundarySchedule_root requires lower<=2^n and concludes start zero. Root
Partial requires lower<2^n. These strict/nonstrict hypotheses must not be
interchanged. Actual code disables middle when C=M, so no empty-root Partial
is claimed. partial_middle_prefix_unique and partial_prefix_unique are useful
integer lemmas but not a replacement for actual schedule validity.

ScalarBond is Option Unit. scalarCore/scalarContract implement the same
no-return mechanism with one free state. scalarBoundaryReadout_eq has a
genuine universal injection/free-factor/target identity as leading hinject;
target is input data, not an assumed final branch sample. scalarContract_boundary
requires schedule validity AND root partiality and needs no hinject itself.
The code keeps these two adapters separate, matching the source's distinction.

## 5. Actual grid, branches and empty cases (lines 608-1006)

leftFree, leftInject and their product identities are literal exponential
formulas for arbitrary real origin/step. The formula 2^r-1 in leftInject is
real subtraction; leftInject_eq_last proves the natural last-index version
after establishing positivity of 2^r. leftFreeContract_eq derives the
complemented-bit exponent. leftInject_readout discharges the generic hinject
for all first,words, not just an assumed successful target instance.

gridStep/gridPointNat match phase 1 exactly. Midpoint equality holds for all
L; positivity, strict monotonicity, strict-zero cut and lower cut require L>0.
cutIndex is Nat.ceil of (-1+pi L)/h, not a rounded comparison. Its bound,
clamped formula and middle membership equivalence are derived results.
injection_domain's positive size and Full are genuine leading hypotheses for
its three endpoint-bound conclusions. Actual middle nonzero locus follows
from the strictly negative middle support; right restriction endpoint one is
allowed because the left endpoint remains <1.

middleReadout is traversal rooted at zero, with all word widths admitted as
a total scalar expression. Its mask theorem holds for every word width,
because out-of-range natural queries simply return zero. Finite-contraction
equality additionally requires length=n+1 and L>0. Middle empty C=M is
explicitly zero. The private sampledAmplitude_word theorem (790-797) is the
flat-index definitional bridge with length proof but no L>0 assumption.
wordSampleIndex contains that proof only to construct Fin(2^(n+1)).

leftFiniteReadout disables C=0; otherwise it proves root partiality using
C<=M and length=n+1, then supplies the actual quotient schedule and
leftInject_readout to the generic scalar adapter. leftInject_bounds requires
an actual Full left block and L>0. These bounds are separate conclusions,
not required root premises and not a stability theorem.

rightFree's product is exp(-hJ). rightCore changes only level r=n to the
numeric bit. rightCore_suffix requires length<=n and proves agreement with
the free product. rightFiniteReadout_eq has no L>0 hypothesis: at exact
width n+1 it is zero for J<M, exp(-p_J) otherwise for all real L. The
sampledAmplitude identification adds L>0 to identify the actual support.
n=0 works through the empty suffix. No code excludes k=0 or C=0/C=M.

threeBranchReadout_eq_sample requires L>0 and correct word length. It rewrites
the three separately proved masks and uses C<=M to partition them. It adds
the outputs; it does not present three OR routes or normalize one branch.

## 6. Whole-kernel theorem and independent count suffix (lines 1010-1180)

kernelContract is generic backward contraction for any finite B and supplied
kernel/right vector; kernelAmplitude pairs with a supplied left vector.
sumKernel is a literal block-diagonal sum. The inl/inr and amplitude-sum
lemmas prove decomposition for arbitrary such data; no unitarity is assumed.
Adapters identify generic contraction with injection, scalar and one-state
contractions. Terminals exactly match phase 1.

leftKernel/middleKernel/rightKernel instantiate the formulas. leftInitial
and middleInitial contain the two empty-branch guards and are zero on all
free/coefficient inputs. Their amplitude adapters hold at every word width
and all real L by literal equality. HermiteFiniteBond is the tagged carrier
Option Unit + (Option Fin(2k+2) + Unit), with distinct states and correct
ordered association. hermiteKernel/Initial/Terminal form the required direct
sum. hermiteKernel_eq_sample unfolds them, applies both sum adapters and
threeBranchReadout_eq_sample. No hidden normalization or correctness object
is passed into this root.

hermiteFiniteBond_card concludes D=2k+6. HermiteCoreAddress is the ordered
product Fin(n+1) × Bool × B × B. hermiteCoreEntry projects these factors and
uses the remaining-suffix level n-t with natural subtraction; the finite t
range ensures the intended ordinary difference. hermiteCoreAddress_card proves
2(n+1)D^2. It neither enumerates stored values nor bounds evaluation time,
bits or a quantum gate count.

The EOF suffix also has injectionBond_card for the actual Option(Fin(2k+1+1)),
and MiddleBond:=Option(Fin(2k+2)) with middleBond_card. MiddleBond is not used
by hermiteKernel, the address count or other target declarations; its count
alone does not prove kernel correctness or an isomorphism-based replacement.
It is mathematically compatible with the source's alternative written carrier,
and retained as an unused suffix rather than omitted from review.

## 7. What this does and does not establish

Against the frozen source-only derivation, every target definition and theorem
has a source role or an explicitly generic adapter/bookkeeping role. No added
root hypothesis, weakened target, omitted endpoint or degree/width restriction
was found. Local generic conditions are proved by suppliers inside the root
route. All project-owned proposition aliases used as leading assumptions were
expanded; none hides an assumed desired sample equality at the root.

This is textual mathematical interpretation only. Tactic scripts and imported
Mathlib lemmas were read as code, not executed. No compiler result, axiom
closure, elaborated dependency graph, generated private name or raw-production
association is certified. The providers' unrelated preparation/rank/circuit
claims are not admitted by this target review. The source's retrospective
recovery and historical formalizer UNKNOWN remain unchanged.
