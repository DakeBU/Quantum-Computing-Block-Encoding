# Own source/formal findings and assumption audit

The comparison baseline is the immutable SOURCE_REVIEW/derivation.md and its
source topology, not inventory commentary or a prior reviewer/decoder. All
labels below are this reviewer's judgments from the independently read code.

## Root interface and data/conclusion distinction

For hermiteKernel_eq_sample (target 1141-1149), the only leading logical
proof inputs are hL:0<L and hbits:bits.length=n+1. The natural parameters
k,n, real L and Boolean list bits are data. There is no omitted ambient
variable context. The finite index uses hbits as a typing witness. These are
SOURCE/TYPING, matching the source exactly, not EXCESS proof ingredients.

The root's left side is a specific literal kernelAmplitude of specific
hermiteKernel, hermiteInitial and hermiteTerminal definitions; the right side
is unnormalized sampledAmplitude at wordSampleIndex. Neither side is an
unexpanded project-owned proposition bundle storing the desired equality.
Every target proposition alias that occurs as an assumption was expanded:
Full, Outside, Partial and ScheduleValid. Kernel is a data type, not a Prop.

The generic leading hypotheses are genuine and scope-limited:

- injection semantics: x(first)!=0;
- polynomial traversal: all interval lattice points have x(j)!=0;
- boundary adapters: ScheduleValid AND Partial(root);
- scalar target traversal: forall first,bits inject*U=target(first+J);
- integer uniqueness: positive block size and indicated partial blocks;
- endpoint bounds: positive size and Full;
- tail bounds: nonnegative step; actual injection bounds additionally Full.

Each is SOURCE for the corresponding generic statement or pure TYPING for
finite carriers. The actual root proves its needed instances internally.
No additional premise was found in the source-facing root. Source-hypothesis
and internal-dependency roles have not been conflated.

Conclusions such as StrictMono, ScheduleValid, three endpoint inequalities,
cardinality equalities and branch sample identities are produced results,
not caller promises. The three Decidable instances return decisions only.
Generic targets, kernels, schedules, injection/free functions and left/right
vectors are mathematical data; their adapter conclusions do not automatically
certify arbitrary data as the source construction.

## Definition classes and source-relative differences

Every target definition and abbreviation is literal. So are the relevant
provider coefficientSeries, coefficientPolynomial, endpointFactor,
sourceInterpolant, smoothInitial, gridPoint, sampledAmplitude, basis and
de Casteljau/restriction operations. No characterized/quotient/representative
choice is used to construct this root. The provider's CRT interpolant and
uniqueness theorem are separate available mathematics, not a uniqueness-based
definition silently substituted for P_k.

Source-relative classification:

| Issue | Own classification | Resolution |
| --- | --- | --- |
| k,n,L,width of final root | same | Zero k/n allowed; only L>0 and exact width required. |
| Explicit Fin witnesses, Option/Sum tags and Fintype generic binders | source-implicit / TYPING | Represent exactly the finite source carriers/sums; no stronger mathematical hypothesis. |
| Power-series coefficient and Taylor-shift representation of A,E,P | same after proved representation bridge | Provider's explicit coefficient/evaluation lemmas expand to the frozen finite formulas. |
| Source closed-middle p=0 versus strict sample-mask proof | same | Endpoint P(0)=1 supplied by a proved jet-at-zero fact; no target change. |
| Generic restriction x(first)!=0 | same / mathematically-necessary local guard | (6) is not claimed at u=1; actual full middle start is negative. |
| All-real midpoint/right branch algebra and all-word traversal adapters | generalization, internal | Stronger helper domain, unchanged guarded final target. |
| Natural sequence extensions beyond finite degree | same literal semantics | Truncated subtraction retained, not silently replaced with zero extension. |
| Finite shared matrices vs natural subdivision path | same after adapter | Unit coefficient plus finite sum proves row-core semantics; no equality premise. |
| MiddleBond unused EOF carrier | same cardinality-only alternative notation | No theorem uses its count to establish the real kernel. |
| Imported norm/circuit/rank modules | not extra root assumptions | Context/import availability is not a proof of the new construction's quantum semantics. |

RULED repairs: none. API-limitation assumption additions: none found.
EXCESS root binders: none found. This does not certify Lean elaboration.

## Findings

No mathematical mismatch with the frozen natural source was found in this
whole-target own interpretation. This is not a forced positive admission:
all compile, independent graph review, decoder comparison, raw association,
publication and integration gates remain unperformed.

The source-critical supplier chain is actual literal coefficient/evaluation
and sample definition code, not the imported cut-rank or normalized-circuit
results. The latter cannot strengthen (22) or (23). The count has no epsilon,
k-selection, L-selection, normalization or finite-bit semantics.

The one private theorem was included in the read and crosswalk. All three
anonymous instances were classified as decisions, not assumptions. The EOF
MiddleBond/cardinality pair was read and found unused by target consumers;
it remains explicit scope rather than disappearing from the module audit.

The natural source remains retrospective recovered local mathematics,
historical formalizer UNKNOWN, AUTHOR/WIP. This phase establishes no history,
novelty or raw-production provenance. Snapshot masking/LF transport is a
description in the authorized inventory, not a verified lexical or TCB
noninterference theorem. Its formal_snapshot_sha256 binds the actual bytes
read, while production_raw_sha256 was not used as a source-integrity check.

## Residual risks and stop condition

- No compiler execution: exact inferred types, elaboration, tactic success,
  axiom closure and actual theorem proof-term dependencies are unverified.
- All 33 files were pinned, but import-only files and Mathlib/Lean internals
  were not fully audited. Read dispositions are explicit, never blanket green.
- The source graph remains proposed, not independently approved; the formal
  supplier chain is textual/read evidence, not a replacement source graph.
- Decoder evidence has not been received; agreement or disagreement with any
  reconstruction cannot yet be asserted.
- There is no verified association to raw production bytes or module state.
- No normalized quantum-state or finite-bit resource conclusion follows from
  these target declarations.

Failure class: NONE for this own-reading task; compiler status NOT RUN, not
PASS. Remaining gates are pending authority/evidence, not source refutations.

STOP OWN_FORMAL_FIRST_FROZEN. Further comparison or raw-source association
requires separate explicit authorization; phase-1 and this packet remain
immutable evidence for that later phase.
