# C96 independent review of the C92 topology successor

Verdict: ACCEPTED FOR THE BOUNDED T1-T5 SOURCE-TOPOLOGY REPAIR SCOPE. No remaining T1-T5 defect was found in the actual pinned successor. This accepts a faithful map of source statements, non-inferential context and OPEN construction obligations. It does not certify that those obligations have witnesses, resolve the error-reference slot, prove a circuit or approve any final publication.

Reviewed object: W/uncompute-c92-gaussian-topology-successor/, exact nine-file allowlist. Manifest SHA256 8d554db406eae9f4b418735e8e416444f0145213192e03fdbdc60274b25aac4e; seal SHA256 95d1327a2383d70accf6a8c5bdcd22c751a04659073fc8b7422adc5b9a7fab7f. Logical aliases W/G/P are used throughout. The original C92 packet, C96 independent source-first packet and C96 comparison packet remain byte-identical for every authorized public name. No private render was accessed in this stage.

This verdict is independent of the successor author's acceptance statements and structural self-checks. I read all nine successor files as data; resolved the graph overlay against the exact frozen original node array; compared its historical crosswalk to the actual old graph and my earlier exact crosswalk; re-read complete primary PDF text pages9,10,33,36; and checked the mathematical roles and full tails below. Prior C96 source-first work had separately extracted and visually inspected complete relevant source pages. This stage adds no new visual inspection and makes no claim to re-inspect every PDF page.

## 1. What is accepted, and what is not

| Layer | Independent verdict |
| --- | --- |
| Source and packet identity; exact allowed membership | PASS. Exact pins, allowed payload hashes/sizes and base graph binding independently recomputed. |
| T1 local inverse/measurement OR | RESOLVED in the source graph. |
| T2 edge-role separation | RESOLVED. Specification, context, provenance and open requirements cannot be read as certified Gaussian derivations. |
| T3 actual lookup/modified-coefficient/phase/lifetime tails | RESOLVED as explicitly OPEN obligations, not supplied witnesses. |
| T4 complete common and route-specific numerical alternatives | RESOLVED. Numerical alternatives do not share an asserted resource tuple. |
| T5 dedicated lookup-semantic gap | RESOLVED; semantics, fitting data and counts remain distinct. |
| Exact analytic-versus-rounded error expression and uniform certificate | STILL OPEN; no interpretation or tolerance change accepted. |
| Actual circuit, all-record phase/cleanup, coefficient tables, resource counts | NOT VERIFIED AND NOT ADMITTED. |
| Lean, arbitrary-precision family, SP/BE, phase consumer, proof/publication admission | OUT OF SCOPE AND NOT ADMITTED. |

An open node is not a theorem assumption available for proving the source Anchor. Acceptance of an obligations graph is not acceptance of the obligations themselves. No mathematical route is retired and no source-invalid/circuit-false verdict is issued.

## 2. T1: local cleanup alternatives are now faithful

Primary Eq11 (physical9) uses a second Toffoli to clear a retained temporary AND. Eq12 instead destructively measures that AND, resets/releases its qubit and cancels the outcome-dependent sign with a conditional CZ on retained controls. The successor's L_STATE records the actual use-site relation t=uv and retained controlling data. L_INVERSE and L_MEASURE are separate mechanisms, and OR_LOCAL_CLEAR repeats the necessary local state/model tails in each alternative.

The head L_CLEAN is only the cleanup of that temporary AND with unchanged retained-data phase. It does not conclude arbitrary lookup erasure or a Gaussian function evaluator. The measured branch includes G05's all-record phase requirement. The boundary explicitly says that substituting inverse gates does not inherit1583/139 or other MBU savings. That repairs the original loss without creating a stronger local theorem or silently replacing the reported Gaussian implementation.

The historical G04 node remains imported unchanged for context; the added explicit alternatives, not a rewording of the immutable original record, carry the repair.

## 3. T2: the actual edge schema now prevents false closure

All21 ordinary successor edges and all3 OR records have declared roles. E01 and E02 are CONTEXT only, so the Methods criteria/statistics do not imply the reported9000 tests or uniform correctness. E03 is SPECIFIES only: the target-defining G09/G16/G20 tail does not construct A01. E06-E08 are REPORTED_PROVENANCE, so unread citations or source descriptions cannot be mistaken for supplied producer theorems. E09 is reported-comparison context.

A01 has one E04_DISCOVERED_REQUIREMENTS edge with explicit common contract/model nodes, the discovered construction ingredients and every named missing witness. It is REQUIRES_OPEN_WITNESS with OPEN_NOT_PROVED status, not one of two apparently sufficient competing derivations. Source-gap tails are explicitly obligations rather than public theorem binders. E10-E12 remain the explained value-level deductions; they are not compiler-backed circuit claims.

The overlay imports only the43 exact original node definitions and does not reactivate the original untyped dependency/OR arrays. Import failure is specified to fail interpretation rather than load a substitute graph. Thus a reader has one operative typed graph, while the old packet and historical crosswalk remain recoverable.

## 4. T3: the lookup and cleanup dependencies now reach the real uncertainty

The source's physical36 pruned lookup depends on actual selected coefficient words and equal-valued subtree structure, not merely on counts455/59/510. E14 requires S02 and the new S06_QROM before K_LOOKUP can be supplied. S06 explicitly includes the actual coefficient table, equal-subtree topology and literal selected-word/phase semantics. C66 remains unread provenance;495 is not asserted as a proven semantic consequence.

The source's direct kernel changes a slope register before coefficient consumption/erasure. E15 requires S07_MODIFIED and K_LOOKUP to identify the actual live/modified coefficient functions at each use. E16 requires those functions, K_KERNEL, original S03 and S08_FIXUP, in addition to the actual-function measurement mechanism and exact model/phase criterion. S08 includes every measurement record, the consumed slope, diagonal cancellation and environment decoupling. The temporary-AND example cannot discharge this edge.

E17 separately requires K_ERASE and S09_LIVENESS before K_REUSE. S09 requires erasure/reset before carry allocation, no later use of destroyed live information, no unsafe alias and final-zero workspace. It does not pretend to prove peak139. E18 separately places the lookup count behind an actual semantic supplier and count trace; E05 still needs the same realized A01 plus total S05 to reach its OPEN resource candidate.

The added schedule semantics matter: K_KERNEL is per-use semantics; arrows are evidence dependencies, not a statement that all arithmetic finishes before any coefficient erasure. G02 is final global cleanup, not a requirement that live lookup outputs or intermediate coefficients be zero at every component boundary. This avoids replacing an interleaved source construction with an unsupported total schedule or an impossible zero-output local interface.

## 5. T4: common contract and full-domain alternatives are explicit

Both E04 and E19, and BOTH alternatives of OR_NUMERICAL_FAMILY, explicitly carry the common set:

    G02, G03, G05, G09, G16, G20, S12_ERROR_REFERENCE.

These are final clean/phase semantics, allowed kickmix model, all-record consistency, rounding/modular conventions, additive promised-domain interface, fixed Gaussian reference/domain and the unresolved precise error reference. This is not merely a successful membership test: these meanings are exactly the common source semantics on physical9-10,33,36 and note63 from the independently frozen source reading.

The discovered alternative further retains offline quantized fitting, shifted fold, all-regime selection, direct arithmetic, cleanup/reuse, actual lookup and modified-coefficient/fixup/lifetime suppliers, and S01-S04 plus their semantic refinements. It does not discard the original uniform-error gap by factoring out S12. The baseline gets its own actual square/interval/Horner/add/reverse and all-record/strict-uniform-error witness S10_BASELINE, plus separate cost witness S11_BASELINE_COST. Baseline cost does not inherit discovered S05, and neither numerical alternative implies a shared1583/139 tuple.

R01 is now explicitly navigation through E21, while N_NUMERICAL is the separately OPEN same-interface family root. The OR alternatives are baseline versus discovered full-domain architectures. The455 quadratic,59 constant and510 zero regimes remain an exhaustive internal case split in G22 and all-regime kernel/lookup requirements, not independent full-domain OR routes. This matches SI III's architecture comparison and III.3's actual case structure.

Repeating route candidates together with their prerequisite tails is graph redundancy for visibility, not a changed mathematical assumption. It does not convert open witnesses into satisfied premises.

## 6. T5: lookup semantics no longer hide in data or cost gaps

S06_QROM is a genuinely separate missing semantic witness. S02 continues to mean actual coefficient/integer arithmetic data and range obligations; S05 continues to mean actual gate/allocation resource traces. K_LOOKUP requires S06, while A_LOOKUP_COST needs both K_LOOKUP and resource evidence. This is the precise separation requested, not simply renaming S05 to a lookup proof.

## 7. Exact crosswalk and unchanged mathematics

The successor crosswalk preserves every original ordered node ID and every old tail/head list for all12 dependency objects and both OR objects. Each named successor target exists. DEP01-03 are context/specification; DEP04 expands to the full discovered requirements and local semantic suppliers; DEP05 remains matched resources with a separate lookup count; DEP06-07 split provenance from actual table/erasure/reuse requirements; DEP08 splits baseline provenance, realization and costs; DEP09 stays reported comparison; DEP10-12 retain the fold/range, fold-only calculus and coordinate deductions. Original OR01 becomes navigation plus full common-tail numerical alternatives; original OR02 stays non-inferential ordinary/phase-gradient use context; the missing local OR is explicitly added. The review JSON records this independently, rather than relying on the author's crosswalk-pass claim.

No new coefficient, integer quadratic, physical wire order, exact producer, error maximum or gate trace has appeared. The inherited39-bit signed scale2^-32 promise[-8,8), arbitrary modular k, ties-away rounding, circular distance and exact all-record phase/cleanup remain unchanged. Negative y=|x|-2^-32 is not normalized to |x|. Ten interval bits and25 full coordinate bits remain geometry, not a multiplier-width certificate. HHL/Coulomb widths, shifts, signs and erase counts are not imported into Gaussian.

The numerical tolerance is still a value relation, not an epsilon for Eqs17-21 trajectory statistics or an operator-norm bound between different integer-addition oracles. The successor keeps the small-epsilon/nonnegative-overlap fidelity caution and one-unit oracle-distance caution as qualifications, not new Gaussian theorems. Source reports9.99e-8,495,1583/139,printed39gain remain reports. SP, diagonal BE, LCU and phase-gradient consumer requirements remain unprovided; no consumer success probability, inverse implementation, normalization or cost follows.

## 8. Residual boundary and stop

No further T1-T5 source-topology repair is required within this bounded review. The actual table, gates, arithmetic, fold restoration, all-record phase correction, legal lifetime trace, strict uniform numerical certificate and same-instance resources remain open exactly because the corrected graph now exposes them accurately. The exact rounded-reference versus analytic-reference expression remains unresolved. External cited results were not read or admitted.

This result may be cited only as independent acceptance of the pinned additive source-topology repair and its explicit open-obligation structure. It is not a complete source-route realization, proof seal, compiler result, arbitrary-precision/family improvement, circuit/resource/SP/BE certificate, PURIFIED state or final publication admission. No implementation release follows. Stop after this independent successor-review freeze.
