# Exact assumptions, definitions, findings and remaining risk

## Natural-source contract, not a Lean binder audit

The final mathematical root uses only k,n natural (zero allowed), L real with
L>0, and a Boolean word w with |w|=n+1. The target, grid, cut, coefficients,
schedule, kernels and initial/terminal vectors are the displayed literal
definitions, not supplied objects assumed to satisfy the conclusion.

| Input or convention | Classification | Use and limit |
| --- | --- | --- |
| k,n natural, including zero | SOURCE / TYPING | Dimensions, degree and word width; no k<=n or n>=1. |
| L real, L>0 | SOURCE | Positive h, strict cut/order and actual branch domains. |
| w Boolean, |w|=n+1 | SOURCE / TYPING | Exact sample index and exceptional right top level. |
| Real scalar arithmetic, finite sums, natural casts and numeric indicators | TYPING / source notation | Exact, not floating-point semantics. |
| Exact pi and exp | SOURCE literal formulas | No rounded-pi cut computation licensed. |
| Natural ceiling with floor zero on nonpositive arguments | SOURCE standing convention | All naturals, not only positive ceiling arguments. |
| Natural subtraction truncated at zero | SOURCE standing convention | Applies outside finite ranges too. |
| Real division x/0=0 | SOURCE standing convention | Defines total values; does not imply affine restriction at u=1. |
| Row updates, MSB word, LSB wire labels, suffix level n-t | SOURCE conventions | Numerical indexing, not a certified physical operation. |
| (12) nonzero locus | SOURCE premise of generic traversal only | Derived from the actual middle interval; not a root binder. |
| (14) schedule validity AND root partiality | SOURCE premises of generic boundary adapters only | Derived for actual nonempty branches; empty branches disabled. |
| (18) arbitrary scalar injection/free target identity | SOURCE premise of generic scalar target adapter only | Proved explicitly for the left branch; not assumed at the root. |
| h>=0 and block fullness for tail bounds | SOURCE local guard | Not additional hypotheses of the exact sample root. |
| Target normalized, circuit implemented, efficiency certified | EXCESS if inserted or advertised | The source does not assert these. |

RULED corrections: none requested or introduced. No EXCESS premise was needed
in the independent natural proof. Since no formal signature or contract
bundle was read, no claim is made about its actual binder classifications.

## Definition audit

All objects are literal: a,A,E,P,f; N,M,h,p,C; words/J and phi/Phi; B,ell,beta;
D,L,R,mathcalR and injected rows; unit sequences, S_b,e_0,Q; predicates
F/O/T and traversal H; supplied schedules, validity predicate, quotient
schedule, boundary kernels and terminals; generic scalar I/gamma/U and their
adapter; concrete left/right factors; tagged bond, block sum, lambda,v,V,A;
the dense address carrier and entry map. No characterized, quotient or
representative object occurs. There is no existence/uniqueness/choice gap
to hide with a zero default. All actual zero cases are explicit formulas.

The source's coefficients are total natural sequences, not finite rows
silently zero-extended. In particular beta beyond degree d uses truncated
d-r; it need not vanish. Only entries <=d are relevant to finite operations.
Definitions outside the theorem's guarded locus remain literal, not promised
to retain their geometric interpretation.

## Findings

1. No mathematical counterexample or missing hypothesis for (22) or (23) was
   found after rederiving the complete source route. This is a bounded
   source-only result, not source/formal equivalence or a positive module
   admission verdict.
2. The u!=1 guard of (6) is substantive. The d=1,c=(0,1),u=1,v=0 example
   in derivation.md shows failure without it. Actual full middle blocks have
   u=1+p_s<1, including a valid right endpoint v=1.
3. The matrix-to-H adapter needs no nonzero-locus premise because its full
   returns are literal row readouts. Interpreting those as P samples does
   need nonzero x(s). Keeping these two steps separate avoids an apparent
   overreach in reading the source's brief reference to (10).
4. The schedule proof really uses aligned upper endpoints only at levels
   r<=n, not an arbitrary claim about two-sided intervals. The prefix and
   aligned-upper uniqueness arguments are distinct ingredients for distinct
   consumers. Generic schedules do not acquire correctness from totality.
5. Free right F_r products equal exp(-hJ) at arbitrary word length; G agrees
   with them throughout suffixes of length <=n. Its full-width root has an
   exceptional factor b, so the G product is the masked right target, not
   exp(-hJ) at all widths. The source's scope explains this correctly.
6. The piecewise target includes p=0 in its literal middle case. Assigning
   that index to the right contraction is justified by P(0)=1, not by a
   silent target change. An exact sample at p=-1 belongs to the middle.
7. Count (23) is an address-space cardinality, not a data-production or
   arithmetic-complexity theorem. Three branch outputs are summed; no
   individual branch suffices. The source asserts no algorithmic OR route.
8. The source's recovered, retrospective and UNKNOWN-formalizer provenance
   is compatible with this fresh source-only review but is not upgraded by
   it. Neither algorithmic novelty nor historical independence is established.

## Mathematical boundary and residual risks

The source-only proof is finite real algebra plus integer interval arguments.
Its graph still needs a distinct raw-source topology/root-closure review.
The present coverage and graph are proposed evidence, not self-approval.

No formal statement, hidden wrapper, finite-index cast, branch ordering,
natural subtraction implementation, total-division convention, or matrix
orientation has been compared against actual Lean. Those are specific
unresolved fidelity risks, not demonstrated defects. Own-formal inspection
and decoder comparison have not been authorized in this phase.

Additional results would be needed for a normalized quantum-state claim:
the true norm of the complete sample and a correct normalized construction.
Unitary/isometry realization, gate/ancilla semantics, coherent access,
postselection, amplification, QR, finite-bit evaluation, errors, preprocessing,
depth/connectivity/readout and any k,L accuracy-selection theorem are all
outside INPUT. Their absence is an explicit nonclaim, not a source gap in
the advertised scalar identity. Do not add them as assumptions to disguise
their lack of proof. Tail factor bounds alone give no overall stability or
compiled resource certificate.

Failure class: NONE for this completed source-only derivation. No route was
retired as REFUTED or SOURCE_INVALID. The singular-endpoint example refutes
only an unclaimed extension of (6), not the guarded source theorem.
