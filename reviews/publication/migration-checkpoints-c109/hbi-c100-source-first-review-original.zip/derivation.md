# Independent derivation from INPUT only

All source line references mean INPUT. Real arithmetic below is exact. Write
[A] for the real indicator of proposition A. Natural subtraction is truncated;
when an ordinary integer difference is used, its nonnegativity is proved.
There is no computation or finite simulation in this derivation.

## 1. Literal target, cut and endpoint identities (S1)

The quantities a_{k,i}, A_k, E_k, P_k and f_k are literal finite formulas,
not objects defined by uniqueness. At i=0 the sole summand is
binom(k,k)/0!=1, so A_k(0)=1. Because k+1>0, E_k(0)=1 and E_k(1)=0.
Therefore P_k(-1)=exp(-1) and P_k(0)=1=exp(0). Moving only p=0 from the
closed-middle case to the right case changes no value. No derivative-matching
or approximation claim is needed or inferred from the name Hermite.

Set N=n+1, M=2^n. Then 2^N=2M, h=pi L/M>0, and hM=pi L. Consequently
p_j=h(j-M) and p_M=0. Put y=(-1+pi L)/h=M-1/h. For j natural,
j<ceil_N(y) iff j<y, including y<=0 (both sides then false). Thus
p_j<-1 iff j<C. Similarly p_j<0 iff j<M. Negating the first equivalence
and combining with the second gives -1<=p_j<0 iff C<=j<M. If C>M,
the first equivalence applied to M would imply 0=p_M<-1. Hence 0<=C<=M.
Substituting 1/h=2^N/(2pi L) proves (2); its upper clamp is redundant.
These arguments do not assume pi L>1, n>=1 or k<=n.

For clarity, C=0 iff pi L<=1. Also C=M iff M-1<y, equivalently h>1.
The equality h=1 gives C=M-1, not C=M. These additional derived cut
characterizations are diagnostics of endpoint strictness, not extra premises.

## 2. MSB words and affine dyadic coordinates (S2)

For length q, induction gives J(w)=sum_{t=0}^{q-1} b_t 2^{q-1-t} and
0<=J(w)<2^q. Empty words have J=0<1. For bw with |w|=q,
Phi_{bw}(0)=(b+J(w)/2^q)/2=(b2^q+J(w))/2^{q+1}.
This proves the coordinate identity, with the first bit acting outside.
At width N, the bit of weight 2^{N-1-t} has LSB wire label N-1-t=n-t.
This is a numerical weight identification only; it supplies no gate semantics.

## 3. Bernstein coefficients and the restriction algebra (S3)

Temporarily let d be any natural degree. On 0<=i<=d set
B_i^d(t)=binom(d,i)t^i(1-t)^{d-i}. Powers at degree zero use x^0=1,
including x=0. The basis sums are finite, so rearrangement is algebraic.

For the source specialization d=2k+1, i<=k and v<=k-i imply i+v<=k<=d.
Every binom(d,i+v) is a positive integer, hence a nonzero real denominator.
Cancelling it against B_{i+v}^d leaves

    sum_v binom(k-i,v)t^{i+v}(1-t)^{2k+1-i-v}
      = t^i(1-t)^{k+1}
        sum_v binom(k-i,v)t^v(1-t)^{k-i-v}
      = t^i(1-t)^{k+1}.

This is a polynomial identity for every real t, not just [0,1]. Multiplying
by a_{k,i}, summing i and grouping by r=i+v proves
sum_{r=0}^d ell_r B_r^d(t)=E_k(t). Reflection uses the bijection r->d-r
on this finite range and binom(d,r)=binom(d,d-r), so
sum ell_{d-r}B_r^d(t)=E_k(1-t). Hence

    sum beta_r B_r^d(t)=exp(-1)E_k(t)+E_k(1-t)=P_k(t-1).

The extension ell_r to all naturals is zero for r>k. The literal extension
beta_r for r>d is generally not zero: truncated d-r is zero, so
beta_r=ell_0=1 there. This causes no defect, because finite evaluation and
all de Casteljau operations used at degree d inspect only indices <=d.
One must not replace this total sequence by zero extension without declaring
a different object, even though the finite row would be unchanged.

For every sequence c, natural q,i and real z, induction and Pascal's identity
give the explicit iterated difference formula

    (D_z^q c)(i)=sum_{j=0}^q binom(q,j)(1-z)^{q-j}z^j c_{i+j}.

At i=0 this gives L_z(c)_q. To evaluate L_z at degree d, exchange finite
sums and use binom(d,i)binom(i,j)=binom(d,j)binom(d-j,i-j). The coefficient
of c_j in sum_i L_z(c)_i B_i^d(t) is

    binom(d,j)(zt)^j
      sum_{v=0}^{d-j} binom(d-j,v)((1-z)t)^v(1-t)^{d-j-v}
      = binom(d,j)(zt)^j(1-zt)^{d-j}=B_j^d(zt).

Thus left restriction is pullback by zt, for all real z,t. Let
rev(c)_j=c_{d-j}. On finite indices R_u(c)=rev(L_{1-u}(rev(c))). Applying
the just-proved formula and finite reflection gives

    sum_i R_u(c)_i B_i^d(t)
      = sum_i c_i B_i^d(u+(1-u)t).

Apply left restriction with z=(v-u)/(1-u). If u!=1,
u+(1-u)zt=u+(v-u)t, proving (6) without order/interval assumptions.
At u=1 the definition is still total (real division by zero is zero), but
the affine semantic statement is not generally true. For example d=1,
c=(0,1), u=1,v=0 gives constant 1 on the defined left side, versus 1-t
on the advertised affine right side. This is outside the stated u!=1
theorem and confirms that its guard is necessary for general d,c,v.

For x(j)=a+gj and the row c^{s,q}, put u=1+x(s), v=1+x(s+2^q).
When x(s)!=0, u!=1. Since v-u=g2^q and Phi_w(0)=J(w)/2^q,

    u+(v-u)Phi_w(0)-1=x(s)+gJ(w)=x(s+J(w)).

The degree-d evaluation of the injected row is therefore the required P_k
sample. For q=0, the excluded endpoint is s+1 while evaluation is at zero,
so it correctly reads the sample at s. Replacing s+2^q by s+2^q-1 would
give the wrong scale for general nonempty suffixes.

## 4. Finite row-core adapter and backwards contraction (S4)

With row input i and output j, the formula for L_{1/2} gives
(c S_0)_j=sum_{i<=j} c_i binom(j,i)/2^j. The explicit R formula gives
(c S_1)_j=sum_{i>=j} c_i binom(d-j,i-j)/2^{d-j}. Thus (8) has the
correct row orientation: S_0 upper triangular, S_1 lower triangular.
Unit input is the literal sequence [j=i], including zeros beyond the finite
index; there is no hidden natural-index fallback.

One can also verify (9) directly. For b=0, using
binom(d,j)binom(j,i)=binom(d,i)binom(d-i,j-i), its left side equals

    binom(d,i)(t/2)^i(1-t+t/2)^{d-i}=B_i^d(t/2).

For b=1, binom(d,j)binom(d-j,i-j)=binom(d,i)binom(i,j) gives

    binom(d,i)((1-t)/2)^{d-i}(t+(1-t)/2)^i
      = B_i^d((1+t)/2).

Both identities hold for all real t and all d, including d=0, where both
cores are the 1x1 identity. At t=0, B_i^d(0)=[i=0]. Induct on w using
(9): Q_empty=e_0 and
Q_{bw}(i)=sum_j S_b(i,j)B_j^d(Phi_w(0))=B_i^d(Phi_{bw}(0)). Combining
with Section 3 yields both equalities (10) with x(s)!=0. The number of terms
at each coefficient contraction is exactly d+1.

## 5. Literal traversal and generic matrix boundary (S5)

F,O,T are literal propositions for arbitrary natural endpoints and sizes.
Traversal inspects F before O and decreases the word length. No interval
interpretation at zero size is needed, since actual size m=2^{|w|}>0.
For m>0, F and O cannot both hold: either O alternative contradicts
l<=s<s+m<=u. This statement is valid even if endpoints are reversed.

Set j=s+J(w), so s<=j<s+2^{|w|}. If F, both s and j lie in [l,u),
therefore (12) supplies x(s)!=0 and the full readout is P_k(x(j)). If O,
one has j<l or u<=j, so the zero return is the required mask. If T and
w=bv, then the child start s'=s+b2^{|v|} satisfies
s'+J(v)=s+J(bv). The induction hypothesis at that child proves (13).
At the empty word size is one. If l<=s<u, integrality gives s+1<=u, hence
F. If not, either s<l (so s+1<=l) or u<=s, hence O. Thus T is impossible
and the explicit empty partial return zero is harmless. Reversed or empty
target intervals also give the correct zero mask.

For a supplied schedule and (15), a coefficient input never returns to the
boundary; its readout is exactly Q_w. Suppose the root is T at start s_q
and (14) holds. For w=bv choose child j_{q-1,b}. Its F case injects the
literal row c^{j,q-1} into Q_v. Its O case has F=T=false and contributes
zero. Its T case leaves only the boundary scalar; (14) equates its start
to s_{q-1}, so the shorter induction applies. Width zero with a partial
root is impossible. This proves the matrix-to-H adapter without (12).

Care is needed here: without (12), the F case agrees with H because both
use the same literal row readout, not because it already equals P_k.
Equation (10)'s polynomial interpretation is used only when nonzero x(s)
has been supplied. This expands the source proof sketch without adding any
premise to the generic matrix-to-H statement.

## 6. Quotient schedule: actual one-boundary proof (S5)

Let m=2^r>0. A child of s_{r+1} in (16) is

    j=m(2 floor(C/(2m))+b),

so it is aligned at size m. For a target upper endpoint U=mB and child
j=mx, T implies j<U and C<j+m (negating O). Alignment gives x<B,
so j+m<=U. Since F fails, its other conjunct must fail: j<C. Therefore
j<C<j+m. Dividing by m yields x<C/m<x+1, hence x=floor(C/m) and j=s_r.
No C<=U assumption was needed; for C>=U partiality is simply impossible.

For the prefix target [0,C), T instead implies j<C and j+m>C. The same
strict bracket yields j=s_r. This proof does not need an aligned upper
endpoint and works at every r. These are two sufficient alignment lemmas
used for two consumers, not two alternative algorithms for the final target.

For the middle consumer U=M=2^n and r<n+1 imply r<=n, so U=m 2^{n-r}.
The first alignment proof supplies all of (14). For the left prefix consumer
the second proof supplies (14) at any width. At root q=N, C<=M<2M gives
floor(C/2^N)=0, hence s_N=0. The block [0,2M) cannot be full in [C,M).
If C<M, it is not outside either, so is partial. If C=M, the middle target
is empty and initialization disables it. Similarly [0,2M) is partial in
[0,C) exactly when 0<C<=M; when C=0 the left branch is disabled.

If F(C,M,s,m) and m>0, then C<=s<s+m<=M. By (1), p_s>=-1 and p_s<0;
by strict affine monotonicity p_s<p_{s+m}; and p_{s+m}<=p_M=0. This proves
(17). It also proves (12) on the entire middle target interval, and u=1+p_s<1
for every used injected row. The other endpoint v can equal 1 when s+m=M;
only u!=1 is required, so this is not a singularity.

Thus the actual middle readout is [C<=J(w)<M]P_k(p_{J(w)}), including
the zero initialization case C=M, with no generic premises left as binders.

## 7. Scalar boundary and left tail (S6)

In the two-state boundary/free specialization, the free-state suffix readout
is U(w). The same proof as Section 5 gives the scalar traversal under (14)
and root partiality. If (18) holds, every full return is z(s+J(w)); the
traversal induction then gives the exact masked target. This generic lemma
really does assume (18); it is not a result for arbitrary I,gamma,z.

For the actual left branch gamma(r,b)=exp(-h(1-b)2^r). At suffix length q,
its exponent is -h times the number represented by the complemented q bits:

    sum_{t=0}^{q-1} (1-b_t)2^{q-1-t}=2^q-1-J(w)>=0.

This identity follows by subtracting J from the geometric sum; all natural
differences are legitimate by J<2^q. Hence
U_left(w)=exp(-h(2^q-1-J(w))), including q=0 where it equals 1.
Multiplying by I_left(s,q)=exp(p_s+h(2^q-1)) gives
exp(p_s+hJ(w))=exp(p_{s+J(w)}), proving (18) for every s,w. The alternative
injection exp(p_{s+2^q-1}) follows from 2^q>=1, with no underflow.

Section 6 supplies root partiality and schedule validity when C>0; when C=0
the initial zero boundary coefficient makes the branch identically zero.
The actual left output is therefore [J(w)<C]exp(p_{J(w)}).
For h>=0 each free factor is 1 or exp(nonpositive), so lies in (0,1].
For a full left block of size 2^r, its last index is <C, so (1) gives
p_{s+2^r-1}<-1. Its injection is positive and <exp(-1)<1. This last bound
uses the actual cut/grid and fullness, not merely arbitrary I or h>=0.

## 8. Right tail, including n=0 (S6)

The unrestricted F_r product along w is exp(-hJ(w)): this follows from
J(bw)=b2^{|w|}+J(w). For a suffix of length <=n, every processed level
r is <n; G=F_r throughout that suffix. At total length n+1, the first
G factor is the numeric bit b. A zero first bit kills the output. A one
first bit leaves exp(-hJ(v)), with |v|=n and J(bv)=M+J(v). Since
p_{M+J(v)}=hJ(v), this equals exp(-p_{J(bv)}).

Numerically the first bit equals [M<=J(bv)], so the output is
[M<=J(w)]exp(-p_{J(w)}). Algebraically this remains true for arbitrary real
L; only identification with the p>=0 support needs h>0. At n=0 the suffix
is empty and the two one-bit outputs are 0 and 1, exactly as required.
If h>=0 all F_r factors, and the exceptional factor b, lie in [0,1].
No normalizing or success factor occurs.

## 9. Direct-sum root and exact address count (S7)

For a block-diagonal kernel, induction on w shows each input block's
backward contraction equals its isolated-block contraction. At the induction
step every summand with output in a different block is literally zero.
The specified initial row then adds exactly the left, middle and right
outputs established above, with zero-initialized empty branches treated
separately. It follows at |w|=N that

    A(w) = [j<C]exp(p_j)
         + [C<=j<M]P_k(p_j)
         + [M<=j]exp(-p_j),  j=J(w).

C<=M ensures these three masks partition the naturals. By (1), the first
is p_j<-1; the second is -1<=p_j<0; the third is p_j>=0. At p_j=0 the
literal f_k definition uses P_k(0), equal to exp(0)=1 by Section 1.
At p_j=-1, j=C and the middle formula gives exp(-1). Thus (22) holds for
the source's exact f_k, not a variant. All unsupported branch outputs are
zero from masks, not cancelled against large values from other branches.

The middle carrier has 1+(d+1)=2k+3 states, left has 2, right has 1;
the tagged union has D=2k+6 distinct states. Stage t has n+1 possibilities,
the bit has 2, and the ordered input/output pair has D^2. By product
cardinality the dense address space has 2(n+1)(2k+6)^2 elements. Stage t
reads the core at remaining suffix level r=n-t; for 0<=t<=n this is the
ordinary nonnegative difference. The total natural-subtraction formula
outside that range is just a total extension, not another time ordering.
No sparsity, runtime, precision, memory-word, or allocation claim follows.

## 10. Totality and edge cases (S8)

- k=0: d=1, A=1, E=1-t, beta=(exp(-1),1) on the finite row and
  P_k(p)=exp(-1)(-p)+(1+p). Every derivation above still applies.
- n=0: N=1, M=1. If pi L<=1, C=0; the sole negative sample is middle,
  unless pi L=1 where it is the middle's left endpoint. If pi L>1,
  C=1=M; it is left-tail instead. The second sample is always p_M=0.
  Thus one-digit words and empty suffixes require no n>=1 hypothesis.
- C=0: the left branch is disabled; middle [0,M) is valid even if the whole
  grid lies to the right of -1. C=M: the middle branch is disabled, never
  misclassified as a partial empty interval.
- Arbitrary d=0 is allowed for the generic Bernstein/core identities; the
  source specialization always has d>=1. Arbitrary k relative to n is fine.
- Reversed endpoints and size zero have literal F/O/T values. Theorems about
  traversed blocks use size 2^q>0; none relies on a size-zero trichotomy.
- Empty contraction returns its terminal; boundary terminal is zero.
  Incorrect full word widths, L<=0 or a supplied invalid schedule remain
  total expressions with no public sample identity claimed.
- Total natural-index formulas outside finite rows, and division at u=1,
  must be retained literally without inventing affine semantics there.

No existential characterization, choice, quotient or arbitrary representative
is used. Every kernel is a finite literal formula. (12), (14), root partiality
and (18) are local conditional interfaces discharged by the actual formulas;
they are not additional public hypotheses for (22). This source-only
derivation does not establish anything about an unseen implementation.
