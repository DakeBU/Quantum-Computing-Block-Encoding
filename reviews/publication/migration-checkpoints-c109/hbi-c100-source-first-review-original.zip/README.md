# Independent source-first review: C100

Status: SOURCE_ONLY_FROZEN. This is a source-only mathematical review, not a
Statement Seal for a Lean signature, Proof Seal, graph approval, module
admission, publication admission, or Exposition Seal.

## Logical paths and exact intake

- W: the assigned review workspace, represented only by this logical alias.
- G: the assigned governance repository, represented only by this logical alias.
- INPUT: W/hermite-boundary-c56-author/natural-source.md.
- OUTPUT: W/hbi-c100-source-first-review/.
- INPUT SHA256: 69f7b917b21e70ca98285530571b11668ea69333f8fdcc0cfca43b19cf898018.
- Reviewer identity: /root/hbi_independent_source_first_c100.

The sole mathematical source is INPUT, read in full before derivation. Its
404 physical lines supply the anchors used in the coverage and source graph.
No statement seal, other author artifact, author graph/audit/map/metadata,
PRIVATE material, formal source, Lean packet, decoder/reviewer artifact,
compiler/olean/result, project metadata, Git, network, or other worker's output
was inspected. No compilation, simulation, production edit, commit, push or
subagent was performed. Read-only hashing and output-structure checks are not
mathematical simulations.

## Provenance and independence boundary

INPUT explicitly calls itself a retrospective recovered local mathematical
lesson, version 2, with historical formalizer UNKNOWN. It was recovered from
an existing implementation and disclaims historical pre-proof status and
algorithmic novelty. This review preserves all of those qualifications.

The present reasoning is independent of implementation and author packet
materials, not evidence that the source historically preceded its proof.
The source-only graph is this reviewer's proposed extraction. A distinct
reviewer must approve it; the extractor does not self-approve.

## Scope and result

The reviewed target is exactly the literal scalar sample identity at length
n+1 for k,n natural (zero allowed), L>0, and the explicit unnormalized
piecewise target f_k. A separate source claim counts dense real-scalar core
addresses. The complete independent derivation is in derivation.md; every
substantive source region is disposed in source-coverage.tsv; source topology
is in source-graph.json. No missing mathematical hypothesis for the stated
root was found in this derivation. This is not a formal equivalence verdict.

No normalization, quantum implementation, efficiency, finite-bit stability,
resource theorem, or novelty is inferred. See assumptions-and-findings.md.

## Governance actually read

All seven files below were read completely. A combined display initially
truncated; HARNESS and both publication/digestion protocols were then reread
individually in full before task derivation. The evidence-memory protocol and
both skill files were fully visible in the combined display.

| Logical path | SHA256 |
| --- | --- |
| G/AGENTS.md | cd6c8e7a3065be88c70d3e09a2b8262e8e80c0805b434579223edb34536ec719 |
| G/HARNESS.md | 74f8847cbb627073ab63d2228cd23b6300b5d59dcae019a9da442a6ddcbf4e2e |
| G/docs/theorem-publication-protocol.md | db45ec07c3cd092bef4c37dc460164d5b06767daee24664645e7b2a18dfc5cd0 |
| G/docs/proof-digestion-protocol.md | c26999839c3b45f2b1663547c8be24c57534fea3e8459467866d1e41e553a75a |
| G/docs/evidence-routed-memory-protocol.md | 2039b9ec55f287d9df5fe53e09b14cc92cb3aa6301be6c060c96f30b11a8e34b |
| G/.agents/skills/qbe-source-dependency-audit/SKILL.md | 29225ba312893fbc7e1253bf296ec277a3d5b01109afe271e2f3f611dff0c31c |
| G/.agents/skills/qbe-substantive-worker/SKILL.md | 906c1ab444d8a4492d84ee941bb214d55d550365cbc78471186f37fc23ac6c83 |

The two named skills governed source-gap classification, coverage, graph
separation, and structured handoff. Their broader repository/Lean workflows
were not entered because this assignment freezes before formal release.

## Chronology and sealing

1. Received a fresh source-only assignment and its exact permitted intake.
2. Read governance, including full rereads after the combined truncation.
3. Hashed INPUT and read it in full; the supplied hash matched.
4. Reread INPUT with physical line numbers; an accompanying clock observation
   was 2026-10-17 18:37:09 UTC. This is an observation, not a fabricated start time.
5. Derived the mathematics without any additional mathematical input; wrote
   derivation, coverage, graph, assumptions/findings and handoff.
6. Bound payload files by manifest.sha256 and bound that manifest by
   SOURCE_ONLY_SEAL.json. The seal does not hash itself; its final hash is
   supplied outside the packet in the delivery message.
7. Stopped SOURCE_ONLY_FROZEN. Subsequent own-formal inspection and decoder
   comparison require separate explicit authorization and successor evidence.

The exact public-safe file set is publicsafe-allowlist.txt. Only those files
may be released as this packet. The source is referenced by hash and logical
path, not repackaged. The manifest hashes the seven payload files (including
the allowlist), not itself or the seal. The seal hashes the manifest, giving
an acyclic binding chain. Hashes establish bytes, not truth or independence.
