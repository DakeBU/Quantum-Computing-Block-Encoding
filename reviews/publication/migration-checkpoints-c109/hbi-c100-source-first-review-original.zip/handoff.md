# Source-only frozen handoff

Objective / frontier node: Independently reconstruct every substantive
mathematical claim of INPUT and its source proof/construction topology before
any formal or decoder release.

Mathematical delta: Full derivation of (1)-(23), all intervening definitions
and construction steps; explicit binomial restriction proof, finite row-core
adapter, integer traversal base case, quotient schedule proof, both tail
products, direct-sum root and exact dense cardinality. Necessary local guards
are retained and discharged at the actual root. No new root premise needed.

Effect on root frontier: Source-only review prepared and frozen. It does not
move the formal, compilation, semantic round-trip, graph-approval or publication
admission frontier.

Named evidence: INPUT SHA256 recorded in README; derivation.md,
source-coverage.tsv (52 exhaustive regions), source-graph.json (proposed source
AND topology, no algorithmic OR route), assumptions-and-findings.md. There
are no Lean roots, tests, simulations, external citations or compilation
results in this packet.

Assumptions and conventions: Exact SOURCE/TYPING/standing-convention audit in
assumptions-and-findings.md; all literal definitions; real scalar arithmetic;
natural cut and truncated subtraction; MSB words, row-update orientation,
excluded endpoints and suffix-level stage order. Quantum/resource semantics
remain outside the claim.

Files changed: Exactly the nine files in publicsafe-allowlist.txt, all newly
created under OUTPUT using apply_patch. No source or production file changed.

Reusable insight: Nonzero-origin restriction semantics must be separated
from literal matrix-to-traversal equality. Alignment proves one boundary
without enumerating all prefixes. Empty branches are disabled rather than
forced into root partiality.

Failure class: NONE. No failure to salvage. The u=1 diagnostic is an exact
symbolic counterexample to an unclaimed extension only. No fragment is
promoted into a compiled reusable library node.

Process-memory IDs consulted: NONE; they are outside the assigned intake.
Direction fingerprint: fresh-natural-source-only/binomial-row-adapter/
integer-alignment/three-mask-direct-sum. Expected information gain: expose
source defects or hidden extra premises independently of implementation.

Parallel admission: No subagents spawned; no other workers' outputs read.
Common-blind-spot review: Not performed; no competing route inspected.
Default verified route/comparator: Not applicable. The source contains one
construction and required left/middle/right summands, not alternative algorithms.

Purification / Exposition Seal: Not claimed. Source topology is not Lean
topology, compressed quantum spine or a certified functor. This packet's
source exposition is not the project's post-merge PURIFIED status.

Source/Lean expansion: Source nodes are all inventoried. No Lean source or
declarations read. Boundary semantics and retrospective provenance preserved.

Typed obstruction: None in the stated scalar mathematics. Independent graph
approval, formal fidelity, decoder comparison, compiler gates and admission
are unperformed, not positive by default. No forced positive verdict.

Residual risk/confidence: No root gap found in the independent mathematical
derivation; finite-index and formal-interface fidelity remain wholly unseen.
Distinct reviewers can still identify errors in this derivation/topology.

Recommended next step: Freeze this packet. A distinct reviewer may audit the
proposed source graph from raw INPUT. Own-formal reading and decoder comparison
must wait for explicit separate authorization and must not retroactively
change these sealed source-only bytes. No admission follows from this handoff.

Context digest: Retrospective recovered lesson, historical formalizer UNKNOWN;
exact unnormalized sample f_k at MSB index J(w), degree 2k+1, width n+1,
L>0; bond 2k+6 and dense addresses 2(n+1)(2k+6)^2. Includes zero k/n and
empty branches. No algorithmic novelty, unitary or compiled-resource claim.

STOP: SOURCE_ONLY_FROZEN.
