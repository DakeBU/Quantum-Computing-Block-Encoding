# Independent source / own-formal / actual-decoder comparison

## Bounded outcome

The actual C97 decoder reconstructs the same mathematics as this reviewer's
previously frozen source-first and own-formal readings. No mathematical
mismatch, added root hypothesis, weakened target, normalized substitute or
lost EOF declaration was found. This is a textual semantic comparison, not
an accepted-publication wrapper, compiler certificate or final admission.

The exact source remains SOURCE with SHA256 recorded in README. The own
interpretation was frozen under seal 2329c8d87cf95c396cee9f207abbeb3e163788317e86834fdcd11f42be657445
before reading the actual decoder sealed under
af0922d26e6f9fe1b403e32143320ea369a17fd42abd446cebb98840ff07e455.
No prior interpretation was edited in response to the actual reconstruction.

## 1. Contract, scalar meaning and notation

The source uses N=n+1 for word width and M=2^n. C97 uses N=2^(n+1)
for grid size and m=2^n. This is a local notation change, not a mathematical
disagreement: decoder N=2^(source N), decoder m=source M. Both give
h=2pi L/2^(n+1), p_j=-pi L+hj and the exact natural-ceiling cut.

Source finite coefficients a_{k,i}, A_k, E_k and P_k are recovered explicitly
in C97's Setting and target function, with Q_k denoting source A_k. Both
own and actual decoder expand the power-series/truncation representation
to the exact finite sums. Neither selects an unspecified polynomial by
choice or assumes its desired endpoint properties as root hypotheses.

The piecewise f_k is identical: exp(p) below -1, P_k on [-1,0], exp(-p)
above zero. The strict-middle proof moves only zero using P_k(0)=1; -1
remains polynomial. C97 explicitly retains this endpoint distinction. Its
root is unnormalized sampledAmplitude, not normalizedAmplitude or one
branch's norm. Imported preparation/certificate names supply no new claim.

All final parameters match: natural k,n with zero allowed, real L>0, Boolean
word of length n+1. There is no pi L>1, k<=n or n>=1 restriction. Incorrect
word width and L<=0 do not acquire the final sample theorem from totality.

## 2. Words, row orientation and literal definitions

Source J and C97 wordValue both read the head most significantly. Their
coordinate nesting is head-outside-suffix, giving J/2^length. The physical
primitive-wire LSB convention is not itself expanded in C97's prose/provider
selection. Own phase 2 independently read PrimitiveBasisLE and established
its numerical bit0+2*tail convention. Thus the source's position t to wire
n-t relation is compatible; this comparison does not credit C97 with a
physical-wire theorem or turn the flat-index root into a gate swap.

Both descriptions preserve input-row/output-column orientation. The actual
decoder writes the same upper-triangular S0 and lower-triangular S1 under
names A0,A1. Its finite matrix adapter is proved from half-subdivision of a
unit coefficient, not assumed as a property of an arbitrary supplied kernel.
Backward contraction ends at e0 and agrees with Bernstein coordinate
evaluation, including arbitrary d and d=0.

The total natural-index source sequences and total real restriction formulas
are literal definitions. C97 providers.json contains the exact beta formula
with truncated d-r; its prose does not individually calculate beta_r for
r>d, but it does not replace it by a zero extension. Own phase 1 calculated
the off-finite behavior. Every finite operation uses only entries <=d.

The u!=1 restriction guard is retained by source, own reading and actual
decoder. Definitions remain total there without asserting affine semantics.
The injection uses the excluded endpoint first+2^q, never the last included
sample. Actual full middle origins have p_first<0, so u=1+p_first<1; the
right endpoint may be one harmlessly. No guard is silently removed.

## 3. Leading hypotheses versus produced facts, all 125 declarations

The actual decoder records 47 defs, six abbreviations, 69 theorems (one
private), and three anonymous instances. Those are exactly the 125 own
declarations. Each actual header and complete body region agrees with the
permitted snapshot; their prefix/regions/suffix recompose its exact bytes.
This binds the actual evidence; it does not prove tactic execution.

Independently scanning each header before its top-level result colon gives
391 leading binder groups and 490 named binders, matching the actual decoder.
Nested quantifiers inside hvalid/hinject stay inside those binder types.
Result arrows and if conditions are not promoted into leading assumptions.
Six unannotated abbreviations correctly have no written result colon; their
literal bodies determine the carriers. No elaborated universe/auxiliary or
generated private/instance names are fabricated by either packet.

Important matched cases include:

- Three Decidable instances are returned decision data, not assumed Full,
  Outside or Partial facts. Own anonymous labels use source lines while C97
  labels by instance ordinal; this is a display convention only.
- #29 hvalid is a real generic nonzero-locus premise. Mask membership in its
  conclusion is not assumed.
- #37 and #52 require BOTH ScheduleValid and root Partial. Their conclusions
  are literal-traversal equalities, not already sample equalities.
- #40/#44 produce ScheduleValid; its internal r/bit quantifiers are not new
  leading inputs. #64 produces StrictMono, not caller monotonicity data.
- #51 genuinely assumes the universal inject/free/target identity. #56
  proves its actual left-branch instance; target functions themselves are data.
- #58/#71/#83/#86 return factor/endpoint bounds. Those returned inequalities
  are distinct from their actual sign/fullness premises.
- hbits is syntactically a logical proof binder in C97 and has exact-width
  and finite-index typing roles in the source-relative audit. These labels
  answer different questions and agree on its literal type and scope.
- #91 is all-real-L algebra at exact width; #92 adds L>0 to identify the
  public sampled target branch. The final #118 also has L>0 and exact width,
  not the generic adapters' conditions as extra binders.

declaration-comparison.json gives every individual correspondence and own
mathematical interpretation, not just these high-risk examples. No generic
result/assumption boundary was found misclassified in the actual reconstruction.

## 4. Interval proof, schedule and scalar tails

Source, own and actual decoder use literal F/O/T predicates for all natural
endpoints, including reversed or empty cases, while actual blocks have
positive power-of-two size. All retain the F-first traversal and size-one
non-partial base argument. No general size-zero trichotomy is asserted.

The one-boundary schedule is the quotient-aligned cut block, not a list of
all prefixes. C97 correctly separates the aligned-upper lower-cut argument
from the prefix upper-cut argument. Width n+1 supplies r<=n to obtain upper
alignment. Validity is implication-only and can be vacuous on an aligned
cut; it does not assume a partial block exists at every level.

The middle root is partial only for C<M. C=M disables its initialization.
The left root is partial only for C>0; C=0 disables it. Neither empty interval
is forced to satisfy Partial. The actual scalar injection identity cancels
the complemented-bit exponent and provides exp(p_J). The right branch's
exceptional level-n factor selects the first bit; free suffix length<=n
does not see that level. C97 preserves both scopes.

Factor boundedness remains local to nonnegative step/full actual blocks.
It is not promoted to conditioning, numerical stability, a normalization
bound or a quantum success probability. Left/right branch algebra and mask
semantics agree with the source derivation.

## 5. Direct sum, count, EOF and degenerate cases

The three branches form a required tagged direct sum. Sum-kernel lemmas
establish zero cross-block contributions and sum of readouts. Masks j<C,
C<=j<M and M<=j partition indices under C<=M, so #93 and #118 recover
the complete sample. These are not OR routes or separate preparations.

Actual bond cardinality is 2k+6. The dense carrier is stage Fin(n+1), bit,
input bond and output bond, with entry level n-t. Count 2(n+1)(2k+6)^2
is distinct from the contraction equality and from allocation/evaluation,
gate, word-size or finite-bit costs. C97 explicitly preserves that boundary.

The actual #123 InjectionBond cardinality, #124 MiddleBond definition and
#125 MiddleBond cardinality are all included. The unused alternate-written
MiddleBond is not substituted for the actual kernel carrier, and its equal
cardinality does not prove readout. Namespace closure at line 1180 is retained.
There is no orphan EOF suffix hidden by final-root-only review.

C97 does not separately tabulate k=0,n=0 examples in prose. Its exact
universal natural interfaces impose no exclusions, its empty-word terminals
are explicit, and its empty-branch guards match the source. Own source proof
already handles these cases, including the one-digit n=0 right branch and
k=0 linear middle polynomial. This is compressed exposition, not an added
positive-width or positive-degree assumption.

## 6. Provider/read scope and independence qualifications

Actual decoder providers.json carries eleven exact selected regions: full
HermiteBernstein plus bounded coefficient/interpolant/endpoint/strict-piecewise,
grid/sample and gridSize regions. Every selected region matches its snapshot
bytes. Its read-coverage honestly distinguishes full target/full bounded
providers from selected ranges and mere hash verification. Own phase 2 read
more of HermitePolynomial, HermiteCutRank, Core and PrimitiveBasisLE; the
comparison does not pretend these larger readings were C97's work.

C97's strict endpoint supplier calls endpointFactor jet results beyond its
printed selected provider records. That is a proof-dependency boundary of
the bounded record, not an omitted semantic definition or a hidden root
premise; own phase 2 read and interpreted their complete local proofs.
Neither packet claims a full elaborated/imported-axiom audit.

The actual decoder's SOURCE/EXCESS verdicts are explicitly absent because
it was source-blind. This review's SOURCE/TYPING and no-extra-root-premise
judgments come from the earlier independent natural proof and own formal
reading, not decoder classifications. Decoder script classifiers are
target-specific text machinery, not trusted Lean parsers; independent header
and manual semantic checks are what support this comparison.

Both decoder scripts were fully read as supplied payloads and were not
executed, sourced, dot-sourced or imported. Independent read-only hash/text
checks establish the recorded byte agreements. No script output is used as
compiler, runtime, CI, raw-production or graph-approval evidence.

Historical formalizer remains UNKNOWN. Source retrospective recovery and
no novelty/pre-proof claims are preserved; C97 cannot establish those facts
from its withheld source. A seal attests content and claimed chronology,
not real-world independence by itself. The staged source/own/decoder release
order observed in this review is recorded without inventing past history.

## 7. Remaining gates and final freeze

No counterexample or substantive mismatch was found; no repair was introduced.
Failure class NONE for this bounded comparison, not an automatic positive
admission verdict. Agreement here cannot discharge:

- Lean elaboration, tactic success, axiom closure or actual proof-term dependencies;
- raw-production association or semantic noninterference of comment masking/LF transport;
- independent approval of the proposed source graph or global source root closure;
- integration/publication/purification/exposition gates;
- normalization, unitary/isometry/circuit semantics, precision, runtime or resources.

All earlier frozen bytes remain unchanged. STOP DECODER_COMPARISON_FROZEN.
Any raw-source, execution or source-graph disclosure requires separate explicit
authorization and new evidence; final admission is not issued by this packet.
