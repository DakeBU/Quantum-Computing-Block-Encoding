# Actual-decoder comparison handoff

Objective: Compare immutable SOURCE and own source/formal derivations against
the ACTUAL released C97 decoder throughout the complete 125-declaration module.

Mathematical delta: Actual three-way textual comparison, not a summary-based
endorsement. No contradiction or extra source-facing root premise found.
All leading/result distinctions, literal definitions, provider scopes and EOF
declarations checked. Source-relative judgments remain independent of decoder
metadata. Notation and compressed-prose differences explicitly recorded.

Exact evidence: declaration-comparison.json (125 rows, source-node crosswalk,
own mathematics, actual decoder ordinals and exact source-region hashes);
source-coverage-comparison.tsv (52 source regions, all 404 lines);
integrity-checks.json (actual twelve decoder file pins and eleven provider
regions, thirty-three formal pins, unchanged previous twenty files);
comparison.md and README chronology.

Assumptions: Root only L>0 and correct word length as logical proofs; k,n
natural data with zero allowed. Generic nonzero-locus, ScheduleValid AND
Partial and universal scalar compatibility remain scoped and supplied locally.
No quotient/choice characterization, hidden normalized target or resource
assumption found. Three branch outputs are required summands, not OR routes.

Files changed: Only the nine newly allowlisted files under OUTPUT via apply_patch.
No prior source/own/decoder/formal input byte changed; no production edit.

Failure class: NONE for textual comparison. No source route retired or repair
made. No compiled salvage fragment promoted. No process-memory, prior review,
old decoder or author auxiliary consulted. No children, Git, network, simulation,
compiler/olean/CI/runtime evidence, commit or push. Decoder scripts read only.

Direction fingerprint: immutable-source-and-own-formal / actual-C97-release /
125-interface-body-binder comparison. Information gain: check actual independent
reconstruction, not expected names or a previous comparison verdict.

Residual qualifications: C97's N denotes grid size, not source word width.
Its prose does not itself derive the LSB physical-wire convention or separately
tabulate n=0,k=0, though exact interfaces/own provider reading preserve these.
Bounded provider records and imports are not full proof-term/axiom audits.
Historical formalizer UNKNOWN and retrospective recovery provenance unchanged.

No source-graph approval, raw-source association, runtime/Lean/publication
admission, Proof Seal, Exposition Seal or PURIFIED status granted. The frozen
source graph remains proposed and distinct from textual supplier records.

Next: STOP DECODER_COMPARISON_FROZEN. New explicit authorization is needed for
raw/execution/source-graph disclosure or any final admission work. Preserve
all three phases' byte bindings unchanged.
