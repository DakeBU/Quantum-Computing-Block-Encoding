# C100 actual-decoder comparison freeze

Status: DECODER_COMPARISON_FROZEN. This is the independent three-way comparison
of the pinned natural source, this reviewer's already-frozen own interpretation,
and the actual released C97 decoder. It is not raw-source association, runtime
or compiler evidence, source-graph approval, or final admission.

## Logical paths

- W: assigned workspace root, logical alias only.
- SOURCE: W/hermite-boundary-c56-author/natural-source.md.
- SOURCE_REVIEW: W/hbi-c100-source-first-review/ (nine immutable phase-1 files).
- OWN: W/hbi-c100-own-formal-first/ (eleven immutable phase-2 files).
- FORMAL: W/hbi-c67-formal-input/ (the previously allowed 33 formal snapshots).
- DECODER: W/hbi-c97-whole-formal-decoder/ (only the explicitly released twelve files).
- OUTPUT: W/hbi-c100-decoder-comparison/.
- Reviewer: /root/hbi_independent_source_first_c100.

## Exact principal pins

| Object | SHA256 |
| --- | --- |
| SOURCE | 69f7b917b21e70ca98285530571b11668ea69333f8fdcc0cfca43b19cf898018 |
| SOURCE_REVIEW/SOURCE_ONLY_SEAL.json | 7cbe100506b3e59f235edaba56fe15e4367aad23a3ee997732ba3ad3bf5282cd |
| SOURCE_REVIEW/manifest.sha256 | 9681a39c57c31adbbd0bf3ec295325e7665d4716d2bacab20b322eb5a7a22def |
| OWN/OWN_FORMAL_FIRST_SEAL.json | 2329c8d87cf95c396cee9f207abbeb3e163788317e86834fdcd11f42be657445 |
| OWN/manifest.sha256 | ea6fb51eb139c02b3226b514fa49366a500fd6694a49599650f1c4f4e9d815b6 |
| FORMAL/formal-inputs.json | faf40d53126c173a94965a5499589104d6648766918d75abdf2561cbc9393de8 |
| FORMAL/QuantumBlockEncoding/HermiteBoundaryInjection.lean | cf4fcd8e410b4c103e8e45a569e878404de64e1f2d3775dad0a99004990627f1 |
| DECODER/seal.json | af0922d26e6f9fe1b403e32143320ea369a17fd42abd446cebb98840ff07e455 |
| DECODER/manifest.sha256 | 7566b132df2982bd28fd48bafa39ad05837afebfb7ca01bb94ce89c72da4e308 |

All decoder payloads, eleven provider slices, 33 formal pins, natural-source
pin and twenty prior frozen files were independently checked without executing
the decoder's scripts. integrity-checks.json records all twelve actual decoder
file digests. The production_raw hashes remain labels of different unread
objects. No association to those objects was made.

## Result and coverage

No mathematical contradiction, source drift or extra final-root hypothesis was
found in this textual comparison. The actual decoder's reconstruction agrees
with the frozen own interpretation of the exact unnormalized sample contraction
and the separate dense address cardinality. comparison.md gives the substantive
comparison and limitations, including notation and provider-reading differences.

declaration-comparison.json covers all 125 target declarations with actual
decoder ordinal/region digest, own source-node/role/mathematics, leading proof
inputs and independent leading/result-boundary checks. The actual decoder's
125 exact header/body regions recompose the already-read target byte-for-byte.
An independent bounded header scan checked 391 leading binder groups and 490
named binders; result conditions were not treated as caller assumptions.

source-coverage-comparison.tsv retains all 52 source regions covering physical
lines 1-404. It records compressed/provenance/provider-only coverage honestly;
the decoder is not credited with source-relative knowledge it did not have.
Source-graph topology remains proposed and separately unapproved.

## Read chronology and limitations

1. Received explicit phase-3 authorization only after OWN was frozen. The
   existing source/own interpretations were not amended to match the decoder.
2. Verified the actual decoder seal and manifest before reading its mathematical
   reconstruction and binder audit. Read README, reconstruction, binder/context,
   pins, coverage, allowlist and both scripts. Scripts were read, not run.
3. The combined display of providers.json truncated. Reread every provider
   record's metadata and source, including the full Bernstein record, in bounded
   displays. Inspected all 125 actual declaration leading/result records.
4. Matched every actual decoder body region to the previously independently read
   target, and checked exact whole-target recomposition. A first overly verbose
   JSON transfer did not parse; a compact read-only transfer was used instead.
   No mathematical input or frozen output changed.
5. Independently checked leading/result boundaries and names/types rather than
   executing or trusting the decoder's parser scripts. Checked every provider
   slice against the formal snapshot. Rechecked all pins and prior freezes.
6. A clock observation after these read-only integrity checks was
   2026-10-17 18:59:44 UTC; no invented task-start timestamp is asserted.
7. Authored only this new OUTPUT packet via apply_patch, then froze its acyclic
   payload -> manifest -> seal binding.

The decoder's historical source-blindness is its attestation and the staged
release boundary observed here, not something a content hash can prove about
the world. The current reviewer remained source-first and own-formal-first
before this actual decoder release. Historical formalizer remains UNKNOWN;
the natural source remains a retrospective recovered local lesson, not a
pre-proof historical source or new algorithm claim.

No old decoder/review, author auxiliary audit/map/seal, raw repository metadata,
compiler/olean/CI/runtime/result, Git, network, simulation or subagent was used.
No parent-reported repository synchronization event was used as mathematical
evidence or independently inspected. No production edit, commit or push occurred.

The exact nine-file release set is publicsafe-allowlist.txt. manifest.sha256
hashes seven payloads, excluding itself and COMPARISON_SEAL.json. The seal
hashes that manifest; its own final byte hash is delivered externally. These
are byte bindings, not semantic proof or admission. STOP DECODER_COMPARISON_FROZEN;
raw/execution/source-graph disclosure and final admission require new authority.
