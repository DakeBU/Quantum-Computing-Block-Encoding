"""Read-only byte/offset/recomposition check; no Lean/compiler execution."""
import argparse
import hashlib
import json
from pathlib import Path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def verify(obj, root):
    data = (root / obj['logical_input'].removeprefix('INPUT/')).read_bytes()
    assert len(data) == obj['bytes']
    assert digest(data) == obj['sha256']
    cursor = 0
    reconstructed = []
    for ordinal, command in enumerate(obj['commands'], 1):
        assert command['ordinal'] == ordinal
        span = command['span']
        assert span['byte_start'] == cursor
        raw = command.get('raw')
        if raw is None:
            raw = command['header'] + command['delimiter'] + command['body']
            for key, text in [('header_span', command['header']),
                              ('delimiter_span', command['delimiter']),
                              ('body_span', command['body'])]:
                sub = command[key]
                assert data[sub['byte_start']:sub['byte_end']].decode('utf-8') == text
        encoded = raw.encode('utf-8')
        assert encoded == data[span['byte_start']:span['byte_end']]
        assert digest(encoded) == command['sha256']
        for binder in command.get('leading_binders', []):
            sub = binder['span']
            assert data[sub['byte_start']:sub['byte_end']].decode('utf-8') == binder['text']
        cursor = span['byte_end']
        reconstructed.append(encoded)
    assert cursor == len(data)
    joined = b''.join(reconstructed)
    assert joined == data
    assert digest(joined) == obj['recompose_sha256']
    return {'logical_input': obj['logical_input'], 'commands': len(obj['commands']),
            'byte_exact_recomposition': True, 'all_command_hashes_and_offsets_match': True,
            'all_subspan_and_binder_texts_match': True}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input-root', required=True)
    parser.add_argument('--output-root', required=True)
    args = parser.parse_args()
    root, out = Path(args.input_root), Path(args.output_root)
    target = json.loads((out / 'target-inventory.json').read_text(encoding='utf-8'))
    providers = json.loads((out / 'provider-inventories.json').read_text(encoding='utf-8'))['inputs']
    checked = [verify(obj, root) for obj in [target] + providers]
    assert [c['ordinal'] for c in target['commands'] if c['human_read_complete']] == list(range(1, 61))
    assert all(not c['human_read_complete'] for obj in providers for c in obj['commands'])
    print(json.dumps({'kind': 'DETERMINISTIC_TEXT_INTEGRITY_ONLY', 'status': 'PASS',
                      'does_not_establish': ['Lean elaboration', 'proof-term dependencies',
                                             'mathematical coverage', 'compilation',
                                             'source fidelity', 'whole-module completeness'],
                      'inputs': checked}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
