# Named provider roles and evidence boundaries

These are inspected mathematical interfaces and textual call signals, not
compiler-extracted dependencies. Imports supply module context only. A name
appearing in a proof gives a textual call signal; comments, string descriptions,
and imported-but-unused declarations do not become dependency edges.

| Provider | Read declaration/interface | Actual role in reconstructed prefix |
| --- | --- | --- |
| Core | Matrix, Matrix.PointwiseEq/zero/identity/mul | Finite function matrices; entrywise equality; finite ordered multiplication. |
| Core | gridSize, clog2, clog2_gridSize | Powers-of-two carriers and the width arithmetic used by target 267–281. |
| Core | Stencil, Stencil.width, BulkWindow, StencilEntry | Data-only stencil/window records, no consistency assumptions. |
| Core | Coeff and all anonymous operation instances; evalWith and its lemmas | Free expression syntax; arbitrary rational symbol interpretation, no field/inverse laws on syntax. |
| RobinHeat | fourthOrderSecondDerivative, centralBulkEntries, all four boundary rows, A1dx/B1dx, robinWindow | The literal row formulas and truncated natural window used by D. |
| RobinHeat | oneTermParameters | Fixed kappa=7, pieces=1, polynomialDegreeCost=1. |
| Resources | Resource, gates, ofCounts, bandedSparseAccessResource | Declared counts; gate total includes unit-cost oracle calls; subtractions are natural. |
| Circuit | Gate, Circuit, Gate.resource, Circuit.resource | Label syntax and generic count model, not a binding from labels to attached matrices. |
| BlockEncoding | RegisterLayout, BlockEncodingSpec | Layout and target/circuit/cost data; no correctness field. |
| CircuitSemantics 25–29 | SemanticObligation | String description, String source, Boolean proved; not a proof type. |
| CircuitSemantics 35–59 | GateMatrix, gateMatricesMatchCircuit, evalGateMatrices | Attached matrices, label-list match, and left multiplication fold. |
| CircuitSemantics 404–424 | CircuitMatrixSemantics and ofGateMatrices | Genuine Boolean gate-list equality plus pointwise product equality. |
| CircuitSemantics 502–511 | BlockExtractionTarget | Target/projection data and Boolean obligations; no unitary or block-equality proposition. |
| CircuitSemantics 661–693 | CircuitBlockEncodingClaim, FiniteBlockCompositionContract | Dimension equality and three genuine target-link equalities; semantic obligations remain data. |
| CircuitSemantics 696–772 | signalSystemBlockRowIndex/ColIndex, range proofs, signalSystemBlockProjection/apply | Exact signal-major flattening and finite restriction to one signal block. |
| CircuitSemantics 786–812 | CircuitMatrixSemantics.blockExtractionTarget | Casts evaluated matrix, computes projection, installs two false records. |
| GHL2025 18–23,49–82,134–174,239–240 | parameter/partition/layout/resource/circuit/normalizer definitions | Concrete bookkeeping providers; the active list has seven labels. |
| GHL2025 274–276 | oneTermRobinNormalizer_eval | Explicit proof call for target numeric evaluation identity. |
| GHL2025 324–328 | ObligationRecord | Same String/String/Bool separation as SemanticObligation. |
| GHL2025 488–549,577–706 | RobinProofObligations, sparse/derivative/function contracts, theorem data and defaults | Recursively exposes data-only statuses; derivative bandwidth equality is genuine. |
| GHL2025 770–829 | total/effective widths and layout correspondence lemmas | Arithmetic and metadata consistency only. |
| GHL2025 852–854 | robinIndicatorBitPosition | Bit-position arithmetic used to interpret function workspace extraction. |
| GHL2025 3896–3921 | indicatorOracleMatrix, oneTermRobinGate_U_indic | Literal indicator-bit toggle matrix and a true Boolean status record. No proof of the descriptive unitarity claim was read here. |
| GHL2025 4256–4263,4592–4599 | oneTermRobinGate_O_DT_S, oneTermRobinGate_Ry_boundary | Attach named rotation-matrix providers; both unitary flags false. Their lower rotation/coefficient definitions remain to be semantically expanded in continuation. |
| GHL2025 3525–3571,4718–4725,5505–5512 | sparse forward/dagger matrices and gate wrappers | Forward incidence matrix of a named image, and its literal transpose; no unitary inverse theorem follows from transposition alone. Underlying image arithmetic remains a continuation obligation. |
| GHL2025 4853–4974 | robinFunctionValue; register/image/normalized-value definitions | f symbols, explicit bit extraction, and symbolic clean amplitude f*N_f_inv. |
| GHL2025 5022–5164 | external-amplitude record and function amplitude route | Reuses opaque citation strings/status objects; no external theorem is assumed or imported by those strings. |
| GHL2025 5208–5275 | route source-contract/status and externalSourceAndFlags lemmas | Actual proof-call signals for target 969–1066: record identities and false flags. |
| GHL2025 5285–5347,5384–5391 | functionOracleOrthogonalEntry, functionOraclePaperMatrix and clean-entry lemma, O_f wrapper | Defines free symbolic off-branch entries; conditional clean-entry theorem is applied by target 1076–1164. |
| GHL2025 5410–5432,5468–5475 | swap matrix/image and gate wrapper | Exchanges n-bit blocks at bit positions 1..n and n+1..2n. Gate label is swap 0 0; attached matrix specifies actual action here. |
| GHL2025 5706–5766 | seven wrappers list, match, gate-list and flag lemmas | Actual call signals in target gate-product/flag theorems; proves the list of status data, not seven unitary operators. |
| GHL2025 8059–8137 | cleanup scope type, decision, activeGlobalSource theorem | Selects a named restricted scope; explicitly forbids semantic cleanup promotion; full-domain/full-space fields false. |
| GHL2025 2906–2983 | full-clean-domain extension record/default | Reveals daggerCleanup=false used in the scope decision; nested unused-branch rule records have not been recursively decoded. |

No proof-edge claim is made for names merely mentioned in description strings,
such as `indicatorOracleMatrix_is_permutation` or
`swapOracleMatrix_is_permutation`. They might exist in the allowed input, but
the description is not an application or a proof term. The present role audit
does not substitute an alleged proof behind a true Boolean flag.

The full provider inventories preserve private declarations and anonymous
instances by exact source spans. Anonymous instances receive explicitly lexical
identities, not invented elaborated Lean names. `deriving` clauses remain
attached to their parent declarations; generated projection/instance identities
are outside source-only reconstruction.

Remaining provider work includes the lower rotation matrices and their
coefficient/normalizer contracts, sparse image/global-slot predicates and range
inverses, and recursively nested unused-branch contracts when later target
declarations consume them. Their unread content is not imported as a presumed
mathematical fact. No bounded supplement is currently needed: the named local
files are present, and reading them in scope remains possible.
