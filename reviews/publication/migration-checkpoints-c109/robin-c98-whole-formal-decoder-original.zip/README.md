# Source-blind whole-module formal decoder checkpoint

Status: **INCOMPLETE — FROZEN_BEFORE_SOURCE_RELEASE**.

This is a recoverable partial checkpoint, not a whole-module reconstruction,
review, theorem-admission decision, compiler certificate, or source comparison.
The mathematical input is exclusively the eleven entries of
`INPUT/formal-inputs.json`, whose SHA256 is
`1e9753617607d960798a6161dcb5b3f0d338524fae3885d1a22d6200b8b7dbf5`.
The assigned whole target is `INPUT/QuantumBlockEncoding/RobinMatrix.lean`.
Its actual masked formal bytes, not production bytes, have SHA256
`17735bc5f3a1d42fa16d9cf55d33237af432178b19c6946cc2294d7d41e61de8`.

Human reading and reconstruction cover target lines 1–1175, byte interval
`[0,56697)`. The exact next uncompleted target declaration begins at line
**1176**, byte **56697**, namely
`oneTermRobinBlockEncodingProofRoute_derivativeBoundaryContractMap`.
Its first 25 lines (1176–1200) were exposed in a truncated read but have not
been reconstructed as a complete declaration. The wholly unviewed target
range starts at line **1201**, byte **58149**, and continues through line
26985, byte 1293994. Resume reading at
1176 to obtain that declaration in full; do not credit the fragment as closure.
The first 60 ordered commands have been read; this statement is not a
declaration-count argument for theorem strength.

`target-inventory.json` mechanically preserves every ordered command, exact
candidate header/body split, leading-binder text, ambient-command references,
byte/line spans, and content hashes over the entire target. Concatenation
reproduces the pinned formal bytes exactly. This lossless mechanical coverage
is deliberately distinct from human mathematical coverage. Splits after the
human-read prefix remain lexical candidates, not audited Lean elaboration.
`provider-inventories.json` does the same for the seven local provider files;
its per-command human flags are deliberately false because the separate
read ledger is authoritative for noncontiguous provider reading.

The reconstruction, declaration-by-declaration prefix map, recursive bundle
audit, provider roles, pins, coverage, and chronology are in the adjacent files.
No natural source, unmasked production module, author rationale, prior decoder,
old review/result, parent notes, Git/network, Lean compiler/olean, theorem
execution, simulator, or child agent was consulted. Opaque source-reference
strings inside the allowed formal declarations were read as record data only;
they were not followed or used as natural-source evidence.

Source-relative `SOURCE`, `STANDING`, `RULED`, and `EXCESS` classifications are
withheld: no source contract was supplied. No conclusion about the unread
remainder follows from the opening obligation flags. In particular, this
checkpoint does not claim the final module fails, succeeds, or lacks later
stronger theorems.

The noncircular integrity seal binds the explicit publicsafe allowlist and
manifest, not its own bytes. To continue, preserve this checkpoint and append
new read-coverage/chronology entries before extending the human frontier.
