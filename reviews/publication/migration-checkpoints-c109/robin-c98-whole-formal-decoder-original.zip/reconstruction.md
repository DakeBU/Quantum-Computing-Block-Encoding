# Mathematical reconstruction of the read prefix

Scope: target lines 1–1175 only. All names below are qualified by
`QuantumBlockEncoding`, and, after target line 111, by
`QuantumBlockEncoding.Examples.RobinHeat`, unless stated otherwise.

## Carriers, coefficients, and finite matrices

`Matrix r c α` is literally a function `Fin r → Fin c → α`; it is not an
imported analytic operator type. `gridSize n = 2^n`, and all row/column indices
are bounded finite naturals. Matrix multiplication sums over the intermediate
finite index by an ordered list fold. This finite operation requires only
zero, addition, and multiplication instances, not ring laws.

`Coeff` is a free expression syntax with rational constants, named symbols,
binary addition/multiplication, and unary negation. Its decidable equality is
structural. Thus an equality of `Coeff` expressions is generally stronger than
equality after rational evaluation and is not equality modulo ring laws.
`Coeff.evalWith env` evaluates every symbol using an arbitrary
`env : String → Rat`; it imposes no positivity, inverse, or normalization laws.
Anonymous operation instances supply the syntax constructors. `divNat a m`
multiplies by the rational value `1/m`; its carrier includes `m=0`.

## Stencil matrices and boundary selection

For row r, column c and a list E of signed-offset/coefficient pairs,
`stencilRowCoeff r c E` retains precisely the coefficients with `r+offset=c`
as an integer equality. It returns rational zero if none, the coefficient
itself for one match, and the left-associated syntax sum for multiple matches.
There is no wraparound in this definition. Repeated offsets are added, not
discarded. Negative/out-of-range stencil destinations simply fail to match an
in-range matrix column.

`robinRowEntries B L R w i` selects L[i] when i<w.lower and in range, otherwise
the empty list on that branch. If the left condition fails and i>w.upper, it
selects R[i-w.upper-1] when in range, otherwise the empty list. Only the remaining
case returns B. The left test has priority even for overlapping/degenerate
windows; the function assumes no ordering of the two window endpoints.
`buildRobinMatrix` applies the selected stencil at each row of a `2^n` square
matrix.

The provider fixes the bulk coefficients, in offsets -2,-1,0,1,2, to
`(-1/12,4/3,-5/2,4/3,-1/12)`. Write a and b for the independent symbols
`A1*dx` and `B1*dx`. The four boundary rows are:

- left row 0: offsets 0,1,2 with coefficients `-5/2+7a/3, 8/3, -1/6`;
- left row 1: offsets -1,0,1,2 with `4/3-a/6, -31/12, 4/3, -1/12`;
- right first row: offsets -2,-1,0,1 with `-1/12,4/3,-31/12,4/3+b/6`;
- right second row: offsets -2,-1,0 with `-1/6,8/3,-5/2-7b/3`.

`robinDerivativeMatrix n`, denoted D, uses these lists with window
`[2,2^n-3]`, where subtraction is truncated natural subtraction. No lower bound
on n is a binder here. In small dimensions the branch priorities still define
a matrix, without any asserted differential-equation interpretation.
`oneTermRobinAkMatrix n` has entries `f_{n,i} * D[i,j]` as coefficient syntax;
the symbol f depends on the row index, not the column. Thus its intended
numeric form, under evaluation, is left diagonal multiplication `diag(f)D`.
The apply theorem unfolds this definition, with no analytic assumptions.

## The norm and declared resource records

`matrixRowAbsSum M env i` is the rational sum of absolute values across row i.
`matrixOneNorm` is the maximum of these row sums and zero. Hence it is the
maximum absolute row sum (the induced infinity-norm convention), not the
maximum column sum suggested by the name “one norm.” Empty row sets return
zero. This identification follows from the explicit finite folds, not from
the declaration name.

The numeric normalizer is `nD*nF*k` with rational nD,nF and natural k.
`robinNormalizerBound` is a Boolean comparison of that product against the
evaluated derivative row-sum maximum. `oneTermRobinNumericNormalizer_eq_eval`
is a symbolic evaluation identity with an environment mapping `N_D` to nD,
`N_f` to nF, and every other symbol to k; it does not prove a normalizer bound.

The fixed parameter record is `(n, kappa=7, functionPieces=1,
polynomialDegreeCost=1)`. The resource provider writes one-qubit count
`degree*n*clog2(n)+kappa*n`, zero CNOTs, and `2n` pure ancillas into a record.
The derivative-oracle resource is a separate `bandedSparseAccessResource n 2`
record, whose ancilla field is truncated `n-1`. These are declared records;
the read prefix does not connect their counts to a gate-level implementation.
`Resource.gates` sums one-qubit, CNOT, and oracle-call fields, with one counted
oracle call not unfolded into its realization.

`robinBlockEncodingSpec` stores target D, normalizer expression
`N_D*N_f*kappa`, error expression zero, layout, circuit list, and resource.
`BlockEncodingSpec` contains no semantic proof fields. In contrast, the later
block-extraction target stores `diag(f)D`. These are distinct formal targets in
the read prefix; no equality between them is asserted there.

## What the route objects actually certify

`robinBlockEncodingPredicate` is only a conjunction of the Boolean numeric
normalizer test at the all-zero symbol environment, the declared ancilla
count, and the stored error expression. It contains neither unitarity nor an
extracted-block equality. `robinResourceBoundHolds` compares fields of the
declared resource record against its formula. `oneTermRobinResourceConsistent`
merely identifies its ancilla field.

`RobinOracleComposition` packages derivative/function records, an LCU
obligation record, and a genuine matrix equality. The derivative record has a
genuine bandwidth=stencil.width proof; its `sparseCorrect` is only a Boolean
record. The function record similarly holds only function-piece data,
normalizer syntax, and an obligation record. The default constructor makes
all three correctness flags false and supplies matrix coherence by reflexivity.

`oneTermRobinCircuitSemantics` really ties a circuit list to seven attached
matrices and their ordered product. If the listed matrices are G1,...,G7, the
fold gives `G7*(G6*(...*(G1*I))))`, retaining exact expression syntax. The
gate-list match is a recursive Boolean label equality, not a theorem that
each label has standard physical semantics. `GateMatrix.unitary` is a
`SemanticObligation` record, not a proof of a unitary predicate.

The register partition has mf width `clog2(n)+3`, one indicator qubit, sparse
width 3, OD workspace width `n-3`, n system qubits, and one low ancillary bit.
Its total width is `clog2(n)+8+(n-3)+n`; effective signal width is
`clog2(n)+8+(n-3)`. These use truncated subtraction. The private width lemma
and public dimension theorem establish exactly that total dimension factors
as effective-signal dimension times `2^n`; neither is a cleanup theorem.

The target casts the ordered matrix product to this factored dimension and
projects signal row and column zero. The flattening convention is
`signal*systemDimension+systemIndex`, i.e. signal-major/system-fast. At signal
zero these are the original finite system indices. The target stores
`diag(f)D` and the symbolic normalizer. Its `unitaryMatrix` field name does not
impose unitarity, and its block-equality fields are Boolean records.

`CircuitBlockEncodingClaim` adds a dimension compatibility proof and another
obligation record, not a block-encoding proof. The default constructor supplies
the already-proved dimension equality. `FiniteBlockCompositionContract`
contains genuine equality fields linking the claim, target matrix, and
normalizer, together with five open Boolean obligations. The transcript
theorem proves those record equalities and the false flag values. The separate
“ExactTheoremObligation” is a record with false flag, not an exact theorem.

`OneTermRobinBlockEncodingProofRoute` bundles all these objects and exact
coherence equalities, plus proofs that specified flags are false. Its default
constructor and subsequent audit lemmas establish wiring, target identity,
the normalizer expression, zero signal selection, the seven labels, and
layout/resource field correspondence. They also preserve the explicit
nonpromotion of full clean-domain/full-space sparse cleanup. These are real
record/coherence theorems, not proofs of the recorded open obligations.
False flags are not mathematical proofs that an operator is nonunitary or
that block encoding is impossible; true flags are not proof terms either.

## The first genuinely conditional entry theorem

The function provider reads the n system bits starting at bit 1, extracts the
mf workspace above the indicator, and declares the input clean when those mf
bits are zero. It clears those bits to form the clean-branch basis index.
The clean amplitude is `f_{n,systemValue} * N_f_inv`, where `N_f_inv` is an
independent symbol. No inverse law follows from `Coeff` or arbitrary `env`.
Other amplitudes are independent `orth_f_entry_...` symbols; on a clean input,
clean output rows off the designated branch are set to literal zero.

The theorem at target lines 1076–1164 assumes two genuine premises: the input
is on the provider's clean workspace branch, and output i is exactly the
provider's designated basis index. By unfolding the fifth attached gate
matrix and applying `functionOraclePaperMatrix_cleanBranch_entry`, it proves
that this one entry equals the clean branch amplitude and the route's
normalized-amplitude expression. It also copies the basis/clean identities
and the remaining false correctness flags. It does not prove the amplitude is
a quotient, a bound by one, an orthogonal completion, or full O_f unitarity.

The preceding external-source transcript theorem has only natural parameters
n and j: it proves equalities of data and false status flags. Citation strings
inside those records are not assumed external mathematical theorems.

## Boundary of this reconstruction

The next unread declaration begins at target line 1176. No assertion above
extrapolates to later product expansions, conditional bundles, evaluated
identities, stronger roots, or the final theorem strength of the whole module.
The whole-module mathematical reconstruction and complete human binder audit
remain unfinished.
