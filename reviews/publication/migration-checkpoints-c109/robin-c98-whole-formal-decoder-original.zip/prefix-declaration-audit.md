# Ordered human audit: target prefix

This table covers every command/declaration whose full command span ends by
line 1175. The lossless inventory gives exact header/body/binder text and
byte spans; ranges here are declaration syntax ranges, excluding following
masked whitespace. Rows grouping adjacent commands do not merge their
identities. No source-relative premise classification is attempted.

Ambient commands 1–5 are the three exact imports, root namespace, and
`open Coeff`; command 9 opens `Examples.RobinHeat`, command 13 closes it,
and command 16 reopens it. There are no ambient variable/typeclass binders in
this prefix. The only private declaration is command 36; it is included.

| Command | Lines | Name | Mathematical role and actual strength |
| --- | --- | --- | --- |
| 6 | 21–26 | stencilRowCoeff | Literal offset filter and ordered sum; two natural indices and a stencil list; no logical premise. |
| 7 | 37–48 | robinRowEntries | Left-priority piecewise list lookup with empty fallback; no window validity premise. |
| 8 | 56–63 | buildRobinMatrix | Literal finite matrix assembled from row lists. |
| 10 | 68–72 | robinDerivativeMatrix | Fixed provider stencils/window; all natural n allowed. |
| 11 | 81–82 | oneTermRobinAkMatrix | Row multiplication of D by independent f symbol. |
| 12 | 84–88 | oneTermRobinAkMatrix_apply | Definitional entry identity, not an operator approximation theorem. |
| 14 | 96–100 | matrixRowAbsSum | Rational evaluation followed by absolute row summation. |
| 15 | 106–109 | matrixOneNorm | Maximum row sum/zero; actual infinity-norm convention. |
| 17 | 117–118 | robinDerivativeNorm | Applies that convention to D. |
| 18 | 125–126 | oneTermRobinNumericNormalizer | Rational product nD*nF*k, without positivity assumptions. |
| 19 | 133–135 | robinNormalizerBound | Boolean scalar comparison, no semantic certification. |
| 20 | 139–144 | oneTermRobinNumericNormalizer_eq_eval | Evaluation identity using the named-symbol environment; no inequality conclusion. |
| 21 | 149–155 | robinBlockEncodingSpec | Data-only record targeting D with declared zero error. |
| 22 | 158–159 | robinBlockEncodingSpec_pureAncilla | Reflexive record field equality 2n. |
| 23 | 163–164 | robinDerivativeOracleResource | Separate stencil-based cost record. |
| 24 | 167–168 | robinDerivativeOracleResource_eq | Record equality to banded sparse cost at l=2. |
| 25 | 171–172 | robinDerivativeOracleResource_pureAncilla | Truncated n-1 ancilla field identity. |
| 26 | 181–184 | robinBlockEncodingPredicate | Three scalar/metadata conjuncts; recursively expanded below. |
| 27 | 188–191 | robinResourceBoundHolds | Bound on a declared resource record, not circuit-derived cost. |
| 28 | 195–196 | oneTermRobinResourceConsistent | Single declared ancilla-field equality. |
| 29 | 204–210 | RobinOracleComposition | Derivative/function data, Boolean LCU record, and actual matrix equality. |
| 30 | 215–229 | robinOracleComposition | Constructs records; all three semantic flags false; matrix coherence by rfl. |
| 31 | 231–232 | robinOracleComposition_bandwidth | Fixed bandwidth 5 equality. |
| 32 | 234–235 | robinOracleComposition_functionPieces | Fixed piece count 1 equality. |
| 33 | 237–238 | robinOracleComposition_matrix | Exact derivative-matrix identity. |
| 34 | 242 | robinProofObligations | Default record of ten false obligation flags. |
| 35 | 252–259 | oneTermRobinCircuitSemantics | Exact seven-matrix list and ordered evaluation, not per-gate unitarity. |
| 36 | 267–273 | effectiveSignal_add_n_eq_total | Private natural-width arithmetic theorem; only n as input. |
| 37 | 275–281 | oneTermRobinCircuitDimCompat | Powers-of-two dimension factorization from command 36. |
| 38 | 296–312 | oneTermRobinBlockExtractionTarget | Cast product, signal-zero projection, Ak target, symbolic normalizer; existence of signal zero proved internally. |
| 39 | 323–338 | oneTermRobinCircuitBlockClaim | Explicit hDim proof input plus open Boolean blockCorrect; hDim is dimension equality, not block equality. |
| 40 | 344–349 | defaultOneTermRobinCircuitBlockClaim | Supplies hDim using command 37; no semantic obligation supplied. |
| 41 | 359–401 | oneTermRobinFiniteBlockCompositionContract | Three genuine target-link equalities; five false semantic flags. |
| 42 | 404–429 | oneTermRobinFiniteBlockCompositionContract_transcript | Let-bound result; proves record strings/link identities and five false flags. |
| 43 | 441–447 | oneTermRobinFiniteCompositionExactTheoremObligation | Data-only obligation; unused natural parameter. |
| 44 | 449–455 | oneTermRobinFiniteCompositionExactTheoremObligation_transcript | Exact source-string identity and false flag, not exact extraction. |
| 45 | 467–522 | OneTermRobinBlockEncodingProofRoute | Bundle of data, coherence equalities, and explicit false-flag proofs; not a bundled proof of unitarity/extraction. |
| 46 | 531–570 | oneTermRobinBlockEncodingProofRoute | Fixed route record; reflexive coherence and false/open status fields. |
| 47 | 573–577 | ..._normalizer | Projects stored theorem-normalizer equality. |
| 48 | 586–599 | ..._blockTarget | Four target/semantics/matrix/index equalities. |
| 49 | 610–670 | ..._blockProjectionNormalizerAudit | Cast and projection definitions plus target/normalizer/zero-index identities and open flags. |
| 50 | 680–701 | ..._circuitProduct | Matrix-product coherence and gate-list match, not product unitarity. |
| 51 | 712–730 | ..._gateUnitaryFlags | Exact [true,false,false,false,false,true,false] status list plus open/nonpromotion flags. |
| 52 | 740–768 | ..._gateListAndFlags | Adds label-list equality to command 51. |
| 53 | 780–811 | ..._gateProjectionFreeze | Combines gate list, status list, normalizer, zero index, and open flags. |
| 54 | 823–855 | ..._layoutProjectionAudit | Layout/resource metadata equalities and effective signal-width formula; cleanup/resource proof flags remain false. |
| 55 | 862–870 | oneTermRobinBlockExtractionTarget_signalZeroBlockIndices | At signal zero, flattened row/column equal i,j; no matrix-entry equality. |
| 56 | 876–889 | ..._signalZeroBlockIndices | Same index fact via route target. |
| 57 | 899–909 | ..._claimBlockCorrectFalse | Three exact false status fields. |
| 58 | 917–957 | ..._flags_false | Thirteen data-status/scope conjuncts, not thirteen failed mathematical theorems. |
| 59 | 969–1066 | ..._ofExternalSourceAndFlags | Equality of local record data and preservation of open function/LCU/block flags. All proof calls are local formal providers, not the papers named in strings. |
| 60 | 1076–1164 | ..._ofCleanFunctionOracleEntry | Genuine clean-input and selected-output premises. Fifth gate entry equals symbolic clean/normalized amplitude, with all listed semantic flags still false. |

The abbreviated `...` prefix in rows 47 onward is
`oneTermRobinBlockEncodingProofRoute`, not an omitted declaration.

## Genuine leading-binder/result boundary checks

The header parser tracks nested (), {}, [], and ⟨⟩ before seeking the outer
result colon and declaration body. Binder-type colons are not result colons.
The result of command 42 begins `let contract := ...`; that assignment belongs
to its result type, not its proof body. Command 60 similarly begins its result
with `let p := oneTermParameters n`. Both are manually checked: the actual
proof delimiter is the later `:= by`. Local have/let bindings inside proofs
are not theorem premises. Complete exact binder/result text is preserved in
the inventory rather than reconstructed by a name-based heuristic.

All prefix theorem leading binders are data/index parameters except the two
logical premises in command 60. `n,j,rowIdx,colIdx,k` are natural data;
`nD,nF` are rational data; finite indices carry their built-in range proofs.
Command 39 is a definition with the genuine logical input hDim, supplied by
command 37 in the default constructor. No prefix theorem assumes an arbitrary
`RobinOracleComposition`, proof route, or “block correct” bundle.

## Recursive project-owned Prop expansion

- `robinBlockEncodingPredicate n`: let D be the fixed derivative matrix and
  d=max_i sum_j |evalWith (fun _ => 0) D[i,j]|, starting each fold at zero.
  Its complete content is the Boolean test `d*1*7 ≥ d` equals true,
  the declared resource's pureAncilla equals 2n, and the stored Coeff error
  equals literal rational zero. There is no quantified circuit action.
- `robinResourceBoundHolds n`: the declared ancilla equality and
  `Resource.gates(declaredResource) ≤ 1*n*clog2(n)+7*n`.
  `Resource.gates=r.oneQubit+r.cnot+r.oracleCalls`. No comparison with
  `Circuit.resource oneTermRobinCircuit` is included.
- `oneTermRobinResourceConsistent p`: exactly
  `(oneTermRobinResource p).pureAncilla = 2*p.n`.
- `Matrix.PointwiseEq A B`: exactly `∀ i j, A i j = B i j`.

`RobinOracleComposition` has one dependent matrix equality and inherits
`DerivativeOracleContract.bandwidth_eq`; its remaining “correct” fields are
data. `OneTermRobinBlockEncodingProofRoute` has the exact equality/false-status
fields shown in target lines 483–522. Expanding the carried record types adds
no hidden proof of the statements described by `SemanticObligation` or
`ObligationRecord`: each is String × String × Bool. `CircuitMatrixSemantics`
adds actual gate-list Boolean equality and pointwise product equality, not a
unitary predicate. `FiniteBlockCompositionContract` adds exactly the three
target-link equalities at provider lines 686–688. `BlockExtractionTarget` has
no logical fields at all. These expansions prevent record names from being
mistaken for mathematical assumptions or conclusions.

## Definition and choice boundary

All prefix definitions are explicit literal functions, piecewise formulas,
or record constructors. No classical choice, unique characterization, or
quotient representative occurs in the read prefix. Empty-list, zero-entry,
natural-subtraction and branch defaults are actual public-carrier semantics;
no natural source is available to say whether those defaults are faithful.
Coefficient symbols and unconstrained orthogonal-entry symbols are not
characterized amplitudes. The norm and record-field equalities are certain
from the allowed definitions, while their intended application to a physical
block encoding remains a separate interface.

Not audited: all target commands after 60, all source-relative classifications,
and elaborated/synthesized declaration identities. Structures and deriving
clauses remain exact in the lossless inventory, but the decoder does not
invent compiler-generated instance/projection names.
