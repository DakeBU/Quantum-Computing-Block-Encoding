"""Formal-text inventory only: no Lean execution or dependency inference.

All output is returned on stdout; the caller persists it using apply_patch.
Offsets are zero-based, half-open UTF-8 byte offsets in exact INPUT bytes.
Command spans partition the entire input, retaining blank/masked regions.
The parser is intentionally lexical, not an elaborator. Generated declarations
from deriving, structure projections, and elaborated anonymous names are not
invented. Human coverage is separately maintained and never inferred here.
"""
import argparse
import bisect
import hashlib
import json
import pathlib
import re


def sha(data):
    return hashlib.sha256(data).hexdigest()


TOKEN = re.compile(r'"(?:\\.|[^"\\])*"|/\-|\-/|--[^\r\n]*|:=|=>|[(){}\[\]⟨⟩:]|[^\s(){}\[\]⟨⟩:]+', re.S)
COMMAND = re.compile(r'^(?:@\[[^\r\n]*?\]\s*)?(?:(?:private|protected|noncomputable|unsafe|partial)\s+)*(import|namespace|end|open|set_option|def|abbrev|theorem|lemma|structure|inductive|instance|variable|section|attribute|notation|scoped|axiom|opaque|example)\b')


def tokenize(text):
    # Mask comments without changing positions. Snapshot masking is not trusted
    # as a general lexer proof. Strings remain single tokens.
    raw = list(TOKEN.finditer(text))
    depth = 0
    for tok in raw:
        s = tok.group()
        if s == '/-':
            depth += 1
        elif s == '-/' and depth:
            depth -= 1
        elif depth or s.startswith('--'):
            continue
        else:
            yield s, tok.start(), tok.end()


def inventory(root, relative, human_end=0):
    data = (root / relative).read_bytes()
    text = data.decode('utf-8')
    charbytes = [0]
    for c in text:
        charbytes.append(charbytes[-1] + len(c.encode('utf-8')))
    lines = text.splitlines(keepends=True)
    linechars = [0]
    for line in lines:
        linechars.append(linechars[-1] + len(line))
    starts = []
    unrecognized = []
    closing_continuations = []
    for i, line in enumerate(lines):
        if line and not line[0].isspace():
            match = COMMAND.match(line)
            if match:
                starts.append((linechars[i], i + 1, match.group(1)))
            elif line.strip() in (']', '}', ')', '⟩'):
                closing_continuations.append({'line': i + 1, 'text': line.rstrip('\r\n')})
            elif not line.startswith('deriving'):
                unrecognized.append({'line': i + 1, 'text': line.rstrip('\r\n')})
    if not starts or starts[0][0] != 0:
        starts.insert(0, (0, 1, 'preamble'))
    ns = []
    commands = []
    pieces = []
    ambient = []
    namespace_ordinals = []
    pending_option = None

    def span(a, b):
        return {'byte_start': charbytes[a], 'byte_end': charbytes[b],
                'line_start': bisect.bisect_right(linechars, a),
                'line_end': bisect.bisect_right(linechars, max(a, b - 1))}

    for index, (a, line, kind) in enumerate(starts):
        b = starts[index + 1][0] if index + 1 < len(starts) else len(text)
        raw = text[a:b]
        toks = list(tokenize(raw))
        keyword_idx = next((i for i, t in enumerate(toks) if t[0] == kind), None)
        name = None
        if keyword_idx is not None and keyword_idx + 1 < len(toks):
            candidate = toks[keyword_idx + 1][0]
            if kind in ('def', 'abbrev', 'theorem', 'lemma', 'structure', 'inductive', 'opaque', 'axiom'):
                name = candidate
            elif kind == 'instance' and candidate not in ('(', '{', '[', ':'):
                name = candidate
        rec = {'ordinal': index + 1, 'kind': kind, 'name': name,
               'namespace_before': '.'.join(ns), 'span': span(a, b),
               'sha256': sha(data[charbytes[a]:charbytes[b]]),
               'human_read_complete': span(a, b)['line_end'] <= human_end,
               'ambient_command_ordinals': ambient + namespace_ordinals + ([pending_option] if pending_option else [])}
        if keyword_idx is not None:
            rec['modifier_tokens'] = [t[0] for t in toks[:keyword_idx]]
        if name:
            rec['qualified_lexical_name'] = '.'.join(ns + [name])
        elif kind == 'instance':
            rec['lexical_identity'] = '.'.join(ns) + '::<anonymous-instance@line-' + str(line) + '>'
            rec['elaborated_name'] = 'WITHHELD/NOT-AVAILABLE-WITHOUT-ELABORATION'
        declaration = kind in ('def', 'abbrev', 'theorem', 'lemma', 'structure', 'inductive', 'instance', 'opaque', 'axiom', 'example')
        if declaration and keyword_idx is not None:
            cursor = keyword_idx + (2 if name else 1)
            depth = []
            result = None
            body = None
            binders = []
            leading = True
            binder_start = None
            result_let_bindings = 0
            for token, ta, tb in toks[cursor:]:
                if token in ('(', '{', '[', '⟨'):
                    if not depth and leading:
                        binder_start = ta
                    depth.append(token)
                elif token in (')', '}', ']', '⟩'):
                    if depth:
                        depth.pop()
                        if not depth and leading and binder_start is not None:
                            binders.append({'text': raw[binder_start:tb], 'span': span(a + binder_start, a + tb)})
                            binder_start = None
                elif not depth:
                    if token == ':' and result is None and body is None:
                        result = ta
                        leading = False
                    elif token == 'let' and result is not None:
                        # A result such as `: let p := value; P p := by ...`
                        # contains an assignment which is not the proof boundary.
                        result_let_bindings += 1
                    elif token == ':=' and result_let_bindings:
                        result_let_bindings -= 1
                    elif token in (':=', 'where'):
                        body = (ta, tb, token)
                        break
                    elif token == '|' and result is not None and kind in ('def', 'abbrev'):
                        body = (ta, tb, token)
                        break
            rec['leading_binders'] = binders
            rec['boundary_status'] = 'lexical-candidate; human audit only if separately recorded'
            if body:
                ba, bb, delimiter = body
                rec['header'] = raw[:ba]
                rec['delimiter'] = delimiter
                rec['body'] = raw[bb:]
                rec['header_span'] = span(a, a + ba)
                rec['delimiter_span'] = span(a + ba, a + bb)
                rec['body_span'] = span(a + bb, b)
                rec['result_type_text'] = raw[result + 1:ba] if result is not None else None
                reconstructed = rec['header'] + delimiter + rec['body']
                rec['recompose_exact'] = reconstructed == raw
            else:
                rec['raw'] = raw
                rec['boundary_unresolved'] = True
        else:
            rec['raw'] = raw
        pieces.append(raw)
        commands.append(rec)
        if kind in ('import', 'open'):
            ambient.append(index + 1)
        if pending_option:
            pending_option = None
        if kind == 'set_option' and re.search(r'\bin\s*$', raw.strip()):
            pending_option = index + 1
        if kind == 'namespace' and keyword_idx is not None:
            ns.append(toks[keyword_idx + 1][0])
            namespace_ordinals.append(index + 1)
        elif kind == 'end' and ns:
            ns.pop()
            namespace_ordinals.pop()
    recomposed = ''.join(pieces).encode('utf-8')
    return {'logical_input': 'INPUT/' + relative, 'bytes': len(data), 'sha256': sha(data),
            'line_count': len(lines), 'offset_convention': 'zero-based half-open UTF-8 bytes; 1-based inclusive lines',
            'semantic_coverage_warning': 'Mechanical inventory is not human mathematical reading, elaboration, compilation, or dependency evidence.',
            'recompose_exact': recomposed == data, 'recompose_sha256': sha(recomposed),
            'unrecognized_column_zero_lines': unrecognized,
            'closing_delimiter_continuations': closing_continuations, 'commands': commands}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--input-root', required=True)
    p.add_argument('--path', default='QuantumBlockEncoding/RobinMatrix.lean')
    p.add_argument('--first', type=int, default=0)
    p.add_argument('--count', type=int, default=25)
    p.add_argument('--human-end', type=int, default=0)
    p.add_argument('--summary', action='store_true')
    args = p.parse_args()
    result = inventory(pathlib.Path(args.input_root), args.path, args.human_end)
    selected = result.pop('commands')
    if args.summary:
        result['command_sizes'] = [len(json.dumps(c, ensure_ascii=False)) for c in selected]
        result['command_headers'] = [{k: c[k] for k in ('ordinal', 'kind', 'name', 'span')} for c in selected[args.first:args.first + args.count]]
        print(json.dumps(result, ensure_ascii=False))
        return
    result['total_commands'] = len(selected)
    result['first_zero_based_command'] = args.first
    result['commands'] = selected[args.first:args.first + args.count]
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
