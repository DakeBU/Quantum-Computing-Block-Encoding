# C96 additive source-only comparison of C92

Terminal scope: SOURCE_ONLY_TOPOLOGY_COMPARISON_COMPLETE. The preceding C96 source-first packet and C92 packet remain immutable. This comparison is later, explicitly authorized evidence, not a rewrite of either pre-exposure interpretation. Logical roots are W/uncompute-c96-gaussian-source-first-review/ (C96-first), W/uncompute-c92-gaussian-source-first/ (C92), and this new W/uncompute-c96-gaussian-source-comparison/ (comparison). P denotes the pinned primary PDF; G denotes already authorized governance.

## Split verdict

- Identity and isolation: PASS. The exact eleven C92 names were the only C92 files accessed. Both source-first manifest/seal pairs and all their bound payload entries were independently rehashed, not accepted on their own status assertions. No actor script was executed.
- Mathematical/source interface: AGREEMENT WITH EXPLICIT OPEN PRECISION SLOT. C92's finite carrier, signed promise, modular additive target, rounded reference, negative offset fold, coordinate derivation, exact phase/cleanup and consumer non-entailments agree with the source and C96's prior independent reconstruction. No contrary formula or source-invalid finding was established.
- Source topology: NEEDS A BOUNDED ADDITIVE REPAIR. C92's prose preserves important qualifications, but its actual graph loses the local inverse-versus-MBU OR route and mixes specification/context dependencies with construction hyperedges. Some lookup/cleanup and OR-family tails omit required witness/interface nodes. Do not read its structural DAG pass as complete mathematical root closure.
- Coverage: SUBSTANTIVE GAUSSIAN REGIONS ACCOUNTED FOR, WITH GRAPH-LEVEL DISPOSITION LOSS. C92 inventories the full Gaussian section, common numerical section, standing conventions, tables, figure and relevant citations. The inverse-cleanup route is explicitly covered in prose but not faithfully represented by the graph. Two supplementary cautions are identified below; neither reverses C92's numerical conclusions.
- Circuit/Lean/family/resource/SP/BE/publication admission: NOT IN SCOPE AND NOT GRANTED. Neither packet certifies a realization or supplies the unresolved error-reference checker expression.

The graph verdict is not a finding that the authors' Gaussian circuit is wrong, and it is not a reason to retire the construction. Failure class of this comparison run is NONE. The outstanding graph discrepancy is review evidence needing a separately authored correction; the original packets stay unchanged.

## 1. Exact source contract comparison

P is Gu et al., arXiv:2610.22367v1, SHA256 3607f457c3349db74e10b131abadef23a4a2dea0fefa0cf6ac6d0ed9f37fdfd9. Physical page36 / SI19 contains III.3 and Eq67; common numerical semantics are on physical33 and convention note63 on physical13. Those anchors, rather than either packet's verdict, control this review.

Both reconstructions use M=2^39 and S=2^32 (C92 calls them B,H). A word u has signed value u below 2^38 and u-M otherwise. The whole scaled carrier is [-64,64); the promised signed integers are [-2^35,2^35), giving 2^36 promised words and real x in [-8,8). C92's full-carrier reference formula is mathematically meaningful but, as its binder audit explicitly says, does not extend the off-promise implementation guarantee. No zero fallback or nonnegative-only domain was substituted.

Eq67 defines F(u)=round(S exp(-(signed(u)/S)^2)). Nearest ties away from zero is the standing convention; for the positive argument, floor(z+1/2) is equivalent. C92 correctly has 0<=F<=S. Its realized A is not silently identified with F or uniquely selected merely by the tolerance relation.

The logical target is |u>|k> -> |u>|k+A(u) mod M>, with arbitrary k and preserved u. The generic XOR example on physical1 is not the numerical interface. C92 correctly separates the ideal translation's algebraic inverse (subtract A) from a physical inverse of a circuit with destructive measurements. It does not assume a free gate-level inverse.

Both packets give the natural rounded-reference relation d_M(A,F)/S<10^-7, with d_M the minimum/infimum over integer wraparounds. For integer a,b the minimum and infimum coincide. The corresponding discrepancy threshold is 429.4967296 integer units, not 10^-7 integer units. C96 additionally spells out the integer upper bound 429; C92's strict inequality has the same consequence. Circular translation invariance makes output-versus-k+F and increment-versus-F checks equivalent. No-wraparound is not an authorized hypothesis.

Both packets leave exactly the same narrow source question open: whether the reported final maximum was evaluated against rounded F/S or analytic exp(-x^2). Their reference values differ by at most 2^-33, so the strict margin cannot be identified without an exact additional witness. No comparison verdict chooses one expression, spends an extra half-ulp, or changes the advertised tolerance.

## 2. Construction arithmetic and source fidelity

C92's conceptual fold m=signed(u) for nonnegative inputs and m=-signed(u)-1 for negative inputs is correct. Complete-word complement of a negative word is M-1-u=-signed(u)-1. Thus y=m/S is |x|-2^-32 on negatives, not exact |x|. Its endpoints, two-to-one collision at m=0 and necessary retention/restoration of sign/original-input information match C96. The source does not supply a gate transcript; neither packet claims to recover one from this value identity.

The derivative bound sup_{t>=0} 2t exp(-t^2)=sqrt(2/e), and hence fold-only error at most sqrt(2/e)/S, is correct. C92's weaker less-than-one-ulp conclusion is compatible with C96's sharper displayed coefficient. Neither turns that bound into a proof of the full piecewise truncated computation.

The local decomposition m=J*2^25+r, J=floor(m/2^25), 0<=r<2^25, is correct. Ten selector bits and twenty-five full local bits follow from scale and interval width; the implemented truncated multiplier width does not. Both packets refuse to import HHL's fifteen-bit coordinate, sixteen-bit slope, 345 leaves, cyclic shifts or signs from Eqs63-64 into Gaussian arithmetic.

Reading the ordered regime description gives J=0..454 quadratic, 455..513 constant, 514..1023 zero. Counts sum to 1024. This is an exhaustive case split inside one coherent evaluator, not three OR alternatives for the entire domain. The value-level Gaussian tail expression at 514/128 is consistent; it does not certify any constant table or truncated quadratic.

C92 accurately describes the source's no-square/no-full-product/no-finished-value-register architecture, in-place slope update, destination accumulation, quantized end-to-end coefficient fitting, QROM subtree pruning and coefficient/carry reuse. It correctly calls the arithmetic/reuse order a partial order rather than imposing a total erasure schedule. Missing table values, widths, signs, shifts, rounding sites, omitted columns, selection semantics, updated-slope phase correction and allocation timing remain missing witnesses. No actual coefficients or code were consulted in this comparison.

## 3. Source formulas, figures and statistical claims

The following is the formula-level disposition, not an approval based on node counts:

| Source formula/region | Comparison disposition |
| --- | --- |
| Introductory XOR embedding, physical1 | Correctly separated from additive III interface by C92 G01 and its mathematics. |
| Eq1 and routing conjugation, physical3 | Context/excluded literal Gaussian wiring. No routing gate transcript inferred. |
| Eq2 history example, physical3 | Correctly excluded as not Gaussian history recovery. |
| Eq10, physical9 | C92 G02 preserves initialized-zero workspace and exact phase/interface/cleanup despite approximate value. |
| Eq11, physical9 | Source's reverse-Toffoli cleanup is inventoried by C92 coverage but absent as an actual graph alternative; repair required. |
| Eq12, physical9 | Measured temporary-AND cleanup is represented by G04, but must remain local, not a general lookup theorem. |
| Eqs13-14, physical9-10 | General measured-function phase (-1)^(r f(y)) and diagonal cancellation correctly retained. |
| Eqs15-16, physical10 | Same permutation and exact target sign on every possible record; no measured-outcome basis changes; agreement. |
| Eqs17-18, physical10 | Joint deferred-measurement states and D-weighted defective-trajectory probability are statistical context, not a supremum error bound. |
| Eq19 and its following paragraph, physical10 | The 2 sqrt(epsilon) state-norm bound is context only in C92 G07; no Gaussian epsilon/confidence was inferred. The source's following squared fidelity expression needs the small-epsilon/nonnegative-overlap qualification if exported as a general theorem. |
| Eqs20-21, physical10 | Fixed-before-draw candidate, independent draws, D and uniform records are conditions. C92 does not infer a confidence level or all-domain proof from 9000 tests. |
| Eq22, physical11 | Toffoli/CCZ count times simultaneous logical-qubit peak; no depth, connectivity, physical compiler or preprocessing theorem. |
| Note63, physical13 | All three clauses retained: ties away, circular metric, unrestricted off-promise numerical behavior. |
| TableI Gaussian row, physical7 | Approximate baseline and reported1583/139,39 comparison; unrelated footnotes not transferred. |
| Extended Data Figure2, physical16 | Resource lineage and observed endpoint, not gate correctness or global optimality. |
| Extended Data Table1 Gaussian row/caption, physical17 | 39 read-only inputs,39 target bits, arbitrary target initialization, strict absolute tolerance,9000 tests; not a Gaussian failure budget. |
| SI contents, physical18 | Correctly treated as location/navigation, not mathematical proof. |
| SI III paragraphs1-6 plus continuation, physical33-34 | Common additive contract, HRS alternative, redesigned dataflow and quantized fitting all covered. |
| Eqs61-64 and FigureS3, physical34-35 | HHL context, not literal Gaussian polynomial or gate figure; correct exclusion. |
| Eqs65-66, physical35-36 | Coulomb context only; its17-Toffoli erase cost not assigned to Gaussian. |
| Eq67 and every III.3 paragraph, physical36 | Covered; exact reference, domain, baseline, fold, regime counts, pruning, direct kernel, MBU/reuse and reported results remain distinct. |
| Eq68 and SI IV opening, physical36 | Other benchmark, not Gaussian LCU/BE supplier. |
| Eqs81-82, physical40-41 | Read in prior C96 source work, not by C92. They illustrate a51-bit phase-gradient consumer for another task; C92 leaves U01 open and makes no incompatible exact39-bit phase assertion. No mandatory Gaussian construction is missing merely because this ancillary illustration is outside C92's reading. |

The fidelity caveat is supplementary, not an error C92 asserted: C92 never states a global all-epsilon squared-fidelity theorem. If a later exposition copies (1-2epsilon)^2 from the source, squaring a negative lower bound for epsilon>1/2 is invalid; use the nonnegative/small-epsilon form. No new statistical acceptance was performed here.

Likewise, a numerically small difference in the integer increment need not be a small state/operator difference between the exact and approximate addition oracles: a basis accumulator shifted by one different unit is orthogonal. C96's prior packet spells this out; C92 does not explicitly say it, but its warnings about consumer error conversion do not contradict it. Adding that sentence would improve the consumer boundary, not repair a false C92 formula.

## 4. Actual graph discrepancies, not merely prose agreement

C92's graph has43nodes,12dependency objects and2OR objects. These counts are bookkeeping. The important differences are:

T1 - Lost local OR. Coverage03 says Eq11 and Eq12 are both NODE G04, but G04's content names measured cleanup only, and neither OR object contains reverse-Toffoli versus measured-CZ cleanup. C96 retained a local TEMP_AND_CLEAN OR with separate source mechanisms. Minimal repair: add distinct reverse and measured nodes and a local cleanup head. Neither branch should imply arbitrary coefficient-lookup cleanup by itself, and using the reverse route does not inherit discovered MBU resources.

T2 - Edge-role ambiguity at the realization root. The dependency G09+G16+G20 -> A01 explicitly says it is insufficient to prove realization; another dependency supplies discovered steps/gaps to the same A01. Context G06+G07+G08 -> G12 also ends at a reported table node, not a correctness theorem. The opening edge_semantics only says each object is an AND-tail, leaving mixed necessary/specification/context/inference meanings. C92's accompanying text prevents a faithful reader from promoting these into proofs, but the graph itself cannot serve as an unambiguous root-closure certificate. Minimal repair: type those edges as SPECIFIES or VALIDATION_CONTEXT (not sufficient derivations), then create a single explicit construction-requirements hyperedge at the discovered candidate root.

T3 - Data-dependent QROM and cleanup witness tails. C66+G22 -> G23 contains a cited unread technique and interval counts but no actual table/equal-subtree witness. Counts455/59/510 alone do not determine which coefficient words are identical or the pruned gate action. C64+G04+G05 -> G25 includes a cited unread cleanup technique, a temporary-AND example and exact phase criterion, but not G24's modified coefficient data, S03's actual correction/reuse schedule, or a consumed-coefficient cleanup witness. These are not established lookup/reuse producer theorems. A01 does retain S02/S03/S04, which materially limits the overclaim, but it does not supply missing local edges by itself. Minimal repair: explicitly mark the two existing edges as reported-method provenance, and add open actual-table/QROM-semantics and updated-coefficient/correction/liveness tails to any proposed construction-producing edge.

T4 - Complete AND tails for OR family and candidate interface. R01's baseline alternative lists G17,C12,G09; its discovered alternative lists G19-G25,S01-S04. Those are reported family summaries, not full sufficient interface-tail sets: the discovered alternative does not explicitly include G09/G16/G02/G03, and the baseline alternative does not include G20's concrete39-bit promise/target or its own exact realization/error witnesses. Some phase context is reachable through G25's provenance edge, but clean-zero and the whole gate-model/reference contract are not thereby complete. A01's discovered dependency also omits G03's allowed gate/measurement model from its explicit construction tail and relies on a separate specification edge for G09/G16/G20. Minimal repair: either label R01 purely as non-inferential family navigation, or give each alternative its complete common contract/model/phase/cleanup and route-specific open witness tail. Do not fix this by turning producer results into public theorem hypotheses.

T5 - Missing lookup-semantic gap identity. S01-S05 collectively preserve fold, table/arithmetic, cleanup, error and cost gaps. However S02 names data/arithmetic/range and S05 names counts/liveness, while neither explicitly identifies the literal pruned-QROM selection/phase map and equal-subtree semantics as its own missing witness. C96 separated QROM_WITNESS_GAP from data and cost gaps. Minimal repair: expand a separately versioned S02 successor or add a dedicated gap for actual pruned lookup semantics, then connect it where used. A generic final count gap must not stand in for a semantic lookup certificate.

The actual graph also has a strength worth preserving: A01 -> A02 requires matched correctness, resource semantics and S05 rather than treating1583/139 as proof of correctness. It has explicit forbidden value-to-SP/BE and sample-to-uniform edges. No consumer root is falsely certified. Grouping citation records within source nodes is acceptable here; merely not giving every citation its own standalone node is not a separate defect.

## 5. Minimal additive repair contract

The original C92 graph must not be edited during this comparison. A later successor graph can preserve all original reported claims and make only these changes:

1. Introduce typed edges: SPECIFIES, REPORTED_PROVENANCE, CONTEXT, REQUIRES_OPEN_WITNESS, DEDUCES. Only a separately established sufficient derivation can be read as root closure.
2. Preserve the explicit local inverse-Toffoli OR measured-CZ temporary-AND routes. This OR concludes only local AND cleanup.
3. For the discovered numerical candidate, retain one full AND requirements tail containing G03,G09,G16,G20,G19,G21-G25,G02,G05,S01-S04 and a dedicated actual-QROM-semantics gap. This lists open obligations, not assumed producer correctness or a proved circuit. External C64/C66 remain provenance dependencies and must later supply exact contracts.
4. Make actual lookup and coefficient-erasure/reuse candidates depend on actual table structure, kernel-modified coefficients, all-record phase correction and legal liveness; keep claimed495 and1583/139 resource proofs separate.
5. Preserve HRS/discovered as OR reported alternatives, but distinguish common interface/model tails and route-specific witness gaps, or mark the family node as navigation rather than inference. Baseline tuning is not a discovered-route assumption.
6. Retain the common unresolved error-reference slot and separate missing uniform certificate. Do not choose a rounded/analytic checker reading from agreement between two reviewers.

This is a proposed source-graph correction only. Its own independent review is pending. No numeric constant, circuit repair, signature, Lean theorem, resource result or consumer choice is proposed or accepted.

## 6. Consumer, resource and final boundary

C92's SP and diagonal-BE requirements match C96's independently frozen boundary: grid/index preparation, actual amplitude target versus density square root, normalization, range-valid amplitude conversion, cleanup/inverse/measurement-channel semantics, nonzero accepted branch, postselection/amplification, error and all costs. Circular closeness alone is not a real-range certificate; near zero a wraparound-close residue can be huge unsigned, and near1 tolerance alone need not preserve an upper bound1. Neither packet claims this occurs in the uninspected implementation.

The PREPARE/SELECT/unprepare LCU tail remains complete in C92's prose and is not inferred from the value routine or separate SI IV benchmark. Phase-gradient use is a distinct consumer, not automatically a Gaussian-amplitude block. C96's conditional first-harmonic deduction gives a39-bit PG phase exp(2pi i A/M), hence real-function scale2pi/128; C92's U01 explicitly leaves Fourier sign, scale and state preparation unprovided, so there is no contradiction.

The reported1583*139=220037 calculation, rounded220000 prose, approximately24000/362 baseline and printed39gain agree. No exact baseline ratio, exhaustive tests, optimality, arbitrary-precision family, Clifford+T expansion, physical cost or downstream SP/BE gain is accepted.

End state: source contract mathematics substantially agrees; C92's topology needs the stated bounded repair before independent exhaustive source-topology approval. Both fixed packets are preserved. Implementation release, code comparison and all production/final admission gates remain closed.
