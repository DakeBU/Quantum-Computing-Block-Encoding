# Whole-module formal decoder — frozen before source release

Status: WHOLE TARGET READING AND RECONSTRUCTION COMPLETE; FROZEN_BEFORE_SOURCE_RELEASE.
This is a source-blind mathematical reconstruction, not a compilation certificate,
source comparison, review verdict, or migration-admission decision.

The complete target is INPUT/QuantumBlockEncoding/RobinMatrix.lean:26985 lines,
1293994 bytes, SHA25617735bc5f3a1d42fa16d9cf55d33237af432178b19c6946cc2294d7d41e61de8.
There is no unread target range. All688 commands, including private helpers,
ambient commands, structures, definitions, theorem statements and complete proof
bodies, were read. Inventory completeness alone was never used as reading evidence.

Read reconstruction.md first. progress.md preserves incremental mathematical
observations and superseded checkpoints; its final EOF entry supersedes earlier
INCOMPLETE frontiers. assumption-audit.md distinguishes actual hypotheses and
proof-valued structure fields from metadata. declaration-boundary-audit.json
records every command's genuine leading binders separately from the returned
type. target-inventory.json and provider-inventories.json are lossless exact-text
inventories, with zero-based half-open UTF8 byte offsets and inclusive line spans.
Private names and lexical anonymous-instance identities are retained; generated
elaborator names are not invented. Providers are mechanically inventoried in full
but human-read only as recorded in read-coverage.json.

The decisive formal distinction is that active raw entry[0,0] evaluates0, while
the proposed seven-diagonal branch fold can evaluate1. The module actually
negates their exact equality. Its positive normalized prepared-entry identities
use a different, explicitly defined diagonal-sum matrix and retain assumptions.
None of this is promoted to a theorem about an external paper's intended circuit.

Only eleven inventoried formal inputs and six governance files were used.
Input hashes use formal_snapshot_sha256, never production_raw_sha256. No raw
production object, paper, old independent decoder/review, Git/network, Lean/olean,
simulation, child agent, or production modification was used. The worker skill
kept substantive reconstruction and its boundary audit separate from evidence
and publication/admission authority.

This additive OUTPUT packet leaves the original sealed checkpoint unchanged.
Public paths use INPUT, OUTPUT, GOVERNANCE only. publicsafe-allowlist.json is
exhaustive. sha256-manifest.json hashes payloads and the allowlist but excludes
itself and seal.json; seal.json binds that manifest and allowlist, avoiding a
circular hash claim. No source release is authorized by this freeze.
