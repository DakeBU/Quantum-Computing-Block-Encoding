param([Parameter(Mandatory=$true)][string]$InputRoot,[Parameter(Mandatory=$true)][string]$OutputRoot)
$ErrorActionPreference='Stop'
$taskUtf8=[System.Text.UTF8Encoding]::new($false,$true)
$taskFiles=@()
$taskTarget=Get-Content -Raw -LiteralPath (Join-Path $OutputRoot 'target-inventory.json') | ConvertFrom-Json
$taskProviders=Get-Content -Raw -LiteralPath (Join-Path $OutputRoot 'provider-inventories.json') | ConvertFrom-Json
foreach($taskInv in @($taskTarget)+@($taskProviders)) {
  $taskRelative=$taskInv.logical_input.Substring(6)
  $taskBytes=[System.IO.File]::ReadAllBytes((Join-Path $InputRoot $taskRelative))
  $taskLineStarts=[System.Collections.Generic.List[int]]::new()
  $taskLineStarts.Add(0)
  for($taskByteIndex=0;$taskByteIndex -lt $taskBytes.Length;$taskByteIndex++){
    if($taskBytes[$taskByteIndex] -eq 10){$taskLineStarts.Add($taskByteIndex+1)}
  }
  $taskLineArray=$taskLineStarts.ToArray()
  function Get-TaskSourceLine([int]$taskOffset){
    $taskPosition=[Array]::BinarySearch($taskLineArray,$taskOffset)
    if($taskPosition -lt 0){$taskPosition=(-bnot $taskPosition)-1}
    return $taskPosition+1
  }
  function Assert-TaskLineSpan($taskSpan){
    if((Get-TaskSourceLine $taskSpan.byte_start) -ne $taskSpan.line_start){throw 'line-start mismatch'}
    $taskLast=[Math]::Max($taskSpan.byte_start,$taskSpan.byte_end-1)
    if((Get-TaskSourceLine $taskLast) -ne $taskSpan.line_end){throw 'line-end mismatch'}
  }
  $taskBuilder=[System.Text.StringBuilder]::new()
  $taskCursor=0
  foreach($taskCommand in $taskInv.commands) {
    if($taskCommand.span.byte_start -ne $taskCursor){throw 'noncontiguous command span'}
    Assert-TaskLineSpan $taskCommand.span
    $taskText=if($null -ne $taskCommand.raw){[string]$taskCommand.raw}else{[string]$taskCommand.header+[string]$taskCommand.delimiter+[string]$taskCommand.body}
    $taskLength=$taskCommand.span.byte_end-$taskCommand.span.byte_start
    $taskSlice=$taskUtf8.GetString($taskBytes,$taskCommand.span.byte_start,$taskLength)
    if($taskText -cne $taskSlice){throw 'command recomposition mismatch'}
    foreach($taskPair in @(@('header','header_span'),@('delimiter','delimiter_span'),@('body','body_span'))) {
      $taskSpan=$taskCommand.($taskPair[1])
      if($null -ne $taskSpan){
        Assert-TaskLineSpan $taskSpan
        $taskPart=$taskUtf8.GetString($taskBytes,$taskSpan.byte_start,($taskSpan.byte_end-$taskSpan.byte_start))
        if($taskPart -cne [string]$taskCommand.($taskPair[0])){throw 'header/body span mismatch'}
      }
    }
    foreach($taskBinder in $taskCommand.leading_binders){
      Assert-TaskLineSpan $taskBinder.span
      $taskPart=$taskUtf8.GetString($taskBytes,$taskBinder.span.byte_start,($taskBinder.span.byte_end-$taskBinder.span.byte_start))
      if($taskPart -cne [string]$taskBinder.text){throw 'binder span mismatch'}
    }
    [void]$taskBuilder.Append($taskText)
    $taskCursor=$taskCommand.span.byte_end
  }
  if($taskCursor -ne $taskBytes.Length){throw 'inventory does not reach EOF'}
  $taskRecomposed=$taskUtf8.GetBytes($taskBuilder.ToString())
  $taskSha=[System.Security.Cryptography.SHA256]::Create()
  $taskHash=([BitConverter]::ToString($taskSha.ComputeHash($taskRecomposed))).Replace('-','').ToLowerInvariant()
  if($taskHash -ne $taskInv.sha256){throw 'whole-file digest mismatch'}
  $taskFiles+=@{path=$taskInv.logical_input;bytes=$taskBytes.Length;commands=$taskInv.commands.Count;recompose_exact=$true;sha256=$taskHash;header_body_binder_offsets_exact=$true;all_recorded_line_spans_exact=$true}
}
@{kind='DETERMINISTIC_TEXT_ONLY_NOT_LEAN_EXECUTION';files=$taskFiles;all_verified=$true} | ConvertTo-Json -Depth 7
