# Actual provider roles and reading limits

The exact full local import closure is inventoried in provider-inventories.json.
An import is availability, NOT a claim that every theorem in that module is a
dependency. Named calls below are observed textual producer signals in the
read target/proofs. They do not claim an elaborated kernel dependency graph.

Core: Matrix finite functions, PointwiseEq, Coeff syntax/evaluation and algebra
syntax instances. These define equality and evaluation conventions, including
why evaluated associativity cannot be promoted to structural equality.
Circuit: Gate labels/lists and constructors; no physical semantics inferred
from an oracleCall name. Resources: assigned arithmetic resource records and
formula equalities. BlockEncoding: stencil/window/spec and supporting finite
matrix/product conventions. Examples/RobinHeat: exact four boundary lists,
five bulk coefficients, window, fixed parameters7/1/1 and width/resource facts.
All five small providers were fully read in the initial stage.

CircuitSemantics, now human-read1–814 in full, is the principal generic proof
provider. Matrix.evalWith_mul_eq_zero_of_all_paths_zero is used for every killed
path; its mechanism pushes eval through a finite fold and proves every summand0.
Matrix.evalWith_mul_apply_unique and its two-path variant use nodup finRange
and membership to extract surviving terms. Private fold inductions145–303 were
read in full; they are not assumed from names. evalWith_mul_identity_right_apply
and evalWith_evalGateMatrices_single handle the syntactic identity factor AFTER
evaluation. Matrix.cast_square_apply transports finite indices through equal
dimension casts. signalSystemBlockProjection defines a raw submatrix at
signal*systemDim+systemIndex. Selected branch/projection/backend statement
equivalence and PreparedCircuitEntryTarget equivalence rewrite genuine stored
coherence proofs but do not manufacture the central missing equalities.

GHL2025 is human-read in selected exact ranges, not claimed wholly read. Full
relevant operator definitions give indicator control, DT/boundary2×2 rotation
symbols, OD splice/address map, Of clean/offbranch/orthogonal cases and swap.
The active gate constructors and list are read and distinguish actual matrix
roles from labels and Bool unitary flags. Address transpose entries are
definitionally the converse indicator relation, not automatically an inverse.

The named bandedSparseAccessPaperPostSwapCleanupProducer_globalSlotSource,
globalSlot inverse-on-range/restricted-dagger THEOREM families provide the
restricted cleanup witness; the similarly named contract STRUCTURE only stores
data, Bool checks and ObligationRecords. Complete producer bodies were read: bit extraction,
reverse-offset modular identity, finite bounds, clean candidate, image equality,
then uniqueness. bandedSparseAccessPaperImage_injective_on_globalSlotSource
(6695–6821) reconstructs equal indices from preserved low bits/high tail/row,
equal addresses, sparse-slot injectivity and clean OD values. Its premises
n≥3,kappa7,clog2=3 and BOTH active-source predicates are essential.
swapOracleImage_self_inverse (6091–6101) uses swapped n-bit block identities,
preserved xor difference and cancellation; all those bodies6003–6101 were read.
This theorem supports row-support isolation in target private zero proofs.

functionOraclePaperMatrix_cleanBranch_entry and offBranch_zero supply actual
entry formulas under exact clean/basis premises; functionOracleAmplitudeProofRoute
merely groups their coefficients with open normalizer/completion records.
Derivative ND and boundary angle routes supply symbolic coefficient expressions
and obligations, not inverse/trigonometric semantics. Those are separately
bound as hentry/inverse hypotheses in the target's actual Rat algebra.

The formal seven-label and ten-label circuit definitions166–238 are data.
Their rfl/list-inequality theorems support textual mismatch only. No source
figure correspondence is inferred. Strings referencing papers or external
amplitude theorems remain uninterpreted provenance data, never read sources.

The read coverage ledger distinguishes complete target coverage, complete small
providers/CircuitSemantics, selected GHL exposure (including explicitly partial
boundary fragments), and whole-stream mechanical inventory. The latter alone
does not certify comprehension. No external Mathlib definition was requested:
the reconstruction needed ordinary finite sums, Nat bit arithmetic and Rat
algebra, whose local producer uses were inspected without a compiler.
