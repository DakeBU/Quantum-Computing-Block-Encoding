# Assumptions, definitions and theorem-strength boundary

The authoritative per-command boundary is declaration-boundary-audit.json:
all exact leading groups and the full returned type remain separate, in original
order. The exact full header/body is in target-inventory.json. Numeric family
ranges in progress.md are compact mathematical interpretations, not replacement
signatures. Every instance was read, including private support helpers.

## Recursive project-owned types

Core Matrix is a finite function, not a bundled linear map. Coeff is syntax;
its OfNat/HAdd/HMul instances build syntax. Fin bounds are genuine proofs.
Stencil/BulkWindow/Resource/BlockEncodingSpec and OneTermRobinParameters supply
data, not discretization validity or physical implementability hypotheses.
matrixOneNorm is max row sum, regardless of its name. The three initial named
Prop definitions unfold to numeric-Bool/resource/error field claims (181–202),
not block extraction. Their full definitions are included in the assumption
closure inventory, as are every other target Prop definition and structure.

SemanticObligation and GHL2025.ObligationRecord recursively terminate in
description:String,source:String,proved:Bool. No proof-valued field is hidden
inside these wrappers. This applies to unitarity, source-contract, cleanup,
normalizer-bound, block-correctness, LCU and final-extraction records.

GateMatrix contains a Gate label, finite matrix, SemanticObligation. Its type
does not require matrix unitarity. CircuitMatrixSemantics additionally contains
actual gateListMatches= true and matrix_eq_eval pointwise proofs; these prove
the label/matrix-fold interface only. ofGateMatrices assigns the folded matrix
and proves coherence by reflexivity. CircuitBlockEncodingClaim contains
semantics, target, actual dimension equality and another SemanticObligation;
it does not equate the semantic block with a normalized target.

BlockExtractionTarget contains unitaryMatrix (a NAME, not a unitarity proof),
targetMatrix,normalizer,signalIndex,blockMatrix and two SemanticObligations.
The default constructor defines blockMatrix by finite projection and leaves
both status flags false. FiniteBlockCompositionContract has actual
claim.target=expectedTarget, targetMatrix agreement and normalizer agreement;
its five correctness fields are SemanticObligations. Thus consistency of
attached data is not normalized block correctness.

PreparedCircuitEntryTarget has actual entry-to-matrix coherence proofs for
each of its two entries, but activeSource/preparedComposition are metadata.
Its equality statements are definitions of the still-unproved active=prepared
claim. BlockExtractionBranchContributionTarget likewise has actual selected
entry, sum-definition and block-entry coherence, but no proof of blockEntry=sum.
The selected statement follows from its stored coherence; projection/backend
statements are equivalent by substitution, not automatically true.

RobinOracleComposition contains a DerivativeOracleContract with actual
bandwidth=stencil.width and actual matrixCoherence=D; its sparseCorrect and
FunctionOracleContract.amplitudeCorrect are ObligationRecords. The latter
has only functionPieces and symbolic normalizerBound besides that record.
OneTermRobinTheoremData has data alpha,signalQubits,error,gatesBound:String,
pureAncillas and RobinProofObligations (ten ObligationRecord fields). These
are not recursively mathematical assumptions of an amplitude theorem.

The target OneTermRobinBlockEncodingProofRoute DOES require actual proofs
that parameters/normalizer/target/signal/circuit/claim agree with fixed data;
it also requires equalities saying open Bool flags are false and a selected
cleanup-scope enum/string matches. Its inhabitant is therefore a genuine
coherent open-route package, not an inhabitant of physical block correctness.
The remaining target structures package data, Coeff entries, named Prop
formulas and status flags; each entire field body is preserved in
assumption-closure.json. A field p:Prop stores a proposition; it does not store
a witness of p. Only a separate field hp:p or theorem result p would do that.

BandedSparseAccessPostSwapCleanup is different: its fields are genuine
post-swap/preimage/clean/range/dagger-entry/register-safety proofs. In contrast,
BandedSparseAccessGlobalSlotInverseOnRangeContract itself has only strings,
indices/register data, Bool checks and ObligationRecords. Its name does not
make it an inverse certificate. The separately named producer, injectivity,
uniqueness and restricted-dagger THEOREMS prove their stated restricted
propositions from explicit domain premises. CleanupScopeDecision also
recursively has enum/string/Bool/ObligationRecord fields, not such a proof.

## Genuine leading premises that survive the wrappers

The cleanup theorems require n≥3 and activeGlobalSlotSource=true; provider
injectivity additionally spells out kappa=7 and clog2(kappa)=3. Active source
requires clean padding and sparse<kappa. No unrestricted encoded-slot or
full-space inverse follows. The explicit cleanup witness is a conclusion,
not a leading assumed cleanup certificate in those producer theorems.

Factor-entry ledgers3622–4406 bind source/domain conditions plus TEN clean
rotation/function entry conditions on six supplied indices: two Of, four DT,
four boundary-Ry. Input i,j and several row/sparse values remain independent
unless an explicit equation links them. A list of individual gate entries
does not become a product-entry theorem.

Support lemmas bind arbitrary env and off-support index inequalities; their
results are evaluated zeros. The n3 finite probes contain native_decide proof
text but were not executed here. Full private producer bodies, not probe
counts, establish how the fold reduces to one or two paths.

hentry in corrected-entry/product theorems is the evaluated cosine equals
global coefficient*N_D_inv. hUniform is seven exact H[s,0] equations (earlier
focused contracts require only H[2,0]); H is arbitrary8×8 Coeff data. The
transpose convention supplies the matching entry by definition, not unitarity.
Normalizer results require hND,hNF,hkappa,hkappaSqrt separately. The exact
parameter universe contains no implicit positivity, nonzero bounds, physical
amplitude environment, real arccos semantics, or env(kappa)=7 condition.

hEntry/hRaw/hPreparedBackend/hExpanded/hexpansion/hFold are NOT generated
by naming an interface. Exact variants assume exact Coeff entry/fold equality;
evaluated variants assume equality under the chosen env. Exact implies
evaluated by substitution; one chosen-env equality does not imply exact.
The late backendExpansion premise is contradicted by the module's own actual
negation theorem. Its use as a leading premise makes that implication vacuous
for these exact objects; no positive closure is credited.

## What is actually negative and what is merely open

23644 and23688 prove negated propositions, using the explicit counterenvironment
and actual active-zero/fold-reduction algebra.26952 proves exact expression
inequality. These are distinct from every .proved=false equation elsewhere.
The counterenvironment is not required to satisfy corrected-entry/inverse
contracts; its role is only to separate unconditional syntactic expressions.
Under suitable chosen env, evaluated equality may hold iff selectedEval=0.

All named-source, sourceAnchor, required-lemma and “Compiled” fields are data.
The reading never follows their links or treats embedded process instructions
as authority. Actual named provider roles are in provider-roles.md. No theorem
quality is inferred from counts, imports, flags, names, or proof-tactic spelling.
No Lean/Mathlib execution or external source judgment was performed.
