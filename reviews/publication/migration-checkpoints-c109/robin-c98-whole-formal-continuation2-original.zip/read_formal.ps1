param([string]$InputFile, [int]$Start, [int]$End)
# Read-only display abbreviations. No source is modified and no Lean is run.
# Mathematical coverage is separately recorded; this script never grants it.
$taskLines = Get-Content -LiteralPath $InputFile
for ($taskIndex = $Start - 1; $taskIndex -lt $End; $taskIndex++) {
  if ($taskLines[$taskIndex].Trim()) {
    $taskText = $taskLines[$taskIndex]
    foreach ($taskPair in @(
      @('oneTermRobinBlockEncodingProofRoute','R'),
      @('GHL2025.','G.'),
      @('bandedSparseAccess','BS'),
      @('oneTermParameters','P'),
      @('oneTermRobinTotalQubits','Qtot'),
      @('oneTermRobinCircuitSemantics','Csem'),
      @('oneTermRobinGateMatrixPlaceholders','Gates'),
      @('oneTermRobinGate_','Gate_'),
      @('oneTermRobinBlockExtractionTarget','Target'),
      @('oneTermRobinGamma3','g3'),
      @('oneTermRobinFiniteBlockCompositionContract','Fcontract')
    )) { $taskText = $taskText.Replace($taskPair[0], $taskPair[1]) }
    '{0,6} {1}' -f ($taskIndex + 1), $taskText
  }
}
