# Mathematical reconstruction of the whole target

All references below are to the masked formal INPUT, not to external sources.
Exact declarations, bodies, offsets and ambient scopes are in the two inventories.
The ordered family reconstruction in progress.md covers the entire target;
declaration-boundary-audit.json maps every command to those families.

## Scalar and matrix conventions

Coeff is a free expression datatype with rational literals, named symbols,
addition, multiplication and negation. Structural equality is not ring equality.
evalWith interprets it in Rat under any env:String→Rat. Symbol names such as
N_D_inv, sqrt_kappa_inv, angle cosines and orthogonal entries have no automatic
inverse, square-root, trigonometric or unitarity law. Matrix r c α is a finite
function. Multiplication is a left fold over Fin indices from zero; the explicit
parenthesization matters before evaluation. Gate matrices are left-multiplied
in circuit order, starting with identity. Generic finite-sum support lemmas work
after Rat evaluation, where associativity and zero laws are available.

## The discretized matrix and numeric predicates

Let N=2^n, a=symbol("A1*dx"), b=symbol("B1*dx"). The row builder selects left
rows first if i<2; otherwise right rows if i>N-3, using natural truncated
subtraction; otherwise bulk. Missing boundary rows yield an empty list. All n
are accepted by these definitions, so familiar large-N row geometry cannot be
assumed at small n. Each stencil entry contributes exactly when integer i+offset=j;
duplicate matching entries are added, with no modular wrapping.

| row family | offset→coefficient |
|---|---|
| left0 |0→-5/2+(7/3)a;1→8/3;2→-1/6 |
| left1 |-1→4/3-a/6;0→-31/12;1→4/3;2→-1/12 |
| bulk |-2→-1/12;-1→4/3;0→-5/2;1→4/3;2→-1/12 |
| right N-2 |-2→-1/12;-1→4/3;0→-31/12;1→4/3+b/6 |
| right N-1 |-2→-1/6;-1→8/3;0→-5/2-(7/3)b |

These define D_n. Ak_n(i,j)=f_n_i*D_n(i,j), with f_n_i a symbol. The quantity
named matrixOneNorm is the maximum absolute ROW sum, starting at0, after chosen
symbol evaluation. The numeric normalizer is nD*nF*k. The named
robinBlockEncodingPredicate is only a conjunction of a normalizer Bool test at
the all-zero environment with nF=1, the resource ancilla equality2n, and stored
error=0. It is not an extracted-unitary block identity. Resource predicates
compare explicitly assigned formula fields (degreeCost*n*clog2(n)+kappa*n,
pureAncilla2n); no implemented-circuit asymptotic theorem follows from those
field equalities. The block-spec record targets D; later extraction targets Ak.

## Active semantics and restricted cleanup

The fixed parameters set kappa7, functionPieces1, degreeCost1. The register
partition has mf=clog2(n)+3, indicator1, sparse3, ODworkspace=n-3, systemn,
low ancilla1. Total qubits are their sum; natural subtraction is truncated.
At n3 the full dimension is8192. The active seven matrices are indicator,
sparse-amplitude DT rotation, boundary rotation, global sparse address matrix,
function matrix, register swap, and address transpose. Oracle labels are data;
the label Gate.swap0 0 has a separately supplied nontrivial matrix swapping
two n-bit blocks. CircuitMatrixSemantics proves label alignment and exact
folded-matrix coherence, not unitarity.

Address registers start above the low ancilla and system blocks. For sparse
slots0..6, global offsets are N-2,N-1,0,1,2,N-3,3; address=(offset+row) mod N.
Other slots default to offset0. The forward map replaces the n-bit OD register,
preserving low bits and high tail. Dagger is its transpose indicator matrix.
The n≥3,kappa7,clean-padding,slot<7 restrictions matter: the three-bit encoded
slot7 duplicates offset0 and is outside the active domain.

The cleanup producer constructs a post-swap index and clean preimage using
inverse-slot map4,3,2,1,0,6,5 (default2), then proves range/register preservation
and dagger entry1. Uniqueness compares only competing active-source indices.
It proves an inverse-on-range indicator statement, not a full-space inverse,
unitary extension, or cleanup of every clean encoded slot. The factor-ledger
theorems additionally have ten genuine rotation/function branch premises on
six separately supplied indices; they do not link those indices into a composed
circuit path merely by listing their individual entries.

Rotation matrices preserve upper bits and apply the symbolic2×2 pattern
[[c,-s],[s,c]] on the low ancilla when the indicator enables them. Boundary and
DT controls select different indicator values. There is no c²+s²=1 assumption
in the matrix definitions. The function matrix, on clean mf input, assigns
f_n_i*N_f_inv to its selected clean output, zero to other clean-mf rows, and
independent orthogonal symbols elsewhere. Nonclean input uses orthogonal
symbols. Clean-branch entry lemmas therefore need clean-input/output premises;
they do not supply amplitude bounds or a unitary completion.

## Actual n3 producer mathematics

The regrouped sevenGate matrix is suffix*prefix, with prefix=BS*(Ry*(DT*indic))
and suffix=Ddagger*(swap*Of). Its evaluated[32,32] is
(env f_3_0 * env N_f_inv)*env boundary_cos_half_0_2.
The proof exposes a two-row prefix support{0,1}, kills the ancilla1 suffix path,
and isolates the surviving path. Input0 instead reaches prefix support{96,97};
the suffix kills both. The active evalGateMatrices fold (including identity)
has a separate complete support proof giving evaluated[0,0]=0 for every env.
Equality with regrouped[0,0] is proved because both evaluate0; this is NOT a
syntactic whole-matrix associativity theorem.

Define I(s)=16s for s:Fin7 and c(s)=sevenGate[I(s),I(s)]*sqrtkappainv².
The six nonselected c(s) evaluate0 for every env. Complete private support
proofs instantiate (input x,forward support y,y+1,swap-preimage z) as
(16,112,14),(48,16,2),(64,32,4),(80,80,10),(96,48,6), plus the earlier slot0
proof. Each uses Of[z,y]=Of[z,y+1]=0 and unique dagger-row support. Thus the
evaluated seven-term fold equals c(2). In the environment assigning f_3_0,
N_f_inv,boundary_cos_half_0_2,sqrt_kappa_inv to1 and all other symbols0,
c(2) evaluates1, whereas active[0,0] evaluates0.

The target proves evaluatedBackendFold(env) iff eval(c(2))=0. It then proves
NOT backendExpansionStatement, NOT projectionSummationStatement, and finally
rawUnitaryEntry≠backendFold as exact Coeff expressions (23644,23688,26952).
The counterenvironment need not satisfy physical amplitude/inverse contracts:
it suffices to refute the unconditional syntactic equality asserted there.
It does not refute all restricted-environment equalities or arbitrary encodings.

## Prepared-entry route and remaining conditional strength

An initial placeholder family selects c(2) and repeats an opaque other-branch
symbol elsewhere. Its selection theorem is definitional, not a projection
theorem. Later c(s) replaces it with actual diagonal entries. Numerous records
and equivalences repackage the missing raw-entry=fold equality; none proves it.
Several later lemmas still bind the exact expansion proposition already negated
above. Such implications are formally conditional on an uninhabitable premise
for these fixed definitions, not successful producers of an active block.

For arbitrary H:Matrix8 8 Coeff, the uniform-column contract is
∀s:Fin7,H[s,0]=symbol(sqrt_kappa_inv). Dagger here is explicitly transpose,
Hdagger[i,j]=H[j,i], not a proved unitary inverse. The prepared8×8 matrix is
defined by the seven DIAGONAL terms U[I(s),I(s)]*(H[s,col]*Hᵀ[row,s]); it is not
derived from a full two-index sandwich of the full8192×8192 matrix. Its clean
entry equals the defined sandwich sum by rfl. A NEW singleton oracle circuit
is assigned this matrix, with unitarity obligation false. Evaluating its fold
agrees with that matrix via right-identity evaluation. Under hUniform, the
prepared clean entry evaluates to the c(s) fold. It is not the active raw entry.

The corrected-rotation premise hentry is
env boundary_cos_half_0_2 = eval(globalBoundaryCoefficient(3,0,2)*N_D_inv).
It is an assumption, not a derived arccos/half-angle identity. With hUniform,
hentry, NDinv*ND=1, Nfinv*Nf=1, kappainv*kappa=1 and sqrtkappainv²=kappainv,
the target proves
eval(preparedCleanEntry)*eval(N_D*N_f*kappa)=eval(Ak_3[0,0]).
No hypothesis equates env("kappa") with literal7 in that algebra, and no
construction of a normalized physical H is supplied. The theorem is a genuine
conditional algebraic statement about the separately defined prepared entry.

The formal10-label circuit differs from active7: it includes preparation and
indicator-dagger labels and different address/dagger spellings. The module
proves list inequality and keeps the attached finite contract wired to active7.
That textual distinction is not a source correspondence judgment. Final large
audits combine the positive conditional prepared identities, exact negative
backend results and false status flags without supplying normalized active
block equality, full unitarity, final extraction or circuit resource correctness.

## Certainty boundary

The scalar/finite-index mathematics above is reconstructed directly from full
formal definitions and producer bodies. Textual calls to native_decide, simp,
omega and named lemmas were read, never executed. No kernel acceptance is
asserted. SemanticObligation/ObligationRecord.proved are Bools; true is not a
proof and false is not negation. Actual negation results are distinguished above.
External-source-relative labels remain WITHHELD: no natural-source contract was
provided, and strings mentioning papers, anchors or prior process have no such
authority here. Stop FROZEN_BEFORE_SOURCE_RELEASE.
