# Exact source-only release boundary

Release ONLY these four files for a new source-only review:

- `whole-natural-source.md`
- `whole-source-graph.json`
- `whole-source-coverage.json`
- `whole-source-only-isolation.md`

This is a retrospective LOCAL distributed AUTHOR proposal, not an independent extraction or approval. The source is implementation-informed. Reading provenance is disclosed in the source and coverage, without pretending that the integrator personally reread the distinct author's raw tail. The requested review must decide whether this natural construction, its quantifiers and its proposed topology actually support their stated contracts. It must not inherit an expected acceptance.

Do NOT release the formal audit, raw or comment-masked Lean, exact formal signatures/fields/definition bodies, author assembly scripts, prospective publication records, author handoff/rationale, prior review/decoder findings or acceptance metadata in this source-only packet. In particular, the C78 file stored under a PUBLIC directory as `definition-binder-field-audit.json` is implementation-informed FORMAL material and is not source-only input. A directory label does not override this separation.

The source itself honestly distinguishes exact symbolic refutations, unconditional evaluated support/fold statements and conditional compressed-prepared entry statements. None is an admission, physical full-operator construction, original-paper verification or arbitrary-n family theorem by default. No production association or scientific target is changed by this release.
