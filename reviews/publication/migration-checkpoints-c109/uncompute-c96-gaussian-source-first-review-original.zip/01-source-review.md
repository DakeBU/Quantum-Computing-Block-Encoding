# C96 Gaussian: independent source-only reconstruction

Status: SOURCE_ONLY_FROZEN after the companion seal is generated. This is a source audit, not a certified circuit, implementation review, publication admission, or independent approval of this auditor's own graph.

Logical paths: W is the task work area, G the read-only governance repository, P the pinned primary PDF. Public packet root: W/uncompute-c96-gaussian-source-first-review/. The source is Gu, Kemeny, Yelin and Lukin, arXiv:2610.22367v1 (15 October 2026), SHA256 3607f457c3349db74e10b131abadef23a4a2dea0fefa0cf6ac6d0ed9f37fdfd9. All page numbers below are physical PDF pages; SI page = physical page minus 17. Text extraction and complete-page visual inspection were separate actions.

## 1. What the source actually supplies

The Gaussian anchor is SI III.3, physical page 36 / SI page 19, Eq. (67). It specifies a finite fixed-point numerical function evaluator. It neither prepares a Gaussian-amplitude state nor supplies a block encoding. Its connection to chemistry [2] and Gaussian state preparation [65] is a stated application motivation, not an implemented consumer construction.

The source specifies a 39-bit two's-complement input Xs, x = Xs/2^32, promised x in [-8,8), and a 39-bit accumulator. Its ideal reference value is

    F(Xs) = round(2^32 exp(-x^2)).

SI III's common map (page 33) is additive, |x>|k> -> |x>|k + f_tilde(x)>, not the generic XOR illustration on page 1. Footnote [63] on page 13 makes the addition modular in the n-bit accumulator, defines nearest-integer rounding with half-integer ties away from zero, defines circular distance modulo 2^n, and leaves behavior outside the promised domain unrestricted. Extended Data Table 1 (page 17) specifies 39 read-only input and 39 target qubits; the target may start nonzero. Thus an overwrite-only or k=0-only witness is not this interface.

The source calls the Gaussian tolerance absolute error strictly below 10^-7, reports worst-case error 9.99 x 10^-8, and reports 9,000 tests. This is a uniform numerical tolerance, not a Gaussian failure budget. Input preservation, phase correctness, and cleanup remain exact even for a numerical approximation (Methods, page 9, Eq. (10)).

## 2. Exact finite carrier and semantic obligations

The following arithmetic expansion is this auditor's deduction, not an extra source hypothesis or circuit transcript. Let M = 2^39, S = 2^32, and u in {0,...,M-1} be the encoded input. Define signed(u) = u for u < 2^38, and u-M otherwise. The whole signed carrier represents [-64,64); only integers -2^35 <= signed(u) < 2^35 are promised. There are 2^36 promised inputs. All k in Z/MZ are allowed accumulator values.

For a deterministic integer increment A(u) in Z/MZ, the intended clean logical action is

    |u>|k>|0^a> -> |u>|k+A(u) mod M>|0^a>.

For a measurement implementation this is the same logical map on every possible measurement record, with the target phase zero and no residual input-dependent sign. No arbitrary phase depending on u, k, or measurement record is allowed; the Methods simulator tracks even a global sign as part of the stated phase test. The choice of a physical endianness, tensor wire order, workspace layout, and exact number a is not given for Gaussian in the PDF. The displayed register order above expresses the interface, not a recovered gate allocation.

The most literal fixed-point reading is

    d_M(A(u), F(signed(u))) / S < 10^-7,
    d_M(a,b) = min_{j in Z} |a-b+j M|.

Equivalently this can be checked against k+F after modular addition because circular distance is translation invariant. The physical scaling by 1/S is essential: 10^-7 is about 429.4967296 output integer units, not a sub-unit integer requirement. On this rounded-reference reading, an integer discrepancy of at most 429 units is allowed. The prose also describes approximation of the analytic Gaussian and gives no formula explicitly defining the reported worst-case-error calculation. Comparison to S exp(-x^2) rather than to round(S exp(-x^2)) changes a boundary by at most half an integer unit. That distinction must be fixed by a later source witness, not silently collapsed here. The quantization bound |F/S-exp(-x^2)| <= 2^-33 is a deduction.

F is a literal uniquely defined integer function on the promised set. The approximation A is NOT uniquely characterized by this relation. Many different increments satisfy the tolerance; the PDF does not identify its actual coefficient table well enough to reconstruct one exact A. Behavior outside the promise is unrestricted by the numerical specification, but any full circuit still has to implement a well-defined coherent operation on its whole carrier; one cannot infer clean/valid off-promise behavior by assigning a zero fallback in a definition.

## 3. Reconstructed discovered construction

SI III (page 33) first explains a shared architecture: bit-selectable fine partitions; lower-degree polynomials on smaller coordinates; arithmetic accumulated directly into its destination; MBU of loaded coefficients rather than reverse lookup. An offline classical search fits coefficients to the exact quantized/truncated integer computation, including coefficient widths, shifts, omitted product columns, truncation and rounding together. It is not a theorem that rounding a real polynomial fit afterwards achieves the same budget.

SI III.3's Gaussian-specific path has these stages:

1. Fold the signed input. For a negative input, use complement instead of absolute-value complement-plus-one. The resulting nonnegative coordinate is y=|x|-2^-32, whereas nonnegative inputs use y=x. The source claims the offset fits the error budget and removes a carry chain; it does not form x^2.
2. Select a uniform interval by ten bits of y. There are 1,024 intervals of width 2^-7 spanning [0,8). Lower bits supply the local coordinate; no general-boundary comparison is needed.
3. Load the selected data using variable-spaced QROM [66], terminating subtrees having identical values. The first 455 intervals need quadratics, the next 59 constants, the remaining 510 zero. This is a coherent fixed circuit with encoded regime behavior, not ordinary classical if-statements that skip the cost of unselected branches. The PDF reports lookup cost falling from 1,022 to 495 Toffolis.
4. On a quadratic interval, obtain intercept, slope, curvature. A truncated product changes the slope register in place. Add the intercept and accumulate the final product directly into k, without materializing y^2, a full product, or a completed Gaussian-value register.
5. MBU clears consumed coefficient information; freed coefficient qubits are reused as carry ancillas for later arithmetic [64]. Common Methods require exact phase correction, clean final ancillas and exact preservation of Xs. The Gaussian paragraph does not give a complete schedule showing which coefficient is measured before which later arithmetic use, or how the modified slope's measurement phase is corrected.

Further deductions, clearly separate from source statements:

- In integer coordinates, j = signed(u) for nonnegative inputs and j = -signed(u)-1 for negatives. Then 0 <= j < 2^35 and y=j/S. The folded image is reached twice: signed values j and -(j+1). Folded data alone are not injective; sign/history must remain available to restore the input. This is a missing explicit gate witness, not permission to discard the sign.
- With mathematical bit index 0 least significant, the interval index is J=floor(j/2^25) in [0,1023], and the local integer is r=j mod 2^25. Thus bits 25 through 34 select J, and 25 lower bits remain as the full exact local coordinate. This does not say how many lower bits the actual truncated kernel uses. The source does not prescribe a physical wire-order convention.
- Reading 'the next' in increasing coordinate order gives regimes J=0..454, 455..513, 514..1023. Their union covers every folded input. This case partition is not three independently sufficient construction routes; the assembled Gaussian evaluator needs all three branches plus coherent selection/cleanup.
- At x=-8 the folded coordinate is 8-2^-32, not 8; the final interval therefore handles this promised endpoint without expanding the partition. Zero is paired with x=-2^-32, not with x=0 under an exact absolute-value fold.
- The fold-only analytic error can be bounded by sup_{t>=0} 2t exp(-t^2) times 2^-32 = sqrt(2/e) 2^-32, using the mean value theorem. This is a narrow analytic bound, not the end-to-end truncated-polynomial bound.

The HHL equations q_L(d)=g0-d(g1-g2 d), in-place update t<-g1-g2 d and k<-k+g0-dt (Eqs. (63)-(64), page 34), and the inverse-routing/MBU figure (Fig. S3, page 35) illustrate the shared design. They are NOT a Gaussian coefficient sign convention, scaling law, 15-bit coordinate claim, 16-bit slope claim, cyclic-shift requirement, or Gaussian circuit diagram. Gaussian's own paragraph does not print an integer quadratic formula with all shifts and column omissions.

## 4. Source alternatives and AND/OR topology

There are two source-described numerical architectures to compare, not one combined recipe:

    NUMERICAL_ROOT = OR(HRS_BASELINE, DISCOVERED_GAUSSIAN).

The tuned HRS route forms x^2, uses cubics on 32 intervals and general 40-bit arithmetic. Common HRS machinery selects coefficients, uses Horner multiplication, accumulates into the output and reverses temporary computation. It is a separate route to the value interface at a different resource point. It is NOT sufficient for the discovered (1,583,139) resource claim.

The discovered route has a complete AND tail: finite domain/rounding contract AND reversible fold/restoration AND all-regime coefficient selection AND exact truncated integer kernel AND coherent/phase-correct MBU cleanup AND uniform error witness AND resource witness. The quadratic/constant/zero branches form an exhaustive case split inside that AND tail. QROM lookup correctness alone cannot supply the polynomial error or complete numerical root. A final value check cannot supply cleanup or relative-phase correctness.

Methods describes two ways to clear a temporary AND: inverse Toffoli, or destructive X measurement plus conditional CZ (Eqs. (11)-(12)). Those are local alternative cleanup mechanisms. Only the MBU route is described as supporting the discovered coefficient reuse/resource saving; replacing it by reverse gates would require fresh resource accounting. The topology JSON preserves these local OR routes and separates them from the full alternative HRS/discovered routes.

External citations are unresolved dependencies in this source-only review: [12] HRS approximation/arithmetic baseline; [8] kickmix; [29] temporary-AND MBU; [64] lookup MBU/reuse; [66] variable-spaced QROM. The PDF gives their identities but their full source statements were not inspected. [57], [61], [62] motivate classical/reversible numerical design; [2], [4], [58]-[60], [65] are application/background links rather than Gaussian circuit certificates. A bibliography record is not a supplied gate theorem.

## 5. Exact phase, cleanup and validation boundary

Methods Eqs. (10)-(16), pages 9-10, allow X, CNOT, Toffoli, swap; Z, CZ, CCZ and global sign; and destructive X-basis measurements. Before measurements the simulator tracks a basis bit string and a sign. A measured Boolean f(y) contributes (-1)^(r f(y)); a conditional diagonal correction must cancel it. Measurement outcomes may be XOR-combined and control diagonal corrections, but may not control basis-changing operations. All measurement records must therefore induce the same basis permutation, and every allowed input/record pair must have the correct phase. Dirty reset is explicitly rejected.

For Gaussian, the logical basis permutation is modular addition by a fixed chosen approximation A(u), independent of measurement record and initial k. Once a circuit witness establishes this map and exact cleanup for every u,k and possible record, linearity gives coherent action on promised superpositions. The PDF does not provide that exhaustive Gaussian witness.

Eqs. (17)-(21) are statistical guarantees conditional on a candidate fixed before test draws, a specified input distribution D, uniformly sampled measurement records, and a defective-trajectory set B. Their epsilon is a probability mass, NOT the Gaussian numerical tolerance. The paper derives a state-norm bound 2 sqrt(epsilon) and a sampled-test confidence relation. The stated fidelity formula (1-2 epsilon)^2 must be used with the nonnegative-overlap bound (or small-epsilon regime); it cannot be blindly extended past epsilon=1/2 by squaring a negative lower bound. These general statistical expressions do not establish a Gaussian uniform maximum from 9,000 samples, nor specify a Gaussian test distribution/confidence level. No confidence level or zero-failure outcome is inferred here.

Even a one-unit difference between A and ideal F maps a computational-basis accumulator to an orthogonal basis state. Therefore a small real-valued numerical error is NOT a small state-vector/operator-norm error between the approximate and exact integer-addition oracles. A consumer-specific stability theorem is needed.

## 6. Resource scope

The source reports discovered T=1,583, Q=139, rounded TQ=220,000 and gain 39, versus an approximately 24,000-Toffoli, 362-qubit tuned HRS baseline (Table I; Extended Data Table 1; SI III.3). Multiplying the reported discovered integers gives 220,037. This is a deduction explaining the rounded prose, not a source correction. The quoted baseline numbers are rounded and do not determine an exact gain ratio. Extended Data Figure 2 marks the same discovered endpoint and shows other valid lineage points, not other fully documented gate constructions.

Methods Eq. (22) counts Toffoli and CCZ equally in T; Q is peak simultaneous allocated logical qubits including data and ancillas. The 39+39 persistent interface accounts for 78 of the 139 at peak; the remaining 61 is a derived peak overhead budget, not a disclosed layout. Clifford operations, measurement records, feed-forward time, routing, depth, connectivity, state preparation and fault-tolerant physical costs are not resolved by this tuple. No asymptotic theorem in variable precision or dimension follows from this one fixed instance. The exact resource witness still needs a complete gate/allocation trace including MBU corrections and reuse legality.

## 7. SP/BE consumer boundary

Page 33 names two uses: ordinary computational-basis accumulation for later bit-controlled operations, OR a phase-gradient accumulator for phase kickback. The evaluator supplies neither the later controlled operation nor preparation of that phase-gradient state. Eq. (81), pages 40-41, gives a 51-bit phase-gradient example for another task; it supports the general mechanism but is not a 39-bit Gaussian consumer circuit.

Conditional deduction: if |PG_M> = M^(-1/2) sum_k exp(-2 pi i k/M)|k> has been prepared, addition by A produces exp(+2 pi i A/M)|PG_M>. Taking the 39-bit Gaussian scale gives a phase near exp(2 pi i exp(-x^2)/128), not automatically exp(i exp(-x^2)). For this first harmonic, circular value error converts to phase error at most 2 pi d_M(A,F)/M. Desired phase scaling, phase-gradient preparation, repeated use, errors and costs are extra AND-tail obligations. This phase is an intended relative phase across x labels, unlike an uncorrected MBU sign.

SP acceptance would additionally require: a named grid/discretization; a target amplitude family (exp(-x^2) is not the square root of the density exp(-x^2)); normalization; preparation of an input distribution; a valid amplitude-conversion/rotation or other loading mechanism; precision propagation; cleanup and any needed inverse access; a nonzero accepted branch; success probability, postselection/amplification costs, and the final state-error metric. None is supplied by a correct value evaluator alone.

BE acceptance would additionally require: a specific operator and basis; scaling alpha; a block projector and ancilla convention; an amplitude conversion plus clean uncompute for a direct diagonal route, OR coefficient PREPARE + phase/sign convention + SELECT + unprepare for an LCU route; and an operator-norm error/resource theorem. SP alone is not arbitrary BE. Conversely BE -> SP needs an input state and a nonzero accepted block action, normalization and success/amplification accounting. These are conceptual conditional transports, not source-certified edges.

An especially important finite-bit boundary is that circular-distance approximation alone does not ensure 0 <= A/S <= 1 under unsigned interpretation. Near zero, A=M-1 is close modulo M to zero but is not a legal unsigned probability. This is a generic logical counterexample to consumer inference, NOT a claim about the authors' actual coefficient table. A consumer needs signed/unwrapped/clipped range semantics proved for the actual outputs; clipping would be a separately identified change, not faithful-source normalization.

## 8. Missing-witness obligations and own verdict

O1: Resolve the exact rounded-versus-analytic reference used by the reported error, and supply a uniform, strict bound for every promised input, including negative fold offsets, interval boundaries and regime transitions.

O2: Supply the actual coefficient table, widths, sign formats, scalings, shifts, local-coordinate truncations, omitted product columns and rounding locations that identify the actual finite function A. No coefficient can be inferred merely from regime counts.

O3: Supply literal variable-spaced QROM topology, equal-subtree values, selection phase and 495-Toffoli accounting, tied to the table.

O4: Supply fold and inverse/restoration semantics retaining the sign distinction, including x=-8 and input read-only restoration, with an explicit physical bit/register order.

O5: Supply the exact in-place kernel on all three regimes for arbitrary initial k, carry/overflow/modular behavior and preserved inputs; do not import HHL widths/signs/rotations.

O6: Supply every coefficient/workspace cleanup and MBU phase fixup, including the consumed/modified slope, all measurement records, a legal coefficient-qubit/carry reuse schedule, and final clean ancillas. A temporary-AND illustration is not that witness.

O7: Supply a complete T/CCZ and peak-allocation trace proving 1,583/139 in the stated model, separately from an expanded all-gate/depth/finite-bit resource claim.

O8: Supply any requested downstream SP/BE/phase consumer construction with its complete AND tail and error/success costs. Do not infer it from Eq. (67) or citation [65].

Own verdict: the PDF specifies a meaningful finite numerical interface and a coherent architectural explanation with a named resource claim. It does not, on its own, expose enough data for this reviewer to reconstruct an exact Gaussian finite function implementation, certify uniform error, certify all-record phase/cleanup, or accept SP/BE consumers. These are SOURCE_CONTRACT_GAP / missing-witness nodes, not evidence of a false Gaussian theorem or failed author circuit. No repair or added public hypothesis is approved here. Failure class for this review run: NONE; the review completed, with source gaps explicitly retained. Independent review of this reconstruction remains pending. No Lean, signature, compilation, simulation, code comparison, Git, network or other-review access occurred. Stop at SOURCE_ONLY_FROZEN.
