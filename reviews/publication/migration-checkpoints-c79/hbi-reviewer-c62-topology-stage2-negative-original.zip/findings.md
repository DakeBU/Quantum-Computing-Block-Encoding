# Stage 2 findings

Overall: `NEGATIVE_AS_COMPLETE_SOURCE_TOPOLOGY`.

Coverage: `ACCEPT_EXACT_BLOCK_TEXT_AND_DISPOSITIONS`, supplemented by the explicit 85 empty lines. Stage 1 `RECOVERABLE_SOURCE_ONLY` remains unchanged. This is not a mathematical counterexample to equation (22).

## F1 — Missing specialized supplier at equation (10) [blocking]

Author goal: `source:c56-finite-suffix`, anchor `S4 equation (10), finite contraction induction`.

Source lines 170-172 contain BOTH Q_w(i)=B_i^d(Phi_w(0)) AND c^(s,|w|)Q_w=P_k(x(s+J(w))) under x(s)!=0. E05 has only shared-cores and word-coordinate tails. Its entire transitive ancestry is restriction + shared-cores + word-coordinate. It contains no injection-eval, Bernstein target row or literal target node. Generic half-subdivision and word fractions cannot identify the source-specific injected row with P_k. The missing source supplier is the S3 injected polynomial identity at lines 138-141 (using lines 85-105 and 107-135). Frozen baseline `FINITE_ADAPTER` requires `FREE_SUFFIX` AND `INJECTION_EVAL`. The tail cannot be recovered by transitivity in the submitted graph.

## F2 — The traversal's finite-readout bridge is not in its ancestry [blocking for the frozen source reading]

Author goal: `source:c56-traversal`, anchor S5 (11)-(13). Full-node semantics at lines 189-192 return the row readout (7)-(10); lines 205-206 apply (10). E06 has only injection-eval and word-coordinate tails. Its full ancestors are Bernstein + injection-eval + restriction + target + word-coordinate; no shared-cores or finite-suffix node occurs. S3's coordinate polynomial evaluation therefore lacks the S4 bridge to finite cQ readout. Frozen baseline `TRAVERSAL_TARGET` requires `FINITE_ADAPTER`.

If F1's node were silently narrowed to Q alone, that would not itself resolve F2 or account for equation (10)'s second conjunct. Conversely, injecting a nonzero-coordinate premise into the generic matrix adapter would alter the source's conditional separation at lines 229-235. No narrowing, alternate H definition, repair edge or repair graph was applied in this stage. Both mechanisms being reachable only at the later exact-root consumer does not supply either intermediate goal retroactively.

## F3 — All-real right-tail algebra versus positive-grid cuts [domain qualification]

E13 advertises arbitrary real L for the exact right-tail expression, but has the combined `source:c56-grid-cuts` node as a tail. Its stated anchor equations (1)-(2) includes L>0-dependent cut semantics. The source's all-real right identity at lines 313-319 uses only the grid formula/hM=pi L; the positive support interpretation uses cuts. The frozen baseline separates `GRID_DEF` from `CUTS`. The coarse projection has no explicit consumed-facet scope, so this claimed generality cannot be certified as a full-domain implication from the entire positive-L cut theorem. This is a projection precision issue; source mathematics and the L>0 public root remain correct.

## F4 — Unsupported imported-provider sentence [non-source assertion excluded]

The final `alternative_routes_explanation` asserts that an imported Euclidean polynomial representation is a provider equality. The sole allowed natural source has no such object or assertion. This fragment is not accepted as source-derived evidence and was not investigated elsewhere. The no-algorithmic-OR conclusion itself is supported by source lines 402-404.

## Accepted checks

All 24 proposed nodes are mapped to the 43-node independent baseline in `node-crosswalk.tsv`. All 16 exact AND tail sets are reviewed in `edge-review.tsv`; no OR route was substituted. All 86 block texts, ranges and dispositions are checked individually in `block-review.tsv`, with gapless 404-line accounting in `coverage-integrity.json`. Generic degree, Hermite specialization, u!=1 versus total formulas, middle and prefix schedules, root-partiality/empty-branch cases, all three exact-root branches, center assignment, stage/wire order and the separate real-dense storage tier are preserved where explicitly scoped.

No source, author proposal or frozen review artifact was changed. No Lean, formal decoder, other review, author audit/statement seal/declaration map/metadata, R repository, network, compiler, simulator or child agent was accessed. This is source-topology review only; there is no compile, source/formal-fidelity, finite-bit ROOT, PURIFIED, publication-binding or normalized-state verdict.
