# Independent Stage 2 source-topology comparison

Verdict: `NEGATIVE_AS_COMPLETE_SOURCE_TOPOLOGY` for the submitted projection. Block-text/disposition coverage is accepted. The frozen Stage 1 verdict `RECOVERABLE_SOURCE_ONLY` is unchanged. A source that supports the theorem and a proposed dependency graph that fully represents that support are different questions.

This review compares only the released source-only proposal against the already sealed independent source baseline. It neither edits nor repairs the proposal, source, or baseline. `W` is the portable logical workspace `hermite-export-work`.

## Inputs and order

The control file hash was checked before its inputs were used. The unchanged source, author projection and exact block inventory were then pinned. The original review seal remains `59d340426a1ad279aeef9ed1a6389655e36e9aa3e964a97260d724bc7bd9b051`; its independent 43-node graph remains `13cae33e218997b56da72221579e7dd9a75067153f2655e2ae8578873ccb2514`. This comparison occurred only after the independent reconstruction had been completed and sealed. Full pins and chronology are in `inputs-chronology.json`.

The author projection has 24 nodes and 16 hyperedges, each marked AND. Its `alternative_routes` list is empty. A coarser 24-node graph can in principle faithfully represent the 43-node independent graph; node-count disagreement is not a defect. The issue is whether coarsening preserves the distinct suppliers and conditional domains of all claimed source goals.

## The decisive missing supplier

Author node `source:c56-finite-suffix` anchors **S4 equation (10)**, not merely its first conjunct. At source lines 170-172, equation (10) says both

    Q_w(i) = B_i^d(Phi_w(0))
    c^(s,|w|) Q_w = P_k(x(s+J(w)))    when x(s) != 0.

Its sole incoming edge E05 has tails `source:c56-shared-cores` and `source:c56-word-coordinate`. Those tails establish the first identity by the finite recursion and e_0 terminal. The second additionally needs the S3 injection identity at lines 138-141, itself supplied by the literal beta representation, affine restriction with u!=1, and the source injection (7). In the author graph, all of that specialized information is under `source:c56-injection-eval` and `source:c56-bernstein`/`source:c56-target`.

The **complete transitive ancestor set** of `source:c56-finite-suffix` in the submitted graph is exactly:

    source:c56-restriction
    source:c56-shared-cores
    source:c56-word-coordinate

There is no transitive path from `source:c56-injection-eval`, `source:c56-bernstein`, or `source:c56-target` to this node. Restriction alone is a generic operator identity for arbitrary degree and coefficient row; it does not identify a row's polynomial with the fixed P_k. Therefore the missing supplier is not already present indirectly. In the frozen baseline the distinction is explicit: `FREE_SUFFIX` proves the generic Q identity, while `FINITE_ADAPTER` requires BOTH `FREE_SUFFIX` and `INJECTION_EVAL`. The nonzero-start condition belongs to the latter, not to generic Q.

This is a dependency-completeness defect, not a counterexample to the source theorem. For example, at k=0 and an empty suffix, Q_empty=e_0 is fixed by the generic suffix data, while a row readout is its zeroth coefficient. The generic suffix premises alone put no source-target constraint on that coefficient. Only the literal injection/evaluation supplier identifies it with P_0(x(s)). The actual source provides that supplier correctly; the proposed E05 ancestry does not.

## Why narrowing the node informally does not resolve the submitted graph

One might read `finite-suffix` as intending only the first, generic Q assertion of equation (10). That narrower interpretation avoids attributing the specialized readout to E05, but it is not a complete topology for the source as submitted:

- `source:c56-traversal` anchors equations (11)-(13), including the full-node **row readout** at source lines 189-192 and its identification using (10) at lines 205-206.
- E06 supplies only `source:c56-injection-eval` and `source:c56-word-coordinate`.
- Its complete ancestor set is `source:c56-bernstein`, `source:c56-injection-eval`, `source:c56-restriction`, `source:c56-target`, `source:c56-word-coordinate`. Neither `source:c56-shared-cores` nor `source:c56-finite-suffix` is an ancestor.

S3's coordinate evaluation of the injected Bernstein polynomial is not, by itself, a proof that the finite matrix readout cQ equals that evaluation. The bridge is precisely the Q identity of S4. In the independent baseline, `TRAVERSAL_TARGET` depends on `FINITE_ADAPTER`, which depends on both suppliers. Thus E06 lacks the finite adapter supplier for the finite-row-readout meaning independently reconstructed in Stage 1.

If an alternative coordinate-only definition of H were intended inside this coarsening, its scope and equivalence with the finite readout would need to be represented, not presumed. The projection does not provide such a scoped bridge. No such alternative definition was adopted or written by this reviewer.

The generic matrix-to-traversal adapter at source lines 229-235 must remain independent of (12): it needs the literal injected row and generic Q, schedule validity and root partiality, but does not need to interpret that row as P_k. Simply importing the entire conditional equation (10) into every generic adapter would blur this source distinction. Its generic goal is not invalid; the submitted coarsened node allocation is insufficiently supplier-complete.

The exact-root node does eventually have both mechanisms somewhere among its ancestors, through different branches of the graph. That does not retroactively supply an intermediate lemma: graph edges point from suppliers to goals, not from a later shared consumer backward to earlier nodes. The exact root's five required tails, including all three actual branch readouts, are correctly marked AND. Root-level reachability is not a substitute for closing E05/E06's own goal scopes.

## Conditional domains and total formulas

The following distinctions agree with the source and the frozen baseline:

- Equations (5) and (7) define total coefficient sequences, but equation (6) has affine-restriction meaning only for u!=1. Actual middle starts satisfy p_s<0, so 1+p_s<1. A right endpoint equal to one is permitted.
- Bernstein basis/restriction/shared Q are available at every natural degree, including zero. The actual source beta and injection specialize d=2k+1. No relation k<=n is used.
- Traversal interpretation needs exactly nonzero coordinates on the integer interval. Generic boundary adapters separately need schedule validity AND root partiality. The scalar target adapter separately needs universal equation (18).
- Actual middle schedule validity uses dyadic divisibility r<=n but not C<=M. Root start zero does use C<=M. The middle is disabled at C=M. The left prefix schedule is valid at arbitrary width; its actual branch is disabled at C=0.
- The source injection uses excluded endpoint s+2^q, while the left exponential injection uses last included point s+2^r-1. These are not interchangeable.
- The right gate is the first/MSB factor at level n; its unrestricted shorter suffix factors agree only at lengths <=n. The center belongs to the right branch by P_k(0)=1.

E13 has an additional **domain-facet ambiguity**: it feeds `source:c56-grid-cuts` into `source:c56-right-tail` while explicitly advertising the right-tail algebra for arbitrary real L. The grid node anchors equations (1)-(2), whose cut equivalences and h>0 interpretation need L>0. The all-real right-tail identity needs only the literal grid formula and hM=pi L, as separately represented by `GRID_DEF` in the frozen baseline. The source is correct at both domains. The projection does not identify which facet of its combined grid node is being consumed. This is not an extra public-root hypothesis and not a counterexample to the source; it is a domain-preservation qualification on accepting the coarse topology. It cannot be certified as an all-real implication if the entire positive-L cut theorem is treated as a mandatory premise.

## Coverage and nonmathematical exclusions

All 86 author block `text` fields match the corresponding source lines exactly after joining line content with the JSON text's LF separator. This does not reserialize or alter the pinned CRLF inventory file. That file has 865 CRLF line endings and zero bare LF endings. All its byte-level pins are unchanged.

The blocks cover 319 source lines: 305 lines in 76 NODE blocks and 14 lines in 10 EXCLUDED blocks. The remaining 85 lines are exactly empty separator lines, each explicitly listed in `coverage-integrity.json`. No nonempty line is omitted or duplicated; these classes exhaust all 404 source lines. `block-review.tsv` gives a separate reviewer disposition and independent-baseline mapping for every block, including every excluded block. Excluding the title, section headings and provenance paragraph from mathematical graph nodes is acceptable; their provenance restrictions remain binding in this review.

The author inventory has no explicit per-block graph-node IDs, only section/disposition/reason. The reviewer crosswalk adds this missing auditability without treating the author's generic NODE labels as proof of graph closure. Exact block text and exhaustive paragraph inventory do not cure missing graph suppliers.

The projection's final `alternative_routes_explanation` adds the sentence that an imported Euclidean polynomial representation is a provider equality. No such imported object or equality is present in the permitted natural source. This sentence is not accepted as a source-derived assertion and is not used. No external context was consulted to interpret it. The surrounding no-algorithmic-OR conclusion is independently supported by source lines 402-404.

## Exact root, storage and remaining scope

The submitted exact-root edge correctly demands left actual + middle actual + right actual + direct sum + grid cuts. The three masks form a required additive partition, not three alternatives. The scalar target, word width n+1, all natural k,n, L>0, endpoint conventions and absence of a normalizer agree with Stage 1. No new scientific target was inferred.

The storage edge independently consumes the explicit tagged direct-sum carrier: its dimension is 2k+6 and dense stage/bit/input/output cardinality is 2(n+1)(2k+6)^2. It need not consume the numerical sample identity. It remains an exact real-scalar address count, not finite-bit memory, runtime, gate count, normalized preparation or error-dependent complexity. This topology distinction is accepted.

No algorithmic OR route, diagnostic-as-proof node, or missing mathematical source paragraph was found. The graph defects concern supplier completeness and domain-facet precision, not the mathematical recoverability verdict already sealed. No proposed repair was applied or submitted. The review stops at this negative topology seal and awaits a separate release before any formal context may be read.
