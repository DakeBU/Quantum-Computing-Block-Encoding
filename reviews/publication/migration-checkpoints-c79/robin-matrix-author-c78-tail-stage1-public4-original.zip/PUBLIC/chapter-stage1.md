# A finite branch fold is not yet a prepared operator

Status: AUTHOR/WIP, local retrospective implementation-informed source recovery. This chapter is neither an independent review nor a compiler result, accepted publication, Proof Seal, or PURIFIED explanation. Historical formalizer identity is unknown. No external paper or pre-proof construction has been recovered here; references appearing inside the implementation are descriptive source strings, not inspected external evidence.

The pinned input is `QuantumBlockEncoding/RobinMatrix.lean`, SHA256 `1cca5119ac056fe041b25c529909b9fb6c3e4995e04ebde2f69e83fce47a0835`, 1,294,042 bytes and 26,985 lines. The dispatch's label “SHA1” and omitted leading `1` are corrected here to the actual raw-byte SHA256, not treated as source drift.

This stage completely reads declarations starting at line 16035 through the declaration ending at line 19708: 152 declarations, comprising 59 public declarations and 93 private helpers. The full owned tail has 334 lexically inventoried declarations; its other 182 declarations, starting with the structure at 19719, are UNREAD/WIP in this stage. The two closing namespace commands at 26983 and 26985 are also not yet body-reviewed. `coverage-stage1.json` gives the exact reviewed declaration allowlist, start/end lines and full-body hashes. The private inventory retains every owned declaration, all structure field literals, and explicit unread dispositions. Neither inventory scanning nor field extraction counts as body reading.

## 1. Objects and semantic levels

Fix the implementation parameters `oneTermParameters 3`: system width `n=3`, sparse cardinality `kappa=7`, one function piece and polynomial-degree-cost datum 1. Let `D` denote the full matrix dimension `qubitDim (oneTermRobinTotalQubits p)`, with `p=oneTermParameters 3`. Nothing below identifies all non-system bits with clean ancillas or proves that any oracle skeleton is unitary.

The coefficients form a syntax tree, not an asserted ring. Its constructors are rational constants, named symbols, binary addition, binary multiplication and negation. Write `E_e(c)` for evaluation under an arbitrary function `e : String → Rat`; evaluation interprets those constructors using rational arithmetic. The evaluation function has no built-in trigonometry, reciprocal, positivity, normalization, or square-root semantics. In particular, writing the symbol `sqrt_kappa_inv` does not make its value a square root.

There are two different equalities in this chapter:

1. `c=d` in `Coeff` is equality of syntax trees, sensitive to added zero nodes, multiplication order and parenthesization.
2. `E_e(c)=E_e(d)` is equality of rationals at a specified environment, or at all environments when universally quantified.

Evaluation can prove identities that do not hold syntactically. The stage does not convert an evaluated identity back into a `Coeff` identity.

Define seven full-index gates, in their actual multiplication order, by

\[
 U=\mathrm{indicatorOracleMatrix}(p),\quad
 T=\mathrm{sparseAmplitudeOracleDTRotationMatrix}(p),\quad
 R=\mathrm{boundaryRotationMatrix}(p),\quad
 B=\mathrm{bandedSparseAccessPaperMatrix}(p),
\]
\[
 F=\mathrm{functionOraclePaperMatrix}(p),\quad
 S=\mathrm{swapOracleMatrix}(p),\quad
 B^{\mathsf t}=\mathrm{bandedSparseAccessPaperDaggerMatrix}(p).
\]

The superscript here denotes the source's transpose-style matrix of an image skeleton. It does not assert an inverse or a unitary adjoint. The four-stage prefix and three-stage suffix are literally

\[
 P=B\bigl(R(TU)\bigr),\qquad Q=B^{\mathsf t}(SF),\qquad M=QP.
\]

These are products of `Matrix ... Coeff` using the project's finite symbolic multiplication. They are not a supplied physical circuit implementation of all advertised oracles. The exact seven-gate factors matter: preparing and unpreparing a sparse register are not factors of this displayed product.

For sparse slot `s : Fin 7`, let `b(s)` be the full-index map defined from the paper-layout expression. At this fixed parameter and system column zero it equals `16*s.val`; the selected slot 2 has full index 32. Define

\[
 a=\operatorname{symbol}(\texttt{sqrt\_kappa\_inv}),\quad w=a\cdot a,
 \qquad C_s=M_{b(s),b(s)}\cdot w.
\]

The common projection factor `w` is literally the nested symbolic product `Coeff.mul a a` (the all-slot formula at 19368 proves this by unfolding). No identity with `kappa_inv` is used in the vanishing or fold-collapse theorem.

Let

\[
 \mathcal L(C)=(((((((0+C_0)+C_1)+C_2)+C_3)+C_4)+C_5)+C_6).
\]

This denotes the literal left fold over `List.finRange 7`, initialized with `Coeff.rat 0`. It is not a `Finset.sum` using an implicit additive-commutative-monoid structure. Its mathematical evaluation can be written as a finite sum, but the expression tree is preserved in the source-level target.

## 2. Per-slot support and vanishing

For slots 1, 3, 4, 5 and 6, the implementation proves a common support mechanism, separately instantiated with exact full-basis indices. The relevant indices are:

| slot | full input `x=16s` | only prefix output rows possibly nonzero | only SWAP preimage of the even prefix row |
| --- | ---: | --- | ---: |
| 1 | 16 | 112, 113 | 14 |
| 3 | 48 | 16, 17 | 2 |
| 4 | 64 | 32, 33 | 4 |
| 5 | 80 | 80, 81 | 10 |
| 6 | 96 | 48, 49 | 6 |

Here “possibly nonzero” is only a support bound, not a nonvanishing assertion. Each row of this table has an independent complete proof body in the reviewed region; it is not extrapolation from a finite test of one slot.

To reconstruct one row, choose its even input `x`, even prefix-output `y`, and SWAP preimage `z`.

First, the system bits of `x` are zero, so the indicator oracle fixes `x`. Its column is syntactically zero away from row `x`. The sparse-amplitude rotation has indicator bit zero on this column and acts as the identity, hence also has a syntactically singleton supported column. For every output row `i≠x`, every intermediate product path in `TU` therefore contains a zero factor. The product is shown zero *after evaluation*.

Second, the boundary rotation preserves every bit except ancilla bit zero. Its column at `x` has no syntactic support outside `x,x+1`. Multiplying this with the preceding supported column shows that `R(TU)` is evaluated-zero outside those two rows. The forward sparse-image matrix maps `x` to `y` and `x+1` to `y+1`; therefore `P[:,x]` is evaluated-zero outside `y,y+1`.

Third, the SWAP image is self-inverse. If a term contributes to row `y` of `SF`, its intermediate index must be `z=swapImage(y)`. At that intermediate row the function-oracle matrix is syntactically zero for each of columns `y,y+1` in the concrete instance. Thus `(SF)[y,y]` and `(SF)[y,y+1]` evaluate to zero. The transpose-style sparse-image matrix has row `x` supported only at column `y`, so `Q[x,y]` and `Q[x,y+1]` evaluate to zero.

Finally,

\[
 E_e(M_{x,x})=E_e\!\left(\sum_q Q_{x,q}P_{q,x}\right)=0.
\]

For `q=y` or `q=y+1`, the suffix factor evaluates to zero. For every other `q`, the prefix factor evaluates to zero. This argument has an essential AND-tail: both the prefix-support theorem and the suffix-vanishing theorem are required. Neither alone proves the diagonal entry zero. Intermediate indices are universally quantified over `Fin D`; the proof does not inspect just one chosen path.

The source proofs use a general all-paths-zero matrix-product evaluation lemma, symbolic unfolding, finite index inequalities and concrete oracle-entry calculations. Some local finite calculations and index equalities are discharged by `native_decide` in the source. No Lean execution or simulator was run in this authoring task, and those source proof commands are not relabelled as fresh compiler evidence.

Slot 0 is handled by identifying its contribution with `M[0,0]*w` and using the earlier column-zero evaluation theorem. That feeder is a necessary prefix dependency, not an extra hypothesis of the tail theorem; its body is outside this stage's ownership. Slots 1, 3, 4, 5 and 6 use the support mechanism above. Thus the reviewed public conclusions are literally

\[
 \forall e:\mathrm{String}\to\mathbb Q,\quad
 E_e(C_s)=0\qquad(s\in\{0,1,3,4,5,6\}).
\]

No nonzero/positivity/normalization/environment hypothesis occurs. The private support lemmas do have output-index exclusions, exactly the one-row or two-row complements described above; those are support antecedents discharged by the final case split, not assumptions left on the public vanishing theorem.

The fixed-index abbreviations are literal `Fin D` values with their finite-bound proofs. They do not introduce physical register-state assumptions. Exact private helper names and ranges are retained in the coverage inventory.

## 3. What the fold theorem proves

The generic local fold lemma at 17765 takes an arbitrary environment `e`, an arbitrary family `c : Fin 7 → Coeff`, and six separate antecedents:

\[
 E_e(c_0)=E_e(c_1)=E_e(c_3)=E_e(c_4)=E_e(c_5)=E_e(c_6)=0.
\]

These are shorthand here for six individual equalities, not one chained equality used as a source replacement. Unfold the left fold, evaluate its additions, and remove six rational zeros. This yields `E_e(L(c))=E_e(c_2)`. No statement about the sum or any matrix entry is an input beyond those six antecedents.

The concrete theorem at 17790 supplies all six antecedents from the vanishing declarations and then rewrites `C_2` to the selected contribution. Consequently

\[
 \boxed{\forall e,\quad E_e(\mathcal L(C))=E_e(C_2).}
\]

At the syntactic level, the separate theorems at 17841 and 17872 expose the full seven-term nested expression. The second expands the full indices to `0,16,32,48,64,80,96`. These syntactic expansions are exact; the syntactic assertion `L(C)=C_2` is not proved here.

Most importantly, the head of the boxed theorem is a fold-to-selected-contribution identity. It does **not** say that the raw clean-index entry `M[0,0]`, a prepared sandwich entry, or a normalized block entry equals that fold. Membership of slot 2 in `List.finRange 7` is also proved separately at 19183. Membership plus a selected contribution formula still does not identify the fold with an operator entry.

## 4. The precise remaining projection proposition

Let `t` be the focused `BlockExtractionBranchContributionTarget` constructed at 18019. It records the finite extraction target for `oneTermRobinFiniteBlockCompositionContract 3`, system row and column zero, the family `C`, selected slot 2 and cached selected contribution, branch sum and block entry. Its equality fields identify each cache with the recorded expression. Its three semantic obligations—backend provenance, selected-branch correctness and branch-summation correctness—are `SemanticObligation` data with `proved=false` in this instance.

The record's `selectedBranchStatement` is the equality between its cached selected contribution and the family at its selected slot. This follows from its stored equality field. Separately, 18078 identifies that cached contribution with the focused selected-slot contribution. These are not projection-summation theorems.

Write `A` for the focused raw signal-zero full-unitary entry, and `B_0` for the corresponding extracted block entry. The reviewed bridges identify the local obstruction's signal entry with `t.blockEntry` and identify that same signal entry with `A`. They give exact equivalences between the following syntactic propositions:

\[
 t.\mathrm{backendExpansionStatement}
 \ \Longleftrightarrow\
 t.\mathrm{projectionSummationStatement}
 \ \Longleftrightarrow\
 B_0=\mathcal L(C)
 \ \Longleftrightarrow\
 A=\mathcal L(C).
\]

The local predicate defined in the prefix at 15240 is exactly the conjunction

\[
 (C_2=\text{selected contribution})\ \land\
 (B_0=\mathcal L(C)).
\]

It has no hidden provenance conjunct despite the descriptive comments mentioning backend sourcing. The first conjunct is supplied by 16051; 18288 conditionally combines it with an input proof of the second. At 18505 an input proof of `t.projectionSummationStatement` supplies the second conjunct through the cache and entry bridges. At 18743 an input proof of `t.backendExpansionStatement` implies projection summation. All these are valid conditional wiring steps; none supplies the missing input. The equivalent entry formulations are representation/cache transports of one contract, not independent alternative constructions that each discharge it.

The exact unproved supplier in this reviewed slice is therefore `A=L(C)` in `Coeff`, or the corresponding equivalent block-entry proposition. There is no source-read justification in this stage for declaring that supplier true or false. Later owned declarations are still unread in this stage; their names or status strings must not be used as evidence of either conclusion.

## 5. Arbitrary preparation matrix and diagonal sandwich fold

Take an arbitrary matrix `H : Matrix 8 8 Coeff`. The clean sparse index is zero and the seven slots embed by `s ↦ s.val : Fin 8`. The implementation's “dagger” for this interface is literally transpose:

\[
 H^\mathsf t_{r,c}=H_{c,r}.
\]

No conjugation, inverse, orthogonality, unitary certificate or actual preparation circuit is present in this definition. The exact all-slot uniform-column contract at 19603 is

\[
 \mathrm{Uniform}(H)\;:\!\Longleftrightarrow\;
 \forall s:\mathrm{Fin}\,7,\quad H_{s,0}=a
 \quad\text{in Coeff syntax.}
\]

This leaves all other columns and the clean-column row 7 unconstrained. It is stronger than evaluated equality of seven entries, but much weaker than physical state preparation or a normalized/unitary matrix contract. The stage does not assume a function on rational environments satisfying this contract is a physical circuit.

Define the diagonal sandwich *contribution* and its fold by

\[
 D_s(H)=M_{b(s),b(s)}\cdot\bigl(H_{s,0}H^\mathsf t_{0,s}\bigr),
 \qquad \mathcal D(H)=\mathcal L(D(H)).
\]

These definitions select the branch-diagonal entries. They do not themselves define the full double sum for an arbitrary lifted matrix sandwich. Under `Uniform(H)`, transpose gives `H^t[0,s]=H[s,0]=a`; substituting twice proves `D_s(H)=C_s` syntactically. Function extensionality then proves `D(H)=C` and hence `Dcal(H)=L(C)` syntactically. No matrix multiplication distributivity, no cross-term cancellation and no physical circuit realization are used in these proofs.

The conditional theorem at 19690 has the complete AND-tail

\[
 H:\mathrm{Matrix}\,8\,8\,\mathrm{Coeff}
 \quad\land\quad\mathrm{Uniform}(H)
 \quad\land\quad\bigl(A=\mathcal D(H)\bigr),
\]

where the matrix is carrier data and the latter two items are separate logical hypotheses. Its head is `A=L(C)`; the proof substitutes the assumed entry-to-diagonal-fold equality and then uses the uniform-column specialization. It is not a proof of `A=Dcal(H)`. Dropping that hypothesis would erase the principal operator bridge. Replacing `H` with a supplied physical sparse-preparation circuit would require a further supplier, not a change of terminology.

## 6. Structure and binder audit

The seven structures in this stage are literal data interfaces:

| structure family | start line | fields | meaning of its proposition fields |
| --- | ---: | ---: | --- |
| all-slot summand formula | 18097 | 29 | no Prop field; family, cache and status data |
| branch-sum closure | 18308 | 27 | selected clause, required sum, projection and predicate propositions |
| projection-statement obstruction | 18573 | 26 | generic projection and focused sum propositions |
| expansion bridge | 18792 | 27 | expansion, projection and focused sum propositions |
| unitary-entry fold target | 19027 | 27 | expansion and unitary-entry fold propositions |
| unitary-entry fold support | 19197 | 30 | membership, selected-contribution and unitary fold propositions |
| prepared-branch expansion | 19390 | 33 | all-slot formula, unitary fold and prepared projection propositions |

Every field is preserved literally, with its own source line interval, in the private inventory. The field counts above are derived from that inventory, not reused historical counts. A `Prop`-valued field stores a proposition, not a term proving it. A `Bool` field stores status data, even when its name contains “proved” or “compiled.” A `String` field stores descriptive text or a declaration name, not a proof reference that Lean enforces. Nested target records carry the specific cache equality fields described above; those equality proofs do not prove the separate projection or provenance obligations.

Transcript theorem bodies in this stage were read fully. Their conjunctions principally verify record identities, literal strings and Boolean values. Some also include actual local propositions, such as the selected-contribution equality, selected-branch statement, fold membership, or the all-slot summand formula. Those particular conjuncts are supported by the corresponding local theorem terms; their neighboring status conjuncts do not increase the proposition's scope. Several transcripts bind earlier facts under `_h...` names and then finish by definitional equalities; such bindings are not evidence that the previous fact proves the missing matrix theorem.

The source-facing binder audit here is retrospective, not a claim of agreement with an unread paper. All data and hypotheses are classified against this literal implementation source:

| binder family | literal role | classification in this recovery |
| --- | --- | --- |
| `env : String → Rat` | arbitrary coefficient interpretation | TYPING/data, with no implicit scalar identities |
| finite output/intermediate indices | whole finite matrix carriers | TYPING/data |
| index exclusions in private support lemmas | complement of one/two-row support | explicit local SOURCE antecedents, discharged in consumers |
| six evaluated vanish hypotheses in the generic fold lemma | rational zero values | explicit local SOURCE antecedents; supplied in the concrete fold theorem |
| `hbranchSum`, `hprojection`, `hexpansion` | exact syntactic projection or expansion proposition | explicit local SOURCE antecedents; not supplied by the conditional bridges |
| arbitrary `H : Matrix 8 8 Coeff` | a matrix parameter | TYPING/data, not supplied preparation |
| `hUniform` | all seven symbolic clean-column equalities | explicit local SOURCE antecedent |
| `hPreparedBackend` | raw entry equals diagonal sandwich fold | explicit local SOURCE antecedent, still a supplier boundary |

No convenient premise has been added by this chapter to strengthen or repair a target. No “SOURCE” classification above claims that an external source assumes it. All definitions in the reviewed region are literal formula, finite-index, or record constructions, not classical-choice characterized objects or quotient representatives.

## 7. Source mechanism graph and remaining boundaries

The compact source/construction graph recovered from these bodies has the following hyperedges, each preserving its full AND-tail:

- Indicator column support + amplitude-rotation column support → evaluated two-gate prefix support.
- Two-gate support + boundary-rotation two-row support → evaluated three-gate prefix support.
- Three-gate support + both forward-image values → evaluated four-gate prefix support.
- SWAP involution and concrete preimage + both function-oracle zero entries → both evaluated `SF` entries zero.
- Transpose-style sparse-image row support + those `SF` zeros → the required suffix entries zero.
- Prefix two-row support + both suffix zeros → evaluated raw diagonal entry zero.
- Raw diagonal zero + contribution definition → evaluated slot contribution zero.
- All six vanish feeders + literal finite left fold + selected contribution identity → evaluated fold equals selected contribution.
- Cache equalities + signal-entry bridges → equivalence of block expansion, projection sum and raw-entry fold targets.
- Uniform clean column + literal transpose → every diagonal sandwich contribution equals its backend contribution.
- Equality of whole contribution families + literal fold → sandwich fold equals backend fold.
- Uniform clean column + separately supplied raw-entry/sandwich equality → raw-entry/backend-fold equality.

The first and second paths in the conditional predicate closure are the same missing proposition in equivalent target wrappers, not genuine same-contract OR routes. No independent complete operator construction is recovered as an OR alternative in this slice.

The actual Lean imports are only the three module imports at source lines 1–3: `QuantumBlockEncoding.Core`, `QuantumBlockEncoding.CircuitSemantics`, and `QuantumBlockEncoding.Examples.RobinHeat`. They are distinct from the mechanism graph just described. Exact called declaration names are recoverable from the original bodies; this work does not call a lexical name scan an elaborated proof-term dependency graph.

Still unsupplied by this stage are the raw-entry-to-prepared-diagonal-fold bridge, any full lifted preparation/sandwich operator identity, a physical implementation of `H`, normalization and reciprocal/trigonometric interpretations of free symbols, inverse/cleanup properties of the sparse-image skeleton, oracle unitarity and amplitude correctness, coherent control semantics, actual gate/query/depth/finite-bit bounds, success probabilities, amplification, normalized block correctness, and final extraction. No result here is a PDE impossibility statement or a general quantum-algorithm lower bound.

The safe compressed lesson is precise: local finite support proves that six weighted diagonal contributions vanish after rational evaluation, so their literal seven-slot fold evaluates to its selected contribution. Turning that statement into a theorem about an actual prepared full operator requires operator and preparation suppliers that the fold identity does not contain.
