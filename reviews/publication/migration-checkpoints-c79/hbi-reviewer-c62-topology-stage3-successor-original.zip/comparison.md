# Independent Stage 3 source-topology successor comparison

Verdict: `ACCEPT_SOURCE_TOPOLOGY_SUCCESSOR_ONLY` for the exact graph and coverage pinned below. This is an independent mathematical source-topology decision, not adoption of the author's `AUTHOR_PROPOSED_NOT_ACCEPTED` status as a verdict. The Stage 2 negative remains historically valid and byte-preserved; the unchanged Stage 1 source-mathematics verdict remains `RECOVERABLE_SOURCE_ONLY`.

`W` is the portable logical workspace `hermite-export-work`. This stage read exactly the ten primary files and three integrity-envelope files in the released primary allowlist. References inside those files were not followed outside that list. In particular the frozen 43-node baseline was used from this reviewer's retained derivation and the released prior-review crosswalk/seal; its original files were not reopened under the narrower Stage 3 release.

## Exact objects accepted

- Source: `W/hermite-boundary-c74-topology-author-successor/natural-source.md`, SHA256 `69f7b917b21e70ca98285530571b11668ea69333f8fdcc0cfca43b19cf898018`, the same 404-line version-2 source.
- Proposed graph: `W/hermite-boundary-c74-topology-author-successor/source-graph-v2.json`, SHA256 `c0e6f83e2eb402836a325810bf3ad3c78cee18f4e871f6d1dc426ade3b859aa0`.
- Proposed coverage: `W/hermite-boundary-c74-topology-author-successor/source-coverage.json`, SHA256 `95b198eaf46578ccbf83c154647a8020bbb36d1c8dda2f0712849a60ad6c5021`.
- Primary release seal: SHA256 `259ab1d482a98272d2bb76c90ae98d82057edff34ae85453875d01b617f24d14`, verified before its proposed mathematical content was assessed.

Acceptance is limited to these source-only objects as a representation of the literal mathematical source. It does not accept withheld rationale, metadata, lineage, publication claims, any implementation or any formal decoder.

## F1: generic suffix and source-specific finite readout now have separate suppliers

The old negative concerned source equation (10), lines 170-172, containing two different goals. The successor makes their ownership explicit:

    E06: shared-cores AND word-coordinate -> c74-free-suffix
    E07: c74-free-suffix AND injection-eval -> c74-finite-source-adapter

The first node explicitly owns only Q_w(i)=B_i^d(Phi_w(0)), with e_0 terminal and finite matrix recursion, at every natural degree d. The second owns c^(s,|w|)Q_w=P_k(x(s+J(w))), at d=2k+1 and x(s)!=0. The source-specific row formula has its own total-definition node `source:c74-injection-row`; coordinate evaluation is explicitly not yet a finite-core product.

This is the actual source derivation. Finite Q equals the Bernstein basis column, so multiplying by the literal injected row gives its Bernstein coordinate evaluation; the S3 injection identity then identifies that value with P_k. Neither tail alone supplies both steps. E07's full ancestors now include the previously missing `source:c56-injection-eval`, `source:c56-bernstein`, and `source:c56-target`, together with shared cores and literal injection. They reach the intermediate finite-readout goal, not just a later common consumer. F1 is closed without changing the source or erasing either conjunct.

The coverage explicitly assigns block 040, source lines 170-172, to BOTH new nodes. Block 039 assigns the Q recursion to the generic node, and block 041 assigns the finite-adapter explanation to the specialized node. Thus the graph's goal split is supported by the literal source text, not merely a relabeling of the old missing edge.

## F2: the traversal uses the finite readout bridge at its own goal

The successor separates total H construction from its target interpretation:

    E08: total injection-row AND generic free-suffix -> traversal-definition
    E09: traversal-definition AND finite-source-adapter AND word-coordinate
           -> interpreted traversal

H's full-node value is explicitly the finite cQ readout from source lines 189-192, rather than a substituted coordinate-only definition. At a full block, source premise (12) gives x(s)!=0 since its first integer point is inside the interval. E07 therefore applies locally. The word bound keeps the query in the block; an outside block excludes it; the partial child preserves the queried integer. At size one, non-outsideness forces fullness by integer inequalities, so the unresolved empty terminal is harmless. This proves source (13) without adding a schedule premise.

The complete traversal ancestor set now contains the finite-source-adapter, generic free-suffix and shared-core nodes missing in Stage 2. It also contains the coordinate injection and its specialized Bernstein supplier. F2 is therefore closed at the interpreted traversal goal itself, not retroactively at the exact root.

## The generic matrix adapter has not inherited the specialized premises

E10's exact tails are total injection-row, generic free-suffix, literal traversal-definition, and schedule-interface. Its consumed facets are specified: literal total row coefficients; Q's finite recursion/terminal; the finite-row H definition; and integer schedule condition (14). It does not consume E07's specialized cQ=P conclusion or E09's interpretation of H.

Its full ancestor set has nine nodes, recorded exactly in `ancestry-audit.json`. It contains no injection-eval, finite-source-adapter, interpreted traversal, grid-algebra, grid-cuts or middle-domain node. The Bernstein ancestor supplies literal beta data to the total row definition, not a nonzero-coordinate hypothesis. The restriction ancestor supplies the total formula to that row; its affine-interpretation condition u!=1 is not inherited. Shared subdivision uses fixed half restrictions, where their ordinary identities are valid independently of x.

The boundary proof is correspondingly generic: a full selected child contributes the literal cQ full-node value; an outside child contributes zero; a partial child follows the valid schedule; coefficient states never return to the boundary. Thus its boundary equality needs exactly ScheduleValid AND current-root Partial, with no x(s)!=0, positive L, (12), or target-value interpretation. At q=0 a partial root is impossible; the conditional statement has no spurious terminal case. This preserves the source's explicit separation at lines 229-235.

## F3: all-real grid algebra is a distinct supplier

`source:c74-grid-algebra` contains only N=n+1, M=2^n, h=2 pi L/2^N, p_j=-pi L+hj, hM=pi L, and p_M=0. These are literal algebra for every real L because the power-of-two denominator is nonzero. Its goal explicitly excludes h>0.

Positive grid cuts are instead derived at E02 under L>0. Their exact ceiling, C bound and strict inequalities are not ancestors of the right-tail algebra. E17's exact tails are word-coordinate AND grid-algebra, with a consumed facet that excludes cuts and positivity. Hence right-tail algebra still works at L=0 and negative L: the top Boolean factor selects the index half, and p_(M+j)=hj identifies the remaining suffix product. No public piecewise-target claim at those L is inferred. E18 separately adds the positive cuts and target endpoints to obtain the actual right sample for L>0.

This closes F3's coarse-domain ambiguity. The shorter suffix replacement still has length<=n, the full word has length n+1, and factor bounds still require nonnegative step. The source's algebra-versus-support distinction at lines 313-319 is preserved.

## F4: no imported provider used or asserted as a source supplier

The unsupported imported Euclidean provider sentence is absent from the successor's alternative-route explanation. Its replacement is supported by source lines 402-404: there is one construction, internal proof cases are not algorithmic alternatives, and the three branch outputs are required additive inputs. The graph provenance explicitly disclaims implementation/decoder/imported-provider evidence as a supplier. No external material was used to interpret, rehabilitate or replace the old unsupported fragment. F4 is closed for this successor only; the old negative artifacts are not rewritten.

## Remaining source obligations rechecked independently

The 28 nodes coarsen the 43-node independent baseline without losing substantive source regions. `node-crosswalk.tsv` records the mathematical correspondence; source provenance remains a retained nonmathematical restriction in excluded block 002. All 20 exact AND tail sets are examined in `edge-review.tsv`, including their conditions and any consumed facets. There is no algorithmic OR route or diagnostic-as-proof supplier.

1. The target still uses literal a, A, E, P and the piecewise f, with P(-1)=exp(-1), P(0)=1. No approximation, new scientific target, normalizer, pi L>1, positive n/k, or k<=n assumption is added.
2. Words remain MSB-first; phi_b is outside the suffix coordinate. Rows are input coefficient states and columns output states, giving upper-triangular S_0 and lower-triangular S_1. The stated wire-position relation is only an index convention, not an externally checked gate action.
3. Generic basis/restriction/shared/free-suffix results retain arbitrary natural d, including zero. The literal beta, injected source row and P_k finite adapter use d=2k+1. Natural-index extensions and truncated subtraction do not change the finite rows.
4. Total restriction at u=1 is not mistaken for affine semantics. Actual full middle blocks satisfy 0<=1+p_s<1+p_(s+m)<=1 and p_s<0, supplying the nonzero start; the excluded endpoint may equal the center. Polynomial injection uses s+2^q, not the last included sample.
5. Partial selected-child schedule validity remains conditional. Aligned-cut uniqueness proves the actual middle schedule at r<=n and the prefix schedule at any width. Middle validity does not need C<=M; actual root start zero does. C=M disables middle, C=0 disables left, without asserting false root partiality for either empty interval.
6. The scalar adapter retains universal equation (18) as a genuine generic premise. Complement-bit left factors and the injection at s+2^r-1 prove it for the actual left tail. Bounds on free factors and full-left injections remain qualified side conclusions, not root premises or numerical stability results.
7. E19 has all THREE actual branch readouts, direct-sum splitting, and grid cuts as required AND tails. The masks j<C, C<=j<M, M<=j partition every natural index under C<=M. Center assignment uses the endpoint identity. Initial/terminal entries and total exact contraction are unchanged.
8. E20 consumes the tagged finite-carrier facet independently of sample-value correctness. The stage/bit/input/output address definition is local to source lines 360-374. Bond size is 2k+6 and dense count is 2(n+1)(2k+6)^2, with entry K_(n-t,b). This remains a real-scalar dense address count, not a finite-bit, sparse-minimal, runtime, allocation, gate or error-complexity theorem.
9. Zero k/n, empty contractions, reversed interval predicates, off-length words, arbitrary real parameters and total division retain their stated roles. Evaluation remains total outside the semantic theorem locus; no sample identity for wrong length or L<=0 is added. No normalization, quantum action, oracle, clean workspace, postselection, amplification, QR, numerical tolerance, preprocessing, connectivity, readout, or polynomial-log-error resource claim is supplied.

## Exact coverage and release isolation

Each of the 86 block texts was read completely and matched to the unchanged source line content. Every NODE block has explicit valid graph-node assignments; every EXCLUDED block has an empty assignment list and is exactly a title, heading or provenance paragraph. The reviewer independently checked semantic appropriateness of every assignment in `block-review.tsv`, including mixed generic/specialized blocks and endpoint/scope clauses. All 28 graph nodes occur in source-block assignments.

The blocks contain 305 NODE lines and 14 nonmathematical EXCLUDED lines. The 85 listed separator lines are exactly empty and disjoint from the blocks. These exhaust all 404 lines with no overlap or missing nonempty line. This check is separate from the mathematical dependency assessment; neither the inventory nor the author's seal established acceptance by itself.

The seven released Stage 2 negative artifacts match their original pins. No old review or author file was edited. Files mentioned by released manifests but outside the exact ten-plus-three release were not opened or followed. No WITHHELD rationale/delta/map/metadata, prior author audit, Lean, formal decoder, other-track review, R repository, Git, network, compiler, tactic, simulator or child agent was used.

The stage stops after this source-only successor seal. This acceptance is not a final migration wrapper, source/formal comparison, MAIN theorem, finite-bit ROOT, PURIFIED, compilation, implementation or publication-binding verdict; those contexts remain outside this release.
