# Independent source-only reconstruction

Direction: `independent-oneboundary-Bernstein-source-mathematics`.

Input: `W/hermite-boundary-c56-author/natural-source.md`, version 2, SHA256 `69f7b917b21e70ca98285530571b11668ea69333f8fdcc0cfca43b19cf898018`. Here `W` is the logical workspace `hermite-export-work`. Source line numbers below refer to that exact input. This document was derived from the whole source before any formal comparison. No formal comparison was performed.

## 1. What is actually to be proved

For every pair of natural numbers k and n, including zero, every real L > 0, and every Boolean word w of length N = n+1, the explicitly defined real scalar contraction A(w) equals f_k(p_J(w)). There is no normalization factor. The degree is d = 2k+1, unrelated to the word width. The grid has M = 2^n, h = 2 pi L / 2^N, and p_j = -pi L + hj. Only j < 2^N is sampled by words, although the grid and cut identities are defined for every natural j.

The polynomial target is fixed literally by

    a[k,i] = sum(m=0..i) binom(k+i-m,k)/m!
    A_k(t) = sum(i=0..k) a[k,i] t^i
    E_k(t) = (1-t)^(k+1) A_k(t)
    P_k(p) = exp(-1) E_k(p+1) + E_k(-p).

The function is exp(p) below -1, P_k(p) on [-1,0], and exp(-p) above zero. Since a[k,0]=1, E_k(0)=1 and E_k(1)=0, P_k(-1)=exp(-1) and P_k(0)=1. Thus moving the zero endpoint to the right exponential branch preserves the literal target, including at zero. No Hermite approximation estimate or derivative matching theorem is needed or supplied here. [S1, lines 11-26]

The natural ceiling C = ceil_N((-1+pi L)/h) is the exact lower cut. For natural j, j < ceil_N(x) iff j < x as a real inequality, also when x <= 0. Division by h > 0 therefore proves p_j < -1 iff j < C. Separately hM=pi L proves p_M=0, and h > 0 proves p_j < 0 iff j < M. If C>M, applying the first equivalence at M would contradict p_M=0. Consequently 0<=C<=M, and the middle mask is exactly C<=j<M. Algebra rewrites the ceiling argument as M-2^N/(2 pi L); its minimum with M is redundant, not a further assumption. No rounded-pi calculation is used. [S1, lines 28-53]

## 2. Word orientation is fixed before matrix orientation

J(empty)=0 and J(bw)=b 2^|w|+J(w). Induction proves 0<=J(w)<2^|w|. The affine coordinate maps obey phi_b(t)=(b+t)/2 and Phi_bw=phi_b composed with Phi_w, with the first bit on the outside. Evaluating at zero gives Phi_w(0)=J(w)/2^|w|. Hence the first processed bit is most significant. [S2, lines 57-67]

The source states that the external flat API uses the same integer sample index with physical wire zero least significant. Under that stated convention, word position t corresponds to wire N-1-t=n-t for 0<=t<N. This is an index correspondence, not a constructed wire-swap gate. The external API convention itself is not independently checked in this source-only review and is unnecessary to the scalar identity formulated using J. [S2, lines 69-74]

## 3. Recovering the polynomial in a finite coefficient row

The Bernstein basis B_i^d(t)=binom(d,i)t^i(1-t)^(d-i) is used only at finite indices 0<=i<=d. In the double sum defining ell_r, all i+v<=k<=d, so every binomial denominator is nonzero. Multiplying its individual term by B_(i+v)^d cancels that denominator. Summing over v yields

    t^i (1-t)^(k+1) sum(v=0..k-i) binom(k-i,v)t^v(1-t)^(k-i-v)
      = t^i (1-t)^(k+1).

Thus ell is the degree-d Bernstein row of E_k. Reflection gives the row beta_r=exp(-1)ell_r+ell_(d-r) for exp(-1)E_k(t)+E_k(1-t)=P_k(t-1). This proves equation (4) for all real t. Truncated subtraction outside 0..d defines extra beta entries but none are used by the finite adapter. [S3, lines 78-105]

For a natural-index sequence c, repeated D_z gives

    (D_z^q c)_0 = sum(j=0..q) binom(q,j)(1-z)^(q-j) z^j c_j.

One may prove the left-restriction identity by substituting this expression into the degree-d Bernstein sum and interchanging the finite sums: L_z(c) represents c's polynomial at zt. Reflecting finite indices yields that R_u(c) represents it at u+(1-u)t. Applying L_((v-u)/(1-u)) after R_u therefore represents it at u+(v-u)t, provided u != 1. The cancellation of 1-u is the only restriction on u,v; no interval inclusion is needed. The formula is still total at u=1 under x/0=0 but that total formula is not generally affine restriction there. All internal sequence accesses needed for a finite output use indices <=d, including the reflected sequence; its total continuation causes no finite-row contamination. [S3, lines 107-129]

For x(j)=a+gj, the injected row c^(s,q) restricts beta from u=1+x(s) to v=1+x(s+2^q). At t=J(w)/2^q, the restricted argument minus one is

    x(s)+(x(s+2^q)-x(s)) J(w)/2^q = x(s+J(w)).

The needed condition is x(s)!=0, equivalent to u!=1. The endpoint s+2^q is excluded from the block of samples but is the correct affine endpoint. Replacing it with s+2^q-1 would change the polynomial readout. [S3, lines 131-141]

## 4. Finite shared matrices, not an assumed adapter

Rows are input coefficient indices and columns are output coefficient indices. Expanding D_(1/2)^j on the coefficient unit vector gives S_0(i,j)=binom(j,i)/2^j for i<=j, zero otherwise. Reflection gives S_1(i,j)=binom(d-j,i-j)/2^(d-j) for j<=i, zero otherwise. Accordingly S_0 is upper triangular and S_1 lower triangular, and a coefficient row transforms as c -> c S_b. These matrices are not their coefficient-column transposes. [S4, lines 145-159]

The resulting polynomial identity is sum_j S_b(i,j)B_j^d(t)=B_i^d(phi_b(t)). Since B_i^d(0)=[i=0], the terminal e_0 and recursion Q_bw(i)=sum_j S_b(i,j)Q_w(j) give, by induction,

    Q_w(i)=B_i^d(Phi_w(0)).

The nesting matches the word definition: S_b acts before the suffix contraction and phi_b acts outside Phi_w. Pairing with c^(s,|w|) now proves the polynomial sample adapter when x(s)!=0. All sums have exactly d+1 terms. The shared identity works also for d=0; only the Hermite beta specialization fixes d=2k+1. [S4, lines 160-175]

## 5. What the one-boundary construction actually requires

For a natural block [s,s+m), fullness is l<=s and s+m<=u; outsideness is s+m<=l or u<=s. Partiality is the conjunction of their negations. These predicates are total for reversed endpoints and zero m. Traversal, however, only uses m=2^q>0. [S5, lines 179-192]

Define the full-node readout as c^(s,|w|)Q_w without yet replacing it by a polynomial. H(s,w) tests full first, then outside, then follows the selected child s+b2^|v| for w=bv. A full block contains s and every s+J(w); (12), quantified over natural j in [l,u), gives x(s)!=0. The finite adapter then identifies its row readout with the target. An outside block contains no queried index; the child preserves s+J(w). At q=0, non-outsideness implies s+1>l and u>s, so integrality gives l<=s and s+1<=u, namely fullness. There is no size-one partial case, even for reversed l,u. This proves (13) under (12), rather than assuming (13). [S5, lines 193-209]

The schedule interface is exactly (14): for each r<q and Boolean b, a partial selected child j_(r,b)=s_(r+1)+b2^r must equal s_r. It does not say all nodes at a depth are scheduled, nor that any full or outside child equals s_r. [S5, lines 211-217]

The middle core has one boundary state plus d+1 coefficient states. Its boundary-to-boundary entry is [T], boundary-to-coefficient row is [F] c^(j,r), coefficient-to-boundary column is zero, and coefficient block is S_b. The terminal boundary value is zero. Once injected, a coefficient state can never return to the boundary. Its readout is Q_w. From the boundary, equality with H(s_q,w) requires BOTH schedule validity and root partiality. For a selected full child the injection followed by Q_v is exactly the full-node row readout; an outside child has both indicators zero; a partial child uses schedule validity to continue at s_r. This adapter does not need (12): that condition is only used later to identify H as the polynomial target. [S5, lines 219-235]

The actual schedule is s_r=2^r floor(C/2^r). Its selected children are aligned size-2^r blocks. For an aligned positive block size D and aligned interval upper endpoint DB, partiality gives start < lower < start+D: non-outsideness gives start<DB, alignment forces start+D<=DB, and failure of fullness then puts the lower cut strictly inside. Thus its start is D floor(lower/D). This also works if the interval endpoints are reversed, in which case no partial block can satisfy incompatible bounds. For [0,u), partiality instead puts u strictly inside the block and gives start=D floor(u/D). [S5, lines 237-253]

For the middle interval [C,2^n), r<n+1 implies r<=n, so 2^r divides its upper endpoint 2^n. The lower-cut argument proves schedule validity, without needing C<=M. For the left interval [0,C), the upper-cut argument proves schedule validity at any width. Actual root identities additionally use C<=M<2^(n+1): s_(n+1)=0. The middle root is never full and is partial exactly in the enabled case C<M. At C=M the initial middle boundary coefficient is zero, rather than making a false root-partiality claim. [S5, lines 243-262]

A positive full middle block has C<=s<s+m<=M. The grid cuts give p_s>=-1, while s<M gives p_s<0. Monotonicity and the excluded endpoint give p_s<p_(s+m)<=0. Therefore 0<=1+p_s<1+p_(s+m)<=1; the left restriction parameter is strictly below one, although the right parameter is allowed to equal one. This supplies (12) on the actual middle interval and the restriction denominator condition exactly where used. [S5, lines 263-270]

## 6. Both tail readouts are constructed

The scalar analogue of the one-boundary core replaces the coefficient block with one free state and a level/bit factor gamma(r,b). Its terminal is one. Free contractions are U(empty)=1, U(bw)=gamma(|w|,b)U(w). The same schedule/root-partiality proof equates boundary contraction with scalar traversal. Only to identify this traversal with a masked z must one add the genuine generic premise I(s,|w|)U(w)=z(s+J(w)) for all natural s and all words w. This is not an unproved final-target premise. [S6, lines 274-287]

For the left tail, gamma(r,1)=1 and gamma(r,0)=exp(-h2^r). The number 2^q-1-J(w) is a nonnegative integer by the word bound. At w=bv, q=r+1, its value is (1-b)2^r+(2^r-1-J(v)). Induction proves

    U_left(w)=exp(-h(2^|w|-1-J(w))).

The injection exp(p_s+h(2^r-1)) is exp(p_(s+2^r-1)), with a legitimate last included natural index since 2^r>=1. Multiplication cancels the offset and proves the generic premise with z(j)=exp(p_j), for every s,w. The prefix schedule is already valid. If C>0, root [0,2^N) is partial for [0,C); if C=0 its initial boundary coefficient is zero. The left output is therefore [J(w)<C]exp(p_J(w)). [S6, lines 289-301]

If h>=0, the left free factors lie in (0,1]. A full left block ends at an included index <C; on the actual positive grid its last point is below -1, so the injection is in (0,exp(-1)), hence in [0,1]. These bounds concern factors and enabled full-block injections. They are not a numerical-error theorem, not bounds on every unused total injection, and not extra root premises. [S6, lines 301-304]

The right branch requires only one state. Its unrestricted factors are 1 for zero and exp(-h2^r) for one, giving exp(-hJ(w)). Replace the factor at level r=n with the Boolean bit itself. For |w|<=n that replacement is never encountered. For a full word bv of length n+1, b=0 annihilates the branch; b=1 leaves exp(-hJ(v)). Since J(bv)=M+J(v) and p_(M+J(v))=hJ(v), this is [M<=J(bv)]exp(-p_J(bv)). The cancellation uses hM=pi L and works for arbitrary real L; positivity is needed only for grid-support interpretation. All right factors, including the Boolean gate, are in [0,1] when h>=0. [S6, lines 306-319]

## 7. Assembly and exact cost tier

The ordered tagged bond is left boundary/free, followed by middle boundary/coefficient, followed by right. The full kernel is block diagonal; cross-branch entries are literally zero. Initial entries are [C!=0] at left boundary, [C!=M] at middle boundary, one at right, zero elsewhere. Terminals are (0,1), (0,e_0), and 1, respectively. Recursion (21) processes the first bit with level |suffix|, not with its left-to-right position t. [S7, lines 323-346]

Induction on word length splits the full contraction as the sum of the three branch contractions. At the prescribed width the derived outputs are

    [j<C] exp(p_j)
      + [C<=j<M] P_k(p_j)
      + [M<=j] exp(-p_j).

The three masks are mutually exclusive and jointly exhaustive for natural j because C<=M. Their sum equals f_k(p_j) by the cut equivalences and P_k(0)=1. Both tails and the middle are required AND dependencies of this identity, not alternative preparations. Disabled branches are multiplied by zero in an exact real contraction of total quantities; the argument does not require cancellation of large unsupported values. [S7, lines 348-358]

The middle dimension is 1+(d+1)=2k+3, so total bond dimension is 2+(2k+3)+1=2k+6. A dense core address has t in 0..n, a Boolean, an input bond index, and an output bond index. Therefore its exact cardinality is 2(n+1)(2k+6)^2. At stage t it stores K_(n-t,b), agreeing with the MSB-first recurrence. This counts dense real scalar addresses only; it is independent of proving the sample identity and does not count vectors, finite-bit representation, minimal sparse storage, runtime, circuit gates, or error-dependent resources. [S7, lines 360-374]

## 8. Total definitions and genuine edge cases

All sums and bond sets used in contractions are finite. Natural subtraction is truncated. Division by zero is assigned zero. Recursion shortens words. Thus total coefficient and contraction definitions do not imply their semantic theorem for arbitrary inputs. Correct grid semantics are only asserted for L>0 and |w|=n+1. Conditions (12), (14), root partiality and (18) have separate generic roles and are supplied by the actual construction, not added as public hypotheses. [S8, lines 378-387]

For k=0, d=1, E_0(t)=1-t and beta=(exp(-1),1), giving P_0(p)=exp(-1)(-p)+(1+p). Nothing requires a positive k or k<=n. For n=0 there are exactly two samples j=0,1, M=1 and C in {0,1}. At j=1 the right gate returns one. At j=0 the middle returns P_k(-pi L) if pi L<=1 (C=0), and the left returns exp(-pi L) if pi L>1 (C=1). At pi L=1 the middle's value at -1 equals exp(-1), as required. These are algebraic edge checks, not a finite-family substitute for the general proof. Empty left and middle branches are handled by zero initial entries. [S1, S5-S8]

No normalization is present; normalizing would require the norm of the complete sample. No unitary, isometry, circuit, oracle, postselection, amplification, numerical tolerance, finite-bit bound, preprocessing bound, gate/depth/connectivity/readout cost, or polynomial-in-log(1/epsilon) resource theorem follows from this source. Those are explicitly outside the claim rather than missing premises of equation (22). [S8, lines 389-404]

## Source-only conclusion

The standalone source supports its stated exact, unnormalized scalar-contraction identity and its separate dense-real-address count. I found no mathematical contradiction or unresolved ambiguity that blocks that precise claim. This conclusion is a source-level mathematical review of the stated formulas and proof sketches, with independently filled derivations above. It does not attest to any Lean statement, implementation, historical publication binding, compile result, ROOT/finite-bit result, or PURIFIED construction.
