# Source-only findings

Verdict: `RECOVERABLE_SOURCE_ONLY`.

The exact version-2 source supports equation (22) for all natural k,n (zero included), every real L>0, and every Boolean word of length n+1, with the literal source target and no normalization. It separately supports equation (23) as a dense real-scalar address count. No blocking mathematical invalidity or target-changing ambiguity was found.

## Checks that materially affect the result

1. **Restriction is conditional; totality is not semantics.** Equation (6) needs u!=1. Actual middle full blocks supply x(s)=p_s<0, hence u=1+p_s<1. The allowed right endpoint v=1 causes no problem. Generic total formulas at u=1 are not used as affine restriction. [107-141, 263-270]
2. **The finite adapter is derived.** Degree elevation, reflection, de Casteljau expansion and finite row-update matrices jointly prove the coefficient-to-sample identity. It is not a target/core hypothesis. Input rows and output columns give upper-triangular S_0 and lower-triangular S_1. The first word bit is outermost in affine composition and is processed first in matrix contraction. [78-175]
3. **One boundary needs an actual schedule.** Equation (14) is conditional on a selected child's partiality, and the adapter also needs root partiality. Dyadic alignment proves the actual middle and prefix schedules. Root-start zero uses C<=M, although middle schedule validity itself does not. C=M disables the middle; C=0 disables the left. [211-270, 289-304]
4. **The two tails are necessary AND branches.** The left injection uses the last included point s+2^r-1, whereas polynomial restriction uses the excluded endpoint s+2^r. Their roles must not be interchanged. Left complement-bit factors prove (18). The right top-bit gate removes the usual high-bit exponential factor, yielding the exp(-p_j) branch exactly. Neither is an alternative algorithmic route. [131-141, 274-319, 352-358]
5. **Masks and endpoints are exact.** The natural ceiling is not numerical ceiling of an approximation. The source assigns j=C to the middle (when C<M), j=M to the right, and p=0 has matching value one. No assumption pi L>1, n>=1, or k<=n was introduced. [11-53, 389-393]
6. **The cost tier is deliberately narrow.** The 2(n+1)(2k+6)^2 figure is exactly a dense address cardinality in real scalars. It is not a finite-bit, algorithmic allocation, normalized state, or circuit resource theorem. Stable tail-factor bounds do not certify floating-point stability. [301-319, 360-404]

## Scope limitations, not mathematical defects

- The input labels itself retrospective local AUTHOR/WIP source recovered from implementation, historical formalizer UNKNOWN. Nothing in this review establishes an original-paper or pre-proof provenance.
- The source's external flat-API/wire convention is a declared contextual fact. It was not checked against any implementation. The source's scalar J-index theorem does not require such an external check.
- Source proof sketches omit routine algebraic expansions and induction detail; `reconstruction.md` supplies those steps without changing any target or assumption.
- No finite mathematical experiment was run. Algebraic k=0 and n=0 checks in the reconstruction are deductions from the same source formulas and are not evidence for arbitrary families by enumeration.
- No Lean, formal decoder, previous review, author sibling, repository R, compiler, native tactic, simulator, external source, network resource, or child agent was used. Thus this verdict cannot be promoted to formal-fidelity, compile, publication-binding, finite-bit ROOT, or PURIFIED approval.

No additional source clarification was necessary. No correction to the source was requested or made.
