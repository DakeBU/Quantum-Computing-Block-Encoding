# RobinMatrix: local retrospective source, bounded checkpoint 1

## S0. Status and exact scientific boundary

This is implementation-informed, retrospective LOCAL mathematical source recovery by an AUTHOR. It is not a prior Statement Seal, an independent extraction/review, a paper-proof reproduction, a historical authorship claim, a compilation result, or whole-module publication evidence. Historical formalizer: UNKNOWN. The whole-module objective is still open.

The fixed subject is `R/QuantumBlockEncoding/RobinMatrix.lean`, raw SHA-256 `1cca5119ac056fe041b25c529909b9fb6c3e4995e04ebde2f69e83fce47a0835`. Fresh statement/body reading covers lines 1–5379. There are 108 complete declarations in that prefix. The remaining 569 declarations, beginning with `OneTermRobinGamma3IndicatorProjectionConvention` at line 5380, are retained but NOT freshly semantically recovered. Retaining all 677 declarations, 69 structures, 114 private declarations and all 11 ambient regions is a lossless continuation aid, not a whole-module audit. The raw file has 26985 nonempty-or-empty physical line records plus a terminal newline; the old inventory's split convention counts a final empty element as line 26986.

The source below explains the read prefix only. Later corrected-angle, complete finite-support, prepared-sandwich, counterexample, and conditional-final-interface families are explicit unread debt. No statement here concludes those later results from their names. The original author checkpoint's selected later-body calculations are a roadmap, not fresh semantic credit.

## S1. Coefficient syntax, evaluation and finite matrices

`Coeff` is a free expression datatype, not a quotient by rational-ring identities. A coefficient is a rational literal, an arbitrary named symbol, an addition, multiplication or negation node. An environment is an arbitrary function from symbol strings to rational numbers; evaluation interprets those constructors recursively. In particular `N_D_inv`, trigonometric-looking symbol names and square-root-looking symbol names acquire no inverse, angle or norm law merely from their spelling. Structural equality of coefficients is stronger and different from equality after an environment evaluation.

The local matrix type is a function on finite row and column labels. Matrix multiplication is the literal increasing-finite-label fold, initially zero, of `A[i,k]*B[k,j]`. Gate-list evaluation folds chronological gates by multiplying each new gate matrix on the left, starting with the literal identity. This retains a free expression tree, including zero and identity terms. Algebraic simplifications in rational evaluation are not free-syntax equalities. The fully read `Core` and `CircuitSemantics` provider bodies establish the evaluation/fold, zero-support, unique-path and two-path rational identities under their explicit support conditions; they do not license dropping those conditions in a later circuit theorem.

Drill-down: target lines 21–36, 96–110, 252–295; full provider `Core.lean`; full provider `CircuitSemantics.lean`. The provider support proofs split the finite sum into surviving labels, use list distinctness for unique/two-label cases, and evaluate before applying rational algebra. No analytic complex-unitary theorem is hidden in this rational expression model.

## S2. Literal Robin matrix and row scaling

For a list of stencil entries, the coefficient at row i and column j keeps precisely entries whose signed integer offset satisfies `Int(i)+offset=Int(j)`. No matches gives the literal rational zero; one match gives its coefficient unchanged; multiple matches are added by a nonempty fold. There is no modular wrap in this stencil lookup. Row selection first tests the left boundary `i<lower`; then the right boundary `i>upper`; otherwise it chooses bulk. Missing boundary-list rows return an empty list, hence a zero coefficient. These are total definitions for every natural n, not a guarantee that a small grid is a valid discretization.

Here N=2^n, lower=2, upper=N−3 with natural subtraction. The bulk offsets −2,−1,0,1,2 have coefficients −1/12,4/3,−5/2,4/3,−1/12. Let a denote the free symbol `A1*dx`, b the free symbol `B1*dx`. The four literal boundary rows are:

| row choice | offsets | coefficients in that order |
| --- | --- | --- |
| left 0 | 0,1,2 | −5/2+(7/3)a, 8/3, −1/6 |
| left 1 | −1,0,1,2 | 4/3−a/6, −31/12, 4/3, −1/12 |
| right N−2 | −2,−1,0,1 | −1/12, 4/3, −31/12, 4/3+b/6 |
| right N−1 | −2,−1,0 | −1/6, 8/3, −5/2−(7/3)b |

This defines D. The target named Ak is ROW-scaled: `Ak[i,j]=f(n,i)*D[i,j]`, where f is the provider's named coefficient for row i. It is not column scaling and is not a proved analytic multiplication operator. The derivative-only spec uses D, whereas the circuit extraction target uses Ak. The parameter instance is n free, kappa=7, one function piece and polynomial-degree cost 1. No new size hypothesis is added to the total definitions.

Drill-down: target lines 21–95, 117–158, 204–241; full provider `Examples/RobinHeat.lean`. These literal stencil data have been read. Their PDE/ghost-elimination justification has not been reconstructed or independently authenticated here.

## S3. The norm name and resource tiers

`matrixRowAbsSum(env,A,i)` sums absolute values of the evaluated rational entries across columns. `matrixOneNorm` takes the MAXIMUM of these ROW sums, starting at zero. Despite its name and source comments it is not the standard maximum-column-sum matrix 1-norm. The numeric normalizer is `nD*nF*k`, where nD is this actual maximum-row-sum quantity. The normalizer-bound function is an executable Boolean comparison; its use at a zero environment is not an arbitrary-environment spectral or column-norm theorem.

The block-spec normalizer is the free expression `(N_D*N_f)*kappa`; the error field is literal zero. The numeric resource data are polynomialDegreeCost*n*clog2(n)+kappa*n and pure ancilla count 2n. The derivative-oracle resource records n−1 pure ancillas using natural subtraction. These are literal resource formulas and consistency equalities, not a derivation of expanded oracle gates or returned physical workspace.

The provider has distinct tiers: the unresolved seven-label circuit score charges the placeholder SWAP and unresolved oracle calls; symbolic asymptotic expressions record the claimed gate shape; the theorem data carry a `gatesBound` String and the 2n budget. None proves the implemented prepared circuit's Ry/CX count or a physical workspace bound. Later such bodies remain unread. Every resource-bound assumption used by a later conditional statement must still be recovered; it cannot be replaced by these data equalities.

Drill-down: target lines 96–203, 823–861; actual GHL provider lines 49–152, 166–285. Visible ket workspace is `(n−clog2(kappa))+1`, a different quantity from the 2n theorem budget. The circuit backend's projection includes every non-system wire, not merely the theorem's signal count.

## S4. Concrete backend versus data wrappers

The active backend is the ordered seven-gate list: indicator, O_DT^S, boundary rotation, sparse access, O_f, SWAP, transpose-style sparse dagger. Each has an actual coefficient matrix even though a provider name contains “Placeholders”. Gate-list evaluation fixes the concrete expression matrix. Its recorded `unitary.proved` flags are `[true,false,false,false,false,true,false]`; these Boolean flags are not proofs of unitarity. A historical provider comment saying all matrices are identities is not used as a definition.

The provider separately records a theorem-facing ten-label transcript with sparse preparation on both sides, explicit indicator dagger and a pre-SWAP transposed sparse-access label. That label list does not replace the seven-gate active backend. Later prepared matrix constructions are distinct objects requiring their own body reading. A counterexample to one exact H-free raw backend contract cannot refute an unexamined prepared sandwich, a PDE, or the original paper algorithm.

`SemanticObligation` and GHL `ObligationRecord` have a description String, source String and Boolean `proved` defaulting to false. The source Strings, Bool flags, source anchors and transcript equalities are ordinary data. A theorem asserting that a flag is false proves that data equality, not that the corresponding mathematical assertion is false. Conversely a flag true is not a mathematical unitarity witness. Actual structure fields of equality/Prop type remain real premises or certificates and are not collapsed into these flags.

The circuit semantics structure really supplies its product-matrix equality and gate-list match. The block extraction target stores a matrix, its projected submatrix, Ak, the normalizer and obligation data. The claim and finite-composition contract store target/layout/coherence equalities plus still-false semantic obligations. The proof route packages these same objects with exact matching proofs, source Strings and scope data. The constructor and transcript theorems are predominantly definitional reduction and conjunction assembly. They do not supply a normalized projected-entry equality simply by naming it.

Drill-down: target lines 242–861, 899–1075, 1614–1871, 2422–2616, 2829–3621; full provider `CircuitSemantics.lean`; actual GHL lines 321–549, 568–706, 770–845. Unread transitive provider bodies are explicitly supplier gaps in the checkpoint topology.

## S5. Dimensions and the zero-signal block

For free n, the concrete register partition has m_f=clog2(n)+clog2(1)+3 high function-work wires, one indicator, three sparse-slot wires, n−3 padded wires (natural subtraction), n system wires and one trailing ancilla. Its total is defined as the sum of the fields; no negative width is inserted. Effective signal count is total minus `clog2(2^n)`. The arithmetic proof uses `clog2(2^n)=n`, derives effectiveSignal+n=total, and factors powers of two to cast the square matrix into signal-times-system dimensions.

The theorem signal field is clog2(n)+clog2(1)+clog2(7)+4. Effective signal equals that field plus the visible padded workspace plus one trailing ancilla. The backend extraction fixes signal index zero. Its compound row is `signalIndex*N+i`, and column similarly; hence the zero-signal block selects full labels i,j, not 2i,2j. The dimension proof is an internal prerequisite; the generic claim constructor also exposes a dimension-compatibility proof binder with its explicit default. It is not a new public physical assumption.

Drill-down: target lines 267–358, 610–679, 823–898, 2711–2828, 3283–3421. All casts and actual projection formulas are retained in the declaration audit; merely identifying a submatrix proves no equality to Ak divided by its normalizer.

## S6. Single-gate entry facts and their complete guards

For a clean O_f entry, choose arbitrary finite full labels `ofRow,ofCol`. The guards are that the provider image of ofCol has clean workspace and ofRow equals its clean-branch basis index. Then the actual fifth gate entry is its named normalized function amplitude. This is a conditional branch identity, not the external function-oracle theorem, a full unitary completion, or an assertion about arbitrary dirty columns.

For O_DT^S choose odtsRow,odtsCol. Its extracted column registers must have indicator 1 and trailing ancilla 0; `odtsRow >> 1` must equal the column's non-ancilla value; and its low bit must be zero. The second gate's actual entry is the provider ket-zero coefficient. The proof unfolds the gate matrix and applies exactly those register tests. The displayed normalized coefficient is free syntax; division, inverse, bound, squared-norm, square-root and 2x2-unitarity obligations remain data flags false.

For the boundary gate choose ryRow,ryCol with the same non-ancilla preservation and low-bit-zero conditions, but column indicator 0 and trailing ancilla 0. The third gate entry is its named cosine-half symbol. The arccos argument is the provider normalized coefficient by definition; this does NOT establish an angle identity or evaluated coefficient law. The proof converts low-bit zero to the modular bit test and simplifies the matrix definition. O_DT^S and boundary routes share the same source coefficient/N_D/bound-obligation objects, not a proved analytic normalization.

These six full labels are independent binders in the ledger. The source parameter `source` used for cleanup and the free row/sparse/ofColumn metadata do not silently connect them into one coherent chronological path. Their complete guard list is retained in every exact declaration header. No new final theorem premise is manufactured to make them align.

Drill-down: target lines 1076–1613, 3622–3844, 3982–4211. GHL gate-entry and analytic-contract definitions are pinned but not all their transitive derivations are freshly read; this checkpoint does not claim provider semantic closure.

## S7. Restricted sparse cleanup, with the domain expanded

Decode a compound basis label z: the trailing ancilla is bit 0; the n-bit system row is bits `[1,1+n)`; the n-bit sparse-address register is `[1+n,1+2n)`. Inside that register the low `n−clog2(kappa)` bits are padding, the remaining sparse slice has width clog2(kappa). The active source predicate means BOTH padding=0 AND the decoded sparse slot s<kappa. With kappa=7, encoded slot 7 is not in the domain, even though it fits three bits. Boundary slots with zero coefficient are not deleted from this index domain.

The literal offset table, modulo N, is `(N−2,N−1,0,1,2,N−3,3)` for slots 0 through 6; all other slots return offset 0. The address is `(offset(s)+row) mod N`. The image replaces only the sparse-address register by this address, retaining low ancilla/system bits and high bits. The forward matrix entry is one exactly at that image, zero otherwise. Its “dagger” is the transpose-style indicator `1` exactly when its column is the forward image of its row; no complex adjoint or full inverse theorem is inferred from the name.

SWAP exchanges the two n-bit blocks via their XOR difference, preserving all other bits. The candidate preimage for the post-SWAP image keeps its row and high bits and writes a clean padded sparse value with inverse slot table `(4,3,2,1,0,6,5)`; the fallback is 2. Candidate checks test image agreement, padding cleanliness and address range. These formulas are actual definitions, not an abstract cleanup oracle.

For n≥3 and a finite active-domain source, the route supplies finite post and pre labels, with post the swap of the forward source image, pre the named candidate, and a real `BandedSparseAccessPostSwapCleanup` certificate. Its fields are: post-SWAP equality, preimage equality, clean preimage, n-bit address bound, dagger entry one, row-preservation/address-written/address-in-range/no-spill Boolean equalities, and exact decoded row/address equalities. The stronger route also supplies uniqueness among OTHER ACTIVE SOURCES and a dagger-column formula restricted to those sources: entry one at pre, zero at each different active-source row.

The proof chain specializes the actual GHL generic theorem to kappa=7 and width=3, uses global-source inverse-on-range/injectivity/candidate facts, then converts chosen and off-candidate cases into an if-then-else indicator. Those actual GHL theorem statements and the final assembly bodies have been read; not all earlier provider proofs have. The topology records this transitive digestion gap rather than asserting a fresh independent proof of it.

No conclusion ranges over all dirty rows, every clean unused slot, or the full Hilbert space. The unused-clean extension has no proposed image in the inspected route. All full-clean/full-space promotion, unitary-extension and final extraction flags remain false data. Native finite regressions distinguish the rejected row-dependent collision model from the active global-slot image, and distinguish active column 8 from a legacy helper. They are finite observations, not a family unitarity theorem.

Drill-down: target lines 1872–2421; actual GHL definitions at 897–943, 1890–1916, 1983–2039, 2406–2430, 3525–3564, 5426–5432, 5555–5577, 6274–6280, 6572–6574, 6865–6888, 7419–7482; final restricted suppliers at 7883–8051. Earlier supplier proofs remain a named context debt.

## S8. What the gamma3 chain proves, and what it does not

The gamma1/2/3 structures cache kappa, window endpoints, N, named normalizers and remainder flags; the default gamma3 normalizer is `(N_D*N_f)*kappa`, its remainder flag true, visible pure wires n−clog2(kappa)+1. A transcript theorem recovers those exact fields; it is not a vector/state evolution theorem.

The route builds a full gate-contract ledger by AND-combining: source/gate/normalizer metadata; the branch-guarded O_f, O_DT^S and boundary entries; restricted sparse cleanup; actual target/projection cache equalities; and the untouched false flag ledger. Closure packets add layout/resource equality data and translate these objects into a finite-composition contract. The proof bodies destruct conjunctions, rewrite cached identities and reassemble all terms. This explains the long repeated statements without treating them as new coefficient computations.

The gamma3 target entry is Ak[i,j]=f(n,i)*D[i,j]. The actual projected block is the cast finite seven-gate product entry at the zero-signal labels. Both sides are individually identified. The product-to-coefficient equality is deliberately NOT concluded in the read prefix. A separate `SemanticObligation` records that missing equation with proved=false. The named “exact theorem interface” is still a data/interface theorem, not the exact block-encoding theorem suggested by an informal abbreviation of its name.

Drill-down: target lines 2617–4416. Complete supplier AND tails for this bounded chain are recorded in `source-topology-checkpoint.json`; import edges are a separate view. No OR alternative is asserted for these different types of facts.

## S9. The n=3 index/path audits

The auxiliary “paper basis” index is `B(s,j)=(s << (1+n+(n−clog2(kappa))))+(j << 1)`. At n=3, s=0 and system labels (2,5), this gives (4,10), whereas the generic zero-signal projection gives (2,5). Both arithmetic facts are fixed; no basis permutation is silently inserted.

The read native finite statements then inspect adjacent states, NOT a full folded product theorem. From clean column 10, indicator gives 138; the ket-zero derivative branch stays there, sparse image gives 186, function clean branch stays at 186, SWAP gives 214, and the named dagger preimage is 198, not row 4. The system row after SWAP is 3. For the desired source column 5 and address row 2, slot 5 (offset −3 modulo 8), not slot 0, is selected. Without indicator, `90 -> 42 -> 84` is the simple sparse/SWAP alignment.

The actual seven-gate ket-zero slot-5 path is `90 -> 218 -> 218 -> 218 -> 170 -> 170 -> 212 -> 228`. The derivative ket-one companion passes 219,171,213,229. Dagger entries at (228,212) and (229,213) are one, but at the clean requested endpoints (84,212) and (85,213) are zero. Final 228 and clean 84 agree in system row 2, padding 0, ancilla 0 and clean function workspace; they differ in indicator (1 versus 0) and sparse slot (6 versus 5). The Boolean audit explicitly checks these fields. Its proof command is `native_decide`; it has been read, not run here.

The decision record stores those endpoint/mismatch Strings, a required-convention obligation default false, and search-blocked data. The next convention record selects the String “sparse-register summation”, range String “s = 0..kappa-1”, and Boolean true for selection. Its separate field `indicatorMismatchHandledBySummation` is false and the indicator convention obligation is false. A chosen label/range does not prove that the current block projection performs a coherent sparse-register sum, nor that summing removes the indicator mismatch.

These observations are NOT an impossibility proof for every projection convention or every prepared construction. They expose exactly which path/index identification this local attempt has not supplied. Later declarations may establish different or conditional contracts; they remain unread and are not pre-judged by this checkpoint.

Drill-down: target lines 4417–5379, including all fields/default instances and transcript proof bodies in that range. The next unread structure begins at line 5380.

## S10. Continuation order and publication stop line

Continue at the indicator-projection convention structure, then read its downstream field/slot-summation interfaces before support-isolation and corrected-angle/evaluated-environment families. Only after those chains should the raw fold, actual prepared sandwich, target identities, evaluated counterexample and conditional projection/feeders be related. The mechanism roadmap is not evidence that those bodies have already been understood.

The full inventory gives exact retained text, body/header boundaries, hashes and lexical field/default starts for every declaration. Binder classifications in the read prefix distinguish data labels, size/index guards, branch/equality hypotheses, dimension defaults and internal proof ingredients. Unread binder groups retain their exact text with semantic classification pending. Generic conditional factor/environment/target predicates after the reading boundary are NOT expanded or waived. The prospective eleven-field record is WIP only and cannot support whole-module publication. Independent source-only review, whole formal decoding, historical attribution, import/TCB/native trust review and source fidelity remain unassessed. No decoder/reviewer acceptance, source catalogue mutation, production binding, scientific ROOT or purification is claimed.
