# C320: SOURCE-FIRST primitiveRepresentation baseline

Internal source-only baseline, frozen BEFORE author/proof/runtime release.
No C298/C305 proof, consumer, derivation or manifest; no C303/C309 output;
no other review packet was opened. Parent-reported C309 pass is metadata only.

## First-exposure and role audit

No prior direct C269 literal-definition or C298/C305 root-source read is found
in retained history; this task is the first direct exposure to that literal root.
Prior roles include allocated degree/setup cost authorship; middle/same-run
internal source/static/runtime work; explicit producer definitions/values,
decoder probes/forensics and allocated polynomial ledger authorship (C311).
General rational algebra, charged qDiv and Hermite source code were already
seen. This is narrow independence from the selected root authors, NOT a fresh
universal decoder or context-free mathematical reviewer. C311 was not reopened,
reviewed or changed. Other unproved specification bodies occur in the allowed
Definitions file; they are not proofs or dependencies assumed by this baseline.

## EXACT third root

For EVERY op:Operation and x,y:Rat, let w=rawWitness op x y and
r=operationValue op x y. The five conclusions, in order, are:
(1)0<w.denominator; (2)witnessValue w=r; (3)r.den divides w.denominator;
(4)r.num.natAbs<=w.numerator.natAbs; (5)height r<=witnessWidth w.
There is NO sign, nonzero-divisor, common-denominator, normalization or
correctness hypothesis. Rat's canonical denominator positivity/reducedness
comes from the actual Rat structure, not an added public oracle.
height=max1(max(size |num|)(size den)); sign encoding is a separate bit.

## Branch reconstruction from literal source

Write a=x.num, u=x.den>0, b=y.num, v=y.den>0.

| op/case | Raw numerator N | Natural denominator D | Positivity and value |
|---|---|---|---|
| add | av+bu | uv | u,v>0; common-denominator addition |
| sub | av-bu | uv | u,v>0; same signed subtraction identity |
| mul | ab | uv | u,v>0; product of represented fractions |
| div,b=0 | 0 | 1 | D>0; b=0 implies y=0; total x/0=0 |
| div,b>0 | av | u*natAbs b | natAbs b=b>0; x/y=av/(ub) |
| div,b<0 | -(av) | u*natAbs b | natAbs b=-b>0; (-av)/(u*(-b))=av/(ub) |

Division's outer test is b=0; only its ELSE branch splits b<0 or b>0.
Thus no zero signed denominator is used as a positive witness. x=0 and
negative x require no special hypothesis. Denominator positivity is DERIVED
for every row, never presumed to justify the conclusion being audited.
Value bridges are actual Rat.num_divInt_den/intCast_div_eq_divInt,
add_def/sub_def/mul_def, and div_def' plus signed divInt normalization.
The supplied pair is mathematically unreduced; cancellation is allowed.

## One positive-pair argument supplies conclusions3--5

Given any N:Int,D:Nat with D>0 and r=(N:Rat)/(D:Rat), the actual cast/divInt
bridge gives r=N/.(D:Int). Rat.num_den_mk (D!=0) supplies c:Int with
N=c*r.num and (D:Int)=c*(r.den:Int). As r.den>0 and D>0, c>0.
Consequently C=natAbs c>=1, D=C*r.den and natAbs N=C*natAbs(r.num).
This gives r.den|D, r.den<=D and natAbs(r.num)<=natAbs N.
Apply actual Nat.size_le_size to both magnitude bounds, then monotonicity
of max and the same max1 baseline: height r<=witnessWidth(N,D).
Coprimality is already the canonical Rat invariant used inside that primary
library factorization theorem. No generic witness-correctness premise is
added to primitiveRepresentation: N,D are the literal row just derived.

Crucial zero/cancellation edge: num_dvd ALONE would not prove a magnitude
cap when N=0. The COMMON factor with positive D does: r=0 has num0,den1,
C=D, and height0=1<=witnessWidth(0,D). In the explicit divisor-zero row
w=(0,1), every conclusion holds with equality where applicable. Additive
cancellation, zero products and zero numerator/nonzero divisor are covered too.
The argument does not use HeightBoundSpec, CommonDenominatorSpec or
PrimitiveWidthSpec as an assumption.

## Primary evidence, unknowns and scope

Read actual Lean4.33 Rat structure, normalize/divInt and signed inv/div,
add/sub/mul definitions and semantic bridges; primary Mathlib num_den_mk,
den_dvd/num_dvd, casts; actual Nat.size monotonicity. Manifest binds exact
files/read ranges. Initial toolchain inventory listed old-version PATH NAMES
only; no old-version body was read or used. Only4.33 bodies support this audit.
Native add/sub use gcd-optimized denominators and mul cross-cancels: rawWitness
is NOT asserted to be an evaluator's literal temporary trace.

This source derivation supports the five mathematical clauses; no selected
author proof or own consumer was inspected, and no new Lean proof/gate ran.
No known source-level counterexample or missing public premise was identified.
Lean elaboration, actual proof dependence/axioms, loader and source-to-binary
association remain unreviewed. This is NOT source-publication/ProofSeal/ROOT.

Clause5 does NOT bound witnessWidth by input heights (that is another root).
No bound on all rawIntegers, GCD/normalization scratch, signed encoding,
native/Rat/CPU/allocator/runtime, Sites/source-suffix/producer coverage or
producer bit cost follows. No physical quantum resource/scientific credit.
Only new report/manifest/seal via apply_patch; no compiler, scripts, Python,
Git, network, subagents or old edits. Freeze and STOP before author release.
