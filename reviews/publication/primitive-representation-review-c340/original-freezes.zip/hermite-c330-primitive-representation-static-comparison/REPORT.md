# C330: primitiveRepresentation STATIC comparison

Outcome: no source-level defect or extra public premise identified in the
selected C305 proof. This is static comparison, NOT Lean/kernel acceptance,
an ordinary-axiom output verdict, or source-to-binary/runtime association.

## Exposure and phase boundaries

C320 was frozen before this first selected-author-proof exposure; its report,
manifest and seal are unchanged. Prior roles: allocated degree/setup author;
middle/same-run internal source/static/runtime work; explicit producer VALUE,
decoder probes/forensics and C311 allocated polynomial cost author. General
Rat algebra and charged rational producers were already seen. Independence
is selective from this root's authors, not a fresh universal decoder. C311
was NOT opened, rehashed, reviewed or changed. Parent-reported C309 pass
metadata was known; no C303/C309 output or other reviewer result was read.

Initial requested AUTHOR_FREEZE_SEAL.json was absent. Filename-only inventory
reported AUTHOR_FREEZE.json; parent separately authorized that actual file.
Only it and the two correctly named C305 Lean files were then read whole.
C305 derivation/manifest/diff and C298 author material remain unopened.

## Exact third root and assumptions

C305 PrimitiveRepresentationProof.lean:39 has the exact sealed closed
PrimitiveRepresentationSpec, then unfolds and introduces only op,x,y.
For w=rawWitness op x y and r=operationValue op x y, all five clauses remain:
positive natural denominator; witness value=r; r.den divides raw denominator;
r.num.natAbs<=raw numerator.natAbs; height r<=witnessWidth w.
No sign/nonzero/cache/oracle/normalization or other unproved C280 root premise
is added. Private witnessReduction:10 assumes raw denominator positivity
locally; the public proof derives and supplies it for the actual witness.

## Literal branches and signed total division

Write a=x.num,u=x.den>0,b=y.num,v=y.den>0.
Add/sub/mul retain (av+bu,uv), (av-bu,uv), (ab,uv).
Source:44-46 derives uv>0 from actual Rat.pos; :60-76 proves the values
using add_num_den (sub via x+(-y)) and mul_eq_mkRat/mkRat_eq_divInt.
Division b=0 uses exactly (0,1), proves y=0, and total x/0=0 (:48-49,78-81).
Otherwise :50-57 derives natAbs b>0 from b!=0, so u*natAbs b>0.
For b<0 the raw pair is (-av,u*natAbs b); :83-87 replaces natAbs b by -b.
The PRIMARY Rat.divInt_neg is n/.-d=(-n)/.d, so the two minuses cancel
to av/.(u*b), exactly Rat.div_def'. For b>=0,b!=0, :88-91 uses natAbs b=b.
All signs of a and x=0 remain unrestricted; no signed denominator is
mistaken for the positive natural witness denominator.

## Canonical reduction: different valid route from C320

C320 derived a COMMON positive canonical scaling factor with num_den_mk.
C305 :14-24 instead casts the positive raw D to nonzero Int and invokes
actual Rat.den_dvd and Rat.num_dvd. Denominator divisibility transports
back to Nat. At :30, Nat.le_of_dvd needs D>0, already supplied locally.

Crucially, C305 does NOT use num_dvd alone across raw N=0:
:26-28 first proves witnessValue=0 and canonical num=0. Only N!=0
uses Int.natAbs_le_of_dvd_ne_zero :29. Its actual primary signature is
m|n -> n!=0 -> natAbs m<=natAbs n; its proof was read. Thus cancellation
to zero, zero products and a zero numerator over a nonzero divisor are
covered without a new public premise. This alternate argument supplies
the same magnitude consequences as C320's common-positive-factor route.
:31-34 applies Nat.size_le_size to both bounds and max monotonicity with
the same baseline1. :92-94 rewrites by the proved actual value and assembles
the five clauses in sealed order. No PrimitiveWidthSpec/input-height bound.

## Consumer and static file association

ExactChecks.lean:6-27 expands every selected project function body:
four operations, both division tests, (0,1), casts, both max1 sizes and
all five conjuncts. It directly consumes the named public theorem.
The inherited namespace C298ExactChecks adds no assumption or authority.
Its check/axiom commands :29-32 are SOURCE, not inspected runtime output.

All16 C320 input hashes still match; both C320 payloads match their seal.
Both authorized C305 Lean files match AUTHOR_FREEZE.json, whose preproof
seal reference matches actual C280. The other three listed payload hashes,
predecessor-byte/diff assertions and freeze status are NOT independently
verified: their contents/predecessors were not released. Exact pins and
read scopes are in input-manifest.json; direct reads are not a loader/TCB closure.

## Residual boundary and handoff

Source comparison supports the five mathematical clauses; no new proof,
compiler, Python, project script, Git, network, subagent or old edit occurred.
Actual elaboration/kernel, type/axiom output, dependency/import resolution
and own-output consumer association remain UNKNOWN in this review phase.
Not native/GCD scratch, evaluator temporaries, Sites/producer occurrence or
bit-cost, CPU/allocation/runtime, physical gates, full scientific ROOT,
publication/ProofSeal or PURIFIED. Failure class: NONE at selected source
level; runtime NOT ASSESSED. Freeze STOP for parent intake; runtime requires
separate authorization. C320 and all predecessor packets remain immutable.
