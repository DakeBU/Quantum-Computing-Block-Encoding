# C334: recorded primitiveRepresentation runtime association

Assessment: the inspected C309 records consistently associate the selected
C305 source with its own proof output and an exact own-output consumer,
one public root and TWO ordinary-three axiom rows. This is recorded-run
association, NOT an independent rerun or clean/transitive-TCB certification.

## Exposure and immutable phases

C320 source-first and C330 static packets retain their exact frozen hashes.
Prior roles/exposure remain as disclosed there: allocated degree/setup,
middle/same-run work, explicit producer VALUE/probes/forensics, and C311 cost
author. C311 was not opened or reviewed. First selected author proof read
was the separately released C330; actual C309 outputs are first read now.
Narrow selected-root independence, not a fresh universal scientific decoder.
No C305 prose/manifest/diff, C303 runtime or other worker/review packet opened.

Inventory confirmed actual wrapper run-c309-primitive-representation-syntax-gate.py.
An earlier combined read still attempted the original authorized guessed
-successor-gate name: missing path only, no body read or mutation.
Parent then explicitly authorized the actual wrapper. Its whole body,
plan/result/two feedbacks and all TEN raw ZIP members were read; ZIP only
in memory, no extraction. Private locations are not reproduced here.

## Source, executable and output bindings

Current runner hash matches recorded runner_sha256. C309 current source
hashes match C305, its author freeze, plan/result and C330 static intake:
proof 88e40ca2...; consumer 77d743ef....
Current executable SHA256 equals recorded dd86e9b2...; this pins lean.exe,
NOT its DLLs, full compiler/runtime or transitive library closure.
Current C278 Definitions.olean is a0a6a6ab..., matching C280/plan/result.
All three selected direct Mathlib provider hashes also match plan/result.
Current proof output ebf25188... and consumer output 5f3d95ba... match
their recorded own_output hashes. Exact full hashes/lengths are in manifest.
Current-file equality corroborates records, not historical process replay.
The wrapper's broader pre/post source-pin verification is reported by the
result; unexposed author manifests and all those sources were NOT re-audited.

## Actual recorded command and resolution scope

The preserved wrapper constructs, for each module:
`lean.exe -M 3072 -j 1 --root=<OWN> -o <OWN>/<module>.olean <OWN>/<module>.lean`
with repository cwd, 120s timeout, >=5120MiB available-memory precondition.
Plan describes 3072MiB Lean memory option +2048MiB reserve, one thread.
Result records exits0/no timeout, available6969/6809MiB and wrapper elapsed
18.531/16.625s (not independent timings or an efficiency benchmark).
Command argv is reconstructed from preserved runner, not a separate OS trace.

LEAN_PATH is explicitly set atop inherited os.environ: OWN then C278 typed
definitions, then an inherited30-entry total path with duplicates and mixed
staging/cache/project/package/toolchain routes. This is not a clean environment.
Separate --deps invocations precede compile. Raw proof --deps selects C278
Definitions and the three expected direct Mathlib modules, plus duplicated
Init. Consumer --deps selects this OWN PrimitiveRepresentationProof.olean,
plus Init. All deps stderr streams are empty. These are direct-query outputs,
NOT a loader trace or recursive imported-source/olean verification.

## Full streams, expanded type and axiom evidence

All four compile stdout/stderr hashes match result. Proof stdout/stderr are
zero bytes; its feedback is just newline. The source has no axiom queries:
source zero rows is NOT an empty-axiom proof or independent axiom coverage.
Consumer raw stdout1919bytes was read WHOLE (not bounded feedback only).
Both feedback files equal wrapper-style path-normalized full raw streams.
A proposition-as-def linter warning remains; its suggested disabling is not
an applied setting. Consumer prints the closed root type and expanded
literal forall op,x,y: add/sub/mul, signed division with zero pair(0,1),
positive denominator, value equality, denominator divisibility, numerator
magnitude cap and max1 Nat.size height cap. This matches C280/C320/C330;
no extra sign/nonzero/oracle premise appears in the printed consumer type.
There is NO printed theorem proof body or full definition/dependency dump.

Exactly two named rows occur: HermiteRationalHeight.primitiveRepresentation
and C298ExactChecks.primitiveRepresentationExpandedCheck, each
[propext, Classical.choice, Quot.sound]. No sorryAx/new axiom is shown.
They cover ONE public root via an expanded own consumer, not two new roots.
Result reports1 own-consumed root and the matching output hash. Raw streams,
exact static consumer and direct own-provider query support that focused
recorded claim; the imported parser/transport helpers were not inspected.
Old schema labels containing heightBound do not substitute another target.

## Limits and STOP

No compiler, Python/project script, Git, network, subagent or old edit.
No independent rerun, full environment capture, loader trace, recursive TCB,
binary/source reconstruction, proof-body print, publication/ProofSeal/PURIFIED.
Not PrimitiveWidth, rawIntegers/Sites/producer coverage, native/GCD scratch,
evaluator/CPU/allocation/bit cost, quantum resources or scientific ROOT.
No discrepancy identified within the released recorded scope; larger claims
remain unverified. Freeze STOP for parent intake, with prior packets unchanged.
