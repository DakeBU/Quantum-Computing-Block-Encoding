param(
  [Parameter(Mandatory = $true)][string]$R,
  [Parameter(Mandatory = $true)][string]$A,
  [string]$Pins = (Join-Path $PSScriptRoot 'input-pins.json')
)
$ErrorActionPreference = 'Stop'
$record = Get-Content -LiteralPath $Pins -Raw -Encoding UTF8 | ConvertFrom-Json
$roots = @{ R = [IO.Path]::GetFullPath($R); A = [IO.Path]::GetFullPath($A) }
$failures = @()
foreach ($inputPin in $record.inputs) {
  if (-not $roots.ContainsKey($inputPin.root)) { throw 'Unknown input root key' }
  $inputRoot = $roots[$inputPin.root]
  $absoluteInput = [IO.Path]::GetFullPath((Join-Path $inputRoot $inputPin.path))
  $rootPrefix = $inputRoot.TrimEnd([char]92,[char]47) + [IO.Path]::DirectorySeparatorChar
  if (-not $absoluteInput.StartsWith($rootPrefix,[StringComparison]::OrdinalIgnoreCase)) {
    throw ('Input escapes supplied root: ' + $inputPin.path)
  }
  $actual = (Get-FileHash -LiteralPath $absoluteInput -Algorithm SHA256).Hash.ToLower()
  if ($actual -ne $inputPin.own_pre_sha256 -or
      $actual -ne $inputPin.own_post_sha256 -or
      $actual -ne $inputPin.own_final_sha256) {
    $failures += ($inputPin.root + '/' + $inputPin.path)
  }
}
if ($failures.Count -gt 0) {
  $failures | ForEach-Object { Write-Output ('DRIFT: ' + $_) }
  exit 1
}
Write-Output ('Stable input hashes: ' + $record.inputs.Count)

