# Independent formal-only reconstruction: nine bounded modules

Decoder identity: `robin_nine_formal_decoder_c45`.
Direction fingerprint: `robin-nine-formal-register-phase-context`.
Expected information gain: independent whole-target semantics with explicit physical-register, phase, logical-guard and provider-adequacy boundaries.

This is a source-blind decoding artifact, not a source-fidelity verdict, compilation report, publication admission, or Proof Seal. Statements below reconstruct what the supplied definitions and theorem bodies say. No Lean build, native execution, simulator, network access, Git operation, source-paper reading, natural-contract reading, author comparison, registry write, or child agent occurred. Original Lean identifiers and formal String values were retained, so this run is formal-only, not identity-blind.

All nine targets were read through EOF. All 37 authorized provider projections were read through EOF. The inventory was independently constructed from those target files before any author comparison: 215 explicit declarations, including the private `transportInput_eq_encode`. No full provider snapshot expansion was needed or performed. In particular, the full RobinMatrix module was not read or admitted: only its supplied projection, with the 14 explicit provider declarations and ambient regions listed in formal extent metadata, was read.

## Common mathematical conventions

Let `PrimitiveBasis q = Fin q → Fin 2`. A basis state is the complete assignment of every physical wire, not a natural-number ket with an inferred ordering. The little-endian equivalence puts wire0 at weight1, wire1 at2, etc.; the six-wire theorem explicitly fixes weights1,2,4,8,16,32. A matrix entry is output row / input column. A permutation matrix is1 exactly when row=permutation(column), otherwise0.

Primitive circuits execute list head first, so `eval(left ++ right)=eval(right)*eval(left)`. Programs additionally carry `exp(i*angle.eval)`; program sequential composition adds phase angles and dagger negates them. X and CX are full-basis permutations. `Ry(θ)` is
`[[cos(θ/2),-sin(θ/2)],[sin(θ/2),cos(θ/2)]]`; `Rz(θ)` has diagonal `exp(-iθ/2),exp(iθ/2)`. Thus `amplitudeRotation(a)=Ry(2acos(a))`, with its00 entry equal to a only under -1≤a≤1. Unitarity of that rotation exists for every real a, but the clean-entry identity needs the bounds. The exact-angle constructors carry explicit rational-bound proofs; they are mathematical exact-real data, not finite-bit synthesized angles.

`LCUIndex C S X = C × (S × X)`. Selector lift is `I_C⊗(P⊗I_X)`; amplitude lift is a coefficient matrix block-diagonal in(selector,system); SELECT fixes coefficient and selector and applies the supplied slot permutation to system. The assembled logical matrix has execution PREPARE, amplitude rotation, SELECT, UNPREPARE, hence matrix `P_lift† * SELECT * amplitudeLift * P_lift`. Its selected coefficient/selector entry sums
`conj(P[s,s0]) * rotation(s,j)[c0,c0] * P[s,s0]`
only over slots mapping the input system j to the output system i. Both the probability factors and the conditional system-map guard are retained. No single preparation state is treated as an arbitrary block encoding.

The fixed integer matrix B is
```text
[-30, 32, -2,  0,  0,  0,  0,  0]
[ 16,-31, 16, -1,  0,  0,  0,  0]
[ -1, 16,-30, 16, -1,  0,  0,  0]
[  0, -1, 16,-30, 16, -1,  0,  0]
[  0,  0, -1, 16,-30, 16, -1,  0]
[  0,  0,  0, -1, 16,-30, 16, -1]
[  0,  0,  0,  0, -1, 16,-31, 16]
[  0,  0,  0,  0,  0, -2, 32,-30]
```
The supplied rational target A=B/12, normalizer56/3, so its normalized block is B/224. B is centrosymmetric, not symmetric/Hermitian merely by name: B01=32 whereas B10=16. No theorem here promotes the fixed8-dimensional target to a generic-width Robin family or a general inhomogeneous parameter family.

For the seven-slot route, d(s)=(s xor3)mod8, row(s,j)=(j+d(s))mod8. Selector weights are1/7 for s<7 and0 for s=7. PaperSeven coefficients are B[row(s,j),j]/32 for s<7 and exactly1 for s=7; the zero-probability padded slot is not deleted from the full unitary. Figure4's source coefficient is instead B[row(s,j),j]/32 for every slot. Its final clean sum agrees with the padded formula because the padded selector probability is0.

For pair coordinates, system carrier is(side,pair)∈Fin2×Fin4 and original j=pair when side0, j=7−pair when side1. The cyclic-four-slot family uses(pair+slot)mod4 and its explicit plus/minus weight tables/56. The XOR family uses pair xor slot and the corresponding sector matrix lookup/56. Those are different full constructions; the legacy `warmRobinFourSlotT3FlatUnitary` alias points specifically to the XOR route. The sector basis change is H=[[c,-c],[c,c]], c=√2/2, not an unsigned Hadamard silently substituted from a label.

## Seven-slot reconstructions by mathematical family

The seven slots are target/normalization; carriers/order/basis; oracle/access/controls; ancilla/workspace/preservation; phase; error/success; resource model. Each family below has all seven populated. Exact declaration interfaces, complete written binders/typeclasses and retained proof regions are in the companion coverage JSON.

### M1: Generic reversible-to-primitive exact compiler

1. Target and normalization: Every finite-width X/CX/CCX reversible program is compiled to a primitive program whose complex matrix is exactly its permutation matrix.

2. Carriers, order and basis: q : Nat; wires : Fin q; basis Fin q → Fin 2; matrices over ℂ. Programs execute list head first, hence concatenation evaluates in reverse multiplication order.

3. Oracle/access and control guards: No oracle constructor. CX requires control≠target; CCX requires all three gate wires pairwise distinct; these proof arguments remain in the interface.

4. Ancillas, workspace and preservation: Equality holds on the whole basis, with every untouched wire preserved; there is no clean-workspace premise.

5. Phase: Exact matrix equality, not equality modulo phase. H/T/T† provider macros carry explicit global-phase compensation.

6. Error and success: No approximation, norm, probability or postselection theorem. This is a deterministic unitary refinement.

7. Resource tier: Primitive X,Ry,Rz,CX circuit plus an exact-angle global phase. No finite-bit synthesis/runtime claim; generic compiler does not assert a numeric gate-count bound here.

Declaration-by-declaration reconstruction (line numbers refer to the complete target snapshot):

- `primitiveXProgram` (line 16; public def): Build a single-X primitive program with zero explicit global phase on any target wire.

- `primitiveXProgram_eval` (line 21; public theorem): Its full complex matrix is exactly the target-bit-flip permutation matrix.

- `compileReversibleGate` (line 31; public def): Translate each reversible X,CX,CCX instruction to the corresponding exact-phase primitive macro, retaining all distinctness proof arguments.

- `compileReversibleGate_eval` (line 40; public theorem): Every translated gate has the exact permutation matrix of its reversible semantics; proof splits the three constructors.

- `compileReversibleProgram` (line 52; public def): Recursively compile a reversible instruction list by primitive sequential composition; empty list maps to identity.

- `compileReversibleProgram_eval` (line 58; public theorem): Induction on the instruction list shows exact equality between the compiled full matrix and the composed reversible permutation.

### M2: Clean three-control toggle

1. Target and normalization: Three CCX gates compute a∧b into work, toggle target under work∧c, then uncompute work.

2. Carriers, order and basis: q : Nat; a,b,c,t,w : Fin q; all states are full PrimitiveBasis q.

3. Oracle/access and control guards: The program needs a≠b,a≠w,b≠w,w≠c,w≠t,c≠t. The clean semantic theorem additionally needs a≠t,b≠t; it does not assume a≠c or b≠c.

4. Ancillas, workspace and preservation: The action theorem assumes input w=0, gives equality of the entire output state with a three-control X action, and hence restores w=0. No dirty-workspace action is asserted.

5. Phase: Compiled-program equality with the three-CCX permutation is full-matrix exact even away from the clean subspace; the three-control interpretation is clean-only.

6. Error and success: No error or postselection. The clean condition is a real logical guard, not merely a layout label.

7. Resource tier: Exactly three reversible CCX instructions before macro expansion; no separate numerical compiled count theorem in this target family.

Declaration-by-declaration reconstruction (line numbers refer to the complete target snapshot):

- `cleanC3XReversibleProgram` (line 75; public def): Construct CCX(a,b,w);CCX(w,c,t);CCX(a,b,w), with the six displayed inequalities and no hidden global pairwise-distinctness assumption.

- `cleanC3XBasisEquiv` (line 88; public def): Define its full-basis equivalence by reversible evaluation, including dirty-work inputs.

- `c3xBasisAction` (line 102; public def): Define target flip precisely when the original state has all three designated controls equal1, otherwise identity.

- `cleanC3XBasisAction` (line 109; public theorem): Under work=0 and the two additional a≠t,b≠t inequalities, the whole basis output equals c3xBasisAction; controls a,c or b,c may coincide.

- `cleanC3XWorkspaceClean` (line 143; public theorem): Under the same guards, the output work bit is0; this follows from the full clean-action equality.

- `cleanC3XPrimitiveProgram` (line 165; public def): Compile the three-CCX list; its construction needs only the six program inequalities, not the extra two clean semantic inequalities.

- `cleanC3XPrimitiveProgram_eval` (line 178; public theorem): Exact full matrix equals the cleanC3XBasisEquiv permutation matrix, without a workClean premise.

### M3: Fixed 3-bit little-endian modular addition

1. Target and normalization: For input data a and b, overwrite a by (a+b) mod 8, preserve b, restore clean workspace.

2. Carriers, order and basis: Exactly seven physical wires: a=(0,1,2), b=(3,4,5), work=6; littleEndian3Value=s0+2s1+4s2.

3. Oracle/access and control guards: No oracle. Eight reversible instructions: five CCX and three CX; wire-distinctness proofs are closed finite facts.

4. Ancillas, workspace and preservation: Semantic action assumes wire6=0 and concludes data sum plus preservation of wires3,4,5 and output6=0.

5. Phase: Compilation is exact permutation-matrix equality including phase, not just a truth-table distribution match.

6. Error and success: modularAdd3_cleanAction uses native_decide +revert over fixed finite states; workspaceClean is a projection of that theorem. No arbitrary-width adder result.

7. Resource tier: resource_faithful is definitional equality with the compiled primitive circuit resource; oracleCalls=0 is structural. No finite-bit count or asymptotic adder claim.

Declaration-by-declaration reconstruction (line numbers refer to the complete target snapshot):

- `littleEndian3Value` (line 198; public def): Interpret an arbitrary ordered triple of seven-wire bits by weights1,2,4; no distinctness of the triple is assumed by this data definition.

- `modularAdd3ReversibleProgram` (line 203; public def): Define the explicit eight-instruction seven-wire reversible circuit (five CCX,three CX).

- `modularAdd3BasisEquiv` (line 214; public def): Define its seven-wire full-basis equivalence.

- `modularAdd3_cleanAction` (line 217; public theorem): For every seven-wire input with wire6=0, data0..2 sum modulo8, wires3..5 are preserved, and wire6 returns0; native_decide +revert is fixed finite evidence.

- `modularAdd3PrimitiveProgram` (line 227; public def): Compile that fixed reversible list into a primitive program.

- `modularAdd3Primitive_eval` (line 230; public theorem): Compiled program equals the full reversible permutation matrix exactly.

- `modularAdd3Primitive_workspaceClean` (line 235; public theorem): Extract output6=0 from the clean-action conjunction; still requires input6=0.

- `modularAdd3Primitive_resource_faithful` (line 241; public theorem): Program.resource is definitionally equal to its actual primitive circuit.resource, not an independent complexity upper bound.

- `modularAdd3Primitive_oracleCalls_eq_zero` (line 245; public theorem): Actual compiled primitive program has oracleCalls=0, by the structural primitive-circuit resource theorem.

### P1: Three-wire uniform-seven selector unitary

1. Target and normalization: A specific 8×8 selector unitary P has |P(s,0)|²=1/7 for s<7 and 0 for s=7. PaddedSlot maps Fin8 to Option Fin7 and sends 7 to none.

2. Carriers, order and basis: PrimitiveBasis 3 flattened by primitiveBasisLEEquiv 3, wire0 least significant. High wire2, middle wire1 controlled by2, low wire0 controlled in order(1,2).

3. Oracle/access and control guards: No oracle. All control-target inequalities are proved for these fixed maps. ExactAngle carries bounds for arccos/sqrt constructors.

4. Ancillas, workspace and preservation: No extra work wires. Matrix and unitary theorems are whole-space; the distribution claim concerns only the zero input column.

5. Phase: Angles: high=2acos√(4/7), tail=2acos√(2/3), middle=π/2 if high=0 else tail, low=0 only if both controls=1 else π/2. Program phase=0. Probability alone does not assert a unique output phase vector.

6. Error and success: Exact column probabilities, no error tolerance and no total-variation-only substitute. Full P is defined by the ordered rotations, not characterized solely by probabilities.

7. Resource tier: Seven Ry and eight CX in the actual compiled list; oracleCalls=0. Exact-real/ideal-angle counts; no Clifford+T accuracy or preprocessing bound.

Declaration-by-declaration reconstruction (line numbers refer to the complete target snapshot):

- `warmRobinUniformSevenHighAngle` (line 17; public def): Exact bounded high angle is2acos√(4/7).

- `warmRobinUniformSevenTailAngle` (line 20; public def): Exact bounded tail angle is2acos√(2/3).

- `warmRobinUniformSevenMiddleAngles` (line 23; public def): Middle angle on a one-bit control isπ/2 if bit0=0, otherwise tail angle.

- `warmRobinUniformSevenLowAngles` (line 28; public def): Low angle on two ordered controls is0 iff both bits=1, otherwiseπ/2.

- `warmRobinUniformSevenMiddleWires` (line 33; public def): Single middle control is high wire2.

- `warmRobinUniformSevenMiddleWires_ne_target` (line 35; public theorem): Middle control is distinct from target1.

- `warmRobinUniformSevenLowWires` (line 40; public def): Low controls are wire1 then wire2.

- `warmRobinUniformSevenLowWires_ne_target` (line 44; public theorem): Both low controls differ from target0.

- `warmRobinUniformSevenPrepareCircuit` (line 48; public def): Concatenate high Ry2,middle controlledRy1,low controlledRy0 in execution order.

- `warmRobinUniformSevenPrepareProgram` (line 56; public def): Package three-wire prepare list with phase0.

- `warmRobinUniformSevenPrepareMatrix` (line 61; public def): Define full matrix lowStage*(middleStage*highStage), not only its zero column.

- `warmRobinUniformSevenPrepareProgram_eval` (line 70; public theorem): Program matrix equals that full ordered stage matrix.

- `warmRobinPaperSevenSelectorPrepare_unitary` (line 84; public theorem): That full three-wire prepare matrix is unitary.

- `warmRobinUniformSevenPrepare_noOracleCalls` (line 90; public theorem): Actual program resource has zero oracle calls.

- `warmRobinUniformSevenPrepare_counts` (line 94; public theorem): Actual prepare circuit has exactly7 Ry and8 CX instructions by the generic compiler count recurrences.

- `warmRobinPaperSevenPaddedSlot` (line 111; public def): Map Fin8 slot to some Fin7 when val<7; otherwise none.

- `warmRobinPaperSevenPaddedSlot_seven` (line 114; public theorem): Slot7 maps to none.

- `warmRobinPaperSevenSelectorPrepare` (line 119; public def): Flatten the full three-bit stage matrix to an8×8 P with little-endian equivalence.

- `warmRobinPaperSevenSelectorPrepare_unitary_flat` (line 124; public theorem): The flattened P is unitary.

- `warmRobinUniformSevenPrepare_probability` (line 134; public theorem): For every slot, conjugate(P(slot,0))*P(slot,0) is1/7 for slot<7 and0 otherwise; symbolic trigonometric proof enumerates the eight slots and retains local sqrt bounds/quarter-angle identities.

### P2: Eight-wire physical embedding of seven-selector prepare

1. Target and normalization: Physical prepare/unprepare circuits equal the reindexed selector-only lift of the same P/P†.

2. Carriers, order and basis: Eight wires: system0..2, selector3..5 little-endian, coefficient6, spectator/work7. Logical index=(coefficient,(selector,(system,work))).

3. Oracle/access and control guards: No oracle; high target5, middle target4 controlled by5, low target3 controlled in order(4,5).

4. Ancillas, workspace and preservation: Whole-matrix embedding preserves all system, coefficient and work states, including work=1. Three Context_iff theorems retain equality of every non-target wire.

5. Phase: Every stage and full circuit equality is exact over ℂ. Unprepare is reversed gate list with dagger angles, not a phase-insensitive inverse.

6. Error and success: No approximation/success parameter; native finite context/bit-decode facts support symbolic matrix proofs.

7. Resource tier: Uses the same uniformly controlled Ry compiler; this module does not prove its own aggregate resource count. No finite-bit compilation statement.

Declaration-by-declaration reconstruction (line numbers refer to the complete target snapshot):

- `warmRobinPaperSevenSelectorHighMatrix` (line 13; public def): Flatten the three-wire high Ry stage into8×8 selector matrix.

- `warmRobinPaperSevenSelectorMiddleMatrix` (line 18; public def): Flatten the three-wire one-control middle stage into8×8 selector matrix.

- `warmRobinPaperSevenSelectorLowMatrix` (line 25; public def): Flatten the three-wire two-control low stage into8×8 selector matrix.

- `warmRobinPaperSevenSelectorStages_eq_prepare` (line 31; public theorem): Low*(Middle*High) equals full selector P by multiplicativity of reindex.

- `warmRobinPaperSevenMiddlePhysicalWires` (line 43; public def): Physical middle control is wire5.

- `warmRobinPaperSevenMiddlePhysicalWires_ne_target` (line 45; public theorem): Wire5 differs from physical target4.

- `warmRobinPaperSevenLowPhysicalWires` (line 51; public def): Physical low controls are4 then5.

- `warmRobinPaperSevenLowPhysicalWires_ne_target` (line 55; public theorem): Both physical low controls differ from target3.

- `warmRobinPaperSevenSelectorBits_decode` (line 60; public theorem): Logical selector decoding recovers exactly physical wires3..5.

- `warmRobinPaperSevenHighContext_iff` (line 66; public theorem): Physical context excluding5 iff coefficient6 agrees, logical selector context excluding2 agrees and(system,spectator7) agrees.

- `warmRobinPaperSevenHighPhysical_eval` (line 82; public theorem): Ry5 high stage equals reindexed selectorLift of logical high matrix on all states.

- `warmRobinPaperSevenMiddleContext_iff` (line 116; public theorem): Physical context excluding4 iff coefficient6 agrees, logical selector context excluding1 agrees and(system,spectator7) agrees.

- `warmRobinPaperSevenMiddlePhysical_eval` (line 130; public theorem): Physical controlledRy4 middle stage equals reindexed selectorLift of logical middle matrix.

- `warmRobinPaperSevenLowContext_iff` (line 177; public theorem): Physical context excluding3 iff coefficient6 agrees, logical selector context excluding0 agrees and(system,spectator7) agrees.

- `warmRobinPaperSevenLowPhysical_eval` (line 191; public theorem): Physical controlledRy3 low stage equals reindexed selectorLift of logical low matrix.

- `warmRobinPaperSevenSelectorPrepareCircuit` (line 238; public def): Execute the three selector stages on wires5,4,3 with controls5 and(4,5).

- `warmRobinPaperSevenSelectorPrepareCircuit_eval` (line 248; public theorem): Full eight-wire circuit equals reindexed selectorLift(P), preserving arbitrary system/coefficient/spectator inputs.

- `warmRobinPaperSevenSelectorUnprepareCircuit` (line 275; public def): Define inverse list by reversal and gate dagger, keeping exact angle negations.

- `warmRobinPaperSevenSelectorUnprepareCircuit_eval` (line 278; public theorem): Full inverse circuit equals reindexed adjoint selectorLift(P).

### A1: Eight-wire controlled amplitude rotation

1. Target and normalization: Rotate coefficient wire6 by 2acos(c(s,j)), where c is integer-target weight/32 for s<7 and exactly1 for padded s=7.

2. Carriers, order and basis: System wires0..2, selector3..5, coefficient6, spectator7; six controls map identically to wires0..5; full-system carrier is Fin8×Fin2.

3. Oracle/access and control guards: No black-box amplitude oracle is assumed. The angle function is constructed from the fixed rational coefficient table and proven bounded by1.

4. Ancillas, workspace and preservation: The context equivalence includes spectator7 and preserves it for both bit values. This is full-matrix amplitudeLift equality, not only a clean-work slice.

5. Phase: Standard Ry=[cos(θ/2),−sin(θ/2);sin(θ/2),cos(θ/2)], exact 2acos angle; all signs and relative phases are retained. Global phase=0.

6. Error and success: Exact matrix equality; finite native bijectivity is a provider leaf, no numerical simulation performed. This family alone is not a full block encoding.

7. Resource tier: Six-control ideal uniformly controlled Ry program, oracleCalls=0. No target-local count theorem or gate-synthesis precision.

Declaration-by-declaration reconstruction (line numbers refer to the complete target snapshot):

- `warmRobinPaperSevenAmplitudeControlWires` (line 14; public def): Six-control wiring is identity0..5 into the eight-wire register.

- `warmRobinPaperSevenAmplitudeControlWires_ne_target` (line 17; public theorem): Each control differs from coefficient target6.

- `warmRobinPaperSevenAmplitudeSystem` (line 24; public def): Read the first three control bits as little-endian Fin8 system.

- `warmRobinPaperSevenAmplitudeSelector` (line 28; public def): Read control bits3..5 as little-endian Fin8 selector.

- `warmRobinPaperSevenAmplitudeAngle` (line 32; public def): Construct bounded ExactAngle2acos(coefficientRat(selector,system)); padded coefficient data remains1.

- `warmRobinPaperSevenAmplitudeRy_eq_rotation` (line 44; public theorem): Standard Ry of that evaluated angle is exactly the PaperSevenRotation matrix for the decoded selector/system.

- `warmRobinPaperSevenAmplitudeContextIndex` (line 58; public def): Decode all seven non-target physical bits to (selector,(system,spectator7)).

- `warmRobinPaperSevenAmplitudeContextIndex_bijective` (line 70; public theorem): Finite native bijectivity of that complete context map, including both spectator values.

- `warmRobinPaperSevenAmplitudeContextEquiv` (line 74; public def): Turn the context decoder into an equivalence.

- `warmRobinPaperSevenAmplitudeContextEquiv_apply` (line 80; public theorem): Forward context equivalence agrees definitionally with the context decoder.

- `warmRobinPaperSevenAmplitude_context_iff` (line 85; public theorem): Equality of physical non-target contexts iff equality of the logical selector/full-system context; use actual equivalence injectivity.

- `warmRobinPaperSevenControlledRy_eq_amplitudeLift` (line 100; public theorem): Full physical controlled-Ry block matrix equals reindexed amplitudeLift of WorkspaceRotation, preserving spectator7.

- `warmRobinPaperSevenAmplitudeCircuit` (line 136; public def): Compile the six-control angle table to an eight-wire primitive circuit.

- `warmRobinPaperSevenAmplitudeProgram` (line 141; public def): Package the circuit with exact phase0.

- `warmRobinPaperSevenAmplitudeProgram_eval` (line 145; public theorem): Full program equals reindexed WorkspaceRotation amplitudeLift; zero phase and compiler semantic theorem are used explicitly.

- `warmRobinPaperSevenAmplitudeProgram_noOracleCalls` (line 159; public theorem): Program resource has zero oracle calls; no complete block theorem is stated by this declaration.

### F1: Nine-wire Figure4 selector embedding

1. Target and normalization: Selector prepare/unprepare programs equal reindexed I_coefficient⊗P_selector⊗I_fullSystem and its adjoint.

2. Carriers, order and basis: Nine physical wires: selector0..2, system3..5, coefficient6, indicator7, work8. FullSystem=Fin8×(Fin2×Fin2); encode and BitsIndex are mutually inverse through a proved equivalence.

3. Oracle/access and control guards: No oracle; high target2, middle target1 controlled by2, low target0 controlled in order(1,2).

4. Ancillas, workspace and preservation: Both indicator and work are genuine spectator factors here, with arbitrary input bits. All three Context_iff statements retain coefficient, residual selector context and the entire (system,indicator,work) tuple.

5. Phase: Exact operator equalities on all512 basis states, not just selector probabilities; zero global phase and explicit dagger program.

6. Error and success: Native finite bijection/encode/decode/context facts, then symbolic lifted-matrix composition; no approximation or accepted-branch assertion.

7. Resource tier: Fixed nine-wire ideal-angle circuit. Resource model inherited from actual primitive list; no count claim stated in this target.

Declaration-by-declaration reconstruction (line numbers refer to the complete target snapshot):

- `WarmRobinFigure4FullSystem` (line 15; public abbrev): FullSystem is exactly Fin8×(Fin2×Fin2), retaining system plus indicator and work bits.

- `warmRobinFigure4EncodeBits` (line 17; public def): Encode selector in wires0..2,system in3..5,coefficient6,indicator7,work8; all three finite register components are explicit.

- `warmRobinFigure4BitsIndex` (line 30; public def): Decode all nine wires into (coefficient,(selector,(system,(indicator,work)))).

- `warmRobinFigure4BitsIndex_bijective` (line 35; public theorem): Declare finite bijectivity of the complete512-state decoding map via native_decide.

- `warmRobinFigure4BitsEquiv` (line 39; public def): Promote that bijective map to an equivalence, without changing its values.

- `warmRobinFigure4BitsEquiv_apply` (line 45; public theorem): The equivalence's forward action unfolds to the decoder.

- `warmRobinFigure4BitsEquiv_encode` (line 48; public theorem): Encoding followed by forward equivalence returns the complete coefficient/selector/full-system tuple, for all spectator values.

- `warmRobinFigure4PrepareMiddleWires` (line 57; public def): Middle-rotation control map is the single wire2.

- `warmRobinFigure4PrepareMiddleWires_ne_target` (line 59; public theorem): That sole control differs from target1.

- `warmRobinFigure4PrepareLowWires` (line 64; public def): Low-rotation control map is wire1 then wire2.

- `warmRobinFigure4PrepareLowWires_ne_target` (line 68; public theorem): Both listed controls differ from target0.

- `warmRobinFigure4SelectorBits_decode` (line 72; public theorem): Reencoding the decoded selector recovers each wire0..2.

- `warmRobinFigure4PrepareHighContext_iff` (line 78; public theorem): Equality of all non-wire2 bits iff coefficient bits agree, logical selector non-high contexts agree and whole(system,indicator,work) tuples agree.

- `warmRobinFigure4PrepareHighPhysical_eval` (line 92; public theorem): Physical Ry on wire2 exactly equals reindexed lifted logical high selector stage on the full512-dimensional space.

- `warmRobinFigure4PrepareMiddleContext_iff` (line 126; public theorem): Equality of all non-wire1 bits iff coefficient bits agree, logical selector non-middle contexts agree and whole full-system tuples agree.

- `warmRobinFigure4PrepareMiddlePhysical_eval` (line 140; public theorem): Controlled middle Ry on wire1 exactly equals the reindexed lifted middle stage; local rowControl aligns the physical and logical control assignments.

- `warmRobinFigure4PrepareLowContext_iff` (line 186; public theorem): Equality of all non-wire0 bits iff coefficient bits agree, logical selector non-low contexts agree and whole full-system tuples agree.

- `warmRobinFigure4PrepareLowPhysical_eval` (line 200; public theorem): Controlled low Ry on wire0 exactly equals reindexed lifted low stage; both logical controls are matched in the proof.

- `warmRobinFigure4SelectorPrepareCircuit` (line 246; public def): Concatenate high rotation,one-control middle compiler,two-control low compiler on the nine-wire selector register.

- `warmRobinFigure4SelectorPrepareProgram` (line 255; public def): Package that circuit with phase angle0.

- `warmRobinFigure4_after_prepare` (line 260; public theorem): The complete program matrix equals the reindexed selector lift of the fixed seven-selector P; proof composes all three stage equalities.

- `warmRobinFigure4SelectorUnprepareProgram` (line 291; public def): Define unprepare as the dagger of the exact prepare program, including its phase field.

- `warmRobinFigure4_after_unprepare` (line 294; public theorem): The complete inverse program matrix is the reindexed adjoint selector lift, not a clean-only inverse statement.

### F2: Nine-wire assembled normalized target block

1. Target and normalization: Full program=P† M P. Its selected 8×8 block equals A/(56/3)=B/224, where B is the explicit fixed integer target and A=B/12.

2. Carriers, order and basis: selector0..2, system3..5, coefficient6, indicator7, work8. Logical carrier Fin2×(Fin8×(Fin8×(Fin2×Fin2))); flat matrix512×512. Clean embedding sets selector,coefficient,indicator,work to0.

3. Oracle/access and control guards: No opaque oracle premise. M is the reindexing of the supplied compiled middle program; clean entries use s-preserving shift r=(j+(s xor3))mod8 and rotation coefficient B[r,j]/32.

4. Ancillas, workspace and preservation: AllWorkspaceClean is a basis theorem for indicator then PostLoader on the specific transport input. Middle clean-entry and final clean-block theorems keep indicator/work0. Whole eval equality specifies dirty sectors by actual M but does not identify them with a clean abstraction.

5. Phase: Exact complex matrix equality, including signs and coherent selector phases. Logical_cleanEntry sums conjugate(P[s,0])*rotation00*P[s,0], using probability1/7 and padded probability0.

6. Error and success: No approximation. Unitarity follows from the actual primitive program; projected block equality does not mean deterministic application of nonunitary A or unit success probability.

7. Resource tier: Candidate layout(system3,signal4,pure2), auxiliary6, default schedule[]. Resource is actual primitive program resource (whose pureAncilla accounting is0 by construction); no theorem identifies layout pure ancillas with resource.pureAncilla. Presentation labels erase angles, refinement retains them.

Declaration-by-declaration reconstruction (line numbers refer to the complete target snapshot):

- `transportInput_eq_encode` (line 15; private theorem): Private whole-state identity equates TransportInput(slot,system,coefficient,indicator) with EncodeBits(coefficient,slot,(system,(indicator,0))).

- `warmRobinFigure4PrimitiveProgram` (line 25; public def): Sequentially execute selector prepare,middle,then prepare dagger.

- `warmRobinFigure4AllWorkspaceClean` (line 33; public theorem): On TransportInput(slot,column,coefficient,0), applying indicator then PostLoader leaves wires7 and8 equal0; this statement does not include the loader rotation in its named basis expression.

- `warmRobinFigure4LogicalMiddle` (line 44; public def): Define logical middle by reindexing the actual nine-wire middle program, not by choosing an arbitrary matrix from a clean-block characterization.

- `warmRobinFigure4LogicalMiddle_apply` (line 51; public theorem): Logical middle entries are actual middle-program entries at inverse logical basis indices.

- `warmRobinFigure4LogicalMiddle_cleanEntry` (line 60; public theorem): On indicator/work0 rows and columns, middle is slot-diagonal, shifts system by DTRow, and has the full coefficient 2×2 rotation entry with coefficient SourceCoefficient(rightSlot,column).

- `warmRobinFigure4Primitive_eval_eq_logical` (line 97; public theorem): Full primitive program matrix equals reindex(P†*LogicalMiddle*P), where P here denotes selectorLift; no clean premise or phase quotient.

- `warmRobinFigure4Logical_cleanEntry` (line 145; public theorem): Selected coefficient0/selector0/indicator0/work0 logical entry equals SourceSevenCleanFormula; proof keeps full selector summation, native finite rational bounds, and padded slot probability0.

- `warmRobinFigure4PrimitiveFlatUnitary` (line 235; public def): Flatten full program matrix to Fin512 using primitiveBasisLEEquiv9.

- `warmRobinFigure4PrimitiveCircuit_unitary` (line 240; public theorem): Declare flat matrix unitary by primitive-program unitarity plus reindexing.

- `warmRobinFigure4PrimitiveCleanIndex` (line 246; public def): Embed a Fin8 system by TransportInput selector0,coefficient0,indicator0,work0 and little-endian flattening.

- `warmRobinFigure4PrimitiveCircuit_cleanEntry` (line 252; public theorem): At these two clean indices, flat matrix entry equals the exact complex cast of SourceSevenCleanFormula.

- `warmRobinFigure4PrimitiveCircuit_cleanBlock` (line 277; public theorem): At the same indices, entry equals complex cast of warmRobinTarget/warmRobinNormalizer.

- `warmRobinFigure4PrimitiveBlockContainsTarget` (line 286; public def): Define the proposition universally equating those flat clean entries to QueryTarget.operator/QueryTarget.normalizer.

- `warmRobinFigure4PrimitiveBlockContainsTarget_proof` (line 294; public theorem): Supply a term of that proposition from cleanBlock and the concrete QueryTarget definitions.

- `warmRobinFigure4PrimitivePresentation` (line 300; public def): Map actual primitive gates to presentation Gate constructors; retain X wire indices and Ry/Rz/CX wiring, replace each angle by String exact-angle.

- `warmRobinFigure4PrimitiveResource` (line 308; public def): Resource data is the actual primitive program resource.

- `warmRobinFigure4PrimitiveOperatorCandidate` (line 311; public def): Build an OperatorBlockEncodingCandidate with auxiliary6,layout(system3,signal4,pure2),actual matrix,presentation/resource,layoutMatches and two specified Prop fields; default schedule is[].

- `warmRobinFigure4PrimitiveRefinement` (line 328; public def): Build a PrimitiveProgramRefinement whose exact field is the full eval_eq_logical equality; it binds actual program,not presentation labels.

- `warmRobinFigure4PrimitiveVerifiedBlockEncoding` (line 343; public def): Build VerifiedOperatorBlockEncoding using the candidate and actual unitary/block proof terms.

### S1: Pair-coordinate map and cyclic-four-slot exact angles

1. Target and normalization: Two CX gates realize pair-coordinate conversion; separate exact angles realize cyclic-four-shift amplitude rotations.

2. Carriers, order and basis: System=Fin2×Fin4. Pair bits=(pair low,pair high,side) on wires0,1,2. CNOT2→1 then2→0 implements original index j=pair for side0, j=7−pair for side1.

3. Oracle/access and control guards: No oracle; the angles take the actual finite slot and sector/pair column, with an internal coefficient-bound proof.

4. Ancillas, workspace and preservation: Coordinate map is a full three-bit bijection; no workspace needed. This file contains no full six-wire assembled block-encoding theorem.

5. Phase: Angle=2acos(weight/56) for the cyclic-four-shift weights, exact standardRy equality. It is not the XOR-slot coefficient merely because both use four slots.

6. Error and success: All finite coordinates covered by fin_cases/decide; exact equality, no error or postselection.

7. Resource tier: Two logical CX for coordinate circuit; exact-angle data for rotations. No complete gate-count bound or finite-bit synthesis claim.

Declaration-by-declaration reconstruction (line numbers refer to the complete target snapshot):

- `warmRobinPairCoordinateCircuit` (line 17; public def): Coordinate conversion is CX2→1 then CX2→0 on three system bits.

- `warmRobinPairCoordinateBasisEquiv` (line 20; public def): Coordinate full-basis equivalence composes those two CX equivalences in execution order.

- `warmRobinPairCoordinateCircuit_eval_eq` (line 25; public theorem): Actual coordinate circuit evaluates to that exact permutation matrix.

- `warmRobinPairBits` (line 33; public def): Encode(sector,pair) with little-endian pair in0,1 and sector in2.

- `warmRobinOriginalBitsValue` (line 40; public def): Interpret a three-bit state as integer b0+2b1+4b2.

- `warmRobinPairCoordinateCircuit_image` (line 44; public theorem): After coordinate conversion, encoded pair bits have integer value PairSystemEquiv(sector,pair); all two-by-four cases are covered.

- `warmRobinPairCoordinateCircuit_bijective` (line 52; public theorem): Coordinate equivalence is bijective, by its Equiv structure.

- `warmRobinFourSlotExactAngle` (line 57; public def): Bounded ExactAngle is2acos(cyclicFourShiftAmplitude(sector,slot,pair)), where amplitude is weight/56.

- `warmRobinFourSlotExactAngle_eval` (line 65; public theorem): Evaluating that angle gives2acos(FourSlotCoefficient(slot,column)).

- `warmRobinFourSlotExactRy_eq_rotation` (line 71; public theorem): Standard Ry of the exact angle is precisely the corresponding cyclic FourSlotRotation.

### X1: Six-wire XOR-four-slot assembled primitive route

1. Target and normalization: Full64×64 primitive matrix equals the specific flat logical unitary, whose coefficient0/selector0 block is B/224=A/(56/3). Legacy FourSlotT3 names are definitional aliases to this XOR route.

2. Carriers, order and basis: Wires0,1=pair low/high;2=side/sector;3,4=selector low/high;5=coefficient. Middle logical carrier Fin2×(Fin4×(Fin2×Fin4)); original flat LE index theorem retains order explicitly.

3. Oracle/access and control guards: No oracle. SELECT is CX3→0 then4→1, pair xor selector, preserving side,selector,coefficient. Amplitude target5 is controlled by all wires0..4; coefficient=(sector block)[pair xor slot,pair]/56.

4. Ancillas, workspace and preservation: No pure work wires. Selector/coeff0 are projected signal conditions, not a claim that all ancillas return0 on every output. Pair-coordinate and symmetry rotations act on full system sectors.

5. Phase: Exact full operator and program equality. Selector Ryπ/2 on3,4; symmetry Ryπ/2 on2; inverse lists use dagger. Pair circuit executes symmetry†,middle,symmetry; matrix is systemLift(H)*middle*systemLift(H)†, with H=[[c,−c],[c,c]], c=√2/2.

6. Error and success: Native finite leafs cover XOR action, context equivalences, involutivity and flat-index alignment; full complex equalities are symbolic compositions. No approximation and no asserted deterministic postselection.

7. Resource tier: Amplitude circuit has32 Ry and62 CX, zero oracleCalls. Whole resource is actual circuit resource; candidate layout(system3,signal3,pure0), auxiliary3 and schedule[]. Angle labels in presentation are not semantic certificates.

Declaration-by-declaration reconstruction (line numbers refer to the complete target snapshot):

- `warmRobinXorFourSlotSelectCircuit` (line 18; public def): SELECT circuit is CX3→0 followed by CX4→1.

- `warmRobinXorFourSlotSelectBasisEquiv` (line 21; public def): Define full six-wire equivalence as the same two CX maps in order.

- `warmRobinXorFourSlotSelectBasisAction_eq_perm` (line 28; public theorem): All inputs satisfy pair-output=pair-input xor selector and preservation of wires2,3,4,5; finite native leaf.

- `warmRobinXorFourSlotSelectProgram_eval` (line 39; public theorem): Actual SELECT list is exactly the permutation matrix of that equivalence.

- `warmRobinXorFourSlotSelectProgram_noOracleCalls` (line 47; public theorem): SELECT list resource has zero oracle calls.

- `warmRobinXorFourSlotControlWires` (line 51; public def): Amplitude controls map Fin5 identically into physical wires0..4.

- `warmRobinXorFourSlotControlWires_ne_target` (line 54; public theorem): All amplitude controls differ from target5.

- `warmRobinXorFourSlotControlPair` (line 60; public def): Read control bits0,1 as little-endian pair in Fin4.

- `warmRobinXorFourSlotControlSector` (line 64; public def): Read bit2 as sector.

- `warmRobinXorFourSlotControlSelector` (line 67; public def): Read bits3,4 as little-endian Fin4 selector.

- `warmRobinXorFourSlotAmplitudeAngle` (line 72; public def): Build bounded exact angle2acos(XorAmplitude(sector,selector,pair)) from the fixed sector-block lookup/56.

- `warmRobinXorFourSlotAmplitudeAngle_eval` (line 84; public theorem): Angle evaluation is2acos of the decoded real XorFourSlotCoefficient.

- `warmRobinXorFourSlotAmplitudeRy_eq_rotation` (line 95; public theorem): Standard Ry of that angle is exactly the decoded XorFourSlotRotation.

- `warmRobinXorFourSlotContextIndex` (line 112; public def): Context decoder maps all non-target5 wires to(selector,(sector,pair)).

- `warmRobinXorFourSlotContextIndex_bijective` (line 121; public theorem): That context decoder is finite bijective by native_decide.

- `warmRobinXorFourSlotContextEquiv` (line 125; public def): Turn the context decoder into an equivalence.

- `warmRobinXorFourSlotContextEquiv_apply` (line 131; public theorem): Forward equivalence equals the decoder.

- `warmRobinXorFourSlotMiddleBitsEquiv` (line 136; public def): Split coefficient5 then decode remaining context to logical LCU index.

- `warmRobinXorFourSlotMiddleBitsEquiv_apply` (line 143; public theorem): Explicit logical index is(bits5,(bits3+2bits4,(bits2,bits0+2bits1))).

- `warmRobinXorFourSlotSelectBasisAction_middleIndex` (line 151; public theorem): SELECT physical equivalence intertwines this full logical-index equivalence with controlledSystemEquiv(XorFourSlotSystemEquiv).

- `warmRobinXorFourSlotSelectProgram_eval_reindexed` (line 172; public theorem): SELECT full matrix equals reindexed logical selectLift.

- `warmRobinXorFourSlotControlledRy_eq_amplitudeLift` (line 199; public theorem): Physical five-control Ry block equals reindexed amplitudeLift(XorFourSlotRotation); proof retains all non-target context, not just selector equality.

- `warmRobinXorFourSlotSelectorLowMatrix` (line 242; public def): Logical low selector stage is reindex(I2⊗UniformBitPrepare) under(high,low)→Fin4.

- `warmRobinXorFourSlotSelectorHighMatrix` (line 247; public def): Logical high selector stage is reindex(UniformBitPrepare⊗I2).

- `warmRobinXorFourSlotSelectorHighLow_eq_prepare` (line 252; public theorem): HighSelector*LowSelector equals the four-slot selector preparation matrix.

- `warmRobinXorFourSlotSelectorPrepareCircuit` (line 264; public def): Selector physical preparation is Ryπ/2 on3 then Ryπ/2 on4.

- `warmRobinFourSlotBitsEquiv_symm_pack` (line 267; public theorem): Packing low+2high under the inverse selector equivalence yields(high,low), retaining tensor-order convention.

- `warmRobinXorFourSlotLowContext_iff` (line 273; public theorem): Context excluding3 iff coefficient5,selector high4,sector2,and pair agree.

- `warmRobinXorFourSlotHighContext_iff` (line 282; public theorem): Context excluding4 iff coefficient5,selector low3,sector2,and pair agree.

- `warmRobinXorFourSlotSelectorLow_eval` (line 291; public theorem): Ryπ/2 on3 exactly equals reindexed selectorLift of logical low stage.

- `warmRobinXorFourSlotSelectorHigh_eval` (line 316; public theorem): Ryπ/2 on4 exactly equals reindexed selectorLift of logical high stage.

- `warmRobinXorFourSlotSelectorPrepareCircuit_eval` (line 341; public theorem): Full selector preparation list equals reindexed selectorLift(four-slot P).

- `warmRobinXorFourSlotSelectorUnprepareCircuit` (line 360; public def): Unprepare is reversed prepare list with each gate dagger.

- `warmRobinXorFourSlotSelectorUnprepareCircuit_eval` (line 363; public theorem): Full selector inverse equals reindexed adjoint selectorLift(four-slot P).

- `warmRobinXorFourSlotAmplitudeCircuit` (line 376; public def): Compile five-control amplitude angle table onto coefficient wire5.

- `warmRobinXorFourSlotAmplitudeProgram` (line 381; public def): Package amplitude list with phase0.

- `warmRobinXorFourSlotAmplitudeProgram_eval` (line 385; public theorem): Amplitude program equals the actual controlledRyBlockMatrix exactly.

- `warmRobinXorFourSlotAmplitudeCircuit_eval_reindexed` (line 398; public theorem): Amplitude circuit equals reindexed amplitudeLift(XorFourSlotRotation).

- `warmRobinXorFourSlotPrimitiveMiddleCircuit` (line 407; public def): Middle list executes selector prepare,amplitude rotation,SELECT,selector unprepare.

- `warmRobinXorFourSlotPrimitiveMiddle_eval` (line 414; public theorem): Middle full matrix equals reindexed XorFourSlotMiddleLogicalUnitary.

- `warmRobinXorFourSlotPairCoordinateCircuit` (line 431; public def): Coordinate list on six wires is CX2→1 then CX2→0, leaving remaining wires untouched.

- `warmRobinXorFourSlotPairCoordinateBasisEquiv` (line 434; public def): Coordinate full six-wire equivalence is those two CX maps in order.

- `warmRobinXorFourSlotPairCoordinateCircuit_eval` (line 439; public theorem): Coordinate list exactly evaluates to its full permutation matrix.

- `warmRobinXorFourSlotPairCoordinateBasisEquiv_involutive` (line 448; public theorem): Coordinate equivalence applied twice is identity for all six-wire inputs.

- `warmRobinXorFourSlotSymmetryContext_iff` (line 454; public theorem): Context excluding sector2 iff coefficient5,selector pair,and physical pair0,1 agree.

- `warmRobinXorFourSlotSymmetryPrepareCircuit` (line 465; public def): Symmetry prepare is a single Ryπ/2 on sector wire2.

- `warmRobinXorFourSlotSymmetryPrepareCircuit_eval` (line 468; public theorem): Symmetry prepare equals reindexed systemLift(SymmetryBasisChange), preserving coefficient,selector,pair.

- `warmRobinXorFourSlotSymmetryUnprepareCircuit` (line 494; public def): Symmetry unprepare is reversal/dagger of that single rotation.

- `warmRobinXorFourSlotSymmetryUnprepareCircuit_eval` (line 497; public theorem): Symmetry inverse equals reindexed adjoint systemLift(SymmetryBasisChange).

- `warmRobinXorFourSlotPrimitivePairCircuit` (line 511; public def): Pair-coordinate list executes symmetry unprepare,middle,symmetry prepare.

- `warmRobinXorFourSlotPrimitivePair_eval` (line 517; public theorem): Its full matrix equals reindexed PairLogicalUnitary, i.e. H*middle*H† in logical system space.

- `warmRobinXorFourSlotOriginalBitsEquiv` (line 532; public def): OriginalBitsEquiv is coordinate conversion followed by middle logical decoding.

- `warmRobinXorFourSlotPrimitiveCircuit` (line 540; public def): Full physical list is coordinate conversion,pair-coordinate list,coordinate conversion.

- `warmRobinXorFourSlotPrimitive_eval_reindexedPair` (line 545; public theorem): Full list equals reindex under OriginalBitsEquiv of PairLogicalUnitary; coordinate involutivity is a real hypothesis supplied to the provider conjugation theorem.

- `warmRobinXorFourSlotOriginalBitsEquiv_index` (line 563; public theorem): FourSlotIndexEquiv composed with OriginalBitsEquiv equals primitiveBasisLEEquiv6 on every basis input; native fixed finite alignment.

- `warmRobinXorFourSlotPrimitive_eval_eq_flatUnitary` (line 581; public theorem): Full primitive circuit equals reindexed64×64 XorFourSlotFlatUnitary in little-endian physical basis.

- `warmRobinXorFourSlotPrimitiveProgram` (line 603; public def): Package full six-wire circuit with phase0.

- `warmRobinXorFourSlotPrimitiveProgram_eval` (line 607; public theorem): Full program equals that same exact reindexed flat unitary.

- `warmRobinXorFourSlotPrimitiveCleanIndex` (line 620; public def): Physical clean embedding is inverse little-endian flattening of FourSlotCleanIndex(system).

- `warmRobinXorFourSlotPrimitive_cleanBlock` (line 625; public theorem): At the physical clean indices, circuit entries equal complex cast of A/(56/3).

- `warmRobinXorFourSlotPrimitive_unitary` (line 638; public theorem): Actual circuit is unitary by primitive-circuit semantics.

- `warmRobinXorFourSlotPrimitive_noOracleCalls` (line 643; public theorem): Full primitive program has zero oracle calls.

- `warmRobinXorFourSlotPrimitivePresentation` (line 649; public def): Map full primitive gate list to symbolic presentation labels X/exact-angle and physical wire indices.

- `warmRobinXorFourSlotPrimitiveResource` (line 657; public def): Resource data is actual full primitive program.resource.

- `warmRobinXorFourSlotPrimitive_resource_faithful` (line 662; public theorem): Resource is definitionally actual circuit.resource, not an external circuit estimate.

- `warmRobinXorFourSlotPrimitiveBlockContainsTarget` (line 666; public def): Prop alias universally equates logical flat clean entries with QueryTarget.operator/normalizer.

- `warmRobinXorFourSlotPrimitiveBlockContainsTarget_proof` (line 674; public theorem): Supply that block proposition from the provider flat-unitary cleanBlock theorem and concrete query-target definitions.

- `warmRobinXorFourSlotPrimitiveOperatorCandidate` (line 682; public def): Candidate binds logical flat matrix,auxiliary3,layout(system3,signal3,pure0),presentation,resource,layoutMatches and selected unitary/block Props; default schedule[].

- `warmRobinXorFourSlotPrimitiveRefinement` (line 699; public def): PrimitiveRefinement binds actual circuit with full exact little-endian reindex equality.

- `warmRobinXorFourSlotPrimitiveVerifiedBlockEncoding` (line 707; public def): VerifiedOperatorBlockEncoding supplies candidate unitary/block proof terms; unitary proof concerns the logical flat matrix, while refinement separately connects actual circuit.

- `warmRobinFourSlotT3FlatUnitary` (line 714; public abbrev): Legacy FourSlotT3FlatUnitary is definitionally the XOR flat unitary,not a second cyclic construction.

- `warmRobinFourSlotPrimitive_eval_eq_flatUnitary` (line 717; public theorem): Legacy eval theorem is exactly the same full circuit equality under that alias.

- `warmRobinFourSlotPrimitiveVerifiedBlockEncoding` (line 724; public abbrev): Legacy verified-block-encoding abbreviation is definitionally the XOR verified certificate.

- `warmRobinXorFourSlotAmplitudeCircuit_counts` (line 727; public theorem): Actual five-control amplitude circuit contains32 Ry and62 CX by generic compiler counts.

- `warmRobinXorFourSlotAmplitudeProgram_noOracleCalls` (line 732; public theorem): Actual amplitude program resource has zero oracle calls.

### G1: Generic clean-block transport under system conjugation

1. Target and normalization: L(H)=I_C⊗I_S⊗H; conjugateSystem(H,U)=L(H)*(U*L(H)†). cleanBlock conjugation equals H*(cleanBlock(U)*H†).

2. Carriers, order and basis: Arbitrary Type* coefficient,selector,system with Fintype and DecidableEq on each when products/multiplication are used. Rectangular row/column auxiliary types need only Fintype. cleanSystemBlock alone has no finiteness/decidability assumptions.

3. Oracle/access and control guards: No oracle or circuit supplied. H and U are arbitrary matrices; unitarity preservation explicitly assumes both H and U unitary. Entry/block identities require neither unitarity hypothesis.

4. Ancillas, workspace and preservation: Clean coefficient and selector are arbitrary designated elements, not necessarily0. There is no extra clean-workspace assumption and no dirty-sector deletion; spectator indices are held by Kronecker deltas.

5. Phase: Conjugation orientation is H U H†, exactly over ℂ; star_systemLift_apply has star(H[columnSystem,rowSystem]). Not transpose-only or equality modulo phase.

6. Error and success: Exact algebraic identities, no approximation, norm, probability or success theorem. Empty finite carriers are allowed except designated clean elements must exist to instantiate those binders.

7. Resource tier: No cost theorem, no physical register embedding, and no gate synthesis supplied. This is an algebraic reusable transport, not by itself a resource-certified circuit.

Declaration-by-declaration reconstruction (line numbers refer to the complete target snapshot):

- `systemLift` (line 19; public def): Lift arbitrary system operator to I_coefficient⊗(I_selector⊗operator), for finite decidable carriers.

- `systemLift_unitary` (line 32; public theorem): If the system operator is unitary, its lift is unitary on the complete LCU product.

- `systemLift_apply` (line 49; public theorem): Lift entry is system operator entry iff both coefficient and selector row/column indices match, else0.

- `star_systemLift_apply` (line 68; public theorem): Adjoint-lift entry is star(operator[columnSystem,rowSystem]) under those same matching guards, else0.

- `systemLift_mul_cleanRow` (line 89; public theorem): For arbitrary rectangular right operator and designated clean coefficient/selector row, multiplying on the left by the lift reduces to a sum over system intermediate only.

- `mul_star_systemLift_cleanColumn` (line 121; public theorem): For arbitrary rectangular left operator and designated clean coefficient/selector column, multiplying on the right by adjoint lift reduces to a sum with star(systemOperator[systemColumn,intermediate]).

- `cleanSystemBlock` (line 154; public def): Extract exact submatrix obtained by fixing coefficient and selector on both sides; no typeclass assumptions are required for this indexing definition.

- `conjugateSystem` (line 165; public def): Conjugate full operator by lifted H on left and its adjoint on right, specifically L(H)*(U*L(H)†).

- `conjugateSystem_unitary` (line 182; public theorem): If both H and U are unitary, the conjugated full matrix is unitary.

- `cleanSystemBlock_conjugateSystem` (line 209; public theorem): For arbitrary H,U and any designated clean indices, the clean system block of the full conjugation equals H*(clean block(U)*H†); no unitarity assumption is used.

## Record fields, defaults, logical bundles and presentation boundary

The provider records were read as mathematical interfaces, not trusted because of their names.

- `PrimitiveProgram` has actual circuit and globalPhase fields. `PrimitiveProgramRefinement` additionally carries target and an equality proof; `PrimitiveRefinement` is the circuit analogue. Those exact fields are actual propositions with terms, not labels.
- `OperatorBlockEncodingCandidate` has auxiliaryQubits,target,unitary,layout,circuit,schedule (default[]),resource,layoutMatches (a real Nat equality proof),isUnitary : Prop,and blockContainsTarget : Prop. A candidate alone stores the latter two propositions, not evidence of them. `VerifiedOperatorBlockEncoding` separately requires unitaryProof and blockProof of exactly the candidate's selected propositions. The two target certificate constructors do supply such terms; their accepted compilation status was not independently replayed.
- The Figure4 candidate uses3 system+6 auxiliary=9 physical wires, split4 signal+2 pure in layout. The XOR candidate uses3 system+3 signal=6 wires and0 pure. The primitive Resource counts pureAncilla as0 by its definition for every list. Thus a layout declaration of two clean-workspace wires and the resource record's pureAncilla=0 are distinct pieces of data. No theorem equating these accounts is present.
- `Resource` has oneQubit,cnot,oracleCalls,pureAncilla,depth,all default0. Primitive resource is computed from actual one-/two-qubit counts and dependency depth, setting oracleCalls and pureAncilla to0. Zero oracle calls is structural for this gate language; it does not say angle computation,classical coefficient lookup,precision synthesis,connectivity or readout are free.
- `QueryOperatorTarget` stores operator,normalizer,source,semanticContract,freeParameters(default[]). The concrete target explicitly sets freeParameters[]. Neither this empty list nor its source/semanticContract Strings independently proves generic parameter closure or an operator theorem. The theorem aliases explicitly quantify the8×8 clean entries instead.
- Formal source metadata Strings such as the concrete QueryTarget's source description and the exact semanticContract String `the coefficient=0 and selector=0 clean block equals A/(56/3) exactly` are retained labels, not additional theorems. Presentation Strings `X` and `exact-angle` erase real angle values. No matrix semantics for that presentation is inferred; the refinement binds the actual exact-angle primitive list.
- `GHL2025.ObligationRecord` has description,source and proved : Bool(default false). The RobinMatrix projection's sparseCorrect,amplitudeCorrect,lcuCorrect are such records with false values, not proof fields of circuit correctness. In contrast its bandwidth_eq and matrixCoherence are genuine equality proof fields. No logical promotion of the Bool records occurs in this decoding.
- Empty `List String` open-contract inventories in provider files mean exactly empty lists. They are not quantified closure theorems. The nearby `_eq_nil` declarations prove list equality only.
- The read StatePreparation interfaces also distinguish normalization : Prop from a normalization proof, and isUnitary : Prop from its evidence. These provider records are not used to manufacture a state-preparation certificate for the nine targets.

## Proof architecture and ambient context

All target headers, imports, namespace/open commands, scoped notation, options,private helper,local have/let constructions and proof bodies were read. The companion inventory records ambient lines separately and retains each exact declaration region, including the guards and local statements. No target declaration was discarded as uninteresting bookkeeping.

The generic compiler uses constructor cases and list induction, with provider exact H/T/T† phase compensation and CCZ-to-CCX conjugation. The clean C3X theorem splits control bits and checks each wire. The fixed adder uses native finite decision over seven wires, not induction over width. Selector probability proof has local square-root positivity/bounds,cos²/sin² identities and individual finite-slot expansion; it is not merely a numerical uniformity test. Physical embedding proofs explicitly compare spectator contexts before reducing entries; local `rowControl` equalities align the physical control order with the logical one. Figure4 assembly retains inverse encodings,full middle reindex,adjoint reindex,permutation inverse clean action and selector sums; it does not take clean block correctness as an extra theorem hypothesis. XOR assembly similarly retains the middle-index intertwining,coordinate involutivity and exact flat little-endian indexing.

The 21 target declaration bodies containing `native_decide` are finite statement/proof leaves, listed in the coverage JSON. These bodies were read but never executed. Other target theorems may rely on finite provider leaves; `symbolic_declared_theorem_proof_not_replayed` does not mean native dependencies are absent.

Ambient options include enlarged recursion/heartbeat budgets and local `backward.isDefEq.respectTransparency false`; these affect elaboration behavior, not the mathematical proposition. The exact option lines are retained. The supplied toolchain is leanprover/lean4:v4.33.0; the supplied Lake manifest pins Mathlib to db584cd6d46c92f209a44c0f1c829460d327499d. The manifest and Lake configuration were read as exact supplied configuration, without package retrieval or checking the working machine's installed toolchain.

## Provider adequacy, pinning and scope

Provider selection is lexical and was not treated as a guarantee of semantic closure. I tracked the definitions actually needed for the reconstructions: complete matrix target/normalizer,slot maps and padded branch,exact-angle and rotation conventions,primitive evaluation/phase/order,all relevant equivalences,selector/amplitude/SELECT lifts,clean projection/conjugation,certificate field/default meanings,and resource computation. Each was present in the supplied target/projection context. No necessary unresolved project-owned definition or field was found,so no full-snapshot expansion was taken.

This is not elaboration-validated sufficiency. External Mathlib/Lean typeclass resolution,generated declarations and tactic search were not replayed; the imported project modules are not all admitted simply because their needed regions were present. The supplied projection RobinMatrix includes ambient references at distant source lines,not a whole-module read. Its14 explicit declarations are decoded as local provider context only. None of the remaining thousands of RobinMatrix declarations received an admission decision here.

`input-pins.json` records own SHA256 before/after each bounded retrieval and final-read checks,with exact relative files and supplied source/projection regions. Declared full-source digests from extent metadata are identified as metadata,not misrepresented as own hashes of unread full snapshots. `chronology-allowlist.json` records read ordering,output truncation recovery and exclusions. The first raw extent-metadata command also displayed its nonsemantic status/selection/adequacy footer; that incidental metadata exposure is disclosed there. It exposed no natural contract,desired theorem conclusion,author binder classifications,author declaration inventory,prior verdict or CI evidence.

## Handoff and acceptance boundary

Mathematical delta: independently reconstruct all215 explicit declarations in nine complete formal modules,including physical register maps,exact phases,clean guards,finite-vs-symbolic proof levels and two actual certificate constructors.

Failure class: NONE for source reading/reconstruction; compilation and source comparison were deliberately out of scope. No mathematical route was refuted or retired. Salvage audit: not applicable; no proof route was attempted or deleted. Process-memory records consulted: none beyond the required governance. No child agents or parallel route comparison occurred. Default verified-route/comparator choice: not made. Purification/Exposition Seal and independent source review: not performed or asserted. Highest frontier claimed by this artifact is independently decoded supplied formal semantics,not a newly accepted theorem.

Remaining authority boundary: compare this sealed reconstruction to separately pinned natural/source contracts and independently review that comparison only in a later authorized stage. No opaque binding or final publication wrapper is included.

