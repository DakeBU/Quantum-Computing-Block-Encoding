# Graph-only v2 author handoff

One canonical bounded source-graph-v2 AUTHOR proposal replaces the old complete-source-graph role. It does not change the raw natural contract, mathematical target, formal code, production, publication, catalog or registry.

Inputs: the distinct negative source-only review (seal 025776f017832c50b915d537b7aba06ccd6e505ebfae84749517538a9621c7a8), independent 49-node/18-AND source-first baseline and coverage, its source questions, the unchanged 104-line natural source, and the author's old graph solely for exact repair slices. No other decoder/source-formal reports or formal code were read for semantics. Original152 and source-first7 artifacts are immutable.

F01: E05/E13 explicitly retain general controlled primitive compiler equality, exact program phase and layout-specific full-carrier context/bijection suppliers.
F02: E11/E15 now end at physical projected heads P-F4/P-XOR; separate certificate edges require full unitarity, full refinement/phase, clean-index, candidate layout, actual witness and owned-resource suppliers.
F03: generic SystemConjugation is optional conceptual navigation, not a source-stated XOR import or implementation edge.
F04: symbolic RobinMatrix mathematics, named ND/Nf/kappa decomposition, actual47 imports and formal215 losslessness are excluded/quarantined from this source-only scope.
F05: preserve baseline C3X/dirty-work, transpose-bulk, rectangular/unitarity/resource boundaries; every raw source character/line has an exact reconstructible disposition. G01-G06 remain open; Q07 and Q08 remain visible. N40 includes provenance line3.
F06: OR is only Figure4 or XOR conditional projected M/224, with distinct layouts/resources. External paper-seven final consumer remains proposed, not a third winner.

New supplier nodes expose missing internal construction prerequisites; they are not new final Anchor binders and do not prove their own obligations. All phase/sign, active/padded-domain, fixed-versus-family, cleanup and exact-real cost boundaries remain. A graph representation failure refutes no source mathematics.

The old author graph (7922868ab8041c873629f80c2c2c505dadc2a9c9e9cd6ef1c2913d5388c0806a) is retained unchanged as historical/navigation-only and RETIRED as a complete source graph. Source-first v1 remains unchanged evidence, not a second maintained v2.

Canonical artifact: canonical-source-graph-v2.json.
Raw expansion: lossless-source-coverage-map.json.
Exact old/new changes: repair-ledger.json.
Bounded four-view navigation: four-view-bounded-navigation.json.
All new files use logical paths and one terminal LF; runtime filesystem roots are CLI arguments only.

Status: AUTHOR REORGANIZATION, NOT independent extraction, self-approval, compilation, mathematical refutation, whole-module/source-paper/publication approval or purification. No expected acceptance. A new distinct source-only review must decide topology. No child, Git, network, Lean/Lake/native proof or production action was used.

Failure class addressed: IMPLEMENTATION_FAILED for earlier graph representation completeness only. Salvage: baseline line coverage, projected derivations and all typed source gaps. No proof fragment newly promoted and no verified route selected. Stop after content seal.
