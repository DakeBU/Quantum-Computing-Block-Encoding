param(
  [Parameter(Mandatory=$true)][string]$WorkspaceRoot,
  [string]$PacketRoot=$PSScriptRoot
)
$ErrorActionPreference='Stop'
function Read-Json([string]$p) { Get-Content -Raw -LiteralPath (Join-Path $PacketRoot $p) | ConvertFrom-Json }
$pins=Read-Json 'input-pins.json'
$changed=@()
foreach($p in @($pins.full_read_inputs)+@($pins.immutable_existing_artifact_sets.files)) {
  $f=Join-Path $WorkspaceRoot $p.path
  $sha=(Get-FileHash -LiteralPath $f -Algorithm SHA256).Hash.ToLower()
  if($sha -ne $p.sha256){$changed+=[pscustomobject]@{path=$p.path;before=$p.sha256;after=$sha}}
}
$g=Read-Json 'canonical-source-graph-v2.json'
$c=Read-Json 'lossless-source-coverage-map.json'
$l=Read-Json 'repair-ledger.json'
$src=[IO.File]::ReadAllText((Join-Path $WorkspaceRoot $c.source))
$reconstructed=(@($c.regions|ForEach-Object{$_.raw_text}) -join '')
$lines=$src.Split([char]10)
if($lines[-1] -eq ''){$lineCount=$lines.Count-1}else{$lineCount=$lines.Count}
$used=@(0)*$lineCount;$position=0;$extents=$true
foreach($r in $c.regions) {
  if($r.source_start_offset -ne $position -or $r.raw_text -cne $src.Substring($r.source_start_offset,$r.source_end_offset-$r.source_start_offset)){$extents=$false}
  $position=$r.source_end_offset
  for($i=$r.lines[0];$i -le $r.lines[1];$i++){$used[$i-1]++}
}
$nodeIds=@{};foreach($n in $g.nodes){$nodeIds[$n.id]=$true}
$external=@{};foreach($id in $g.external_interface_nodes){$external[$id]=$true}
$unknown=@()
foreach($e in $g.edges){foreach($id in @($e.tails)+@($e.heads)){if(-not $nodeIds.ContainsKey($id) -and -not $external.ContainsKey($id)){$unknown+=$id}}}
foreach($r in $c.regions){foreach($id in $r.canonical_nodes){if(-not $nodeIds.ContainsKey($id)){$unknown+=$id}}}
$baseline=Get-Content -Raw -LiteralPath (Join-Path $WorkspaceRoot 'robin-nine-c45-source-first/natural-topology.json')|ConvertFrom-Json
$gapsPreserved=$true
foreach($id in @('G01','G02','G03','G04','G05','G06')){
  $old=@($baseline.nodes|Where-Object{$_.id -eq $id})[0]
  $new=@($g.nodes|Where-Object{$_.id -eq $id})[0]
  if($old.claim -cne $new.claim -or $new.kind -ne 'SOURCE_GAP'){$gapsPreserved=$false}
}
function Has-Tails([string]$edgeId,[string[]]$ids) {
  $e=@($g.edges|Where-Object{$_.id -eq $edgeId})[0]
  foreach($id in $ids){if($id -notin $e.tails){return $false}}
  return $true
}
$f01=(Has-Tails 'E05' @('UCR-GENERAL','CTX-8','PHASE-8')) -and (Has-Tails 'E13' @('UCR-GENERAL','CTX-6','PHASE-6'))
$f02=(Has-Tails 'E11-CERT' @('P-F4','F4-FULL-UNITARY','F4-REFINE','F4-CLEAN-INDEX','F4-LAYOUT','F4-WITNESSES','F4-RESOURCE-OWNERSHIP')) -and (Has-Tails 'E15-CERT' @('P-XOR','XOR-FULL-UNITARY','XOR-REFINE','XOR-CLEAN-INDEX','XOR-LAYOUT','XOR-WITNESSES','XOR-RESOURCE-OWNERSHIP'))
$or=@($g.alternative_routes)[0]
$orMatched=($or.routes.Count -eq 2 -and (@($or.routes[0].requires_all) -join ',') -eq 'P-F4' -and (@($or.routes[1].requires_all) -join ',') -eq 'P-XOR')
$n40=@($g.nodes|Where-Object{$_.id -eq 'N40'})[0]
$n40Line3=@($n40.exact_source_ranges|Where-Object{$_[0] -eq 3 -and $_[1] -eq 3}).Count -eq 1
$jsonErrors=@();$textErrors=@();$leaks=@();$fileCount=0
foreach($f in Get-ChildItem -LiteralPath $PacketRoot -Recurse -File){
  $fileCount++
  $s=[IO.File]::ReadAllText($f.FullName)
  $relative=$f.FullName.Substring($PacketRoot.Length+1).Replace('\','/')
  if($f.Extension -eq '.json'){try{$null=$s|ConvertFrom-Json}catch{$jsonErrors+=$relative}}
  if($s.Contains([char]13) -or -not $s.EndsWith([char]10) -or $s.EndsWith("`n`n")){$textErrors+=$relative}
  foreach($m in [regex]::Matches($s,'(?i)\b[A-Z]:[\\/]|/(?:Users|home)/[^/\s]+/|sk-[A-Za-z0-9_-]{20,}|ghp_[A-Za-z0-9]{20,}')){
    $leaks+=[pscustomobject]@{path=$relative;offset=$m.Index;type='absolute-local-root-or-credential-pattern'}
  }
}
[pscustomobject]@{
  kind='deterministic graph/content integrity only, NOT independent topology acceptance'
  input_and_immutable_hash_changes=$changed
  original_152_and_source_first_7_unchanged=($changed.Count -eq 0)
  raw_source_sha256=$c.source_sha256
  source_lines=$lineCount
  every_source_line_disposed_once=(@($used|Where-Object{$_ -ne 1}).Count -eq 0)
  all_raw_source_characters_reconstructed=($src -ceq $reconstructed -and $position -eq $src.Length -and $extents)
  unknown_node_references=@($unknown|Sort-Object -Unique)
  baseline_nodes_preserved=(@($baseline.nodes|Where-Object{-not $nodeIds.ContainsKey($_.id)}).Count -eq 0)
  source_gap_claims_G01_G06_unchanged=$gapsPreserved
  Q07_preserved=$nodeIds.ContainsKey('Q07')
  Q08_preserved=$nodeIds.ContainsKey('Q08')
  N40_includes_source_line3=$n40Line3
  F01_supplier_tail_presence=$f01
  F02_split_certificate_tail_presence=$f02
  OR_only_two_conditional_projected_targets=$orMatched
  repair_ledger_F01_F06=(@($l.findings.id) -join ',')
  canonical_nodes=$g.nodes.Count
  canonical_AND_edges=$g.edges.Count
  json_errors=$jsonErrors
  UTF8_LF_single_terminal_LF_errors=$textErrors
  local_root_or_credential_pattern_findings=$leaks
  all_current_files_scanned=$fileCount
  source_topology_acceptance=$false
  source_mathematics_refuted=$false
  independent_new_review='PENDING'
  limitations='Lexical graph shape, raw source reconstruction and content pins only; no formal reread, elaboration, proof, import/ownership, scientific-target or publication validation.'
}|ConvertTo-Json -Depth 8 -Compress
