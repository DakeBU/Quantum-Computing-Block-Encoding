"""Mechanical, read-only pairing of two sealed static inventories.

All filesystem roots are CLI arguments. JSON goes to stdout; artifact writes
are performed separately with apply_patch. No Lean/native proof execution.
"""
import argparse
import hashlib
import json
import re
from pathlib import Path

DECODER_PINS={
 "chronology-allowlist.json":"a4673178c73629ed26b7f475070aa1a7595748301b36f6eba5cabfa1241e0f6d",
 "independent-declaration-coverage.json":"0b57563d54eadce553f1c057157589ad6133fd3991143ba2446bf5573d7091c7",
 "input-pins.json":"5ec1845eb34a91a306929886e55fffc1ed9018ed631b0c300c0361dfe409c872",
 "reconstruction.md":"7bbf2afc2ad733f47ea0f80e3a61312eeece827581b3dc8f0b9b6233bbee129f",
 "seal.json":"6393b34e8bbb9d7486cac9a868b7d7f623396354c4f328472124eeef1b745f5c",
 "unresolved-context.json":"d8693709825fb574b3b76f2edb36f123e16ccd0324327ee967c9dae72b52073f",
 "validate-input-pins.ps1":"9473c81ef39bcc7693e3d1f4d93bdab911b831c2a8d1eae8b8a5d84bfdd12684"
}
S1="0b8fd2a6b6dd193f380a983e62f9e00dabac216a62bac82c6994f72124030347"
S2="7035fc54c559fce21c466e3dd4c3a786120fd0f08c638aa51676b0376bad9bb3"
OWN_INVENTORY="3c24fd0f7a475dd62a0811937aedb819762a87c462f51f5cbb3389f16dcbb849"
NATURAL="519b05b4fb6e84f1b1cafc11a6fc8752af47fe1c22e0a2b9897b1e585ad079ee"
EXPECTED_FAMILY_COUNTS={"M1":6,"M2":7,"M3":9,"P1":20,"P2":19,"A1":16,"F1":23,"F2":20,"S1":10,"X1":75,"G1":10}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def load_json(path):
    return json.loads(path.read_text(encoding="utf-8"))

def canonical(text):
    # The full file byte pins remain exact. Region comparison only normalizes
    # CRLF to LF and removes line-end/outer whitespace from differing extents.
    return "\n".join(line.rstrip() for line in text.splitlines()).strip()

def split_header_body(text):
    """Find outer := or where, ignoring named args, strings and type-level lets."""
    stack=[]
    closing={"(":")","{":"}","[":"]"}
    quoted=False
    escaped=False
    pending_let=0
    i=0
    while i<len(text):
        char=text[i]
        if quoted:
            if escaped:
                escaped=False
            elif char=="\\":
                escaped=True
            elif char=='"':
                quoted=False
            i+=1
            continue
        if char=='"':
            quoted=True
            i+=1
            continue
        if char in closing:
            stack.append(closing[char])
            i+=1
            continue
        if stack and char==stack[-1]:
            stack.pop()
            i+=1
            continue
        if not stack:
            if char=="|" and not text[:i].rsplit("\n",1)[-1].strip():
                return text[:i].strip(),text[i:].strip(),"equations"
            word=re.match(r"[A-Za-z_][A-Za-z_0-9']*",text[i:])
            if word:
                token=word.group()
                if token=="let":
                    pending_let+=1
                if token=="where":
                    return text[:i].strip(),text[i:].strip(),"where"
                i+=len(token)
                continue
            if text.startswith(":=",i):
                if pending_let:
                    pending_let-=1
                    i+=2
                    continue
                return text[:i].strip(),text[i:].strip(),":="
        i+=1
    raise ValueError("No outer definition/proof delimiter")

def own_family(module_name,line):
    if module_name=="ModularAdder3.lean":
        return "M1" if line<75 else "M2" if line<198 else "M3"
    return {"PaperSevenPrepare.lean":"P1","PaperSevenPreparePrimitive.lean":"P2","PaperSevenAmplitudePrimitive.lean":"A1","Figure4PreparePrimitive.lean":"F1","Figure4T3.lean":"F2","SymmetryFourSlotPrimitive.lean":"S1","SymmetryXorFourSlotPrimitive.lean":"X1","SystemConjugation.lean":"G1"}[module_name]

def sealed(root,name,expected):
    path=root/name
    raw=path.read_bytes()
    assert sha(raw)==expected,"Seal/input mutation: "+name
    return raw

def verify_artifact_seal(root,filename,expected):
    data=json.loads(sealed(root,filename,expected))
    records=data["artifacts"] if "artifacts" in data else data["integrity"]["artifacts"]
    for record in records:
        raw=(root/record["path"]).read_bytes()
        assert sha(raw)==record["sha256"] and len(raw)==record["bytes"],"Sealed artifact mutation: "+record["path"]
    return len(records)

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--work-root",required=True)
    p.add_argument("--decoder-root",required=True)
    p.add_argument("--author-root",required=True)
    p.add_argument("--repository-root",required=True)
    p.add_argument("--part",choices=["summary","module","families","pins","check"],default="summary")
    p.add_argument("--module",type=int,default=0)
    args=p.parse_args()
    work=Path(args.work_root)
    decroot=Path(args.decoder_root)
    s1root=work/"robin-nine-c45-source-first"
    s2root=work/"robin-nine-c45-source-review-phase2"
    s1count=verify_artifact_seal(s1root,"stage1-seal.json",S1)
    s2count=verify_artifact_seal(s2root,"stage2-seal.json",S2)
    verify_artifact_seal(decroot,"seal.json",DECODER_PINS["seal.json"])
    sealed(Path(args.author_root),"natural-contract.md",NATURAL)
    decoder_pins=[]
    for name,expected in DECODER_PINS.items():
        raw=sealed(decroot,name,expected)
        decoder_pins.append({"path":"decoder/"+name,"bytes":len(raw),"sha256_before":expected,"sha256_after":sha(raw),"equal":True})
    own=json.loads(sealed(s2root,"whole-inventory-and-source-map.json",OWN_INVENTORY))
    decoder=load_json(decroot/"independent-declaration-coverage.json")
    prose=(decroot/"reconstruction.md").read_text(encoding="utf-8")
    prose_rows=re.findall(r"^- `([^`]+)` \(line (\d+); (public|private) (def|theorem|abbrev)\): (.+)$",prose,re.M)
    assert len(prose_rows)==215,"Reconstruction prose declaration bullet count differs"
    lookup={}
    for d in decoder["declarations"]:
        key=(d["file"],d["name"])
        assert key not in lookup
        lookup[key]=d
    assert len(lookup)==215
    modules=[]
    used=set()
    for module in own["modules"]:
        path=module["path"].removeprefix("author/")
        raw=(Path(args.author_root)/path).read_bytes()
        assert sha(raw)==module["sha256"]
        rows=[]
        for d in module["all_regions"]:
            if "name" not in d:
                continue
            key=(path,d["name"])
            assert key in lookup
            q=lookup[key]
            used.add(key)
            own_region=canonical(d["literal_region"])
            decoder_region=canonical(q["exact_declaration_region"])
            try:
                own_header,own_body,delimiter=split_header_body(own_region)
            except ValueError as error:
                raise ValueError(d["name"]+": "+str(error)) from error
            decoder_header,decoder_body,decoder_delimiter=split_header_body(decoder_region)
            visibility="private" if d["private"] else "public"
            namespace="QuantumBlockEncoding" if path.endswith("/ModularAdder3.lean") else "QuantumBlockEncoding.Robin.ComplexLCU" if path.endswith("/SystemConjugation.lean") else "QuantumBlockEncoding.Robin"
            qualified=namespace+"."+d["name"]
            family=own_family(Path(path).name,d["start_line"])
            identity_matches=(q["qualified_name"]==qualified) if visibility=="public" else (q["qualified_name"] is None and key==(q["file"],q["name"]))
            checks={"identity":identity_matches,"kind":d["kind"]==q["kind"],"privacy":visibility==q["visibility"],"noncomputable":bool(re.search(r"\bnoncomputable\b",own_header))==q["noncomputable"],"start_line":d["start_line"]==q["line_start"],"decoder_extent_inside_own_complete_region":q["line_end_inclusive"]<=d["end_line"],"whole_region":own_region==decoder_region,"header":own_header==decoder_header,"body":own_body==decoder_body,"family":family==q["family"],"delimiter":delimiter==decoder_delimiter}
            assert all(checks.values()),"Pair mismatch "+qualified+":"+str(checks)
            prose_match=[r for r in prose_rows if r[0]==d["name"] and int(r[1])==d["start_line"]]
            assert len(prose_match)==1
            assert prose_match[0][2:4]==(visibility,d["kind"])
            assert prose_match[0][4]==q["mathematical_reconstruction"]
            rows.append({"file":"author/"+path,"name":d["name"],"qualified_name":q["qualified_name"],"lexical_namespace_name":qualified,"identity_boundary":"Public namespace name, or private(file,name,visibility) lexical identity; private elaborated mangled name not invented.","kind":d["kind"],"visibility":visibility,"noncomputable":q["noncomputable"],"line_start":d["start_line"],"own_region_end":d["end_line"],"decoder_region_end":q["line_end_inclusive"],"family":family,"checks":checks,"region_sha256_own":sha(own_region.encode()),"region_sha256_decoder":sha(decoder_region.encode()),"header_sha256_own":sha(own_header.encode()),"header_sha256_decoder":sha(decoder_header.encode()),"body_sha256_own":sha(own_body.encode()),"body_sha256_decoder":sha(decoder_body.encode()),"delimiter":delimiter,"source_nodes":d["source_nodes"],"own_sealed_interpretation":d["own_semantic_mapping"],"actual_decoder_interpretation":q["mathematical_reconstruction"],"interpretation_comparison":"Substantive prose fully read and compared against prior independently read/pinned formal region; no contradictory claim identified. Family-slot qualifiers retained; raw-region hash equality alone is NOT a semantic judgment."})
        modules.append({"file":"author/"+path,"target_sha256":module["sha256"],"pairs":rows,"pair_count":len(rows)})
    assert used==set(lookup)
    counts={f:sum(d["family"]==f for m in modules for d in m["pairs"]) for f in EXPECTED_FAMILY_COUNTS}
    assert counts==EXPECTED_FAMILY_COUNTS
    ownpins=load_json(s2root/"input-pins.json")
    expected={("A",x["path"].removeprefix("author/")):x["sha256_after"] for x in ownpins["inputs"]}
    expected.update({("R",x["path"].removeprefix("repository/")):x["sha256_after"] for x in ownpins["protocol_pins"]})
    dpins=load_json(decroot/"input-pins.json")["inputs"]
    assert len(dpins)==56
    assert {(x["root"],x["path"]) for x in dpins}==set(expected)
    roots={"A":Path(args.author_root),"R":Path(args.repository_root)}
    formal_pins=[]
    for x in dpins:
        key=(x["root"],x["path"])
        h=sha((roots[x["root"]]/x["path"]).read_bytes())
        assert h==expected[key]==x["own_pre_sha256"]==x["own_post_sha256"]==x["own_final_sha256"]
        formal_pins.append({"path":("author/" if x["root"]=="A" else "repository/")+x["path"],"own_prior_sha256":expected[key],"decoder_pre_sha256":x["own_pre_sha256"],"decoder_post_sha256":x["own_post_sha256"],"decoder_final_sha256":x["own_final_sha256"],"stage3_current_sha256":h,"all_equal":True})
    family_records=decoder["families"]
    assert len(family_records)==11
    assert all(len(f["seven_slots"])==7 for f in family_records)
    native_own=[d["qualified_name"] for m in modules for d in m["pairs"] if "native_decide" in lookup[(m["file"].removeprefix("author/"),d["name"])]["exact_declaration_region"]]
    assert len(native_own)==21
    unresolved=load_json(decroot/"unresolved-context.json")
    listed_native=next(x["precise_items"] for x in unresolved["unresolved_or_deliberately_unverified"] if x["id"]=="FINITE-NATIVE-LEAVES")
    assert set(listed_native)==set(native_own)
    summary={"schema":"independent-stage3-mechanical-pairing-v1","normalization":"Exact whole-file byte hashes are primary. Per-declaration region hashes canonicalize CRLF/LF, remove each line's trailing whitespace and strip outer whitespace; headers/bodies split at outer where,:= or equation clause, ignoring named args/strings/type-level let assignments. No internal code token rewritten.","old_header_aid_boundary":"Stage2 signature_text was expressly a conservative lexical aid; fresh header/body hashes derive from its sealed complete literal_region, not that aid. Stage2 artifact unchanged.","declarations":215,"module_count":9,"family_counts":counts,"family_slots":77,"prose_bullets_exactly_paired":215,"all_identity_privacy_kind_header_body_checks":True,"all56_formal_protocol_pins_equal":True,"decoder_payloads":decoder_pins,"own_prior_seals":{"stage1":S1,"stage2":S2,"stage1_bound_artifacts_equal":s1count,"stage2_bound_artifacts_equal":s2count},"own_inventory_sha256":OWN_INVENTORY,"native_source_bodies":native_own,"formal_proof_execution":"NONE"}
    if args.part=="module":
        output=modules[args.module]
    elif args.part=="families":
        output=family_records
    elif args.part=="pins":
        output={"decoder_payloads":decoder_pins,"formal_and_protocol_inputs":formal_pins,"prior_seals":summary["own_prior_seals"],"natural_source_sha256":NATURAL}
    elif args.part=="check":
        out=work/"robin-nine-c45-source-review-phase3"
        saved=load_json(out/"215-pair-mapping.json")
        assert saved["modules"]==modules
        slot_packet=load_json(out/"family-slot-comparison.json")
        assert slot_packet["family_count"]==11 and slot_packet["slot_count"]==77
        assert {f["id"] for f in slot_packet["families"]}==set(EXPECTED_FAMILY_COUNTS)
        for f in slot_packet["families"]:
            actual=next(x for x in family_records if x["id"]==f["id"])
            assert f["seven_slots"]==actual["seven_slots"] and len(f["slot_comparison"])==7
            assert all(s["actual_decoder_interpretation"]==actual["seven_slots"][s["name"]] and s["own_comparison"] for s in f["slot_comparison"])
        saved_pins=load_json(out/"input-pins.json")
        assert saved_pins["decoder_payloads"]==decoder_pins and saved_pins["formal_and_protocol_inputs"]==formal_pins
        gap_packet=load_json(out/"gaps.json")
        assert {g["id"] for g in gap_packet["source_gaps"]}=={"G01","G02","G03","G04","G05","G06"}
        assert gap_packet["scope_question"]["id"]=="Q07"
        checks=[]
        for path in sorted(out.iterdir()):
            assert path.is_file()
            raw=path.read_bytes()
            assert raw.endswith(b"\n") and not raw.endswith(b"\n\n") and not raw.endswith(b"\r\n"),"Final LF mismatch"
            text=raw.decode("utf-8")
            assert not re.search(r"[A-Za-z]:[/\\]",text),"Absolute machine path in artifact"
            if path.suffix==".json":
                json.loads(text)
            checks.append({"path":path.name,"bytes":len(raw),"sha256":sha(raw)})
        output={"status":"PASS_MECHANICAL_EVIDENCE_CHECK_ONLY","summary":summary,"artifacts":checks}
    else:
        output=summary
    print(json.dumps(output,ensure_ascii=False,indent=2))

if __name__=="__main__":
    main()
