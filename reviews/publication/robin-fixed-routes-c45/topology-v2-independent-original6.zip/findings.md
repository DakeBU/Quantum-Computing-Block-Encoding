# Independent source-only topology review: v2

Verdict: ACCEPTED_BOUNDED_LOCAL for the conditional construction topology in canonical-source-graph-v2.json and its exact raw-source coverage. This resolves my graph-representation blockers F01–F06. It does not close any mathematical SOURCE_GAP or certify any circuit/proof artifact. The original six-artifact negative packet remains unchanged and remains the verdict on the original proposals.

Direction fingerprint: distinct-raw-natural-source-hyperedge-closure-v2.
Expected information gain: determine whether the actual graph-only successor repairs F01–F06, independently of any source–formal comparison.

## What was independently compared

I reread the unchanged 104-line natural contract, my own prior findings, every canonical v2 node and edge, the complete raw-region mappings, the preserved gaps/questions, the four-view navigation and repair ledger. The author proposal's self-reported validation/repair claims were not treated as review acceptance. I independently checked all eleven artifact hashes and byte lengths against the supplied v2 seal, all raw-region text and offsets against the actual source, the 104-line dispositions, all edge/coverage node references, and the baseline node/edge changes. No supplied validation script was executed. Some large display outputs were truncated; omitted portions were subsequently inspected in compact parsed views. No implementation or external source was followed.

The raw source is implementation-informed retrospective LOCAL notes. The v2 remains an AUTHOR reorganization of a prior independent extraction, not a new independent extraction or a historical pre-proof seal. This review is the distinct source-only comparison; it does not independently establish the raw source's implementation/binder-audit assertions.

## F01–F06 findings

F01 resolved. E05 now requires UCR-GENERAL, CTX-8 and PHASE-8 in addition to conventions, layout and the bounded coefficient table. E13 analogously requires UCR-GENERAL, CTX-6 and PHASE-6. Those nodes explicitly retain full-carrier equality, well-formed wiring, complete angle tables, spectator/context bijections and exact exp(i phi), rather than inferring a compiled circuit from ideal RY semantics. Their suppliers remain unexpanded and linked to gaps. They are dependency obligations, not new final Anchor binders.

F02 resolved. E11 ends at P-F4 and E15 at P-XOR: physical projected-target identities only. F4-REFINE/F4-CLEAN-INDEX and XOR-SECTOR-MATCH/XOR-REFINE/XOR-CLEAN-INDEX expose the required physical/model correspondence. E11-CERT and E15-CERT separately require each route's projected identity, full-unitary result, refinement, clean-index agreement, layout, actual proof witnesses and resource ownership. N27/N36 are explicitly conditional certificate/metadata conjunctions, not certificates proved by a slot sum. In particular P-F4/P-XOR have explicit non-edges to full unitarity. Adding supplier nodes has represented the missing obligations, not supplied their proofs.

F03 resolved. Generic system-conjugation algebra N38 is not an AND prerequisite of the XOR circuit. E15 uses the explicit signed S and involutive C construction, with a separate provider-match obligation. The N38 -> N36 non-edge remains. The navigation's optional conceptual applicability is correctly distinguished from source-stated use, module imports and declaration ownership.

F04 resolved within the successor's live source graph. The canonical graph's only raw mathematical authority is the pinned natural contract. Symbolic RobinMatrix mathematics, the named ND/Nf/kappa decomposition, 47-import and 215-formal-losslessness assertions are explicitly quarantined. The repair ledger quotes old assertions solely to identify rejected historical representations; those quotations are not accepted mathematical nodes or source evidence. The Lean view has no asserted nodes/edges and is marked unavailable.

F05 resolved. The canonical graph retains N07 (C3X domain distinction), N24 (transpose-bulk columns3,4), N09/N13/N37 (resource tiers), N38/N39 (parametric and unitary quantifiers), all six gaps, and explicit unresolved rectangular subresults. N40 now explicitly includes line3 and exact source ranges. The 61 source regions reconstruct all 16032 characters of the actual raw text, including terminal whitespace, and dispose all 104 lines exactly once. All 32 substantive regions in my previous independent map still receive NODE dispositions. The map includes raw source expansion; it does not claim formal declaration expansion. The compressed spine is honestly labelled nonexhaustive navigation.

F06 resolved. The only bounded OR alternatives are P-F4 and P-XOR, with common head exact fixed projected M/224. Figure4 retains its nine-wire layout, clean coefficient/selector/indicator/work projection and 3/4/2 partition. XOR retains its six-wire layout, q3/q4/q5 clean projection, system sector q2 and 3/3/0 partition. No common full matrix, unitarity proof, resource tuple or verified default is inferred. The paper-seven consumer is separately PROPOSED EXTERNAL CONDITIONAL, with actual SELECT/workspace extension, sandwich/cleanup, phase/index/normalizer and target obligations, not a third bounded winner.

## Source mathematics and guards checked again

The same-strength target remains A/alpha=M/224 for fixed eight-dimensional A=M/12 and alpha=56/3. Matrices act on columns and chronological gate order reverses in products; phases are exact, not projective. RY's standard half-angle signs are retained. The seven-state preparation uses eight physical labels, with probability1/7 on labels0..6 and zero at7. Its selector factors in the sandwich occur as conjugate amplitudes, not an assumed all-positive phase convention.

For Figure4, d is a permutation, the missing active offset is4, and its opposite-row matrix entry is zero in each column by the stated band and reflected boundary support. Thus the active slot sum yields M/224, conditional on the stated B interface. That interface retains both coefficient indices; indicator/work cleanup is for BOTH coefficient input basis states, not only q6=0. Transpose-bulk remains j=3 or4; columns2 and5 have second-neighbor boundary coefficient -2 rather than the bulk -1. Different padded loader values remain distinct total definitions; zero prepared padding probability does not erase the physical label.

For XOR, amplitude uses the input pair before SELECT. The 1/56 amplitude and 1/4 selector probability give the sector block /224. C gives coordinate blocks [[T,K],[K,T]] and standard-RY S requires sectors T+K,T-K. This is a necessary mathematical expectation; XOR-SECTOR-MATCH preserves the uninspected provider match. The chronology S-dagger,middle,S yields S middle S-dagger, and sector q2 remains system. Cyclic shifts cannot replace XOR coefficients. The source's max coefficient and sector bounds do not establish any unread table/compiler theorem.

For generic conjugation, the projected identity is arbitrary-finite and needs no unitary premise. L(V) unitary requires V unitary, and conjugated U unitary requires BOTH V and U unitary. Exact rectangular signatures remain G06 rather than being invented from compressed prose. No cost or elementary gate realization for arbitrary V is inferred.

## Gaps, questions and conditional transports

G01–G06 retain exactly their baseline node claims and all remain open: exact C3X inequalities; adder list/macro phases; missing tables/general compiler proofs; Figure4 middle implementation/cleanup; sector definitions; exact signatures/witness/resource details. No new supplier has an incoming edge falsely discharging one of those gaps. Calling an internal supplier an obligation is not a proof or a new public assumption.

Q07 preserves the nine-versus-ten scope question without modifying raw text or approving RobinMatrix. Q08 preserves the representation question; mathematically the source preparation angles can be written arccos(1/7) and arccos(1/3) by the double-angle identity on the principal branches, but this is not a checked representation or compiled-angle identity.

Functor navigation preserves PREPARE data, SELECT/addressing, inverse, exact phase, registers, clean projection/cleanup, normalization and resource tier. Its BE-to-state consumer separately requires a prepared input, nonzero accepted branch, normalization, postselection and any claimed amplification/readout costs. Those prerequisites are not supplied here. No categorical identity/composition certificates are implied. Zero abstract queries and stated fixed gate counts do not imply finite-bit synthesis, hardware routing, approximation, optimality, asymptotic or resource-comparison results.

## Nonblocking annotation

UCR-GENERAL has lines=[36,42], while its explicit exact_source_ranges correctly also includes [83,83]. The coarse locator should span [36,83] in a future version or be labelled nonbounding. This does not omit content or change an edge: the exact-range list and independent raw coverage correctly map line83. No source mathematics or additional proof is required to address it. The immutable proposal was not edited.

## Final boundary and handoff

Failure class: NONE for this bounded conditional graph representation. The previous representation failure is resolved only in the successor. Salvage: the original source-first coverage/guards/gaps are preserved with explicit graph obligations. No source mathematics is retired and no compiled fragment is promoted. Actual imports, ownership, proof terms, 215 declarations, all whole-module gates, original-paper fidelity, Lean/compiler acceptance, publication, purification and an Exposition Seal remain outside this acceptance. No verified circuit default is chosen. No child, network, Git, compiler/native proof, production or registry operation was used. Required governance was already read fully by this same review identity; no additional curated process-memory item was consulted.

Recommended handoff: use this seal solely as independent bounded LOCAL graph/topology acceptance. Any broader promotion needs its separately authorized evidence; this seal cannot stand in for it.
