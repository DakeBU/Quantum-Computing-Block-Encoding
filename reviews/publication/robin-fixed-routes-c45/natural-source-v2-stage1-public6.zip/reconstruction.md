# Independent raw-source mathematical reconstruction — Stage 1

Identity: `/root/robin_c47_raw_source_recovery`. Direction fingerprint: `raw-source-math-recovery`.
Input authority: one local retrospective mathematical source, SHA256 `10681db8c6f62818bcdd8d6eef787027983b010540e86c547afbaacc34031790`, 414 lines.
This report is not an original-paper reconstruction, a formal-source comparison, an author audit, or a Lean certificate.

## Judgment and information gained

**Source-mathematics judgment: ACCEPT the two finite fixed-target construction arguments, with the explicit boundaries below.** I found no irreducible missing mathematical bridge or counterexample to their stated local contracts. This does not accept the source's claims about exact implementation signatures or actual compiled witness terms: those were not inspected. The source is a specification plus mathematical arguments, not evidence that its implementation agrees.

The independent gain is an explicit proof path from literal gate lists and complete tables to both projected roots, rather than acceptance from module names, supplied graph IDs, or matching finite tables. In particular: C3X control aliases are harmless under the actual eight clean guards; UCR induction does not need injective controls; Figure4 coherence needs the whole coefficient 2x2 matrix; XOR requires the signed RY conjugation and the two physically counted C circuits. Physical work wires, list-resource fields, abstract scalar phases, and schema witness fields have separate roles.

No source-claimed formal result was run. The independent diagnostic makes 7,120 exact integer/bit assertions, including 5,760 C3X input/alias cases; it supports, but does not replace, the general mathematical derivations. Its gate-topology re-emission independently yields the stated finite counts/depths.

## 1. Frozen contract and exact conventions

Basis: B_q consists of q bit functions, with little-endian index ell(x)=sum_k 2^k x_k. Complex matrices act on columns. A chronological list g1,...,gm has matrix Gm...G1. A Program is (list,phi), with matrix exp(i phi) times that product. Dagger reverses the list, negates rotation angles and phi. No quotient by global phase is taken.

Logical order is coefficient x (selector x full-system). A clean block fixes coefficient/selector on both indices, plus any specified indicator/work. It is not a unitary on the projected system in general. For normalized psi, accepted amplitude is M psi/224, with success probability ||M psi||^2/224^2; conditional normalized output is M psi/||M psi|| only if nonzero. Nothing here promises deterministic preparation or amplification.

Fixed target:
A=M/12, alpha=56/3, A/alpha=M/224.
M is the complete 8x8 integer matrix in source lines128–140. It is centrosymmetric, not Hermitian (M01=32, M10=16). No PDE scale factor is reintroduced.

Figure4 root: a 512x512 exact Program U_F with U_F[8i,8j]=M[i,j]/224 for all i,j in Fin8, and full U_F unitary.
XOR root: a 64x64 exact zero-phase Program U_X with U_X[i,j]=M[i,j]/224 for all i,j in Fin8, and full U_X unitary. Here indices i,j denote the explicitly clean first-eight states, not arbitrary full-matrix indices.
They are OR alternatives only at this matched projected target. They do not have equal dimensions, full matrices, phases, clean embeddings, or resources.

The nine named modules are the administrative scope of the source, not a verified exhaustive module-declaration inventory. The final paper7 consumer and complete RobinMatrix backend are outside this review.

## 2. Primitive semantics, phase and reversible compilation

The specified RY(theta) has first column (cos(theta/2),sin(theta/2)); RZ(theta) is diag(exp(-i theta/2),exp(i theta/2)). R(c)=RY(2 arccos c) is unitary for any real c, while its00 entry equals c only on [-1,1]. For bounded c its other column is (-sqrt(1-c^2),c). Negative coefficients are not replaced by absolute values. Active c=0 gives RY(pi), not identity.

The exact H macro is exp(i pi/2) RY(pi/2) RZ(pi). Direct multiplication gives [[1,1],[1,-1]]/sqrt2. T is exp(i pi/8)RZ(pi/4)=diag(1,exp(i pi/4)); T-dagger has the opposite phase. Thus actual scalar compensation is essential for exact equality, even when no probability changes.

In the CCX middle, the four target CX restore t. Their T/T-dagger phase contributions are
-(t xor b)+(t xor b xor a)-(t xor a)+t.
The b-target CX pair restores b, with remaining terms b+a-(a xor b).
Their sum is the displayed seven-term phase polynomial, equal to 4abt. Hence the middle is CCZ, and H on each side changes controlled Z to controlled X exactly. There are 2 RY,9 RZ,6 CX and stored phase9pi/8. The empty-list identity and head/tail multiplication prove arbitrary-ambient-q reversible-list compilation by induction. This is not an arbitrary-width arithmetic theorem.

C3X actual list is CCX(a,b;w), CCX(w,c;t), CCX(a,b;w). Six guards ensure those three CCX instructions are well formed. They permit t=a or t=b, in which cases no ideal triple-control interpretation follows. For ideal clean action add a!=t,b!=t and w=0; a=c or b=c remains permitted. Since a,b,c are then unchanged, the target toggle is c(w xor ab), and work is restored. For dirty w the extra toggle cw is real. No all-dirty ideal tensor extension follows.

## 3. Fixed adder and full-context controlled RY

The literal eight-instruction adder preserves b and restores w. On work0 let c1=a0 b0. The first triple changes a2 by a1 c1 and cleans w before modifying a0,a1. The fourth instruction changes a1 to a1 xor c1. The sixth contributes b1(a1 xor c1) to a2. Thus the high carry is a1c1 xor a1b1 xor b1c1, the majority carry; remaining CX form the sum bits. Therefore a'=(a+b) mod8, b'=b, w'=0. For dirty work, the actual permutation remains defined but this arithmetic theorem does not apply. Compiler equality holds on all128 basis states, not only work0. Its scalar phase is5*(9pi/8)=45pi/8.

For the controlled-RY compiler, fix an entire non-target context z. All recursive instructions preserve z, even when two controls name the same wire. Let h be the first control and A=(theta0+theta1)/2, B=(theta0-theta1)/2. The compiled chronological blocks A,CX,B,CX have target product:
h=0: RY(B)RY(A)=RY(theta0);
h=1: X RY(B) X RY(A)=RY(A-B)=RY(theta1).
Induct on the remaining tuple length. Correlated/repeated controls only restrict the encountered contexts; they never invalidate the two identities. The only wire premise is each control!=target. The proof gives the whole matrix, both target input/output values and all dirty spectators, with no scalar phase. Counts solve y(k)=2y(k-1), x(k)=2x(k-1)+2, giving 2^k RY and2(2^k-1)CX.

P uses high h=2 arccos sqrt(4/7), middle angles pi/2 or2 arccos sqrt(2/3), low angle0 only at control tuple11 and pi/2 otherwise. It is a defined full eight-state unitary, not merely a prepared vector. The zero-input branching yields probabilities1/7 on0..6 and0 on7. These squared amplitudes alone suffice for LCU; a common phase premise is unnecessary. The eighth state is not deleted.

## 4. Tables, padded distinction and eight-wire stages

For each physical selector s, d_s=s xor3=(3,2,1,0,7,6,5,4), r_s(j)=j+d_s mod8, and W_sj=M[r_s(j),j]. For fixed j these eight rows are distinct; the omitted s=7 row j+4 has zero M entry. This proves sum_(s<7) [i=r_s(j)]W_sj=Mij. The displayed table directly supplies |W|<=32.

Two literal total coefficients must not be merged:
paper7 has c=W/32 for s<7 and c=1 for s=7;
Figure4 has c=W/32 on all eight selectors.
Thus their slot7 physical rotations are I and RY(pi), respectively. Only the subsequent zero-probability P contraction identifies their clean sums, not their entire matrices.

Eight-wire order: system0–2, selector3–5, coefficient6, work7. The inverse decoding (x6,(s,(j,x7))) is defined on all256 states. Six controls0–5 target6 give the entire paper7 R(c) block on coefficient, leaving work7 as spectator. P on5,4,3 lifts I_coeff tensor(P tensor I_(system,work)), and the dagger is exact on all work values.

Contextual eight-wire SELECT flips selector3,4, runs the fixed adder on system plus modified selector, then flips them back. Clean action is j->r_s(j), selector preserved, work restored. On dirty work the source's formulas follow directly from the adder: u=w xor b0a0, v2=a2 xor u a1, v1=a1 xor b0a0, followed by the displayed sum XORs. The loader's dirty-spectator theorem does not strengthen SELECT. No external final paper7 theorem is admitted here.

## 5. Figure4: every register and the coherent cleanup

Physical order: selector0–2, system3–5, coefficient6, indicator7, work8. Full decode is (x6,(s,(j,(x7,x8)))); T(s,j,a,i) explicitly sets work8=0. Clean final embeddings set selector=coefficient=indicator=work=0, with physical flat index8j.

The indicator circuit tests011 and100 in the three system bits. Each C3X has the needed eight clean guards. It toggles indicator by beta(j)=[j=3 or4], preserves every other logical input, and cleans work8, for either initial indicator. Its actual full permutation and actual Program dagger are used.

The bulk array is (0,-1,16,-30,16,-1,0,0)/32. W on columns3,4 equals this array. Bulk is controlled by indicator=1; boundary is controlled by indicator=0 AND not beta(j), on the entire specified table. On the reached indicator beta(j) exactly one relevant loader implements R(c_Fig4(s,j)); the other is identity. This is an equality of whole2x2 matrices, not of just the00 coefficient. Work8 and all non-target coordinates remain spectators.

DT first maps selector s to d_s with X0,X1, then adds the unchanged system j into selector, giving (r_s(j),j).
D first maps s to e_s=s+5 mod8: CCX(0,1;2),CX(0;1),X0 implement increment, and X2 adds4 modulo8. The adder then gives (j+e_s,j).
DT does not restore its address X gates. The swap is three physical SWAPs, nine CX.

On post-loader input T(s,j,b,beta(j)):
DT -> T(r_s(j),j,b,beta(j));
indicator dagger -> T(r_s(j),j,b,0), because system j has not changed;
swap -> T(j,r_s(j),b,0);
D dagger -> T(s,r_s(j),b,0).
The last step uses forward D on that claimed preimage and d_s+e_s=0 modulo8. Every step is valid on the shown clean-work state and for both b; no assumption on dirty-work D is needed.

For initial coefficient a, linearity applies this transcript to
sum_b R(c_sj)[b,a]T(s,j,b,beta(j)).
Therefore the whole clean middle is
B[(b,s,i,0,0),(a,t,j,0,0)]
= [s=t][i=r_t(j)]R(c_tj)[b,a].
This is the missing logical distinction that a bare basis-cleanliness statement could not supply. The source actually provides the additional loader argument, so I do not mark a remaining SOURCE_GAP here.

Prepare/middle/unprepare has matrix P-dagger B P, with each embedding understood explicitly. Projecting gives sum_s |P_s0|^2 [i=r_s(j)] W_sj/32=Mij/224. Full unitarity is established independently from primitive unitary factors, scalar unit modulus and reindexing.

Indicator phases cancel against its dagger. DT has5 CCX, D has6, D is daggered. Thus stored phase=(5-6)*9pi/8=-9pi/8. Consequently the bare primitive list has matrix exp(+i9pi/8) U_F, not U_F. This is not a source contradiction: the declared contract uses Programs and explicitly retains the scalar. It is a real physical/export boundary if one later emits only the list while advertising literal exact phase equality.

## 6. Signed-sector XOR route, with cyclic prerequisite kept separate

The pair bijection F(e,p)=p for e=0 and7-p for e=1 is realized physically by C=CX(2;1),CX(2;0) on raw bits(e,p). Its inverse is the same action. No free gate is gained from calling it a coordinate map.

With T_pq=M_pq, K_pq=M_(p,7-q), centrosymmetry gives pair matrix [[T,K],[K,T]]. Define M+=T+K, M-=T-K, with the complete source entries. Neither sector is required Hermitian.

The cyclic table V_e(s,p)=M_e[(p+s)mod4,p] defines bounded angles only. There is no complete cyclic SELECT/circuit; I give it no OR edge to the final target.
The actual XOR table is Z_e(s,p)=M_e[p xor s,p], distinct from V. Its coefficients Z/56 satisfy |Z|<=46<56.

Six-wire middle: pair0,1; sector2; selector3,4; coefficient5. Five controls0–4 target5 implement the full coefficient R(Z/56), evaluated before SELECT at input p. SELECT CX(3;0),CX(4;1) gives p->p xor s and preserves sector, selector, coefficient on the full carrier. P4 has uniform first-column probabilities1/4. Thus fixed sector clean block is
(1/4)sum_s [r=p xor s]Z_e(s,p)/56 = M_e[r,p]/224.
There is no cross-sector transition, and full middle unitarity is a separate product theorem.

Let S=[[c,-c],[c,c]] tensor I4, c=1/sqrt2. Direct multiplication gives
S diag(M+,M-) S-dagger
= [[(M++M-)/2,(M+-M-)/2],[(M+-M-)/2,(M++M-)/2]]
= [[T,K],[K,T]].
This works for arbitrary T,K; it does not require Hermiticity or commuting sectors.
Chronology S-dagger,middle,S is exactly the needed order. Replacing S by Hadamard without updating the rest changes the signed-sector convention.

Full chronology is C,S-dagger,P4,amplitude,SELECT,P4-dagger,S,C.
For an original-index input j, first C obtains F^{-1}(j); last C returns F of the output. Hence projected matrix is F [S diag(M+,M-)S-dagger] F^{-1}/224=M/224. This also fixes the apparently high-risk source adapter sentence: the original logical coordinate is F applied to the middle pair coordinate, not a second free physical C. Clean selector/coefficient are3–5=0; sector2 remains a system bit and is not projected out. The coordinate composition is defined on all64 states. Every emitted gate has phase0, so the Program is the literal list.

## 7. Generic conjugation quantifiers and binder audit

Q_c0,s0(U) is an entry restriction on arbitrary types C,S,H and chosen c0,s0. It requires no finite or DecEq instances and does not imply elements exist for empty C,S.

For lifts/products take Fintype and DecEq separately on C,S,H. V and U are arbitrary matrices, not unitary assumptions. L(V) entries are delta_ab delta_st V_ij. The adjoint has delta_ab delta_st conjugate(V_ji).

Left rectangular formula: for any finite K, A:(C x (S x H)) x K -> C, and k in K,
(L(V)A)[(c0,s0,i),k]=sum_r V_ir A[(c0,s0,r),k].
Right rectangular formula: for any finite R, A:R x (C x (S x H)) -> C,
(A L(V)-dagger)[r0,(c0,s0,j)]=sum_t A[r0,(c0,s0,t)]conjugate(V_jt).
Expand finite sums over (a,s,r); deltas force a=c0,s=s0. No equality test on K or R is used, although their Fintype assumptions are retained literally as specified. Taking appropriate rectangular A twice gives Q(Conj(V,U))=V Q(U) V-dagger with no unitarity premise. Separate implications need V unitary for L(V), and both V,U unitary for Conj(V,U). This is algebra, not a compiler for arbitrary V. These conceptual formulas are not asserted as actual XOR implementation imports.

Binder classification:
- SOURCE: the declared local guards, clean-work input where stated, arbitrary table/angles/controls, arbitrary rectangular types and chosen clean elements, explicitly conditional unitarity premises.
- STANDING: complex column semantics, exact real angles, fixed bit/order/phase conventions and resource recurrence.
- TYPING: q,k and Fin dimensions, finite/decidable instances exactly as stated; extra finite row/column instances are retained even when stronger than algebraically necessary.
- RULED: none introduced.
- EXCESS: none added to either fixed-target root. Normalization, loader bounds, P probabilities, cleanup, SELECT and refinement are outputs/dependencies, never caller hypotheses.

Definition classification:
Every displayed construction is literal on its declared carrier. R(c) is total but does not promise c as00 outside its bounded locus. Angle constructors contain validity evidence, supplied internally for fixed tables. The finite coordinate inverses are exhibited, so bijective packaging is not arbitrary choice. No characterized uniqueness proof or quotient/representative selection is needed. Programs retain actual scalar phase, not phase classes. Empty generic carriers cause no hidden positivity hypothesis.

## 8. Candidate schema, physical resources and proof boundaries

Candidate's free Props can be unrelated to matrix unitarity/target inclusion; VerifiedCandidate proves only those stored Props. Its name cannot certify arbitrary instances. For these concrete source instances the intended Props are actual unitary membership and explicit entry equations, supplied by the preceding routes. I independently reconstructed why those equations can hold; I did not inspect the actual stored terms. LayoutMatches is only signal+pure=a; it does not force layout.system=n or link resources/schedule/presentation circuit to the matrix.

Figure4 candidate: n=3,a=6, layout system3/signal4/pure2, actual nine-wire Program matrix. XOR: n=3,a=3, layout system3/signal3/pure0, logical64x64 matrix plus independent exact physical-list refinement. Both schedule=[] defaults are data, not executed schedules. Lossy legacy angle strings and omitted scalar phase cannot own the exact denotation.

List resource counts X/RY/RZ, CX, with oracleCalls=pureAncilla=0 by definition. Depth is the displayed touched-wire maximum recurrence under all-to-all logical gates. Program phase carries no extra resource charge. The independent re-emission in diagnostics.js gives:
PREPARE:7 one-qubit,8 CX,depth13;
adder:55,33,53;
XOR amplitude only:32,62,94;
whole XOR:38,68,96;
whole Figure4:427,454,674.
Figure4 subdivision is204RY+207RZ+16X and454CX. These are finite topology diagnostics, not kernel results, optimization bounds, hardware schedules, or bit-complexity theorems.

Figure4 physically needs two initially/finally clean wires7,8 despite Resource.pureAncilla=0. Coefficient plus three selector bits are the other four signal auxiliaries. XOR needs three signal auxiliary wires and no extra work; sector2 is system. Arbitrary exact-real and arccos/sqrt syntax is not a finite-bit data producer. Initialization, evaluation, readout, postselection and amplification remain uncharged.

## 9. Coverage, graph and root-closure status

source-coverage.json assigns each of414 source lines NODE or EXCLUDED(reason); blank lines, headings and standalone display delimiters alone are excluded. All substantive formulas, total tables, definitions, circuit/transcript steps, resources, qualifications and authority claims map to independent R nodes. The author N/G names do not determine my nodes or closure.

source-graph.json retains complete AND prerequisites and one OR at the matched projected target. The cyclic prerequisite is not a sufficient route. Generic conjugation is an independent algebra family, not an inferred Lean dependency. Metadata/definition/boundary leaves need no fabricated mathematical prerequisite. Missing implementation comparison, kernel execution, original-paper/PDE authentication, cyclic full circuit, external paper7 consumer, finite-bit implementation and independent topology acceptance are explicitly typed boundaries, not quietly erased source gaps.

No mathematical claim is retired. Failure class for the examined finite natural-source mathematics: NONE.
Unclosed source/formal certification gates: explicitly pending, not mathematical failure or environmental refutation.
Salvage: the generic UCR proof, C3X guard audit, coefficient-coherence argument, inverse-preimage cleanup and signed-sector identity are reusable natural-language fragments; none is promoted as compiled library memory.
Process-memory entries consulted: none; the sealed reading restriction excluded prior mathematical verdicts.
Parallel admission: parent-authorized independent raw-source recovery only; no children launched.
Default verified route/comparator: not selected; this review does not rank or certify implementation routes.
Purification/Exposition Seal: not claimed. This is a Stage1 packet for later distinct review.

Residual ambiguity: the exact mathematical carriers and proofs recover the local construction, but prose claims of actual field values, full module coverage and exact declaration signatures remain source assertions until formal comparison. A stronger demand for a literally exact Lean Statement Seal cannot be met from this restricted packet alone. That is B-FORMAL, not a reason to add convenient public premises or fabricate a verdict.

## 10. Supplied argument versus this review's derivations

The source directly supplies the CCX phase-polynomial argument, C3X work invariant, adder carry explanation, UCR context induction, selector probabilities, Figure4 clean transcript plus loader-coherence composition, LCU contractions, signed-sector identity, and rectangular delta-sum proof sketches. I reconstructed their logic independently rather than relying on historical N/G labels.

Several routine verifications are asserted or compressed in the source: reindexing preservation of products/adjoints, coordinate inverse checks, finite W/V/Z/sector table arithmetic, exact all-basis physical/logical adapter refinements, and evaluated resource depths. The source defines enough literal data to check them, but it does not print every summation, coordinate case, or scheduling trace. My derivations and finite diagnostic supply additional review evidence; they must not be relabeled as source-supplied Lean proofs. In particular the full formal-signature/module-completeness bridge is absent from this allowed source and remains B-FORMAL, not something the independent argument fills.

I find no unresolved mathematical ambiguity or missing substantive inference preventing the two fixed projected roots after this reconstruction. This is a judgment of recoverability and validity at the natural-mathematical layer, not a statement that every low-level proof was printed in the source. If the admission rule demands fully explicit source derivations of every routine finite trace or exact elaborated signature, request that additional source evidence; do not turn these assertions into caller hypotheses.


