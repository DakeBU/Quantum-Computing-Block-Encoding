function runDiagnostics() {
  const M=[[-30,32,-2,0,0,0,0,0],[16,-31,16,-1,0,0,0,0],[-1,16,-30,16,-1,0,0,0],[0,-1,16,-30,16,-1,0,0],[0,0,-1,16,-30,16,-1,0],[0,0,0,-1,16,-30,16,-1],[0,0,0,0,-1,16,-31,16],[0,0,0,0,0,-2,32,-30]];
  const W=[[0,0,0,0,0,0,0,0],[-1,-1,-1,-1,-1,-2,0,0],[16,16,16,16,16,16,32,0],[-30,-31,-30,-30,-30,-30,-31,-30],[0,32,16,16,16,16,16,16],[0,0,-2,-1,-1,-1,-1,-1],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]];
  const Z=[ [[-30,-31,-30,-14],[16,32,15,15],[-1,-1,-2,-1],[0,16,16,0]], [[-30,-31,-30,-46],[16,32,17,17],[-1,-1,-2,-1],[0,16,16,0]] ];
  const V=[ [[-30,-31,-30,-14],[16,16,15,0],[-1,-1,-2,-1],[0,32,16,15]], [[-30,-31,-30,-46],[16,16,17,0],[-1,-1,-2,-1],[0,32,16,17]] ];
  const d=[3,2,1,0,7,6,5,4], e=[5,6,7,0,1,2,3,4];
  let checks=0;
  function eq(a,b,label){checks++; if(a!==b)throw Error(label+": "+a+" != "+b);}
  for(let i=0;i<8;i++)for(let j=0;j<8;j++){eq(M[i][j],M[7-i][7-j],"centrosymmetry");let sum=0;for(let s=0;s<7;s++)if(i===(j+d[s])%8)sum+=W[s][j];eq(sum,M[i][j],"seven-slot contraction numerator");}
  for(let s=0;s<8;s++)for(let j=0;j<8;j++){eq(W[s][j],M[(j+d[s])%8][j],"W lookup");eq((j+d[s]+e[s])%8,j,"DT/D inverse");if(j===3||j===4)eq(W[s][j],[0,-1,16,-30,16,-1,0,0][s],"bulk table");}
  for(let sec=0;sec<2;sec++)for(let p=0;p<4;p++)for(let s=0;s<4;s++){const rX=p^s,rC=(p+s)%4,sign=sec===0?1:-1;eq(Z[sec][s][p],M[rX][p]+sign*M[rX][7-p],"XOR sector table");eq(V[sec][s][p],M[rC][p]+sign*M[rC][7-p],"cyclic sector table");}
  const bits=(n,q)=>Array.from({length:q},(_,k)=>(n>>k)&1), val=(a)=>a.reduce((s,b,k)=>s+(b<<k),0);
  const X=t=>["X",t], CX=(a,t)=>["CX",a,t], CC=(a,b,t)=>["CC",a,b,t];
  function act(a,gs){a=a.slice();for(const g of gs){if(g[0]==="X")a[g[1]]^=1;if(g[0]==="CX")a[g[2]]^=a[g[1]];if(g[0]==="CC")a[g[3]]^=a[g[1]]&a[g[2]];}return a;}
  function ad(a,b,w){return [CC(b[0],a[0],w),CC(w,a[1],a[2]),CC(b[0],a[0],w),CC(b[0],a[0],a[1]),CX(b[0],a[0]),CC(b[1],a[1],a[2]),CX(b[1],a[1]),CX(b[2],a[2])];}
  function c3(a,b,c,t,w){return [CC(a,b,w),CC(w,c,t),CC(a,b,w)];}
  const ind=[X(5),...c3(3,4,5,7,8),X(5),X(3),X(4),...c3(3,4,5,7,8),X(4),X(3)];
  const dt=[X(0),X(1),...ad([0,1,2],[3,4,5],8)];
  const da=[CC(0,1,2),CX(0,1),X(0),X(2),...ad([0,1,2],[3,4,5],8)];
  const sw=[CX(0,3),CX(3,0),CX(0,3),CX(1,4),CX(4,1),CX(1,4),CX(2,5),CX(5,2),CX(2,5)];
  for(let n=0;n<128;n++){const a=bits(n,7);if(a[6]===0){const b=act(a,ad([0,1,2],[3,4,5],6));eq(val(b.slice(0,3)),(val(a.slice(0,3))+val(a.slice(3,6)))%8,"adder");eq(val(b.slice(3)),val(a.slice(3)),"preserved operand and work");}}
  for(let s=0;s<8;s++)for(let j=0;j<8;j++)for(let a=0;a<2;a++)for(let i=0;i<2;i++){
    const v=[...bits(s,3),...bits(j,3),a,i,0], out=act(v,ind);
    eq(val(out.slice(0,7)),val(v.slice(0,7)),"indicator preserved");eq(out[7],i^(j===3||j===4?1:0),"indicator value");eq(out[8],0,"indicator work");
    if(i===0){const transcript=act(v,[...ind,...dt,...ind.slice().reverse(),...sw,...da.slice().reverse()]);eq(val(transcript),val([...bits(s,3),...bits((j+d[s])%8,3),a,0,0]),"postloader coherent-basis transcript");}
  }
  let aliasCases=0;
  for(let a=0;a<5;a++)for(let b=0;b<5;b++)for(let c=0;c<5;c++)for(let t=0;t<5;t++)for(let w=0;w<5;w++){
    if(a===b||a===w||b===w||w===c||w===t||c===t||a===t||b===t)continue;
    for(let n=0;n<32;n++){let v=bits(n,5);if(v[w])continue;let z=act(v,c3(a,b,c,t,w)),expected=v.slice();expected[t]^=v[a]&v[b]&v[c];eq(val(z),val(expected),"eight-guard C3X with alias controls");aliasCases++;}
  }
  const G=(k,...w)=>({k,w}), x=t=>G("X",t), y=t=>G("RY",t), z=t=>G("RZ",t), cx=(a,b)=>G("CX",a,b);
  function cc(a,b,t){return [z(t),y(t),cx(b,t),z(t),cx(a,t),z(t),cx(b,t),z(t),cx(a,t),z(b),z(t),cx(a,b),z(a),z(b),cx(a,b),z(t),y(t)];}
  function c3p(a,b,c,t,w){return [...cc(a,b,w),...cc(w,c,t),...cc(a,b,w)];}
  function add(a,b,w){return [...cc(b[0],a[0],w),...cc(w,a[1],a[2]),...cc(b[0],a[0],w),...cc(b[0],a[0],a[1]),cx(b[0],a[0]),...cc(b[1],a[1],a[2]),cx(b[1],a[1]),cx(b[2],a[2])];}
  function ucr(c,t){if(!c.length)return [y(t)];const [h,...tail]=c;return [...ucr(tail,t),cx(h,t),...ucr(tail,t),cx(h,t)];}
  function prep(a){return [y(a[2]),...ucr([a[2]],a[1]),...ucr([a[1],a[2]],a[0])];}
  function res(gs,q){let ds=Array(q).fill(0),ns={RY:0,RZ:0,X:0,CX:0};for(const g of gs){ns[g.k]++;let v=1+Math.max(...g.w.map(k=>ds[k]));for(const w of g.w)ds[w]=v;}return {...ns,oneQubit:ns.RY+ns.RZ+ns.X,cnot:ns.CX,total:gs.length,depth:Math.max(0,...ds),wireDepth:ds};}
  const p=prep([0,1,2]),amp=ucr([0,1,2,3,4],5),co=[cx(2,1),cx(2,0)],p4=[y(3),y(4)];
  const xp=[...co,y(2),...p4,...amp,cx(3,0),cx(4,1),...p4.slice().reverse(),y(2),...co];
  const ip=[x(5),...c3p(3,4,5,7,8),x(5),x(3),x(4),...c3p(3,4,5,7,8),x(4),x(3)];
  const dtp=[x(0),x(1),...add([0,1,2],[3,4,5],8)],dap=[...cc(0,1,2),cx(0,1),x(0),x(2),...add([0,1,2],[3,4,5],8)];
  const swp=sw.map(g=>cx(g[1],g[2]));
  const fp=[...p,...ip,...ucr([0,1,2,7],6),...ucr([0,1,2,3,4,5,7],6),...dtp,...ip.slice().reverse(),...swp,...dap.slice().reverse(),...p.slice().reverse()];
  return {evidenceClass:"Finite exact integer/bit and gate-topology diagnostic, not a Lean result or arbitrary-width proof.",checks,aliasCases,prepare:res(p,3),adder:res(add([0,1,2],[3,4,5],6),7),xorAmplitude:res(amp,6),xor:res(xp,6),figure4:res(fp,9),notes:["Resource transcription retains gate order and reversed daggers, but deliberately omits angle signs: they do not affect touched-wire depth.","No floating-point matrix calculation and no claim of generic compiler verification.","Phase calculations are analytic in reconstruction.md, not tested by this topology-only diagnostic."]};
}
if (typeof module !== "undefined" && require.main === module) console.log(JSON.stringify(runDiagnostics(),null,2));

