"""Read-only Stage6 binding/coverage association checks, no Lean or repository writes.
The prospective lesson/source object is overlaid in memory only.
Unrelated local Lean bytes are hashed, never interpreted or emitted.
"""
import sys,json,hashlib,re
from pathlib import Path
def sha(x):return hashlib.sha256(x).hexdigest()
def j(p):return json.loads(p.read_bytes())
KEYS=('module','source_id','source_statement','source_anchor','lesson_path','declarations','obligation_map','assumption_deltas','graph_contribution','formalizer','residual_boundary')
def canonical(x):return json.dumps(x,sort_keys=True,ensure_ascii=False).encode()
def main():
    w=Path(sys.argv[1]);r=Path(sys.argv[2]);control_dir=w/'c60-robin-selected-final-review'
    control=j(control_dir/'review-control.json')
    assert sha((control_dir/'review-control.json').read_bytes())=='b4d7ab9ff0b2322c7d3643193481b059042840e2fc6a68ac49be1e6e7f159776'
    assert sha((w/'robin-c47-signature-stage5'/'seal.json').read_bytes())=='40cfd9a24909ff5654b604aac08a471919907f547f88db401c58a2f02ffbe06b'
    records=j(control_dir/'selected-nine-records.json')['records'];source=j(control_dir/'selected-local-source-row.json')
    assert len(records)==9
    assert sha((control_dir/'selected-nine-records.json').read_bytes())==control['selected_nine_records_sha256']
    assert sha((control_dir/'selected-local-source-row.json').read_bytes())==control['selected_source_row_sha256']
    lesson=(w/'robin-nine-c46-natural-source-v2-author'/'natural-source-v2.md').read_bytes()
    assert sha(lesson)==source['source_sha256']==source['lesson_sha256']==control['source_sha256']
    baseline=j(w/'robin-c47-source-formal-stage4'/'module-declaration-coverage.json')['modules']
    bm={x['path'].split('/formal-only/')[1]:x for x in baseline}
    c54=w/'c54-selected-publication-freeze';freeze=j(c54/'selected-records.json')['records']
    assert sha((c54/'seal.json').read_bytes())==control['parent_freeze_sha256']
    assert source==next(x for x in j(c54/'selected-source-rows.json')['rows'] if x['id']==source['id'])
    frozen={x['module']:x for x in freeze if x['module'] in {z['module'] for z in records}}
    pins=j(c54/'raw-context-pins.json')['files']
    expected={x['path']:x for x in pins}
    raw={}
    for x in pins:
        data=(r/x['path']).read_bytes()
        assert sha(data)==x['sha256'] and len(data)==x['bytes']
        raw[x['path']]=data
    directories=[]
    for dirname in ('QuantumBlockEncoding','ABEISTests'):
        directories+=sorted((r/dirname).rglob('*.lean'))
    leannames=[p.relative_to(r).as_posix() for p in directories]
    assert len(leannames)==202
    assert set(expected)==set(leannames)|{'lean-toolchain','lakefile.lean','lake-manifest.json'}
    # Exactly the production binding formula, but in-memory selected source/lesson.
    dm={x['module']:x for x in control['decoder_wrappers']}
    author_map=j(w/'robin-c52-prospective-publication'/'declaration-source-map.json')
    author_inv=j(w/'robin-c52-prospective-publication'/'whole-public-inventories.json')
    source_graph=j(w/'robin-c50-select-context-topology-successor'/'source-graph-v4-proposal.json')
    assert sha((w/'robin-c50-select-context-topology-successor'/'source-graph-v4-proposal.json').read_bytes())=='eb559adfcb49ed3760de99f28a9cc1b7baebf480927a867cdce3d684ad877e18'
    authorpub={x['fullName']:x for x in author_map['records'] if x.get('public_inventory')}
    authorinv={x['module']:{a['fullName'] for a in x['declarations']} for x in author_inv['modules']}
    private=[x for x in author_map['records'] if x.get('private')]
    ambient=[x for x in author_map['records'] if x['kind']=='ambient']
    assert len(authorpub)==214 and len(private)==1 and len(ambient)==53
    assert private[0]['name']=='transportInput_eq_encode' and private[0]['module']=='QuantumBlockEncoding/Robin/Figure4T3.lean'
    private_own=next(x for x in bm[private[0]['module']]['declarations'] if x['private'])
    assert private[0]['signature']==private_own['actualSourceHeader']
    assert private[0]['source_sections']==[{'id':'A7','lines':[188,269]}]
    source_ids={n['id'] for n in source_graph['nodes']}
    assert len(source_ids)==74
    resultrows=[];obligationrows=[]
    for rec in records:
        module=rec['module'];base=bm[module]
        assert {k:rec[k] for k in KEYS}=={k:frozen[module][k] for k in KEYS}
        assert rec['source_id']==source['id'] and rec['lesson_path']==source['lesson_path']
        assert rec['formalizer']==rec['historical_formalizer']=='UNKNOWN'
        assert not rec['statement_seal']['pre_proof_seal_claim']
        pub={x['qualifiedSourceName']:x for x in base['declarations'] if not x['private']}
        assert set(rec['declarations'])==set(pub)==authorinv[module]
        assert len(rec['declarations'])==len(set(rec['declarations']))==len(rec['obligation_map'])
        mapped=[]
        for o in rec['obligation_map']:
            assert len(o['declarations'])==1
            name=o['declarations'][0];mapped.append(name);own=pub[name];proposal=authorpub[name]
            assert o['exact_decl_header']==own['actualSourceHeader']==proposal['signature']
            assert o['source_sections']==proposal['source_sections']
            assert o['source_node_ids']==proposal['source_node_ids']
            assert set(o['source_node_ids']) <= source_ids
            assert o['source_obligation']==proposal['id']+': '+proposal['source_obligation']
            assert o['kind']==proposal['role']
            assert o['source_or_formal_approval'] is False
            obligationrows.append({'module':'R/'+module,'declaration':name,
                'exactHeaderMatchesIndependentStage4':True,'sourceSections':o['source_sections'],
                'sourceNodeIds':o['source_node_ids'],'semanticKind':o['kind'],
                'sourceObligationId':proposal['id'],'semanticComparison':'Own source/formal comparison agrees at the stated local construction scope; role labels distinguish literal prerequisites from proof edges, not caller hypotheses.'})
        assert set(mapped)==set(pub) and len(mapped)==len(set(mapped))
        digest=hashlib.sha256(canonical({k:rec.get(k) for k in KEYS}))
        for name in (module,rec['lesson_path'],'lean-toolchain','lake-manifest.json'):
            digest.update(name.encode());digest.update(lesson if name==rec['lesson_path'] else raw[name])
        for path in directories:
            name=path.relative_to(r).as_posix();digest.update(name.encode());digest.update(raw[name])
        digest.update(canonical(source));actual=digest.hexdigest()
        assert actual==rec['binding_sha256']==frozen[module]['binding_sha256']
        e=dm[module];wrapper_file=w/'robin-c49-signature-successor-c57'/Path(e['path']).name
        wrapper_raw=wrapper_file.read_bytes();wrapper=json.loads(wrapper_raw)
        assert sha(wrapper_raw)==e['sha256']
        assert (r/e['path']).read_bytes()==wrapper_raw
        assert wrapper['role']=='decoder' and wrapper['identity']=='/root/robin_c49_current_formal_decoder'
        assert wrapper['module']==module and wrapper['binding_sha256']==actual
        bound11=sha(canonical({k:rec.get(k) for k in KEYS}))
        assert bound11==wrapper['opaque_bound11field_sha256']
        assert sha(raw[module])==wrapper['current_raw_module_sha256']
        assert (r/wrapper['packet_path']).read_bytes()==(w/'robin-c49-signature-successor-c57'/'packet.json').read_bytes()
        assert (r/wrapper['artifact_path']).read_bytes()==(w/'robin-c49-signature-successor-c57'/'reconstruction.md').read_bytes()
        assert sha((r/wrapper['packet_path']).read_bytes())==wrapper['packet_sha256']
        assert sha((r/wrapper['artifact_path']).read_bytes())==wrapper['artifact_sha256']
        nav=j(w/'robin-c52-prospective-publication'/'graph-views.json')['lean_import_navigation']
        navrow=next(z for z in nav['modules'] if z['path']==module)
        assert navrow['imports']==[a['command'].removeprefix('import ') for a in base['ambientRegions'] if a['command'].startswith('import ')]
        assert navrow['raw_sha256']==sha(raw[module])
        ownambient=[a['command'] for a in base['ambientRegions']]
        mapambient=[a['signature'] for a in ambient if a['module']==module]
        assert ownambient==mapambient
        graph=rec['graph_contribution']
        assert graph['source_graph_sha256']=='eb559adfcb49ed3760de99f28a9cc1b7baebf480927a867cdce3d684ad877e18'
        # Node IDs are explicitly complete inventory/navigation, not a dependency claim.
        declaration_ids={x for x in graph['node_ids'] if x.startswith('declaration:')}
        assert declaration_ids=={'declaration:'+name for name in pub}
        assert {x for x in graph['node_ids'] if x.startswith('source:')}=={'source:'+n for n in source_ids}
        resultrows.append({'module':'R/'+module,'binding_sha256':actual,
            'bound11field_sha256':bound11,'all11FieldsEqualC54':True,'publicDeclarations':len(pub),
            'privateDeclarations':sum(x['private'] for x in base['declarations']),
            'ambientCommands':len(ownambient),'obligationBijection':True,
            'allActualHeadersExact':True,'selectedRowAndLessonExact':True,
            'bindingIndependentlyRecomputed':True,'rawModuleSha256':sha(raw[module]),
            'decoderPath':'R/'+e['path'],'decoder_evidence_sha256':sha(wrapper_raw),
            'decoderRoleIdentityBindingAndPayloadsExact':True,
            'C57WrapperExactInR':True,'literalImportNavigationMatches':True,
            'futureReviewerEvidencePath':'R/'+rec['reviewer_evidence']})
    assert len(obligationrows)==214
    inputpins=[]
    paths=[control_dir/'review-control.json',control_dir/'selected-nine-records.json',control_dir/'selected-local-source-row.json',
       c54/'seal.json',c54/'selected-records.json',c54/'selected-source-rows.json',c54/'raw-context-pins.json',
       w/'robin-c47-signature-stage5'/'seal.json',
       w/'robin-c47-source-formal-stage4'/'seal.json',
       w/'robin-c47-source-formal-stage4'/'module-declaration-coverage.json',
       w/'robin-c47-source-topology-stage3'/'typed-findings.json',
       w/'robin-c52-prospective-publication'/'declaration-source-map.json',
       w/'robin-c52-prospective-publication'/'whole-public-inventories.json',
       w/'robin-c52-prospective-publication'/'graph-views.json',
       w/'robin-c50-select-context-topology-successor'/'source-graph-v4-proposal.json',
       w/'robin-nine-c46-natural-source-v2-author'/'natural-source-v2.md']
    paths += [w/'robin-c49-signature-successor-c57'/Path(e['path']).name for e in control['decoder_wrappers']]
    for p in paths:
        data=p.read_bytes();inputpins.append({'path':'W/'+p.relative_to(w).as_posix(),'sha256':sha(data),'bytes':len(data)})
    result={'schema':'stage6-independent-selected-association-checks-v1',
       'reviewer':'/root/robin_c47_raw_source_recovery','run_id':'robin-c47-metadata-stage6',
       'stage5AcceptedBeforeMetadataAccess':True,
       'records':resultrows,'obligationCoverage':obligationrows,'inputPins':inputpins,
       'context':{'currentLeanFilesHashOnly':len(leannames),'configPinsHashOnly':3,'all205RawPinsMatch':True,
          'bindingAlgorithm':'Python default JSON separators, sort_keys=True, ensure_ascii=False;11fields; ordered(module,lesson,toolchain,lake-manifest) names+rawbytes; orderedtwo directories/sortedLean pathnames+rawbytes; exact selectedsourceobject JSON. lakefile is contextual pin, not direct binding input.',
          'overlay':'Only selected lesson bytes/source object substituted in memory. No filesystem overlay/publication integration.',
          'rawPrivateOverlayPublished':False,'other39Bindings':'Parent prior result not independently replayed here; no preservation theorem claimed.'},
       'coverage':{'public':214,'private':1,'ambient':53,'explicit':215},
       'limits':'Read-level semantic association, not compiler/kernel/generatedname/TCB/scientific/finitebit/reader/integration/PURIFIED admission.'}
    print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':main()

