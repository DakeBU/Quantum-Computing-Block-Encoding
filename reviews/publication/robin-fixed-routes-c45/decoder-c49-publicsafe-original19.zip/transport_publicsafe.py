"""Actor-owned transport-only successor. No mathematical source rewriting.

Run with explicit --workspace-root and --repository-root locations locally.
Only own sealed original artifacts are read. No original artifact is edited.
The public output contains logical W/ and R/ identifiers, never local roots.
"""
from pathlib import Path
import argparse, ast, hashlib, json, re

ORIGINAL='robin-c49-current-formal-decoder'
SUCCESSOR='robin-c49-publicsafe-successor'
SEAL='5d1dd69afe8b91764cc7fadf189ec66d1bb9c8d95885e34c4f53fa7ad091cb46'
MANIFEST='4fdd79b7bcf090b9531e1b5a9a71a69e8cb12722ef3454ac69a7e44d653184db'
RECON='ebd11e8da0663f9ddb46eba785c72437d382303cc10aa7155112419f6e8dc167'

def digest(data): return hashlib.sha256(data).hexdigest()
def json_bytes(value): return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--workspace-root',required=True)
    ap.add_argument('--repository-root',required=True)
    args=ap.parse_args()
    workspace=Path(args.workspace_root).resolve()
    repository=Path(args.repository_root).resolve()
    old=workspace/ORIGINAL
    out=Path(__file__).resolve().parent
    assert out.name==SUCCESSOR and out.parent==workspace
    assert not (out/'seal.json').exists(), 'Refuse overwriting sealed successor'
    original_allow=json.loads((old/'publicsafe-allowlist.json').read_bytes())['files']
    original_manifest=json.loads((old/'manifest.json').read_bytes())
    assert digest((old/'seal.json').read_bytes())==SEAL
    assert digest((old/'manifest.json').read_bytes())==MANIFEST
    assert digest((old/'reconstruction.md').read_bytes())==RECON
    old_pins={name:digest((old/name).read_bytes()) for name in original_allow}
    for entry in original_manifest['artifacts']:
        assert old_pins[entry['file']]==entry['sha256']

    # Explicit negative finding: the old package claimed two different sets.
    manifest_set=set(original_manifest['publicsafeAllowlist'])
    artifact_set={x['file'] for x in original_manifest['artifacts']}
    assert manifest_set==artifact_set and len(manifest_set)==13
    assert len(set(original_allow))==15
    assert set(original_allow)-manifest_set=={'manifest.json','seal.json'}
    root_pairs=[(str(workspace).replace('\\','/'),'W/'),
                (str(repository).replace('\\','/'),'R/')]
    mapping=[]
    def transport(value,pointer='',key=None):
        if isinstance(value,dict):
            return {k:transport(v,pointer+'/'+k,k) for k,v in value.items()}
        if isinstance(value,list):
            return [transport(v,pointer+'/'+str(i),key) for i,v in enumerate(value)]
        if isinstance(value,str) and key=='path':
            posix=value.replace('\\','/')
            for root,logical in root_pairs:
                if posix.startswith(root+'/'):
                    converted=logical+posix[len(root)+1:]
                    mapping.append({'jsonPointer':pointer,'oldValueSha256':digest(value.encode()),
                                    'newValue':converted})
                    return converted
        return value

    excluded={'build_packet.py','manifest.json','seal.json','publicsafe-allowlist.json'}
    expected_changed={'source-blind-packet.json','input-pins-pre.json',
                      'input-pins-post.json','input-pins-final.json'}
    deltas=[]
    original_scans=[]
    runner_prefix='/'.join(('', 'home', 'runner'))
    unsafe=re.compile(r'[A-Za-z]:[\\/]|'+re.escape(runner_prefix)+r'|(?:^|[\\/])Users[\\/]',re.I)
    # Value-pattern checks, not deletion of mathematical words such as "secretly".
    credentials=re.compile(r'(?:sk-[A-Za-z0-9_-]{16,}|gh[pousr]_[A-Za-z0-9]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)',re.I)
    def strings(value,pointer=''):
        if isinstance(value,dict):
            for k,v in value.items():
                yield pointer+'/key',k
                yield from strings(v,pointer+'/'+k)
        elif isinstance(value,list):
            for i,v in enumerate(value): yield from strings(v,pointer+'/'+str(i))
        elif isinstance(value,str): yield pointer,value
    def inspect(name,data):
        text=data.decode('utf-8-sig')
        checks=[('$raw',text)]
        if name.endswith('.json'): checks+=list(strings(json.loads(text)))
        elif name.endswith('.py'):
            tree=ast.parse(text)
            checks += [('pythonLiteral',n.value) for n in ast.walk(tree)
                       if isinstance(n,ast.Constant) and isinstance(n.value,str)]
        return [(pointer,'localPath' if unsafe.search(s) else 'credential')
                for pointer,s in checks if unsafe.search(s) or credentials.search(s)]
    for name in original_allow:
        data=(old/name).read_bytes()
        found=inspect(name,data)
        original_scans.append({'file':'W/'+ORIGINAL+'/'+name,'sha256':digest(data),
                               'findingKinds':sorted({kind for _,kind in found}),
                               'findingLocations':[p for p,_ in found],
                               'stringPayloadsRecursivelyInspected':True})
        if name in excluded:
            deltas.append({'oldFile':'W/'+ORIGINAL+'/'+name,'oldSha256':digest(data),
              'oldBytes':len(data),'disposition':'EXCLUDED_ORIGINAL_RETAINED_UNCHANGED',
              'reason':'private-location script' if name=='build_packet.py' else 'superseded control object; original bindings retained hash-only'})
            continue
        new=data
        if name.endswith('.json'):
            mapping_start=len(mapping)
            value=json.loads(data)
            updated=transport(value)
            # Reserialize only objects with an actual authorized path change.
            if value != updated:
                new=json_bytes(updated)
                for row in mapping[mapping_start:]: row['file']=name
        assert (data!=new)==(name in expected_changed), 'Unexpected transport delta'
        assert not inspect(name,new), 'Unsafe payload after narrow transport'
        (out/name).write_bytes(new)
        deltas.append({'oldFile':'W/'+ORIGINAL+'/'+name,'newFile':'W/'+SUCCESSOR+'/'+name,
          'oldSha256':digest(data),'newSha256':digest(new),'oldBytes':len(data),'newBytes':len(new),
          'disposition':'PATH_VALUES_ONLY' if data!=new else 'BYTEIDENTICAL'})

    # Verify input digests/sizes and all non-path values survived recursively.
    def compare(a,b):
        if isinstance(a,dict):
            assert set(a)==set(b)
            for k in a:
                if k=='path' and isinstance(a[k],str) and a[k]!=b[k]:
                    assert b[k].startswith(('W/','R/'))
                else: compare(a[k],b[k])
        elif isinstance(a,list):
            assert len(a)==len(b)
            for x,y in zip(a,b):compare(x,y)
        else: assert a==b
    for name in expected_changed:
        compare(json.loads((old/name).read_bytes()),json.loads((out/name).read_bytes()))
    assert (out/'reconstruction.md').read_bytes()==(old/'reconstruction.md').read_bytes()
    assert (out/'declaration-inventory.json').read_bytes()==(old/'declaration-inventory.json').read_bytes()

    (out/'path-transport-map-v1.json').write_bytes(json_bytes({
      'version':1,'logicalRoots':{'W/':'workspace-relative identifier; local root deliberately absent',
                                'R/':'production-repository-relative identifier; local root deliberately absent'},
      'method':'only JSON path string values rooted at the two explicit invocation locations; no source/signature/String blanket scrub',
      'oldValues':'hash-only for privacy; originals remain sealed and unchanged',
      'replacements':mapping}))
    (out/'origin-binding.json').write_bytes(json_bytes({
      'origin':'W/'+ORIGINAL+'/', 'originalSealSha256':SEAL,'originalManifestSha256':MANIFEST,
      'originalReconstructionSha256':RECON,
      'historicalFormalizer':'UNKNOWN','actor':'/root/robin_c49_current_formal_decoder',
      'newAction':'PUBLICSAFE transport-only successor; not mathematical reconstruction revision',
      'finding':'PUBLICATION_PRIVACY_FAILURE_RETAINED_NOT_MATH_REFUTATION',
      'originalManifestCount':13,'originalStandaloneAllowlistCount':15,
      'originalSetConflict':'manifest publicsafeAllowlist/artifacts were 13 payloads; standalone allowlist was 15 by additionally naming manifest.json and seal.json. The names publicsafeAllowlist/files therefore did not denote one exact set.',
      'originalsImmutable':True,'excludedOriginals':sorted(excluded),
      'scriptSuccessor':'transport_publicsafe.py is new actor-owned transport-only code; it is not claimed to reproduce Lean capture, proof checks, or the original build script',
      'noNewApproval':'No source/comparison, compiler, native tactic, publication admission or mathematical approval is upgraded',
      'publicationDigest':'NOT_SUPPLIED_NO_BINDING_WRAPPER_CREATED'}))
    (out/'privacy-delta-v1.json').write_bytes(json_bytes({
      'version':1,'finding':'ACTUAL_PUBLICATION_PRIVACY_FAILURE',
      'originalArtifactScan':original_scans,'artifactDeltas':deltas,
      'changedPayloads':sorted(expected_changed),'pathValueReplacementCount':len(mapping),
      'preserved':'every non-path JSON value, including every raw input SHA256/size; reconstruction/signatures/body captures byte-identical',
      'inspectionLimits':'credential value patterns and literal recursive scans are not an omniscient secret detector; no candidate credential value found',
      'classification':'privacy/transport correction, not mathematical refutation or new source verdict'}))

    # Inventory the exact public universe once. All three control files name the
    # same universe; self/cross bindings avoid impossible self-hash cycles.
    controls={'publicsafe-allowlist.json','manifest.json','seal.json','privacy-checks.json'}
    files=sorted({p.name for p in out.iterdir() if p.is_file()} | controls)
    def scan_out():
        scan=[]
        for name in sorted(p.name for p in out.iterdir() if p.is_file()):
            data=(out/name).read_bytes()
            findings=inspect(name,data)
            assert not findings, 'Public successor scan failed: '+name
            scan.append({'file':name,'sha256':digest(data),'bytes':len(data),
                         'recursiveStringInspection':True,'privatePathOrCredentialPatternFound':False})
        return scan
    before=scan_out()
    checks={'status':'ACTOR_CHECKED_PUBLICSAFE_TRANSPORT_NOT_INDEPENDENT_APPROVAL',
      'originalAllowlistedObjectsInspected':len(original_allow),
      'originalManifest13VsAllowlist15ConflictRetained':True,
      'originalSealManifestAndAllAllowlistedBytesStable':True,
      'reconstructionByteIdentical':True,'sourceSignatureAndBodyCapturesByteIdentical':True,
      'allNonPathJsonValuesPreserved':True,'replacementCount':len(mapping),
      'unsafeOriginalScriptExcluded':True,'actorOwnedTransportScriptInspectedAsPythonAST':True,
      'scannedPayloadsBeforeControls':before,
      'controlObjectsScannedAfterAssembly':True,
      'scanner':'recursive JSON keys/values, Python AST String literals, and raw UTF-8 text; local absolute-path and credential-value patterns',
      'noApprovalUpgrade':True}
    (out/'privacy-checks.json').write_bytes(json_bytes(checks))
    (out/'publicsafe-allowlist.json').write_bytes(json_bytes({
      'version':1,'files':files,'exactSetIncludesControls':True,
      'hashBindingRule':'manifest hashes all files except manifest and seal; seal hashes manifest; allowlist exact set is identical in every control'}))
    entries=[{'file':name,'sha256':digest((out/name).read_bytes()),'bytes':(out/name).stat().st_size}
             for name in files if name not in {'manifest.json','seal.json'}]
    (out/'manifest.json').write_bytes(json_bytes({'version':1,'publicsafeAllowlist':files,
      'artifacts':entries,'hashExcludedControls':['manifest.json','seal.json'],
      'exclusionMeaning':'excluded from recursive hash list only, not excluded from exact public allowlist',
      'originalSealSha256':SEAL,'originalManifestSha256':MANIFEST}))
    (out/'seal.json').write_bytes(json_bytes({'version':1,
      'status':'PUBLICSAFE_TRANSPORT_SUCCESSOR_SEALED_NO_APPROVAL_UPGRADE',
      'publicsafeAllowlist':files,'manifestSha256':digest((out/'manifest.json').read_bytes()),
      'originalSealSha256':SEAL,'originalManifestSha256':MANIFEST,
      'reconstructionSha256':RECON,'originalNegativeFinding':'PUBLICATION_PRIVACY_FAILURE',
      'actor':'/root/robin_c49_current_formal_decoder','historicalFormalizer':'UNKNOWN',
      'publicationDigest':'NOT_SUPPLIED_NO_BINDING_WRAPPER_CREATED',
      'comparison':'NOT_PERFORMED'}))
    assert sorted(p.name for p in out.iterdir() if p.is_file())==files
    scan_out()
    assert old_pins=={name:digest((old/name).read_bytes()) for name in original_allow}
    print(json.dumps({'fileCount':len(files),'pathReplacements':len(mapping),
      'sealSha256':digest((out/'seal.json').read_bytes()),
      'manifestSha256':digest((out/'manifest.json').read_bytes()),
      'reconstructionSha256':RECON,'originalBytesUnchanged':True,
      'exactPublicSet':files}))

if __name__=='__main__': main()
