# Source-blind packet / read chronology

This sequence is reconstructed from the current worker's tool transcript;
individual read calls did not record wall-clock timestamps. It is not a claim
that the pre-reconstruction pin existed before the first input read.

1. Read repository AGENTS.md, HARNESS.md and substantive-worker SKILL.md. A
   combined output was truncated inside HARNESS; HARNESS was reread separately
   through EOF. Read theorem-publication protocol separately through EOF.
   Read proof-digestion and evidence-routed-memory protocols; proof-digestion
   was reread separately through EOF after a combined-output truncation.
   Announced the substantive-worker skill. Repository formal-source-only
   restrictions override the general source-reading/build permissions of that
   skill. Parent had performed safe fetch; worker made no Git operation.
2. Listed only file names/lengths of allowed formal snapshot, config and provider
   directories. Read ModularAdder3.lean through EOF.
3. Read Figure4PreparePrimitive, Figure4T3, PaperSevenAmplitudePrimitive,
   PaperSevenPrepare, PaperSevenPreparePrimitive, SymmetryFourSlotPrimitive,
   SymmetryXorFourSlotPrimitive, SystemConjugation through EOF, in that order.
4. First current-production raw-hash check: all nine raw mismatches retained.
   Read only formal config lean-toolchain, lakefile.lean and manifest through
   EOF. Asked parent for bounded normalization authority rather than reading
   production natural prose. The first PowerShell hash command had a syntax
   error (an empty pipe after foreach); it had no successful hash output and
   was corrected without mutation.
5. Read provider projections through EOF in these groups, in order:

   - PrimitiveCircuit, Resources, ReversibleClassical, PrimitiveRefinement;
   - PrimitiveSemantics;
   - PrimitiveMacros;
   - PrimitiveBasisLE, UniformlyControlledRy;
   - Robin/ComplexLCU;
   - Robin/ComplexLCUProjection, Robin/SymmetryXorFourSlotLogicalUnitary;
   - Robin/SymmetryFourSlotBlockEncoding;
   - Robin/SymmetryFourSlotLogicalUnitary, Robin/SymmetryFourSlot,
     Robin/FixedN3Data, Robin/Hadamard8Verified;
   - Robin/Hadamard8BlockEncoding, Robin/PaperSevenPrimitive,
     Robin/PaperSevenLogicalUnitary, Robin/SourceSevenSparseData,
     Robin/SourceBaseline, Robin/WeightedPermutation;
   - Robin/Figure4SourceData, Robin/Figure4Primitive, Robin/Figure4Loaders;
   - Robin/Figure4MiddlePrimitive;
   - Core, BlockEncoding, BlockEncodingClassics, RobinEvolution,
     Examples/RobinHeat;
   - Circuit, ConcreteSemantics, CircuitSemantics, StatePreparation;
   - RobinMatrix projection, GHL2025 projection.

   Every projection was read as supplied to EOF; none is represented as a
   whole original module audit. No full RobinMatrix was read.
6. Parent authorized own deterministic hash-only lexical comment masking on
   current production targets. No source prose was emitted by that process.
   Inspected metadata property names and projected only file/source/extents
   range/kind/name fields; a large projected metadata output was truncated.
   No author statuses, selection/adequacy rationale or footer was consumed.
   Captured the complete safe range projection mechanically without relying
   on its mathematical completeness. This metadata was not used to choose a
   desired conclusion.
7. Created build_packet.py with apply_patch, then mechanically generated
   pre-reconstruction input pins, independent lexical target/provider
   declaration capture, range map, and own tested hash control. All9 targets
   and3 configs match under the explicit normalization, not in raw bytes.
   Inventoried 215 explicit target source declarations and all target ambient
   commands. Noticed source theorem signatures may contain let assignments;
   adjusted the capture delimiter to retain those bindings and recaptured.
8. Parent reported its separate hash-only redaction match and offered a
   control file. That file was not read; own control was retained. This
   process-control message contained no source mathematics or comparison
   verdict and did not replace own interpretation.
9. Wrote reconstruction independently from the read formal definitions. The
   signature/inventory artifact includes exact target bodies, not only the
   root statements, and explicit bounded-provider scope.
10. Post and final pins, validation, publicsafe allowlist/manifest and seal are
    generated after writing and checking this reconstruction. Those pin files
    report their actual generation UTC time. No sealed final-publication
    digest was available and no binding wrapper was created.

Never read: natural-contract, author-context, author inventory/coverage/binder
classifications, constructor-fields, graph-proposals, README/handoff/seal/
validation files, natural-source-v2, prior decoders/reviewers/verdicts, CI/fullbuild
results, or the original external source. General repository operational
protocols were read as required, not as mathematical evidence for source
agreement. No network/compiler/simulator/children/production writes occurred.
