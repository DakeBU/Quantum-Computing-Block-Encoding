# Formal decoder handoff

Objective / frontier: independently reconstruct the current nine formal target
modules, exposing guards, definitions, quantifiers, phase, layout and resource
semantics. Direction: current-nine-formal-register-phase-context. Expected gain:
source-blind whole-target meanings rather than root-name paraphrases.

Mathematical delta: reconstruction.md and lossless independently captured
source-signature/body/ambient inventory; fixed target J/224, padded-one versus
all-label Figure4 coefficients, exact B versus H and conjugation direction,
strided9-wire versus contiguous6-wire clean extraction, workspace guards and
arbitrary candidate Prop/String/default field meanings are explicit.

Root effect: provides formal interpretation input for a distinct later
comparison. It does not advance the certified Lean build frontier or certify
natural-source agreement. No publication admission, finite-bit, scientific-root,
or whole dependent-module proof audit claim.

Named evidence: 9 whole target sources, 37 EOF-read bounded provider projections,
3 formal config files; own raw/normalized pins and independent capture.
Historical formalizer UNKNOWN; decoder identity is the current worker only.

Assumptions/conventions: exact-real complex finite matrices, stated primitive
gate model and LE reindexings; raw snapshot/production mismatch preserved;
comment-redacted match is not raw equality or TCB noninterference.

Files changed: only this fresh output directory. Failure class NONE for
the reconstruction; unexecuted compilation is a role boundary, not a refutation.
No essential target semantic definition currently unresolved. Unknowns outside
scope remain imported proof/TCB audit, natural agreement, bit synthesis and
scientific-root closure. Salvage: exact input/capture/guard evidence retained;
no source or code deleted. Process-memory IDs consulted: none (restricted
source-blind context). Parallel admission: user-authorized independent worker
fork assigned by parent; no children. Common-blind-spot/source comparison:
not performed here. No default verified-route selection or comparator claim.
Purification/Exposition Seal: not asserted; this is a sealed decoder artifact,
not a production admission or human-facing completion seal.

Next: parent may inspect and release the sealed reconstruction to a distinct
source-comparison reviewer. STOP before that release/comparison. If a current
publication digest is later supplied hash-only, create a separately versioned
binding wrapper without rewriting this sealed reconstruction.
