"""Bounded deterministic Lean source-command header extraction and C57 repair.

This is not a complete Lean parser, elaborator, or proof checker. Local roots
are supplied only as command arguments; all output references are logical.
The sealed predecessors are read-only, never rewritten.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse, ast, copy, hashlib, importlib.util, json, re, sys

RUN='robin-c49-signature-successor-c57'
ACTOR='/root/robin_c49_current_formal_decoder'
FEEDBACK_CONTROL='a67b1b70edeb552c06b0558d0625d8aaaf476b0b25236cba17a9a15819f44450'
FEEDBACK='9ea249b228368fe002ab23257f793d7cf6dce9745427bd78a4e0c6165cf2ba8c'
OPAQUE='c6135c2df881cb970e7ede23d34ed5695d382c7dd7460bf8003556e22bfc32b3'
ORIGINAL_RECON='ebd11e8da0663f9ddb46eba785c72437d382303cc10aa7155112419f6e8dc167'
ORIGINAL_SEAL='5d1dd69afe8b91764cc7fadf189ec66d1bb9c8d95885e34c4f53fa7ad091cb46'
SAFE_SEAL='87be99d0328957ff8c7e09ea1f48d49afde67590a4a28aafcfb1efe182466548'
C54_SEAL='c6b0dd88899b21c1c4b677305a69503f9cc64c3c9ebbf6b840da81b921dedf9a'
C54_SCRIPT='fd09ac83ca8c61a957758776f280f2e143f1c7f68bbd4d7c8aa7ee38e6398603'
PUBLIC='reviews/publication/robin-fixed-routes-c45/'
PACKET_PATH=PUBLIC+'decoder-c57-packet.json'
ARTIFACT_PATH=PUBLIC+'decoder-c57-reconstruction.md'

def sha(data):return hashlib.sha256(data).hexdigest()
def encode(v):return (json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf-8')

def tokens(text):
    """Yield (kind,exact token,start,end), preserving quoted token boundaries.
    Handles ordinary/escaped/raw Strings, quoted identifiers, simple Char
    literals, nested comments, and binder/constructor delimiters. No macro or
    notation elaboration; unsupported grammar must remain an explicit limit.
    """
    i=0
    while i<len(text):
        c=text[i]
        if c.isspace():i+=1;continue
        if text.startswith('--',i):
            end=text.find('\n',i);i=len(text) if end<0 else end;continue
        if text.startswith('/-',i):
            j=i+2;depth=1
            while depth and j<len(text):
                if text.startswith('/-',j):depth+=1;j+=2
                elif text.startswith('-/',j):depth-=1;j+=2
                else:j+=1
            if depth:raise ValueError('unterminated nested comment')
            i=j;continue
        raw=re.match(r'r(#+)"',text[i:])
        if raw:
            marker='"'+raw.group(1);j=text.find(marker,i+len(raw.group()))
            if j<0:raise ValueError('unterminated raw String')
            end=j+len(marker);yield 'quoted',text[i:end],i,end;i=end;continue
        if c=='"':
            j=i+1
            while j<len(text):
                if text[j]=='\\':j+=2;continue
                if text[j]=='"':break
                j+=1
            if j>=len(text):raise ValueError('unterminated String')
            end=j+1;yield 'quoted',text[i:end],i,end;i=end;continue
        if c=='«':
            j=text.find('»',i+1)
            if j<0:raise ValueError('unterminated quoted identifier')
            end=j+1;yield 'quotedIdentifier',text[i:end],i,end;i=end;continue
        char=re.match(r"'(?:\\u[0-9a-fA-F]{4}|\\[^\n]|[^'\\\n])'",text[i:])
        if char:
            end=i+len(char.group());yield 'quoted',text[i:end],i,end;i=end;continue
        if text.startswith(':=',i):yield 'assign',':=',i,i+2;i+=2;continue
        if c.isalpha() or c=='_':
            j=i+1
            while j<len(text) and (text[j].isalnum() or text[j] in "_'"):j+=1
            yield 'identifier',text[i:j],i,j;i=j;continue
        yield 'punct',c,i,i+1;i+=1

def exact_header(capture):
    """Bounded command header: stop before outer where/equation/assignment.
    Assignment inside nested binders/default expressions is not a boundary;
    unparenthesized let expressions in a theorem type retain their bindings.
    Returned offset is into the unchanged full declaration capture.
    """
    stack=[];pairs={')':'(',']':'[','}':'{','⟩':'⟨'}
    pending_lets=0;previous=None
    for kind,value,start,end in tokens(capture):
        if kind in {'quoted','quotedIdentifier'}:previous=value;continue
        if value in {'(','[','{','⟨'}:stack.append(value);previous=value;continue
        if value in pairs:
            if not stack or stack.pop()!=pairs[value]:raise ValueError('unbalanced header delimiter')
            previous=value;continue
        if stack:previous=value;continue
        if kind=='identifier' and value=='let':pending_lets+=1
        elif kind=='assign':
            if pending_lets:pending_lets-=1
            else:return capture[:start].rstrip(),{'kind':'ordinary-assignment','offset':start}
        elif kind=='identifier' and value=='where' and previous!='.':
            return capture[:start].rstrip(),{'kind':'where','offset':start}
        elif value=='|' and not capture[capture.rfind('\n',0,start)+1:start].strip():
            return capture[:start].rstrip(),{'kind':'equation-clauses','offset':start}
        previous=value
    raise ValueError('No supported command body boundary')

def unit_tests():
    cases=[
     ('where','def p (q : Nat) : P q where\n  field := 1','def p (q : Nat) : P q','where'),
     ('equations','def f : Nat → Nat\n  | 0 => 1\n  | n+1 => n','def f : Nat → Nat','equation-clauses'),
     ('ordinary','theorem t (n : Nat) : n=n := by rfl','theorem t (n : Nat) : n=n','ordinary-assignment'),
     ('default-binder','def f (n : Nat := (let x := 2; x)) : Nat := n','def f (n : Nat := (let x := 2; x)) : Nat','ordinary-assignment'),
     ('nested-default-record','def f (p : P := { x := 1, y := [2] }) : Nat := 0','def f (p : P := { x := 1, y := [2] }) : Nat','ordinary-assignment'),
     ('quoted-String','def f (s : String := "where := | ( )") : Nat := 1','def f (s : String := "where := | ( )") : Nat','ordinary-assignment'),
     ('escaped-String','def f (s : String := "a\\\" where :=") : Nat := 1','def f (s : String := "a\\\" where :=") : Nat','ordinary-assignment'),
     ('quoted-identifier','def «where := | (» (n : Nat) : Nat := n','def «where := | (» (n : Nat) : Nat','ordinary-assignment'),
     ('raw-String','def f (s : String := r##"where ") := |"##) : Nat := 1','def f (s : String := r##"where ") := |"##) : Nat','ordinary-assignment'),
     ('theorem-let','theorem t : let n := 0\n  n=n := by rfl','theorem t : let n := 0\n  n=n','ordinary-assignment'),
     ('two-theorem-lets','theorem t : let n := 0\n  let m := n\n  m=m := by rfl','theorem t : let n := 0\n  let m := n\n  m=m','ordinary-assignment'),
     ('nested-comments','def f /- where /- := -/ | -/ : Nat := 1','def f /- where /- := -/ | -/ : Nat','ordinary-assignment'),
     ('character-default',"def f (c : Char := ')') : Nat := 1","def f (c : Char := ')') : Nat",'ordinary-assignment'),
     ('attribute-private','@[simp] private theorem t : True := by trivial','@[simp] private theorem t : True','ordinary-assignment'),
     ('qualified-keyword','def f : Foo.where := x','def f : Foo.where','ordinary-assignment'),
    ]
    rows=[]
    for name,capture,expected,boundary in cases:
        actual,info=exact_header(capture)
        assert actual==expected and info['kind']==boundary,name
        rows.append({'test':name,'capture':capture,'expectedHeader':expected,'boundary':boundary,'passed':True})
    return rows

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--workspace-root',required=True);parser.add_argument('--repository-root',required=True)
    args=parser.parse_args();workspace=Path(args.workspace_root).resolve();repository=Path(args.repository_root).resolve()
    out=Path(__file__).resolve().parent;assert out==workspace/RUN and not (out/'seal.json').exists()
    safe=workspace/'robin-c49-publicsafe-successor';old=workspace/'robin-c49-current-formal-decoder';c54=workspace/'robin-c49-current-binding-c54'
    lineage=[];immutable={}
    for base,expected in [(old,ORIGINAL_SEAL),(safe,SAFE_SEAL),(c54,C54_SEAL)]:
        assert sha((base/'seal.json').read_bytes())==expected
        manifest=json.loads((base/'manifest.json').read_bytes())
        for e in manifest['artifacts']:assert sha((base/e['file']).read_bytes())==e['sha256']
        names=json.loads((base/'publicsafe-allowlist.json').read_bytes())['files']
        immutable[base.name]={n:sha((base/n).read_bytes()) for n in names}
        lineage.append({'path':'W/'+base.name+'/','sealSha256':expected,'manifestSha256':sha((base/'manifest.json').read_bytes())})
    feedback_dir=workspace/'c57-formal-signature-feedback'
    fb_control=(feedback_dir/'snapshot-control.json').read_bytes();fb=(feedback_dir/'signature-annex-findings.snapshot.json').read_bytes()
    assert sha(fb_control)==FEEDBACK_CONTROL and sha(fb)==FEEDBACK
    findings=json.loads(fb)
    inventory_bytes=(safe/'declaration-inventory.json').read_bytes();inventory=json.loads(inventory_bytes)
    tests=unit_tests();corrected=copy.deepcopy(inventory);comparisons=[];changes=[]
    # The extractor has no dependency on the feedback headers; comparisons occur
    # only after all 215 headers have been extracted from actual own captures.
    for module in corrected['targets']:
        source=(workspace/'robin-fixed-routes-c45-author'/module['path']).read_bytes()
        assert sha(source)==module['sha256']
        text=source.decode('utf-8-sig')
        for declaration in module['declarations']:
            capture=declaration['sourceCapture'];assert text[declaration['characterStart']:declaration['characterEndExclusive']]==capture
            assert sha(capture.encode())==declaration['captureSha256']
            header,boundary=exact_header(capture)
            declaration['sourceSignatureStatus']='OBSOLETE_LEXICAL_PREFIX_AID_NOT_EXACT_COMMAND_HEADER'
            declaration['exactSourceHeader']=header
            declaration['exactSourceHeaderBoundary']=boundary
            declaration['exactSourceHeaderScope']='source-command/type-header only; bounded lexical extraction; not elaborated type'
            row={'path':module['path'],'name':declaration['name'],'kind':declaration['kind'],
              'exactSourceHeader':header,'oldSourceSignature':declaration['sourceSignature'],
              'different':header!=declaration['sourceSignature'],'boundary':boundary['kind'],
              'captureSha256':declaration['captureSha256'],'sourceStart':declaration['characterStart'],
              'headerEndOffsetInCapture':boundary['offset']}
            comparisons.append(row)
            if row['different']:changes.append(row)
    assert len(comparisons)==215
    by_key={(r['path'],r['name']):r for r in comparisons}
    feedback_checks=[]
    for f in findings['differences']:
        rel=f['path'].split('W/robin-fixed-routes-c45-author/',1)[1]
        own=by_key[(rel,f['name'])]
        feedback_checks.append({'path':rel,'name':f['name'],
          'actualHeaderMatch':own['exactSourceHeader']==f['actualSourceHeader'],
          'oldLexicalAidMatch':own['oldSourceSignature']==f['C49Signature'],
          'boundaryMatch':own['boundary']==f['boundary']})
    assert all(all(v for k,v in r.items() if k.endswith('Match')) for r in feedback_checks)
    feedback_keys={(f['path'].split('W/robin-fixed-routes-c45-author/',1)[1],f['name']) for f in findings['differences']}
    additional=[r for r in changes if (r['path'],r['name']) not in feedback_keys]
    missing=[r for r in feedback_checks if not by_key[(r['path'],r['name'])]['different']]
    assert not missing
    # Keep every original field, including old lexical prefix, complete source
    # captures, proof bodies, namespace/private data and ambient commands intact.
    for prev,after in zip(inventory['targets'],corrected['targets']):
        assert {k:v for k,v in after.items() if k!='declarations'}=={k:v for k,v in prev.items() if k!='declarations'}
        for p,n in zip(prev['declarations'],after['declarations']):
            assert {k:n[k] for k in p}==p
    assert corrected['providers']==inventory['providers']
    corrected['method']='C57 versioned command-header annex: all215 whole-target exactSourceHeader extracted with bounded tested source lexer; old sourceSignature remains obsolete lexical-prefix aid; all original field values/captures unchanged; provider signatures remain legacy lexical aids, not repaired exact headers'
    corrected['signatureAnnexVersion']=2
    corrected['legacySourceSignaturePolicy']='Every sourceSignature value is an obsolete lexical-prefix aid, not a source command/type header; only whole-target exactSourceHeader is repaired here'
    corrected['formalOnlyFeedbackSha256']=FEEDBACK
    (out/'declaration-inventory-c57.json').write_bytes(encode(corrected))

    original_recon=(safe/'reconstruction.md').read_bytes();assert sha(original_recon)==ORIGINAL_RECON
    text=original_recon.decode('utf-8')
    replacements=[(
      'declarations, totaling 215. `declaration-inventory.json` is the lossless signature\nannex: each entry retains exact source signature, entire declaration capture,',
      'declarations, totaling 215. `declaration-inventory-c57.json` is the versioned\nsource-command-header annex: each whole-target entry retains an exactSourceHeader\nextracted from its unchanged full source capture. The old sourceSignature field is\nretained verbatim only as an obsolete lexical-prefix aid, not a command/type header.\nTwelve where and six equation-clause boundaries were incorrect in that old aid;\nthe formal-only C57 successor repairs them, preserving entire declaration capture,'),
      ('Source signatures are not elaborated signatures: instance synthesis, inferred',
       'Exact source-command headers are not elaborated signatures: instance synthesis, inferred'),
      ("premise. The target's exact source signatures in the inventory preserve all",
       "premise. The target's exactSourceHeader entries in the C57 annex preserve all")]
    for before,after in replacements:assert text.count(before)==1;text=text.replace(before,after)
    lineage_note='\n\n## C57 annex-only successor lineage\n\nThe original mathematical reconstruction is retained verbatim apart from the\nthree explicit annex-description replacements recorded in annex-delta-c57.json.\nThe original reading was source-blind. This later repair consumed only the two\npinned formal-header feedback objects, not any natural source, comparison\nsections or verdict. All original seals and the actual privacy and18-header\nartifact failures remain immutable negative findings. Historical statements in\nthe reconstruction about unavailable binding digests describe the original run;\nthe separately versioned C54 and C57 wrappers associate the reconstruction with\nthe same parent-provided opaque nine-module bindings without reading their\nnatural-source rows or eleven field contents. This is not a new full\nmathematical review or source agreement. Independent targeted C47 re-review\nremains required.\n'
    changed_recon=(text+lineage_note).encode('utf-8')
    recovered=text
    for before,after in reversed(replacements):recovered=recovered.replace(after,before)
    assert recovered.encode()==original_recon
    (out/'reconstruction.md').write_bytes(changed_recon)
    (out/'snapshot-control.json').write_bytes(fb_control)
    (out/'signature-annex-findings.snapshot.json').write_bytes(fb)
    delta={'schema':'C57_ACTUAL_FORMAL_HEADER_REPAIR_DELTA_V1',
      'negativeFinding':'18 lexical sourceSignature boundary issues; original full captures intact. Retained artifact-level negative, not mathematical refutation.',
      'originalAnnexSha256':sha(inventory_bytes),'newAnnexSha256':sha((out/'declaration-inventory-c57.json').read_bytes()),
      'originalReconstructionSha256':ORIGINAL_RECON,'newReconstructionSha256':sha(changed_recon),
      'wholeTargetDeclarationsChecked':len(comparisons),'actualHeaderDifferences':len(changes),
      'whereDifferences':sum(r['boundary']=='where' for r in changes),
      'equationDifferences':sum(r['boundary']=='equation-clauses' for r in changes),
      'changes':changes,'additionalGenuineFindings':additional,'feedbackComparisons':feedback_checks,
      'allOriginalTargetFieldsAndCaptureValuesUnchanged':True,'allOriginalProviderValuesUnchanged':True,
      'providerSourceSignaturePolicy':'unchanged legacy lexical aids, not repaired exact headers',
      'reconstructionDescriptionReplacements':[{'old':a,'new':b} for a,b in replacements],
      'reconstructionAddedLineage':lineage_note,'allOtherReconstructionBytesPreserved':True,
      'notFullLeanParser':True,'notElaboratedTypes':True,'noMathematicalOrSourceVerdictUpgrade':True}
    (out/'annex-delta-c57.json').write_bytes(encode(delta))
    (out/'extractor-tests-c57.json').write_bytes(encode({'unitTests':tests,'actual215Comparisons':comparisons,
      'allUnitTestsPassed':True,'all215SourceCaptureChecksPassed':True,'formalFeedbackComparisons':feedback_checks,
      'limits':'bounded lexical extractor over actual215 captures, not complete Lean grammar or elaboration; no claim of repaired provider command headers'}))

    c54_code=(c54/'bind_decoder_c54.py').read_bytes();assert sha(c54_code)==C54_SCRIPT
    sys.dont_write_bytecode=True
    spec=importlib.util.spec_from_file_location('own_c54_binding_functions',c54/'bind_decoder_c54.py');own=importlib.util.module_from_spec(spec);spec.loader.exec_module(own)
    previous=json.loads((c54/'current-correspondence-receipt.json').read_bytes())
    def resolve(logical):
        if logical.startswith('W/'):root=workspace;rel=logical[2:]
        elif logical.startswith('R/'):root=repository;rel=logical[2:]
        else:raise ValueError('nonlogical path')
        p=(root/rel).resolve();assert p.is_relative_to(root);return p
    pin_checks=[]
    for e in previous['formalInputRechecks']:
        data=resolve(e['path']).read_bytes();assert sha(data)==e['sha256'] and len(data)==e['bytes']
        pin_checks.append({'path':e['path'],'sha256':e['sha256'],'bytes':e['bytes'],'pinMatched':True,'scope':e['scope']})
    current=[]
    for e in previous['currentTargetAndConfigCorrespondence']:
        production=resolve(e['path']).read_bytes();snapshot=resolve(e['snapshotPath']).read_bytes()
        assert sha(production)==e['currentRawSha256'] and sha(snapshot)==e['snapshotRawSha256']
        assert own.normalized(production)==own.normalized(snapshot)
        assert sha(own.normalized(production))==e['normalizedSha256']
        current.append({**e,'c57Rechecked':True})
    opaque_bytes=(c54/'opaque-control.json').read_bytes();assert sha(opaque_bytes)==OPAQUE
    opaque=json.loads(opaque_bytes)
    assert len(opaque['bindings'])==9
    for b in opaque['bindings']:assert any(e['path']=='R/'+b['module'] and e['currentRawSha256']==b['raw_module_sha256'] for e in current)
    (out/'opaque-control.json').write_bytes(opaque_bytes)
    now=datetime.now(timezone.utc).isoformat()
    scope={
      'action':'formal command-header annex repair plus same opaque binding association, not new full mathematical/source review',
      'originalReading':'source-blind before this formal-only feedback',
      'feedback':'only two pinned actual formal-header feedback objects consumed; no natural source, other Stage4 sections, typed findings, selected rows or11fields',
      'binding':'same nine parent-provided opaque C54 bindings; no independent recompute from withheld11field contents',
      'providers':'37 bounded projections rehashed, not whole ambient-module or current TCB audit',
      'execution':'no Lean/compiler/native tactic/simulator/Git/network/children',
      'review':'independent targeted C47 re-review required; no source agreement or reviewer accepted verdict created',
      'historicalFormalizer':'UNKNOWN'}
    receipt={'schema':'C57_FORMAL_SIGNATURE_CORRESPONDENCE_RECEIPT_V1','identity':ACTOR,'run_id':RUN,'recordedAtUTC':now,
      'lineage':lineage,'formalFeedbackPins':{'snapshotControlSha256':FEEDBACK_CONTROL,'actualFindingsSha256':FEEDBACK},
      'originalNegativeFindingsPreserved':['PUBLICATION_PRIVACY_FAILURE','18 lexical header-boundary issues'],
      'allOriginalArtifactsImmutable':True,'formalInputPins':pin_checks,'currentTargetAndConfigCorrespondence':current,
      'boundedProviderPinsMatched':sum('/bounded-nine/providers/' in e['path'] for e in pin_checks),
      'wholeTargetDeclarationsRepairedOrChecked':215,'actualHeaderDifferences':len(changes),'additionalFindings':additional,
      'annexSha256':sha((out/'declaration-inventory-c57.json').read_bytes()),'reconstructionSha256':sha(changed_recon),
      'mathematicalTextUnchangedOutsideRecordedAnnexDescriptions':True,'scope':scope}
    (out/'current-correspondence-receipt.json').write_bytes(encode(receipt))
    chronology='''# C57 formal-annex-only repair chronology

The same genuine decoder actor performed this versioned run after its original
source-blind reconstruction, privacy transport successor, and C54 binding run.
All predecessor bytes remain sealed and immutable.

1. Consumed only the authorized snapshot-control and formal-header findings;
   verified both supplied hashes. Did not read their Stage4 origin directory,
   natural source, semantic/source comparison sections, other-worker packets,
   selected metadata rows, eleven field contents or any verdict.
2. Read own prior annex/reconstruction and header-capture machinery. Wrote a
   bounded token-based source-header extractor with quoted token, nested
   delimiter/default binder, where/equation/ordinary assignment handling.
3. Ran deterministic unit tests, then extracted all215 headers independently
   from actual own full captures and checked each capture against the pinned
   formal snapshot. Only then compared extraction with the formal feedback.
4. Preserved every old target/provider field value and entire source capture,
   including body/proof/private/ambient data. Added exactSourceHeader for all
   whole-target entries; marked sourceSignature an obsolete lexical-prefix
   aid. Provider legacy aids are unchanged and not claimed repaired.
5. Made only the exact annex-description/lineage reconstruction changes listed
   in annex-delta-c57.json; verified inverse replacement recovers the original
   reconstruction bytes. No mathematical assertion was revised.
6. Rehashed original49 formal inputs, including37 bounded projections, and
   rechecked nine raw production target hashes plus three configs and the
   original in-memory comment-redacted correspondences without emitting prose.
7. Created new own decoder wrappers on the already authorized same nine opaque
   bindings; future portable artifact/packet locations are prospective and
   this actor did not write or publish them in the repository.
8. Checked raw/recursive JSON/Python-literal privacy, exact public file set,
   manifest/seal integrity, and predecessor immutability. Stopped at this
   package; independent C47 targeted re-review remains required. No compiler,
   native proof, source comparison or accepted reviewer verdict was performed.
'''
    (out/'chronology.md').write_bytes(chronology.encode())
    packet={'schema':'C57_OWN_SOURCE_BLIND_FORMAL_HEADER_SUCCESSOR_PACKET_V1','identity':ACTOR,'run_id':RUN,
      'source_blind':True,'source_blind_timing':'original reading preceded bounded formal-only feedback; feedback disclosed, not a fresh source-blind full math run',
      'lineage':lineage,'formalFeedback':{'controlSha256':FEEDBACK_CONTROL,'findingsSha256':FEEDBACK},
      'correctedAnnex':{'logicalPath':'W/'+RUN+'/declaration-inventory-c57.json','sha256':sha((out/'declaration-inventory-c57.json').read_bytes())},
      'deltaSha256':sha((out/'annex-delta-c57.json').read_bytes()),'testsSha256':sha((out/'extractor-tests-c57.json').read_bytes()),
      'reconstruction':{'futureRepositoryPath':ARTIFACT_PATH,'sha256':sha(changed_recon),'repositoryTransportByParentPending':True},
      'receiptSha256':sha((out/'current-correspondence-receipt.json').read_bytes()),'opaqueControlSha256':OPAQUE,
      'correctedHeaderCount':len(changes),'allTargetHeadersChecked':215,'scope':scope}
    (out/'packet.json').write_bytes(encode(packet))
    wrappers=[]
    for b in opaque['bindings']:
        name=Path(b['module']).stem+'.decoder-c57.json';wrappers.append(name)
        wrapper={'role':'decoder','identity':ACTOR,'run_id':RUN,'source_blind':True,'module':b['module'],
          'reconstruction':'Own original mathematical reconstruction with only disclosed C57 annex-description/lineage corrections; corrected all215 source command headers from unchanged full captures; actual18 boundary errors retained as negative finding.',
          'binding_sha256':b['binding_sha256'],'packet_path':PACKET_PATH,'packet_sha256':sha((out/'packet.json').read_bytes()),
          'artifact_path':ARTIFACT_PATH,'artifact_sha256':sha(changed_recon),
          'paths_status':'prospective portable R paths explicitly authorized for parent exact-byte transport; actor performed no repository write or publication',
          'current_raw_module_sha256':b['raw_module_sha256'],'opaque_bound11field_sha256':b['bound11field_sha256'],
          'formal_feedback_control_sha256':FEEDBACK_CONTROL,'formal_feedback_findings_sha256':FEEDBACK,
          'corrected_annex_sha256':sha((out/'declaration-inventory-c57.json').read_bytes()),
          'receipt_sha256':sha((out/'current-correspondence-receipt.json').read_bytes()),
          'original_source_blind_seal_sha256':ORIGINAL_SEAL,'privacy_successor_seal_sha256':SAFE_SEAL,
          'c54_binding_seal_sha256':C54_SEAL,'historical_formalizer':'UNKNOWN','scope':scope}
        (out/name).write_bytes(encode(wrapper))
    # No private root values are emitted, including in JSON escape forms or
    # Python String literals. Value-pattern scanning is not an omniscient
    # detector of arbitrary secrets; no candidate credential value is found.
    runner_prefix='/'.join(('', 'home', 'runner'))
    badpath=re.compile(r'[A-Za-z]:[\\/]|'+re.escape(runner_prefix)+r'|(?:^|[\\/])Users[\\/]',re.I)
    badcredential=re.compile(r'(?:sk-[A-Za-z0-9_-]{16,}|gh[pousr]_[A-Za-z0-9]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)',re.I)
    def strings(v):
        if isinstance(v,dict):
            for k,x in v.items():yield k;yield from strings(x)
        elif isinstance(v,list):
            for x in v:yield from strings(x)
        elif isinstance(v,str):yield v
    def scan():
        for p in out.iterdir():
            if not p.is_file():continue
            text=p.read_text(encoding='utf-8-sig');values=[text]
            if p.suffix=='.json':values+=list(strings(json.loads(text)))
            elif p.suffix=='.py':values+=[n.value for n in ast.walk(ast.parse(text)) if isinstance(n,ast.Constant) and isinstance(n.value,str)]
            assert not any(badpath.search(v) or badcredential.search(v) for v in values),'public payload failed privacy scan'
    scan()
    for base in [old,safe,c54]:assert immutable[base.name]=={n:sha((base/n).read_bytes()) for n in immutable[base.name]}
    controls={'publicsafe-allowlist.json','manifest.json','seal.json'};files=sorted({p.name for p in out.iterdir() if p.is_file()}|controls)
    (out/'publicsafe-allowlist.json').write_bytes(encode({'version':1,'files':files,'exactSetIncludesControls':True,
      'hashRule':'manifest hashes all except manifest+seal; seal hashes manifest; all controls contain identical exact set'}))
    (out/'manifest.json').write_bytes(encode({'version':1,'publicsafeAllowlist':files,
      'artifacts':[{'file':n,'sha256':sha((out/n).read_bytes()),'bytes':(out/n).stat().st_size} for n in files if n not in {'manifest.json','seal.json'}],
      'hashExcludedControls':['manifest.json','seal.json'],'lineage':lineage,'role':'decoder','scope':scope}))
    (out/'seal.json').write_bytes(encode({'status':'C57_OWN_FORMAL_HEADER_REPAIR_AND_DECODER_WRAPPERS_SEALED_PENDING_INDEPENDENT_TARGETED_REVIEW',
      'identity':ACTOR,'run_id':RUN,'publicsafeAllowlist':files,'manifestSha256':sha((out/'manifest.json').read_bytes()),
      'actualHeaderCorrections':len(changes),'additionalGenuineFindings':len(additional),'whereCorrections':sum(r['boundary']=='where' for r in changes),
      'equationCorrections':sum(r['boundary']=='equation-clauses' for r in changes),'all215HeadersChecked':True,
      'sourceCaptureAndMathematicalAssertionsPreserved':True,'wrapperCount':len(wrappers),
      'formalFeedbackSha256':FEEDBACK,'packetSha256':sha((out/'packet.json').read_bytes()),
      'reconstructionSha256':sha(changed_recon),'annexSha256':sha((out/'declaration-inventory-c57.json').read_bytes()),
      'negativeFindingsRetained':['original privacy failure','original18header boundary issues'],
      'reviewerVerdict':'NOT_CREATED','targetedC47ReReview':'REQUIRED','scope':scope}))
    scan();assert files==sorted(p.name for p in out.iterdir() if p.is_file())
    print(json.dumps({'headersChecked':len(comparisons),'actualCorrections':len(changes),'where':sum(r['boundary']=='where' for r in changes),
      'equations':sum(r['boundary']=='equation-clauses' for r in changes),'additional':len(additional),'unitTests':len(tests),'wrappers':len(wrappers),
      'publicFiles':len(files),'sealSha256':sha((out/'seal.json').read_bytes()),'manifestSha256':sha((out/'manifest.json').read_bytes()),
      'packetSha256':sha((out/'packet.json').read_bytes()),'reconstructionSha256':sha(changed_recon),'annexSha256':sha((out/'declaration-inventory-c57.json').read_bytes())}))

if __name__=='__main__':main()
