"""Read only explicitly allowed snapshots; emit mechanical evidence as JSON.

Roots are CLI arguments. No file is written by this script. This is lexical
inventory/byte accounting, never a Lean parser, elaborator, verifier or verdict.
"""
import argparse
import hashlib
import json
import re
from pathlib import Path

BASELINES = dict(line.split() for line in """
ModularAdder3.lean a8bcc72eb3f5ff887c533e8d1bd3737faeaf38cff61971a6bee9aba844fd0852
Figure4PreparePrimitive.lean 1c8dfa0632bd299a7eaf77943188a7982323e6a56af82b6cbd9f75e576c91148
Figure4T3.lean c719dabe6991071e951fe875617375a97ac810cceed86c105a940effd4881616
PaperSevenAmplitudePrimitive.lean aa0f5b99d8c465364fde9f5925ed589a4cbbed00f83999bea6077a58f9c67c41
PaperSevenPrepare.lean 82dd80ae4082e1ae250244a89724f2be95a2bcb5cc9f199659151a2aebca1eff
PaperSevenPreparePrimitive.lean 28b6437751360e09ea1fb09ffd09e26cccebdcc192e1f0a368721e350cf954d8
SymmetryFourSlotPrimitive.lean 641e76b6291ec5934553e5e0c7da504d16df9d2bb48ef4b07968e29dfdd41e84
SymmetryXorFourSlotPrimitive.lean ec0b65b6a2054da03108050dcd564611931d0eb691446103d22254bde7e451fc
SystemConjugation.lean 967a83990a03c75c5be21a6fc88442980f0f289bf71b9803d69bbde4d0f18320
RobinMatrix.lean.txt 302a44e6646c850af14f5e53572a9923153f9a72beb51120c3dbace31bfe9484
PrimitiveMacros.lean.txt 2b63937ec3d5b8cf18829786baeef31b394d4cee6eb4990df4cfefeb5632936d
Core.lean.txt 54d70a4faebbac108a56ede4376a68eb4641198936f0bfe096f0008544cc1db6
CircuitSemantics.lean.txt 6b581d84a38d4a4f269149ff9ebdb9d90f9532a7f7485b4db1fc9bb599124c6a
RobinHeat.lean.txt 83081da1d41d0f70f725123a033e0a9df387922ba43707777129d6e6557d1c15
Figure4Loaders.lean.txt 467332234b016f33ef1df0446914a5ab1d1052ee6a887d2da1bfff62cbcb4b5c
Figure4MiddlePrimitive.lean.txt ae937f07908bad6fe2b151c28e8f2e21144867ad150f4d9dcc847fd18e116e70
PrimitiveRefinement.lean.txt 871bc76d43038ad7ea06ef4116ee5e363fa09913382700a8a429c57d93f31184
PaperSevenPrimitive.lean.txt 4e945b328f33c8e1e7ddf423c7d1a15e69a279d1bf43e0de02a133361f23639f
PrimitiveBasisLE.lean.txt e80d81f9715847ba579e0a1f315ee80422cc77dac561e4c588266fbf9ffee952
UniformlyControlledRy.lean.txt e12b4af1aaba50078fd8f7692bfe6053790af410d4ac691a7d40216417183ed3
SymmetryFourSlotBlockEncoding.lean.txt 94332130cb7ad50750b788304e7ca1f0f1f57b2e55cb2dda10726f2c051d84f5
SymmetryXorFourSlotLogicalUnitary.lean.txt 8556601d79cb61bd34e4069d67076424db9d99dc3af933e1e6d85576c51f86a5
ComplexLCUProjection.lean.txt 9fd526abca13750982f5cf56bc647e220baa99d8b67aeef01e4225135d8fe1f2
ReversibleClassical.lean.txt a8a16149c7b804cc02934b0553531cb409dd7f9cdaa0a3edf222766f6196e4f4
BlockEncoding.lean.txt d4a8598b0a9f798b2e4141652588d10666d70a89a9319275b0f6ffb4a1fdf12d
GHL2025.lean.txt 514c3cf1cdf5ceb3dc29a00b7cc4db30c2c815f4a38a7f9f2e7b84569cd25085
Figure4Primitive.lean.txt 231be4293f83a12abbffa0033404d8d83db414c9501cfbfb8b7c7c364840ff94
PrimitiveSemantics.lean.txt a6aa23b51a730efb6abc1543657208edb40997066b7cb4a91d0263c19de4c88c
PaperSevenLogicalUnitary.lean.txt 629d5b3b27aadcf9f3ef08cd0f020fbb1803393626c2d967df80c99188667c29
SourceBaseline.lean.txt 09fcecbc8b412792f6f7592b30b94c4e705f7eae43f375c724995a075b4d27b6
WeightedPermutation.lean.txt a22ea653f1ebc69673ad70806f5fc28a30ece3e11746e182c4b339f0dc86fe03
SymmetryFourSlotLogicalUnitary.lean.txt d26815a28f9f4ea6f8de12c9e32292ec371d33d01568f68fe0668baedda225e1
Hadamard8BlockEncoding.lean.txt 089e42c6a39dac8582a93dec5aef2e8a9310c3d66529cc203f491099cad7f5f0
ComplexLCU.lean.txt 27e02a68e8ad9991b0c46b4d27c926c4939b00426dee44141fd57f1abd3ce895
Circuit.lean.txt c09076e45377eb148b4289c13a3b5c82763d3a54b68f538d78731eccd0ca0f59
Figure4SourceData.lean.txt dba23cd9382dbb69747dacdbf3def0d08a2d5ae4d64a03c9c743ce576913e2b8
PrimitiveCircuit.lean.txt 1551481076df8cb512d99c75346ba87b8903447e8cf670b79952e976df957f72
Hadamard8Verified.lean.txt 67751388c8322e7503ceb0b1fcf14d83da36890202f6d55806936e5f469e0707
SourceSevenSparseData.lean.txt 546fdfacc7aed90c5ebabad13a181a636179eea901522e7a352e3943ff2151db
FixedN3Data.lean.txt c7bacb4220c5e158ea4c04be66a89869aafb7b593abacfc077085fb394a8aad6
SymmetryFourSlot.lean.txt f838b35a6e00e3c397478aa1e589ecf98962f63c66c449f5a99a79ae044936e3
ConcreteSemantics.lean.txt a6cd51547345df0f69ea87a93311711d56b8ca7037544a75c53781597529c931
Resources.lean.txt 84c5ee631f262985fa5cfddf0446702da89eda3a73e98e04081320dbf559e4db
RobinEvolution.lean.txt 96c925aff60d67d94f92f68fa58490ba15dd8f6c8aa1e600468468fda67b259e
BlockEncodingClassics.lean.txt e1b8c76fc5f16c04a9a34b931b8926960ad491922aec90d047e199a9c722bbdd
StatePreparation.lean.txt 65ef9c0342ed989ec1e64f4b8a09f2468c6786268974a53cb63c2d45b18f5fd8
lake-manifest.json 510171e8214a2ac5e00f16c1bf92ad474d2de42c4cd2dc2b3d411272f7b58763
lakefile.lean c8b6e3f46a451e8f71501b5ef57072ee683c54636e69ee3769bda63f0a284d4e
lean-toolchain 302cd63c54178885b89e669f33b38f12f4dd7ae7e5cac537b3203e3768d8fb2b
extents-and-adequacy.json 7b7b06483b3e4deb5ab6c745d7c946c34eebef7d9c163c0f5b43a85a906edc90
""".strip().splitlines())

RULES = {
 "ModularAdder3.lean": [(16,74,["N05","N06"],"Exact reversible gate/list compilation with true macro phases; arbitrary ambient q, finite gate alphabet."),(75,197,["N07","G01"],"C3X actual permutation versus clean action; six constructor guards, eight action inequalities, clean state only in action theorem."),(198,239,["N08","G02"],"Fixed seven-wire adder, literal eight instructions, clean work and preserved b; no arbitrary-width theorem."),(240,249,["N09"],"Definitional program/circuit resource ownership or structural zero query count.")],
 "Figure4PreparePrimitive.lean": [(15,56,["N19"],"Nine-bit explicit encode/decode including indicator and work; finite bijection not arbitrary quantum choice."),(57,245,["N20"],"High/middle/low spectator-context identities and exact stage embeddings, including all dirty spectator states."),(246,306,["N20"],"Exact zero-phase selector PREPARE and program-dagger unprepare; chronological product checked.")],
 "Figure4T3.lean": [(15,21,["N19"],"Private transport/encode bridge, all coefficient and indicator bits, work initialized0."),(25,32,["N27"],"PREPARE then actual middle then PREPARE-dagger exact program."),(33,43,["N21"],"Branchwise indicator/work cleanup for every coefficient basis value; not an all-dirty-input theorem."),(44,96,["N25"],"Actual middle reindex and clean entry with both coefficient inputs/outputs."),(97,144,["N27"],"Full-carrier primitive program equality to Pdagger B P with exact reindex and phase."),(145,234,["N26","D01"],"Clean slot contraction, c00 entry, probability and padded active/zero split."),(235,285,["N26","N27"],"Flat512 dimension, clean-index target M/224, full circuit unitarity separately."),(286,299,["N27"],"Concrete forall-entry block predicate and actual proof term; not arbitrary proposition data alone."),(300,327,["N27"],"Angle-dropping legacy presentation, actual ideal-gate resource and candidate; inherited schedule empty; layout proof only auxiliary arithmetic."),(328,342,["N27"],"PrimitiveProgramRefinement fields program,target,exact; exact matrix including compiler phase."),(343,349,["N27"],"Verified candidate actual unitaryProof and blockProof supplied.")],
 "PaperSevenAmplitudePrimitive.lean": [(14,57,["N15","N16"],"Six lower physical controls select bounded total coefficient RY on q6; bound produced internally."),(58,99,["N14","N16"],"Context retains q7 and finite bijection; full context iff, no dropped dirty sector."),(100,163,["N16"],"All-carrier amplitude-lift refinement, zero program phase and structural zero queries; not SELECT semantics.")],
 "PaperSevenPrepare.lean": [(17,47,["N10"],"Exact sqrt-rational arccos constructors, wire maps and target inequalities; no general angle-extraction algorithm."),(48,89,["N10","N11","N12"],"Chronological stage product and exact program equality, unitarity via primitive semantics."),(90,110,["N13"],"Fixed ideal counts seven RY/eight CX and structural zero abstract oracle calls."),(111,129,["N12","N13"],"Physical Fin8 selector and optional padded Fin7 label; reindexed P remains unitary."),(134,285,["N12"],"Actual symbolic trig-square derivation plus all eight finite labels; modulus probabilities only, not assumed common phase.")],
 "PaperSevenPreparePrimitive.lean": [(13,42,["N17"],"Three logical selector stage matrices and exact product relation."),(43,237,["N17"],"Physical q5,q4,q3 stage contexts and entries preserving system/coefficient/q7 on full carrier."),(238,291,["N17","N18"],"Actual compile-stage preparation composition and reversed gate daggers; stage theorem, not complete block encoding.")],
 "SymmetryFourSlotPrimitive.lean": [(17,56,["N28"],"Actual two-CX coordinate permutation, finite image p or7-p, basis encoding and bijection."),(57,81,["N29","G03"],"Cyclic shift table bounded standard-RY angle interface only, not XOR SELECT or final cyclic certificate.")],
 "SymmetryXorFourSlotPrimitive.lean": [(18,50,["N31"],"Two CX SELECT full-basis action p XOR slot and spectator preservation; exact permutation and zero queries."),(51,111,["N30","N32"],"Actual five-control wire decoding and internally bounded 32 XOR angles; standard half-angle RY."),(112,241,["N30","N31","N32"],"Finite complete context and middle equivalences; SELECT reindex and full amplitude-lift equality."),(242,375,["N33"],"Uniform4 selector stage matrices and two RY physical circuit; contexts and exact reverse-dagger inverse."),(376,406,["N32"],"Actual amplitude circuit/program and exact controlled-block/logical refinement."),(407,430,["N34"],"Chronology PREPARE, amplitude, SELECT, inverse; actual exact logical middle equality."),(431,464,["N28","N35"],"Six-bit coordinate permutation/involution and all-spectator sector-rotation context."),(465,531,["N35"],"Standard RY S, inverse and pair chronology Sdagger,middle,S; exact S middle Sdagger."),(532,602,["N36"],"Two coordinate conjugations, physical original-index/LE identity, full exact flat-matrix equality."),(603,648,["N36"],"Zero-phase actual program, clean-index projection, unitarity and structural zero queries; signal excludes sector."),(649,681,["N36","N37"],"Lossy presentation, ideal-gate resource, explicit block predicate and actual proof."),(682,713,["N36"],"Candidate fields/default schedule, exact PrimitiveRefinement, actual verified proof fields."),(714,736,["N37"],"Compatibility abbreviations refer to XOR object; amplitude-only32RY/62CX and zero queries, no cyclic circuit theorem.")],
 "SystemConjugation.lean": [(19,31,["N38"],"Literal Kronecker system lift over arbitrary finite C,S,H."),(32,48,["N39"],"Lift unitarity conditional on V unitary only."),(49,181,["N38"],"Exact entries/adjoint, rectangular clean-row/column sums, literal clean block and conjugation; arbitrary complex operators."),(182,208,["N39"],"Conjugation unitarity requires BOTH U and V unitary."),(209,234,["N38"],"Clean block conjugates exactly with NO unitarity premise; finite delta-sum proof.")]
}

DECL = re.compile(r"^(?:@\[[^\n]*\]\s*)?(?:(?:private|noncomputable|protected|unsafe)\s+)*(?P<kind>def|theorem|lemma|abbrev|structure|inductive|instance)\s+(?P<name>[\w'.]+)")
AMBIENT = re.compile(r"^(import|namespace|end|open|set_option|variable|local|scoped|attribute)\b")

def pin(root, logical, baseline=True):
    raw = (root / logical).read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    initial = BASELINES[Path(logical).name] if baseline else digest
    if initial != digest:
        raise RuntimeError("Input mutation: " + logical)
    return {"path":"author/"+logical,"bytes":len(raw),"sha256_before":initial,"sha256_after":digest,"equal":True}

def classify_binder(text):
    if re.search(r"≠|≤|(?<![\w])state work = 0|workClean|unitaryGroup", text):
        return "SOURCE_LOCAL_OPERATION_OR_CONDITIONAL_PREMISE; exact omitted natural details retain G01"
    return "TYPING_OR_LITERAL_INPUT; see exact text and semantic audit"

def inventory(root, logical):
    raw = (root/logical).read_bytes()
    text = raw.decode("utf-8")
    lines = text.splitlines(keepends=True)
    starts = [(i,DECL.match(line)) for i,line in enumerate(lines) if DECL.match(line) or AMBIENT.match(line)]
    regions = []
    if starts and starts[0][0] > 0:
        regions.append({"kind":"preamble","start_line":1,"end_line":starts[0][0],"literal_region":"".join(lines[:starts[0][0]])})
    for pos,(i,match) in enumerate(starts):
        end = starts[pos+1][0] if pos+1<len(starts) else len(lines)
        literal = "".join(lines[i:end])
        entry = {"start_line":i+1,"end_line":end,"literal_region":literal,"region_sha256":hashlib.sha256(literal.encode()).hexdigest()}
        if not match:
            entry.update(kind="ambient",command=lines[i].strip(),disposition="Retained exact command/context, no theorem premise inferred.")
            regions.append(entry)
            continue
        kind,name = match.group("kind","name")
        rule = next((r for r in RULES[Path(logical).name] if r[0]<=i+1<=r[1]), None)
        if not rule:
            raise RuntimeError("Unmapped declaration: "+logical+":"+name)
        signature_lines = []
        for line in lines[i:end]:
            signature_lines.append(line)
            if ":=" in line and not re.match(r"\s*let\b",line):
                signature_lines[-1] = line.split(":=",1)[0]
                break
            if re.search(r"\bwhere\s*$",line):
                signature_lines[-1] = re.sub(r"\bwhere\s*$","",line)
                break
        signature = "".join(signature_lines)
        groups = []
        stack = []
        opens = {"(":")","{":"}","[":"]"}
        for k,char in enumerate(signature):
            if char in opens:
                stack.append((char,k))
            elif stack and char==opens[stack[-1][0]]:
                opening,start=stack.pop()
                candidate=signature[start:k+1]
                if not stack and (re.match(r"[({]\s*[\w\s]+\s*:(?!=)",candidate) or opening=="["):
                    groups.append({"text":candidate,"classification":classify_binder(candidate)})
        local_steps = [{"line":i+offset+1,"text":line.rstrip()} for offset,line in enumerate(lines[i:end]) if re.match(r"\s+(?:let|have|suffices|obtain|by_cases|rcases)\b",line)]
        fields = [{"line":i+offset+1,"text":line.rstrip()} for offset,line in enumerate(lines[i:end]) if re.match(r"\s+[\w.]+\s*:=",line)]
        if kind in ("theorem","lemma"):
            role = "finite_native_proof_text_NOT_REPLAYED" if "native_decide" in literal else "symbolic_or_definitional_proof_text_NOT_COMPILED"
        elif re.search(r":\s*Prop\s*:=" ,literal):
            role="literal_proposition_definition_NOT_A_PROOF"
        elif kind=="abbrev":
            role="literal_type_or_compatibility_abbreviation"
        elif name.endswith("VerifiedBlockEncoding"):
            role="record_constructor_WITH_actual_proof_fields"
        elif "Candidate" in name:
            role="candidate_data_WITH_Prop_fields_NOT_alone_a_certificate"
        elif "Refinement" in name:
            role="literal_refinement_record_WITH_exact_equality_proof"
        else:
            role="literal_definition_or_data_constructor"
        entry.update(kind=kind,name=name,private=bool(re.match(r"private\b",lines[i])),role=role,signature_text=signature,binder_groups=groups,local_steps=local_steps,field_assignments=fields,source_nodes=rule[2],own_semantic_mapping=rule[3],source_expectation_status="static comparison only; no compiler/source approval",definition_kind="literal" if kind not in("theorem","lemma") else None)
        regions.append(entry)
    declarations = [r for r in regions if r["kind"] not in("ambient","preamble")]
    return {"path":"author/"+logical,"sha256":hashlib.sha256(raw).hexdigest(),"line_count":len(lines),"declaration_count":len(declarations),"all_regions":regions,"line_partition_verified":sum(r["end_line"]-r["start_line"]+1 for r in regions)==len(lines),"private_declarations":[d["name"] for d in declarations if d["private"]]}

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--author-root",required=True)
    parser.add_argument("--work-root",required=True)
    parser.add_argument("--part",choices=["all","summary","module","providers","pins","check"],default="summary")
    parser.add_argument("--module",type=int,default=0)
    args=parser.parse_args()
    root=Path(args.author_root)
    ext=json.loads((root/"bounded-nine/extents-and-adequacy.json").read_text(encoding="utf-8"))
    targets=ext["targets"]
    providers=[p["file"] for p in ext["providers"]]
    assert len(targets)==9 and len(providers)==37
    allowed=targets+providers+["formal-only/config/lean-toolchain","formal-only/config/lakefile.lean","formal-only/config/lake-manifest.json","bounded-nine/extents-and-adequacy.json"]
    pins=[pin(root,p) for p in allowed]
    modules=[inventory(root,p) for p in targets]
    provider_records=[]
    for metadata in ext["providers"]:
        path=metadata["file"]
        content=(root/path).read_text(encoding="utf-8")
        provider_records.append({"path":"author/"+path,"read_through_EOF":True,"line_count":len(content.splitlines()),"source_regions":[{"start_line":e["sourceLine"],"end_line":e["sourceEndLineInclusive"],"kind":e["kind"],"name":e["name"]} for e in metadata["extents"]],"adequacy":"All projection bytes independently read including ambient commands, fields/defaults; lexical selection not elaboration adequacy guarantee."})
    work=Path(args.work_root)
    natural=work/"robin-fixed-routes-c45-author/natural-contract.md"
    seal=work/"robin-nine-c45-source-first/stage1-seal.json"
    assert hashlib.sha256(natural.read_bytes()).hexdigest()=="519b05b4fb6e84f1b1cafc11a6fc8752af47fe1c22e0a2b9897b1e585ad079ee"
    assert hashlib.sha256(seal.read_bytes()).hexdigest()=="0b8fd2a6b6dd193f380a983e62f9e00dabac216a62bac82c6994f72124030347"
    output={"schema":"own-static-whole-inventory-and-local-source-map-v1","limitations":"Mechanically bounded lexical inventory enriched by my independently authored semantic mapping after full reads. Not elaboration/proof-term extraction. Complete literal regions preserve every binder/body/local let/have and constructor field even when regex summaries are conservative.","stage1_seal_sha256":"0b8fd2a6b6dd193f380a983e62f9e00dabac216a62bac82c6994f72124030347","modules":modules,"providers":provider_records,"input_pins":pins,"counts":{"targets":len(modules),"target_declarations":sum(m["declaration_count"] for m in modules),"providers":len(provider_records),"configs":3,"bounded_formal_inputs":len(pins)},"extra_full_snapshots_read":[],"source_gaps_retained":["G01","G02","G03","G04","G05","G06","Q07"]}
    if args.part=="check":
        destination=work/"robin-nine-c45-source-review-phase2"
        recorded=json.loads((destination/"whole-inventory-and-source-map.json").read_text(encoding="utf-8"))
        assert recorded["modules"]==modules, "Recorded inventory differs from complete literal regions or own semantic rules"
        assert all(m["line_partition_verified"] for m in modules)
        known_pins=json.loads((destination/"input-pins.json").read_text(encoding="utf-8"))
        assert known_pins["inputs"]==pins
        protocol_expected={
          "AGENTS.md":"cd6c8e7a3065be88c70d3e09a2b8262e8e80c0805b434579223edb34536ec719",
          "HARNESS.md":"74f8847cbb627073ab63d2228cd23b6300b5d59dcae019a9da442a6ddcbf4e2e",
          "docs/theorem-publication-protocol.md":"db45ec07c3cd092bef4c37dc460164d5b06767daee24664645e7b2a18dfc5cd0",
          "docs/proof-digestion-protocol.md":"c26999839c3b45f2b1663547c8be24c57534fea3e8459467866d1e41e553a75a",
          "docs/evidence-routed-memory-protocol.md":"2039b9ec55f287d9df5fe53e09b14cc92cb3aa6301be6c060c96f30b11a8e34b",
          ".agents/skills/qbe-substantive-worker/SKILL.md":"906c1ab444d8a4492d84ee941bb214d55d550365cbc78471186f37fc23ac6c83"
        }
        expected_recorded={"repository/"+p:h for p,h in protocol_expected.items()}
        assert all(p["sha256_before"]==p["sha256_after"]==expected_recorded[p["path"]] for p in known_pins["protocol_pins"])
        s1=json.loads(seal.read_text(encoding="utf-8"))
        assert all(hashlib.sha256((seal.parent/item["path"]).read_bytes()).hexdigest()==item["sha256"] for item in s1["artifacts"])
        checked=[]
        for path in sorted(destination.iterdir()):
            if not path.is_file():
                raise RuntimeError("Unexpected non-file output: "+path.name)
            data=path.read_bytes()
            assert data.endswith(b"\n") and not data.endswith(b"\n\n") and not data.endswith(b"\r\n"), "Not single final LF: "+path.name
            content=data.decode("utf-8")
            assert not re.search(r"[A-Za-z]:[/\\]",content), "Machine path leakage: "+path.name
            if path.suffix==".json":
                json.loads(content)
            checked.append({"path":path.name,"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()})
        output={"status":"PASS_STATIC_EVIDENCE_CONSISTENCY_ONLY","counts":output["counts"],"target_line_total":sum(m["line_count"] for m in modules),"complete_inventory_equal_to_fresh_mechanical_extraction":True,"all50_formal_input_hashes_equal":True,"all6_stage1_artifact_bindings_equal":True,"protocol_pin_values_equal":True,"all_output_files_single_final_LF":True,"all_JSON_parse":True,"no_machine_absolute_paths":True,"artifacts":checked}
    elif args.part=="summary":
        output={"schema":output["schema"],"limitations":output["limitations"],"stage1_seal_sha256":output["stage1_seal_sha256"],"counts":output["counts"],"module_summary":[{"path":m["path"],"declaration_count":m["declaration_count"],"line_count":m["line_count"],"line_partition_verified":m["line_partition_verified"],"json_chars":len(json.dumps(m,ensure_ascii=False))} for m in modules]}
    elif args.part=="module":
        output=modules[args.module]
    elif args.part=="providers":
        output=provider_records
    elif args.part=="pins":
        output=pins
    print(json.dumps(output,ensure_ascii=False,indent=2))

if __name__=="__main__":
    main()
