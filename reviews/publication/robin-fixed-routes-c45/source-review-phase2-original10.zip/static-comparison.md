# Independent static comparison, stage 2

## Result and authority

The nine complete target snapshots and all 37 provider projections were read through EOF, including ambient commands, private helpers, proof bodies, local lets/haves, structure fields, defaults and constructor assignments. The three configuration files were also read. The independently generated inventory contains 215 target declarations and partitions all 2,694 target lines. This is a static comparison against the previously sealed LOCAL natural expectation; it is not compilation, a mathematical proof seal, an original-paper equivalence verdict, publication approval or whole RobinMatrix approval.

Stage 1 remains frozen at seal SHA256 `0b8fd2a6b6dd193f380a983e62f9e00dabac216a62bac82c6994f72124030347`. Its only mathematical input was the retrospective, implementation-informed LOCAL natural source, SHA256 `519b05b4fb6e84f1b1cafc11a6fc8752af47fe1c22e0a2b9897b1e585ad079ee`. Historical formalizer is UNKNOWN; actual names and String values are visible, so neither stage is identity-blind. No author classification, inventory, natural graph, handoff/seal, previous reviewer, decoder output, CI, registry, production Lean, network, Git or compiler was read or invoked. Only my own Stage-1 seal is an input seal here.

No contradiction between the explicit fixed target/register/phase formulas in the permitted natural source and these actual target statements was identified. This narrower observation must not be expanded to an expected acceptance verdict. The six natural-source detail gaps remain gaps in that exact source; actual formal text now explains what several omitted details are, without retrospectively changing the pinned source.

## Whole-file coverage and context adequacy

The inventory counts are: ModularAdder3 22; Figure4PreparePrimitive 23; Figure4T3 20; PaperSevenAmplitudePrimitive 16; PaperSevenPrepare 20; PaperSevenPreparePrimitive 19; SymmetryFourSlotPrimitive 10; SymmetryXorFourSlotPrimitive 75; SystemConjugation 10. One private helper is included: `transportInput_eq_encode`. Every complete region is retained with its exact text and region hash; source-node mapping, exact signature text, binder-group aid, local proof-step heads and constructor field assignments are attached. The raw complete region is authoritative when the lexical summaries are conservative. This is my inventory, not a copy of an author classification or an elaborated dependency graph.

All 37 selected projections were independently read, rather than trusting their lexical-selection description as a semantic adequacy guarantee. They include primitive semantics, exact angles, reversible gates/macros, multiplexor construction, resource definitions, full pertinent LCU definitions, fixed integer/rational data, physical middle/loaders and symmetry providers. I did not identify a necessary project-owned contract symbol whose meaning was absent from this union plus the nine full targets. Thus no extra full snapshot was retrieved. This does not establish elaboration/typeclass/tactic closure: Mathlib elaboration, generated declarations and actual compiler acceptance remain untested. The masked projection is not an executable rewritten module, and orphan ambient options in it must not be treated as a standalone build.

RobinMatrix was read ONLY as its 6,715-byte bounded projection, with original source extent labels preserved in `provider-context-audit.json`. The 26,985-line full file was not opened. Its stencil constructors and symbolic oracle/obligation records do not license whole-module approval or a parametric source-oracle certificate.

## 1. Primitive contracts, exact phases and C3X

The provider `PrimitiveCircuit` defines four primitive constructors: X, RY, RZ, CX; CX carries a proof that control and target differ. `ExactAngle` actually includes both `twiceArccosRational` with |c|<=1 and `twiceArccosSqrtRational` with 0<=c<=1, plus rational/pi-rational/real/add/neg/scale constructors. The Stage-1 square-root-angle question is therefore explained by an explicit constructor, not a newly imposed rational-only angle restriction.

`standardRyMatrix theta` is `realRotation (theta/2)` and the real rotation has rows (cos,-sin),(sin,cos). `amplitudeRotation c` is `realRotation (arccos c)`. The actual bounded angle construction and `standardRyMatrix_two_arccos_eq_amplitudeRotation` preserve negative c, the off-diagonal sign and BOTH coefficient basis values. That equality's bound parameters are not used by its definitional angle-halving proof; bounds are genuinely used later for the clean entry cos(arccos c)=c. No change of gate convention is warranted.

`evalPrimitiveCircuit` evaluates a head gate after recursively evaluating the tail matrix, i.e. chronological gates produce reversed matrix multiplication. `PrimitiveProgram.seq` appends circuits and adds phases; dagger reverses, maps primitive dagger and negates phase. `evalPrimitiveProgram` multiplies by exp(i phi), and its seq/dagger lemmas explicitly transport that scalar.

The actual CCX macro is an H program, the monomial CCZ middle, then H. H has phase pi/2 and chronological RZ(pi),RY(pi/2); T/Tdagger have phases plus/minus pi/8 with corresponding RZ angles. The monomial middle carries its state-dependent phase and permutation with an equality proof field; its proof reduces the permutation to identity and phase to (-1) on the all-one triple. H-conjugation converts CCZ to CCX. The compiler uses these named equality proofs, rather than discarding macro phases. These are read proof texts, not replayed compiler evidence.

`cleanC3XReversibleProgram`, `cleanC3XBasisEquiv`, `cleanC3XPrimitiveProgram` and its compiler equality have exactly SIX distinctness inputs:

    c0 != c1, c0 != w, c1 != w, w != c2, w != t, c2 != t.

The clean action and workspace-clean theorems additionally require c0!=t and c1!=t, making EIGHT inequalities, plus state[w]=0. They do NOT require c0!=c2 or c1!=c2. The six-input compiler theorem gives equality to the actual three-CCX permutation even when t aliases a first control; the stronger eight-input action theorem is the clean C3X interpretation. These domains must not be conflated. This confirms Stage-1 G01 was a real omission in the natural summary: the exact list is newly observed formal detail, not a retrospective source amendment.

## 2. Fixed three-bit adder

The literal chronological reversible instructions at target lines 203-212 are:

    CCX(3,0;6), CCX(6,1;2), CCX(3,0;6), CCX(3,0;1),
    CX(3;0), CCX(4,1;2), CX(4;1), CX(5;2).

The semicolon separates controls from target. With bits (a0,a1,a2,b0,b1,b2,w), the first three compute w=b0*a0, use it in a2 and restore w=0. The next gates give

    a0' = a0 XOR b0,
    a1' = a1 XOR (b0 AND a0) XOR b1,
    a2' = a2 XOR (b0 AND a0 AND a1)
                 XOR (b1 AND (a1 XOR (b0 AND a0))) XOR b2.

These are the carry parities for addition modulo8; the b wires remain untouched. The theorem `modularAdd3_cleanAction` quantifies only `PrimitiveBasis 7`, requires state6=0, and concludes the three-bit numeric sum modulo8, preservation of bits3,4,5 and output6=0. Its proof text is `native_decide +revert`; no such computation was executed here. `modularAdd3Primitive_eval` separately transports the whole permutation via the compiler, and `modularAdd3Primitive_workspaceClean` projects a conjunct. Resource faithfulness is rfl, and oracleCalls=0 follows by the primitive resource definition. This is not arbitrary-width carry correctness. G02 remains an omission in the pinned natural source even though the ordered gates and macro phases are now formally visible.

## 3. Seven-state PREPARE and eight-wire stage refinements

`PaperSevenPrepare` uses the exact sqrt-rational arccos constructors for 4/7 and 2/3, with internally supplied `norm_num` bounds. Its Middle control is wire2 targeting1; Low controls map to wires1,2 targeting0. The angle condition for Low is both control bits1, where the angle is zero. The chronological circuit concatenation and matrix `Low*(Middle*High)` match Stage1. Each physical circuit is rewritten through the general multiplexor theorem; its unitarity follows from the actual primitive program.

The probability proof has real trig-square local haves for quarter-angle, high and tail branches, then all eight finite labels. The exact result is star(P[s,0])*P[s,0] = if s<7 then 1/7 else0. It is not a theorem that the physical carrier is Fin7 or an assumption that all phases agree. `warmRobinPaperSevenPaddedSlot` is an optional label only. Counts seven RY/eight CX are proved by compiler count formulas. Both maxHeartbeats assignments are retained as ambient commands; neither is a mathematical premise or proof replay result.

The provider chain supplies total `warmRobinPaperSevenCoefficientRat = warmRobinSourceSevenPaddedCoefficient`: active slots have M[r_s(j),j]/32, padded slot7 has value1. Source offsets are `(slot XOR3) mod8`, which gives exactly (3,2,1,0,7,6,5,4). The fixed bounds are supplied internally, not final external hypotheses. The amplitude physical controls are q0...q5 and target q6. The context index retains selector and system plus q7; finite bijection and context iff establish full-carrier amplitude lift, including dirty q7. The separate actual reversible full-system permutation carries the dirty-work extension; no SELECT identity on work is inferred from amplitude spectators.

`PaperSevenPreparePrimitive` embeds High/Middle/Low on q5/q4/q3. All three context-iff theorems retain coefficient q6, non-target selector bits, system and q7, and their native proof texts quantify full input row/column states. The stage entry proofs use these exact contexts, not only initialized states. Compilation gives the full selector lift; reverse+dagger gives its adjoint. The local transparency options affect tactic unification, not the statement. Neither target has a final whole paper-seven BE theorem. The source's named external consumer is not silently brought into this scope.

## 4. Nine-wire Figure-4 chain

`WarmRobinFigure4FullSystem = Fin8 x (Fin2 x Fin2)` retains indicator/work inside the logical system factor. `warmRobinFigure4EncodeBits` and its decoder explicitly assign selector q0...2, system q3...5, coefficient q6, indicator q7, work q8. Bijection and encode theorem are genuine finite proof texts. Preparation embeddings preserve every other bit on the full carrier; its phase is zero and unprepare is actual program dagger.

The provider middle is not just a label. Its indicator reversible sequence uses clean C3X to mark transpose-bulk columns3 or4; D-transpose sparse access computes the addressed row in the selector/address register while preserving the original system. Bulk loader is active on indicator1; boundary loader is active on indicator0 AND not-transpose-bulk. Their branch theorem connects the loaded c to M[r_s(j),j]/32. D-transpose access, inverse indicator, identity homogeneous loader, full register swap, and inverse D-access form the post-loader. The proof preserves the original column long enough to uncompute its indicator, then uses the offset inverse to clean D after swap. In particular, it is not valid to uncompute an indicator using the changed output system instead of the original column.

Both coefficient inputs are retained in `warmRobinFigure4DerivativeLoader_entry`, post-loader transport identities and `warmRobinFigure4MiddleProgram_cleanEntry`. The clean middle interface in Figure4T3 then agrees exactly with Stage1's delta(slot equality), delta(row address) and R(c)[b,a]. `warmRobinFigure4AllWorkspaceClean` is explicitly a statement about indicator plus post-loader acting on a basis transport input with arbitrary coefficient; it is not by itself the amplitude-superposition theorem. The separate full 2x2 loader entry and actual permutation refinements supply the coherent extension.

The private transport/encode bridge is included in the inventory. Full program equality is to Pdagger B P under the exact nine-bit equivalence, with program phases retained. The clean-entry proof expands the appropriate sums, collapses the slot match, uses R00=c and the proved probability, and splits active versus padded slots. The active coefficient matches M/32; the padded probability is zero, so the paper-seven padded1 and Figure4 padded0 remain different total definitions without affecting the clean sum. The source sum theorem is a separate finite fixed-data proof. Full unitary dimension is512 and clean indices retain only the system bits with all other bits0.

`warmRobinFigure4PrimitiveBlockContainsTarget` literally expands to forall row,column in Fin8, the flat matrix at the designated clean indices equals `warmRobinQueryTarget.operator / normalizer`. `warmRobinQueryTarget` supplies the fixed complex cast of A and 56/3, with freeParameters=[] and actual provenance strings. The target proof is supplied, not an arbitrary assumption. The operator candidate has auxiliary6 and layout (system3,signal4,pure2); verified constructor supplies the concrete unitarity and block proof terms. The refinement record has the actual program, exact target matrix and equality proof. No theorem says the legacy Circuit's `"exact-angle"` String contains the discarded angle value.

## 5. Symmetry prerequisite versus complete XOR circuit

`SymmetryFourSlotPrimitive` proves the actual two-CX coordinate image on the three system bits and builds exact angles for the CYCLIC coefficient table only. The provider now makes its orientation explicit: `warmRobinSymmetryFourShiftPerm slot column = (column+slot) mod4`. Thus Stage1's conditional plus-shift discriminator is applicable. At column1/slot1, cyclic row2 has weight16, but XOR row0 has weight32. These are not interchangeable tables with SELECT held fixed. This prerequisite file is not a full cyclic primitive construction certificate.

The actual plus/minus blocks are exactly M[p,q] plus/minus M[p,7-q], agreeing with the independently derived T+K,T-K. Sector0 is plus, sector1 minus. Their finite total tables produce all32 XOR amplitudes internally as M_e[p XOR s,p]/56. The bounded provider theorem is a fixed finite proof, not an arbitrary amplitude oracle.

`SymmetryXorFourSlotPrimitive` uses pair0,1; sector2; selector3,4; coefficient5. The two-CX SELECT action preserves sector/selector/coefficient on every basis input and changes only pair by XOR. Exact middle-index and context equivalences retain all five non-target bits. Its amplitude comes before SELECT, so the table reads the original input pair. Uniform4 PREPARE is RY(pi/2) on3 then4, with reverse-dagger inverse. The actual middle equality composes these full-carrier refinements.

S is precisely standard RY(pi/2) on sector2, using the provider matrix with negative upper-right entry. Pair chronology is Sdagger,middle,S, hence S middle Sdagger, and the full chronology is C,pair,C with C involutive. The actual six-bit original-index theorem identifies the coordinate/logical equivalence with little-endian flattening, so the final flat matrix equality is not a free tensor reorder. Clean index fixes only q3,q4,q5; q2 stays in the three-bit system.

The final candidate unitary is the imported logical flat matrix, and the explicit primitive refinement equality binds it to the actual primitive circuit. Verified fields supply that matrix's unitarity and the concrete clean block proof. The target `PrimitiveRefinement` is circuit-based; the separate program has phase0 and an exact program theorem as well. Compatibility abbreviations name this XOR object. They do not prove a cyclic SELECT primitive route.

## 6. Parametric conjugation

`SystemConjugation` has ten declarations over arbitrary coefficient/selector/system types. Lift and multiplication statements carry explicit Fintype/DecidableEq instances. The left rectangular lemma additionally retains a finite `columnType`; the right lemma a finite `rowType`. Neither coerces that external type to the system. Clean coefficient/selector values are explicit parameters; no extra Nonempty instance is invented, and empty types admit no chosen clean value unless one is supplied.

`cleanSystemBlock` itself is a literal selected-entry function without Fintype/DecidableEq instances. `conjugateSystem` is L(V)*(U*star L(V)), with actual adjoint entries in `star_systemLift_apply`. The clean conjugation theorem has NO unitary premise. `systemLift_unitary` has V unitary only; `conjugateSystem_unitary` has BOTH V and U unitary. Its proof constructs each unitary product. The entry identity expands finite sums via the two rectangular helpers. This matches Stage1's genuinely parametric algebra and does not synthesize an arbitrary V.

The actual XOR logical provider explicitly uses these conjugation theorems. That is an implementation dependency observed now; it does not rewrite Stage1's separate source-construction topology or turn a conceptual adjacency there into a retrospectively asserted source edge.

## 7. Defaults, resources and proof strength

All target definitions read are literal formulas/circuits/adapters, data/record constructors, or equivalences of a specified function supplied with a bijectivity proof. `Equiv.ofBijective` is not a chosen arbitrary quantum representative; no uniqueness/quotient repair or fallback semantics is required. `_ =>0` in M is the literal source table's zero extension, not a claimed general Robin default. The 215-declaration map includes the private helper and actual local proof steps. No sorry/admit/axiom/unsafe token was found in the allowed target/provider texts by the scoped static scan. This is not a transitive axiom report or compiler check; classical and native proof texts are not certified by reading alone.

`OperatorBlockEncodingCandidate` defines isUnitary and blockContainsTarget as freely stored Props. `VerifiedOperatorBlockEncoding` asks for witnesses of those stored Props; the schema alone does not force them to refer to the unitary/target fields. Here BOTH concrete candidates instantiate actual matrix-unitarity membership and the concrete forall-entry block predicate, and the verified constructors supply corresponding proof terms. That local expansion is why these objects must not be assessed only by the word Verified or by generic schema shape.

The candidate default schedule=[] is inherited in both target constructors. `layoutMatches` proves only signalQubits+pureAncillas=auxiliaryQubits; matching systemQubits=3 is literal data here, not an extra property enforced by that field. No schedule/circuit correctness relation is supplied. Exact program/circuit refinement, not legacy presentation or the default schedule, is the semantic bridge.

PrimitiveCircuit.resource is exactly `ofCountsWithDepth oneQubitCount twoQubitCount 0 0 depth`. Thus oracleCalls=0 AND pureAncilla=0 for every primitive circuit by this accounting definition. Figure-4's separately declared physical layout nevertheless uses two pure ancilla wires. These records measure different things; a reader must not substitute resource.pureAncilla=0 for the physical clean-work requirement. Gate depth is obtained by the touched-wire fold under ideal primitive connectivity; it is not a hardware routing or bit-synthesis theorem. Program resource ignores its declared scalar phase as a separate cost item although exact matrix semantics retain it.

The32RY/62CX count in the XOR file is amplitude-loader-only. From the displayed surrounding fixed circuit, adding two selector rotations and their two inverses, S and its inverse, two SELECT CX, and two copies of the two-CX coordinate map gives a static ideal count38RY/68CX for the full circuit. This is an independent arithmetic reading of the definitions and amplitude count, NOT a new source resource theorem, compiler run, finite-bit estimate, hardware comparison or optimality claim. The fixed zero-query claims do not pay for finite-bit arccos/sqrt evaluation, classical table generation, rotation synthesis, amplification or readout.

The frozen local source still has six omitted-detail regions G01-G06, the nine/ten scope ambiguity Q07, and no authenticated original-paper proof. They are retained in `gaps.json`; no formal observation silently alters that input. The static stage ends at its seal, before decoder cross-reading, final reviewer reconciliation or any completion/publication decision.
