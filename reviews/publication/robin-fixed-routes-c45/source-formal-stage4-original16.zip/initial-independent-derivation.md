# Independent formal/source derivation checkpoint (before C49 reconstruction)

Reviewer: /root/robin_c47_raw_source_recovery.
Source-first baseline: immutable Stage1/2/3, natural-source-v2 SHA25610681db8c6f62818bcdd8d6eef787027983b010540e86c547afbaacc34031790, accepted graphv4/coveragev3 only at source-topology layer.

This checkpoint was written before reading C49 reconstruction/inventory/hash-control artifacts and before author-audit classifications. The C49 source-blind-packet was used only to locate/pin exact formal mathematical inputs. Parent validation statements were not mathematical premises.

I have read all nine complete target snapshots through EOF, including proof bodies/private helper/ambient commands. My own declaration scan yields215 declarations:22 ModularAdder3;23 Figure4PreparePrimitive;20 Figure4T3;16 PaperSevenAmplitudePrimitive;20 PaperSevenPrepare;19 PaperSevenPreparePrimitive;10 SymmetryFourSlotPrimitive;75 SymmetryXorFourSlotPrimitive;10 SystemConjugation. There is one private target theorem, transportInput_eq_encode. This count was independently derived, not imported from C49 inventory.

All49 listed formal snapshot/provider/config file hashes and lengths match the source-blind packet. The37 providers are bounded projections, not whole modules: loaded exactly and inspected for required definitions/interfaces, with critical Figure4loader/middle bodies read; no assertion that all provider proofs or transitive imports were audited. Full RobinMatrix and external final paper7 consumer were not read. Toolchain is leanprover/lean4:v4.33.0, mathlib revdb584cd6d46c92f209a44c0f1c829460d327499d. No build/native_decide/kernel/axiom execution occurred.

The actual nine R counterpart raw sources were independently comment-redacted in memory with nested comments/string handling. Each matched its exact snapshot without even CRLF normalization. This is current raw correspondence, not kernel acceptance.

## Actual formal meanings recovered

1. ModularAdder3 compiles literal well-formed reversible gates/programs to exact primitive Programs including scalar phase. The C3X constructor/compiler has six guards; clean action/work theorem has eight guards plus inputwork0, permitting the third control to alias a first control. The literal fixed eight-instruction adder has work0-conditional addition and all-input actual permutation refinement. Only resource-faithful equality and zero-oracle results are claimed in its formal statements, not the source's newly executed numerical count/depth theorem.

2. PaperSevenPrepare uses actual twiceArccosSqrtRational constructors4/7 and2/3, total middle/low tables, full P=Low(Middle High), phase0 Program, exact full-circuit equality and unitarity. Its probability theorem is star(P_s0)P_s0, not a common positive-amplitude assumption. All8 labels remain. Formal counts7RY/8CX and zeroqueries are supplied; depth13 belongs to reconstructed finite list arithmetic, not an inspected theorem here.

3. PaperSevenAmplitudePrimitive supplies six-control target6 full coefficient matrix equality on all256 states, using explicit non-target context bijection. Work7 is retained, not assumed clean. Its coefficient comes from total paper7padded table (slot7=1) and the full workspace rotation ignores work only in this loader.

4. PaperSevenPreparePrimitive and Figure4PreparePrimitive supply full-carrier stage embeddings, context iff identities and exact daggers under the displayed8-/9-wire inverse maps. The Figure4 full system is Fin8×(Fin2×Fin2); indicator/work are not dropped by a bijection.

5. Figure4T3 defines B logically by reindexing the actual middle Program. The full2x2 clean-entry theorem is supplied through actual derivative-loader and postloader providers. AllWorkspaceClean itself contains only indicator followed by postloader, and must not be mistaken for loader coherence. The final closed clean block is the queried A/alpha under explicit PrimitiveCleanIndex. The physical index evaluates to8j from its literal transport/basis definitions. Full Program equality includes all macro phases and full unitarity is independent from the clean block. The literal construction phase evaluates to-9pi/8, not a bare-list phase0 identity.

6. Figure4 candidate is actual512 Program matrix with n3/a6, layout3/4/2, actual unitary membership and explicitforall-entry Prop. Its exact PrimitiveProgramRefinement and unitary/block witness terms are actually present. Schedule is omitted by the constructor and inherits[]. The legacypresentation discards exact angle expressions and program phase.

7. SymmetryFourSlotPrimitive supplies only the two-CX physical coordinate action and bounded cyclic angle interface. It is not a whole primitive cyclic SELECT/circuit. The providers actually define plus/minus sectors as T+K,T-K; cyclic orientation is p+s modulo4.

8. SymmetryXorFourSlotPrimitive uses input-p coefficients from actual XOR sector tables, two-CX full SELECT, two-RY P4 and full6-wire adapters. Chronology is C,S-dagger,P4,amplitude,SELECT,P4-dagger,S,C with standard RY sign. Clean q3,q4,q5 and retained systemsectorq2 give physical indexj. Full-list and phase0 Program equalities plus actual PrimitiveRefinement are supplied. There is a theorem PrimitiveProgram_eval, but no separately named concrete PrimitiveProgramRefinement6 record in the nine target files: do not turn the equality into an invented declaration. Compatibility aliases denote XOR only.

9. XOR candidate stores the64×64 logical flat matrix and actual logicalunitary/blockproofs, with a separate physical refinement. Its layout is3/3/0 and schedule[]. Resource is the actual Program list resource, not a presentation or default schedule.

10. SystemConjugation has arbitrary-type clean extraction with no finite/DecEq assumptions; lift/products have Fintype+DecEq eachC/S/H. Left/right rectangular types retain an extra FintypeK/R, no DecEqK/R; block identity needs no unitarity, lift unitarity needsV, full conjugated unitarity needsV andU. The actual XOR logical provider DOES define its pair unitary via conjugateSystem and invokes its clean-system identity: this is a real formal dependency, while the source graph intentionally used an explicit signed-block argument and did not infer implementation ownership. Different source and formal topology must remain separate.

## Definition/binder/schema judgment so far

The literal circuits,tables,angles,entryfunctions and bijective packaging match the natural-source mathematics on their full declared carriers. Equiv.ofBijective is applied to an exhibited index map with an independent finite bijectivity result, not uniqueness fiction or a phase representative. Generic local guards and chosen clean elements are preserved, with no newly supplied final PREPARE/SELECT/normalization/cleanup/refinement premises.

The generic Candidate's isUnitary and blockContainsTarget are arbitrary Props. Its verified schema proves those chosen Props only; layoutMatches enforces signal+pure=a, not layout.system=n or circuit/resource/matrix consistency. The two actual candidate instances use real matrix-unitary membership and actual target entry formulas. QueryTarget source/contract are Strings, not proofs. ProgramRefinement and PrimitiveRefinement are genuine exact equalities and must be kept separate from these strings.

Resource semantics match the source: list counts plus touched-wire logicaldepth, oracle0,pureAncilla0, scalarphase uncharged. Figure4 physicalwork2 is not resourcepure0, and neither schedule[] nor a compatibilityalias proves execution/cost. Source numeric counts/depths are reconstructed finite static arithmetic; no finite-bit/classicaldata/synthesis/hardware theorem follows.

Preliminary source/formal fidelity judgment: no mathematical mismatch found in these recovered nine-target statements/definitions. This is not a final C49 comparison verdict and no compilation or full transitive-proof/axiom acceptance is claimed. The source's routine proof outlines are not relabeled as executed Lean proofs. All later C49/author claims will be compared against this independently fixed checkpoint.

