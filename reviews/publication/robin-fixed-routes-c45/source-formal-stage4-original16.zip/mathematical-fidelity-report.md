# Stage4 source-first formal comparison — genuine scoped result

Reviewer: /root/robin_c47_raw_source_recovery. Decoder compared: /root/robin_c49_current_formal_decoder. Historical formalizer: UNKNOWN.
The reviewer's source-first Stage1/2/3 baselines and their original bytes/verdicts are unchanged.

## Outcome

The unchanged LOCAL natural source and the actual nine target formal sources agree at the **source-read mathematical meaning** level. I found no mismatch in the target matrices/normalizers, exact phases, conditional guards, full-carrier versus projected claims, clean/dirty work, arbitrary Prop/String schema choices, or fixed resource model. C49's mathematical reconstruction also agrees with those actual sources in the seven semantic slots.

There is a real, separately typed artifact limitation: **18 C49 sourceSignature fields are not command/type headers**—12 where constructions retain the first field label, and6 equation definitions retain their RHS clauses. The complete captures are intact. These fields must be corrected in a successor or explicitly relabeled as lexical prefix aids before use as exact signature/type-header binding evidence. This is not a refutation of the mathematics.

No final publication/accepted-review binding wrapper is created. The prospective eleven-field metadata/digests/row/lesson association was not released to this review, and later parent metadata packets remain unread. No Lean/compiler/native/kernel gate was run. This is an ordinary genuine scoped comparison report, not admission or Proof Seal.

## Independence and chronology

I first read the actual nine complete target snapshots, not C49's mathematical reconstruction. I independently recovered the contracts and counted215 source declarations. Required bounded definitions/interfaces were then inspected from37 provider projections; their complete file hashes were checked without treating them as whole-module audits. All3 configs were pinned.

Before reading C49 reconstruction/inventory/hash-control or author classifications, I wrote and froze:
W/robin-c47-source-formal-stage4/initial-independent-derivation.md
SHA256d45e3d3498c2e09d519d30994a1f1d9f9fa7dd20c1565a4f73400f4725211a09.
Its preliminary derivation is not rewritten after later comparisons.

I also independently read/redacted the exact nine current R counterparts in memory. All matched their complete snapshots after comment masking, without line-ending normalization for these nine targets. The later config comparison additionally found lakefile requires the declared CRLF-to-LF normalization; all3 config correspondences match at that stated level. Raw target bytes differ from comment-masked snapshots and their distinct hashes are retained.

Only after this checkpoint did I inspect C49's reconstruction, lexical inventory, hash control and controls. Finally I read the two author audit proposals, comparing their actual prefix groups/types/definition classifications rather than adopting their conclusions. No author classification or parent validation statement was used as a mathematical premise.

## Exhaustive target coverage

W/robin-c47-source-formal-stage4/module-declaration-coverage.json accounts for every explicit declaration and all ambient source regions, with full source paths, exact source-command headers, offsets/ranges, capture hashes, binder/definition audit and source-family links. The independent source partition concatenates exactly to every target file through EOF.

| Actual module | Explicit declarations |
| --- | ---: |
| ModularAdder3 |22|
| Figure4PreparePrimitive |23|
| Figure4T3 |20|
| PaperSevenAmplitudePrimitive |16|
| PaperSevenPrepare |20|
| PaperSevenPreparePrimitive |19|
| SymmetryFourSlotPrimitive |10|
| SymmetryXorFourSlotPrimitive |75|
| SystemConjugation |10|

Total215:214 public explicit declarations and one private theorem, transportInput_eq_encode. All53 ambient commands are retained, including imports, namespaces, scoped opens, local transparency options and heartbeat/recursion settings. No target variable/universe command supplies a hidden ambient binder. Generated compiler/elaborator auxiliary declarations were not inventoried without elaboration; this is an explicit-source inventory, not a claim about all generated Lean names.

All215 C49 whole declaration captures match exact source slices; their215 capture hashes were independently recomputed. Names, private status, source positions and ambient commands match the independent scan. Full proof bodies were read in the nine targets, including native tactic syntax; reading is not execution or kernel acceptance. Static source scanning sees no explicit sorry/admit/axiom commands in the nine files, but is not a transitive axiom audit.

## Actual mathematics and types

### Reversible compiler and fixed adder

The actual compiler takes well-formed reversible X/CX/CCX data and yields PrimitivePrograms whose exact matrices equal the actual permutation matrices, including all scalar compensation. The program theorem is parametric in ambient qubit count, not operand width.

C3X constructor/compiler has exactly six guards. Clean action/work theorems add the two first-control/target inequalities and inputwork0, but not first-control/third-control distinctness. Third-control aliases are allowed. Dirty input retains the actual three-CCX permutation, not ideal C3X. The source accurately separates these domains.

The eight-instruction seven-wire adder overwrites the little-endian a operand, preserves b and restores work0, modulo8 with overflow discarded. The arithmetic theorem is work0-conditional; compiled permutation equality is full-space. Resource-faithfulness is only the actual program/list resource equality and zero-oracle result; the source's55/33/depth53 arithmetic is not relabeled as a newly executed formal numeric theorem.

### Full PREPARE and eight-wire stage refinements

The actual sqrt-rational angle constructors, complete middle/low functions and P=Low(Middle High) agree on all eight labels. The formal probability theorem is conjugate(P_s0)*P_s0; it does not import positive common phase as a premise. The full matrix and exact inverse are defined, so probability agreement does not replace full-unitary semantics. Counts7RY/8CX have actual source theorems; depth13 remains finite static recurrence arithmetic.

The eight-wire amplitude equality is full-carrier, with arbitrary coefficient row/column and dirty work retained in the non-target context. Paper7 slot7 coefficient is1. Eight-wire PREPARE/unprepare stages have full context iff/eval theorems, not a clean-only extension. The source's full-system dirty SELECT formula matches the bounded provider definition. The external final paper7 emitted consumer and its composition/refinement are not among the nine targets and remain excluded.

### Figure4

The actual full system carrier includes both indicator and work. Its index inverse fixes the stated wire assignments on all512 states. Guarded bulk/boundary tables retain the extra NOT beta(j) branch and distinct active-zero rotation versus inactive identity.

The middle provider supplies entire2x2 coefficient entries and composes them with the actual DT/indicator-dagger/swap/D-dagger permutation. AllWorkspaceClean alone omits the coefficient loader; the source explicitly makes that distinction and supplies the extra coherence chain. Both coefficient inputs are preserved through the clean transport argument.

The whole Program equals the reindexed P-dagger B P, where B is the actual physical middle matrix in logical coordinates. It is not asserted to be an idealized dirty-work SELECT tensor extension. Full unitarity follows separately from primitive Program unitarity. The clean target uses the literal strided index8j, not the leading contiguous8x8 block.

Program scalar syntax retains the actual macro phases; its interpreted Figure4 total is-9pi/8. No bare-list zero-phase equality follows. Exact program refinement, actual matrix-unitary membership, explicit target Prop and their proof terms are present in the concrete candidate. Layout is system3/signal4/pure2; schedule inherits[] and the presentation drops angles/scalar phase. These fields do not certify the generic schema.

### Cyclic interface versus actual XOR

The three-wire SymmetryFourSlotPrimitive gives the two-CX coordinate map and bounded cyclic-angle interface only. The actual provider sectors are T+K,T-K, with cyclic orientation p+s modulo4. The module does not prove a complete primitive cyclic SELECT/circuit.

The XOR target uses the actual input-p sector table, full coefficient rotation, full SELECT p->p xor s and P4. Sector rotation is standard RY(pi/2), not Hadamard. Physical chronology is C,S-dagger,P4,amplitude,SELECT,P4-dagger,S,C, matching the source signs and directions. The full original-index theorem retains sectorq2 as system; clean q3,q4,q5 produces flat indexj. All dirty signal sectors remain part of the exact full matrix.

The actual candidate stores the64x64 logical matrix, with actual logical unitary/block proofs and a separate physical PrimitiveRefinement. There is a phase0 Program_eval equality theorem, but no separately named concrete PrimitiveProgramRefinement6 record in these target files. The source's program-equality wording is faithful; graph shorthand must not invent that record or add a declaration to the count.

### Generic system conjugation

Clean extraction alone has arbitrary types and chosen clean elements, with no Fintype/DecidableEq. Lift/product identities have exactly the finite/decidable C/S/H instances in the source. Extra rectangular K/R has Fintype, not DecidableEq. Neither rectangular identity nor final clean conjugation requires unitary V/U. Lift unitarity requiresV; full conjugated unitarity requiresbothV andU. No Nonempty or positivity hypothesis is silently added; chosen elements simply cannot be instantiated in empty clean carriers.

The actual XOR logical provider uses conjugateSystem and its generic clean-system identity. This is an observed formal implementation path, distinct from the source's explicit signed-block derivation and its refusal to infer implementation ownership. Source and formal proof graphs are not forced to be identical.

## Binder, definition and record expansion

I independently recovered all247 declaration-prefix groups:47 source logical conditions and200 typing/carrier/index/construction-data groups. The47 logical premises are exactly local C3X/clean-adder conditions or the separate generic unitarity hypotheses. No EXCESS logical premise or newly supplied final PREPARE/SELECT/cleanup/normalization/refinement assumption was found. Matrix/index inputs are data, not proof ingredients turned into hypotheses.

Only after this recovery were author aids read. Their247 prefix groups match exactly. All25 author critical statement headers and full proof captures match actual source after comment redaction. This supports their concrete bindings; it does not make their classifications independent evidence or certify all imported proofs.

Definitions are literal total circuits/tables/entry functions/Prop aliases and explicitly bijective adapters. Equiv.ofBijective packages a specified finite map with a bijectivity theorem and independently known inverse correspondence; it is not arbitrary quantum representative selection. No characterized uniqueness fiction, global-phase quotient, default zero repair or new oracle premise is introduced.

Generic Candidate stores freely chosen isUnitary and blockContainsTarget Props; Verified proves those chosen Props only. LayoutMatches is signal+pure=a, not layout.system=n or matrix/circuit/resource consistency. Both actual instances choose genuine unitary membership and explicit target equations and provide terms for them. Query source/semanticContract are Strings; source truth is not a proof field. Legacy presentations lose exact angles, and Figure4's Program scalar. PrimitiveRefinement/PrimitiveProgramRefinement are exact equality records and are not interchangeable with these Strings or compatibility aliases.

Provider ObligationRecord Bool flags and empty OpenContracts lists do not establish mathematical closure or general Robin synthesis. They are not smuggled into the two concrete root proofs as stronger semantic certificates.

## Seven slots and resource boundary

W/robin-c47-source-formal-stage4/seven-semantic-slots.json compares target/normalization; dimensions/scalars/order; oracle/access; ancillas/workspace; phase; error/success; resources, with actual named formal evidence and residual boundaries.

Resource counts X/RY/RZ equally, CX separately, and computes touched-wire all-to-all logical depth. OracleCalls and resourcepureAncilla are0 by primitive vocabulary/definition. Physical Figure4 cleanwork2 is not zero because the resource bookkeeping field is0; XOR has no extra work and retains sector as system. Program phase is uncharged. Schedule[] is default data, not a computed execution layering. Source full numeric list arithmetic remains finite static support, not fresh compiler acceptance, optimized synthesis or a finite-bit/classical-preprocessing/hardware theorem.

All equalities are exact. A projected clean branch is Apsi/alpha, not deterministic successful output or automatic signal cleanup. No amplification, postselection/readout cost, finite-bit approximation, arbitrary-width family or scientific algorithm success is supplied.

## C49 annex limitation S4-SIG-01

The exact lossless captures are strong evidence and are intact, but the field named sourceSignature is not a uniform source-command/type boundary.

For primitiveXProgram it ends with PrimitiveProgram qubits where circuit rather than ending at PrimitiveProgram qubits. Concrete candidate fields similarly end with where auxiliaryQubits. Twelve such where cases contain a first body field label; six equation definitions include all equation RHS clauses. These are literal source prefixes/regions, not command/type headers. The theorem headers, including type-level lets and all generic binders, match.

W/robin-c47-source-formal-stage4/signature-annex-findings.json records all18 cases and independently recovered command headers. Full capture equality/hash checks prevent this metadata issue from becoming an invented mathematical counterexample. A successor may correct the boundary field, or explicitly label it a lexical aid and bind full captures instead. Original C49 bytes must not be silently edited, and no elaborated signature is claimed by this review.

The artifact failure is narrowly IMPLEMENTATION_FAILED for that extraction/label if used as an exact-header exporter. The mathematical failure class is NONE. I do not grant unqualified exact-signature-annex approval, but the intact full captures suffice for this independent source-read mathematical comparison.

## Remaining boundary and handoff

All nine target files and explicit private/ambient regions have been accounted for. The37 providers remain bounded projections; complete RobinMatrix, all transitive imports/provider proofs and generated elaborator declarations were not reviewed as whole modules. No compiler/native tactic/kernel/axiom gate was executed. Original paper/PDE/preproof authenticity and historical authorship beyond UNKNOWN remain unestablished.

No C52/C54, selected-publication rows, fresh binding wrappers or unrelated Sequential2 review packets were read. The opaque prospective metadata fields/digests were not supplied for this phase, so final metadata association is not performed or fabricated. Publication/admission/PURIFIED/Exposition Seal remain separate.

This is a genuine scoped result: mathematical agreement at the actual source/definition/statement layer, with the signature-annex limitation and all scientific/finite-bit/kernel boundaries retained. All predecessor source/review bytes are preserved. Only new Stage4 artifacts were written with apply_patch; no R/Git/network/compiler/child work was performed. Stop after the Stage4 evidence seal and await separately authorized metadata association.

