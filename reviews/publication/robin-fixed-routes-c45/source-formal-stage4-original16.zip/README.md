# Stage4: source-first formal comparison

Reviewer: /root/robin_c47_raw_source_recovery. Historical formalizer: UNKNOWN.

Actual result: SCOPED_SOURCE_FORMAL_AGREEMENT_AT_SOURCE_READ_LEVEL for the pinned LOCAL source and nine complete target formal sources. All215 explicit declarations (214 public, one private),53 ambient commands and247 prefix groups are accounted for.

Open artifact finding S4-SIG-01:18 original C49 sourceSignature fields are not exact command/type headers (12 where forms,6 equation definitions). Complete215 captures and hashes remain exact. No mathematical mismatch was found; the signature annex is not accepted as an exact-header exporter without correction or explicit relabeling.

Read W/robin-c47-source-formal-stage4/mathematical-fidelity-report.md, W/robin-c47-source-formal-stage4/typed-findings.json and W/robin-c47-source-formal-stage4/signature-annex-findings.json for the actual judgment and limits. The independently frozen first derivation is not rewritten after C49/author comparison.

This is not a compiler/kernel gate, whole-provider/wholeRobinMatrix review, external final paper7 consumer review, paper/PDE authentication, finite-bit result, or publication/admission/PURIFIED approval. No prospective metadata association or accepted-review wrapper is created. Future repair notices do not close the original finding.

The exact16-file public set is W/robin-c47-source-formal-stage4/publicsafe-allowlist.json. All new Stage4 files in that set are explicitly publicsafe; predecessor publication rules remain unchanged. W/robin-c47-source-formal-stage4/input-pins.json distinguishes read contents from hash-only files, and W/robin-c47-source-formal-stage4/read-chronology.json states actual ordering without fabricated timestamps.

The qbe-substantive-worker skill's source-first, explicit-assumption, dependency and evidence-boundary discipline shaped this review. It supplied process, not a mathematical premise. Only this new Stage4 directory was written; no source or predecessor file was changed.

