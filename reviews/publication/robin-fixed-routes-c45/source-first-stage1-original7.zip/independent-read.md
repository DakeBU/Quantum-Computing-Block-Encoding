# Independent local-source reconstruction, stage 1

Direction fingerprint: `robin-fixed-register-source-expectation`.

## Evidence boundary

The only mathematical input read was `robin-fixed-routes-c45-author/natural-contract.md`, all 104 lines, SHA256 `519b05b4fb6e84f1b1cafc11a6fc8752af47fe1c22e0a2b9897b1e585ad079ee`. This is an implementation-informed retrospective LOCAL source. It is not authenticated original-paper mathematics or historical pre-proof evidence. Historical formalizer identity is UNKNOWN. Filenames in it were visible as labels; this exercise is not identity-blind. No formal snapshot, declaration inventory, author classification, graph proposal, prior review, production implementation, registry, CI or Lean execution was consulted.

This document gives my own mathematical expectation, not a verdict about any formal implementation. The source asserts proof methods, but those assertions are not checked proof evidence in this stage. Nine module families are covered below. The separately mentioned symbolic RobinMatrix checkpoint is incomplete and is not a tenth approval or a blanket approval for that module. Protocols and the substantive-worker skill were read in full; their hashes are recorded separately. No source topology is self-approved by this packet.

## 1. Common mathematical contract

For q physical qubits the basis is {0,1}^q and the flattening is x = sum_k 2^k x_k. Matrices are complex square matrices acting on column vectors. Chronological gates g1,...,gk have matrix Gk...G1. A declared scalar exp(i phi) is part of the exact program matrix. No equality is weakened to equality modulo global phase. A label-dependent phase is especially not disposable in a coherent coefficient/selector register.

The available ideal primitives are X, standard RY, RZ, and CX with different control and target. RY(theta) has rows (cos(theta/2),-sin(theta/2)) and (sin(theta/2),cos(theta/2)). Thus, for real -1 <= c <= 1,

    R(c) = RY(2 arccos c)
         = [[c, -sqrt(1-c^2)], [sqrt(1-c^2), c]].

Its 00 entry is c, not cos(c), not cos(arccos(c)/2), and not |c|. Its action on coefficient input 1 has a negative off-diagonal entry. Exact rational arccos bounds are construction obligations; the source also uses non-rational square-root preparation angles. Neither exact-real angles nor ideal rotations yield a finite-bit synthesis algorithm or an error budget.

The source determines the following total integer matrix (row and column order 0,...,7):

    M = [-30, 32, -2,  0,  0,  0,  0,  0;
          16,-31, 16, -1,  0,  0,  0,  0;
          -1, 16,-30, 16, -1,  0,  0,  0;
           0, -1, 16,-30, 16, -1,  0,  0;
           0,  0, -1, 16,-30, 16, -1,  0;
           0,  0,  0, -1, 16,-30, 16, -1;
           0,  0,  0,  0, -1, 16,-31, 16;
           0,  0,  0,  0,  0, -2, 32,-30].

A=M/12, alpha=56/3 > 0, and A/alpha=M/224. Physical delta-x scaling is absent. Restoring a positive multiplier lambda would require matching alpha'=lambda alpha, rather than claiming the unchanged normalizer. Eq.(9), A1=B1=0 and f=1 are local teaching labels here, not a verified derivation from the original paper.

For nested logical indices coefficient x (selector x system), a block is a restriction to designated clean input AND output values. If E embeds an 8-dimensional system with all signal/work bits zero, the fixed target is E† U E=M/224. It is not U=M/224. With unit-norm psi, the corresponding accepted probability is ||A psi||^2/alpha^2; there need be no nonzero accepted branch for every psi. Obtaining normalized A psi requires A psi != 0, measurement/postselection or another acceptance mechanism, and any promised amplification cost. Conversely, PREPARE alone does not supply SELECT, amplitude loading, their phases, inverse PREPARE or cleanup. No automatic SP-to-arbitrary-BE or BE-to-deterministic-SP edge is present.

## 2. Reversible compilation and fixed addition

Module family: ModularAdder3.

For arbitrary ambient q, the expected compiler maps each well-formed X/CX/CCX reversible operation to exactly its permutation matrix, with the macro's phase included. Lists then compose by induction in chronological order, hence reversed matrix product order. The source does not provide the actual CCX macro gates/phases, so this is an explicit provider interface, not an independently derived macro proof.

The clean three-control construction is compute a*b into work w, flip target using w and third control c, then uncompute a*b. On a valid wiring locus its Boolean algebra is

    w' = w XOR (a AND b),
    t' = t XOR (c AND w'),
    w'' = w.

For w=0 this flips t by a AND b AND c. For dirty w it additionally flips t by c AND w; e.g. a=b=0,c=w=1 distinguishes it from an ideal C3X. The exact compiler may remain valid on dirty input because it compiles this actual reversible program. The third control may coincide with a or b without invalidating the Boolean conjunction argument; requiring all five named wires pairwise different would be unjustified. However the precise permitted inequalities are NOT listed in the authorized source. I therefore cannot independently enumerate the exact public wiring domain. Gate well-formedness, distinct controls/target where required, and preservation of computed controls must be supplied explicitly later, not guessed from a stronger all-distinct hypothesis.

For seven physical bits in order (a0,a1,a2,b0,b1,b2,w), define a=a0+2a1+4a2 and b=b0+2b1+4b2. The advertised clean permutation is (a,b,0) -> ((a+b) mod 8,b,0). This is fixed width three, with 64 clean basis inputs in a 128-dimensional full space. The source says the circuit has five CCX and three CX and the first three CCX compute/use/uncompute a temporary carry. It does not reproduce the eight ordered instructions, so their truth-table action cannot be independently derived from the permitted input. A claim that a finite native procedure proves it remains a claim about a proof method, not execution evidence here. Ambient-q compiler parametricity must not be confused with an arbitrary-width adder theorem. Definitional resource ownership plus zero abstract oracle calls is not an asymptotic cost bound.

## 3. Three-bit seven-state preparation

Module family: PaperSevenPrepare.

There are eight physical selector basis states, not a seven-dimensional Hilbert space. Starting at 000, first rotate bit 2 by 2 arccos sqrt(4/7). Conditional on high bit 0, rotate bit 1 by pi/2; conditional on high bit 1 use 2 arccos sqrt(2/3). Finally rotate bit 0 by pi/2 except when high=middle=1, where its angle is zero. The matrix is P=Low Middle High.

The first branch has mass 4/7 and two half-splits, giving labels 0,1,2,3 each mass 1/7. The other branch has mass 3/7 and middle masses 2/7,1/7: splitting the first gives labels 4,5 each 1/7, while leaving the final low bit unchanged gives label 6 mass 1/7 and label 7 mass 0. The specified nonnegative trigonometric factors also permit a direct positive clean-column derivation under these exact stage matrices, but the needed downstream statement is only conj(P[s,0])*P[s,0]=1/7 on s<7 and zero at 7.

Phases in individual P[s,0] cancel in P†BP only because middle preserves the slot label. Arbitrary PREPARE phases cannot simply be discarded in a construction that mixes slots. Correct multiplexor stage refinements AND unitarity of primitive matrices justify unitary P. The optional some/none map labels the padded slot and does not delete it. The claimed resources are seven RY, eight CX, zero abstract oracle calls for this fixed circuit, not an end-to-end BE cost theorem.

## 4. Eight-wire refinements

Module families: PaperSevenAmplitudePrimitive and PaperSevenPreparePrimitive.

The physical order is system q0,q1,q2; selector q3,q4,q5; coefficient q6; work q7. Thus flat dimension is 256. The corresponding logical target system can include work as a spectator; a bijection must retain it rather than silently identifying a 256-dimensional object with a 128-dimensional one.

For amplitude loading, six lower bits coherently select R(c(s,j)) on q6. Expected entry on arbitrary work states is

    delta(j',j) delta(s',s) delta(w',w) R(c(s,j))[b,a].

This is full-carrier equality and requires a total bounded coefficient table, not merely its values on initialized inputs. The authorized source does not reproduce that full table. The source explicitly warns that its padded coefficient may differ from the Figure-4 convention. No equality of those total amplitude loaders may be inferred. A spectator proof for this loader gives no spectator proof for an imported SELECT's dirty-work extension.

Preparation embeds High on q5, Middle on q4, Low on q3 and preserves system/coefficient/work for every basis state. Each stage needs its exact control-context equivalence, including every spectator and non-target selector bit, then the exact multiplexed entry. The product gives the selector lift of P; reversing order and daggering individual gates gives the adjoint, with phases conjugated. These two modules are stage refinements only. The source supplies no full paper-seven final circuit consumer in this bounded nine-family reconstruction. Nothing here licenses an authenticated paper-circuit claim.

## 5. Nine-wire Figure-4 route

Module families: Figure4PreparePrimitive and Figure4T3.

Physical order is selector q0,q1,q2; system q3,q4,q5; coefficient q6; indicator q7; work q8. The full dimension is 512. Logical indices are (coefficient,selector,system,indicator,work), specifically coefficient x (selector x (system x (indicator x work))). Exact encoding/decoding must witness this reorder. Embedded P acts on 2,1,0 and identity on everything else; its inverse is its exact adjoint, not merely a circuit with a similar name.

The chronological root is PREPARE, middle, PREPARE†. The middle's stated ingredients are transpose-bulk indicator, conditional coefficient loaders, D-transpose sparse access, register transport, indicator uncomputation and D cleanup; f=1 makes its separate homogeneous loader identity. Those supplied actions are all required jointly, including cleanup for both coefficient inputs 0 and 1, to support arbitrary coherent coefficient states. Clean action alone makes no universal assertion about dirty indicator/work input.

Slots have d=(3,2,1,0,7,6,5,4), r_s(j)=(j+d_s) mod 8. For fixed j they biject to rows; s=7 addresses j+4. Inspection of the displayed M reconstruction shows M[j+4 mod 8,j]=0 for all j, so omitting this zero-probability slot loses no target entry. Figure-4 c(s,j)=M[r_s(j),j]/32 on ALL slots, including padded c=0. Its |c|<=1 follows from max |M_ij|=32. The alternative padded value 1 belongs to a different total loader, not a definitionally equal one.

The transpose-bulk columns are j=3,4. Rows 2,...,5 match the interior stencil, but are a different test. Concrete exclusions: column 2 has M[0,2]=-2 rather than periodic -1; column 5 has M[7,5]=-2 rather than periodic -1. Thus enlarging the transpose-bulk set to {2,3,4,5} is false for this M.

Let B be middle after exact reindexing. Its required clean entry, for a,b in {0,1}, s,t,j,i in {0,...,7}, is

    B[(b,s,i,0,0),(a,t,j,0,0)]
      = delta(s,t) delta(i,r_t(j)) R(c(t,j))[b,a].

The stronger stated branchwise cleanup ensures no omitted work sectors contribute when composing with preparation. At outer coefficient/selector/indicator/work all zero,

    (P†BP)_clean[i,j]
      = sum_s conj(P[s,0]) P[s,0] delta(i,r_s(j)) c(s,j)
      = sum_(s<7) delta(i,r_s(j)) M[r_s(j),j]/224
      = M[i,j]/224.

The last equality requires BOTH row enumeration and the absent-slot zero just checked. It is not supplied by a lone state-preparation theorem. Coefficient signs are carried by R00=c, and slot phases cancel as explained above. Unitarity of the actual full circuit and this projected identity are separate obligations. Data saying 'is unitary' or 'contains target' must specify propositions and actual proofs; declaring a record with these proposition-valued fields alone does not discharge them. An exact refinement must bind the full program including exp(i phi). An angle-dropping legacy presentation cannot be used to recover its matrix.

The resource partition is three system, four signal (selector plus coefficient), two pure ancilla (indicator/work), six auxiliary. This is a fixed-instance exact ideal circuit. Actual resource enumeration is asserted, not independently reproduced by this natural source. The internal imported middle construction is not expanded enough for gate-by-gate reconstruction in this stage.

## 6. Symmetry and XOR route

Module families: SymmetryFourSlotPrimitive and SymmetryXorFourSlotPrimitive.

The coordinate permutation C applies CX(2,1) then CX(2,0). With pair p in {0,...,3}, sector e in {0,1}, it maps physical p+4e to original label p if e=0 and 7-p if e=1. It is involutive. This map is a full basis permutation, not a projection to one sector.

The prerequisite family's cyclic coefficients are NOT the XOR coefficients. Exact standard-RY angle existence for a cyclic table does not certify an XOR SELECT circuit. To make the symmetry claim mathematically testable, derive from M the upper-left 4x4 matrix T and T-reversed cross block K, where T[p,q]=M[p,q], K[p,q]=M[p,7-q]. Centrosymmetry gives the coordinate block [[T,K],[K,T]]. Necessarily the expected sectors are Mplus=T+K, Mminus=T-K:

    Mplus = [-30,32,-2,0; 16,-31,16,-1; -1,16,-30,15; 0,-1,15,-14]
    Mminus= [-30,32,-2,0; 16,-31,16,-1; -1,16,-30,17; 0,-1,17,-46].

These are independently derived expectations, not values read from an imported provider. The source names provider sectors but does not state their definitions. Matching them to these formulas is an explicit later comparison obligation. The derived entries obey |weight|<=46<=56.

Six physical wires are pair q0,q1; sector q2; selector q3,q4; coefficient q5, with no workspace. Selector P4=RY_q4(pi/2) RY_q3(pi/2) has clean amplitude 1/2 in each slot, probability 1/4. For e,p,s define w(e,s,p)=M_e[p XOR s,p] and c=w/56; all 2*4*4=32 angles must be supplied internally. On all basis inputs SELECT=CX(3,0),CX(4,1) changes p to p XOR s and leaves e,s,coefficient unchanged. Amplitude must occur BEFORE SELECT, since c is evaluated on the input p. The middle chronology is P4, amplitude, SELECT, P4† and its sector clean block is

    sum_s (1/4) delta(i,p XOR s) M_e[p XOR s,p]/56
      = M_e[i,p]/224.

The address permutation p XOR s hits every pair index exactly once. A useful conditional cyclic/XOR discriminator is p=1,s=1 IF cyclic addressing means p+s mod4: XOR row=0 has entry 32 in column 1, whereas cyclic row=2 has entry 16. If cyclic instead means p-s mod4, use p=2,s=1: XOR row3 has column2 entry15 or17, whereas cyclic row1 has entry16. The authorized source does not specify that cyclic orientation, so these are conditional diagnostic tests, not assertions about an unread provider. Even if both reorganizations might encode the same matrix with their own coefficients, one table cannot replace the other with SELECT held fixed.

S=RY_sector(pi/2) tensor I_pair, with block rows (I,-I)/sqrt(2), (I,I)/sqrt(2). The required pair chronology is S†, middle, S, giving S middle S†; with Mplus,Mminus as above this yields [[T,K],[K,T]]/224. Replacing S by a Hadamard changes signs in the sector transformation and is not a free convention. Finally chronological C,pair,C yields matrix C S middle S† C and restores M/224 under the checked physical/logical basis map. Signal cleanup fixes q3,q4,q5=0 on input and output; sector q2 remains a system bit. This final matrix is 64x64 with 3 system and 3 signal qubits.

Again, proposition statements, witness proofs and primitive-to-logical equality are separate. Compatibility names are labels, not a cyclic route certificate. The quoted 32 RY and 62 CX belong to the amplitude compiler, not necessarily the whole final circuit. Zero abstract oracle calls does not mean zero gates or cost-free classical parameter generation. There is no finite-bit, precision, hardware-routing, optimality or cross-route cost comparison theorem here.

## 7. Parametric conjugation algebra

Module family: SystemConjugation.

Let C,S,H be arbitrary finite types with explicit decidable equality for matrix formulas, c0 in C and s0 in S. Choosing clean elements entails nonempty C,S where an instantiation is desired; no unstated arbitrary clean element exists in an empty type. For any complex V:H x H and U:(C x (S x H))^2, set

    L(V)[(c,s,i),(d,t,j)] = delta(c,d) delta(s,t) V[i,j],
    Q0(U)[i,j] = U[(c0,s0,i),(c0,s0,j)],
    Conj(V,U) = L(V) U L(V)†.

Expanding the two finite sums and collapsing deltas gives

    Q0(Conj(V,U))[i,j]
      = sum_(k,l) V[i,k] Q0(U)[k,l] conj(V[j,l]),
    Q0(Conj(V,U)) = V Q0(U) V†.

No unitarity is used for this identity. If V is unitary, L(V) is unitary; if BOTH V and U are unitary, Conj(V,U) is unitary. These are complete conjunctive sufficient premises for separate theorems, not extra assumptions on the entry identity. Rectangular left/right formulas must retain distinct finite external row/column types and cannot silently coerce them into H; their exact local signatures are absent from the permitted source. This algebra is genuinely parametric, unlike the fixed circuits. It gives no compiler or resource realization for arbitrary V.

## 8. Definitions, limitations and source integrity

My natural expectation is that tables/circuits/matrix expressions and their presentation adapters are literal definitions; finite encoding bijections give explicit reindexings, not arbitrary quantum representatives. No quotient modulo phase or false uniqueness of a unitary dilation is justified. But the source's blanket statement about every definition cannot be verified without the forbidden formal context; it is retained as a source assertion, not adopted as an implementation verdict.

Finite types/indices are typing data. Exact clean-work and wiring restrictions are genuine local operation conditions; reusable conjugation unitarity statements are explicitly conditional. Bounds, macro semantics, normalization, sparse decomposition and cleanup that the fixed construction is supposed to establish belong to dependency interfaces, not convenient new final-target hypotheses. No original-paper premise classification is inferred.

Native finite checks, symbolic identities, presentation data, propositions and proofs are different evidence kinds. This stage ran none of the claimed proofs. Namespaces, attributes and tactic budgets mentioned by the source are not mathematical premises; their actual preservation is outside this natural-only stage. 'Nine bounded modules' versus references to 'ten-target set' is a scope/bookkeeping ambiguity: this packet counts the nine named families in sections 2-7, and explicitly excludes whole symbolic RobinMatrix approval.

No direct mathematical contradiction was found among the explicit numeric formulas. That does not close the omitted provider/macro/circuit details. The independent checks above isolate the strongest later discriminators: exact compiler phase; half-angle and negative amplitudes; padded total-table differences; clean versus dirty work; transpose bulk columns; input-dependent amplitude before XOR SELECT; standard-RY sector signs; fixed versus parametric quantification; and proposition data versus proof witnesses. Stage 1 stops here, before any formal comparison or review verdict.
