# Stage2 independent source-topology comparison

Actual reviewer: `/root/robin_c47_raw_source_recovery`.
Direction: `raw-source-math-recovery`, followed by sealed-baseline source-topology comparison.
This review is independent of the author, but intentionally uses the same reviewer's frozen Stage1 reconstruction. It is not a second independent review of my own Stage1 graph.

## Verdict

**REQUEST CHANGES to semantic source coverage only.** The author proposal omits a positive-semantic disposition for the eight-wire contextual SELECT action at raw-source lines181–183. Its line map is lossless, but blanket A6 node association does not identify a node that actually retains that action.

The two fixed-target mathematical routes remain accepted at the Stage1 natural-mathematical level. Their projected-target AND/OR structure, phase conventions, clean-index transports, full-unitary separation and resource boundaries agree with the independently derived construction under the author's coarser atomic-supplier granularity. I found no new mathematical contradiction or reason to retire either route.

This is a real source-topology verdict, not a Lean/formal-fidelity or complete-module verdict. It does not authorize publishing author claims as checked formal evidence.

## Finding F01: supplied SELECT context is not semantically inventoried

A6 line181 specifies the actual eight-wire SELECT wrapper: flip selector wires3,4; apply the literal fixed adder with system as overwritten operand, selector as preserved operand and work7; flip selector3,4 back. It states clean-work j->r_s(j), preserved selector and restored work. Lines182–183 additionally provide the actual dirty-work formulas:
u=w xor b0a0; v2=a2 xor u a1; v1=a1 xor b0a0;
a0'=a0 xor b0; a1'=v1 xor b1; a2'=v2 xor b1v1 xor b2; w'=w.
This is substantive supplied circuit/action mathematics, even though it is explicitly context rather than admission of the external final consumer.

The author coverage assigns181–183 to the entire A6 set:
N14,N15,N16,N17,N18,G03,CTX-8,PHASE-8.
N14/CTX-8 are coordinates and context; N15 is coefficient data; N16/PHASE-8 are the amplitude refinement; N17 is PREPARE; N18 is scope; G03 describes the historical loader/compiler expansion. None states the positive SELECT wrapper or its clean/dirty map. N16's warning about not inferring dirty SELECT behavior is correct, but a negative non-implication is not the supplied positive action.

My sealed Stage1 R26 identified precisely this source content before I saw the author graph. The issue is not that the author has73 nodes instead of61, or20 AND edges instead of41: one grouped node preserving the action would be sufficient. The mathematical action is missing from the associated claims, not merely differently grouped.

Preferred minimal repair: add a context-only SELECT node for181–184, with dependencies on exact reversible compilation, the literal adder, eight-wire layout and offsets. Retain the actual dirty extension and the work0 condition for modular addition. This is not a new final-root premise and does not add a paper7 OR winner. Alternatively explicitly EXCLUDE this context with a reason and narrow the semantic coverage claim; do not treat a blanket NODE tag as a positive-semantic audit.

The proposed external paper7 route can still require final matching/application and the final consumer composition/refinement/cleanup. It should not imply that the local source contains no specified SELECT action at all. I did not inspect the external consumer or its implementation.

## What is accepted, and why

The full exact crosswalk is in crosswalk.json: every61 independent Stage1 node, every73 author node, every20 author AND hyperedge, the OR and all10 non-edges are explicitly compared.

- Reversible macros: exact H/T compensation and CCX phase9pi/8 are retained. Six constructor versus eight clean C3X guards and allowed control aliases match. A generic ambient carrier is not an arbitrary-width adder.
- Controlled RY: only control-to-target inequalities are required; repeated controls are permitted. Whole-context exact semantics, not a clean-only table, support the loader refinements.
- Padding: paper7 slot7 is R(1); Figure4 slot7 is R(0). They are not equal full matrices. P's zero slot7 probability justifies the projected sum.
- Figure4: the provider node N21 is coarse but explicitly carries the complete indicator/loaders/access/swap/inverse-cleanup construction. N25 retains the whole2x2 coefficient action for both coefficient inputs. It is not a basis-cleanliness-only closure. The relevant AND edges are therefore valid under that atomic-supplier reading, even though my graph splits these proofs.
- Phase: F4-REFINE explicitly keeps stored program phase -9pi/8. A bare list would differ by exp(+i9pi/8). The graph makes no unsupported phase0 claim. Exact physical phase realization and finite-bit export remain separate.
- Root transport: Figure4 uses flat clean index8j on nine wires; XOR uses indexj with coefficient5/selector3,4 clean and sector2 retained as system. Full unitary suppliers remain separate from projected blocks and concrete certificate packaging.
- XOR: the sector tables are actual T+K,T-K, amplitudes use input p, SELECT uses p xor s, and signed standard RY S-dagger-before/S-after plus two emitted C circuits restores M. Cyclic V tables are not interchangeable with Z and are not a third complete construction.
- Generic conjugation: no unitary premise is needed for the entry/block identity. Left/right rectangular carriers and the limited unitary hypotheses remain correct. The conceptual relation to XOR is explicitly not promoted to an actual implementation import edge.
- OR: P-F4 or P-XOR suffices only for a projected fixed M/224 entry identity. Separate carriers, program phases, full-unitarity witnesses, layouts, physical clean wires and resources are not equated.
- Packaging/resources: schema free Props, layoutMatches, lossy presentation Strings and empty default schedules are not granted universal semantic authority. Physical Figure4 cleanwork2 and computed Resource.pureAncilla0 remain distinct. Finite exact-real counts are not finite-bit preprocessing/synthesis/hardware guarantees.

Author E03's external head fixed_adder_complex_permutation must be read as the actual full-carrier compiled permutation, with its modular-addition action conditional on work0. Under that explicit reading it matches the source. Reading it as an ideal all-dirty adder would be false, but the node/source disclaimers do not support that reading; I record clarification rather than inventing a second defect.

N38 bundles arbitrary-type Q extraction and finite/DecEq product identities. Its finite E17 tails apply to the latter, not an extra requirement for defining Q. Again the full source and node say this explicitly; differing granularity is not a rejection reason.

## Coverage and evidence scope

The author line map concatenates to the exact41709-code-unit raw source, with contiguous offsets and414 sequential lines. All headings/blanks are excluded with a reason. It assigns298 NODE lines; Stage1 assigned209 substantive NODE lines. The89 extras are standalone mathematical delimiters/environment rows, harmlessly retained as NODE. No substantive raw line was hidden by an EXCLUDED label. The failure is semantic association at181–183, not loss of bytes.

source-coverage-comparison.json retains a disposition comparison for every414 line; the existing Stage1 lines and node definitions are not rewritten. The supplied table/circuit mathematics is not accepted merely because this mechanical check passes.

The allowed statement seal and navigation files are still author proposals. They refer to uninspected audit files, claim215 target declarations/25 critical contracts and list static imports. Those counts and actual imports are not verified here, and none supplies missing formal fidelity. Embedded historical metadata was not treated as a prior verdict; no referenced prior report or audit was opened.

## Public reproduction and sealed-stage chronology

Stage1 was sealed before the six new author files were read. Its input hash, original artifact hashes and original seal hash are recorded in publicsafe-envelope.json. The original six-publicsafe Stage1 rule is unchanged: I do not newly authorize publishing its scope-manifest.json, SHA256SUMS.json or SEAL.md. The new publicsafe envelope publishes hashes and a bounded chronology without reproducing those original audit-only bytes or local absolute paths.

All Stage2 files are new. No source, author proposal, Stage1 file, registry or implementation was modified. No network, Git writes, builds or child agents were used. Optional literal-construction-data.json was not read.

Failure class: SOURCE_INVALID, bounded to semantic exhaustiveness of the author topology/coverage proposal. Raw-source mathematics: NONE; Stage1 verdict unchanged. Salvage: all accepted bounded roots/suppliers and the existing lossless line retention survive; repair only the missing context disposition. Formal/compiler/full-module/paper/finite-bit/PURIFIED states remain unassessed. Stop after this Stage2 seal; later formal release requires separate authorization.

