# Positive SELECT-context construction audit — AUTHOR proposal

This is the bounded mathematical audit for proposed node SELECT8-CONTEXT and edge E20-CONTEXT-SELECT8. It is source-topology recovery from the fixed LOCAL natural source, not a new algorithm, a Lean/formal check or independent acceptance. F01 remains pending the actual independent reviewer.

## Source and scope

The unchanged source is W/robin-nine-c46-natural-source-v2-author/natural-source-v2.md, version2, SHA25610681db8c6f62818bcdd8d6eef787027983b010540e86c547afbaacc34031790. A6 lines181–183 supply positive wrapper/action mathematics; line184 bounds it. The previous blanket A6 association did not retain that mathematics in any positive node. This successor adds that node, rather than using the correct negative spectator warning as its substitute.

The eight physical wires are system0,1,2; selector3,4,5; coefficient6; work7. All8selector labels and bothwork values remain physical. Use coefficient bit z, original selector s, original system bits a0,a1,a2 and work w. No initial cleanliness is assumed for defining the actual permutation.

## Why these four AND suppliers are sufficient

N14 supplies the full256-state coordinates and wire layout (source169–175). Embed A3's seven local wires by (0,1,2,3,4,5,6) ->(0,1,2,3,4,5,7). This is injective and leaves q6 unused. Every concrete distinct-wire guard of the eight reversible instructions remains true. Coefficient6 is consequently a genuine spectator of THIS wrapper; this is not deduced from an amplitude theorem.

Before the adder, X3 and X4 flip the selector's two low bits. Thus its integer operand is b=s XOR3. Enumerating s=0,...,7 gives exactly3,2,1,0,7,6,5,4: the N22 offset d_s (source143–146). No label is removed, including padded selector7. The outer X gates commute because their targets differ; after the adder the suffix flips restore the original selector.

N08 supplies the literal eight-instruction adder (source73–89), embedded as:

1. CCX(3,0;7)
2. CCX(7,1;2)
3. CCX(3,0;7)
4. CCX(3,0;1)
5. CX(3;0)
6. CCX(4,1;2)
7. CX(4;1)
8. CX(5;2)

For the actual full dirty extension, follow these literal bits rather than extending a clean-only arithmetic theorem. The first gate gives u=w XOR(b0 AND a0). The second gives v2=a2 XOR(u AND a1). The third restores work to its original w because neither a0 nor b0 has changed. The fourth gives v1=a1 XOR(b0 AND a0). The remaining gates give exactly:

a0'=a0 XORb0;
a1'=v1 XORb1;
a2'=v2 XOR(b1 AND v1) XORb2;
w'=w.

These are the positive formulas at source182–183, valid for all original bits. b is unchanged by the adder, so the final X3/X4 restores s. z is unchanged throughout. Work value is preserved but can affect the system output through u; that is NOT an ideal modular addition tensored with identity on work.

For inputw=0, N08's carry argument gives j'=(j+b)mod8. The offset identification gives j'=r_s(j), with work0 restored. This exact input condition is retained; it is not a premise for defining the full actual permutation, and no stronger full dirty ideal-adder claim is made.

N06 supplies phase-aware exact gate/list compilation (source39–58), with its existing ANDsuppliers N01,N05 retained. Thus the whole embedded literal wrapper has the complex permutation semantics of THIS actual bit map on all256 states. Exact H/T/Tdg/CCX scalar compensation is retained; the raw primitive list is not rebranded phase0 or identified modulo globalphase.

Accordingly E20-CONTEXT-SELECT8 has all four tails N06,N08,N14,N22. These are construction dependencies, not newly assumed final Anchor hypotheses. N08 provides the literal list as well as its clean corollary: the dirty map above comes from that list, not from a claimed clean-to-dirty implication.

## What the new node does not establish

Source184's negative warning remains: the amplitude loader's q7-spectator equality cannot prove stronger SELECT behavior. Existing non-edge N16 ->SELECT_dirty_work_identity stays unchanged. Positive actual action and the negative non-implication have different jobs.

No edge connects SELECT8-CONTEXT to the bounded fixed target or a certificate. The existing Figure4/XOR projectedM/224 OR, all20 oldANDedges, all73 oldnodes and all10 non-edges remain unchanged. The external paper7 route may now cite the supplied local SELECT node, but still requires exact matching/application and the final outsideconsumer composition/refinement/cleanup/projection. It is not a thirdORwinner. WholeRobinMatrix remains outside scope.

This is an AUTHOR proposed repair. Lossless source bytes, line counts, a positive node label or a passing structural validator do not themselves establish semantic completeness or close the independent finding.
