param(
  [Parameter(Mandatory=$true)][string]$RepositoryRoot,
  [Parameter(Mandatory=$true)][string]$WorkspaceRoot,
  [string]$PacketRoot=$PSScriptRoot
)
$ErrorActionPreference='Stop'
$utf8Strict=[System.Text.UTF8Encoding]::new($false,$true)
function Read-Utf8([string]$Path) { return $utf8Strict.GetString([System.IO.File]::ReadAllBytes($Path)) }
function Assert-Local([bool]$Condition,[string]$Message) { if (-not $Condition) { throw $Message } }
function Verify-Pin([string]$Base,$Pin) {
  $resolved=Join-Path $Base $Pin.path
  $item=Get-Item -LiteralPath $resolved
  $digest=(Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash.ToLowerInvariant()
  Assert-Local ($digest -ceq $Pin.sha256) ("Changed raw input: "+$Pin.path)
  if ($null -ne $Pin.bytes) { Assert-Local ($item.Length -eq $Pin.bytes) ("Changed byte count: "+$Pin.path) }
  return [ordered]@{path=$Pin.path;sha256=$digest;bytes=$item.Length}
}
function Mask-LeanComments([string]$Value) {
  $chars=$Value.ToCharArray()
  $depth=0; $lineComment=$false; $inString=$false; $escaped=$false
  for ($i=0; $i -lt $chars.Length; $i++) {
    $ch=$Value[$i]
    $next=if ($i+1 -lt $Value.Length) { $Value[$i+1] } else { [char]0 }
    if ($lineComment) {
      if ($ch -eq [char]10) { $lineComment=$false } elseif ($ch -ne [char]13) { $chars[$i]=[char]32 }
      continue
    }
    if ($depth -gt 0) {
      if ($ch -eq '/' -and $next -eq '-') { $chars[$i]=[char]32; $chars[$i+1]=[char]32; $i++; $depth++; continue }
      if ($ch -eq '-' -and $next -eq '/') { $chars[$i]=[char]32; $chars[$i+1]=[char]32; $i++; $depth--; continue }
      if ($ch -ne [char]10 -and $ch -ne [char]13) { $chars[$i]=[char]32 }
      continue
    }
    if ($inString) {
      if ($escaped) { $escaped=$false; continue }
      if ($ch -eq '\') { $escaped=$true; continue }
      if ($ch -eq '"') { $inString=$false }
      continue
    }
    if ($ch -eq '"') { $inString=$true; continue }
    if ($ch -eq '/' -and $next -eq '-') { $chars[$i]=[char]32; $chars[$i+1]=[char]32; $i++; $depth=1; continue }
    if ($ch -eq '-' -and $next -eq '-') { $chars[$i]=[char]32; $chars[$i+1]=[char]32; $i++; $lineComment=$true }
  }
  Assert-Local ($depth -eq 0 -and -not $inString) 'Unterminated target comment/string'
  return (-join $chars)
}
$pins=Read-Utf8 (Join-Path $PacketRoot 'input-pins.json') | ConvertFrom-Json -Depth 100
$repositoryAfter=@($pins.repository_inputs_before | ForEach-Object { Verify-Pin $RepositoryRoot $_ })
$supplementAfter=@($pins.supplemental_repository_hash_only | ForEach-Object { Verify-Pin $RepositoryRoot $_ })
$governanceAfter=@($pins.governance | ForEach-Object { Verify-Pin $RepositoryRoot $_ })
$feedbackAfter=@($pins.late_feedback_and_predecessor_source_graph | ForEach-Object { Verify-Pin $WorkspaceRoot $_ })
$inventoryAfter=@($pins.inherited_target_inventory | ForEach-Object { Verify-Pin $WorkspaceRoot $_ })
$protectedAfter=@($pins.protected_predecessor_files | ForEach-Object { Verify-Pin $WorkspaceRoot $_ })
$sourcePath=Join-Path $PacketRoot 'natural-source-v2.md'
$source=Read-Utf8 $sourcePath
$sourceHash=(Get-FileHash -LiteralPath $sourcePath -Algorithm SHA256).Hash.ToLowerInvariant()
$coverage=Read-Utf8 (Join-Path $PacketRoot 'source-proof-coverage-proposal.json') | ConvertFrom-Json -Depth 100
Assert-Local ($coverage.sha256 -ceq $sourceHash) 'Source/coverage hash mismatch'
Assert-Local ((-join @($coverage.lines | ForEach-Object { $_.text })) -ceq $source) 'Source line coverage not lossless'
$nextOffset=0; $nextLine=1
foreach ($r in $coverage.lines) {
  Assert-Local ($r.line -eq $nextLine -and $r.startOffset -eq $nextOffset) 'Source line/offset partition gap'
  Assert-Local ($r.endOffset -eq $r.startOffset+$r.text.Length) 'Source region length mismatch'
  Assert-Local ($r.classification -in @('NODE','EXCLUDED')) 'Unclassified source line'
  if ($r.classification -eq 'NODE') { Assert-Local ($r.node_ids.Count -gt 0) 'NODE has no navigation binding' }
  $nextLine++; $nextOffset=$r.endOffset
}
Assert-Local ($nextOffset -eq $source.Length -and $coverage.line_count -eq 414) 'Source terminal offset/count mismatch'
foreach ($binding in @(@('source-version.json','new_sha256'),@('source-delta.json','source_sha256'),@('statement-seal-proposal.json','source_sha256'),@('source-graph-v3-proposal.json','source_sha256'),@('four-view-navigation.json','source_sha256'))) {
  $obj=Read-Utf8 (Join-Path $PacketRoot $binding[0]) | ConvertFrom-Json -Depth 100
  Assert-Local ($obj.($binding[1]) -ceq $sourceHash) ('Stale source binding: '+$binding[0])
}
$audit=Read-Utf8 (Join-Path $PacketRoot 'author-audit/declaration-binder-definition-coverage.json') | ConvertFrom-Json -Depth 100
$declarations=0; $ambientRegions=0; $targetChecks=@()
foreach ($module in $audit.modules) {
  $raw=Read-Utf8 (Join-Path $RepositoryRoot $module.path)
  $mask=Mask-LeanComments $raw
  Assert-Local ((-join @($module.records | ForEach-Object { $_.formal_region })) -ceq $mask) ('Masked region mismatch: '+$module.path)
  $expected=0
  foreach ($r in $module.records) {
    Assert-Local ($r.startOffset -eq $expected -and $r.endOffset -eq $r.startOffset+$r.formal_region.Length) ('Formal partition gap: '+$module.path)
    $expected=$r.endOffset
    if ($r.kind -eq 'ambient') { $ambientRegions++ } else { $declarations++ }
  }
  Assert-Local ($expected -eq $raw.Length) ('Incomplete formal partition: '+$module.path)
  $targetChecks+=[ordered]@{path=$module.path;characters=$raw.Length;regions=$module.records.Count;literal_preserving_mask=$true}
}
Assert-Local ($audit.modules.Count -eq 9 -and $declarations -eq 215) 'Wrong target/declaration count'
$graph=Read-Utf8 (Join-Path $PacketRoot 'source-graph-v3-proposal.json') | ConvertFrom-Json -Depth 100
$oldGraph=Read-Utf8 (Join-Path $WorkspaceRoot 'robin-nine-c45-graph-v2-proposal/canonical-source-graph-v2.json') | ConvertFrom-Json -Depth 100
Assert-Local ($graph.nodes.Count -eq 73 -and $graph.edges.Count -eq 20) 'Graph baseline count changed'
Assert-Local ((-join @($graph.nodes.id | Sort-Object)) -ceq (-join @($oldGraph.nodes.id | Sort-Object))) 'Stable node IDs changed'
foreach ($e in $oldGraph.edges) {
  $n=@($graph.edges | Where-Object { $_.id -ceq $e.id })
  Assert-Local ($n.Count -eq 1 -and $n[0].mode -ceq 'AND') ('Lost AND edge: '+$e.id)
  Assert-Local ((($n[0].tails | ConvertTo-Json -Compress) -ceq ($e.tails | ConvertTo-Json -Compress)) -and (($n[0].heads | ConvertTo-Json -Compress) -ceq ($e.heads | ConvertTo-Json -Compress))) ('Changed suppliers/head: '+$e.id)
}
Assert-Local ($graph.alternative_routes.Count -eq 1 -and $graph.alternative_routes[0].routes.Count -eq 2) 'OR routes broadened'
Assert-Local (($graph.alternative_routes[0].heads | ConvertTo-Json -Compress -AsArray) -ceq '["clean_fixed_M_over_224"]') 'OR head broadened'
Assert-Local (($graph.nodes | Where-Object { $_.id -eq 'N40' }).exact_source_ranges[0][0] -eq 3) 'Lost source line3 provenance'
$checkedPaths=@()
foreach ($file in Get-ChildItem -LiteralPath $PacketRoot -Recurse -File) {
  $rel=[System.IO.Path]::GetRelativePath($PacketRoot,$file.FullName).Replace('\','/')
  $v=Read-Utf8 $file.FullName
  Assert-Local (-not $v.Contains([char]13)) ('NonLF file: '+$rel)
  Assert-Local ($v.EndsWith([string][char]10) -and -not $v.EndsWith(([string][char]10+[string][char]10))) ('Not single terminal LF: '+$rel)
  Assert-Local ($v.Length -eq 0 -or $v[0] -ne [char]0xFEFF) ('BOM: '+$rel)
  Assert-Local ($v -notmatch '(?i)(?:\b[A-Z]:/|\b[A-Z]:\\(?!\\?mathrm\b)|\\\\[A-Za-z0-9._-]+\\[A-Za-z0-9._-]+(?:\\|/)|/(?:Users|home|mnt)/)') ('Private absolute path: '+$rel)
  Assert-Local ($v -notmatch '(?:\bsk-[A-Za-z0-9]{20,}|\bgh[pousr]_[A-Za-z0-9]{20,}|\bAKIA[A-Z0-9]{16})') ('Credential pattern: '+$rel)
  if ($file.Extension -eq '.json') { $null=$v | ConvertFrom-Json -Depth 100 }
  $checkedPaths+=$rel
}
$sealedCount=$null
if (Test-Path -LiteralPath (Join-Path $PacketRoot 'seal.json')) {
  $seal=Read-Utf8 (Join-Path $PacketRoot 'seal.json') | ConvertFrom-Json -Depth 100
  $sealedCount=$seal.files.Count
  $null=@($seal.files | ForEach-Object { Verify-Pin $PacketRoot $_ })
  Assert-Local (((@($checkedPaths | Where-Object { $_ -ne 'seal.json' } | Sort-Object)) -join '|') -ceq ((@($seal.files.path | Sort-Object)) -join '|')) 'Seal missing/extra file'
}
[ordered]@{
  schema='natural-source-v2-readonly-structural-validation'
  status='PASS_READONLY_STRUCTURAL_CHECKS_ONLY'
  source_sha256=$sourceHash
  source_lines=414
  targets=9
  declarations=$declarations
  ambient_regions=$ambientRegions
  target_mask_checks=$targetChecks
  source_nodes=73
  AND_edges=20
  OR_projected_routes=2
  repository_after=$repositoryAfter
  supplemental_hash_only_after=$supplementAfter
  governance_after=$governanceAfter
  authorized_feedback_after=$feedbackAfter
  inherited_inventory_after=$inventoryAfter
  protected_predecessors_after=$protectedAfter
  checked_packet_paths=$checkedPaths
  sealed_file_count=$sealedCount
  evidence_limit='Hashes, lossless partitions, literal-preserving comment mask, stable AND structure, JSON/LF/public-path/credential-pattern scans only. No math proof validation, independent acceptance, Lean/native/compiler/axiom gate or publication.'
} | ConvertTo-Json -Depth 100
