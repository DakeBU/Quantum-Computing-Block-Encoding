# Independent Stage3 source-topology successor review

Reviewer: `/root/robin_c47_raw_source_recovery`, the same independent raw-source reviewer who sealed Stage1 and Stage2.
Review direction: frozen source-only baseline -> bounded SELECT-context topology successor.
Authority: unchanged retrospective LOCAL mathematical source, not original-paper or formal-source certification.

## Actual verdict

**ACCEPT_BOUNDED_SOURCE_TOPOLOGY_SUCCESSOR.** The pinned graphv4/coveragev3 pair repairs Stage2 F01. The finding is resolved for these new exact successor bytes only. The prior Stage2 graphv3/map remain the objects for which the original REQUEST_CHANGES verdict was correct; no prior file or verdict has been amended.

The positive SELECT action is now a real claim with a complete construction dependency edge and precise per-line semantic association. This conclusion follows from the independent derivation below, not from the author's repair status or a mechanical PASS label. Optional repair-ledger/construction-audit files were not needed and remain unread.

This is a source-topology/coverage acceptance only. It is not actual Lean-signature fidelity, a compiler/kernel/axiom gate, complete-module review, external consumer admission, original-paper authentication, finite-bit efficiency, public admission or PURIFIED/Exposition Seal.

## Pinned comparison

The allowlist SHA256 is3b10f321dce819bdccf8efc99e1a45cc8faf38366fb5c857e35fd8bc5acfbd21.
The unchanged natural-source-v2 SHA256 is10681db8c6f62818bcdd8d6eef787027983b010540e86c547afbaacc34031790,41921bytes/41709UTF16 code units.
The graphv4 SHA256 iseb559adfcb49ed3760de99f28a9cc1b7baebf480927a867cdce3d684ad877e18.
The coveragev3 SHA256 ise1f3c17e0ea3d0fcf1a853eed4b74f21b74f4dfecf5694fd02c6c79099db6137.

Every old73 node object and20 edge object is exactly unchanged under full JSON serialization, not merely the same ID or informal meaning. The new totals are74nodes/21ANDedges. The only added node is SELECT8-CONTEXT; the only added edge is E20-CONTEXT-SELECT8. Existing bounded root edges, the projected-target OR, all10 non-edges, interface-node list, source-boundary records and scope quarantine are unchanged.

All414 coverage lines reconstruct the exact source text with contiguous original offsets. Only line objects181–184 differ. Lines181–183 now name the positive context node with individual semantics;184 names it together with N16 and retains the negative spectator non-implication. Other410 complete line objects are unchanged. Complete comparison records are in comparison-checks.json and source-coverage-comparison.json.

## Independent reconstruction of the repaired claim

Physical registers are system0,1,2; selector3,4,5; coefficient6; work7. Let a0,a1,a2 be original system bits, s the original selector, z the coefficient and w arbitrary work.

Prefix X3,X4 changes selector to b=s XOR3. Its integer value is d_s=(3,2,1,0,7,6,5,4)[s], including physical padded slot7. The source's seven-wire adder embeds by0,1,2,3,4,5,6 ->0,1,2,3,4,5,7, leaving coefficient6 untouched. This map is injective and all mapped CCX/CX wire guards remain true. No new clean-work assumption is used for well-formedness.

Read the mapped gates in chronological order:

1. CCX(3,0;7) changes work to u=w XOR b0a0.
2. CCX(7,1;2) changes the high system bit to v2=a2 XOR u a1.
3. CCX(3,0;7) restores work to w, because both controls are still unchanged.
4. CCX(3,0;1) changes the middle bit to v1=a1 XOR b0a0.
5. CX(3;0) gives a0'=a0 XOR b0.
6. CCX(4,1;2) changes the high bit by b1v1.
7. CX(4;1) gives a1'=v1 XOR b1.
8. CX(5;2) gives a2'=v2 XOR b1v1 XOR b2.

The suffix X3,X4 restores the original selector. Coefficient6 never occurs in any instruction, and work7 ends at its original value. These are exactly source182–183 and the new node's dirty_action, for both work values and both coefficient values. A preserved work value is not a tensor-identity spectator: system output still depends on w.

For w=0, the existing fixed-width carry argument gives j'=(j+d_s)mod8=r_s(j), with work0 restored. It would be invalid to apply that clean theorem to w=1. Here the arbitrary-work result is instead derived directly from the literal gate list. Relative to clean addition on the same j,s, the only extra high-bit toggle is w*a1. A concrete discriminator is s=0,j=2,w=1: actual system output1, whereas ideal modular addition would give5. This prevents accidentally accepting an all-dirty ideal-adder claim.

The new node retains all physical8 selector values, the literal wrapper, originalselector/coefficient preservation and actual dirty extension. It explicitly states local context only and does not add a caller premise or a new final consumer.

## Four-way AND supplier audit

E20-CONTEXT-SELECT8 has complete tail {N06,N08,N14,N22} and head SELECT8-CONTEXT.

- N14 supplies full eight-wire coordinates/inverse, including arbitrary work and coefficient spectator placement.
- N22 supplies the complete d_s/r_s addressing needed for the selector prefix and the clean addition interpretation.
- N08 supplies the literal eight-instruction A3 construction and its clean carry corollary. The literal list, not an inappropriate clean theorem, supplies the independently derived dirty formulas.
- N06 supplies exact compilation/composition of the actual entire reversible list; its existing E01 ancestors N01,N05 retain reverse chronology and exact compensated gate macros. The injective physical embedding preserves all guards.

These are source construction dependencies, not new public Anchor hypotheses. No PREPARE probability, coefficient table, amplitude loader or claimed final block is smuggled into the input. The four suppliers suffice at this natural-source layer; lack of a fresh elaborated Lean dependency graph is not hidden.

There are five CCX macros in the embedded adder. Their existing exact compilation has stored scalar phase5*(9pi/8)=45pi/8; outer X has phase0. Thus the interpreted Program equals the actual full-carrier permutation. The bare primitive list is not silently assigned phase0 or identified with that permutation modulo global phase. No physical phase-synthesis or finite-bit cost result is newly claimed.

## Independent diagnostic and its limit

select-context-checks.js was independently transcribed from the raw literal reversible wrapper, not taken from the optional author audit. It executes1669 exact assertions over all256 basis inputs:128 work0,128 work1, both coefficients and all8 selector labels. All output formulas, selector/coefficient/work preservation, mapped guards and full permutation size agree. There are64 dirty inputs where ideal modular addition fails; the discriminator above is recorded.

This is finite exact supporting evidence for a fixed eight-wire object. The gate-by-gate derivation and already stated generic source compiler argument supply the mathematical reasoning. The diagnostic is not Lean, kernel, arbitrary-width or compiled primitive-matrix evidence, and it does not promote the source's actual implementation assertions.

## External route, OR and invariant root boundary

The external-paper7 descriptor now lists the supplied context node and separately requires exact matching/application to the uninspected final consumer, final PREPARE/amplitude/SELECT/unprepare composition/refinement/cleanup, phase/index/normalizer matching and the final projected-target proof. This correctly narrows what is locally supplied without declaring that consumer complete.

SELECT8-CONTEXT is not a bounded OR winner, nor a new prerequisite of the unchanged Figure4/XOR target roots or certificate conjunctions. Those routes still agree only at projected fixed M/224, with their own physical clean embeddings, phases, full unitarity suppliers, layouts and resources. Cyclic angle interfaces remain distinct from XOR; generic conjugation is not promoted into an actual implementation-import edge.

Figure4's program phase-9pi/8, clean embedding8j, physicalwork2 versus resourcepure0, and XOR's zero phase/clean embeddingj/sector2-as-system are untouched. No full-matrix/resource equivalence, third route, arbitrary-width theorem, table-generation algorithm, numerical synthesis or hardware result is inferred.

## Reading, immutability and publication boundary

The new allowlist was read and hash-checked first. Only its three required source/graph/map inputs were then loaded, before baseline comparison. Previously inspected/pinned source-only predecessor graph/map and my own public Stage1 graph/coverage and Stage2 typedF01 were reread for exact comparison; no Stage1 audit-only envelope bytes were reopened. Optional author explanations were left unread.

No RLean, author-audit, formal decoder, publication metadata, other reviewer packet or predecessor hidden feedback file was opened. Embedded legacy inventory/provenance labels in the allowed graph are not treated as verified evidence. No network/Git/compiler/child agents were used. All output is in a new exclusive Stage3 directory; every predecessor file is preserved.

The new publicsafe envelope records exact input pins and chronological scope without local absolute paths or private audit contents. Stage1 andStage2 retain their original publicsafe rules; no prior audit-only bytes receive new publication authorization. This review's own exact publicsafe list is specified separately and bound by its manifest.

Failure class: NONE for this bounded successor review. Stage2 F01 status is an additive successor resolution, not retroactive approval. Remaining formal/compiler/fullmodule/paper/finitebit/admission/PURIFIED gates are unassessed and require separate release/evidence. Stop after this seal.

