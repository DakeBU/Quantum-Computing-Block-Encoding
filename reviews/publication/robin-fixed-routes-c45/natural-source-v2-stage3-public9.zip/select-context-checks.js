function runSelectContextChecks() {
  const d=[3,2,1,0,7,6,5,4];
  const gates=[["X",3],["X",4],["CCX",3,0,7],["CCX",7,1,2],["CCX",3,0,7],["CCX",3,0,1],["CX",3,0],["CCX",4,1,2],["CX",4,1],["CX",5,2],["X",3],["X",4]];
  const bits=n=>Array.from({length:8},(_,k)=>(n>>k)&1);
  const value=a=>a.reduce((v,b,k)=>v+(b<<k),0);
  const act=(a)=>{a=a.slice();for(const g of gates){if(g[0]==="X")a[g[1]]^=1;else if(g[0]==="CX")a[g[2]]^=a[g[1]];else a[g[3]]^=a[g[1]]&a[g[2]];}return a;};
  let checks=0,cleanInputs=0,dirtyInputs=0,dirtyNonIdeal=0;
  const outputs=new Set();
  function eq(a,b,label){checks++;if(a!==b)throw Error(label+": "+a+" != "+b);}
  for(let n=0;n<256;n++){
    const a=bits(n),z=a[6],w=a[7],j=value(a.slice(0,3)),s=value(a.slice(3,6));
    const bb=bits(s^3),b0=bb[0],b1=bb[1],b2=bb[2];
    eq(s^3,d[s],"prefix offset including padded slot");
    const u=w^(b0&a[0]),v2=a[2]^(u&a[1]),v1=a[1]^(b0&a[0]);
    const expected=[a[0]^b0,v1^b1,v2^(b1&v1)^b2,...a.slice(3,6),z,w];
    const out=act(a),jp=value(out.slice(0,3));
    eq(value(out),value(expected),"entire arbitrary-work source formula");
    eq(value(out.slice(3,6)),s,"original selector preserved");
    eq(out[6],z,"coefficient spectator");
    eq(out[7],w,"work preserved");
    eq(jp,((j+d[s])%8)^((w&a[1])<<2),"dirty deviation is original high-carry perturbation");
    if(w===0){cleanInputs++;eq(jp,(j+d[s])%8,"clean modular addition");}
    else{dirtyInputs++;if(jp!==(j+d[s])%8)dirtyNonIdeal++;}
    outputs.add(value(out));
  }
  eq(outputs.size,256,"full input-output permutation");
  const witness=[0,1,0,0,0,0,0,1],wout=act(witness);
  eq(value(wout.slice(0,3)),1,"dirty discriminator output");
  eq((2+d[0])%8,5,"dirty discriminator ideal output");
  const guardFailures=gates.filter(g=>g[0]==="CX"&&g[1]===g[2]||g[0]==="CCX"&&new Set(g.slice(1)).size!==3);
  eq(guardFailures.length,0,"all mapped gate guards");
  eq(gates.some(g=>g.slice(1).includes(6)),false,"coefficient wire unused in literal reversible wrapper");
  return {evidenceClass:"Independent finite exact bit/permutation diagnostic, not Lean/compiler evidence",basisInputs:256,cleanInputs,dirtyInputs,assertions:checks,uniqueOutputs:outputs.size,dirtyInputsNotIdealAddition:dirtyNonIdeal,dirtyWitness:{selector:0,system:2,work:1,actualSystem:1,idealAdditionWouldBe:5},allMappedGateGuards:true,coefficientWireUnused:true,genericPhaseProof:"The five existing CCX exact compiler macros contribute stored phase5*(9pi/8)=45pi/8, outer X phase0. This is analytic transport from the fixed source, not numeric phase simulation.",boundary:"All8 selector values including padded7; no probability weights/loader assumptions/newfinalroot supplied."};
}
if(typeof module!=="undefined"&&require.main===module)console.log(JSON.stringify(runSelectContextChecks(),null,2));

