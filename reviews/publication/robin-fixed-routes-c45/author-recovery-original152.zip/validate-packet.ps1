param(
  [Parameter(Mandatory=$true)][string]$SourceRoot,
  [string]$PacketRoot=$PSScriptRoot
)
$ErrorActionPreference='Stop'
function Mask-Comments([string]$s) {
  $b=[Text.StringBuilder]::new()
  $mode='code'; $depth=0
  for($i=0;$i -lt $s.Length;$i++) {
    $c=$s[$i]
    $n=if($i+1 -lt $s.Length){$s[$i+1]}else{[char]0}
    if($mode -eq 'line') {
      if($c -eq [char]10 -or $c -eq [char]13) {$mode='code';[void]$b.Append($c)}
      else {[void]$b.Append(' ')}
    } elseif($mode -eq 'block') {
      if($c -eq '/' -and $n -eq '-') {$depth++;[void]$b.Append('  ');$i++}
      elseif($c -eq '-' -and $n -eq '/') {$depth--;[void]$b.Append('  ');$i++;if($depth -eq 0){$mode='code'}}
      elseif($c -eq [char]10 -or $c -eq [char]13) {[void]$b.Append($c)}
      else {[void]$b.Append(' ')}
    } elseif($mode -eq 'string') {
      [void]$b.Append($c)
      if($c -eq '\') {if($i+1 -lt $s.Length){$i++;[void]$b.Append($s[$i])}}
      elseif($c -eq '"') {$mode='code'}
    } elseif($mode -eq 'identifier') {
      [void]$b.Append($c)
      if($c -eq '»') {$mode='code'}
    } else {
      if($c -eq '-' -and $n -eq '-') {$mode='line';[void]$b.Append('  ');$i++}
      elseif($c -eq '/' -and $n -eq '-') {$mode='block';$depth=1;[void]$b.Append('  ');$i++}
      else {[void]$b.Append($c);if($c -eq '"'){$mode='string'};if($c -eq '«'){$mode='identifier'}}
    }
  }
  if($mode -ne 'code' -and $mode -ne 'line'){throw 'Unclosed lexical construct'}
  return $b.ToString()
}
$pins=Get-Content -Raw -LiteralPath (Join-Path $PacketRoot 'pins-before.json') | ConvertFrom-Json
$results=@()
foreach($p in $pins.formalSources) {
  if(-not $p.path.StartsWith('QuantumBlockEncoding/')){continue}
  $src=Join-Path $SourceRoot $p.path
  $dst=Join-Path $PacketRoot ('formal-only/'+$p.path)
  $expected=Mask-Comments ([IO.File]::ReadAllText($src))
  $actual=[IO.File]::ReadAllText($dst)
  $results+=[pscustomobject]@{path=$p.path;equal=($expected -ceq $actual);expectedChars=$expected.Length;actualChars=$actual.Length;rawSha256Equal=((Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash.ToLower() -eq $p.sha256)}
}
$bounded=Get-Content -Raw -LiteralPath (Join-Path $PacketRoot 'bounded-nine/extents-and-adequacy.json') | ConvertFrom-Json
$boundedResults=@()
foreach($p in $bounded.providers) {
  $masked=Mask-Comments ([IO.File]::ReadAllText((Join-Path $SourceRoot $p.source)))
  $b=[Text.StringBuilder]::new()
  foreach($e in $p.extents) {[void]$b.Append($masked.Substring($e.sourceStart,$e.sourceEnd-$e.sourceStart))}
  $actual=[IO.File]::ReadAllText((Join-Path $PacketRoot $p.file))
  $boundedResults+=[pscustomobject]@{path=$p.file;equal=($b.ToString() -ceq $actual);chars=$actual.Length}
}
$inventoryResults=@()
foreach($p in $pins.formalSources) {
  if(-not $p.path.StartsWith('QuantumBlockEncoding/')){continue}
  $v=Get-Content -Raw -LiteralPath (Join-Path $PacketRoot ('inventory/'+$p.path+'.json')) | ConvertFrom-Json
  $position=0;$good=$true
  foreach($r in $v.regions) {
    if($r.offset -ne $position -or $r.endOffset -lt $r.offset){$good=$false}
    $position=$r.endOffset
  }
  $inventoryResults+=[pscustomobject]@{path=$p.path;consecutiveCompletePartition=($good -and $position -eq $v.characterCount);regions=$v.regions.Count}
}
$leaks=@()
foreach($f in Get-ChildItem -LiteralPath $PacketRoot -Recurse -File) {
  $s=[IO.File]::ReadAllText($f.FullName)
  $matches=[regex]::Matches($s,'(?i)\b[A-Z]:[\\/]|/(?:Users|home)/[^/\s]+/|(?:sk-[A-Za-z0-9_-]{20,}|ghp_[A-Za-z0-9]{20,})')
  foreach($m in $matches) {
    $leaks+=[pscustomobject]@{path=$f.FullName.Substring($PacketRoot.Length+1).Replace('\','/');offset=$m.Index;kind='private-path-or-credential-pattern'}
  }
}
[pscustomobject]@{kind='deterministic lexical evidence only';formalSnapshotChecks=$results;allFormalSnapshotsExact=(@($results|Where-Object{-not $_.equal -or -not $_.rawSha256Equal}).Count -eq 0);boundedProjectionChecks=$boundedResults;allBoundedProjectionsExact=(@($boundedResults|Where-Object{-not $_.equal}).Count -eq 0);inventoryPartitionChecks=$inventoryResults;allInventoriesPartitionFullSource=(@($inventoryResults|Where-Object{-not $_.consecutiveCompletePartition}).Count -eq 0);pathCredentialPatternFindings=$leaks;scannedEveryCurrentFile=$true;limitations='Not Lean elaboration, compilation, semantic review, or a general credential detector. Source strings and identifiers preserved exactly; config raw bytes archived separately.'} | ConvertTo-Json -Depth 7 -Compress

