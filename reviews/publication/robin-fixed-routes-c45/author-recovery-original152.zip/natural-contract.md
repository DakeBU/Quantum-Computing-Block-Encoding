# Local mathematical contract and construction

Evidence class: implementation-informed retrospective AUTHOR recovery. Nine bounded target modules were read semantically, including proof bodies and ambient commands. No compilation or independent/source-first approval is asserted. Exact declarations and all source lines remain in the formal snapshots; per-declaration classification is in coverage-and-binders.json. RobinMatrix has a separate, explicitly incomplete semantic checkpoint.

## 1. Shared carriers and target

PrimitiveBasis q is the bit function Fin q → Fin 2. A flattened index is little-endian: bit q0 has weight 1. Matrices act on column vectors; a chronological list g₁,…,gₖ denotes gₖ⋯g₁. A PrimitiveProgram also multiplies this matrix by its declared exp(iφ). Compiler macro phases therefore matter: equality here is exact matrix equality, not equality modulo global phase. There is no projective quotient.

The exact primitive alphabet is X, RY, RZ, CX with distinct control/target for CX. Standard RY(θ) is
\[
\begin{pmatrix}\cos(\theta/2)&-\sin(\theta/2)\\
\sin(\theta/2)&\cos(\theta/2)\end{pmatrix}.
\]
The chosen amplitude rotation is RY(2 arccos(c)); for −1≤c≤1 its clean entry is c. A typed ExactAngle contains bounds for rational arccos constructors; addition, negation and rational scaling also occur in the multiplexor compiler. This is exact-real ideal-gate semantics, not a finite-bit implementation.

The fixed benchmark is an 8×8 rational matrix A=M/12, with normalizer α=56/3 and clean block A/α=M/224. The integer matrix M is the literal table in Robin/FixedN3Data.lean: boundary rows (-30,32,-2), (16,-31,16,-1) and reversed right-end counterparts; interior five-point rows have (-1,16,-30,16,-1). Zero entries outside those displayed positions are part of the total finite table. The link to the symbolic Robin derivative evaluates every boundary symbol to zero. Existing teaching describes this as the dimensionless Eq.(9) specialization A1=B1=0, f=1, with the physical Δx⁻² factored out. That is local teaching provenance, not a newly authenticated paper derivation. Reinstating physical scaling would change α accordingly; no implementation is changed here.

Logical LCU indices are nested coefficient × (selector × system). A clean block fixes designated coefficient and selector indices on both sides; additional physical work wires are also fixed where declared. It is not the full unitary and does not assert successful output with probability one. For an input ψ, the accepted component is Aψ/α; any probability statement would additionally specify ψ and its normalization. No amplitude amplification or readout cost theorem is supplied by these modules.

## 2. Exact reversible compilation and the three-bit adder

ModularAdder3.lean defines an X program, then compiles X/CX/CCX reversible gates and lists to primitive programs. Gate correctness uses the actual macro providers; list correctness follows induction and reversal of temporal order in multiplication. It applies at arbitrary ambient qubit count q, but only to this finite gate vocabulary.

The clean C3X construction computes a∧b into a zero work bit, uses that work bit and the third control to flip the target, then uncomputes the first conjunction. The action theorem has precisely the listed inequalities between controls, target and work. It does NOT universally require the first two controls to differ from the third; imposing full five-wire pairwise distinctness would silently strengthen the contract. The action result assumes the work bit is zero. The compiler equality itself describes the full actual reversible permutation even on dirty inputs; the clean C3X interpretation is restricted to the clean locus.

The fixed adder's seven wires are (a0,a1,a2,b0,b1,b2,w). Its eight reversible instructions are the literal list at lines 203–214: five CCX and three CX, with the first three CCX performing the temporary carry computation/use/uncomputation. If w=0, the a register becomes (a+b) mod 8, b is preserved, and w returns to zero. The body of modularAdd3_cleanAction uses finite native_decide with the input reverted; it is a fixed-domain theorem, not arbitrary-width carry induction. No such computation was executed in this recovery. Exact primitive compilation transports the reversible permutation to complex matrix semantics. The two resource facts are definitional resource ownership and zero abstract oracle calls, not a synthesized asymptotic adder bound.

## 3. Uniform seven-state preparation

PaperSevenPrepare.lean constructs a unitary on THREE physical selector qubits, hence eight basis labels. There are seven active labels and a genuine padded eighth label. Its chronological stages are:

1. RY(2 arccos√(4/7)) on selector high bit 2.
2. A controlled RY on middle bit 1, controlled by high bit 2: π/2 if high=0, otherwise 2 arccos√(2/3).
3. A two-control RY on low bit 0: zero if both high/middle bits are 1, otherwise π/2.

The independent stagewise matrix is low × middle × high. The general uniformly-controlled-RY theorem equates each emitted primitive stage to its block diagonal specification, and all primitive matrices are unitary. The high-bit probability is 4/7 versus 3/7. On the first branch, two equal splits give four probabilities 1/7. On the second, the middle split gives 2/7 versus 1/7; the first splits equally and the final low bit is not rotated, giving labels 4,5,6 probability 1/7 and label 7 probability zero. The proof checks the real trigonometric squares and all eight finite labels, not a floating-point simulator.

The exact assertion is \(\overline{P_{s0}}P_{s0}=1/7\) for s<7 and zero for s=7. It avoids needing an arbitrary common phase convention for clean-column amplitudes. Physical dimension is never Fin 7. The optional padded-slot map is some(s) on active labels and none at 7; it is a literal partial-label representation, not a discarded Hilbert sector. The circuit has seven RY and eight CX and zero abstract oracle calls. This stage alone is neither SELECT nor a complete block encoding.

## 4. Eight-wire physical embeddings

PaperSevenAmplitudePrimitive.lean uses system q0–q2, selector q3–q5, coefficient q6, and work q7. The six lower wires control an exact RY on q6 with angle 2 arccos(c(s,j)). The imported coefficient table and its proved bound, not an added hypothesis, supply each angle constructor. The context equivalence includes q7, so the physical amplitude block is proved equal to the logical amplitude lift on ALL eight-wire basis states while q7 is a spectator. Finite bijectivity establishes the specified reindexing. This does not assert that SELECT is identity on a dirty work wire: its imported reversible extension is the actual compiled extension.

PaperSevenPreparePrimitive.lean embeds the three selector stages on physical q5 (high), q4 (middle), q3 (low), preserving system, coefficient and q7. It defines separate stage matrices, proves context equality iff the correct spectators and non-target selector bits agree, identifies each controlled block entry, then composes them to the selector lift of P. Reverse order with gate daggers yields exactly the adjoint lift. All preserved-register facts apply on the full carrier, not only a clean input.

Both files provide stage refinements. Neither is by itself the complete paper-seven final block theorem; its consumer lies outside the ten-target set. The source name is a local route label, not evidence that the unavailable paper's literal gate-level proof was reproduced.

## 5. Nine-wire Figure-4 realization

Figure4PreparePrimitive.lean uses selector q0–q2, system q3–q5, coefficient q6, indicator q7 and reversible work q8. The logical system factor therefore includes system × (indicator × work). Encoding and decoding are explicit finite bijections; no silent tensor reorder is free. The same P is embedded on selector wires 2,1,0 while every other wire is retained. The context iff lemmas, matrix entries, program zero phase, stage products and program dagger prove the exact selector lift and its adjoint.

Figure4T3.lean composes chronological PREPARE → middle → PREPARE†. Its imported middle program includes the transpose-bulk indicator, bulk/boundary coefficient loaders, D-transpose sparse access, register transport, indicator uncomputation and D cleanup; the homogeneous f=1 loader is identity. The actual imported transport and cleanup functions, not merely labels, supply the clean action. Both indicator q7 and work q8 return zero branchwise for every selector/system branch and BOTH coefficient basis values; this supports coherent superposition of q6.

The fixed source-address table is
\[
d_s=[3,2,1,0,7,6,5,4]_s,\quad r_s(j)=(j+d_s)\bmod8.
\]
For each j the physical slots enumerate distinct rows. Slots 0–6 are active and slot 7 has zero PREPARE probability; that padded coefficient may be assigned 1 by the independent paper-seven convention without affecting the clean sum, whereas Figure4SourceCoefficient uses the literal target value M(r_s(j),j)/32 on every slot. Neither definition is silently changed to agree off the active set.

The bulk test is j=3 or j=4, because it applies to a row of D-transpose, i.e. a column of D. Rows 2 through 5 of D form a different periodic agreement region. Columns 2 and 5 have explicit differing boundary entries and cannot be added to the transpose-bulk set. This is a fixed-N interpretation checked by provider formulas, not a new paper-fidelity ruling.

Reindex the physical middle matrix as B. On clean indicator/work states,
\[
B_{(b,s,i,0,0),(a,t,j,0,0)}
=\mathbf1_{s=t}\mathbf1_{r_t(j)=i}\,R(c(t,j))_{ba}.
\]
For the full product P†BP, summing the coefficient and selector indices collapses the slot equality; at coefficient=0, R(c)₀₀=c and the selector amplitudes multiply to \(|P_{s0}|²\). Thus
\[
U_{\mathrm{clean}}(i,j)
=\sum_{s<7}\mathbf1_{r_s(j)=i}\frac17\frac{M_{r_s(j),j}}{32}
=\frac{M_{ij}}{224}=\frac{A_{ij}}{56/3}.
\]
The sparse decomposition supplies the second equality; no general LCU claim is used to erase the slot/basis/cleanup obligations.

The flat full unitary is 512×512. Clean indices explicitly set selector, coefficient, indicator and work to zero and retain the three system bits. Candidate data declares 3 system, 4 signal, 2 pure ancilla qubits, total auxiliary=6. Its isUnitary and blockContainsTarget fields are propositions; the VerifiedOperatorBlockEncoding constructor separately provides their proofs. PrimitiveProgramRefinement binds the exact program matrix including compiler phases. The legacy Circuit presentation keeps names "X" and "exact-angle" but drops angle values; it is presentation data, not the authoritative matrix semantics. Resource is computed from the actual primitive program.

## 6. Symmetry and XOR four-slot route

SymmetryFourSlotPrimitive.lean is only the prerequisite layer. Its two-CX coordinate map controls from sector bit 2 to pair bits 1 and 0. With pair p∈Fin4 and sector e∈Fin2, the original basis label is p for e=0 and 7−p for e=1. The finite image theorem connects that formula to the actual gate permutation. It also constructs exact standard-RY angles for the CYCLIC four-shift coefficient table. This angle interface is distinct from the XOR table. It makes no complete circuit certificate by itself.

SymmetryXorFourSlotPrimitive.lean uses six wires: pair q0,q1; sector q2; selector q3,q4; coefficient q5. There is no separate workspace. In each symmetry sector, the provider sector matrix is M+ or M−; each XOR weight is the matrix entry at row p XOR s, column p. The amplitude is weight/56, and uniform four-slot selector probability is 1/4, giving sector block M±/224. Bounds are proved over the finite tables and used internally to construct all 32 exact amplitude angles; no arbitrary amplitude-table oracle is assumed.

SELECT is exactly CX(q3,q0); CX(q4,q1). It preserves selector, sector and coefficient and changes p to p XOR s on every basis input. Five controls q0–q4 select RY on q5. Explicit context and middle-register equivalences identify the compiled block diagonal with the logical amplitude lift. Selector PREPARE is RY(π/2) on q3 then q4; its adjoint is reverse+dagger. Middle chronology is PREPARE, amplitude, SELECT, unprepare.

The system symmetry basis change S is RY(π/2) on sector q2, with pair identity. Its signs are those of standard RY, not a silently substituted Hadamard. To conjugate back, the pair-circuit chronology is S†, middle, S; matrix product is S·middle·S†. The outer coordinate circuit C is involutive; full chronology is C, pair-circuit, C. The physical original-index equivalence is checked against the six-bit little-endian flattening. These two conjugations and reindexing give exact equality with the imported logical flat unitary, followed by the clean-block theorem A/α. The clean projection fixes q3,q4,q5=0, not sector q2.

The candidate declares 3 system, 3 signal, 0 pure ancilla qubits, auxiliary=3. As in Figure 4, proposition fields and their proof fields are separate, and a refinement equality links the presented primitive circuit to the chosen logical matrix. Dashboard compatibility abbreviations name this XOR route; they do not prove the earlier cyclic SELECT primitive route. The amplitude compiler has 32 RY and 62 CX; resource ownership is definitional and abstract oracle calls are zero. No finite-bit synthesis, hardware routing, approximation, asymptotic optimality or resource comparison theorem is proved in this module.

## 7. Reusable system-conjugation algebra

SystemConjugation.lean is genuinely parametric over arbitrary finite coefficient, selector and system types with the displayed Fintype/DecidableEq instances. It is not fixed-N8. Define L(V)=I⊗(I⊗V), Q₀(U) as the submatrix with specified clean coefficient/selector values, and C(V,U)=L(V)·U·L(V)†. Kronecker deltas collapse the coefficient/selector sums, leaving ordinary system sums:
\[
Q_0(C(V,U))=V\,Q_0(U)\,V^\dagger.
\]
This identity requires NO unitarity hypotheses. Distinct theorems establish L(V) unitary if V is unitary and C(V,U) unitary if BOTH V and U are unitary. Rectangular left/right-entry lemmas preserve their extra finite row/column carriers. No resource or elementary-gate realization of an arbitrary system unitary is inferred from this algebra.

## 8. Exhaustive roles and boundaries

All definitions in these nine modules are literal formulas, circuits, tables, presentation adapters, record constructors, or equivalences of an explicit proved-bijective function. Equiv.ofBijective does not choose an arbitrary quantum representative. No unique-existence/quotient well-definedness repair is needed or introduced. Imported coefficient bounds, gate semantics, selector probabilities, sparse decompositions and block-entry results are construction dependencies, NOT new premises on the final fixed block certificate.

Every explicit binder is retained in the coverage file and formal snapshot: finite indices and matrices form carriers/inputs, distinct-wire and clean-work conditions are exact local operation conditions, and unitary premises in the reusable library theorem remain explicitly conditional. None is advertised as a verified premise of the unavailable original paper. Ambient namespaces, opens, simp attributes and maxRecDepth/maxHeartbeats/transparency options remain frozen. The transparency option controls tactic unification, not a mathematical premise. Native finite proofs, symbolic matrix identities, pure data wrappers and true Prop proof fields remain separately classified. This packet neither runs the proofs nor claims that a Boolean named proved supplies a proof.

Original-paper source proof completeness, reviewer independence, all ten whole-module approval gates, compiler acceptance and post-merge purification remain pending. In particular the exact fixed-N certificates cannot close the arbitrary-width source oracle/compiler/resource theorem, and the symbolic RobinMatrix obligations cannot weaken or strengthen the fixed-N target.

