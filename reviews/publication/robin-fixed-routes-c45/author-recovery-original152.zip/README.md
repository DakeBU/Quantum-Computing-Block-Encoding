# Retrospective local author recovery: fixed Robin routes, c45

State: AUTHOR CHECKPOINT; nine bounded modules have author-level semantic recovery; the large RobinMatrix module has complete mechanical source inventory and selected-mechanism recovery, not a completed whole-module semantic audit.

This is implementation-informed LOCAL source recovery. It is not a pre-proof Statement Seal, a reconstruction of the unavailable original paper proof, source-blind decoding, independent review, compilation, acceptance, novelty, or purification. Historical formalizer: UNKNOWN. Recovery author: robin_fixed_routes_source_author_c45.

## Read order

1. natural-contract.md: shared mathematical contract and complete nine-module mechanism coverage.
2. robin-matrix-checkpoint.md: distinct symbolic-matrix route, actual obstructions, and exact residual scope.
3. coverage-and-binders.json: each declaration/header/body range, fields, ambient commands, definition and binder/source-role audit links.
4. graph-proposals.json: proposed local construction topology and complete AND/OR transports.
5. pins-before.json, pins-after.json, seal.json: raw file bindings and output digests.
6. formal-only/: comment-masked target and complete recursive project-import context; config is pinned separately.
7. inventory/: lossless source region indices for all 47 project modules. Offsets are UTF-16 JavaScript character offsets; intervals are half-open. These are lexical inventories, not elaborated Lean declarations or dependency certificates.

## Disclosure separation

formal-only contains only comment-masked formal source plus toolchain/configuration, with every identifier and String literal retained. Do not hand a decoder author-context, natural-contract, this README, graph proposals, inventories' author classifications, or handoff. formal-allowlist.json identifies the exact decoder-visible files and targets. The titles and file/module identifiers remain because changing identifiers would corrupt the formal evidence.

The raw source bindings include all ten targets, all 37 recursively imported local providers, toolchain, dependency manifest, and Lake configuration. Mathlib itself is externally identified by lake-manifest.json; its entire checkout is NOT copied. No elaboration or toolchain execution occurred.

Existing teaching/excerpt text is reused under author-context with exact source hashes. It contains retrospective source-correction and historical compilation prose. Those passages are not independent paper text or new compilation evidence. The edited source excerpts' final Hamiltonian sections are EXCLUDED from this objective: their consumer is a different module.

No production, registry, Git, network, compiler, or native-decide execution; only this new export directory was written with apply_patch. No children were delegated. No source repair, new hypothesis, fallback adjustment, or renamed literal.

