# RobinMatrix author checkpoint: exact scope, not whole-module review

The whole 26,985-line raw module is pinned and its complete formal body is preserved comment-masked. The lexical inventory identifies 677 declarations (including multiline theorem names), 69 structures, 1,950 field starts, 69 names ending _transcript, and 236 regions containing native_decide. These are deterministic syntax counts, not compiler output, theorem dependencies, semantic approval, or a claim that all proofs are repetitive. Every byte region has a lossless drill-down; the remaining semantic audit is NOT complete.

## Semantically recovered prefix and selected mechanisms

The prefix through the first proof-route constructor (lines 1–580), the full gamma3AkCoefficientEntryContract region (3982–4220), and selected actual bridge/obstruction bodies listed below were inspected as mathematical code. Most remaining regions were classified mechanically by declaration/header/body features and mechanism grouping, not individually semantically checked. The inventory must not be presented as a human understanding of every proof.

1. stencilRowCoeff adds all matching stencil coefficients, but returns the bare coefficient when exactly one matches. Empty lists give rational zero. robinRowEntries selects left rows first when i<w.lower, then right rows when i>w.upper, otherwise bulk. Missing boundary rows return the empty list. This total-carrier fallback is PRESENT in the old definition; no source legitimacy is certified and no repair was made. buildRobinMatrix applies it to finite row/column labels. The symbolic derivative uses the literal fourth-order bulk and four boundary lists in Examples/RobinHeat. oneTermRobinAkMatrix scales ROW i by the free symbol f_i; it is not the column-scaled transpose.

2. Coeff is a free rational/symbol/add/mul/neg expression tree; env:String→Rat interprets it. Syntactic associativity is false in general even when evaluated rational associativity is true. A named inverse or cosine is just another independent symbol unless an explicit environment hypothesis imposes its meaning. matrixOneNorm is the maximum ABSOLUTE ROW SUM of the evaluated matrix. Despite its name and comments calling this an induced 1-norm, the literal formula is the conventional infinity norm, not the conventional maximum-column-sum 1-norm. No renaming or downstream norm proof is supplied.

3. Numeric normalization multiplies nD·nF·κ. Its equality with the named symbolic normalizer uses a specified environment. Bool comparisons do not certify bounds for arbitrary environments. robinBlockEncodingPredicate checks a normalizer comparison at the zero environment, pure-ancilla count and error field, but contains NO full projected-matrix equation. Resource rows and cost inequalities are data-level formulas unless separately linked to physical circuits.

4. CircuitMatrixSemantics supplies a gate list, matched matrices and their ordered finite product. Here the active backend has seven gates: indicator, O_DT^S, boundary RY, sparse access, O_f, SWAP, dagger sparse access. Its stored unitary flags are [true,false,false,false,false,true,false]. Bool proved=true is NOT a complex-unitarity theorem. Signal projection uses all non-system wires, not only the theorem-facing signal count. oneTermRobinBlockExtractionTarget selects that raw product's zero-signal submatrix and targets the row-scaled A_k. The derivative-only BlockEncodingSpec and row-scaled block target are separate objects.

5. The finite composition contract and OneTermRobinBlockEncodingProofRoute carry exact targets, source strings, data equalities and false obligation fields. The proof-route constructor provides field equalities, not the advertised block-encoding equality. Conditional theorems that accept external source/flag or local clean-entry hypotheses only assemble a ledger under those hypotheses. A field asserting that an obligation is false does not prove that a corresponding mathematical theorem is impossible.

6. The active sparse cleanup provider uses a global slot and a restricted source domain. In the relevant family, n≥3, κ=7 and sparse-width=3 accompany padded-clean input with slot<7. Restricted inverse-image uniqueness and restricted transpose-column support are not a full unitary extension or all-zero output projection. The old row-dependent collision model and encoded eighth slot guards remain distinct. The existing retrospective GHL lesson supplied useful context for this distinction; it was not treated as independent review of this module.

7. At n=3, support lemmas isolate paths in an explicit seven-gate matrix. The selected branch is sparse slot 2 at full basis index 32, whereas the raw active zero-signal entry is index 0. Actual bodies show the six nonselected backend contributions vanish after rational evaluation, leaving slot 2. This is finite symbolic support analysis, not a general-width oracle theorem.

8. An arbitrary preparation matrix H:Matrix 8 8 Coeff enters the prepared route. Its uniform-column predicate is exactly
\[
\forall s\in\mathrm{Fin}\,7,\quad H_{\operatorname{slotIndex}(s),\operatorname{cleanIndex}}
=\text{symbol}(\text{"sqrt_kappa_inv"}).
\]
A sandwich contribution is the branch-diagonal seven-gate entry times this ket amplitude times the TRANSPOSE-style bra amplitude. This is Coeff algebra, not an implicit complex adjoint. Under the explicit predicate both amplitudes become the same free symbol. The prepared singleton/finite-sum route then reaches the backend fold. It does NOT prove that the original H-free active entry equals the prepared entry.

9. Corrected boundary-entry evaluation is conditional on env("boundary_cos_half_0_2") equalling the interpreted normalized coefficient. Genuine inverse semantics additionally requires env("N_D_inv")·env("N_D")=1 and the analogous N_f equation; κ-projection uses additional amplitude-factor semantics. These remain explicit local inputs to conditional bridges, not assumptions newly licensed for an original-paper final theorem.

10. The actual all-one branch environment assigns f_3_0, N_f_inv, boundary_cos_half_0_2 and sqrt_kappa_inv value 1, and all other symbols 0. The selected contribution evaluates to 1, while the active [0,0] product evaluates to 0 for every env. Thus the evaluated backend-fold equality is equivalent to selected contribution=0; the universal raw backend expansion and raw projection-summation statement are negated in the source. This is a refutation of THAT symbolic H-free target, not a proof that the PDE block encoding or prepared fixed-N circuit is impossible.

11. Near the end, active/prepared evaluation hypotheses imply the same selected contribution must vanish, and downstream product/LCU/projection/block/extraction flags stay false. Thus conditional feeders cannot be promoted by their names or by transcript strings saying "compiled". The final gate-matrix-list theorem is an actual syntactic list equality, not equality of differently parenthesized raw Coeff matrix products.

## Exact inspected bridge anchors

Full declarations and headers/bodies, not only names, are available at these inventory extents:

- oneTermRobinGamma3BoundarySymbolicInverseEval_n3: 9650–9713.
- oneTermRobinGamma3BoundaryBackendBranchFoldEval_eq_selectedSlotContribution_n3: 17790–17840.
- PreparedProjectionSandwichContribution, Sum, and the three subsequent conditional bridge theorems: 19603–19718.
- SourcePreparedProjectionTarget transcript, preparedBackendEval, feedsProductRoute, preparedProjectionEntryEval_eq_backend and the two named wrapper leaves: 22320–22555.
- EvaluatedBackendFoldStatement and equivalent cast/uncast active-entry forms: 22963–23202.
- SelectedSlotContribution_allOne_nonzero_n3: 23203–23253.
- BackendExpansionStatement_not_n3 and BackendProjectionSummationStatement_not_n3: 23644–23710.
- SourcePreparedActiveEval_forces_selectedSlotContribution_zero_n3 through final GateMatrixList_n3: 26875–26982.

Ranges here are navigation aids; inventory half-open offsets define the exact partition. Endpoint comment/whitespace overlap in displayed line labels is not an extra declaration.

## Complete mechanism grouping for later review

| Source lines | Mechanism family | Present recovery level |
|---|---|---|
| 1–580 | stencil, norm/resource metadata, semantics, block target, route records | semantic prefix |
| 581–3421 | route ledger wrappers; external-source/clean-entry conditional maps; active-domain cleanup bookkeeping | inventory + headers, not complete body audit |
| 3422–4416 | gamma3 signal-entry/product-to-coefficient obligations and factor ledger | selected full contract; remaining bodies pending |
| 4417–6577 | fixed-N path/slot/projection/indicator convention records | inventory; full semantic audit pending |
| 6578–8566 | support and actual prefix/suffix/seven-gate entry calculations, including zero-column guard | selected consumers inspected; every support proof still pending |
| 8567–13923 | corrected-angle, inverse-symbol, κ-projection, bra/transpose, clean-column factor bridges | selected inverse body; rest exact inventory/pending |
| 13924–16034 | projection branch decomposition, branch-family/gap records and indexing | inventory/pending |
| 16035–18307 | per-slot support/vanishing computations and all-slot fold | fold mechanism inspected, individual supports pending |
| 18308–20686 | fold/expansion targets; prepared sandwich, singleton circuit semantics/gaps | selected sandwich mechanism; rest pending |
| 20687–22962 | cast/uncast active-vs-prepared interfaces and theorem-facing target wrappers | selected target/bridge bodies; rest pending |
| 22963–24937 | evaluated raw-fold obstruction/equivalence, counterexample and target wrapper | selected obstruction bodies, other wrappers pending |
| 24938–26985 | normalized projection/finite-block contract audit, conditional feeders, final no-go and gate-list equality | selected final bodies; complete audit pending |

No omitted region is labelled mathematically verified. "Inventory/pending" includes all private helpers, record fields/defaults and ambient commands in those regions.

## What remains before a whole-module review packet can be called complete

An author/reader must still check every remaining listed body against its exact binders, expand each project contract/structure field actually used by conditional conclusions, and disposition every substantive source region. In particular, distinguish closure of a finite support calculation from closure of the block target; data-level source strings from theorem dependencies; corrected-angle evaluation from actual original-paper fidelity; full versus restricted cleanup; explicit matrix conditions from internally constructed oracle facts; and the H-free active backend from prepared singleton circuit semantics.

The complete 47-module freeze is retained for this continuation. The bounded-nine projection includes the small RobinMatrix provider extents needed for the nine fixed-route modules and conservative simp-context additions. That does not waive RobinMatrix's own whole-module gate.

This checkpoint retires no new mathematics and supplies no new Lean proof. The source's refutation is recovered as a local distinction; it is not newly compiled here. Failure class for this author work: NONE (scope remains intentionally incomplete, not an environment or mathematical failure). Purification, Exposition Seal, Proof Seal, independent decoder/reviewer and original-paper source topology are all PENDING.

