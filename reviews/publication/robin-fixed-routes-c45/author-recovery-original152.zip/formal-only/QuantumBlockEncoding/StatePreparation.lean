import QuantumBlockEncoding.BlockEncoding

   
                                

                                                                        
                                                                     
                                                                             
                                                                    
  

namespace QuantumBlockEncoding

                                                                       
def zeroBasisIndex (n : Nat) : Fin (gridSize n) :=
  ⟨0, Nat.pow_pos (by decide)⟩

                                                
structure StatePreparationTarget (α : Type u) (qubits : Nat) where
  amplitudes : Fin (gridSize qubits) → α
  normalization : Prop
  source : String := ""

                                                          
def FirstColumnMatches {α : Type u} {qubits : Nat}
    (unitary : Matrix (gridSize qubits) (gridSize qubits) α)
    (target : StatePreparationTarget α qubits) : Prop :=
  ∀ row, unitary row (zeroBasisIndex qubits) = target.amplitudes row

                                                                         
structure StatePreparationCandidate (α : Type u) (qubits : Nat) where
  target : StatePreparationTarget α qubits
  unitary : Matrix (gridSize qubits) (gridSize qubits) α
  circuit : Circuit
  schedule : LayeredCircuit := []
  resource : Resource
  auxiliaryQubits : Nat := 0
  isUnitary : Prop

namespace StatePreparationCandidate

                                                                                  
def preparesTarget (candidate : StatePreparationCandidate α qubits) : Prop :=
  FirstColumnMatches candidate.unitary candidate.target

                                                                                
def cost (candidate : StatePreparationCandidate α qubits) : BlockEncodingCost :=
  {
    auxiliaryQubits := candidate.auxiliaryQubits
    gateCount := candidate.resource.gates
    depth := candidate.resource.depth
    oracleCalls := candidate.resource.oracleCalls
  }

end StatePreparationCandidate

                                                                                    
structure VerifiedStatePreparation (α : Type u) (qubits : Nat) where
  candidate : StatePreparationCandidate α qubits
  normalizationProof : candidate.target.normalization
  unitaryProof : candidate.isUnitary
  preparationProof : candidate.preparesTarget

                                                                              
structure ApproximateStatePreparationCandidate
    (α : Type u) (qubits : Nat) where
  candidate : StatePreparationCandidate α qubits
  epsilon : α
  approximationBound : Prop

                                                            
structure VerifiedApproximateStatePreparation
    (α : Type u) (qubits : Nat) where
  approxCandidate : ApproximateStatePreparationCandidate α qubits
  normalizationProof : approxCandidate.candidate.target.normalization
  unitaryProof : approxCandidate.candidate.isUnitary
  approximationProof : approxCandidate.approximationBound

namespace VerifiedStatePreparation

   
                                                                          
                                                                         
                       
  
def asZeroErrorApprox [OfNat α 0]
    (verified : VerifiedStatePreparation α qubits) :
    VerifiedApproximateStatePreparation α qubits where
  approxCandidate := {
    candidate := verified.candidate
    epsilon := 0
    approximationBound := verified.candidate.preparesTarget
  }
  normalizationProof := verified.normalizationProof
  unitaryProof := verified.unitaryProof
  approximationProof := verified.preparationProof

theorem firstColumn
    (verified : VerifiedStatePreparation α qubits) :
    verified.candidate.preparesTarget :=
  verified.preparationProof

end VerifiedStatePreparation

end QuantumBlockEncoding
