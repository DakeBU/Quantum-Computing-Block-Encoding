import QuantumBlockEncoding.PrimitiveSemantics

   
                                          

                                                                       
                                                                          
                                                                      
  

namespace QuantumBlockEncoding

                                                                           
                                                                                
structure PrimitiveProgramRefinement (qubits : Nat) where
  program : PrimitiveProgram qubits
  target : _root_.Matrix (PrimitiveBasis qubits) (PrimitiveBasis qubits) ℂ
  exact : evalPrimitiveProgram program = target

def PrimitiveProgramRefinement.resource {qubits : Nat}
    (refinement : PrimitiveProgramRefinement qubits) : Resource :=
  refinement.program.resource

theorem PrimitiveProgramRefinement.oracleCalls_eq_zero {qubits : Nat}
    (refinement : PrimitiveProgramRefinement qubits) :
    refinement.resource.oracleCalls = 0 := by
  exact PrimitiveCircuit.resource_oracleCalls_eq_zero refinement.program.circuit

def PrimitiveRefinement.resource {qubits : Nat}
    (refinement : PrimitiveRefinement qubits) : Resource :=
  refinement.circuit.resource

theorem PrimitiveRefinement.oracleCalls_eq_zero {qubits : Nat}
    (refinement : PrimitiveRefinement qubits) :
    refinement.resource.oracleCalls = 0 := by
  exact PrimitiveCircuit.resource_oracleCalls_eq_zero refinement.circuit

end QuantumBlockEncoding
