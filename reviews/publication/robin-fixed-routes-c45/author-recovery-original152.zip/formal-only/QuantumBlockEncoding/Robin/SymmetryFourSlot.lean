import QuantumBlockEncoding.Robin.FixedN3Data
import Mathlib.Tactic

   
                                               

                                                                            
                                                                          
                                                                               
                                                                           
                                                                              
  

namespace QuantumBlockEncoding.Robin

                                                
def warmRobinReverse8 (index : Fin 8) : Fin 8 :=
  ⟨7 - index.val, by omega⟩

@[simp] theorem warmRobinReverse8_value (index : Fin 8) :
    (warmRobinReverse8 index).val = 7 - index.val := by
  rfl

@[simp] theorem warmRobinReverse8_involution (index : Fin 8) :
    warmRobinReverse8 (warmRobinReverse8 index) = index := by
  fin_cases index <;> decide

                                                                               
theorem warmRobinIntegerTarget_centrosymmetric (row column : Fin 8) :
    warmRobinIntegerTarget row column =
      warmRobinIntegerTarget (warmRobinReverse8 row)
        (warmRobinReverse8 column) := by
  fin_cases row <;> fin_cases column <;> native_decide

                                                       
def warmRobinPairLow (index : Fin 4) : Fin 8 :=
  ⟨index.val, by omega⟩

                                                         
def warmRobinPairHigh (index : Fin 4) : Fin 8 :=
  warmRobinReverse8 (warmRobinPairLow index)

                                                       
def warmRobinSymmetryPlusBlock : Matrix 4 4 Int := fun row column =>
  warmRobinIntegerTarget (warmRobinPairLow row) (warmRobinPairLow column) +
    warmRobinIntegerTarget (warmRobinPairLow row) (warmRobinPairHigh column)

                                                           
def warmRobinSymmetryMinusBlock : Matrix 4 4 Int := fun row column =>
  warmRobinIntegerTarget (warmRobinPairLow row) (warmRobinPairLow column) -
    warmRobinIntegerTarget (warmRobinPairLow row) (warmRobinPairHigh column)

                                                                  
def warmRobinSymmetryFourShiftPerm (slot column : Fin 4) : Fin 4 :=
  ⟨(column.val + slot.val) % 4, Nat.mod_lt _ (by decide)⟩

theorem warmRobinSymmetryFourShiftPerm_bijective (slot : Fin 4) :
    Function.Bijective (warmRobinSymmetryFourShiftPerm slot) := by
  fin_cases slot <;> decide

                                                
def warmRobinSymmetryPlusWeight (slot column : Fin 4) : Int :=
  match slot.val, column.val with
  | 0, 0 => -30 | 0, 1 => -31 | 0, 2 => -30 | 0, _ => -14
  | 1, 0 => 16 | 1, 1 => 16 | 1, 2 => 15 | 1, _ => 0
  | 2, 0 => -1 | 2, 1 => -1 | 2, 2 => -2 | 2, _ => -1
  | _, 0 => 0 | _, 1 => 32 | _, 2 => 16 | _, _ => 15

                                                    
def warmRobinSymmetryMinusWeight (slot column : Fin 4) : Int :=
  match slot.val, column.val with
  | 0, 0 => -30 | 0, 1 => -31 | 0, 2 => -30 | 0, _ => -46
  | 1, 0 => 16 | 1, 1 => 16 | 1, 2 => 17 | 1, _ => 0
  | 2, 0 => -1 | 2, 1 => -1 | 2, 2 => -2 | 2, _ => -1
  | _, 0 => 0 | _, 1 => 32 | _, 2 => 16 | _, _ => 17

                                                              
theorem warmRobinSymmetryPlusFourShiftDecomposition (row column : Fin 4) :
    warmRobinSymmetryPlusBlock row column =
      ∑ slot : Fin 4,
        if warmRobinSymmetryFourShiftPerm slot column = row then
          warmRobinSymmetryPlusWeight slot column
        else 0 := by
  fin_cases row <;> fin_cases column <;> native_decide

                                                                  
theorem warmRobinSymmetryMinusFourShiftDecomposition (row column : Fin 4) :
    warmRobinSymmetryMinusBlock row column =
      ∑ slot : Fin 4,
        if warmRobinSymmetryFourShiftPerm slot column = row then
          warmRobinSymmetryMinusWeight slot column
        else 0 := by
  fin_cases row <;> fin_cases column <;> native_decide

                                                                                     
def warmRobinSymmetryFourShiftWeight
    (sector : Fin 2) (slot column : Fin 4) : Int :=
  if sector.val = 0 then
    warmRobinSymmetryPlusWeight slot column
  else
    warmRobinSymmetryMinusWeight slot column

                                                                
def warmRobinSymmetryFourShiftAmplitude
    (sector : Fin 2) (slot column : Fin 4) : Rat :=
  warmRobinSymmetryFourShiftWeight sector slot column / 56

                                                           
theorem warmRobinSymmetryFourShiftAmplitude_bounded
    (sector : Fin 2) (slot column : Fin 4) :
    |warmRobinSymmetryFourShiftAmplitude sector slot column| ≤
      (23 / 28 : Rat) := by
  fin_cases sector <;> fin_cases slot <;> fin_cases column <;> native_decide

                                                       
def warmRobinSymmetryFourShiftCleanFormula
    (sector : Fin 2) : Matrix 4 4 Rat := fun row column =>
  (1 / 4 : Rat) * ∑ slot : Fin 4,
    if warmRobinSymmetryFourShiftPerm slot column = row then
      warmRobinSymmetryFourShiftAmplitude sector slot column
    else 0

                                                                
theorem warmRobinSymmetryPlusFourShiftCleanFormula_eq
    (row column : Fin 4) :
    warmRobinSymmetryFourShiftCleanFormula 0 row column =
      (warmRobinSymmetryPlusBlock row column : Rat) / 224 := by
  fin_cases row <;> fin_cases column <;> native_decide

                                                                    
theorem warmRobinSymmetryMinusFourShiftCleanFormula_eq
    (row column : Fin 4) :
    warmRobinSymmetryFourShiftCleanFormula 1 row column =
      (warmRobinSymmetryMinusBlock row column : Rat) / 224 := by
  fin_cases row <;> fin_cases column <;> native_decide

                                                                    
theorem warmRobinSymmetryBlocks_columnOne_fullSupport :
    (∀ row : Fin 4, warmRobinSymmetryPlusBlock row 1 ≠ 0) ∧
      (∀ row : Fin 4, warmRobinSymmetryMinusBlock row 1 ≠ 0) := by
  constructor <;> intro row <;> fin_cases row <;> native_decide

end QuantumBlockEncoding.Robin
