import QuantumBlockEncoding.ConcreteSemantics
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Data.Matrix.Block
import Mathlib.LinearAlgebra.Matrix.Kronecker
import Mathlib.LinearAlgebra.Matrix.Reindex
import Mathlib.Tactic

   
                                        

                                                                             
                                                                           
                                                                         
                                           
                                                      
  

namespace QuantumBlockEncoding.Robin.ComplexLCU

open scoped Kronecker

                                                                                     
noncomputable def realOrthogonalRotation (cosine sine : Real) :
    _root_.Matrix (Fin 2) (Fin 2) ℂ := fun row column =>
  match row.val, column.val with
  | 0, 0 => (cosine : ℂ)
  | 0, _ => -(sine : ℂ)
  | _, 0 => (sine : ℂ)
  | _, _ => (cosine : ℂ)

                                                                                         
theorem realOrthogonalRotation_unitary
    (cosine sine : Real) (normalization : cosine * cosine + sine * sine = 1) :
    realOrthogonalRotation cosine sine ∈
      _root_.Matrix.unitaryGroup (Fin 2) ℂ := by
  rw [_root_.Matrix.mem_unitaryGroup_iff']
  ext row column
  fin_cases row <;> fin_cases column
  · have hcast : (((cosine * cosine + sine * sine : Real) : ℂ)) = 1 := by
      exact_mod_cast normalization
    simpa [realOrthogonalRotation, _root_.Matrix.mul_apply,
      Fin.sum_univ_two] using hcast
  · simp [realOrthogonalRotation, _root_.Matrix.mul_apply,
      Fin.sum_univ_two]
    ring
  · simp [realOrthogonalRotation, _root_.Matrix.mul_apply,
      Fin.sum_univ_two]
    ring
  · have normalization' : sine * sine + cosine * cosine = 1 := by
      calc
        sine * sine + cosine * cosine =
            cosine * cosine + sine * sine := by ring
        _ = 1 := normalization
    have hcast : (((sine * sine + cosine * cosine : Real) : ℂ)) = 1 := by
      exact_mod_cast normalization'
    simpa [realOrthogonalRotation, _root_.Matrix.mul_apply,
      Fin.sum_univ_two] using hcast

                                                         
noncomputable def realRotation (angle : Real) :
    _root_.Matrix (Fin 2) (Fin 2) ℂ :=
  realOrthogonalRotation (Real.cos angle) (Real.sin angle)

@[simp] theorem realRotation_zero_zero (angle : Real) :
    realRotation angle 0 0 = (Real.cos angle : ℂ) := by
  rfl

@[simp] theorem realRotation_zero_one (angle : Real) :
    realRotation angle 0 1 = -(Real.sin angle : ℂ) := by
  rfl

@[simp] theorem realRotation_one_zero (angle : Real) :
    realRotation angle 1 0 = (Real.sin angle : ℂ) := by
  rfl

@[simp] theorem realRotation_one_one (angle : Real) :
    realRotation angle 1 1 = (Real.cos angle : ℂ) := by
  rfl

                                                      
theorem realRotation_unitary (angle : Real) :
    realRotation angle ∈
      _root_.Matrix.unitaryGroup (Fin 2) ℂ := by
  apply realOrthogonalRotation_unitary
  nlinarith [Real.sin_sq_add_cos_sq angle]

                                                                      
noncomputable def amplitudeRotation (coefficient : Real) :
    _root_.Matrix (Fin 2) (Fin 2) ℂ :=
  realRotation (Real.arccos coefficient)

                                                                       
theorem amplitudeRotation_unitary (coefficient : Real) :
    amplitudeRotation coefficient ∈
      _root_.Matrix.unitaryGroup (Fin 2) ℂ :=
  realRotation_unitary _

                                                                                    
theorem amplitudeRotation_cleanEntry
    (coefficient : Real) (lower : -1 ≤ coefficient) (upper : coefficient ≤ 1) :
    amplitudeRotation coefficient 0 0 = (coefficient : ℂ) := by
  simp [amplitudeRotation, Real.cos_arccos lower upper]

                                                                               
theorem reindex_unitary
    {ι κ : Type*} [Fintype ι] [DecidableEq ι]
    [Fintype κ] [DecidableEq κ]
    (equiv : ι ≃ κ) (operator : _root_.Matrix ι ι ℂ)
    (unitary : operator ∈ _root_.Matrix.unitaryGroup ι ℂ) :
    _root_.Matrix.reindexAlgEquiv ℂ ℂ equiv operator ∈
      _root_.Matrix.unitaryGroup κ ℂ := by
  rw [_root_.Matrix.mem_unitaryGroup_iff'] at unitary ⊢
  have star_reindex :
      star (_root_.Matrix.reindexAlgEquiv ℂ ℂ equiv operator) =
        _root_.Matrix.reindexAlgEquiv ℂ ℂ equiv (star operator) := by
    ext row column
    rfl
  rw [star_reindex, ← _root_.Matrix.reindexAlgEquiv_mul, unitary]
  simp

                                                                                 
theorem blockDiagonal_unitary
    {ι κ : Type*} [Fintype ι] [DecidableEq ι]
    [Fintype κ] [DecidableEq κ]
    (blocks : κ → _root_.Matrix ι ι ℂ)
    (unitary : ∀ k, blocks k ∈ _root_.Matrix.unitaryGroup ι ℂ) :
    _root_.Matrix.blockDiagonal blocks ∈
      _root_.Matrix.unitaryGroup (ι × κ) ℂ := by
  rw [_root_.Matrix.mem_unitaryGroup_iff']
  have star_blockDiagonal :
      star (_root_.Matrix.blockDiagonal blocks) =
        _root_.Matrix.blockDiagonal (fun k => star (blocks k)) := by
    ext ⟨row, blockRow⟩ ⟨column, blockColumn⟩
    by_cases h : blockRow = blockColumn
    · subst blockColumn
      simp [_root_.Matrix.blockDiagonal_apply]
    · have h' : blockColumn ≠ blockRow := Ne.symm h
      simp [_root_.Matrix.blockDiagonal_apply, h, h']
  rw [star_blockDiagonal, ← _root_.Matrix.blockDiagonal_mul]
  have pointwise :
      (fun k => star (blocks k) * blocks k) =
        (1 : κ → _root_.Matrix ι ι ℂ) := by
    funext k
    exact _root_.Matrix.mem_unitaryGroup_iff'.mp (unitary k)
  rw [pointwise, _root_.Matrix.blockDiagonal_one]

                                            
def equivPermutationMatrix
    {ι : Type*} [DecidableEq ι] (equiv : ι ≃ ι) :
    _root_.Matrix ι ι ℂ := fun row column =>
  if row = equiv column then 1 else 0

                                                              
theorem equivPermutationMatrix_unitary
    {ι : Type*} [Fintype ι] [DecidableEq ι] (equiv : ι ≃ ι) :
    equivPermutationMatrix equiv ∈
      _root_.Matrix.unitaryGroup ι ℂ := by
  rw [_root_.Matrix.mem_unitaryGroup_iff']
  ext row column
  by_cases equal : row = column
  · subst column
    simp [equivPermutationMatrix, _root_.Matrix.mul_apply]
  · have reverse_ne : column ≠ row := Ne.symm equal
    simp [equivPermutationMatrix, _root_.Matrix.mul_apply, equal, reverse_ne]

                                                                                      
theorem equivPermutationMatrix_mul_apply
    {ι κ : Type*} [Fintype ι] [DecidableEq ι]
    (equiv : ι ≃ ι) (operator : _root_.Matrix ι κ ℂ)
    (row : ι) (column : κ) :
    (equivPermutationMatrix equiv * operator) row column =
      operator (equiv.symm row) column := by
  classical
  rw [_root_.Matrix.mul_apply]
  rw [Finset.sum_eq_single (equiv.symm row)]
  · simp [equivPermutationMatrix]
  · intro candidate _ candidate_ne
    have miss : row ≠ equiv candidate := by
      intro hit
      apply candidate_ne
      apply equiv.injective
      calc
        equiv candidate = row := hit.symm
        _ = equiv (equiv.symm row) :=
          (equiv.apply_symm_apply row).symm
    simp [equivPermutationMatrix, miss]
  · simp

                                                                   
                          
theorem mul_equivPermutationMatrix_apply
    {ι κ : Type*} [Fintype κ] [DecidableEq κ]
    (operator : _root_.Matrix ι κ ℂ) (equiv : κ ≃ κ)
    (row : ι) (column : κ) :
    (operator * equivPermutationMatrix equiv) row column =
      operator row (equiv column) := by
  classical
  rw [_root_.Matrix.mul_apply]
  rw [Finset.sum_eq_single (equiv column)]
  · simp [equivPermutationMatrix]
  · intro candidate _ candidate_ne
    simp [equivPermutationMatrix, candidate_ne]
  · simp

                                                              
theorem equivPermutationMatrix_mul
    {ι : Type*} [Fintype ι] [DecidableEq ι]
    (first second : ι ≃ ι) :
    equivPermutationMatrix second * equivPermutationMatrix first =
      equivPermutationMatrix (first.trans second) := by
  ext row column
  rw [equivPermutationMatrix_mul_apply]
  simp only [equivPermutationMatrix, Equiv.trans_apply]
  by_cases hit : second.symm row = first column
  · have forward : row = second (first column) := by
      rw [← hit]
      exact (second.apply_symm_apply row).symm
    simp [hit, forward]
  · have miss : row ≠ second (first column) := by
      intro forward
      apply hit
      rw [forward, second.symm_apply_apply]
    simp [hit, miss]

                                                                          
                                                                        
theorem equivPermutationMatrix_conjugates_reindex
    {ι κ : Type*} [Fintype ι] [DecidableEq ι]
    [Fintype κ] [DecidableEq κ]
    (basis : ι ≃ ι) (logical : ι ≃ κ)
    (operator : _root_.Matrix κ κ ℂ)
    (involutive : Function.Involutive basis) :
    equivPermutationMatrix basis *
          _root_.Matrix.reindexAlgEquiv ℂ ℂ logical.symm operator *
        equivPermutationMatrix basis =
      _root_.Matrix.reindexAlgEquiv ℂ ℂ
        (basis.trans logical).symm operator := by
  ext row column
  rw [mul_equivPermutationMatrix_apply,
    equivPermutationMatrix_mul_apply]
  have basisSymm (index : ι) : basis.symm index = basis index := by
    apply basis.injective
    rw [basis.apply_symm_apply, involutive index]
  simp only [_root_.Matrix.reindexAlgEquiv_apply,
    _root_.Matrix.reindex_apply, _root_.Matrix.submatrix_apply,
    Equiv.symm_symm, Equiv.trans_apply]
  rw [basisSymm]

                                                                              
abbrev LCUIndex (coefficient selector system : Type*) :=
  coefficient × (selector × system)

                                                                
def selectorLift
    {coefficient selector system : Type*}
    [Fintype coefficient] [DecidableEq coefficient]
    [Fintype selector] [DecidableEq selector]
    [Fintype system] [DecidableEq system]
    (prepare : _root_.Matrix selector selector ℂ) :
    _root_.Matrix
      (LCUIndex coefficient selector system)
      (LCUIndex coefficient selector system) ℂ :=
  (1 : _root_.Matrix coefficient coefficient ℂ) ⊗ₖ
    (prepare ⊗ₖ (1 : _root_.Matrix system system ℂ))

                                                                                  
theorem selectorLift_unitary
    {coefficient selector system : Type*}
    [Fintype coefficient] [DecidableEq coefficient]
    [Fintype selector] [DecidableEq selector]
    [Fintype system] [DecidableEq system]
    (prepare : _root_.Matrix selector selector ℂ)
    (unitary : prepare ∈ _root_.Matrix.unitaryGroup selector ℂ) :
    selectorLift (coefficient := coefficient) (system := system) prepare ∈
      _root_.Matrix.unitaryGroup
        (LCUIndex coefficient selector system) ℂ := by
  apply _root_.Matrix.kronecker_mem_unitary
  · exact (_root_.Matrix.unitaryGroup coefficient ℂ).one_mem
  · apply _root_.Matrix.kronecker_mem_unitary
    · exact unitary
    · exact (_root_.Matrix.unitaryGroup system ℂ).one_mem

                                                                           
def amplitudeLift
    {coefficient selector system : Type*}
    [Fintype coefficient] [DecidableEq coefficient]
    [Fintype selector] [DecidableEq selector]
    [Fintype system] [DecidableEq system]
    (rotation : selector → system →
      _root_.Matrix coefficient coefficient ℂ) :
    _root_.Matrix
      (LCUIndex coefficient selector system)
      (LCUIndex coefficient selector system) ℂ :=
  _root_.Matrix.blockDiagonal (fun context => rotation context.1 context.2)

                                                                  
theorem amplitudeLift_unitary
    {coefficient selector system : Type*}
    [Fintype coefficient] [DecidableEq coefficient]
    [Fintype selector] [DecidableEq selector]
    [Fintype system] [DecidableEq system]
    (rotation : selector → system →
      _root_.Matrix coefficient coefficient ℂ)
    (unitary : ∀ selector system,
      rotation selector system ∈
        _root_.Matrix.unitaryGroup coefficient ℂ) :
    amplitudeLift rotation ∈
      _root_.Matrix.unitaryGroup
        (LCUIndex coefficient selector system) ℂ := by
  apply blockDiagonal_unitary
  intro context
  exact unitary context.1 context.2

                                                                                       
def controlledSystemEquiv
    {coefficient selector system : Type*}
    (permutation : selector → system ≃ system) :
    LCUIndex coefficient selector system ≃
      LCUIndex coefficient selector system where
  toFun index :=
    (index.1, (index.2.1, permutation index.2.1 index.2.2))
  invFun index :=
    (index.1, (index.2.1, (permutation index.2.1).symm index.2.2))
  left_inv index := by
    simp
  right_inv index := by
    simp

                                                                 
def selectLift
    {coefficient selector system : Type*}
    [DecidableEq coefficient] [DecidableEq selector] [DecidableEq system]
    (permutation : selector → system ≃ system) :
    _root_.Matrix
      (LCUIndex coefficient selector system)
      (LCUIndex coefficient selector system) ℂ :=
  equivPermutationMatrix (controlledSystemEquiv permutation)

                                                           
theorem selectLift_unitary
    {coefficient selector system : Type*}
    [Fintype coefficient] [DecidableEq coefficient]
    [Fintype selector] [DecidableEq selector]
    [Fintype system] [DecidableEq system]
    (permutation : selector → system ≃ system) :
    selectLift (coefficient := coefficient) permutation ∈
      _root_.Matrix.unitaryGroup
        (LCUIndex coefficient selector system) ℂ :=
  equivPermutationMatrix_unitary _

                                                               
noncomputable def prepareAmplitudeSelectUnprepare
    {coefficient selector system : Type*}
    [Fintype coefficient] [DecidableEq coefficient]
    [Fintype selector] [DecidableEq selector]
    [Fintype system] [DecidableEq system]
    (prepare : _root_.Matrix selector selector ℂ)
    (rotation : selector → system →
      _root_.Matrix coefficient coefficient ℂ)
    (permutation : selector → system ≃ system) :
    _root_.Matrix
      (LCUIndex coefficient selector system)
      (LCUIndex coefficient selector system) ℂ :=
  star (selectorLift (coefficient := coefficient) (system := system) prepare) *
    (selectLift (coefficient := coefficient) permutation *
      (amplitudeLift rotation *
        selectorLift (coefficient := coefficient) (system := system) prepare))

                                                                                   
theorem prepareAmplitudeSelectUnprepare_unitary
    {coefficient selector system : Type*}
    [Fintype coefficient] [DecidableEq coefficient]
    [Fintype selector] [DecidableEq selector]
    [Fintype system] [DecidableEq system]
    (prepare : _root_.Matrix selector selector ℂ)
    (rotation : selector → system →
      _root_.Matrix coefficient coefficient ℂ)
    (permutation : selector → system ≃ system)
    (prepareUnitary :
      prepare ∈ _root_.Matrix.unitaryGroup selector ℂ)
    (rotationUnitary : ∀ selector system,
      rotation selector system ∈
        _root_.Matrix.unitaryGroup coefficient ℂ) :
    prepareAmplitudeSelectUnprepare prepare rotation permutation ∈
      _root_.Matrix.unitaryGroup
        (LCUIndex coefficient selector system) ℂ := by
  apply (_root_.Matrix.unitaryGroup
    (LCUIndex coefficient selector system) ℂ).mul_mem
  · exact Unitary.star_mem
      (selectorLift_unitary (coefficient := coefficient) (system := system)
        prepare prepareUnitary)
  · apply (_root_.Matrix.unitaryGroup
      (LCUIndex coefficient selector system) ℂ).mul_mem
    · exact selectLift_unitary (coefficient := coefficient) permutation
    · apply (_root_.Matrix.unitaryGroup
        (LCUIndex coefficient selector system) ℂ).mul_mem
      · exact amplitudeLift_unitary rotation rotationUnitary
      · exact selectorLift_unitary (coefficient := coefficient)
          (system := system) prepare prepareUnitary

end QuantumBlockEncoding.Robin.ComplexLCU
