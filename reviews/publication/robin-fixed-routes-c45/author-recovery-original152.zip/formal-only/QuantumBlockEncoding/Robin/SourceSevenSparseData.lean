import QuantumBlockEncoding.Robin.EvolvedCandidates
import Mathlib.Tactic

   
                                                                    

                                                                            
                                                                           
                                                                            
                                  
  

namespace QuantumBlockEncoding.Robin

                                                                            
def warmRobinSourceDTOffset (slot : Fin 8) : Fin 8 :=
  ⟨(slot.val ^^^ 3) % 8, Nat.mod_lt _ (by decide)⟩

theorem warmRobinSourceDTOffset_table :
    List.ofFn warmRobinSourceDTOffset = [3, 2, 1, 0, 7, 6, 5, 4] := by
  native_decide

                                                                          
def warmRobinSourceDTRow (slot column : Fin 8) : Fin 8 :=
  ⟨(column.val + (warmRobinSourceDTOffset slot).val) % 8,
    Nat.mod_lt _ (by decide)⟩

                                                                      
def warmRobinSourceSevenWeight (slot column : Fin 8) : Int :=
  warmRobinIntegerTarget (warmRobinSourceDTRow slot column) column

                                                                      
theorem warmRobinSourceSevenWeight_slot7_zero (column : Fin 8) :
    warmRobinSourceSevenWeight 7 column = 0 := by
  fin_cases column <;> native_decide

                                                                                 
theorem warmRobinSourceDTRow_bijective_in_slot (column : Fin 8) :
    Function.Bijective (fun slot : Fin 8 => warmRobinSourceDTRow slot column) := by
  native_decide +revert

                                                                             
theorem warmRobinSourceDTRow_bijective_in_column (slot : Fin 8) :
    Function.Bijective (fun column : Fin 8 => warmRobinSourceDTRow slot column) := by
  native_decide +revert

                                                                           
theorem warmRobinSourceSevenSparseDecomposition (row column : Fin 8) :
    warmRobinIntegerTarget row column =
      ∑ slot : Fin 8,
        if slot.val < 7 ∧ warmRobinSourceDTRow slot column = row then
          warmRobinSourceSevenWeight slot column
        else 0 := by
  fin_cases row <;> fin_cases column <;> native_decide

def warmRobinSourceND : Rat := 8 / 3
def warmRobinSourceNf : Rat := 1
def warmRobinSourceKappa : Rat := 7

theorem warmRobinSourceAmplitude_eq_integer_div_32 (row column : Fin 8) :
    ((warmRobinIntegerTarget row column : Rat) / 12) /
        warmRobinSourceND =
      (warmRobinIntegerTarget row column : Rat) / 32 := by
  norm_num [warmRobinSourceND]
  ring

theorem warmRobinSourceAlpha_eq :
    warmRobinSourceND * warmRobinSourceNf * warmRobinSourceKappa = 56 / 3 := by
  norm_num [warmRobinSourceND, warmRobinSourceNf, warmRobinSourceKappa]

                                                                        
def warmRobinSourceSevenSelectorProbability (slot : Fin 8) : Rat :=
  if slot.val < 7 then 1 / 7 else 0

                                                                            
                                                                          
def warmRobinSourceSevenPaddedCoefficient (slot column : Fin 8) : Rat :=
  if slot.val < 7 then warmRobinSourceSevenWeight slot column / 32 else 1

def warmRobinSourceSevenCleanFormula : Matrix 8 8 Rat := fun row column =>
  ∑ slot : Fin 8,
    if warmRobinSourceDTRow slot column = row then
      warmRobinSourceSevenSelectorProbability slot *
        warmRobinSourceSevenPaddedCoefficient slot column
    else 0

theorem warmRobinSourceSevenCleanFormula_eq_integer_div_224
    (row column : Fin 8) :
    warmRobinSourceSevenCleanFormula row column =
      warmRobinIntegerTargetRat row column / 224 := by
  fin_cases row <;> fin_cases column <;> native_decide

theorem warmRobinSourceSevenCleanFormula_eq_target (row column : Fin 8) :
    warmRobinSourceSevenCleanFormula row column =
      RobinEvolution.warmRobinTarget row column /
        RobinEvolution.warmRobinNormalizer := by
  rw [warmRobinSourceSevenCleanFormula_eq_integer_div_224]
  symm
  exact congrFun (congrFun warmRobin_normalized_eq_integer_div_224 row) column

end QuantumBlockEncoding.Robin
