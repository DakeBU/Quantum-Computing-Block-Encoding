import QuantumBlockEncoding.Robin.Hadamard8BlockEncoding
import QuantumBlockEncoding.Robin.SymmetryFourSlot
import QuantumBlockEncoding.Robin.SystemConjugation
import Mathlib.Tactic

   
                                                       

                                                                          
                                                                
                                                                               
                                                                     
  

namespace QuantumBlockEncoding.Robin

open ComplexLCU
open scoped Kronecker

                                                              
abbrev WarmRobinFourSlotBits := Fin 2 × Fin 2

                                      
def warmRobinFourSlotBitsEquiv : WarmRobinFourSlotBits ≃ Fin 4 :=
  finProdFinEquiv

                                        
noncomputable def warmRobinFourSlotBitsPrepare :
    _root_.Matrix WarmRobinFourSlotBits WarmRobinFourSlotBits ℂ :=
  warmRobinUniformBitPrepare ⊗ₖ warmRobinUniformBitPrepare

                                               
theorem warmRobinFourSlotBitsPrepare_unitary :
    warmRobinFourSlotBitsPrepare ∈
      _root_.Matrix.unitaryGroup WarmRobinFourSlotBits ℂ := by
  apply _root_.Matrix.kronecker_mem_unitary
  · exact warmRobinUniformBitPrepare_unitary
  · exact warmRobinUniformBitPrepare_unitary

                                            
noncomputable def warmRobinFourSlotSelectorPrepare :
    _root_.Matrix (Fin 4) (Fin 4) ℂ :=
  _root_.Matrix.reindexAlgEquiv ℂ ℂ warmRobinFourSlotBitsEquiv
    warmRobinFourSlotBitsPrepare

                                               
theorem warmRobinFourSlotSelectorPrepare_unitary :
    warmRobinFourSlotSelectorPrepare ∈
      _root_.Matrix.unitaryGroup (Fin 4) ℂ := by
  apply reindex_unitary
  exact warmRobinFourSlotBitsPrepare_unitary

                                                                 
@[simp] theorem warmRobinFourSlotBitsPrepare_cleanColumn
    (bits : WarmRobinFourSlotBits) :
    warmRobinFourSlotBitsPrepare bits (0, 0) =
      (((Real.sqrt 2 / 2 : Real) : ℂ) *
        ((Real.sqrt 2 / 2 : Real) : ℂ)) := by
  rcases bits with ⟨first, second⟩
  simp [warmRobinFourSlotBitsPrepare]

                                                                
@[simp] theorem warmRobinFourSlotSelectorPrepare_cleanColumn (slot : Fin 4) :
    warmRobinFourSlotSelectorPrepare slot 0 =
      (((Real.sqrt 2 / 2 : Real) : ℂ) *
        ((Real.sqrt 2 / 2 : Real) : ℂ)) := by
  change warmRobinFourSlotBitsPrepare
      (warmRobinFourSlotBitsEquiv.symm slot)
      (warmRobinFourSlotBitsEquiv.symm 0) = _
  have zeroIndex : warmRobinFourSlotBitsEquiv.symm 0 = (0, 0) := by
    decide
  rw [zeroIndex]
  exact warmRobinFourSlotBitsPrepare_cleanColumn _

                                                                             
@[simp] theorem warmRobinFourSlotSelectorPrepare_probability (slot : Fin 4) :
    star (warmRobinFourSlotSelectorPrepare slot 0) *
        warmRobinFourSlotSelectorPrepare slot 0 = (1 / 4 : ℂ) := by
  rw [warmRobinFourSlotSelectorPrepare_cleanColumn]
  let c : Real := Real.sqrt 2 / 2
  have sqrtSquare : (Real.sqrt 2) ^ 2 = (2 : Real) :=
    Real.sq_sqrt (by norm_num)
  have cSquare : c * c = (1 / 2 : Real) := by
    dsimp [c]
    nlinarith
  have realProbability : (c * c) * (c * c) = (1 / 4 : Real) := by
    rw [cSquare]
    norm_num
  apply Complex.ext
  · simpa [c, mul_assoc] using realProbability
  · simp

                                                                              
abbrev WarmRobinSymmetrySystem := Fin 2 × Fin 4

                                                         
def warmRobinFourSlotSystemPerm
    (slot : Fin 4) (index : WarmRobinSymmetrySystem) :
    WarmRobinSymmetrySystem :=
  (index.1, warmRobinSymmetryFourShiftPerm slot index.2)

                                                                     
theorem warmRobinFourSlotSystemPerm_bijective (slot : Fin 4) :
    Function.Bijective (warmRobinFourSlotSystemPerm slot) := by
  fin_cases slot <;> decide

                                                              
noncomputable def warmRobinFourSlotSystemEquiv (slot : Fin 4) :
    WarmRobinSymmetrySystem ≃ WarmRobinSymmetrySystem :=
  Equiv.ofBijective (warmRobinFourSlotSystemPerm slot)
    (warmRobinFourSlotSystemPerm_bijective slot)

                                                                          
def warmRobinFourSlotCoefficient
    (slot : Fin 4) (column : WarmRobinSymmetrySystem) : Real :=
  ((warmRobinSymmetryFourShiftAmplitude column.1 slot column.2 : Rat) : Real)

                                                       
theorem warmRobinFourSlotCoefficient_abs_le_one
    (slot : Fin 4) (column : WarmRobinSymmetrySystem) :
    |warmRobinFourSlotCoefficient slot column| ≤ 1 := by
  rcases column with ⟨sector, pairColumn⟩
  fin_cases sector <;> fin_cases slot <;> fin_cases pairColumn <;>
    norm_num [warmRobinFourSlotCoefficient,
      warmRobinSymmetryFourShiftAmplitude,
      warmRobinSymmetryFourShiftWeight,
      warmRobinSymmetryPlusWeight,
      warmRobinSymmetryMinusWeight]

                                                               
noncomputable def warmRobinFourSlotRotation
    (slot : Fin 4) (column : WarmRobinSymmetrySystem) :
    _root_.Matrix (Fin 2) (Fin 2) ℂ :=
  amplitudeRotation (warmRobinFourSlotCoefficient slot column)

                                                        
theorem warmRobinFourSlotRotation_unitary
    (slot : Fin 4) (column : WarmRobinSymmetrySystem) :
    warmRobinFourSlotRotation slot column ∈
      _root_.Matrix.unitaryGroup (Fin 2) ℂ :=
  amplitudeRotation_unitary _

                                                                   
theorem warmRobinFourSlotRotation_cleanEntry
    (slot : Fin 4) (column : WarmRobinSymmetrySystem) :
    warmRobinFourSlotRotation slot column 0 0 =
      (warmRobinFourSlotCoefficient slot column : ℂ) := by
  have bounded := abs_le.mp
    (warmRobinFourSlotCoefficient_abs_le_one slot column)
  exact amplitudeRotation_cleanEntry _ bounded.1 bounded.2

                                                                          
theorem warmRobinFourSlotCoefficient_complex
    (slot : Fin 4) (column : WarmRobinSymmetrySystem) :
    (warmRobinFourSlotCoefficient slot column : ℂ) =
      (warmRobinSymmetryFourShiftAmplitude
        column.1 slot column.2 : ℂ) := by
  norm_num [warmRobinFourSlotCoefficient]

                                                                            
noncomputable def warmRobinFourSlotMiddleLogicalUnitary :
    _root_.Matrix
      (LCUIndex (Fin 2) (Fin 4) WarmRobinSymmetrySystem)
      (LCUIndex (Fin 2) (Fin 4) WarmRobinSymmetrySystem) ℂ :=
  prepareAmplitudeSelectUnprepare
    warmRobinFourSlotSelectorPrepare
    warmRobinFourSlotRotation
    warmRobinFourSlotSystemEquiv

                                                                     
theorem warmRobinFourSlotMiddleLogicalUnitary_unitary :
    warmRobinFourSlotMiddleLogicalUnitary ∈
      _root_.Matrix.unitaryGroup
        (LCUIndex (Fin 2) (Fin 4) WarmRobinSymmetrySystem) ℂ := by
  apply prepareAmplitudeSelectUnprepare_unitary
  · exact warmRobinFourSlotSelectorPrepare_unitary
  · exact warmRobinFourSlotRotation_unitary

                                                                
noncomputable def warmRobinFourSlotSectorCleanFormula :
    _root_.Matrix WarmRobinSymmetrySystem WarmRobinSymmetrySystem Rat :=
  fun row column =>
    (1 / 4 : Rat) * ∑ slot : Fin 4,
      if warmRobinFourSlotSystemEquiv slot column = row then
        warmRobinSymmetryFourShiftAmplitude
          column.1 slot column.2
      else 0

                                                                                 
theorem warmRobinFourSlotSectorCleanFormula_same
    (sector : Fin 2) (row column : Fin 4) :
    warmRobinFourSlotSectorCleanFormula
        (sector, row) (sector, column) =
      warmRobinSymmetryFourShiftCleanFormula sector row column := by
  simp [warmRobinFourSlotSectorCleanFormula,
    warmRobinFourSlotSystemEquiv, warmRobinFourSlotSystemPerm,
    warmRobinSymmetryFourShiftCleanFormula]

                                                                             
theorem warmRobinFourSlotSectorCleanFormula_cross
    {rowSector columnSector : Fin 2} (sectorMismatch : rowSector ≠ columnSector)
    (row column : Fin 4) :
    warmRobinFourSlotSectorCleanFormula
        (rowSector, row) (columnSector, column) = 0 := by
  simp [warmRobinFourSlotSectorCleanFormula,
    warmRobinFourSlotSystemEquiv, warmRobinFourSlotSystemPerm,
    Ne.symm sectorMismatch]

                                                                 
def warmRobinFourSlotSectorTarget :
    _root_.Matrix WarmRobinSymmetrySystem WarmRobinSymmetrySystem Rat :=
  fun row column =>
    if row.1 = column.1 then
      if row.1.val = 0 then
        (warmRobinSymmetryPlusBlock row.2 column.2 : Rat) / 224
      else
        (warmRobinSymmetryMinusBlock row.2 column.2 : Rat) / 224
    else 0

                                                                         
theorem warmRobinFourSlotSectorCleanFormula_eq_target
    (row column : WarmRobinSymmetrySystem) :
    warmRobinFourSlotSectorCleanFormula row column =
      warmRobinFourSlotSectorTarget row column := by
  rcases row with ⟨rowSector, rowPair⟩
  rcases column with ⟨columnSector, columnPair⟩
  by_cases sectorMatch : rowSector = columnSector
  · subst columnSector
    rw [warmRobinFourSlotSectorCleanFormula_same]
    fin_cases rowSector
    · simpa [warmRobinFourSlotSectorTarget] using
        warmRobinSymmetryPlusFourShiftCleanFormula_eq rowPair columnPair
    · simpa [warmRobinFourSlotSectorTarget] using
        warmRobinSymmetryMinusFourShiftCleanFormula_eq rowPair columnPair
  · rw [warmRobinFourSlotSectorCleanFormula_cross sectorMatch]
    simp [warmRobinFourSlotSectorTarget, sectorMatch]

                                                                                      
theorem warmRobinFourSlotMiddleLogicalUnitary_cleanEntry
    (row column : WarmRobinSymmetrySystem) :
    warmRobinFourSlotMiddleLogicalUnitary
        (0, (0, row)) (0, (0, column)) =
      (warmRobinFourSlotSectorCleanFormula row column : ℂ) := by
  unfold warmRobinFourSlotMiddleLogicalUnitary
  rw [prepareAmplitudeSelectUnprepare_cleanEntry]
  change
    (∑ slot : Fin 4,
      if warmRobinFourSlotSystemEquiv slot column = row then
        star (warmRobinFourSlotSelectorPrepare slot 0) *
          warmRobinFourSlotRotation slot column 0 0 *
          warmRobinFourSlotSelectorPrepare slot 0
      else 0) = _
  have castFormula :
      (warmRobinFourSlotSectorCleanFormula row column : ℂ) =
        (1 / 4 : ℂ) * ∑ slot : Fin 4,
          if warmRobinFourSlotSystemEquiv slot column = row then
            (warmRobinSymmetryFourShiftAmplitude
              column.1 slot column.2 : ℂ)
          else 0 := by
    norm_num [warmRobinFourSlotSectorCleanFormula]
    apply Finset.sum_congr rfl
    intro slot _
    by_cases selected : warmRobinFourSlotSystemEquiv slot column = row
    · simp [selected]
    · simp [selected]
  rw [castFormula, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro slot _
  by_cases selected : warmRobinFourSlotSystemEquiv slot column = row
  · simp only [selected, if_pos]
    rw [warmRobinFourSlotRotation_cleanEntry]
    rw [warmRobinFourSlotCoefficient_complex]
    rw [← warmRobinFourSlotSelectorPrepare_probability slot]
    ring
  · simp [selected]

                                                                              
theorem warmRobinFourSlotMiddleLogicalUnitary_cleanEntry_eq_target
    (row column : WarmRobinSymmetrySystem) :
    warmRobinFourSlotMiddleLogicalUnitary
        (0, (0, row)) (0, (0, column)) =
      (warmRobinFourSlotSectorTarget row column : ℂ) := by
  rw [warmRobinFourSlotMiddleLogicalUnitary_cleanEntry]
  exact_mod_cast warmRobinFourSlotSectorCleanFormula_eq_target row column

                                                         
theorem warmRobinFourSlotMiddleLogicalUnitary_cleanSystemBlock :
    cleanSystemBlock warmRobinFourSlotMiddleLogicalUnitary 0 0 =
      fun row column =>
        (warmRobinFourSlotSectorTarget row column : ℂ) := by
  ext row column
  exact warmRobinFourSlotMiddleLogicalUnitary_cleanEntry_eq_target row column

end QuantumBlockEncoding.Robin
