import QuantumBlockEncoding.RobinMatrix
import Mathlib.Tactic

   
                                        

                                                                          
                      
  

namespace QuantumBlockEncoding.RobinEvolution

                                                                      
def warmRobinTarget : Matrix 8 8 Rat := fun i j =>
  match i.val, j.val with
  | 0, 0 => -5 / 2
  | 0, 1 => 8 / 3
  | 0, 2 => -1 / 6
  | 1, 0 => 4 / 3
  | 1, 1 => -31 / 12
  | 1, 2 => 4 / 3
  | 1, 3 => -1 / 12
  | 2, 0 => -1 / 12
  | 2, 1 => 4 / 3
  | 2, 2 => -5 / 2
  | 2, 3 => 4 / 3
  | 2, 4 => -1 / 12
  | 3, 1 => -1 / 12
  | 3, 2 => 4 / 3
  | 3, 3 => -5 / 2
  | 3, 4 => 4 / 3
  | 3, 5 => -1 / 12
  | 4, 2 => -1 / 12
  | 4, 3 => 4 / 3
  | 4, 4 => -5 / 2
  | 4, 5 => 4 / 3
  | 4, 6 => -1 / 12
  | 5, 3 => -1 / 12
  | 5, 4 => 4 / 3
  | 5, 5 => -5 / 2
  | 5, 6 => 4 / 3
  | 5, 7 => -1 / 12
  | 6, 4 => -1 / 12
  | 6, 5 => 4 / 3
  | 6, 6 => -31 / 12
  | 6, 7 => 4 / 3
  | 7, 5 => -1 / 6
  | 7, 6 => 8 / 3
  | 7, 7 => -5 / 2
  | _, _ => 0

                                                                    
def warmRobinNormalizer : Rat := 56 / 3

                                            
def warmRobinCleanSignalIndex : Nat := 0

                                                                                       
def warmRobinSignalFirstIndex (signal : Nat) (system : Fin 8) : Nat :=
  signal * 8 + system.val

                                                                            
                                          
theorem warmRobinTarget_eq_eval_robinDerivativeMatrix :
    warmRobinTarget = fun i j =>
      Coeff.evalWith (fun _ => 0)
        (Examples.RobinHeat.robinDerivativeMatrix 3 i j) := by
  funext i j
  fin_cases i <;> fin_cases j <;>
    native_decide


   
                                                                       
                                                                               
                                                                               
                                                                          
                                                                            
  
theorem warmRobinTarget_eq_paperEq9_dimensionless_A1_B1_zero :
    warmRobinTarget = fun i j =>
      Coeff.evalWith (fun _ => 0)
        (Examples.RobinHeat.robinDerivativeMatrix 3 i j) :=
  warmRobinTarget_eq_eval_robinDerivativeMatrix

                                          

                                                                             
                                                                          
                                                                
  

                                                                             
def warmRobinParameters : GHL2025.OneTermRobinParameters :=
  Examples.RobinHeat.oneTermParameters 3

                                                                          
def warmRobinSourceLayout : RegisterLayout :=
  GHL2025.oneTermRobinLayout warmRobinParameters

                                                                              
def warmRobinVisiblePartition : GHL2025.RobinRegisterPartition :=
  GHL2025.defaultRobinRegisterPartition warmRobinParameters

                                                                        
                                                                    
                                                       
def warmRobinSourceCircuit : Circuit :=
  [ Gate.oracleCall "H_W^(kappa)"
  , Gate.oracleCall "U_indic"
  , Gate.oracleCall "O_DT^S"
  , Gate.oracleCall "Ry_boundary"
  , Gate.oracleCall "O_DT^BS"
  , Gate.oracleCall "U_indic^dagger"
  , Gate.oracleCall "O_f"
  , Gate.oracleCall "SWAP(two n-qubit registers; paper label only)"
  , Gate.oracleCall "(O_D^BS)^dagger"
  , Gate.oracleCall "(H_W^(kappa))^dagger"
  ]

                                                                           
theorem warmRobinSourceCircuit_gateList :
    warmRobinSourceCircuit =
      [ Gate.oracleCall "H_W^(kappa)"
      , Gate.oracleCall "U_indic"
      , Gate.oracleCall "O_DT^S"
      , Gate.oracleCall "Ry_boundary"
      , Gate.oracleCall "O_DT^BS"
      , Gate.oracleCall "U_indic^dagger"
      , Gate.oracleCall "O_f"
      , Gate.oracleCall "SWAP(two n-qubit registers; paper label only)"
      , Gate.oracleCall "(O_D^BS)^dagger"
      , Gate.oracleCall "(H_W^(kappa))^dagger"
      ] := by
  rfl

                                                                     
theorem warmRobinSourceCircuit_length :
    warmRobinSourceCircuit.length = 10 := by
  rw [warmRobinSourceCircuit_gateList]
  rfl

                                                           
theorem warmRobinParameters_spec :
    warmRobinParameters.n = 3 ∧
      warmRobinParameters.kappa = 7 ∧
      warmRobinParameters.functionPieces = 1 ∧
      warmRobinParameters.polynomialDegreeCost = 1 := by
  native_decide

                                                                          
theorem warmRobinSourceLayout_spec :
    warmRobinSourceLayout.systemQubits = 3 ∧
      warmRobinSourceLayout.signalQubits = 9 ∧
      warmRobinSourceLayout.pureAncillas = 6 := by
  native_decide

                                                                    
theorem warmRobinVisiblePartition_spec :
    warmRobinVisiblePartition.mfQubits = 5 ∧
      warmRobinVisiblePartition.indicatorQubit = 1 ∧
      warmRobinVisiblePartition.sparseIndexQubits = 3 ∧
      warmRobinVisiblePartition.odPureAncillaQubits = 0 ∧
      warmRobinVisiblePartition.systemQubits = 3 ∧
      warmRobinVisiblePartition.ancillaQubit = 1 := by
  native_decide

                                                                      
theorem warmRobinTotalQubits_eq :
    GHL2025.oneTermRobinTotalQubits warmRobinParameters = 13 := by
  native_decide

                                                            
theorem warmRobinEffectiveSignalQubits_eq :
    GHL2025.effectiveRobinSignalQubits warmRobinParameters = 10 := by
  rw [GHL2025.effectiveRobinSignalQubits_eq_layout_signal_plus_visibleWorkspace]
  native_decide

                                                                                      
theorem warmRobinIndicatorCertificate :
    (GHL2025.oneTermRobinGate_U_indic_dagger warmRobinParameters).matrix =
        (GHL2025.oneTermRobinGate_U_indic warmRobinParameters).matrix ∧
      (∀ j : Nat,
        GHL2025.indicatorOracleImage warmRobinParameters
          (GHL2025.indicatorOracleImage warmRobinParameters j) = j) ∧
      (∀ i : Fin (qubitDim
          (GHL2025.oneTermRobinTotalQubits warmRobinParameters)),
        ∃ j : Fin (qubitDim
            (GHL2025.oneTermRobinTotalQubits warmRobinParameters)),
          GHL2025.indicatorOracleMatrix warmRobinParameters i j = Coeff.rat 1 ∧
          ∀ j' : Fin (qubitDim
              (GHL2025.oneTermRobinTotalQubits warmRobinParameters)),
            GHL2025.indicatorOracleMatrix warmRobinParameters i j' = Coeff.rat 1 →
              j' = j) ∧
      (∀ j : Fin (qubitDim
          (GHL2025.oneTermRobinTotalQubits warmRobinParameters)),
        ∃ i : Fin (qubitDim
            (GHL2025.oneTermRobinTotalQubits warmRobinParameters)),
          GHL2025.indicatorOracleMatrix warmRobinParameters i j = Coeff.rat 1 ∧
          ∀ i' : Fin (qubitDim
              (GHL2025.oneTermRobinTotalQubits warmRobinParameters)),
            GHL2025.indicatorOracleMatrix warmRobinParameters i' j = Coeff.rat 1 →
              i' = i) := by
  have hbridge :=
    GHL2025.oneTermRobinGate_U_indic_dagger_selfInverseBridge
      warmRobinParameters
  have hperm :=
    GHL2025.indicatorOracleMatrix_is_permutation warmRobinParameters
  exact ⟨hbridge.1, GHL2025.indicatorOracleImage_self_inverse warmRobinParameters,
    hperm.1, hperm.2⟩

end QuantumBlockEncoding.RobinEvolution
