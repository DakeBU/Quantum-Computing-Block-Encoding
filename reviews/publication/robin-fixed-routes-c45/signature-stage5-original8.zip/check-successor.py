"""Own bounded C57 successor checks. No writes or Lean invocation.
Supply only authorized logical roots as arguments; output logical paths only.
"""
import sys, json, hashlib, importlib.util
from pathlib import Path
sys.dont_write_bytecode=True

def sha(b): return hashlib.sha256(b).hexdigest()
def j(p): return json.loads(p.read_bytes())
def main():
    root=Path(sys.argv[1])
    c57=root/'robin-c49-signature-successor-c57'
    old=root/'robin-c49-publicsafe-successor'
    own=root/'robin-c47-source-formal-stage4'
    manifest=j(c57/'manifest.json'); allow=j(c57/'publicsafe-allowlist.json'); seal=j(c57/'seal.json')
    names=sorted(p.name for p in c57.iterdir() if p.is_file())
    assert names==sorted(allow['files'])==sorted(manifest['publicsafeAllowlist'])==sorted(seal['publicsafeAllowlist'])
    pins=[]
    for n in names:
        b=(c57/n).read_bytes()
        pins.append({'path':'W/'+c57.name+'/'+n,'sha256':sha(b),'bytes':len(b)})
    bypin={p['path'].split('/')[-1]:p for p in pins}
    for p in manifest['artifacts']: assert bypin[p['file']]['sha256']==p['sha256'] and bypin[p['file']]['bytes']==p['bytes']
    assert sha((c57/'manifest.json').read_bytes())==seal['manifestSha256']
    assert sha((c57/'seal.json').read_bytes())=='799ad3b94ab03f9dbc7430b3b8870baaab55c28be6161194d7a09120fe3a9de9'
    assert sha((own/'seal.json').read_bytes())=='4af475e99b1f4a5211c0a8fc9cb78ed90ea2c9710a8d726a11b1a6254997fc64'
    assert (c57/'signature-annex-findings.snapshot.json').read_bytes()==(own/'signature-annex-findings.json').read_bytes()
    prior=j(old/'declaration-inventory.json'); after=j(c57/'declaration-inventory-c57.json')
    baseline=j(own/'module-declaration-coverage.json')['modules']
    assert prior['providers']==after['providers']
    spec=importlib.util.spec_from_file_location('c57_tested_helper',c57/'repair_signature_annex.py')
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    unit=helper.unit_tests()
    published=j(c57/'extractor-tests-c57.json')
    assert unit==published['unitTests'] and len(unit)==15
    rows=[];sourcepins=[];oldfields=0;published_comparisons=[]
    additions={'sourceSignatureStatus','exactSourceHeader','exactSourceHeaderBoundary','exactSourceHeaderScope'}
    for index,(p,n,b) in enumerate(zip(prior['targets'],after['targets'],baseline)):
        assert 'W/robin-fixed-routes-c45-author/'+n['path']==b['path']
        assert {k:v for k,v in n.items() if k!='declarations'}=={k:v for k,v in p.items() if k!='declarations'}
        assert len(p['declarations'])==len(n['declarations'])==len(b['declarations'])
        raw=(root/'robin-fixed-routes-c45-author'/n['path']).read_bytes()
        assert sha(raw)==n['sha256']==b['sha256']
        sourcepins.append({'path':'W/robin-fixed-routes-c45-author/'+n['path'],'sha256':sha(raw),'bytes':len(raw)})
        text=raw.decode('utf-8-sig')
        for a,z,ownrow in zip(p['declarations'],n['declarations'],b['declarations']):
            assert set(z)==set(a)|additions
            assert {k:z[k] for k in a}==a
            oldfields+=len(a)
            capture=z['sourceCapture']
            assert capture==text[z['characterStart']:z['characterEndExclusive']]
            assert sha(capture.encode())==z['captureSha256']==ownrow['completeCaptureSha256']
            assert z['name']==ownrow['name']
            assert z['exactSourceHeader']==ownrow['actualSourceHeader']
            reextracted,boundary=helper.exact_header(capture)
            assert reextracted==z['exactSourceHeader'] and boundary==z['exactSourceHeaderBoundary']
            assert z['sourceSignatureStatus']=='OBSOLETE_LEXICAL_PREFIX_AID_NOT_EXACT_COMMAND_HEADER'
            published_comparisons.append({'path':n['path'],'name':z['name'],'kind':z['kind'],
                'exactSourceHeader':reextracted,'oldSourceSignature':z['sourceSignature'],
                'different':reextracted!=z['sourceSignature'],'boundary':boundary['kind'],
                'captureSha256':z['captureSha256'],'sourceStart':z['characterStart'],
                'headerEndOffsetInCapture':boundary['offset']})
            rows.append({'path':b['path'],'name':z['name'],'baselineHeaderExact':True,
                'wholeCaptureExact':True,'oldFieldsExact':True,'helperReplayExact':True,
                'boundary':boundary['kind'],'changedFromOldAid':z['exactSourceHeader']!=z['sourceSignature']})
    assert len(rows)==215
    assert published_comparisons==published['actual215Comparisons']
    changes=[r for r in rows if r['changedFromOldAid']]
    assert len(changes)==18
    original_diffs=j(own/'signature-annex-findings.json')['differences']
    assert {(x['path'],x['name']) for x in changes}=={(x['path'],x['name']) for x in original_diffs}
    delta=j(c57/'annex-delta-c57.json')
    assert delta['changes']==[r for r in published_comparisons if r['different']]
    newbytes=(c57/'reconstruction.md').read_bytes();newtext=newbytes.decode()
    assert newtext.endswith(delta['reconstructionAddedLineage'])
    recovered=newtext[:-len(delta['reconstructionAddedLineage'])]
    for pair in reversed(delta['reconstructionDescriptionReplacements']):
        assert recovered.count(pair['new'])==1
        recovered=recovered.replace(pair['new'],pair['old'])
    oldbytes=(old/'reconstruction.md').read_bytes()
    assert recovered.encode()==oldbytes
    reconstruction={'inverseReplacementRecoversOriginalBytes':True,'originalBytes':len(oldbytes),
        'originalSha256':sha(oldbytes),'successorBytes':len(newbytes),'successorSha256':sha(newbytes),
        'descriptionReplacements':len(delta['reconstructionDescriptionReplacements']),'lineageAppendOnlyBeyondReplacements':True}
    priorpins=[]
    for base,ns in [(own,['seal.json','module-declaration-coverage.json','signature-annex-findings.json']),
        (old,['declaration-inventory.json','reconstruction.md'])]:
        for n in ns:
            data=(base/n).read_bytes();priorpins.append({'path':'W/'+base.name+'/'+n,'sha256':sha(data),'bytes':len(data)})
    result={'schema':'stage5-own-bounded-successor-checks-v1','reviewer':'/root/robin_c47_raw_source_recovery',
      'packageFiles':len(names),'packageHashesAndSetsExact':True,'originalStage4SealExact':True,
      'originalFindingSnapshotExact':True,'allTargetHeaders':len(rows),'privateHelperAndAmbientRetainedViaOldFields':True,
      'allOldDeclarationFieldValuesPreserved':True,'oldDeclarationFieldValueCount':oldfields,
      'all37ProviderRecordsExact':True,'boundedUnitTestsReplayed':unit,
      'actualCaptureAndHeaderChecks':rows,'changes':changes,'whereChanges':sum(r['boundary']=='where' for r in changes),
      'equationChanges':sum(r['boundary']=='equation-clauses' for r in changes),'reconstruction':reconstruction,
      'inputPins':pins+sourcepins+priorpins,
      'limits':'Bounded215actualsourceheaders and15lexer tests only. Prior independent headers predate C57. Not fullLeangrammar, elaboration, kernel, providerheader repair or metadata association. Helper main never invoked; no writes.'}
    print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':main()

