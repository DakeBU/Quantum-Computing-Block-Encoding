# C55 author-proposed topology successor

Status: AUTHOR_PROPOSED, NOT ACCEPTED. A genuine independent successor review
of this exact graph is required before any staged formal comparison proceeds.
This is a repair of a retrospective source-topology artifact, not a source
theorem correction, new scientific target, Lean proof or publication admission.

## Frozen scope

The complete successor graph retains the original source digest, all ten
established section nodes and their tails, all 71 region coverage records,
the empty exclusions list and the no-import-substitution flag exactly.
SOURCE.md remains unchanged. The finite-bit/hardware and Hermite gap records
also remain unchanged and unproved. The canonical-catalog addendum is retained,
not reinterpreted or edited. Original publication/role candidates, attributed
identities and signed bytes are not repaired by this graph task.

The only semantic inputs are the author's original source and graph, together
with the actual independent C51 Stage 2 topology report and findings. Original
package and catalog-addendum files are hashed for preservation only; their
implementation/formal/metadata contents are not used or released as evidence
for this repair. No formal packet, decoder result, production Lean or unrelated
later review/selected-metadata artifact is opened.

## T2-01: preserve the stronger full-operator OR

Source lines 333-335 explicitly allow remaining-column verification OR a
sufficient independent full-operator argument. The old graph recorded only
clean-sector equality AND remaining dirty-input columns, and its global OR list
was empty. That was incomplete at this stronger root even though the established
supplied-list assembly route has only one construction.

The successor has an OR group headed by the same unproved full-target gap.
Its all-columns route has the complete AND-tail: target-specific equality on
the clean input sector, plus specified and verified remaining nonzero-data-input
columns. The clean-sector equality with the recurrence is established in the
source, but equality of that recurrence with an arbitrary intended target is
not; the target-specific tail remains explicitly unsupplied.

The independent-operator route instead requires a sufficient independent proof
of the same whole operator identity, in the same dimensions, register convention
and literal phase semantics. It does not require column enumeration as an
additional route dependency. Such a proof would imply all column equalities,
but a logical consequence is not the same as its source proof path. Neither
route, nor any supplier to either route, is claimed delivered. The complete
matrix E(A_n)=F_n from the source is not confused with a separately specified
target-operator identity.

## T2-02: scope support to the restricted-active route

Source lines 323-327 first require core alignment and an initial-boundary
identity, then add support obligations if alignment is only on an active set.
The successor preserves the full-domain and restricted-active routes as separate
unresolved sufficient AND-routes to the same tensor-contraction head.

To describe the dependency meaning, let K_t be the intended local core and
beta its intended initial boundary. Define its contraction Q by the same
finite recurrence as source equation (9), with K in place of the actual local
clean-column entries and beta in place of the initial circuit column. These
symbols only expand the source's generic stronger application obligation.
No K, beta, target family or supplier is constructed here.

On the full-domain route, initial boundary equality and clean-column alignment
for all bond labels suffice: substitute in every term of the finite sum and
induct on the stage. There is no additional active-support premise. On the
restricted route choose active sets A_t. Require alignment only for incoming
labels in A_t, initial support in A_0, and preservation of this support by the
intended core recurrence through the used stages. Inductively the intended
contraction vanishes outside A_t; its equality with the actual run makes the
unidentified incoming terms zero. The same finite-sum substitution then works
on the remaining terms. Support is thus essential to this restricted route,
not a universal extra dependency of the full-domain route.

Taking every A_t to be the entire bond carrier makes support conditions
vacuous. This explains compatibility of the two formulations, but the graph
does not hide this specialization inside an unexplained universal AND-tail.
No support invariant, alignment fact or boundary match for a particular
application is proved by this repair.

## T2-03: spell out the terminal semantic head

Source lines 327-331 require both: every non-clean output bond amplitude
R_n(v_a)[x,b] is zero, and the surviving clean-bond amplitudes equal the
specified target. The successor records those two unsupplied obligations
explicitly, with the actual run identification retained. Preserved old data
does not supply either obligation. Nor does a support phrase by itself supply
the clean-branch target identity.

The old occupied-subspace/terminal-support phrases are retained as a scoped
supplier note, not universal additional premises for every possible proof of
the terminal semantic head. If a proof uses terminal columns specified only on
an occupied input subspace, it must justify that occupied-input support and
derive the literal two output conditions. Imposing the terminal prescription
on all padded input labels may be incompatible with unitarity, so the source's
warning remains unchanged. The repair asserts no terminal cleanup construction.

## Evidence and stopping boundary

exact-delta.json records complete old and new values for every changed graph
field and the unchanged-field list. boundary-ledger.json records the five
stronger heads and their still-unproved status. checks.json covers structural
preservation, OR/AND shape, exact raw-source region binding, input hashes and
public-safe output scan; it is not mathematical approval.

The first successor topology reviewer may receive the original unchanged raw
source, original graph, actual Stage 2 feedback and the proposed complete
successor graph. The stricter primary comparison allowlist withholds this
author rationale, delta, ledger, checks, preservation metadata and any prior
approval claim until the reviewer freezes its own comparison. The rationale
is separately available for a later explicitly authorized author-response
stage. Independent review, formal fidelity, compilation, publication and
Exposition gates remain pending. Integrity seals do not upgrade them.
