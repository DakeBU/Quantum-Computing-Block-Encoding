# Source-only assumption and definition audit

Identity: `/root/sequential_c51_raw_source_review`. No Lean binder expansion was
performed; the classifications below concern only the pinned mathematical source.

| Input or convention | Class | Role and limits |
| --- | --- | --- |
| Natural q,n; finite bit carriers and index membership | TYPING | All natural values, including zero. |
| Actual finite J and C_t family | SOURCE | Explicit source inputs, not existence theorems assumed to close synthesis. |
| Valid gate target and distinct CX wires | TYPING | Required to form the supplied instruction. |
| Supplied real angles and constructor domain inequalities | TYPING | Exact expression interface; not a cost or computability promise. |
| Complex scalars; output rows/input columns; chronological E | STANDING | Explicit S1 semantics; no reversal silently inferred from software. |
| Named-wire all-to-all model | STANDING | Explicit S2 boundary; no physical routing promise. |
| Literal phase equality, no quotient | STANDING | Both global and relative phases retained. |
| a,b in B_q, x in B_n, arbitrary v:B_q -> C | TYPING | Universally quantified labels/boundary; v can be zero or unnormalized. |
| Data input exactly 0_n | SOURCE | Domain of equations (10),(13),(18), not a global dirty-input theorem. |
| h natural and used-stage R+C<=h | SOURCE | Only the conditional bound (15); not a premise for amplitude identities. |
| J prepares the particular chosen application boundary | NOT SUPPLIED | Application identification obligation, not source binder. |
| Local cores equal occupied clean columns | NOT SUPPLIED | Must be a proof supplier for application contraction. |
| Active support and preservation | NOT SUPPLIED | Additional suppliers if only restricted local identities are available. |
| Terminal bond zero, target amplitudes, or target full operator | NOT SUPPLIED | Separate proof obligations; never inferred from passive old data. |
| Normalization, nonzero/positive boundary, rank condition | NOT REQUIRED | No such hypothesis for finite algebra. Unit-normalization of actual basis outputs follows from gates. |
| Future-stage bound, free initial state, free angle generation | NOT REQUIRED / NOT CLAIMED | Source expressly excludes these conveniences. |

RULED inputs: none. EXCESS inputs introduced by this reconstruction: none.
There is no exact Lean theorem available to justify a no-EXCESS Lean verdict.

All source definitions are literal: B_m, zero/empty words, concatenation,
gate entries, angle constructors, E, pad/P, e_* and basis pullbacks, R/C/G,
p/T/Q, A/F, U/R_t, delta, W/v_a, o/rev/V. The count promise is a hypothesis,
not a characterized object. No source object uses uniqueness, classical
choice, quotient representatives, default values off a valid locus, or an
unproved unitary-completion witness. The wire bijections are explicit formulas
with explicit inverses, not chosen reorderings. q=0 uses a singleton state
carrier, never an empty Hilbert space. Empty lists are literal identities.

Proof suppliers rather than assumed inputs: pad product law, placement
transport, stage kernel, A/F equality, clean-column induction, R-linearity,
initial-J composition, selected-count additivity, h summation, output reversal,
and gate unitarity. The source supplies the arguments; reconstruction.md
expands routine finite details. Stronger Hermite/application supplier nodes
remain outside the established roots and are not turned into conclusions.
