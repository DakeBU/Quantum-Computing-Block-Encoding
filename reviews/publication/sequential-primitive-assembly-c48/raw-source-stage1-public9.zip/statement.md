# Stage 1 source-only contract freeze

Reviewer: Codex worker `/root/sequential_c51_raw_source_review`.
Source author: Codex worker `/root/sequential_assembly_c48_source_author`, as
identified by SOURCE.md line 4. No formalizer or decoder identity is claimed.
Direction fingerprint: `raw-source-clean-column-and-wire-placement`.

The sole mathematical input is `sequential-assembly-c48-author/SOURCE.md`,
SHA256 `583cc9333ea977ec6684313749b6f52b49aded53e50456913f065487cada426a`,
344 lines, read completely before this independent reconstruction. This is
LOCAL retrospective source, not historical pre-proof evidence or a paper.
Governance was read for process only. No implementation was inspected.

For every natural q,n, chronological finite J on q wires, and family of finite
C_t on q+1 wires, construct A_n, W_n and the placed V_n exactly as source
equations (4),(7),(16) specify. Angles and valid distinct CX indices are supplied
typing data. Only t<n matters. Work in complex output-row/input-column matrices
on bit-function carriers B_m; concatenation is ordered and phases are literal.

The source's unconditional full-matrix root is E(A_n)=F_n, where F_n uses every
column of the actual local matrices. Its clean-input root is

    E(V_n)[x|b,0_n|a] = R_n(v_a)[rev(x),b],
    v_a[c] = E(J)[c,a],

for every a,b in B_q and x in B_n. This is the entire output of every input
in the linear span of |0_n>|a>; no conclusion for dirty data input or terminal
zero bond is included. Initial bond preparation is an actual list, not free.

For D=RY-count or CX-count, D(W_n)=D(J)+sum_{t<n}D(C_t), preserved for V_n.
If h is natural and each used stage has RY-count+CX-count <= h, then the same
selected sum for V_n is <= RY-count(J)+CX-count(J)+n*h. This promise is not
unconditional and is not a total-gate/depth/finite-bit/routing bound.

Empty lists and q=0,n=0 are in scope. Exact-real all-to-all named-wire gates
are X, RY, RZ, CX. There are no oracle instructions, measurements, implicit
phase quotients, numerical tolerances, or free physical state permutations.

This records a source-only contract before writing the explicit derivation.
It is NOT the repository's formal Statement Seal: no exact Lean signature has
been supplied or read, and no formal/compilation/publication acceptance follows.
