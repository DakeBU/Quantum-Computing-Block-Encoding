# Independent raw-source mathematical reconstruction

Reviewer: `/root/sequential_c51_raw_source_review` (Codex worker).
Source author: `/root/sequential_assembly_c48_source_author` (SOURCE.md:4).
Stage: 1, raw source only. Mathematical source digest:
`583cc9333ea977ec6684313749b6f52b49aded53e50456913f065487cada426a`.

## Verdict and scope

RECOVERABLE: the pinned LOCAL retrospective source supplies a sound algebraic
construction and derivation of its full-matrix assembly identity, clean-data
input amplitudes, physical-wire placement, and selected RY/CX resource counts.
I found no false mathematical step or missing substantive bridge within those
roots. Details expanded below are ordinary finite-sum and coordinate proofs,
not new hypotheses. No author material other than this source was read.

This is a mathematical verdict, not a Lean-fidelity verdict, compilation result,
source-topology approval of somebody else's graph, formal decoder result, or
publication/purification acceptance. The source is explicitly retrospective.
No historical source independence or new synthesis result is established.
No Hermite-family, finite-bit, or terminal-bond-cleanup theorem follows.

## Objects, quantifiers, and exact domain

For m natural, B_m consists of functions from {0,...,m-1} to {0,1}.
It has 2^m basis labels, including one empty label at m=0. Concatenation a|x
has a at indices <m and x at m+j; a dot u appends one bit. Vectors and square
matrices over B_m have complex entries, indexed output first and input second.
For matrices M,N, (MN)[r,s]=sum_z M[r,z]N[z,s]. Empty tensor factors are units.

For every q,n natural, J is an actual finite list on q valid wires and each
C_t is an actual finite list on q+1 valid wires. The family is indexed for all
natural t but no result uses or constrains t>=n. X_i, RY_i(theta), RZ_i(theta)
have one valid target; CX_(i,j) has two distinct valid wires. The real-angle
expression interfaces include the displayed arccos-domain inequalities;
arbitrary real values are allowed and no finite representation is promised.
The gate matrices and their untouched-coordinate conditions are literal
definitions. E([g0,...,gk]) applies g0 first, hence is E(gk)...E(g0).

U_t has index set {0,1} x B_q: its ordered pair (u,b) is a reindexing of the
physical word b dot u, NOT a claim that the fresh bit originally occupies the
lowest physical wire. R_t(v) has coordinates (emitted word x, final bond b).
Every complex v:B_q -> C is allowed in the recurrence, including zero and
unnormalized vectors. In the actual assembled circuit v_a is specifically
the a-th column of E(J), for every a in B_q.

The clean-data sector before final placement is span{|a>|0_n>:a in B_q}.
After placement it is span{|0_n>|a>:a in B_q}. The theorem determines every
output x and b on that sector and therefore its action on every superposition
of those inputs, with literal phase. For n>0 it does not determine the rest of
the operator. For n=0 the sector is the full input space. The full operator
E(A_n)=F_n is separately defined using the complete actual C_t matrices.

## Derivation 1: chronological products, padding, and placement

The source supplies proofs at lines 55-65 and 79-104. I expand the finite-sum
content here. A chronological split gives E(L++K)=E(K)E(L); no gate reversal
other than this operator-product convention is allowed. X and CX permute the
orthonormal basis, RY has orthonormal columns by c^2+s^2=1 and cancellation of
cs-sc, and RZ has diagonal modulus one. Thus finite lists are unitary. This
normalization fact is a proved consequence, not a premise for the identities.

For padding, the entry is

    P_t(M)[a|x,b|y] = [x=y] M[a,b].

The empty passive word gives t=0. Appending a passive bit multiplies by that
bit's equality indicator, proving the formula inductively. Moreover,

    (P_t(M)P_t(N))[a|x,b|y]
      = sum_{c,z} [x=z][z=y] M[a,c]N[c,b]
      = [x=y] sum_c M[a,c]N[c,b]
      = P_t(MN)[a|x,b|y].

Each padded gate has exactly this kernel because the new coordinates are
untouched. Induction over the finite list proves E(pad_t(L))=P_t(E(L)).

For a bijection e of old wires onto new wires, replacing every target/control
transports both boundary labels by pullback: r goes to r composed with e and
s goes to s composed with e. A one-gate equality follows from the touched
coordinates, the bijection of untouched coordinates, and distinct CX images.
For a product, z -> z composed with e bijects all intermediate words, so the
matrix sum is unchanged. Identity and induction give equation (3). A bijection
between the full finite wire sets entails equal wire cardinalities; the source's
m,m' notation does not provide an embedding into extra unaccounted wires.

Each padding/relabeling replaces an instruction by one of the same kind and
angle, without inserting a SWAP or any other gate. R,C,G are invariant and are
additive under list concatenation. Relabeling the entire program is a different
physical placement, not an operation that freely relocates an existing state.
The model permits all-to-all named-wire instructions, without locality charges.

## Derivation 2: one stage and passive data

Before stage t, physical order is bond a then old data x. Padding C_t by t
first gives temporary order (bond, fresh, old data). The source bijection sends
bond i to i, fresh q to q+t, and passive q+1+j to q+j. Its stated inverse has
disjoint exhaustive cases, so it is a bijection also when q=0 or t=0.
For output (a|x) dot u, pullback evaluates respectively to a[i], u, x[j],
which is exactly (a dot u)|x. The same applies to the input (b|y) dot v.
Combining this coordinate fact with padding and placement yields

    Q_t(M)[(a|x) dot u,(b|y) dot v]
      = [x=y] M[a dot u,b dot v],
    E(T_t(L)) = Q_t(E(L)).

This is the full stage kernel, not merely a clean-bit statement. It preserves
every old data coordinate as a passive quantum subsystem: the operator is
identity on that subsystem tensored/reordered with the active bond/fresh
operator. It does not freeze the bond. It also does not erase prior
entanglement between bond and data. The active gate may change bond amplitudes
while the numeric bond wire labels stay fixed. The fresh wire is q+t.
The example images (0,1,5,2,3,4) for q=2,t=3 follow directly.

## Derivation 3: the complete flattened matrix

A_0 is empty and F_0=I. For each t,

    E(A_(t+1))
      = E(T_t(C_t)) E(pad_1(A_t))
      = Q_t(E(C_t)) P_1(E(A_t)).

Substitution of the inductive equality E(A_t)=F_t gives exactly F_(t+1).
Thus E(A_n)=F_n for all output and input labels, including dirty data inputs.
Lifting to the final width preserves every numerical wire index of earlier
gates; old data stays passive under subsequent local stages. This equality
does not reconstruct the full matrices from a subset of clean columns: the
definition of F uses every actual supplied matrix entry.

## Derivation 4: clean-data accumulation and the initial list

Define K_t(u)[b,c]=E(C_t)[b dot u,c dot 0]. This abbreviation is not extra
input. The recurrence in the source says

    R_0(v)[empty,b]=v[b],
    R_(t+1)(v)[x dot u,b]=sum_c K_t(u)[b,c] R_t(v)[x,c].

Equivalently, for emitted word w and terminal b_n=b, its explicit finite
contraction is

    R_n(v)[w,b]
      = sum_{b_0,...,b_(n-1) in B_q}
          v[b_0] product_{t=0}^{n-1} K_t(w[t])[b_(t+1),b_t].

For n=0 this expression is interpreted by the recurrence as v[b], without
introducing a nonexistent b_0 summation. This contraction is my routine
expansion of the source recurrence, not an identified external tensor core.

Now evaluate F_(t+1) on input (a|0_t) dot 0. Its intermediate label is
(c|y) dot v. The padding factor is [v=0]F_t[c|y,a|0_t], while the stage factor
is [x=y]E(C_t)[b dot u,c dot v] at output (b|x) dot u. Summing over c,y,v
forces y=x and v=0; no other terms survive. The result is

    sum_c K_t(u)[b,c] F_t[c|x,a|0_t].

The base entry is [b=a]. Substituting the induction hypothesis identifies
this sum with R_(t+1)(delta_a)[x dot u,b], proving equation (10) for every a,b,x.
In particular, no bond output sector was discarded; nonzero bond outputs are
part of the conclusion and are not asserted to vanish.

Linearity is also a finite induction. At t=0,
sum_a [b=a]v[a]=v[b]. At the successor, insert the previous expansion into
sum_c K_t(u)[b,c]R_t(v)[x,c], distribute, and interchange finite sums. The
coefficient of v[a] is precisely R_(t+1)(delta_a)[x dot u,b]. This proves (12)
for all v with no nonzero, positivity, normalization, or convergence condition.

Finally W_n=pad_n(J)++A_n applies J before all stages. By chronology its
matrix is F_n P_n(E(J)). On clean-data input the intermediate passive data
word is forced to 0_n, leaving

    sum_c R_n(delta_c)[x,b] E(J)[c,a]
      = R_n(v_a)[x,b].

This proves (13). It uses the column of the given J and provides no algorithm
to synthesize J for arbitrary externally prescribed v. For physical zero
input use a=0_q. From gate unitarity its resulting full state is normalized;
the amplitude identities themselves do not need unitarity as a premise.

## Derivation 5: public low-wire order and the phase-exact adapter

The final bijection o sends old bond i to n+i and emitted position q+t to
n-1-t. The ranges are disjoint and exhaustive, with the source's inverse.
Pulling x|b back yields b|rev(x), where rev(x)[t]=x[n-1-t]; pulling 0_n|a
back yields a|0_n. Applying whole-program placement then (13) gives

    E(V_n)[x|b,0_n|a] = R_n(v_a)[rev(x),b].

No row-only permutation, column-only permutation, complex conjugation, phase
factor, or physical SWAP is inserted. Equation (18) is literal. Setting
w=rev(x) and j=n-1-t transforms sum_t 2^(n-1-t)w[t] into sum_j 2^j x[j].
This explains why the first emitted bit is on the highest data wire, despite
the public data integer being little-endian. For q=2,n=3 the images are
(3,4,2,1,0). The final bond is on high wires, with no zero-output promise.

## Derivation 6: resources and exact omissions

For D=R or C, pad and placement preserve D. Therefore
D(A_(t+1))=D(A_t)+D(C_t) from A_0=[], giving sum_{t<n}D(C_t).
W_n adds exactly D(J), and V_n preserves that total. If each used stage obeys
R(C_t)+C(C_t)<=h, summing the n inequalities and adding R(J)+C(J) gives (15).
At n=0 there is no stage promise to check and the bound is equality.

The source explicitly supplies the promise only for t<n; it is not a lemma
about arbitrary lists. R counts RY, not all one-qubit rotations. RZ and X
contribute to length G but not R+C. A stage with k X instructions has R+C=0
and G=k, for arbitrarily large k. Thus the h bound gives no total-gate bound.
The same additive recurrence also yields G(W_n)=G(J)+sum_{t<n}G(C_t) as a
routine independent corollary of the supplied invariances, but NO numerical
bound on those G(C_t) is supplied. This corollary is not presented as a claimed
source resource root. No depth, precision, Clifford+T, runtime, connectivity,
readout, or classical angle/list-generation bound is inferred. Oracle count
zero is grammatical absence, not a free-input or free-compilation theorem.

## Degenerate cases, strengthened claims, and sharp boundaries

When q=0, B_q is a singleton. J must be empty because none of the instruction
constructors has a valid target. Each C_t is still on one fresh wire and the
bond sums have one term. CX cannot occur on one wire, but X/RY/RZ can.
Stage placement leaves old bits passive and sends that fresh wire to t.
When n=0, A_0=[], W_0=J, o fixes the bond, R_0(v_a)=v_a, and the public
equation is E(J)[b,a]=v_a[b]. With q=n=0 the matrices are 1 by 1 identity.
An empty C_t has identity kernel K_t(u)[b,c]=[b=c][u=0], so it emits zero
and preserves the bond. All zero-dimension statements follow by actual
singleton/empty-word evaluation, not a zero-vector fallback.

The source gives no application tensor core. To identify its contraction one
must supply the K_t-to-core identifications AND initial-boundary identification.
If these hold only on active bond labels, one additionally needs initial
support AND preservation of support; otherwise transitions outside the active
set can contribute. To remove the final bond one additionally needs all
non-clean b amplitudes zero AND an identification of the surviving amplitudes.

A minimal non-clean-bond witness uses q=1,n=0,J=[X_0],a=0: the output bond
is 1. Even with one emitted bit, q=1,n=1,J=[],C_0=[X_0] outputs bond 1 and
data 0. These are boundary counterexamples to an unclaimed strengthening,
not counterexamples to the source. More generally a unitary cannot map two
orthogonal occupied inputs to one identical normalized terminal output; this
is why cleanup prescriptions require a justified occupied subspace rather
than arbitrary padded-column specifications.

Clean columns also cannot imply a target full-operator identity: at q=0,n=1,
diag(1,1) and diag(1,-1) have identical clean-input (first) columns but different
second columns. This phase-exact information example is supplied by the source;
it does not add a gate to the instruction grammar. Supplying every dirty-input
column OR a sufficient independent full-operator argument would close that
different root; neither is supplied here. Relative/global phase is never
quotiented away, so even a phase-only difference cannot be ignored.

## Source proof versus reviewer work; handoff

Source-supplied arguments: gate unitarity; padding induction and product
compatibility; wire-bijection transport; stage kernel; flattened-matrix
induction; clean-column induction; boundary linearity; J composition; selected
count induction and h summation; final reversal; degenerate and scope cases.
Reviewer-filled routine details: explicit padded-product double sum, three-case
pullback expansion, full clean-sector collapse, explicit finite contraction,
G-additivity corollary, and concrete unclaimed-cleanup counterexamples.
No new substantive mathematical premise was inserted and no external theorem
supplier, citation, code, finite diagnostic, or implementation graph was used.

Failure class: NONE for the pinned mathematical roots. Stronger application
roots are NOT_ESTABLISHED, not refuted in general. Their absent prerequisites
are explicitly separate graph nodes, not hidden theorem binders.
Salvage: all source algebraic identities remain mathematically usable; no
formal reusable library status is asserted without Lean and independent gates.
Process-memory IDs consulted: none, to preserve the first-stage input boundary.
Expected information gain: independently distinguish full actual-matrix
assembly from clean-column application data, and audit both placement boundaries.
Parallel/common-blind-spot status: this worker spawned nobody; comparison with
other routes remains parent-owned and is not claimed performed here.
Default verified route: only the pinned construction was assessed, with no
comparison winner. Purification/Exposition Seal: not performed; this report
preserves the source boundary but does not inspect Lean expansion nodes.
Recommended next step: stop at Stage 1; any later formal comparison requires
separate authorization/release and a genuinely distinct formal decoder/reviewer
assignment. The same worker must not masquerade as those independent identities.
