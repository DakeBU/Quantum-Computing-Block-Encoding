# Independent source-only successor review

Reviewer: Codex worker `/root/sequential_c51_raw_source_review`.
Retrospective SOURCE author: `/root/sequential_assembly_c48_source_author`.
Historical formalizer: UNKNOWN. No formal decoder or formal comparison role
is claimed. This is source-topology Stage 3, not the previously contemplated
source/formal Stage 3.

## Verdict

ACCEPTED_SOURCE_TOPOLOGY_ONLY for the exact C55 successor graph
`21e9cadc1325b35382dea47c46e2fdad4a99e8f34fdbe90a4347567d5b67323d`.
No blocking source-topology issue found in this successor. The two blocking
findings against the original graph are addressed here, and the terminal
precision recommendation is addressed. The old graph and its adverse Stage 2
review remain frozen, not retroactively accepted or overwritten.

This verdict concerns the LOCAL retrospective source and its graph, not a
historical pre-proof source, formal signature/body fidelity, compiler success,
selected publication metadata, final wrapper, main admission or PURIFIED state.
All stronger application heads and their suppliers remain unproved. Formal
comparison is not entered and requires a separate later release.

## Inputs and independent comparison order

I first read and verified the primary-input allowlist
`531f2794d1cfb8bd4d784323e61bd3a772e6e4f2670917d96adadb6b2b3e410b`.
Its five primary inputs were the same SOURCE, original graph, my own Stage 2
report/findings, and the successor graph. My frozen source-first Stage 1
derivation remained the independent mathematical baseline. I read the whole
1036-line successor in four bounded chunks before writing this comparison.
All five primary input pins matched. No rationale, delta, ledger, author checks,
build helper, formal packet, decoder output, selected metadata, unrelated review
or production repository material was read. The primary inputs suffice, so
those withheld supporting materials are unnecessary for this verdict.

## Established construction and coverage preserved

Exact parsed-object comparison verifies the successor preserves all ten
section nodes including every ordered AND tail, all 71 coverage records
including stored text/digests/ranges/dispositions, the excluded list, the
source digest and the no-Lean-import-substitution flag. The finite-bit/hardware
and Hermite stronger-gap objects are also unchanged. Coverage therefore inherits
the already directly checked 274 nonblank source lines with zero omissions,
overlaps, text mismatches or digest mismatches. The terminal line-345 sentinel
convention is unchanged and remains harmless; the ordinary source has 344 lines.

The established mathematical route is still exact supplied gate lists,
chronological multiplication, padding and both-boundary pullback, stage kernel
with passive old data, full actual-stage matrix assembly, clean-data-input
recurrence, actual initial-J column, selected RY/CX counts, and whole-program
MSB/LE output reversal. No bond cleanup, dirty-input target equality or numerical
resource theorem has been smuggled into it. The single established construction
has not been conflated with the newly explicit unproved application OR routes.

## T2-01: full-operator OR independently recovered

Source 333-335 allows remaining-column verification OR a sufficient independent
full-operator proof. The successor gives `gap:full-target-unitary` the group
`or:full-target-operator`. Its all-columns route has the complete AND tail
of target clean-sector equality and verified remaining data-input columns.
Both obligations bind the same supplied circuit and specified target, include
all bond/output labels, and preserve dimensions, register order and literal
phase. Every input word has either zero or nonzero data, so these two column
families partition all inputs. Entrywise equality on both proves matrix equality.

The other route has only a sufficient independent full-operator argument as its
tail, with the same target and exact semantics. Such a proof establishes the
whole identity without requiring column enumeration as its proof topology.
Remaining-column equality is then a consequence, not an extra dependency of
this route. Thus the explicit OR now matches the source without creating a
second proved circuit or accepting any target supplier. Both routes and the
head are UNRESOLVED; the repair delivers no supplier.

## T2-02: full-domain versus restricted-active route

Write H_t(x,b)=R_t(v_a)[x,b] for the actual source run, and let Q_t be the
intended core contraction with boundary beta and coefficients K_t(u,b,c).
Both use the finite recurrence

    next(x dot u,b) = sum_c coefficient(u,b,c) current(x,c).

The actual coefficient is E(C_t)[b dot u,c dot 0]. The initial-boundary
obligation identifies beta with the actual J column on every bond label.

Full-domain route: the successor requires coefficient equality for every used
t, every emitted bit u, every output bond b, and every input c in B_q. At
t=0 the run values agree by the boundary identity. At a successor, substitute
the induction equality into every summand, then replace every coefficient
by the core coefficient. The sums agree for all x dot u and b. No support
assumption is needed because no summand is outside the equality's domain.
This proves the claimed sufficient route within the established source-run
context, without supplying either application identity.

Restricted-active route: active sets A_t are chosen in B_q. The successor's
`core-columns-restricted-active` says, literally, for every used t, u,b and
incoming c in A_t the coefficients agree. In particular b is NOT restricted
to A_(t+1). I do not infer this outgoing-label scope from support language;
it is expressly quantified in the coefficient obligation itself.

The initial support obligation says beta[c]=0 outside A_0. The preservation
obligation concerns the intended recurrence Q: support on A_t implies support
on A_(t+1) at each used stage. This suffices without assuming actual-run
support independently. Induct simultaneously:

1. Q_t is supported on A_t, using its initial support and preservation.
2. H_t=Q_t for every emitted prefix and EVERY output bond label.

The base equality follows from beta=v_a. For the successor equality, use the
induction equality H_t=Q_t, so terms with c outside A_t vanish. On c inside
A_t, coefficient equality holds for every outgoing b, so the remaining finite
sum is exactly Q_(t+1). Therefore H_(t+1)=Q_(t+1) on all output labels, and
the intended support statement also transfers to the actual run as a derived
fact. This is why intended-core support preservation, as actually stated in
the successor, is sufficient. The case A_t=B_q makes all support conditions
vacuous but does not add them to the separate full-domain route.

Outgoing-label scope is essential, not cosmetic. If comparison only tested
active-to-active entries, take q=1,n=1, J empty, C_0=[X on the bond], beta=delta_0,
A_0=A_1={0}, and intended core identically zero. Every active-to-active entry
agrees (zero), the intended run preserves support, but the actual state has
amplitude one at emitted bit 0 and outgoing bond 1. This is a rigorous finite
counterexample to that weakened alternative, NOT to the successor, which
explicitly requires equality also at outgoing b=1 and therefore excludes it.
No executable diagnostic substitutes for the general induction above.

The successor's two contraction tails now retain the source's conditional
support scope. Every application supplier is marked UNSUPPLIED and both routes
UNRESOLVED. The established source run is the ambient proved context for
these stronger-root obligations; the repair does not independently construct
any K_t, beta, active set or application target.

## T2-03: exact terminal conditions

The cleanup head now has the AND tail: identify the actual terminal source run,
prove nonclean output amplitudes zero, and identify the surviving target
amplitudes. For designated b_clean its two application obligations explicitly
say, respectively,

    for every x and b != b_clean, R_n(v_a)[x,b] = 0;
    for every x, R_n(v_a)[x,b_clean] = f[x].

These conditions identify every output coordinate. Thus the joint state is
the specified data amplitude vector with bond b_clean, in the source emission
and literal phase convention; the existing public placement adapter can then
be applied without altering the proof obligation. No projection, postselection,
normalization, target synthesis or free cleanup is substituted. If a supplier
uses only occupied terminal input columns, it must separately justify that
occupied support and column action; the successor does not impose those
particular supplier prerequisites on every possible proof of the output
conditions. The incompatibility warning for arbitrary all-padded-column
prescriptions is retained. The zero and surviving-amplitude suppliers remain
UNSUPPLIED; the generic run identity does not supply either.

## Unproved boundaries and disposition

The five stronger heads are still source gaps/application boundaries, not
gaps inside the established assembly proof. No alternative supplier is supplied
by this repair. Finite input encoding, charged angle production, error analysis,
logical synthesis/routing, Hermite formula/norm, core/rank generator, compiler
columns, initial/terminal interfaces and the relevant charged resource theorem
remain separate future work, unchanged by this topology verdict.

Failure class: NONE for the exact successor source topology. T2-01/T2-02 are
resolved only in this successor, T2-03 is clarified only here, and the original
adverse review is preserved. Salvage/promotion: the successor is suitable as
source-topology evidence for a later separately authorized formal comparison;
no formal/library/publication promotion is claimed. Process-memory IDs: none.
Direction fingerprint: raw-source-clean-column-and-wire-placement / successor
topology continuation. Common-blind-spot and formal comparator work: not done.
Purification/Exposition Seal: not performed. Stop after this source-only seal.
