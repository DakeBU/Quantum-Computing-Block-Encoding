# Definition and proof-source dependency map

This is a human source-read map, NOT an elaborated Lean proof-term graph. Imports, definitional support, explicit proof references, and separately derived mathematical observations have different meanings. Tactic elaboration and implicit simp/typeclass dependencies are not exhaustively exported here. All target declarations were read; providers are definition context, not whole-module source admission. `T` abbreviates the target namespace QuantumBlockEncoding.SequentialPrimitiveAssembly; `RAP`, `SBP`, `PWR` abbreviate RealAmplitudePreparation, SequentialBondPreparation, PrimitiveWireRename within QuantumBlockEncoding.

## Imports only

The target directly imports PWR (line 1) and SBP (line 2). PWR imports RAP; SBP imports RAP. RAP imports UniformlyControlledRy, PrimitiveBasisLE and StatePreparation. UniformlyControlledRy and PrimitiveBasisLE import PrimitiveSemantics; PrimitiveSemantics imports PrimitiveCircuit, Robin.Hadamard8Verified and Mathlib.Tactic. PrimitiveCircuit imports Resources and Mathlib modules for inverse trigonometry, rational/real data and finite sets. Resources imports Core; StatePreparation imports BlockEncoding. The requested ComplexLCU supplement imports ConcreteSemantics and matrix/trigonometry/Mathlib modules. These import edges do NOT say that every declaration in an imported module is used by the target or admitted by this review. Core, BlockEncoding, Hadamard8Verified and ConcreteSemantics were not opened.

## Definitions actually expanded to interpret the target

| Provider and exact snapshot positions | Semantic role |
| --- | --- |
| PrimitiveCircuit 17–30, 46–55 | ExactAngle constructors/guards and exact-real evaluation. |
| PrimitiveCircuit 95–101, 132–159, 181–195 | Gate syntax, circuit list, gateCount/Ry/CX counters, touched-wire depth and circuit Resource. |
| PrimitiveSemantics 18–20, 116–125, 143–145, 158–180, 200–224, 238–245, 329–335, 380–398 | Basis, one-qubit and permutation gate action, Ry/Rz conventions, chronological matrix evaluation. |
| ComplexLCU supplement 18–30, 60–78, 148–151 | Ambient namespace, actual rotation sign and actual permutation direction. |
| RAP 20–45, 60–64 | Last-wire split, liftLastMatrix and gate lifting. |
| PWR 10–33 | Basis transport, gate/list renaming and matrix pullback convention. |
| SBP 26–41, 44–59, 64–68, 93–96, 113, 248–260 | Ambient finite-bond requirements, Stage/BondState, fresh zero input, step/run, basisBoundary, and circuit-stage index adapter. |
| Resources 21–27, 68–73 | All Resource fields and actual ofCountsWithDepth argument positions. |

All nine original provider modules were read through EOF, as separately logged. The table distinguishes definition-support slices from whole-file reading. Additional formal provider content was not silently turned into target conclusions. In particular SBP's core/support/terminal cleanup and transfer theorems, RAP's prepareCircuit and normalization, PrimitiveBasisLE's integer conversion, and StatePreparation's certificate records are not needed to establish what the target states.

## Target definition-body edges

| Target definition | Actual body support |
| --- | --- |
| pad | itself recursively; List.map; RAP.liftGate |
| padMatrix | itself recursively; RAP.liftLastMatrix |
| stageWires | explicit Fin.addCases/lastCases/castAdd/castSucc/natAdd maps and inverse proofs |
| placeStage | T.pad; T.stageWires; PWR.circuit |
| placedMatrix | T.padMatrix; T.stageWires; PWR.matrix |
| assemble | itself recursively; RAP.liftGate; T.placeStage; list append |
| assembledMatrix | itself recursively; identity matrix; T.placedMatrix; evalPrimitiveCircuit; RAP.liftLastMatrix; matrix multiplication |
| withInitial | T.pad; T.assemble; list append |
| outputWires | explicit Fin.addCases/natAdd/castAdd/rev maps and inverse proofs |
| publicCircuit | T.outputWires; T.withInitial; PWR.circuit |

## Every target theorem: inspected proof-body support

The following records explicit mathematical references and the structural argument; standard equality congruence, Fin extensionality and tactic infrastructure are understood, not promoted to source theorems.

| Theorem | Proof-source support read in its body |
| --- | --- |
| eval_pad | pad recursion, induction on extra, RAP.eval_liftCircuit. |
| padMatrix_append | padMatrix recursion; empty-function subsingleton at zero; RAP.lastBasisEquiv/symm; Fin.append_snoc; RAP.liftLastMatrix_apply; induction; equality splits on old tail and last bit. |
| pad_ryCount | pad recursion; RAP.liftCircuit_ryCount; induction. |
| pad_cxCount | pad recursion; RAP.liftCircuit_cxCount; induction. |
| pad_gateCount | pad recursion; PrimitiveCircuit.gateCount; list-map simplification; induction. |
| stageWires_fresh | stageWires expansion and Fin case simplification. |
| stageWires_bond | stageWires expansion, numeric-value simplification. |
| stageWires_basis | stageWires expansion, Fin.addCases/lastCases, snoc/append coordinates. |
| eval_placeStage | placeStage; PWR.eval_circuit; eval_pad; definitional reduction to placedMatrix. |
| placedMatrix_apply | placedMatrix; PWR.matrix_apply; stageWires_basis twice; padMatrix_append. |
| placeStage_ryCount | placeStage; PWR.ryCount and pad_ryCount through simp. |
| placeStage_cxCount | placeStage; PWR.cxCount and pad_cxCount through simp. |
| placeStage_gateCount | placeStage; PWR.gateCount; pad_gateCount. |
| eval_assemble | assemble; evalPrimitiveCircuit_append; eval_placeStage; RAP.eval_liftCircuit; assembledMatrix recursion and induction. |
| assembledMatrix_clean_column | assembledMatrix recursion; SBP.run/basisBoundary/step_apply/circuitStage_apply; RAP.lastBasisEquiv and liftLastMatrix_apply; matrix entry multiplication; Fin.appendEquiv and product-sum reindexing; placedMatrix_apply; induction. |
| assemble_clean_column | eval_assemble; assembledMatrix_clean_column. |
| run_boundary_decomposition | SBP.run/basisBoundary/step_apply; induction; finite multiplication-over-sum and sum interchange. No unitary premise is used. |
| withInitial_column | withInitial; evalPrimitiveCircuit_append; eval_pad; matrix multiplication entries and Fin.appendEquiv sum reindexing; padMatrix_append; assemble_clean_column; run_boundary_decomposition. |
| assemble_ryCount | assemble; PrimitiveCircuit.ryCount/ryCount_append; RAP.liftCircuit_ryCount; placeStage_ryCount; finite range sum successor; induction. |
| assemble_cxCount | assemble; PrimitiveCircuit.cxCount/cxCount_append; RAP.liftCircuit_cxCount; placeStage_cxCount; finite range sum successor; induction. |
| assemble_noOracle | rfl: unfolds circuit.resource and Resource.ofCountsWithDepth's oracleCalls field. No oracle theorem supplied by an external construction. |
| withInitial_ryCount | withInitial; PrimitiveCircuit.ryCount_append; pad_ryCount; assemble_ryCount. |
| withInitial_cxCount | withInitial; PrimitiveCircuit.cxCount_append; pad_cxCount; assemble_cxCount. |
| withInitial_primitive_bound | withInitial_ryCount; withInitial_cxCount; h applied to each member of Finset.range n; Finset.sum_le_sum; constant-sum simplification; Finset.sum_add_distrib; natural arithmetic. |
| outputWires_basis | outputWires; Fin.addCases coordinate cases; Fin.append_left/right. |
| publicCircuit_column | publicCircuit; PWR.eval_circuit; PWR.matrix_apply; outputWires_basis for output and input; withInitial_column. |
| publicCircuit_primitive_bound | publicCircuit; PWR.ryCount; PWR.cxCount; withInitial_primitive_bound with the unchanged explicit h. |

## Referenced provider theorem support

PWR.eval_circuit (112–118) uses list induction, PWR.eval_gate and matrix_mul; PWR.eval_gate (83–109) checks the four constructors using oneQubit/context_eq and x/cx action pullbacks. PWR.matrix_mul (35–38) is the algebra-equivalence multiplication property. The count transport proofs occur at PWR 120–133. RAP.eval_liftCircuit (135–140) uses list induction, eval_liftGate (108–133), and liftLastMatrix_mul (54–57); eval_liftGate handles Ry/Rz through lift_oneQubit and X/CX through their basis actions. RAP's liftCircuit counter proofs are at 329–341. PrimitiveSemantics.evalPrimitiveCircuit_append is at 395–404. SBP.step_apply is at 64–68, directly expanding step, matrix-vector multiplication and freshZero; SBP.circuitStage_apply is definitional at 256–260. These are the actual provider interfaces reached by target proofs, not an assertion of compiler-extracted dependency completeness.

## Distinct from source-proof topology

No natural-source construction graph was reconstructed: source is withheld. The target proof topology is padding/relabeling -> whole-matrix sequential recursion -> clean-column recursion -> initial-column linearity -> public wire adapter, with a separate syntactic-count branch. That is an interpretation of inspected Lean source, not a claim about how a withheld author proved anything. No source classification, accepted comparison verdict, or fabricated source-to-Lean wrapper is present.
