# Whole-target declaration, signature, and body inventory

Target: `W/sequential-c53-formal-input/QuantumBlockEncoding/SequentialPrimitiveAssembly.lean`. All positions below are 1-based LF snapshot lines. Namespace: `QuantumBlockEncoding.SequentialPrimitiveAssembly`; `open RealAmplitudePreparation` at line 12 affects unqualified name resolution. Imports occupy lines 1–2; namespace begins at 11 and ends at 331. There are no `variable`, `universe`, notation, instance, private, axiom, or structure declarations in this target. The two explicit equivalence constructors have implementation fields rather than separately authored declarations. All 37 authored declarations below are public; the table is a source inventory, not an elaborator-generated declaration list.

The full exact textual signatures and bodies are retained in the line-addressed transcript after the table. A signature span includes the declaration header through `:=` or `where`; body begins on that delimiter line or the next as shown. All implicit braces, explicit parentheses, dependent returns, attributes and proof scripts remain visible. No theorem binder was assigned a natural-source category.

| Fully qualified suffix | Kind | Whole span | Signature through | Body read |
| --- | --- | --- | --- | --- |
| `pad` | def | 14–16 | 14 | 15–16 |
| `padMatrix` | noncomputable def | 18–22 | 18–20 | 21–22 |
| `eval_pad` | theorem | 24–28 | 24–25 | 25–28 |
| `padMatrix_append` | theorem | 30–49 | 30–34 | 34–49 |
| `pad_ryCount` | theorem | 51–55 | 51–52 | 52–55 |
| `pad_cxCount` | theorem | 57–61 | 57–58 | 58–61 |
| `pad_gateCount` | theorem | 63–67 | 63–64 | 64–67 |
| `stageWires` | def | 70–87 | 70–70 | 70–87 |
| `stageWires_fresh` | theorem | 89–91 | 89–90 | 90–91 |
| `stageWires_bond` | theorem | 93–95 | 93–94 | 94–95 |
| `stageWires_basis` | theorem | 97–106 | 97–101 | 101–106 |
| `placeStage` | def | 108–110 | 108–109 | 109–110 |
| `placedMatrix` | noncomputable def | 112–115 | 112–114 | 114–115 |
| `eval_placeStage` | theorem | 117–120 | 117–118 | 118–120 |
| `placedMatrix_apply` | theorem | 122–128 | 122–126 | 126–128 |
| `placeStage_ryCount` | theorem | 130–131 | 130–131 | 131–131 |
| `placeStage_cxCount` | theorem | 133–134 | 133–134 | 134–134 |
| `placeStage_gateCount` | theorem | 136–138 | 136–137 | 137–138 |
| `assemble` | def | 141–144 | 141–142 | 143–144 |
| `assembledMatrix` | noncomputable def | 146–151 | 146–148 | 149–151 |
| `eval_assemble` | theorem | 153–159 | 153–154 | 154–159 |
| `assembledMatrix_clean_column` | theorem | 161–195 | 161–166 | 166–195 |
| `assemble_clean_column` | theorem | 199–206 | 199–205 | 205–206 |
| `run_boundary_decomposition` | theorem | 208–220 | 208–213 | 213–220 |
| `withInitial` | def | 224–226 | 224–225 | 225–226 |
| `withInitial_column` | theorem | 228–241 | 228–234 | 234–241 |
| `assemble_ryCount` | theorem | 243–249 | 243–244 | 244–249 |
| `assemble_cxCount` | theorem | 251–257 | 251–252 | 252–257 |
| `assemble_noOracle` | theorem | 259–260 | 259–260 | 260–260 |
| `withInitial_ryCount` | theorem | 262–266 | 262–265 | 265–266 |
| `withInitial_cxCount` | theorem | 268–272 | 268–271 | 271–272 |
| `withInitial_primitive_bound` | theorem | 274–285 | 274–278 | 278–285 |
| `outputWires` | def | 289–297 | 289–289 | 289–297 |
| `outputWires_basis` | theorem | 299–305 | 299–301 | 301–305 |
| `publicCircuit` | def | 309–311 | 309–310 | 310–311 |
| `publicCircuit_column` | theorem | 313–321 | 313–319 | 319–321 |
| `publicCircuit_primitive_bound` | theorem | 323–329 | 323–327 | 327–329 |

Each suffix expands under `QuantumBlockEncoding.SequentialPrimitiveAssembly`. Complete read transcript, lines 1–331 (line-number prefix is presentation only; source Unicode and comment-mask layout are retained; this transcript is not claimed as a byte-for-byte transport copy):

```lean
  1 | import QuantumBlockEncoding.PrimitiveWireRename
  2 | import QuantumBlockEncoding.SequentialBondPreparation
  3 | 
  4 |                                                                   
  5 |                                                             
  6 |                                                   
  7 |                                                                   
  8 |                                                                        
  9 |                                                                     
 10 | 
 11 | namespace QuantumBlockEncoding.SequentialPrimitiveAssembly
 12 | open RealAmplitudePreparation
 13 | 
 14 | def pad {m : Nat} (c : PrimitiveCircuit m) : (extra : Nat) → PrimitiveCircuit (m + extra)
 15 |   | 0 => c
 16 |   | extra + 1 => (pad c extra).map liftGate
 17 | 
 18 | noncomputable def padMatrix {m : Nat}
 19 |     (M : _root_.Matrix (PrimitiveBasis m) (PrimitiveBasis m) ℂ) :
 20 |     (extra : Nat) → _root_.Matrix (PrimitiveBasis (m + extra)) (PrimitiveBasis (m + extra)) ℂ
 21 |   | 0 => M
 22 |   | extra + 1 => liftLastMatrix (padMatrix M extra)
 23 | 
 24 | theorem eval_pad {m : Nat} (c : PrimitiveCircuit m) (extra : Nat) :
 25 |     evalPrimitiveCircuit (pad c extra) = padMatrix (evalPrimitiveCircuit c) extra := by
 26 |   induction extra with
 27 |   | zero => rfl
 28 |   | succ extra ih => rw [pad, eval_liftCircuit, ih]; rfl
 29 | 
 30 | theorem padMatrix_append {m : Nat}
 31 |     (M : _root_.Matrix (PrimitiveBasis m) (PrimitiveBasis m) ℂ)
 32 |     (t : Nat) (a b : PrimitiveBasis m) (x y : PrimitiveBasis t) :
 33 |     padMatrix M t (Fin.append a x) (Fin.append b y) =
 34 |       if x = y then M a b else 0 := by
 35 |   induction t with
 36 |   | zero =>
 37 |     have ha : Fin.append a x = a := by
 38 |       funext i
 39 |       simpa only [Fin.cast, Fin.castAdd, Fin.castLE] using Fin.append_left a x i
 40 |     have hb : Fin.append b y = b := by
 41 |       funext i
 42 |       simpa only [Fin.cast, Fin.castAdd, Fin.castLE] using Fin.append_left b y i
 43 |     rw [padMatrix, ha, hb, if_pos (Subsingleton.elim x y)]
 44 |   | succ t ih =>
 45 |     obtain ⟨⟨x, u⟩, rfl⟩ := (lastBasisEquiv t).symm.surjective x
 46 |     obtain ⟨⟨y, v⟩, rfl⟩ := (lastBasisEquiv t).symm.surjective y
 47 |     simp only [lastBasisEquiv_symm_apply, Fin.append_snoc, padMatrix,
 48 |       liftLastMatrix_apply, Fin.init_snoc, Fin.snoc_last, ih, Fin.snoc_inj]
 49 |     by_cases h : x = y <;> by_cases hv : u = v <;> simp [h, hv]
 50 | 
 51 | @[simp] theorem pad_ryCount {m : Nat} (c : PrimitiveCircuit m) (extra : Nat) :
 52 |     (pad c extra).ryCount = c.ryCount := by
 53 |   induction extra with
 54 |   | zero => rfl
 55 |   | succ extra ih => rw [pad, liftCircuit_ryCount, ih]
 56 | 
 57 | @[simp] theorem pad_cxCount {m : Nat} (c : PrimitiveCircuit m) (extra : Nat) :
 58 |     (pad c extra).cxCount = c.cxCount := by
 59 |   induction extra with
 60 |   | zero => rfl
 61 |   | succ extra ih => rw [pad, liftCircuit_cxCount, ih]
 62 | 
 63 | @[simp] theorem pad_gateCount {m : Nat} (c : PrimitiveCircuit m) (extra : Nat) :
 64 |     (pad c extra).gateCount = c.gateCount := by
 65 |   induction extra with
 66 |   | zero => rfl
 67 |   | succ extra ih => simpa [pad, PrimitiveCircuit.gateCount] using ih
 68 | 
 69 |                                                                                   
 70 | def stageWires (q t : Nat) : Fin ((q + 1) + t) ≃ Fin ((q + t) + 1) where
 71 |   toFun := Fin.addCases
 72 |     (Fin.lastCases (Fin.last (q + t)) (fun i => (Fin.castAdd t i).castSucc))
 73 |     (fun i => (Fin.natAdd q i).castSucc)
 74 |   invFun := Fin.lastCases (Fin.castAdd t (Fin.last q))
 75 |     (Fin.addCases (fun i => Fin.castAdd t i.castSucc) (Fin.natAdd (q + 1)))
 76 |   left_inv i := by
 77 |     refine Fin.addCases (fun i => ?_) (fun i => ?_) i
 78 |     · refine Fin.lastCases ?_ (fun i => ?_) i <;>
 79 |         simp only [Fin.addCases_left, Fin.lastCases_last,
 80 |           Fin.lastCases_castSucc]
 81 |     · simp only [Fin.addCases_right, Fin.lastCases_castSucc]
 82 |   right_inv i := by
 83 |     refine Fin.lastCases ?_ (fun i => ?_) i
 84 |     · simp only [Fin.addCases_left, Fin.lastCases_last]
 85 |     · refine Fin.addCases (fun i => ?_) (fun i => ?_) i <;>
 86 |         simp only [Fin.addCases_left, Fin.addCases_right,
 87 |           Fin.lastCases_castSucc]
 88 | 
 89 | @[simp] theorem stageWires_fresh (q t : Nat) :
 90 |     stageWires q t (Fin.castAdd t (Fin.last q)) = Fin.last (q + t) := by
 91 |   simp [stageWires]
 92 | 
 93 | theorem stageWires_bond (q t : Nat) (i : Fin q) :
 94 |     (stageWires q t (Fin.castAdd t i.castSucc)).val = i.val := by
 95 |   simp [stageWires]
 96 | 
 97 | theorem stageWires_basis (q t : Nat) (b : PrimitiveBasis q)
 98 |     (x : PrimitiveBasis t) (bit : Fin 2) :
 99 |     (fun w : Fin ((q + 1) + t) =>
100 |       (Fin.snoc (Fin.append b x) bit : PrimitiveBasis ((q + t) + 1)) (stageWires q t w)) =
101 |       Fin.append (Fin.snoc b bit) x := by
102 |   funext w
103 |   refine Fin.addCases (fun i => ?_) (fun i => ?_) w
104 |   · refine Fin.lastCases ?_ (fun i => ?_) i <;> simp [stageWires]
105 |   · simp only [stageWires, Equiv.coe_fn_mk, Fin.addCases_right,
106 |       Fin.snoc_castSucc, Fin.append_right]
107 | 
108 | def placeStage {q : Nat} (t : Nat) (c : PrimitiveCircuit (q + 1)) :
109 |     PrimitiveCircuit ((q + t) + 1) :=
110 |   PrimitiveWireRename.circuit (stageWires q t) (pad c t)
111 | 
112 | noncomputable def placedMatrix {q : Nat} (t : Nat)
113 |     (M : _root_.Matrix (PrimitiveBasis (q + 1)) (PrimitiveBasis (q + 1)) ℂ) :
114 |     _root_.Matrix (PrimitiveBasis ((q + t) + 1)) (PrimitiveBasis ((q + t) + 1)) ℂ :=
115 |   PrimitiveWireRename.matrix (stageWires q t) (padMatrix M t)
116 | 
117 | theorem eval_placeStage {q : Nat} (t : Nat) (c : PrimitiveCircuit (q + 1)) :
118 |     evalPrimitiveCircuit (placeStage t c) = placedMatrix t (evalPrimitiveCircuit c) := by
119 |   rw [placeStage, PrimitiveWireRename.eval_circuit, eval_pad]
120 |   rfl
121 | 
122 | theorem placedMatrix_apply {q : Nat} (t : Nat)
123 |     (M : _root_.Matrix (PrimitiveBasis (q + 1)) (PrimitiveBasis (q + 1)) ℂ)
124 |     (a b : PrimitiveBasis q) (x y : PrimitiveBasis t) (u v : Fin 2) :
125 |     placedMatrix t M (Fin.snoc (Fin.append a x) u) (Fin.snoc (Fin.append b y) v) =
126 |       if x = y then M (Fin.snoc a u) (Fin.snoc b v) else 0 := by
127 |   rw [placedMatrix, PrimitiveWireRename.matrix_apply, stageWires_basis,
128 |     stageWires_basis, padMatrix_append]
129 | 
130 | @[simp] theorem placeStage_ryCount {q : Nat} (t : Nat) (c : PrimitiveCircuit (q + 1)) :
131 |     (placeStage t c).ryCount = c.ryCount := by simp [placeStage]
132 | 
133 | @[simp] theorem placeStage_cxCount {q : Nat} (t : Nat) (c : PrimitiveCircuit (q + 1)) :
134 |     (placeStage t c).cxCount = c.cxCount := by simp [placeStage]
135 | 
136 | @[simp] theorem placeStage_gateCount {q : Nat} (t : Nat) (c : PrimitiveCircuit (q + 1)) :
137 |     (placeStage t c).gateCount = c.gateCount := by
138 |   simp only [placeStage, PrimitiveWireRename.gateCount, pad_gateCount]
139 | 
140 |                                                                                    
141 | def assemble (q : Nat) (stages : Nat → PrimitiveCircuit (q + 1)) :
142 |     (n : Nat) → PrimitiveCircuit (q + n)
143 |   | 0 => []
144 |   | n + 1 => (assemble q stages n).map liftGate ++ placeStage n (stages n)
145 | 
146 | noncomputable def assembledMatrix (q : Nat)
147 |     (stages : Nat → PrimitiveCircuit (q + 1)) :
148 |     (n : Nat) → _root_.Matrix (PrimitiveBasis (q + n)) (PrimitiveBasis (q + n)) ℂ
149 |   | 0 => 1
150 |   | n + 1 => placedMatrix n (evalPrimitiveCircuit (stages n)) *
151 |       liftLastMatrix (assembledMatrix q stages n)
152 | 
153 | theorem eval_assemble (q : Nat) (stages : Nat → PrimitiveCircuit (q + 1)) (n : Nat) :
154 |     evalPrimitiveCircuit (assemble q stages n) = assembledMatrix q stages n := by
155 |   induction n with
156 |   | zero => rfl
157 |   | succ n ih =>
158 |     rw [assemble, evalPrimitiveCircuit_append, eval_placeStage, eval_liftCircuit, ih]
159 |     rfl
160 | 
161 | theorem assembledMatrix_clean_column (q : Nat)
162 |     (stages : Nat → PrimitiveCircuit (q + 1)) (n : Nat)
163 |     (a b : PrimitiveBasis q) (x : PrimitiveBasis n) :
164 |     assembledMatrix q stages n (Fin.append b x) (Fin.append a (fun _ => 0)) =
165 |       SequentialBondPreparation.run (fun t => SequentialBondPreparation.circuitStage (stages t))
166 |         (SequentialBondPreparation.basisBoundary a) n (x, b) := by
167 |   classical
168 |   induction n generalizing b with
169 |   | zero =>
170 |     have hx : Fin.append b x = b := by
171 |       funext i
172 |       simpa only [Fin.cast, Fin.castAdd, Fin.castLE] using Fin.append_left b x i
173 |     have ha : Fin.append a (fun _ : Fin 0 => (0 : Fin 2)) = a := by
174 |       funext i
175 |       simpa only [Fin.cast, Fin.castAdd, Fin.castLE] using Fin.append_left a (fun _ => 0) i
176 |     simp [assembledMatrix, hx, ha, SequentialBondPreparation.run,
177 |       SequentialBondPreparation.basisBoundary, _root_.Matrix.one_apply]
178 |   | succ n ih =>
179 |     obtain ⟨⟨x, bit⟩, rfl⟩ := (lastBasisEquiv n).symm.surjective x
180 |     have hz : (fun _ : Fin (n + 1) => (0 : Fin 2)) = Fin.snoc (fun _ => 0) 0 := by
181 |       funext i
182 |       refine Fin.lastCases ?_ (fun i => ?_) i <;> simp
183 |     simp only [lastBasisEquiv_symm_apply, hz, Fin.append_snoc, assembledMatrix,
184 |       SequentialBondPreparation.run, SequentialBondPreparation.step_apply,
185 |       Fin.init_snoc, Fin.snoc_last, SequentialBondPreparation.circuitStage_apply]
186 |     rw [_root_.Matrix.mul_apply, ← (lastBasisEquiv (q + n)).symm.sum_comp]
187 |     simp only [Fintype.sum_prod_type, lastBasisEquiv_symm_apply, liftLastMatrix_apply,
188 |       Fin.init_snoc, Fin.snoc_last, mul_ite, mul_zero, Finset.sum_ite_eq',
189 |       Finset.mem_univ, if_true]
190 |     rw [← (Fin.appendEquiv q n).sum_comp]
191 |     simp only [Fin.appendEquiv, Equiv.coe_fn_mk, Fintype.sum_prod_type,
192 |       placedMatrix_apply, ite_mul, zero_mul, Finset.sum_ite_eq,
193 |       Finset.mem_univ, if_true]
194 |     simp only [ih]
195 |     simp [Fin.snoc]
196 | 
197 |                                                                           
198 |                                                                             
199 | theorem assemble_clean_column (q : Nat)
200 |     (stages : Nat → PrimitiveCircuit (q + 1)) (n : Nat)
201 |     (a b : PrimitiveBasis q) (x : PrimitiveBasis n) :
202 |     evalPrimitiveCircuit (assemble q stages n)
203 |         (Fin.append b x) (Fin.append a (fun _ => 0)) =
204 |       SequentialBondPreparation.run (fun t => SequentialBondPreparation.circuitStage (stages t))
205 |         (SequentialBondPreparation.basisBoundary a) n (x, b) := by
206 |   rw [eval_assemble, assembledMatrix_clean_column]
207 | 
208 | theorem run_boundary_decomposition {q : Nat}
209 |     (U : Nat → SequentialBondPreparation.Stage (PrimitiveBasis q))
210 |     (v : PrimitiveBasis q → ℂ) (n : Nat) (x : PrimitiveBasis n) (b : PrimitiveBasis q) :
211 |     SequentialBondPreparation.run U v n (x, b) =
212 |       ∑ a, SequentialBondPreparation.run U (SequentialBondPreparation.basisBoundary a)
213 |         n (x, b) * v a := by
214 |   classical
215 |   induction n generalizing b with
216 |   | zero => simp [SequentialBondPreparation.run, SequentialBondPreparation.basisBoundary]
217 |   | succ n ih =>
218 |     simp only [SequentialBondPreparation.run, SequentialBondPreparation.step_apply, ih,
219 |       Finset.mul_sum, Finset.sum_mul, mul_assoc]
220 |     exact Finset.sum_comm
221 | 
222 |                                                                             
223 |                                                                          
224 | def withInitial {q : Nat} (initial : PrimitiveCircuit q)
225 |     (stages : Nat → PrimitiveCircuit (q + 1)) (n : Nat) : PrimitiveCircuit (q + n) :=
226 |   pad initial n ++ assemble q stages n
227 | 
228 | theorem withInitial_column {q : Nat} (initial : PrimitiveCircuit q)
229 |     (stages : Nat → PrimitiveCircuit (q + 1)) (n : Nat)
230 |     (a b : PrimitiveBasis q) (x : PrimitiveBasis n) :
231 |     evalPrimitiveCircuit (withInitial initial stages n)
232 |         (Fin.append b x) (Fin.append a (fun _ => 0)) =
233 |       SequentialBondPreparation.run (fun t => SequentialBondPreparation.circuitStage (stages t))
234 |         (fun c => evalPrimitiveCircuit initial c a) n (x, b) := by
235 |   classical
236 |   rw [withInitial, evalPrimitiveCircuit_append, eval_pad, _root_.Matrix.mul_apply,
237 |     ← (Fin.appendEquiv q n).sum_comp]
238 |   simp only [Fin.appendEquiv, Equiv.coe_fn_mk, Fintype.sum_prod_type,
239 |     padMatrix_append, mul_ite, mul_zero, Finset.sum_ite_eq',
240 |     Finset.mem_univ, if_true, assemble_clean_column]
241 |   exact (run_boundary_decomposition _ _ n x b).symm
242 | 
243 | theorem assemble_ryCount (q : Nat) (stages : Nat → PrimitiveCircuit (q + 1)) (n : Nat) :
244 |     (assemble q stages n).ryCount = ∑ t ∈ Finset.range n, (stages t).ryCount := by
245 |   induction n with
246 |   | zero => simp [assemble, PrimitiveCircuit.ryCount]
247 |   | succ n ih =>
248 |     rw [assemble, PrimitiveCircuit.ryCount_append, liftCircuit_ryCount,
249 |       placeStage_ryCount, ih, Finset.sum_range_succ]
250 | 
251 | theorem assemble_cxCount (q : Nat) (stages : Nat → PrimitiveCircuit (q + 1)) (n : Nat) :
252 |     (assemble q stages n).cxCount = ∑ t ∈ Finset.range n, (stages t).cxCount := by
253 |   induction n with
254 |   | zero => simp [assemble, PrimitiveCircuit.cxCount]
255 |   | succ n ih =>
256 |     rw [assemble, PrimitiveCircuit.cxCount_append, liftCircuit_cxCount,
257 |       placeStage_cxCount, ih, Finset.sum_range_succ]
258 | 
259 | theorem assemble_noOracle (q : Nat) (stages : Nat → PrimitiveCircuit (q + 1)) (n : Nat) :
260 |     (assemble q stages n).resource.oracleCalls = 0 := rfl
261 | 
262 | theorem withInitial_ryCount {q : Nat} (initial : PrimitiveCircuit q)
263 |     (stages : Nat → PrimitiveCircuit (q + 1)) (n : Nat) :
264 |     (withInitial initial stages n).ryCount = initial.ryCount +
265 |       ∑ t ∈ Finset.range n, (stages t).ryCount := by
266 |   rw [withInitial, PrimitiveCircuit.ryCount_append, pad_ryCount, assemble_ryCount]
267 | 
268 | theorem withInitial_cxCount {q : Nat} (initial : PrimitiveCircuit q)
269 |     (stages : Nat → PrimitiveCircuit (q + 1)) (n : Nat) :
270 |     (withInitial initial stages n).cxCount = initial.cxCount +
271 |       ∑ t ∈ Finset.range n, (stages t).cxCount := by
272 |   rw [withInitial, PrimitiveCircuit.cxCount_append, pad_cxCount, assemble_cxCount]
273 | 
274 | theorem withInitial_primitive_bound {q : Nat} (initial : PrimitiveCircuit q)
275 |     (stages : Nat → PrimitiveCircuit (q + 1)) (n bound : Nat)
276 |     (h : ∀ t < n, (stages t).ryCount + (stages t).cxCount ≤ bound) :
277 |     (withInitial initial stages n).ryCount + (withInitial initial stages n).cxCount ≤
278 |       initial.ryCount + initial.cxCount + n * bound := by
279 |   rw [withInitial_ryCount, withInitial_cxCount]
280 |   have hs : (∑ t ∈ Finset.range n, ((stages t).ryCount + (stages t).cxCount)) ≤ n * bound := by
281 |     calc
282 |       _ ≤ ∑ _t ∈ Finset.range n, bound := Finset.sum_le_sum (fun t ht => h t (Finset.mem_range.mp ht))
283 |       _ = n * bound := by simp
284 |   rw [Finset.sum_add_distrib] at hs
285 |   omega
286 | 
287 |                                                                           
288 |                                                                                 
289 | def outputWires (q n : Nat) : Fin (q + n) ≃ Fin (n + q) where
290 |   toFun := Fin.addCases (Fin.natAdd n) (fun i => Fin.castAdd q i.rev)
291 |   invFun := Fin.addCases (fun i => Fin.natAdd q i.rev) (Fin.castAdd n)
292 |   left_inv i := by
293 |     refine Fin.addCases (fun i => ?_) (fun i => ?_) i <;>
294 |       simp only [Fin.addCases_left, Fin.addCases_right, Fin.rev_rev]
295 |   right_inv i := by
296 |     refine Fin.addCases (fun i => ?_) (fun i => ?_) i <;>
297 |       simp only [Fin.addCases_left, Fin.addCases_right, Fin.rev_rev]
298 | 
299 | theorem outputWires_basis (q n : Nat) (b : PrimitiveBasis q) (x : PrimitiveBasis n) :
300 |     (fun w => Fin.append x b (outputWires q n w)) =
301 |       Fin.append b (fun i => x i.rev) := by
302 |   funext w
303 |   refine Fin.addCases (fun i => ?_) (fun i => ?_) w <;>
304 |     simp only [outputWires, Equiv.coe_fn_mk, Fin.addCases_left,
305 |       Fin.addCases_right, Fin.append_left, Fin.append_right]
306 | 
307 |                                                                             
308 |                                                                                 
309 | def publicCircuit {q : Nat} (initial : PrimitiveCircuit q)
310 |     (stages : Nat → PrimitiveCircuit (q + 1)) (n : Nat) : PrimitiveCircuit (n + q) :=
311 |   PrimitiveWireRename.circuit (outputWires q n) (withInitial initial stages n)
312 | 
313 | theorem publicCircuit_column {q : Nat} (initial : PrimitiveCircuit q)
314 |     (stages : Nat → PrimitiveCircuit (q + 1)) (n : Nat)
315 |     (a b : PrimitiveBasis q) (x : PrimitiveBasis n) :
316 |     evalPrimitiveCircuit (publicCircuit initial stages n)
317 |         (Fin.append x b) (Fin.append (fun _ => 0) a) =
318 |       SequentialBondPreparation.run (fun t => SequentialBondPreparation.circuitStage (stages t))
319 |         (fun c => evalPrimitiveCircuit initial c a) n ((fun i => x i.rev), b) := by
320 |   rw [publicCircuit, PrimitiveWireRename.eval_circuit, PrimitiveWireRename.matrix_apply,
321 |     outputWires_basis, outputWires_basis, withInitial_column]
322 | 
323 | theorem publicCircuit_primitive_bound {q : Nat} (initial : PrimitiveCircuit q)
324 |     (stages : Nat → PrimitiveCircuit (q + 1)) (n bound : Nat)
325 |     (h : ∀ t < n, (stages t).ryCount + (stages t).cxCount ≤ bound) :
326 |     (publicCircuit initial stages n).ryCount + (publicCircuit initial stages n).cxCount ≤
327 |       initial.ryCount + initial.cxCount + n * bound := by
328 |   simp only [publicCircuit, PrimitiveWireRename.ryCount, PrimitiveWireRename.cxCount]
329 |   exact withInitial_primitive_bound initial stages n bound h
330 | 
331 | end QuantumBlockEncoding.SequentialPrimitiveAssembly
```

The declarations were read through their final bodies, including the private-helper absence, both equivalence inverse proofs, every zero case, the clean-column sum reductions, and the final conditional resource theorem at lines 323–329. Provider read positions and actual supporting references are in `dependencies.md` and `chronology-and-pins.json`.

