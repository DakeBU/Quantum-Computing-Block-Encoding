# Own initial whole-module formal derivation, before decoder

Reviewer: `/root/sequential_c51_raw_source_review`. Historical formalizer:
UNKNOWN. This file and declaration-coverage.tsv are written and hash-frozen
before opening the distinct formal decoder's reconstruction or inventory.
No author mapping or selected publication metadata was read.

## Inputs and provisional mathematical verdict

I read the entire masked target QuantumBlockEncoding/SequentialPrimitiveAssembly.lean,
331 lines through EOF, including all ten definitions and 27 theorem bodies.
Its snapshot SHA256 is
`02b062dcfa8f0faaa53fc69250e46230ca6107d2f038d73d95646dc0808bf23b`.
The formal packet declares raw-production association
`46c8c3aaa6d37a61dadc36dd7ef618b46f7667ffd91047f738b7c3efd40a4f55`;
I did not read the raw repository file or prove mask noninterference.
All 13 supplied packet snapshot digests and the supplied ComplexLCU snapshot
digest were verified. The recorded toolchain is leanprover/lean4:v4.33.0;
no Lean command or compiler was run.

My initial verdict is that every one of the 37 target declarations faithfully
implements or states the corresponding local retrospective source construction
or its routine internal consequence. No excess mathematical hypothesis, changed
gate/order/phase convention, or claim of a stronger target was found. This is
source-level interpretation of actual masked code, not a kernel certificate,
production-byte equality check, or publication acceptance. The source remains
the unchanged LOCAL retrospective source, not a historical pre-proof source.

## Actual provider definitions, not guessed names

PrimitiveCircuit is List(PrimitiveGate m), with X/RY/RZ valid targets and CX
distinct control/target. ExactAngle has the source's rational, pi-rational,
bounded twice-arccos rational/sqrt-rational, arbitrary real, addition, negation
and rational scaling constructors. The bounded constructors carry the actual
domain inequalities. eval evaluates exactly those expressions noncomputably;
this is not a finite-bit representation, evaluation-time or synthesis theorem.

PrimitiveBasis m is Fin m -> Fin 2. PrimitiveSemantics defines RY(theta) as
ComplexLCU.realRotation(theta/2). The requested supplement actually defines
realRotation(alpha)=realOrthogonalRotation(cos alpha,sin alpha), whose four
entries are cosine, negative sine, positive sine, cosine. Thus the signs and
half-angle are exactly the source's, not inferred from a familiar gate name.
RZ is diagonal cos(theta/2)-i sin(theta/2), cos(theta/2)+i sin(theta/2), equal
to the source exponentials by the ordinary complex Euler identity. The
one-qubit lift requires every other coordinate to agree. X updates its target
by flipBit; CX does so iff control is nonzero, equivalently bit 1 in Fin 2.
The supplement's equivPermutationMatrix has entry [row=equiv(column)], fixing
the action direction. E([])=1; E(g::rest)=E(rest)E(g), so concatenation applies
left list first and E(left++right)=E(right)E(left). No PrimitiveProgram global
phase field is used anywhere in the target: it operates on literal circuits.

RealAmplitudePreparation.lastBasisEquiv splits a word into its prefix and last
bit, with inverse Fin.snoc. liftLastMatrix is a reindex of M tensor I, with
kernel [last(row)=last(column)]M[init(row),init(column)]. liftGate applies
castSucc to each wire, retaining its integer index. eval_liftCircuit and
the two lift count proofs supply the target's padded-list recursion.

PrimitiveWireRename.basisEquiv e pushes a basis label by composing with e.symm,
and matrix reindexing therefore pulls BOTH row and column back by e. Its
gate/circuit definitions map the same e over every target and control, with
the CX distinctness proof transported by injectivity. matrix_apply says
literally M(row composed with e,column composed with e). Its product law and
gate induction supply eval_circuit, while its count proofs map one instruction
to the same kind. This is whole-program placement, not a SWAP circuit.

SequentialBondPreparation defines Stage B as a complex square matrix on
Fin 2 x B, not as a structure bundling hidden unitary or correctness proofs.
BondState n B is PrimitiveBasis n x B -> C. freshZero is nonzero only when
the fresh input bit equals 0. liftStage is I_old tensor U. step applies that
matrix to freshZero and regroups the last emitted bit. Its actual step_apply
is sum_a U[(newbit,b),(0,a)]v[prefix,a]. run starts at the arbitrary boundary
and recurses by step. basisBoundary a is [b=a]. localBasisEquiv swaps the
prefix/last-bit pair into (fresh,bond), and circuitStage is actual E(C)
reindexed by that equivalence, with entry E(C)[b dot u,a dot v]. This is a
coordinate convention, not an inserted physical swap.

Resource is an explicit record. PrimitiveCircuit.resource sets oracleCalls
to zero through ofCountsWithDepth; ryCount counts only .ry and cxCount only
.cx. gateCount is list length. X and RZ contribute to length/oneQubitCount,
not ryCount. The resource record's pureAncilla field zero is bookkeeping in
this constructor, not a proof that the source's bond is clean or that q=0.
The target only advertises the oracle field and selected counts, not that
record as a terminal-clean-ancilla theorem.

## Target construction and proof reconstruction

pad c extra recursively maps liftGate, leaving all original numeric wire
indices unchanged. padMatrix recursively appends an identity bit. eval_pad
follows by the provider lift-list theorem; padMatrix_append expands to
[x=y]M[a,b]. At extra=0, x,y are the unique empty functions, not absent basis
states. The three pad count theorems preserve RY, CX and length separately.
These are source S2 identities on every matrix entry and arbitrary M.

stageWires has three exhaustive cases: old bond i<q goes to i, old fresh q
goes to q+t, and temporary old-data q+1+j goes to q+j. Its actual inverse
reverses these cases. stageWires_fresh and stageWires_bond extract those
facts; stageWires_basis proves that (b|x) dot u pulls back to (b dot u)|x.
placeStage is precisely rename(stageWires,pad C t), and placedMatrix is the
same padding and reindexing at matrix level. Both boundary pullbacks yield

    placedMatrix t M[(a|x) dot u,(b|y) dot v]
      = [x=y]M[a dot u,b dot v].

Thus all old data is passive but the bond may change; a fixed bond wire
position is not a preserved bond state. The three placeStage counts add no
SWAP, oracle or routing charge in this all-to-all named-wire model.

assemble starts empty at q wires and at stage n lifts all earlier gates and
appends placeStage n (stages n). assembledMatrix starts at identity and
recurses by placed stage matrix times lifted previous matrix. Chronological
concatenation gives eval_assemble on the complete matrices, including dirty
data-input columns. This uses all entries of the actual stage matrices.

assembledMatrix_clean_column restricts the input only: arbitrary bond a,
data all zero. Every output word x and every bond b remains quantified.
At n=0 both sides are [b=a]. At a successor, split the output as x dot u
and intermediate basis as (c|y) dot v. liftLastMatrix forces v=0; the placed
stage kernel forces y=x. The product collapses to

    sum_c E(C_n)[b dot u,c dot 0] F_n[c|x,a|0_n],

which is the exact provider step recurrence after the induction hypothesis.
assemble_clean_column transfers this to the actual list using eval_assemble.
This does not replace a clean-column result by a full target-unitary equality.

run_boundary_decomposition is more general than circuit stages: U is ANY
family of complex Stage matrices. Its identity is linearity in arbitrary
complex v. At zero steps the delta sum returns v[b]; at a successor distribute
the two finite sums and commute them. No normalization, unitarity, positivity,
rank or nonzero hypothesis is introduced. This agrees with source equation (12).

withInitial is pad initial n ++ assemble, so initial J acts first. Multiplying
E(assemble) by padMatrix E(initial), passive data forces the intermediate word
to zero. The clean-column theorem plus boundary linearity leaves exactly run
with boundary c -> E(initial)[c,a], for EVERY input bond a. This does not
synthesize a circuit for an arbitrary external v, nor suppress J's cost.

assemble_ryCount/cxCount sum exactly over Finset.range n. assemble_noOracle is
definitionally the resource oracle field zero, not a statement about the cost
of producing inputs. withInitial count theorems add initial's actual counts.
The two primitive_bound theorems assume only h: forall t<n,
RY(stages t)+CX(stages t)<=bound, and conclude initial RY+CX plus n*bound.
The proof sums h over range n. No hypothesis for t>=n is present. No bound on
X/RZ length, depth, T count, classical generation, precision or routing follows.

outputWires maps original bond i to n+i and emitted bit q+t to n-1-t. Its
inverse is explicit, using Fin.rev_rev. outputWires_basis shows pullback of
x|b is b|rev(x). publicCircuit renames the ENTIRE withInitial circuit, not
only assembled stages or only final state labels. publicCircuit_column applies
the two-boundary matrix pullback to output x|b and input 0_n|a, yielding
run at (rev(x),b) with actual J column. This is literal equality with no
global-phase quotient or relative-phase loss. Public selected bound follows
from unchanged kinds under rename. The LE/MSB integer interpretation follows
from rev by a finite index substitution; it is not a separately named target
declaration. The supplied PrimitiveBasisLE recursion confirms wire 0 is the
least significant bit, but no target integer-value theorem is silently added.

## Complete binder/definition audit

The target namespace has no ambient variable, section variable, local instance,
axiom or project-owned contract bundle. Each signature supplies its own Nat
dimensions, actual circuits/family, arbitrary matrices, or basis labels. Finite
instances for the concrete Fin/function carriers are the ordinary typing
substrate, not extra source promises. q/m/n/t/extra, labels and valid carriers
are TYPING; actual initial/stages and arbitrary M/U/v are explicit SOURCE data
of the corresponding construction or general finite algebra. Chronology,
complex entries and exact phase are STANDING. The only non-typing mathematical
hypothesis is the h bound in the two conditional resource theorems, and it is
SOURCE. There is no RULED correction or EXCESS hypothesis found. All proof
ingredients occur in bodies/provider results, not as new theorem binders.

All ten target definitions are literal: pad, padMatrix, stageWires, placeStage,
placedMatrix, assemble, assembledMatrix, withInitial, outputWires, publicCircuit.
Equivalences have explicit inverses with proof fields; they are not arbitrary
chosen representatives or uniqueness/choice definitions. noncomputable matrices
do not imply any finite runtime statement. The arbitrary complex boundary is
not normalized by definition or hidden behind a default/zero fallback.

## Zero cases, stronger boundaries, and trust limits

All target dimensions are unrestricted Nat; no hidden positivity is in a
provider alias. PrimitiveBasis 0 has one empty function. At q=0 initial must
be empty, since PrimitiveGate 0 has no constructor with a valid target; C_t
is still a one-wire circuit. n=0 gives assemble=[], assembledMatrix=1,
withInitial=initial and the public equation reduces to E(initial)[b,a].
Both zero gives the scalar identity. An empty stage emits zero and preserves
bond by the exact circuitStage/step definitions. These are mathematical
specializations of the read definitions; no separate compiled regression is
claimed and no target theorem specifically named for each zero case exists.

The imported SequentialBondPreparation file contains conditional transfer,
support and terminal-cleanup theorems. They require compiler-column/core and
support/terminal inputs in their own statements and do not produce such inputs
for the target's arbitrary supplied stage family. None of the target's 37
declarations states that every bond output is clean, supplies an application
K_t/boundary/support supplier, identifies a particular target, proves a
Hermite family/rank bound, or constructs a finite-bit algorithm. The accepted
C55 source graph's unresolved stronger OR heads therefore remain unresolved.
Provider imports do not replace that source topology.

No essential semantic provider definition remains missing for these 37 target
claims. I requested/assumed no guessed rotation signs, permutation direction,
hidden oracle contract or uncharged initial state. A lexical scan of the target
finds no sorry/admit/axiom/unsafe/opaque token; this is not elaboration, axiom
closure auditing, mask noninterference or compiler acceptance. This own initial
interpretation is now ready to be frozen before the separate decoder read.
