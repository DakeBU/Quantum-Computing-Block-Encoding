# Whole-module independent source/formal comparison

Reviewer: `/root/sequential_c51_raw_source_review`.
Distinct decoder package identity: `agent:sequential_c53_formal_decoder`.
Retrospective mathematical source author:
`/root/sequential_assembly_c48_source_author`. Historical formalizer: UNKNOWN.
These roles are not interchangeable; no historical authorship or identity
proof is inferred from a retrospective source or an artifact identity string.

## Actual verdict and exact acceptance boundary

ACCEPTED_LOCAL_RETROSPECTIVE_SOURCE_FORMAL_SNAPSHOT_FIDELITY for the complete
37-declaration, 331-line masked target snapshot
`02b062dcfa8f0faaa53fc69250e46230ca6107d2f038d73d95646dc0808bf23b`,
interpreted with the actual necessary supplied provider definitions. No
source/formal mathematical mismatch or excess theorem premise was found.
The independent decoder agrees with the own interpretation frozen before
its reconstruction was read. No repair to source, target or decoder was needed.

This is NOT compilation, elaboration, axiom-closure or TCB acceptance. Raw
production digest `46c8c3aaa6d37a61dadc36dd7ef618b46f7667ffd91047f738b7c3efd40a4f55`
is the packet's declared association; I did not read that raw file or establish
comment-mask noninterference. This verdict does not certify the transport
procedure or infer raw-code equivalence beyond its provided association.
No exact selected metadata was released, no final wrapper is created, and
publication admission, main/PURIFIED status and historical pre-proof fidelity
are unassessed. The source is explicitly LOCAL retrospective.

## Independent order and actual materials

Stage 1 reconstructed the sole raw mathematical source before any graph or
formal input. Stage 2 rejected the original stronger-root topology. The
separately reviewed exact C55 successor restored source OR/support scope and
was accepted as source topology only. Those frozen records are unchanged.

For this stage I first read the formal-only packet and requested supplement,
then the whole target, the actual wire-renaming/list/angle semantics and
recurrence providers, padding providers, resource definitions and the requested
ComplexLCU definitions. All 13 packet snapshot digests and the supplement
provider digest matched. No omitted essential semantic provider remained.

I wrote initial-formal-derivation.md and all 37 declaration dispositions, then
froze them in initial-derivation-freeze.json before reading the decoder. The
initial freeze digest is
`7d371e4f5e61f3b1d4b7934da93087e94df7e3efb6bb92239fb8f40923ad93fe`.
Only afterward I read the decoder reconstruction, its public packet and whole
inventory through EOF. The reconstruction's supplied digest matched. All
37 names/order/spans agree with my independent inventory and every one of
its 331 transcript lines matches the actual target snapshot exactly.

No author audit/mapping, selected metadata, prior source/formal verdict,
withheld C55 rationale, unrelated review or production repository was read.
No Git, network, compiler, simulator or child agent was used.

## Mathematical correspondence, not just a theorem-name match

The actual angle and gate constructors match source S1, including arbitrary
exact reals and guarded arccos constructors. The requested realOrthogonalRotation
definition fixes the RY signs, realRotation fixes cos/sin substitution, and
standardRyMatrix divides its angle by two. The RZ trigonometric entries match
the source exponentials by complex Euler's identity. The permutation matrix
entry is [row=equiv(column)], with X/CX basis actions exactly as the source.
The chronological evaluator applies the first list element first. This gives
the SAME E(L++K)=E(K)E(L), not a reversed convention inferred from prose.

Padding repeatedly inserts an identity on the new highest wire, retaining
existing indices via castSucc. The target's exact kernel [x=y]M[a,b] follows
by splitting off each last bit; its proof handles empty passive words
explicitly. Wire placement pulls both row and column back by the same
bijection. At a local stage the three wire cases are precisely bond i->i,
fresh q->q+t, old-data q+1+j->q+j. Combining both pullbacks with padding gives

    Q_t(M)[(a|x) dot u,(b|y) dot v] = [x=y]M[a dot u,b dot v].

This proves passive old-data semantics on the whole stage matrix, not bond
invariance. Numeric bond positions remain fixed but their state may change.
No physical permutation/SWAP is inserted or charged in the named-wire model.

The actual assemble and assembledMatrix recurrences match source (7). The
proof of their complete matrix equality uses chronological append and actual
stage matrices, including every dirty-input column. The clean-column theorem
is a DIFFERENT assertion restricted to initial data zero and arbitrary initial
bond a. In its successor multiplication the lifted prefix forces fresh input
v=0 and the stage kernel forces old-data word y=x. The remaining sum is exactly
the provider's actual step recurrence with coefficient E(C_t)[b dot u,c dot 0].
Every output x and b remains quantified; no nonzero bond sector is discarded.

The provider's Stage is an ordinary square complex matrix on bit x bond, and
run/basisBoundary are literal finite recurrences. run_boundary_decomposition
holds for ANY such Stage family and arbitrary complex v, not just unitary or
normalized inputs. Its proof distributes and interchanges finite sums. It
does not assert that v is a physically supplied initial preparation circuit.

withInitial applies padded J first. The matrix product then collapses its
passive intermediate data word to zero and uses boundary linearity, leaving
v_a(c)=E(J)[c,a]. Thus the source's actual-J boundary is present for every a,
not silently a=0, an assumed arbitrary normalized vector, or a free state.

The final outputWires shifts bond wires after data and reverses emitted data.
Its pullback is (x|b) composed with o = b|rev(x). publicCircuit renames the
ENTIRE initial-plus-stages list. publicCircuit_column applies the pullback
to both output x|b and input 0_n|a, and matches source (18) exactly, including
the reversal and actual-J column. No quotient by global phase, separate phase
wrapper or label-dependent phase erasure appears. The source's MSB/LE integer
interpretation is the finite reindexing corollary of rev; the target does not
declare a separate integer-indexed matrix or integer-value theorem, and this
review does not invent one. Its actual bit-level adapter is faithful.

The two selected counts separately sum over range n. Initial J contributes
its own counts, and public placement preserves them. The only logical bound
premise is forall t<n, ryCount(C_t)+cxCount(C_t)<=bound, exactly the source's
conditional promise for used stages. X/RZ remain legal and unbounded by this
premise. The target proves length invariance for pad/placeStage, not a total
G bound from the selected count bound. assemble_noOracle reads the actual
resource field zero; no list/angle generation, precision, runtime, depth,
Clifford+T, connectivity or external oracle implementation theorem is inferred.

## Whole-module binders, definitions and edge cases

All 37 public authored declarations were individually compared, including
all signatures and proof/definition bodies. There are ten literal definitions
and 27 theorems, no private authored declaration or ambient variable/instance/
contract bundle in this target. The two equivalence objects have explicit
toFun/invFun and proof fields, not hidden choice or representative selection.
Provider aliases expand to explicit matrices, bit-function carriers and
finite-list data. The only theorem input with substantive logical content is
the same source h bound in the two resource-bound statements. No support,
normalization, circuit correctness, terminal cleanup, PREPARE/SELECT or other
proof ingredient was promoted to a convenient public binder.

All dimensions are arbitrary Nat. B_0 is the singleton empty-function carrier;
PrimitiveGate 0 has no valid constructor and initial J is necessarily empty
at q=0. Stages then still act on one fresh wire. At n=0 assemble is empty,
assembledMatrix identity, withInitial=J and outputWires fixes bond indices;
the public column formula becomes E(J)[b,a]. Both zero gives the one-by-one
identity. An empty stage has identity matrix, emits zero and preserves bond.
These edge cases are source-level specializations of the read definitions,
not separately executed or compiled test claims. No positivity/rank/nonzero
fallback changes off-locus semantics.

## Decoder comparison and unresolved stronger roots

The decoder's mathematical reconstruction agrees across all seven semantic
slots, declaration signatures and bodies, all ten definitions, ambient scope
and h binders. Its bit/bond pair convention, both boundary pullbacks, initial
J, public reversal, all-output-b quantifiers and selected-versus-total resource
distinction agree with my pre-decoder derivation. It correctly refuses to
classify source assumptions or claim source correspondence; those were my
later independent comparison responsibilities. Its source/compilation unknowns
are not adverse mathematical findings and are not silently marked proved here.

The accepted source graph's stronger OR routes stay UNRESOLVED. Imported
conditional transfer/cleanup lemmas are provider context, not suppliers of
local compiler columns, active support, initial application boundary or
terminal zero/surviving target identities for arbitrary stages. They do not
close application tensor contraction, specified target full operator, final
clean bond, Hermite family/rank/compiler or finite-bit/hardware resource roots.
The initial bond remains retained, not implicitly erased. Neither independent
interpretation upgrades clean INPUT zero to postselected success or clean
OUTPUT bond. The original source-topology rejection is not erased by this
later successor/formal snapshot fidelity result.

Failure class: NONE within the authorized source/formal snapshot comparison.
No mathematical correction or salvage of a rejected implementation is needed.
Residual non-acceptance layers: raw-mask transport, compiler/elaboration/axiom
closure, exact selected metadata and publication lifecycle. Process-memory
IDs: none. No new agents. Canonical-library/novelty/purification assessments:
not performed. This report provides bounded evidence for parent reconciliation;
stop after the genuine whole-module review seal, with no final admission wrapper.
