# Independent Stage 2 source-topology review

Reviewer: Codex worker `/root/sequential_c51_raw_source_review`.
Source author: `/root/sequential_assembly_c48_source_author` as disclosed in the
source. Historical formalizer: UNKNOWN, not inferred from retrospective authorship.
No decoder, formal comparison or metadata admission is claimed.

## Actual verdict

NEEDS_TOPOLOGY_REVISION; STOP_BEFORE_FORMAL.

The LOCAL retrospective source mathematics remains RECOVERABLE under my frozen
Stage 1 derivation. The author's source-region inventory faithfully captures
all substantive source text, and its section-level dependency DAG follows the
main supplied-list assembly. However, the exact proposed topology does not
faithfully preserve the source's alternative stronger-root proof pathways or
the conditional scope of active-support obligations. These are topology
findings, not a refutation of assembly mathematics or an implementation failure.
The current authorization requires stopping after a substantive topology issue;
therefore I did not read any formal packet, supplement, decoder output, author
audit, catalog addendum, selected publication row or production Lean.

## Frozen comparison inputs

The sole source is W/sequential-assembly-c48-author/SOURCE.md,
SHA256 `583cc9333ea977ec6684313749b6f52b49aded53e50456913f065487cada426a`.
The new comparison input is W/sequential-assembly-c48-author/source-graph.json,
SHA256 `ffb1b18419c2f340baa76b0ded4ceb5f0fcc3c25a18da03b1d87d8d7c2eff805`.
My source-first baseline is W/sequential-c51-raw-source-review, whose seal is
`8bec8f6db81825bde182d33a0c82e29931f83f51662a9123c50d87e3f5066045`
and manifest is `4789395f2eed72ecda52b3d8d17e0a163dc366946f35bbb9074e0d8be176a6e2`.
The original nine files remain unchanged and hash-verified.

## Coverage and primary construction: recovered

I read the entire author graph. Its 71 coverage records cover all 274 nonblank
source lines, including every displayed formula and substantive paragraph. The
records' stored texts match their source slices, and all 71 UTF-8 text digests
match. No omitted substantive region or overlapping coverage region was found.
Blank separator lines are not assigned records; this is not a mathematical
coverage defect. The final record ends at 345 because splitting the LF-terminated
source retains an empty terminal sentinel; ordinary file-line count is 344.
Its final stored text includes that trailing newline. This is an explainable
line-accounting convention, not a missing mathematical source line.

Section nodes S0 through S9 compress multiple definitions and proof steps.
Their section identities and tails are intelligible by source-section labels;
the region-level coverage preserves drill-down text. My finer baseline graph
separates padding, both placement pullbacks, full actual-matrix induction,
clean-column induction, linearity, initial J, counts and output order. The
author's coarser grouping does not by itself falsify the construction.

S0 preserves the actual-list input contract, legal zero cases, and absence of
target/core/free-initial-state assumptions. S1 retains finite complex carriers,
literal gate kernels, chronology and phase; unitarity is a consequence rather
than an extra theorem premise. S2 contains both padding and bijection transport,
including both boundary labels and no free physical routing. S3 retains the
temporary bond/fresh/old order and final passive-old-data kernel. S4 constructs
the full actual-stage matrix, not an operator determined by clean columns.
S5 derives all output amplitudes only on clean data-input columns and proves
linearity for arbitrary boundary. S6 uses the actual J column. S7 includes J
in the selected counts, bounds only used stages, and excludes total/depth and
finite-bit conclusions. S8 transforms the whole circuit and both boundaries,
with exact reversal and unchanged counts; it does not clean the final bond.
S9 faithfully inventories degeneracies and stronger-root warnings. The
section tails are broad, sometimes carrying more of a section than a specific
subclaim needs, but do not introduce a false single-input implication for the
established supplied-list assembly route.

## Blocking finding T2-01: omitted OR at the full-target boundary

Source lines 333-335 state two ways to justify the stronger full-target-operator
root: verify the remaining nonzero-data-input columns OR give a sufficient
independent full-operator argument. This alternative was already explicit in
my Stage 1 graph, before seeing the author's graph: the TARGET_FULL_OPERATOR
head has the routes `all-columns` and `independent-operator-proof`.

The author's `gap:full-target-unitary` has only the complete tail

    clean-sector equality
    AND specified and verified remaining data-input columns.

Its `or_alternatives` is empty. Its explanation that there is a single
supplied-list assembly route is correct for the established assembly root but
does not record the explicit alternative in the stronger-root boundary it
also purports to inventory. An independent operator proof is not an already
proved alternate circuit, but it IS an explicitly permitted sufficient route
to this stronger head. Marking both routes unresolved preserves that fact
without asserting that either supplier has been delivered.

The distinction has mathematical information content. One may prove an
operator identity through algebraic composition or a structural uniqueness
argument without enumerating its dirty-input columns individually. That proof
implies their equality as a consequence; this does not make a column-enumeration
proof obligation its actual dependency path. Source topology must preserve
the allowed proof route rather than replace it by a logically consequential
but structurally different route. The proposed graph therefore needs an OR
group at this unproved boundary, not a promotion of either path to proved.

## Blocking finding T2-02: conditional support flattened into unconditional AND

Source lines 323-327 require local clean-column/core identification and an
initial-boundary identity. They impose initial support and preservation of
support additionally IF local identification holds only on an active bond set.
The author's `gap:target-contraction` places all four ingredients in one
unqualified AND tail, with no full-clean-column route or active-set condition.

This loses the source's domain-sensitive fork. If every relevant local clean
column is identified on the whole bond carrier, finite recurrence substitution
plus initial-boundary identity suffices: each term of the finite sum can be
replaced directly, and no restricted-support invariant is needed. If the
identifications are only on active labels, support is essential so that
unidentified terms cannot contribute. My frozen Stage 1 graph already records
both routes, with the support tail only on the restricted route.

A precise revision could make the active set the entire carrier and explicitly
derive trivial support facts, or retain separate full-domain and restricted
routes. The current tail does neither; it simply presents the conditional
obligations as universal prerequisites. This overstates the proof dependencies
for the stronger application root even though that root remains unproved.
No source change or new theorem premise is needed to fix the topology.

## Other stronger boundaries: no false closure, but retain exact meanings

The five author `source_gaps` are explicitly unproved stronger applications.
They are not missing bridges in the proved local assembly roots. The finite-bit
and Hermite tails do not constitute delivered suppliers, and the graph does
not pretend otherwise. I do not interpret their high-level wording as full
future theorem signatures or complete cost contracts.

The terminal-cleanup tail names an identified run, occupied-subspace column
semantics, terminal support and target identity. Its broad semantic phrase
should expand to the literal condition R_n(v_a)[x,b]=0 for every non-clean b
and the surviving-amplitude identity from source 327-328. I record this as
a precision recommendation, not a separate proven false tail: the undefined
phrase could intend that stronger property. Merely preserving old data or
naming terminal support does not independently prove it. The source's warning
about incompatible all-padded-column prescriptions remains necessary.

The exact RY+CX h promise is present in region 054 and source 253-254 even
though no separate h node appears in the coarse section DAG. This is acceptable
only with lossless section drill-down; it is not permission to infer the bound
for arbitrary stages, omit J, or promote it to total G or finite-bit cost.

## Disposition and minimal next action

Failure class: SOURCE_INVALID for this exact proposed source-topology artifact
only (T2-01 and T2-02); the pinned source theorem is not declared invalid.
Salvage: source-region coverage, exact text/hash bindings, the established
section-level assembly DAG and all Stage 1 mathematical derivations remain
usable. No production or formal reusable-node acceptance has been performed.

Recommended next action: revise only the topology's stronger-root alternatives
and support scoping, keep those suppliers unproved, pin a successor graph, and
obtain the necessary source-topology re-review before authorizing a new formal
comparison. I do not modify the author's files or silently replace the pinned
graph with my own. No Stage 3 output directory or formal review is created.
No final wrapper, main admission, historical-formalizer attribution, Hermite
closure, or PURIFIED state is authorized by this report.
