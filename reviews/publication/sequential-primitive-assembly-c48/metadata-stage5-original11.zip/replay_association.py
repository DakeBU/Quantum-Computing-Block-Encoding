"""Read-only, bounded evidence replay; not a Lean parser/compiler or TCB proof.

Arguments are repository root and workspace root. Output uses logical paths only.
The checker functions are extracted verbatim by AST without executing its CLI.
Missing lesson and source registry entry are streamed from exact selected inputs.
"""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path, PurePosixPath, PureWindowsPath
import sys
from typing import Any


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def comment_projection(text: str) -> tuple[str, int]:
    """Observed-input projection only; general Lean lexical correctness unproved."""
    out: list[str] = []
    i = 0
    segments = 0
    while i < len(text):
        if text.startswith('/-', i):
            segments += 1
            depth = 1
            start = i
            i += 2
            while depth:
                if i >= len(text):
                    raise ValueError('Unclosed observed block comment')
                if text.startswith('/-', i):
                    depth += 1
                    i += 2
                elif text.startswith('-/', i):
                    depth -= 1
                    i += 2
                else:
                    i += 1
            out.extend(c if c == '\n' else ' ' * (len(c.encode('utf-16-le')) // 2)
                       for c in text[start:i])
        elif text.startswith('--', i):
            segments += 1
            end = text.find('\n', i)
            if end < 0:
                end = len(text)
            out.extend(' ' * (len(c.encode('utf-16-le')) // 2) for c in text[i:end])
            i = end
        elif text[i] in ('"', '«'):
            end_char = '"' if text[i] == '"' else '»'
            start = i
            i += 1
            while i < len(text):
                if text[i] == '\\' and end_char == '"':
                    i += 2
                elif text[i] == end_char:
                    i += 1
                    break
                else:
                    i += 1
            out.append(text[start:i])
        else:
            out.append(text[i])
            i += 1
    return ''.join(out), segments


def main() -> None:
    repository = Path(sys.argv[1]).resolve()
    workspace = Path(sys.argv[2]).resolve()
    selected_dir = workspace / 'c63-sequential-selected-final-review'
    control = json.loads((selected_dir / 'review-control.json').read_text(encoding='utf-8'))
    selected_bytes = (selected_dir / 'selected-record.json').read_bytes()
    source_row_bytes = (selected_dir / 'selected-source-row.json').read_bytes()
    assert sha(selected_bytes) == control['selected_record_sha256']
    assert sha(source_row_bytes) == control['selected_source_row_sha256']
    record = json.loads(selected_bytes)
    source_row = json.loads(source_row_bytes)
    lesson_bytes = (workspace / 'sequential-assembly-c48-author/SOURCE.md').read_bytes()
    assert sha(lesson_bytes) == control['exact_source_sha256']

    pin_bytes = (workspace / 'c54-selected-publication-freeze/raw-context-pins.json').read_bytes()
    assert sha(pin_bytes) == control['raw_context_pins_sha256']
    pins = json.loads(pin_bytes)['files']
    for item in pins:
        data = (repository / item['path']).read_bytes()
        assert sha(data) == item['sha256'] and len(data) == item['bytes'], item['path']

    formal_dir = workspace / 'sequential-c53-formal-input'
    supplement_dir = workspace / 'sequential-c53-formal-supplement'
    associations = []
    for packet_dir, packet_name in ((formal_dir, 'formal-inputs.json'),
                                    (supplement_dir, 'formal-supplement.json')):
        packet = json.loads((packet_dir / packet_name).read_text(encoding='utf-8'))
        for item in packet['inputs']:
            raw = (repository / item['path']).read_bytes()
            snapshot = (packet_dir / item['path']).read_bytes()
            assert sha(raw) == item['production_raw_sha256'], item['path']
            assert sha(snapshot) == item['formal_snapshot_sha256'], item['path']
            if item['path'].endswith('.lean'):
                raw_text = raw.decode('utf-8').replace('\r\n', '\n').replace('\r', '\n')
                projected, segments = comment_projection(raw_text)
                assert projected.encode('utf-8') == snapshot, item['path']
                relation = 'Observed comment-space projection exactly equals frozen snapshot'
            else:
                assert raw == snapshot, item['path']
                relation = 'Raw bytes identical to frozen snapshot'
                segments = 0
            associations.append({'path': 'R/' + item['path'], 'raw_sha256': sha(raw),
                                 'snapshot_sha256': sha(snapshot), 'comment_segments': segments,
                                 'relation': relation})

    checker_path = repository / 'website/scripts/check_research_publications.py'
    checker_bytes = checker_path.read_bytes()
    checker_text = checker_bytes.decode('utf-8')
    tree = ast.parse(checker_text)
    names = {'local_file', 'load', 'binding_digest'}
    functions = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
    assert {n.name for n in functions} == names
    namespace = {'Path': Path, 'PurePosixPath': PurePosixPath,
                 'PureWindowsPath': PureWindowsPath, 'Any': Any,
                 'json': json, 'hashlib': hashlib}
    exec(compile(ast.Module(body=functions, type_ignores=[]), '<three-reviewed-checker-functions>', 'exec'), namespace)
    actual_local_file = namespace['local_file']
    actual_load = namespace['load']

    class StreamedLesson:
        def read_bytes(self) -> bytes:
            return lesson_bytes

    def overlay_local_file(root: Path, name: str):
        if name == record['lesson_path']:
            return StreamedLesson()
        return actual_local_file(root, name)

    def overlay_load(root: Path, name: str):
        if name == 'website/research/sources.json':
            return {'sources': [source_row]}
        return actual_load(root, name)

    namespace['local_file'] = overlay_local_file
    namespace['load'] = overlay_load
    binding = namespace['binding_digest'](repository, record)
    assert binding == record['binding_sha256']

    keys = ('module', 'source_id', 'source_statement', 'source_anchor', 'lesson_path',
            'declarations', 'obligation_map', 'assumption_deltas', 'graph_contribution',
            'formalizer', 'residual_boundary')
    digest = hashlib.sha256(json.dumps({k: record.get(k) for k in keys},
                                      sort_keys=True, ensure_ascii=False).encode())
    ordered_inputs = []
    for name in (record['module'], record['lesson_path'], 'lean-toolchain', 'lake-manifest.json'):
        data = lesson_bytes if name == record['lesson_path'] else (repository / name).read_bytes()
        digest.update(name.encode())
        digest.update(data)
        ordered_inputs.append({'path': 'R/' + name, 'sha256': sha(data),
                               'streamed_missing_lesson': name == record['lesson_path']})
    directory_count = 0
    for directory in ('QuantumBlockEncoding', 'ABEISTests'):
        for path in sorted((repository / directory).rglob('*.lean')):
            name = path.relative_to(repository).as_posix()
            digest.update(name.encode())
            digest.update(path.read_bytes())
            directory_count += 1
    digest.update(json.dumps(source_row, sort_keys=True, ensure_ascii=False).encode())
    assert digest.hexdigest() == binding

    wrapper_path = repository / control['decoder_wrapper']
    wrapper_data = wrapper_path.read_bytes()
    assert sha(wrapper_data) == control['decoder_wrapper_sha256']
    wrapper = json.loads(wrapper_data)
    assert wrapper['binding_sha256'] == binding
    for path_key, hash_key in (('packet_path', 'packet_sha256'), ('artifact_path', 'artifact_sha256')):
        assert sha((repository / wrapper[path_key]).read_bytes()) == wrapper[hash_key]
    assert (repository / wrapper['packet_path']).read_bytes() == (workspace / 'sequential-c53-formal-decoder/public-packet.json').read_bytes()
    assert (repository / wrapper['artifact_path']).read_bytes() == (workspace / 'sequential-c53-formal-decoder/reconstruction.md').read_bytes()
    print(json.dumps({
        'status': 'PASS_BOUNDED_RAW_ASSOCIATION_AND_EXACT_BINDING_REPLAY',
        'binding_sha256': binding,
        'raw_context_files_hash_and_size_verified': len(pins),
        'sorted_directory_lean_files_bound': directory_count,
        'all_fourteen_formal_raw_associations': associations,
        'checker_sha256': sha(checker_bytes),
        'checker_function_mode': 'Only exact AST function bodies local_file/load/binding_digest executed; no checker CLI/Git/compiler',
        'canonical_json': 'sort_keys=True, ensure_ascii=False, DEFAULT separators',
        'binding_direct_inputs': ordered_inputs,
        'exact_selected_source_object_sha256': sha(source_row_bytes),
        'source_object_canonical_json_sha256': sha(json.dumps(source_row, sort_keys=True, ensure_ascii=False).encode()),
        'decoder_wrapper_sha256': sha(wrapper_data),
        'decoder_R_copies_byte_identical_to_actual_W_originals': True,
        'lakefile': 'Separately hash-pinned; not directly included by binding_digest',
        'transport_limit': 'Observed actual files compared; no general Lean lexer/mask/compiler/TCB noninterference theorem',
        'writes': 'None; result emitted on stdout only'
    }, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
