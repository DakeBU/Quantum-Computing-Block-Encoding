"""Versioned test-only repair. NO Lean invocation or kernel-proof claim."""
import copy
import importlib.util
import json
from pathlib import Path
import sys
import unittest
from fractions import Fraction

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('kernel_only', HERE / 'kernel_only.py')
K = importlib.util.module_from_spec(spec); spec.loader.exec_module(K)

class StaticTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original = (HERE / 'original/CubicStatePreparation.lean').read_bytes()
        cls.candidate = (HERE / 'candidate/CubicStatePreparation.lean').read_bytes()

    def test_exact_nine_token_delta(self):
        result = K.verify_exact_delta(self.original, self.candidate)
        self.assertEqual(len(result['exactTokenEdits']), 9)
        self.assertTrue(result['allOtherBytesIdentical'])

    def test_original_hash_refused(self):
        with self.assertRaisesRegex(ValueError, 'RESEAL original raw source mismatch'):
            K.mechanically_patch(self.original + b'\n')

    def test_nonproof_change_refused(self):
        mutated = self.candidate.replace(b'(397 : Rat)', b'(398 : Rat)')
        self.assertNotEqual(mutated, self.candidate)
        with self.assertRaisesRegex(ValueError, 'candidate differs outside nine exact tactic-token replacements'):
            K.verify_exact_delta(self.original, mutated)

    def test_partial_replacement_refused(self):
        mutated = self.candidate.replace(b'decide +kernel', b'native_decide', 1)
        self.assertNotEqual(mutated, self.candidate)
        with self.assertRaisesRegex(ValueError, 'candidate differs outside nine exact tactic-token replacements'):
            K.verify_exact_delta(self.original, mutated)

    def test_newline_rewrite_refused(self):
        self.assertNotIn(b'\r\n', self.candidate)
        self.assertIn(b'\n', self.candidate)
        mutated = self.candidate.replace(b'\n', b'\r\n')
        self.assertNotEqual(mutated, self.candidate)
        with self.assertRaisesRegex(ValueError, 'candidate differs outside nine exact tactic-token replacements'):
            K.verify_exact_delta(self.original, mutated)

    def test_old_source_unchanged(self):
        self.assertEqual(K.digest(self.original), K.ORIGINAL_SHA)

    def test_all_native_tokens_removed(self):
        self.assertNotIn(b'native_decide', self.candidate)
        self.assertEqual(self.candidate.count(b'decide +kernel'), 8)
        self.assertIn(b'have hzero : (0 : Rat) - 0 = 0 := by exact Rat.sub_self', self.candidate)

    def test_static_package_pins(self):
        self.assertTrue(K.static_check()['allOtherBytesIdentical'])

    def test_fraction_discriminator_not_lean_proof(self):
        expected = [Fraction(1, 64), Fraction(397, 2048), Fraction(46205, 65536)]
        self.assertEqual([sum((Fraction(j, 2**n)**6 for j in range(2**n)), Fraction(0))
                          for n in (1, 2, 3)], expected)

    def test_linux_gate_pass(self):
        gate = K.linux_resource_gate(HERE, 'MemAvailable: 5242880 kB\nSwapFree: 2097152 kB\n', 9 * 2**30)
        self.assertTrue(gate['gatePassed'])

    def test_linux_gate_low_memory_no_lean(self):
        for text, free in [('MemAvailable: 3145728 kB\nSwapFree: 4194304 kB\n', 9 * 2**30),
                           ('MemAvailable: 5242880 kB\nSwapFree: 0 kB\n', 9 * 2**30),
                           ('MemAvailable: 5242880 kB\nSwapFree: 2097152 kB\n', 7 * 2**30)]:
            self.assertFalse(K.linux_resource_gate(HERE, text, free)['gatePassed'])

    def test_linux_gate_missing_measurement(self):
        with self.assertRaisesRegex(ValueError, 'Linux available memory/swap measurement missing'):
            K.linux_resource_gate(HERE, 'MemFree: 99999999 kB\n', 9 * 2**30)

class ValidatorTests(unittest.TestCase):
    observations = []
    @classmethod
    def setUpClass(cls):
        cls.baseline = json.loads((HERE / 'baseline-observations.json').read_text(encoding='utf-8'))
        cls.expected = json.loads((HERE / 'vendor/expected-roots.json').read_text(encoding='utf-8'))
        cls.old_records = json.loads((HERE / 'tests-input/actual-ci3-records-without-values.json').read_text(encoding='utf-8'))

    @classmethod
    def tearDownClass(cls):
        with (HERE / 'tests-private/guard-rejections.json').open('x', encoding='utf-8', newline='\n') as f:
            json.dump(dict(scope='SYNTHETIC_INSTRUMENTATION_ONLY_NOT_LEAN_PROOF',
                           observations=cls.observations), f, indent=2)
            f.write('\n')

    def fixture(self):
        r = copy.deepcopy(self.old_records)
        removed = set(self.baseline['removedNativeAxioms'])
        r['C29_GENERATED_JSON'] = [row for row in r['C29_GENERATED_JSON'] if row['actualName'] not in removed]
        for row in r['C29_ROOT_JSON'] + r['C29_GENERATED_JSON']:
            row['axioms'] = [a for a in row['axioms'] if a not in removed]
            if row['actualHasValueAllowOpaque']:
                row['valuePrettyExplicitAllowOpaque'] = 'SYNTHETIC_VALUE_VALIDATOR_TEST_ONLY'
            else:
                row['valuePrettyExplicitAllowOpaque'] = None
        n = len(r['C29_GENERATED_JSON'])
        r['C29_BINDING_JSON'][0]['observedTargetOwnedConstants'] = 319 + n
        s = r['C29_SUMMARY_JSON'][0]
        s['generatedTargetOwnedConstants'] = n
        s['observedTargetOwnedConstants'] = 319 + n
        s['generatedTypeValueAxiomAuditCompleted'] = n
        return r

    def setUp(self):
        # Every negative starts from a fixture that has actually traversed ALL
        # relational checks and returned the terminal diagnostic, not a stub.
        self.valid_fixture = self.fixture()
        self.positive_result = self.checked(self.valid_fixture)
        self.assertEqual(self.positive_result['status'], 'RELATIONAL_KERNEL_SUBSTITUTION_DIAGNOSTIC_NOT_ACCEPTANCE')
        self.assertEqual(self.positive_result['explicitRoots'], 319)
        self.assertEqual(self.positive_result['generatedObserved'], 441)
        self.assertTrue(self.positive_result['capturedSignatureTextCompared'])

    def stream(self, records):
        return '\n'.join(tag + ' ' + json.dumps(row) for tag, rows in records.items() for row in rows)

    def checked(self, records, exit_code=0):
        return K.validate_changed(self.expected, self.stream(records), exit_code, self.baseline)

    def reject(self, records, pattern, exit_code=0):
        with self.assertRaisesRegex(ValueError, pattern) as caught:
            self.checked(records, exit_code)
        self.observations.append(dict(test=self._testMethodName, expectedErrorRegex=pattern,
            actualError=str(caught.exception), baselineFullRelationalPositiveCompleted=True))

    def test_synthetic_validator_positive_not_lean(self):
        self.assertEqual(self.positive_result['additionalGeneratedTheorems'], [])
        self.assertEqual(self.positive_result['removedNativeAxiomsAbsent'], self.baseline['removedNativeAxioms'])
        self.assertEqual(set(self.positive_result['newRecursiveAxiomUnion']),
                         set(self.baseline['allRecursiveAxioms']) - set(self.baseline['removedNativeAxioms']))
        self.assertIsNone(self.positive_result['axiomPolicyPass'])
        self.assertFalse(self.positive_result['nativeAccepted'])

    def test_nonzero_exit_partial_output(self):
        self.reject(self.valid_fixture, 'nonzero actual native exit: partial records rejected', 1)

    def test_actual_native_stream_rejected(self):
        # Schema-completed SYNTHETIC stream retaining the actual old native
        # types/axioms; no claim to restore the omitted actual proof values.
        r = copy.deepcopy(self.old_records)
        for row in r['C29_GENERATED_JSON']:
            row['valuePrettyExplicitAllowOpaque'] = ('SYNTHETIC_VALUE_VALIDATOR_TEST_ONLY'
                if row['actualHasValueAllowOpaque'] else None)
        self.reject(r, 'old native, new foreign or sorry axiom observed')

    def test_native_axiom_still_on_consumer(self):
        r = self.valid_fixture; r['C29_ROOT_JSON'][0]['axioms'].append(self.baseline['removedNativeAxioms'][0])
        self.reject(r, 'old native, new foreign or sorry axiom observed')

    def test_new_foreign_axiom(self):
        r = self.valid_fixture; r['C29_GENERATED_JSON'][0]['axioms'].append('Injected.foreignAxiom')
        self.reject(r, 'old native, new foreign or sorry axiom observed')

    def test_sorry(self):
        r = self.valid_fixture; r['C29_GENERATED_JSON'][0]['axioms'].append('sorryAx')
        self.reject(r, 'old native, new foreign or sorry axiom observed')

    def test_unsafe(self):
        r = self.valid_fixture; r['C29_GENERATED_JSON'][0]['isUnsafe'] = True
        self.reject(r, 'unsafe/missing kernel constant')

    def test_target_axiom(self):
        r = self.valid_fixture; r['C29_ROOT_JSON'][0]['actualKind'] = 'axiomInfo'
        self.reject(r, 'target-owned axiom or self axiom remains')

    def test_missing_explicit(self):
        r = self.valid_fixture; r['C29_ROOT_JSON'].pop()
        self.reject(r, 'explicit root count mismatch')

    def test_missing_generated(self):
        r = self.valid_fixture; r['C29_GENERATED_JSON'].pop()
        self.reject(r, 'generated count mismatch')

    def test_duplicate_generated(self):
        r = self.valid_fixture; r['C29_GENERATED_JSON'].append(r['C29_GENERATED_JSON'][0])
        self.reject(r, 'duplicate or conflated generated identities')

    def test_native_acceptance_claim(self):
        r = self.valid_fixture; r['C29_SUMMARY_JSON'][0]['nativeAccepted'] = True
        self.reject(r, 'unexpected native acceptance')

    def test_policy_claim(self):
        r = self.valid_fixture; r['C29_GENERATED_JSON'][0]['axiomPolicyPass'] = True
        self.reject(r, 'generated diagnostic made acceptance/policy claim: axiomPolicyPass')

    def test_explicit_signature_change(self):
        r = self.valid_fixture; r['C29_ROOT_JSON'][0]['typePrettyExplicit'] += ' changed'
        self.reject(r, 'explicit signature observation changed; independent typed review required:')

    def test_generated_signature_change(self):
        r = self.valid_fixture; r['C29_GENERATED_JSON'][0]['typePrettyExplicit'] += ' changed'
        self.reject(r, 'surviving generated signature observation changed; review required:')

    def test_universe_change(self):
        r = self.valid_fixture; r['C29_ROOT_JSON'][0]['universeParameters'].append('newUniverse')
        self.reject(r, 'explicit signature observation changed; independent typed review required:')

    def test_fresh_olean_binding_failed(self):
        r = self.valid_fixture; r['C29_BINDING_JSON'][0]['freshOleanPathComparisonPassed'] = False
        self.reject(r, 'fresh artifact comparison failed')

    def test_generated_value_omitted_field(self):
        r = self.valid_fixture; del r['C29_GENERATED_JSON'][0]['valuePrettyExplicitAllowOpaque']
        self.reject(r, 'generated actual value observation missing')

    def test_unknown_record_tag(self):
        with self.assertRaisesRegex(ValueError, 'unknown diagnostic record tag') as caught:
            K.parse_records('C29_FAKE_JSON {}')
        self.observations.append(dict(test=self._testMethodName,
            expectedErrorRegex='unknown diagnostic record tag', actualError=str(caught.exception),
            baselineFullRelationalPositiveCompleted=True))

if __name__ == '__main__':
    unittest.main(verbosity=2)
