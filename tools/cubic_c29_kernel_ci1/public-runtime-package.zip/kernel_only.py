"""UNTESTED_KERNEL_PROOF_PROPOSAL: static guards and opt-in isolated CI diagnostic.

No code path grants scientific, source, publication, or axiom-policy acceptance.
No Lean subprocess is run unless --execute-after-parent-review is explicitly set.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
TARGET = 'QuantumBlockEncoding/CubicStatePreparation.lean'
MODULE = 'QuantumBlockEncoding.CubicStatePreparation'
ORIGINAL_SHA = 'd125f8c239bca1c15e6e4fa6e788df6dd8984394630cb2dcc9be8946c4cbcb55'
LINES = (252, 372, 437, 441, 771, 775, 779, 2465, 2535)
REPLACEMENTS = {line: (b'exact Rat.sub_self' if line == 2465 else b'decide +kernel') for line in LINES}
FLAGS = dict(sourceAgreement=None, publicationBinding=None, authorBinding=None,
             axiomPolicyPass=None, nativeAccepted=False, scientific_ROOT=False)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def mechanically_patch(original):
    if digest(original) != ORIGINAL_SHA or len(original) != 166483:
        raise ValueError('RESEAL original raw source mismatch')
    lines = original.splitlines(keepends=True)
    if original.count(b'native_decide') != 9:
        raise ValueError('unexpected native token count')
    edits = []
    offset = 0
    for line, raw in enumerate(lines, 1):
        if line in REPLACEMENTS:
            if raw.count(b'native_decide') != 1:
                raise ValueError('callsite mismatch')
            at = raw.index(b'native_decide')
            replacement = REPLACEMENTS[line]
            edits.append(dict(line=line, originalByteOffset=offset + at,
                              originalToken='native_decide', replacement=replacement.decode()))
            lines[line - 1] = raw.replace(b'native_decide', replacement)
        offset += len(raw)
    patched = b''.join(lines)
    if len(edits) != 9 or b'native_decide' in patched:
        raise ValueError('native replacement incomplete')
    return patched, edits

def verify_exact_delta(original, candidate):
    patched, edits = mechanically_patch(original)
    if candidate != patched:
        raise ValueError('candidate differs outside nine exact tactic-token replacements')
    # Recover original bytes from the predetermined, line-bound substitutions.
    lines = candidate.splitlines(keepends=True)
    for line in LINES:
        replacement = REPLACEMENTS[line]
        if lines[line - 1].count(replacement) != 1:
            raise ValueError('ambiguous inverse replacement')
        lines[line - 1] = lines[line - 1].replace(replacement, b'native_decide')
    if b''.join(lines) != original:
        raise ValueError('non-proof bytes or newline format changed')
    return dict(originalRawSHA256=digest(original), candidateRawSHA256=digest(candidate),
                originalBytes=len(original), candidateBytes=len(candidate), exactTokenEdits=edits,
                allOtherBytesIdentical=True, signatureBinderDefinitionResourceChanges=False)

def parse_records(stdout):
    tags = ('C29_BINDING_JSON', 'C29_ROOT_JSON', 'C29_GENERATED_JSON', 'C29_SUMMARY_JSON')
    records = {tag: [] for tag in tags}
    for line in stdout.splitlines():
        if line.startswith('C29_') and not any(line.startswith(t + ' ') for t in tags):
            raise ValueError('unknown diagnostic record tag')
        for tag in tags:
            if line.startswith(tag + ' '):
                records[tag].append(json.loads(line[len(tag) + 1:]))
    return records

def no_accept(row):
    for key, value in FLAGS.items():
        if key in row and row[key] is not value:
            raise ValueError('forbidden policy/acceptance field: ' + key)

def signature(row):
    return dict(actualKind=row['actualKind'], universeParameters=row['universeParameters'],
                typeTextSHA256=digest(row['typePrettyExplicit'].encode()),
                actualPrivate=row['actualPrivate'], isUnsafe=row['isUnsafe'],
                actualHasValueAllowOpaque=row['actualHasValueAllowOpaque'])

def validate_changed(expected, stdout, exit_code, baseline, package=HERE):
    if exit_code != 0:
        raise ValueError('nonzero actual native exit: partial records rejected')
    original = load_module('c29_kernel_original_validator', package / 'vendor/validate-output.py')
    field_validator = load_module('c29_kernel_generated_fields', package / 'vendor/validate-output-v2.py')
    original.validate(expected, stdout, exit_code)
    parsed = parse_records(stdout)
    roots = parsed['C29_ROOT_JSON']; generated = parsed['C29_GENERATED_JSON']
    summary = parsed['C29_SUMMARY_JSON'][0]; binding = parsed['C29_BINDING_JSON'][0]
    if binding.get('targetModule') != MODULE:
        raise ValueError('wrong target module')
    # Identity/count is genuinely dynamic for the changed source. This reuses the
    # old field validator ONLY for fields, not a fake independent 450-name oracle.
    field_validator.validate_generated(generated,
        [dict(actualName=r['actualName'], actualKind=r['actualKind']) for r in generated],
        [r['actualName'] for r in roots], summary)
    removed = set(baseline['removedNativeAxioms'])
    prior_union = set(baseline['allRecursiveAxioms'])
    if len(removed) != 9 or not removed <= prior_union:
        raise ValueError('bad immutable baseline native partition')
    remaining_prior = prior_union - removed
    for row in roots + generated:
        no_accept(row)
        if row.get('kernelRootPresent') is not True or row.get('isUnsafe') is not False:
            raise ValueError('unsafe/missing kernel constant')
        if row['actualKind'] == 'axiomInfo' or row.get('selfOccursInAxioms') is not False:
            raise ValueError('target-owned axiom or self axiom remains')
        if '_native' in row['actualName'] or 'native_decide' in row['actualName']:
            raise ValueError('native generated declaration remains')
        axioms = set(row['axioms'])
        if axioms & removed or not axioms <= remaining_prior or any('sorry' in a.lower() for a in axioms):
            raise ValueError('old native, new foreign or sorry axiom observed')
    no_accept(binding); no_accept(summary)
    by_source = {r['sourceUserName']: r for r in roots}
    if set(by_source) != set(baseline['explicit']):
        raise ValueError('source root identity changed')
    for name, old in baseline['explicit'].items():
        new = by_source[name]
        if signature(new) != old['signature']:
            raise ValueError('explicit signature observation changed; independent typed review required: ' + name)
        if not set(new['axioms']) <= set(old['axioms']) - removed:
            raise ValueError('explicit consumer acquired new recursive axiom: ' + name)
    gen_by_user = {}
    for row in generated:
        key = row['userNameViaActualAPI']
        if key in gen_by_user:
            raise ValueError('ambiguous generated actual API user name')
        gen_by_user[key] = row
    old_generated = baseline['generatedWithoutNineNativeAxioms']
    if not set(old_generated) <= set(gen_by_user):
        raise ValueError('non-native prior generated declaration disappeared; review required')
    changed_signatures = []
    for name, old in old_generated.items():
        new = gen_by_user[name]
        if signature(new) != old['signature']:
            changed_signatures.append(name)
    # Actual elaboration may produce proof-only auxiliary declarations. Export
    # them all and fail closed on altered surviving generated signature text.
    if changed_signatures:
        raise ValueError('surviving generated signature observation changed; review required: ' + ', '.join(changed_signatures))
    new_helpers = sorted(set(gen_by_user) - set(old_generated))
    if any(gen_by_user[n]['actualKind'] != 'thmInfo' for n in new_helpers):
        raise ValueError('unexpected non-theorem generated addition')
    for old_axiom, consumers in baseline['nativeConsumers'].items():
        for name in consumers['explicit']:
            if old_axiom in by_source[name]['axioms']:
                raise ValueError('explicit native consumer still depends on removed axiom')
        for name in consumers['generated']:
            if name not in gen_by_user or old_axiom in gen_by_user[name]['axioms']:
                raise ValueError('generated native consumer missing or still depends on axiom')
    return dict(status='RELATIONAL_KERNEL_SUBSTITUTION_DIAGNOSTIC_NOT_ACCEPTANCE',
        explicitRoots=319, generatedObserved=len(generated), generatedCountWasNotAssumed450=True,
        removedNativeAxiomsAbsent=sorted(removed), additionalGeneratedTheorems=new_helpers,
        newRecursiveAxiomUnion=sorted({a for r in roots + generated for a in r['axioms']}),
        axiomComparison='New union is a subset of old union minus nine observed native axioms; this is not a policy whitelist',
        capturedSignatureTextCompared=True, losslessExpr=False, wholeTargetTrustClosed=False, **FLAGS)

def static_check(package=HERE):
    pins = json.loads((package / 'proposal-pins.json').read_text(encoding='utf-8'))
    runner = load_module('c29_kernel_vendor_runner', package / 'vendor/runner.py')
    runner.verify_pins(package, pins['packageFiles'])
    return verify_exact_delta((package / 'original/CubicStatePreparation.lean').read_bytes(),
                              (package / 'candidate/CubicStatePreparation.lean').read_bytes())

def linux_resource_gate(output_directory, meminfo_text=None, free_bytes=None):
    if meminfo_text is None:
        if not sys.platform.startswith('linux'):
            raise ValueError('Native proposal execution is Linux CI only; no guessed Windows resource gate')
        meminfo_text = Path('/proc/meminfo').read_text(encoding='ascii')
    info = {}
    for line in meminfo_text.splitlines():
        parts = line.split()
        if len(parts) == 3 and parts[2] == 'kB':
            info[parts[0].rstrip(':')] = int(parts[1]) * 1024
    if 'MemAvailable' not in info or 'SwapFree' not in info:
        raise ValueError('Linux available memory/swap measurement missing')
    if free_bytes is None:
        free_bytes = shutil.disk_usage(output_directory).free
    physical = info['MemAvailable']
    virtual = physical + info['SwapFree']
    return dict(physicalAvailableBytes=physical, virtualAvailableBytes=virtual,
        virtualDefinition='Linux MemAvailable + SwapFree, not Windows CIM', outputFreeBytes=free_bytes,
        minimumPhysicalBytes=4 * 2**30, minimumVirtualBytes=6 * 2**30,
        minimumOutputFreeBytes=8 * 2**30,
        gatePassed=physical >= 4 * 2**30 and virtual >= 6 * 2**30 and free_bytes >= 8 * 2**30)

def execute_after_review(project, package=HERE):
    """One bounded cohort, only after explicit review and separate run authorization."""
    static = static_check(package)
    runner = load_module('c29_kernel_vendor_runner', package / 'vendor/runner.py')
    project = project.resolve()
    out = runner.safe_child(project, '_out/cubic-c29-kernel-only-v1')
    out.mkdir(parents=True, exist_ok=False)
    private = out / 'private'; private.mkdir(mode=0o700)
    public = out / 'public'; public.mkdir()
    logical = {str(project): '$PROJECT', str(package): '$KERNEL_PROPOSAL'}
    status = dict(status='DIAGNOSTIC_NOT_RUN', **FLAGS)
    code = 1
    try:
        pins = json.loads((package / 'proposal-pins.json').read_text(encoding='utf-8'))
        runner.verify_pins(project, pins['originalProjectInputs'])
        runner.write_json(private / 'input-delta.json', static)
        runner.write_json(private / 'input-pins.json', pins)
        gate = linux_resource_gate(out)
        runner.write_json(private / 'resource-gate.json', gate)
        if not gate['gatePassed']:
            raise ValueError('ENV_BLOCKED resource gate; zero Lean calls, no retry')
        env = dict(os.environ)
        bootstrap = shutil.which('lean', path=env.get('PATH'))
        if not bootstrap:
            raise FileNotFoundError('lean executable missing from lake env PATH')
        runner.native_call(private, '01-help', [bootstrap, '--help'], project, env, timeout=30)
        runner.verify_lean_help((private / '01-help.stdout.raw').read_text(encoding='utf-8'))
        runner.native_call(private, '02-prefix', [bootstrap, '--print-prefix'], project, env, timeout=30)
        prefix = Path((private / '02-prefix.stdout.raw').read_text(encoding='utf-8').strip()).resolve()
        logical[str(prefix)] = '$TOOLCHAIN'
        lean = prefix / 'bin' / ('lean.exe' if os.name == 'nt' else 'lean')
        raw_roots = env.get('LEAN_PATH', '').split(os.pathsep)
        if not raw_roots or any(not root for root in raw_roots):
            raise ValueError('explicit lake env LEAN_PATH required')
        roots = [(Path(p) if Path(p).is_absolute() else project / p).resolve() for p in raw_roots]
        roots = list(dict.fromkeys(roots + [prefix / 'lib/lean']))
        original_local = (project / '.lake/build/lib/lean').resolve()
        effective = [root for root in roots if root != original_local]
        # The original target cache is not on ANY effective explicit search root.
        for root in effective:
            if (root / TARGET.replace('.lean', '.olean')).exists():
                raise ValueError('original/foreign target cache remains on effective search path')
        for i, root in enumerate(roots):
            if not root.is_relative_to(project) and not root.is_relative_to(prefix):
                logical[str(root)] = '$SEARCH_ROOT_' + str(i)
        native_roots = list(dict.fromkeys(roots + [prefix / 'lib']))
        present, absent = runner.partition_search_roots(native_roots)
        inventory = runner.inventory_providers(present, out)
        runner.write_json(private / 'providers.json', dict(
            inventoryMode='POTENTIAL_PROVIDER_FILES_NOT_ACTUAL_LOAD_TRACE_NOT_CLEAN_TRANSITIVE',
            files=inventory, actualLeanBinarySHA256=runner.sha(lean),
            removedOriginalProjectBuildSearchRoot=str(original_local),
            effectiveSearchRoots=list(map(str, effective)), absentSearchRoots=list(map(str, absent))))
        fresh = out / 'fresh'; fresh.mkdir()
        copies = runner.copy_local_providers(project, fresh)
        runner.write_json(private / 'copied-five-local-providers.json', dict(files=copies))
        cohort = out / 'cohort'; cohort.mkdir()
        (cohort / 'QuantumBlockEncoding').mkdir()
        candidate = cohort / TARGET
        shutil.copyfile(package / 'candidate/CubicStatePreparation.lean', candidate)
        if runner.sha(candidate) != pins['candidateRawSHA256']:
            raise ValueError('candidate changed during copy')
        output = fresh / TARGET.replace('.lean', '.olean')
        if output.exists():
            raise FileExistsError('fresh target already exists')
        env['LEAN_PATH'] = os.pathsep.join(map(str, [fresh] + effective))
        env.pop('QBE_EXPECT_FRESH_OLEAN', None)
        runner.native_call(private, '03-candidate-target', [str(lean), '--threads=1', '--memory=3072',
            '-o', str(output), TARGET], cohort, env, timeout=600)
        if not output.is_file():
            raise FileNotFoundError('successful compile without fresh candidate artifact')
        if runner.sha(output) == 'bf072be3d4df8ed32049b7f67db6e0223ebb7f48dd84035715683b983f18cf45':
            raise ValueError('candidate artifact unexpectedly equals original native target cache')
        fresh_rows = [dict(path=str(p), sha256=runner.sha(p), bytes=p.stat().st_size)
                      for p in output.parent.glob('CubicStatePreparation.*') if p.is_file()]
        runner.write_json(private / 'fresh-candidate-artifacts.json', dict(
            files=fresh_rows, candidateSourceSHA256=runner.sha(candidate),
            baselineOriginalOleanMustNotBeLoaded='bf072be3d4df8ed32049b7f67db6e0223ebb7f48dd84035715683b983f18cf45'))
        driver = out / 'driver'; driver.mkdir()
        shutil.copyfile(package / 'vendor/Probe-v5.lean', driver / 'Probe.lean')
        env['QBE_EXPECT_FRESH_OLEAN'] = str(output)
        result = runner.native_call(private, '04-full-kernel-candidate-probe',
            [str(lean), '--threads=1', '--memory=3072', 'Probe.lean'], driver, env, timeout=300)
        expected = json.loads((package / 'vendor/expected-roots.json').read_text(encoding='utf-8'))
        baseline = json.loads((package / 'baseline-observations.json').read_text(encoding='utf-8'))
        checked = validate_changed(expected,
            (private / '04-full-kernel-candidate-probe.stdout.raw').read_text(encoding='utf-8'),
            result['exitCode'], baseline, package)
        runner.write_json(private / 'relational-axiom-signature-comparison.json', checked)
        runner.verify_pins(project, pins['originalProjectInputs'])
        static_check(package)
        if any(root.exists() for root in absent):
            raise ValueError('RESEAL absent provider search root appeared')
        for row in inventory + fresh_rows:
            if runner.sha(Path(row['path'])) != row['sha256']:
                raise ValueError('RESEAL provider or candidate artifact changed')
        for row in copies:
            if runner.sha(Path(row['source'])) != row['sha256'] or runner.sha(Path(row['destination'])) != row['sha256']:
                raise ValueError('RESEAL copied provider changed')
        if runner.sha(candidate) != pins['candidateRawSHA256']:
            raise ValueError('candidate input changed during diagnostic')
        status.update(status='KERNEL_SUBSTITUTION_RUNTIME_DIAGNOSTIC_COMPLETE_NOT_ACCEPTANCE',
                      relationalDiagnostic=checked, inheritedProviders=True, cleanTransitive=False,
                      dynamicLibraryLoadTrace=False)
        code = 0
    except Exception as error:
        status.update(status='DIAGNOSTIC_FAILED_NOT_MATHEMATICAL_REFUTATION',
                      failureType=type(error).__name__, failure=str(error))
    finally:
        runner.write_json(private / 'result.json', status)
        runner.export_public(private, public, logical)
    print(json.dumps(runner.redact_tree(status, logical)), flush=True)
    return code

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, default=Path.cwd())
    parser.add_argument('--execute-after-parent-review', action='store_true')
    args = parser.parse_args()
    try:
        if args.execute_after_parent_review:
            sys.exit(execute_after_review(args.project))
        print(json.dumps(dict(status='STATIC_ONLY_NOT_LEAN_PROOF', delta=static_check(), **FLAGS)))
    except Exception as error:
        print(json.dumps(dict(status='FAILED_CLOSED', failureType=type(error).__name__, **FLAGS)))
        sys.exit(1)
