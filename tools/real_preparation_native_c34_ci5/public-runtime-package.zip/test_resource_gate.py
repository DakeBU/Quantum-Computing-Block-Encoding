"""CI5 adapter negatives: no Lean, no procfs reads, no actual capacity claim."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import bindings as b
import resource_adapter as ra
import resource_fixtures as f
import test_discovery as old

HERE = Path(__file__).resolve().parent


class ResourceTests(unittest.TestCase):
    def pipeline(self, directory):
        return old.SyntheticPipelineTests().setup_pipeline(directory)

    def test_exact_reused_source_chain_and_explicit_current_budget(self):
        chain = json.loads((HERE/'resource-chain.json').read_text())
        for name, row in chain['files'].items():
            self.assertEqual(hashlib.sha256((HERE/name).read_bytes()).hexdigest(), row['sha256'])
            self.assertEqual((HERE/name).stat().st_size, row['bytes'])
        self.assertEqual(chain['namespaceSchema'], 'C31_CI4_RESOURCE_SELF_NAMESPACE_V1')
        self.assertEqual(ra.strict_argv(['lean','--threads=1','--memory=5120']),
                         ['lean','--threads=1','--memory=5120'])
        for argv in (['lean'], ['lean','--memory=3072','--threads=1'],
            ['lean','--memory=5120','--threads=2'], ['lean','--memory=5120','--threads=1','-M0'],
            ['lean','--memory=5120','--memory=5120','--threads=1']):
            with self.assertRaises(ValueError): ra.strict_argv(argv)

    def test_boundary_and_every_child_pre_post_receipt(self):
        with tempfile.TemporaryDirectory(prefix='SYNTHETIC-ci5-',dir=HERE) as directory:
            rt,api,prefix=self.pipeline(directory)
            gate=rt.resource_guard.gate
            data=f.files();data[f.MOUNT+'/parent/memory.max']=str(8192*gate.MIB).encode()
            sample=lambda:f.snapshot(gate,data)
            self.assertEqual(sample()['effectiveHeadroomBytes'],7168*gate.MIB)
            rt.resource_guard.callback.sampler=sample
            with patch.object(old.runner.shutil,'which',return_value=str(prefix/'bin/lean')):
                rt.prepare_toolchain_and_providers()
                old.d.discover_project_providers(rt)
                result=old.runner.execute_fresh_observation(rt)
            self.assertEqual(result['roots'],57);self.assertFalse(result['nativeAccepted'])
            self.assertEqual(len(api.calls),10)
            for label,_ in api.calls:
                pre=json.loads((rt.private/('ci2-'+label+'.preflight.json')).read_text())
                post=json.loads((rt.private/('ci2-'+label+'.postflight.json')).read_text())
                obs=json.loads((rt.private/('ci2-'+label+'.observation.json')).read_text())
                self.assertTrue(gate.validate_snapshot(pre));self.assertTrue(gate.validate_snapshot(post))
                self.assertEqual(obs['classification'],'PROCESS_EXIT_ZERO')
                self.assertEqual(obs['requestedArgv'],obs['actualArgv'])
                self.assertIn('--memory=5120',obs['actualArgv'])
                self.assertTrue(obs['actualPIDResultReceiptsMatch'])
                self.assertTrue(obs['actualStreamHashesMatch'])

    def test_insufficient_unknown_cgroup_wrong_namespace_or_missing_fields_start_zero_children(self):
        with tempfile.TemporaryDirectory(prefix='SYNTHETIC-ci5-',dir=HERE) as directory:
            rt,api,prefix=self.pipeline(directory);gate=rt.resource_guard.gate
            low=f.files();low[f.MOUNT+'/parent/memory.max']=str(8192*gate.MIB).encode()
            low[f.MOUNT+'/parent/memory.current']=str(1024*gate.MIB+1).encode()
            rt.resource_guard.callback.sampler=lambda:f.snapshot(gate,low)
            with self.assertRaises(RuntimeError):
                rt.call('01-prefix',[str(prefix/'bin/lean'),'--threads=1','--memory=5120','--print-prefix'],
                        rt.project,30)
            self.assertEqual(api.calls,[])
            self.assertTrue((rt.private/'ci2-01-prefix.preflight.json').is_file())
        for row_kind in ('unknown','namespace','missing','windows'):
            with tempfile.TemporaryDirectory(prefix='SYNTHETIC-ci5-',dir=HERE) as directory:
                rt,api,prefix=self.pipeline(directory);gate=rt.resource_guard.gate
                if row_kind=='unknown':
                    data=f.files();data[f.MOUNT+'/parent/memory.max']=b'unknown';row=f.snapshot(gate,data)
                elif row_kind=='namespace':row=f.snapshot(gate,namespace='cgroup:[4026533000]')
                elif row_kind=='windows':row=f.snapshot(gate,context=dict(f.CONTEXT,platform='win32'))
                else:row={'gatePassed':True}
                rt.resource_guard.callback.sampler=lambda:row
                with self.assertRaises(RuntimeError):
                    rt.call('01-prefix',[str(prefix/'bin/lean'),'--threads=1','--memory=5120','--print-prefix'],rt.project,30)
                self.assertEqual(api.calls,[])
                self.assertTrue((rt.private/'ci2-01-prefix.preflight.json').is_file())

    def test_budget_profile_or_guard_drift_starts_zero_children(self):
        for kind in ('argv','profile','guard'):
            with tempfile.TemporaryDirectory(prefix='SYNTHETIC-ci5-',dir=HERE) as directory:
                rt,api,prefix=self.pipeline(directory)
                argv=[str(prefix/'bin/lean'),'--threads=1','--memory=5120','--print-prefix']
                if kind=='argv':argv[2]='--memory=3072'
                elif kind=='profile':rt.profile['envelope']['memoryMiB']=3072
                else:rt.resource_guard=None
                with self.assertRaises((ValueError,RuntimeError)):
                    rt.call('01-prefix',argv,rt.project,30)
                self.assertEqual(api.calls,[])
                if kind=='guard':self.assertTrue((rt.private/'resource-refused-01-prefix.json').is_file())

    def test_unknown_postflight_cannot_be_success(self):
        with tempfile.TemporaryDirectory(prefix='SYNTHETIC-ci5-',dir=HERE) as directory:
            rt,api,prefix=self.pipeline(directory);gate=rt.resource_guard.gate
            samples=iter([f.snapshot(gate),{'gatePassed':True}])
            rt.resource_guard.callback.sampler=lambda:next(samples)
            with self.assertRaises(ValueError):
                rt.call('01-prefix',[str(prefix/'bin/lean'),'--threads=1','--memory=5120','--print-prefix'],rt.project,30)
            self.assertEqual(len(api.calls),1)
            self.assertTrue((rt.private/'ci2-01-prefix.postflight.json').is_file())

    def test_namespace_policy_has_no_pid1_or_hidden_root_fallback(self):
        with tempfile.TemporaryDirectory(prefix='SYNTHETIC-ci5-',dir=HERE) as directory:
            rt,api,prefix=self.pipeline(directory);gate=rt.resource_guard.gate
            row=f.snapshot(gate);self.assertTrue(gate.validate_snapshot(row))
            self.assertEqual([x['logicalPath'] for x in row['namespaceReads']],['$PROC/self/ns/cgroup'])
            self.assertFalse(row['namespaceObservation']['pid1Observation']['readRequested'])
            for field in ('rootObservation','namespaceObservation','cgroups','readAttempts'):
                changed=deepcopy(row);changed.pop(field)
                with self.assertRaises((ValueError,KeyError)):gate.validate_snapshot(changed)
            data=f.files();data['/proc/self/mountinfo']=b'31 20 0:27 /parent /sys/fs/cgroup rw - cgroup2 cgroup rw\n'
            self.assertFalse(f.snapshot(gate,data)['gatePassed'])


if __name__=='__main__':unittest.main()
