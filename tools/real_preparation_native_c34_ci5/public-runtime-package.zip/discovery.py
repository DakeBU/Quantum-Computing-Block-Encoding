"""Compiler-observed import discovery. No Lean parser or provider-list override in Python."""
import re
from pathlib import Path

ROW_TAG = 'C34_IMPORTS_JSON'
SUMMARY_TAG = 'C34_IMPORTS_SUMMARY_JSON'
IMPORT_FIELDS = {'module', 'importAll', 'isExported', 'isMeta'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def enumerate_candidates(project, scopes, b):
    project = Path(project).resolve()
    paths = []
    for directory in scopes['directoryRoots']:
        root = b.child(project, directory)
        require(root.is_dir() and not root.is_symlink(), 'candidate source directory absent/linked')
        for path in root.rglob('*'):
            require(not path.is_symlink(), 'linked candidate subtree entry forbidden')
            if path.suffix != '.lean':
                continue
            require(path.is_file(), 'candidate source not a regular file')
            relative = path.relative_to(project).as_posix()
            require(b.child(project, relative).resolve() == path.absolute(), 'candidate path alias/escape')
            paths.append(relative)
    for relative in scopes['rootFiles']:
        path = b.child(project, relative)
        require(path.is_file() and not path.is_symlink(), 'root candidate source absent/linked')
        paths.append(relative)
    require(paths and len(paths) == len(set(paths)), 'empty/duplicate candidate paths')
    return sorted(paths)


def check_candidates(project, candidate, profile, b):
    require(candidate.get('schema') == 'C34_FROZEN_PROJECT_CANDIDATES_V2', 'candidate schema')
    require(candidate.get('scopes') == profile['candidateSourceScopes'], 'candidate scope drift')
    rows = candidate.get('files')
    require(type(rows) is list and rows, 'empty candidate vector')
    require([r['relativePath'] for r in rows] == enumerate_candidates(project, candidate['scopes'], b),
            'candidate file membership/order changed')
    modules = []
    for row in rows:
        relative = row['relativePath']
        require(relative.endswith('.lean') and row['module'] == relative[:-5].replace('/', '.'),
                'candidate module/path mismatch')
        require(re.fullmatch(r'[A-Za-z_][A-Za-z0-9_.]*', row['module']) is not None,
                'unsupported candidate module identifier')
        path = b.child(project, relative)
        require(type(row['bytes']) is int and row['bytes'] > 0 and
                path.stat().st_size == row['bytes'] and b.sha(path) == row['sha256'],
                'candidate source byte binding changed')
        modules.append(row['module'])
    require(len(modules) == len(set(modules)), 'candidate module collision')
    by_name = {r['module']: r for r in rows}
    for module in profile['modules']:
        require(module['module'] in by_name and
                by_name[module['module']]['sha256'] == module['rawSHA256'], 'target/candidate digest drift')
    return rows


def validate_parser_output(stdout, request, request_sha, exit_code, timed_out, v):
    require(type(exit_code) is int and exit_code == 0 and timed_out is False,
            'parser process nonzero/missing/timeout exit')
    rows, summary = [], None
    for line in stdout.splitlines():
        if not line.strip():
            continue
        require(summary is None, 'parser output after terminal summary')
        tag, sep, payload = line.partition(' ')
        require(sep and tag in (ROW_TAG, SUMMARY_TAG), 'unexpected parser output line')
        row = v.loads(payload)
        require(type(row) is dict, 'parser record not object')
        v.no_accept(row)
        for field in ('candidateSetSHA256', 'profileSHA256', 'runID'):
            require(row.get(field) == request[field], 'parser binding drift ' + field)
        require(row.get('requestSHA256') == request_sha, 'parser request digest drift')
        require(row.get('parserAPI') == 'Lean.Elab.parseImports', 'parser API provenance absent')
        if tag == SUMMARY_TAG:
            summary = row
            continue
        require(len(rows) < len(request['candidates']), 'excess/duplicate parser candidate row')
        expected = request['candidates'][len(rows)]
        require(type(row.get('ordinal')) is int and row['ordinal'] == len(rows) + 1,
                'parser candidate ordinal drift')
        for field in ('module', 'relativePath', 'snapshotPath', 'sha256', 'bytes'):
            require(row.get(field) == expected[field], 'parser candidate binding drift ' + field)
        require(type(row.get('bytes')) is int and type(row.get('parseMessages')) is int and
                row['parseMessages'] == 0 and row.get('hasParseErrors') is False,
                'parser diagnostics or incorrect byte count type')
        imports = row.get('imports')
        require(type(imports) is list, 'parser imports missing')
        for imp in imports:
            require(type(imp) is dict and set(imp) == IMPORT_FIELDS and
                    type(imp['module']) is str and imp['module'], 'incorrect Import field set')
            require(all(type(imp[k]) is bool for k in IMPORT_FIELDS - {'module'}),
                    'missing/nonboolean Import flag')
        rows.append(row)
    require(summary is not None and len(rows) == len(request['candidates']), 'partial parser stream')
    require(summary.get('status') == 'COMPILER_IMPORT_HEADERS_OBSERVED_NOT_ACCEPTANCE' and
            type(summary.get('candidateCount')) is int and summary['candidateCount'] == len(rows) and
            summary.get('importFields') == ['module', 'importAll', 'isExported', 'isMeta'],
            'parser terminal count/field vector drift')
    return rows, summary


def derive_closure(profile, candidate, parsed):
    """Graph traversal of compiler observations only; not theorem support or proof closure."""
    all_candidates = {r['module']: r for r in candidate['files']}
    require(len(parsed) == len(all_candidates), 'compiler candidate coverage incomplete')
    by_name = {r['module']: r for r in parsed}
    require(len(by_name) == len(parsed) and set(by_name) == set(all_candidates),
            'compiler candidate identity coverage differs')
    prefixes = set(candidate['scopes']['directoryRoots'])
    roots = {p[:-5].replace('/', '.') for p in candidate['scopes']['rootFiles']}
    targets = [m['module'] for m in profile['modules']]
    index = {name: i for i, name in enumerate(targets)}
    visiting, visited, ordered = set(), set(), []
    def project_owned(name):
        return name in all_candidates or name in roots or name.split('.', 1)[0] in prefixes
    def visit(name):
        require(name not in visiting, 'project import cycle')
        if name in visited:
            return
        require(name in by_name, 'unresolved project-owned import ' + name)
        visiting.add(name)
        for imp in by_name[name]['imports']:
            dependency = imp['module']
            if project_owned(dependency):
                visit(dependency)
        visiting.remove(name)
        visited.add(name)
        ordered.append(name)
    for target in targets:
        visit(target)
    target_dependencies = {}
    for target in targets:
        seen = set()
        def descend(name):
            for imp in by_name[name]['imports']:
                dep = imp['module']
                if project_owned(dep) and dep not in seen:
                    seen.add(dep)
                    descend(dep)
        descend(target)
        required = [dep for dep in targets if dep in seen]
        require(all(index[dep] < index[target] for dep in required), 'frozen target compile order invalid')
        target_dependencies[target] = required
    sources = {all_candidates[name]['relativePath']: all_candidates[name]['sha256'] for name in ordered}
    providers = [name for name in ordered if name not in index]
    external = [dict(owner=name, imports=[imp for imp in by_name[name]['imports']
                if not project_owned(imp['module'])]) for name in ordered]
    return dict(projectClosure=ordered, sourcePins=sources, providers=providers,
                targetDependencies=target_dependencies, externalImports=external,
                compilerRows=[by_name[name] for name in ordered])


def discover_project_providers(rt):
    """Freeze candidates, execute ONE bounded Lean parser observation, derive exact closure."""
    b, v, api = rt.b, rt.v, rt.api
    candidate_path = b.child(rt.package, 'candidate-sources.json')
    candidate = v.loads(candidate_path.read_text(encoding='utf-8'))
    v.no_accept(candidate)
    rows = check_candidates(rt.project, candidate, rt.profile, b)
    rt.candidate = candidate
    candidate_sha = b.sha(candidate_path)
    directory = rt.out / 'discovery'; directory.mkdir()
    snapshot = directory / 'source'; snapshot.mkdir()
    requests = []
    for row in rows:
        source = b.child(rt.project, row['relativePath'])
        copied = b.child(snapshot, row['relativePath'])
        rt.copies.append(b.copy_bound(source, copied, row['sha256']))
        requests.append(dict(row, snapshotPath=str(copied.resolve())))
    request = dict(schema='C34_PARSER_REQUEST_V2', candidateSetSHA256=candidate_sha,
                   profileSHA256=rt.profile_sha, runID=rt.run_id, candidates=requests)
    request_path = rt.private / 'parser-request.json'
    api.write_json(request_path, request)
    request_sha = b.sha(request_path)
    rt.bind_artifact(request_path)
    parser = directory / 'Parser.lean'
    rt.copies.append(b.copy_bound(b.child(rt.package, 'Parser.lean'), parser,
                                 rt.manifest['files']['Parser.lean']))
    parser_env = dict(rt.env)
    parser_env['LEAN_PATH'] = __import__('os').pathsep.join(map(str, rt.external))
    parser_env['C34_PARSER_REQUEST_SHA256'] = request_sha
    flags = [str(rt.lean), '--threads=1', '--memory=5120']
    compile_result = rt.call('03-parser-compile', flags +
        ['-o', str(directory / 'Parser.olean'), 'Parser.lean'], directory,
        rt.profile['envelope']['parserCompileTimeoutSeconds'], env=parser_env)
    require((directory / 'Parser.olean').is_file(), 'parser compile exit without olean')
    for suffix in b.SIDECARS:
        path = directory / ('Parser' + suffix)
        if path.is_file():
            rt.bind_artifact(path)
    observe_result = rt.call('04-parser-observe', flags +
        ['--run', 'Parser.lean', str(request_path)], directory,
        rt.profile['envelope']['parserObserveTimeoutSeconds'], env=parser_env)
    raw_path = rt.private / '04-parser-observe.stdout.raw'
    parsed, summary = validate_parser_output(raw_path.read_text(encoding='utf-8', errors='strict'),
        request, request_sha, observe_result['exitCode'], observe_result['timedOut'], v)
    rt.revalidate()
    closure = derive_closure(rt.profile, candidate, parsed)
    provenance_path = rt.private / 'parser-provenance.json'
    api.write_json(provenance_path, dict(
        method='Lean.Elab.parseImports', parserSourceSHA256=b.sha(parser),
        parserSourceCopies=[row for row in rt.copies if row['destinationRealPath'] == str(parser.resolve())],
        parserCompile=compile_result, parserObserve=observe_result,
        actualLeanBinary=str(rt.lean), actualLeanBinarySHA256=b.sha(rt.lean),
        entry=rt.entry, requestSHA256=request_sha, candidateSetSHA256=candidate_sha,
        rawObservationSHA256=b.sha(raw_path), stages=rt.stage_receipts,
        parserObservationMode='LEAN_RUN_REELABORATES_SAME_PINNED_DRIVER_SOURCE_NOT_LOADING_PARSER_OLEAN',
        **v.NO_ACCEPT))
    rt.bind_artifact(provenance_path)
    result = dict(method='LEAN_ELAB_PARSE_IMPORTS_COMPLETE_PROJECT_CLOSURE', closureComplete=True,
        candidateSetSHA256=candidate_sha, candidateCount=len(rows), requestSHA256=request_sha,
        parserReceiptSHA256=b.sha(provenance_path), parserStdoutSHA256=b.sha(raw_path),
        parserSummary=summary, runID=rt.run_id, **closure, **v.NO_ACCEPT)
    api.write_json(rt.private / 'compiler-discovery.json', result)
    rt.bind_artifact(rt.private / 'compiler-discovery.json')
    for path, digest in closure['sourcePins'].items():
        require(path not in rt.source_pins or rt.source_pins[path] == digest,
                'compiler closure cannot override a frozen input pin')
        rt.source_pins[path] = digest
    rt.revalidate()
    return result


def confirmed_runtime_discovery(rt):
    """Re-derive providers from this run's bound raw compiler stream; no provider JSON input."""
    rt.revalidate()
    b, v = rt.b, rt.v
    request_path = rt.private / 'parser-request.json'
    raw_path = rt.private / '04-parser-observe.stdout.raw'
    provenance_path = rt.private / 'parser-provenance.json'
    request = v.loads(request_path.read_text(encoding='utf-8'))
    result = v.loads((rt.private / '04-parser-observe.result.json').read_text(encoding='utf-8'))
    require(request.get('runID') == rt.run_id and request.get('profileSHA256') == rt.profile_sha and
            request.get('candidateSetSHA256') == b.sha(rt.package / 'candidate-sources.json'),
            'runtime parser request binding differs')
    require(result.get('stdoutSHA256') == b.sha(raw_path), 'actual parser stdout receipt drift')
    parsed, summary = validate_parser_output(raw_path.read_text(encoding='utf-8', errors='strict'),
        request, b.sha(request_path), result.get('exitCode'), result.get('timedOut'), v)
    recomputed = derive_closure(rt.profile, rt.candidate, parsed)
    saved = v.loads((rt.private / 'compiler-discovery.json').read_text(encoding='utf-8'))
    v.no_accept(saved)
    for key, expected in recomputed.items():
        require(saved.get(key) == expected, 'saved provider/closure data differs from compiler stream')
    require(saved.get('parserReceiptSHA256') == b.sha(provenance_path) and
            saved.get('parserStdoutSHA256') == b.sha(raw_path) and saved.get('parserSummary') == summary and
            saved.get('requestSHA256') == b.sha(request_path), 'parser evidence binding drift')
    rt.revalidate()
    return saved
