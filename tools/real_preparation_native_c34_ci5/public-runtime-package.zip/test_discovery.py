"""Synthetic compiler-stream/controller fixtures only. NEVER invokes Lean or any subprocess."""
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import contextlib
import io
import json
import os
import shutil
import tempfile
import unittest
from unittest.mock import patch

import bindings as b
import discovery as d
import runner
import validator as v
import test_adapter as a
import resource_adapter
import resource_fixtures

HERE, PROJECT, PROFILE = a.HERE, a.PROJECT, a.PROFILE


def imp(module, **flags):
    return dict(module=module, importAll=flags.get('importAll', False),
                isExported=flags.get('isExported', True), isMeta=flags.get('isMeta', False))


INIT = [imp('Init'), imp('Init', isMeta=True)]


def parser_fixture(request, request_sha, graph):
    stream = []
    common = {key: request[key] for key in ('candidateSetSHA256', 'profileSHA256', 'runID')}
    for ordinal, row in enumerate(request['candidates'], 1):
        stream.append((d.ROW_TAG, dict(row, ordinal=ordinal, requestSHA256=request_sha,
            parserAPI='Lean.Elab.parseImports', parseMessages=0, hasParseErrors=False,
            imports=deepcopy(graph[row['module']]), **common, **v.NO_ACCEPT)))
    stream.append((d.SUMMARY_TAG, dict(status='COMPILER_IMPORT_HEADERS_OBSERVED_NOT_ACCEPTANCE',
        candidateCount=len(request['candidates']), requestSHA256=request_sha,
        parserAPI='Lean.Elab.parseImports', importFields=['module', 'importAll', 'isExported', 'isMeta'],
        **common, **v.NO_ACCEPT)))
    return stream


def tiny():
    names = ['QuantumBlockEncoding.A', 'QuantumBlockEncoding.B', 'QuantumBlockEncoding.P']
    rows = [dict(module=n, relativePath=n.replace('.', '/') + '.lean', sha256='a' * 64, bytes=10)
            for n in names]
    candidate = dict(schema='C34_FROZEN_PROJECT_CANDIDATES_V2',
        scopes=dict(directoryRoots=['QuantumBlockEncoding'], rootFiles=[]), files=rows)
    profile = dict(modules=[dict(module=names[0]), dict(module=names[1])])
    request = dict(schema='C34_PARSER_REQUEST_V2', candidateSetSHA256='b' * 64,
        profileSHA256='c' * 64, runID='SYNTHETIC_NOT_A_NATIVE_RUN',
        candidates=[dict(r, snapshotPath='$SNAPSHOT/' + r['relativePath']) for r in rows])
    graph = {names[0]: INIT + [imp(names[2], importAll=True, isExported=False, isMeta=True)],
             names[1]: INIT + [imp(names[0])], names[2]: INIT + [imp('Mathlib.SyntheticExternal')]}
    return profile, candidate, request, graph


class DiscoveryTests(unittest.TestCase):
    def test_current_complete_candidate_set_is_frozen_not_a_closure(self):
        candidate = v.loads((HERE / 'candidate-sources.json').read_text(encoding='utf-8'))
        rows = d.check_candidates(PROJECT, candidate, PROFILE, b)
        self.assertEqual(len(rows), 220)
        self.assertIs(candidate['closureAuthority'], False)

    def test_compiler_stream_all_flags_and_implicit_init_preserved(self):
        profile, candidate, request, graph = tiny()
        parsed, summary = d.validate_parser_output(a.dump(parser_fixture(request, 'd' * 64, graph)),
            request, 'd' * 64, 0, False, v)
        self.assertEqual(parsed[0]['imports'][:2], INIT)
        self.assertEqual(parsed[0]['imports'][2], graph['QuantumBlockEncoding.A'][2])
        closure = d.derive_closure(profile, candidate, parsed)
        self.assertEqual(closure['projectClosure'], ['QuantumBlockEncoding.P',
                                                    'QuantumBlockEncoding.A', 'QuantumBlockEncoding.B'])
        self.assertEqual(closure['providers'], ['QuantumBlockEncoding.P'])
        self.assertEqual(closure['targetDependencies']['QuantumBlockEncoding.B'], ['QuantumBlockEncoding.A'])
        self.assertEqual(closure['externalImports'][0]['imports'][:2], INIT)

    def test_parser_stream_binding_and_flag_negative_cases(self):
        _, _, request, graph = tiny()
        cases = [lambda s: s[0][1].update(sha256='0' * 64),
            lambda s: s[0][1].update(snapshotPath='$WRONG'),
            lambda s: s[0][1].update(ordinal=2),
            lambda s: s[0][1].update(bytes=True),
            lambda s: s[0][1].update(parseMessages=1),
            lambda s: s[0][1].update(hasParseErrors=True),
            lambda s: s[0][1]['imports'][0].pop('isMeta'),
            lambda s: s[0][1]['imports'][0].update(isMeta=1),
            lambda s: s[0][1]['imports'][0].update(unknownFlag=False),
            lambda s: s[0][1].update(nativeAccepted=True),
            lambda s: s[-1][1].update(candidateCount=999)]
        for index, mutate in enumerate(cases):
            with self.subTest(index=index), self.assertRaises(ValueError):
                stream = parser_fixture(request, 'd' * 64, graph); mutate(stream)
                d.validate_parser_output(a.dump(stream), request, 'd' * 64, 0, False, v)
        for code, timeout in ((1, False), (0, True), (True, False)):
            with self.assertRaises(ValueError):
                d.validate_parser_output(a.dump(parser_fixture(request, 'd' * 64, graph)),
                    request, 'd' * 64, code, timeout, v)
        stream = parser_fixture(request, 'd' * 64, graph)
        for bad in (a.dump(stream[:-1]), a.dump(stream + [stream[-1]]),
                    a.dump(stream) + 'warning unexpected\n'):
            with self.assertRaises(ValueError):
                d.validate_parser_output(bad, request, 'd' * 64, 0, False, v)

    def test_cycles_missing_project_import_and_target_order_rejected(self):
        profile, candidate, request, graph = tiny()
        for changed in ({'QuantumBlockEncoding.P': INIT + [imp('QuantumBlockEncoding.A')]},
                        {'QuantumBlockEncoding.P': INIT + [imp('QuantumBlockEncoding.Missing')]},
                        {'QuantumBlockEncoding.A': INIT + [imp('QuantumBlockEncoding.B')],
                         'QuantumBlockEncoding.B': INIT}):
            parsed, _ = d.validate_parser_output(a.dump(parser_fixture(request, 'd' * 64, graph | changed)),
                request, 'd' * 64, 0, False, v)
            with self.assertRaises(ValueError): d.derive_closure(profile, candidate, parsed)

    def test_no_python_lean_parser_or_unimplemented_producer(self):
        source = (HERE / 'discovery.py').read_text(encoding='utf-8')
        self.assertNotIn('NotImplementedError', source)
        self.assertNotIn('re.findall', source)
        parser = (HERE / 'Parser.lean').read_text(encoding='utf-8')
        self.assertEqual([line for line in parser.splitlines() if line.startswith('import ')], ['import Lean'])
        self.assertIn('Lean.Elab.parseImports input', parser)

    def test_candidate_source_membership_and_copy_mutations_rejected(self):
        with tempfile.TemporaryDirectory(prefix='SYNTHETIC-c34-', dir=HERE) as directory:
            root = Path(directory); source = root / 'QuantumBlockEncoding/A.lean'
            source.parent.mkdir(); source.write_bytes(b'-- SYNTHETIC CANDIDATE\n')
            row = dict(module='QuantumBlockEncoding.A', relativePath='QuantumBlockEncoding/A.lean',
                       sha256=b.sha(source), bytes=source.stat().st_size)
            candidate = dict(schema='C34_FROZEN_PROJECT_CANDIDATES_V2',
                scopes=dict(directoryRoots=['QuantumBlockEncoding'], rootFiles=[]), files=[row])
            profile = dict(candidateSourceScopes=candidate['scopes'],
                           modules=[dict(module=row['module'], rawSHA256=row['sha256'])])
            d.check_candidates(root, candidate, profile, b)
            extra = source.parent / 'Added.lean'; extra.write_bytes(b'-- EXTRA\n')
            with self.assertRaises(ValueError): d.check_candidates(root, candidate, profile, b)
            extra.unlink()
            source.write_bytes(b'-- CHANGED SYNTHETIC CANDIDATE\n')
            with self.assertRaises(ValueError): d.check_candidates(root, candidate, profile, b)


class SyntheticAPI:
    """Uses shared file/receipt utilities, replaces native_call with SYNTHETIC IO only."""
    def __init__(self, actual, prefix, profile, graph):
        self.actual, self.prefix, self.profile, self.graph = actual, prefix, profile, graph
        self.calls = []
        self.mutate_after_parser = None

    def __getattr__(self, name):
        return getattr(self.actual, name)

    def native_call(self, private, label, argv, cwd, env, timeout):
        self.calls.append((label, timeout))
        stdout = ''
        if label == '01-prefix': stdout = str(self.prefix) + '\n'
        elif label == '02-help': stdout = 'Lean (version 4.33.0, SYNTHETIC_NOT_EXECUTED) --threads --memory --print-prefix\n'
        elif label == '04-parser-observe':
            request = v.loads(Path(argv[-1]).read_text(encoding='utf-8'))
            stdout = a.dump(parser_fixture(request, env['C34_PARSER_REQUEST_SHA256'], self.graph))
            if self.mutate_after_parser: self.mutate_after_parser(request)
        elif label == '30-observe':
            stream = a.fixture(self.profile)
            for tag, row in stream:
                if tag in ('C34_BINDING_JSON', 'C34_SUMMARY_JSON'):
                    row.update(profileSHA256=env['C34_PROFILE_SHA256'], cohortID=env['C34_COHORT_ID'])
                if tag == 'C34_BINDING_JSON':
                    row['resolvedOleanPath'] = str(Path(env['C34_FRESH_ROOT']) /
                                                  (row['module'].replace('.', '/') + '.olean'))
            stdout = a.dump(stream)
        elif '-o' in argv:
            output = Path(argv[argv.index('-o') + 1]); output.parent.mkdir(parents=True, exist_ok=True)
            output.write_bytes(('SYNTHETIC_NOT_EXECUTED_' + label).encode())
        else: raise AssertionError('unexpected synthetic native stage ' + label)
        (private / (label + '.stdout.raw')).write_bytes(stdout.encode('utf-8'))
        (private / (label + '.stderr.raw')).write_bytes(b'')
        self.actual.write_json(private / (label + '.setup.json'), dict(
            synthetic=True, argv=list(argv), cwd=str(cwd), timeoutSeconds=timeout))
        self.actual.write_json(private / (label + '.started.json'), dict(synthetic=True, PID=424242))
        result = dict(synthetic=True, PID=424242, exitCode=0, timedOut=False,
            stdoutSHA256=b.sha(private / (label + '.stdout.raw')),
            stderrSHA256=b.sha(private / (label + '.stderr.raw')),
            startedUTC='2026-10-17T00:00:00+00:00', finishedUTC='2026-10-17T00:00:00+00:00', wallSeconds=0.0)
        self.actual.write_json(private / (label + '.result.json'), result)
        return result


class SyntheticPipelineTests(unittest.TestCase):
    def setup_pipeline(self, directory):
        root = Path(directory)
        project = root / 'project'; project.mkdir()
        package = root / 'package'; package.mkdir()
        profile = deepcopy(PROFILE)
        profile['candidateSourceScopes'] = dict(directoryRoots=['QuantumBlockEncoding'], rootFiles=[])
        for path in profile['projectInputs']:
            destination = project / path; destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(PROJECT / path, destination)
        provider_name = 'QuantumBlockEncoding.SyntheticProvider'
        provider = project / (provider_name.replace('.', '/') + '.lean')
        provider.write_bytes(b'-- SYNTHETIC PROVIDER FOR CONTROLLER TEST ONLY\n')
        inherited = project / '.lake/build/lib/lean' / (provider_name.replace('.', '/') + '.olean')
        inherited.parent.mkdir(parents=True); inherited.write_bytes(b'SYNTHETIC_INHERITED_PROVIDER')
        candidate_rows = [dict(module=p.relative_to(project).as_posix()[:-5].replace('/', '.'),
            relativePath=p.relative_to(project).as_posix(), sha256=b.sha(p), bytes=p.stat().st_size)
            for p in sorted((project / 'QuantumBlockEncoding').glob('*.lean'))]
        candidate = dict(schema='C34_FROZEN_PROJECT_CANDIDATES_V2', scopes=profile['candidateSourceScopes'],
                         files=candidate_rows, **v.NO_ACCEPT)
        for name in ('bindings.py', 'validator.py', 'discovery.py', 'runner.py', 'Collector.lean', 'Parser.lean',
                     'pending-drivers/Profile.lean', 'pending-drivers/Probe.lean', 'resource_adapter.py',
                     'resource-chain.json', 'resource-vendor/resource_common.py',
                     'resource-vendor/resource_gate_v4.py', 'resource-vendor/callback_v2.py'):
            path = package / name; path.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(HERE / name, path)
        (package / 'profile.json').write_text(json.dumps(profile), encoding='utf-8')
        (package / 'candidate-sources.json').write_text(json.dumps(candidate), encoding='utf-8')
        files = {p.relative_to(package).as_posix(): b.sha(p) for p in package.rglob('*') if p.is_file()}
        manifest = dict(files=files)
        (package / 'package-bindings.json').write_text(json.dumps(manifest), encoding='utf-8')
        prefix = root / 'toolchain'; (prefix / 'bin').mkdir(parents=True)
        (prefix / 'bin/lean').write_bytes(b'SYNTHETIC_TOOLCHAIN_NOT_EXECUTABLE')
        (prefix / 'lib/lean').mkdir(parents=True)
        actual, shared = b.load_shared(PROJECT, profile)
        targets = [m['module'] for m in profile['modules']]
        graph = {targets[0]: INIT + [imp(provider_name)], targets[1]: INIT,
                 targets[2]: INIT + [imp(targets[0]), imp(targets[1]), imp(provider_name)],
                 provider_name: INIT + [imp('Mathlib.SyntheticExternal')]}
        api = SyntheticAPI(actual, prefix, profile, graph)
        rt = runner.Runtime(project, package, profile, manifest, b, v, d,
                            dict(synthetic=True), api, shared)
        rt.env['LEAN_PATH'] = os.pathsep.join([str(project / '.lake/build/lib/lean'), str(prefix / 'lib/lean')])
        rt.resource_guard, _ = resource_adapter.bind(rt)
        gate = rt.resource_guard.gate
        rt.resource_guard.callback.sampler = lambda: resource_fixtures.snapshot(gate)
        return rt, api, prefix

    def test_end_to_end_discovery_fresh_57_flow_synthetic_no_native(self):
        with tempfile.TemporaryDirectory(prefix='SYNTHETIC-c34-', dir=HERE) as directory:
            rt, api, prefix = self.setup_pipeline(directory)
            with patch.object(runner.shutil, 'which', return_value=str(prefix / 'bin/lean')):
                rt.prepare_toolchain_and_providers()
                discovery = d.discover_project_providers(rt)
                self.assertEqual(discovery['providers'], ['QuantumBlockEncoding.SyntheticProvider'])
                checked = runner.execute_fresh_observation(rt)
            self.assertEqual(checked['roots'], 57)
            self.assertEqual(checked['generated'], 0)
            self.assertIs(checked['nativeAccepted'], False)
            self.assertEqual([label for label, _ in api.calls], ['01-prefix', '02-help',
                '03-parser-compile', '04-parser-observe', '11-target', '12-target', '13-target',
                '21-driver', '22-driver', '30-observe'])
            self.assertEqual([timeout for _, timeout in api.calls], [30, 30, 120, 30, 600, 600, 600, 120, 120, 300])
            rt.revalidate()
            rt.api.export_public(rt.private, rt.public, rt.logical)
            self.assertTrue((rt.public / 'raw-derivation-receipts.json').is_file())

    def test_snapshot_mutation_during_parser_is_rejected(self):
        with tempfile.TemporaryDirectory(prefix='SYNTHETIC-c34-', dir=HERE) as directory:
            rt, api, prefix = self.setup_pipeline(directory)
            api.mutate_after_parser = lambda request: Path(request['candidates'][0]['snapshotPath']).write_bytes(b'MUTATED')
            with patch.object(runner.shutil, 'which', return_value=str(prefix / 'bin/lean')):
                rt.prepare_toolchain_and_providers()
                with self.assertRaises(ValueError): d.discover_project_providers(rt)
            self.assertNotIn('11-target', [label for label, _ in api.calls])

    def test_handwritten_provider_result_is_not_an_input_and_tamper_fails(self):
        with tempfile.TemporaryDirectory(prefix='SYNTHETIC-c34-', dir=HERE) as directory:
            rt, api, prefix = self.setup_pipeline(directory)
            with self.assertRaises(TypeError): runner.execute_fresh_observation(rt, {'providers': []})
            with patch.object(runner.shutil, 'which', return_value=str(prefix / 'bin/lean')):
                rt.prepare_toolchain_and_providers()
                d.discover_project_providers(rt)
                saved = rt.private / 'compiler-discovery.json'
                value = v.loads(saved.read_text(encoding='utf-8')); value['providers'] = []
                saved.write_text(json.dumps(value), encoding='utf-8')
                with self.assertRaises(ValueError): runner.execute_fresh_observation(rt)
            self.assertNotIn('11-target', [label for label, _ in api.calls])

    def test_reviewed_full_packet_gate_accepts_only_exact_sealed_bytes(self):
        with tempfile.TemporaryDirectory(prefix='SYNTHETIC-c34-', dir=HERE) as directory:
            root = Path(directory)
            payload = root / 'payload.txt'; payload.write_bytes(b'SYNTHETIC REVIEW GATE')
            seal = root / 'packet-seal.json'
            seal.write_text(json.dumps(dict(files=[dict(path='payload.txt', sha256=b.sha(payload),
                                                       bytes=payload.stat().st_size)])), encoding='utf-8')
            digest = b.sha(seal)
            with patch.object(runner.sys, 'platform', 'linux'), patch.dict(runner.os.environ,
                    dict(GITHUB_ACTIONS='true', RUNNER_ENVIRONMENT='github-hosted')):
                runner.require_future_ci(root, digest, True)
                with self.assertRaises(ValueError): runner.require_future_ci(root, '0' * 64, True)
                payload.write_bytes(b'TAMPERED')
                with self.assertRaises(ValueError): runner.require_future_ci(root, digest, True)


if __name__ == '__main__':
    unittest.main(verbosity=2)
