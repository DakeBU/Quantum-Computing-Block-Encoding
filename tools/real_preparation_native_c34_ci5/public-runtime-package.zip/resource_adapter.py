"""CI5 thin adapter: exact C31 CI4 gate + exact CI2 receipt callback; no capacity fallback."""
import importlib.util
import json
from pathlib import Path
import sys

CONTRACT = 'C34_CI5_FINITE_GATED_5120_V1'
CAPS = {'01-prefix': 30, '02-help': 30, '03-parser-compile': 120, '04-parser-observe': 30,
        '11-target': 600, '12-target': 600, '13-target': 600,
        '21-driver': 120, '22-driver': 120, '30-observe': 300}
TARGETS = {'11-target', '12-target', '13-target'}


def strict_argv(argv):
    """No rewrite: profile and every actual command already declare the current 5120 budget."""
    argv = list(map(str, argv))
    if not argv or [a for a in argv if a.startswith('--memory')] != ['--memory=5120'] or \
            [a for a in argv if a.startswith('--threads')] != ['--threads=1'] or \
            any(a.startswith(('-M', '-j')) for a in argv):
        raise ValueError('CI5 exact memory/thread budget drift; NO_CHILD_STARTED')
    return argv


def load(package, relative, files, b, name):
    module, binding = b.load_pinned(b.child(package, relative), files[relative], name)
    return module, binding


class Guard:
    contract = CONTRACT

    def __init__(self, rt, callback, gate, bindings):
        self.rt, self.callback, self.gate, self.bindings = rt, callback, gate, bindings

    def __call__(self, private, label, argv, cwd, env, timeout):
        self.rt.b.check_envelope(self.rt.profile)
        if label not in CAPS or type(timeout) not in (int, float) or not 0 < timeout <= CAPS[label]:
            raise ValueError('unknown stage or timeout budget drift; NO_CHILD_STARTED')
        # Gate's preflight/receipts remain responsible for accepting the actual job headroom.
        # Reject wrong-stage scheduling before reaching any native callback.
        if list(map(str, argv)).count('-DElab.async=false') != (1 if label in TARGETS else 0):
            raise ValueError('fresh-target serial flag partition drift; NO_CHILD_STARTED')
        return self.callback(private, label, argv, cwd, env, timeout=timeout)


def bind(rt, sampler=None):
    """Production passes no sampler: only real self/procfs reads. Injection is Python fixture-only."""
    files, b = rt.manifest['files'], rt.b
    chain_path = b.child(rt.package, 'resource-chain.json')
    chain = rt.v.loads(chain_path.read_text(encoding='utf-8'))
    for relative, row in chain['files'].items():
        if files.get(relative) != row['sha256'] or b.sha(b.child(rt.package, relative)) != row['sha256']:
            raise ValueError('exact reused resource source drift')
    common, common_binding = load(rt.package, 'resource-vendor/resource_common.py', files, b,
                                  'c34_ci5_resource_common')
    gate, gate_binding = load(rt.package, 'resource-vendor/resource_gate_v4.py', files, b,
                              'c34_ci5_resource_gate_v4')
    gate.bind_common(common)
    # The reused callback imports its historical common-module name. Supply only our exact
    # pinned common copy during that import, then restore the process module table.
    old = sys.modules.get('resource_gate')
    sys.modules['resource_gate'] = common
    try:
        prior, callback_binding = load(rt.package, 'resource-vendor/callback_v2.py', files, b,
                                        'c34_ci5_reused_callback_v2')
    finally:
        if old is None:
            del sys.modules['resource_gate']
        else:
            sys.modules['resource_gate'] = old
    prior.gate = gate
    prior.rewrite_argv = strict_argv
    binding = dict(contract=CONTRACT, profileSHA256=rt.profile_sha,
        packageManifestSHA256=rt.manifest_sha, runID=rt.run_id,
        resourceSourceChainSHA256=b.sha(chain_path), candidateMemoryMiB=5120, reserveMiB=2048,
        requiredHeadroomBytes=7168 * 1024**2, namespacePolicy='SELF_ONLY_RESERVED_INIT_V1',
        PID1ReadRequested=False, loadedModules=[common_binding, gate_binding, callback_binding],
        rawActualContext=common.actual_context(), **rt.v.NO_ACCEPT)
    callback = prior.BudgetCallback(rt.api, rt.revalidate, binding,
                                   sampler=gate.sample if sampler is None else sampler)
    return Guard(rt, callback, gate, binding), binding
