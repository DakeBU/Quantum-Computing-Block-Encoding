"""C34 thin binding/driver adapter. Reuses pinned shared process/receipt helpers."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PureWindowsPath
import re
import shutil
import sys
import time

SHARED_REL = 'tools/cubic_c29_diagnostic/runner.py'
SIDECARS = ('.olean', '.olean.private', '.olean.server', '.ir')


def sha(path):
    with Path(path).open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def child(root, relative):
    root = Path(root).resolve()
    normalized = relative.replace('\\', '/')
    if (not normalized or normalized.startswith('/') or PureWindowsPath(relative).is_absolute()
            or ':' in normalized or any(p in ('', '..') for p in normalized.split('/'))):
        raise ValueError('unsafe relative path')
    path = root.joinpath(*normalized.split('/'))
    if not path.resolve().is_relative_to(root):
        raise ValueError('resolved path escapes root')
    return path


def verify_files(package, files):
    if type(files) is not dict or not files:
        raise ValueError('empty package files')
    rows = []
    for relative, expected in files.items():
        path = child(package, relative)
        if not re.fullmatch('[0-9a-f]{64}', expected) or sha(path) != expected:
            raise ValueError('sealed file digest drift: ' + relative)
        rows.append(dict(path=str(path.resolve()), sha256=expected))
    return rows


def load_pinned(path, expected, label):
    path = Path(path).resolve()
    if sha(path) != expected:
        raise ValueError('executable module digest mismatch')
    spec = importlib.util.spec_from_file_location(label, path)
    if spec is None or spec.loader is None:
        raise ValueError('no file loader')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if Path(module.__file__).resolve() != path or sha(path) != expected:
        raise ValueError('executed module path/digest drift')
    return module, dict(path=str(path), sha256=expected)


def load_shared(project, profile):
    entry = profile['sharedInstrumentation']
    if entry['path'] != SHARED_REL:
        raise ValueError('unexpected instrumentation path')
    return load_pinned(child(project, SHARED_REL), entry['sha256'], 'c34_shared_receipts')


def copy_bound(source, destination, expected):
    source, destination = Path(source).resolve(), Path(destination)
    if source == destination.resolve() or destination.exists() or destination.is_symlink():
        raise FileExistsError('copy destination already present or aliases source')
    before = sha(source)
    if before != expected:
        raise ValueError('copy source differs from seal')
    destination.parent.mkdir(parents=True, exist_ok=True)
    with source.open('rb') as src, destination.open('xb') as dst:
        shutil.copyfileobj(src, dst)
    row = dict(sourceRealPath=str(source), destinationRealPath=str(destination.resolve()),
               sha256=expected, sourceSHA256Before=before,
               destinationSHA256Before=sha(destination), sourceSHA256After=sha(source),
               destinationSHA256After=sha(destination))
    recheck_copy(row)
    return row


def recheck_copy(row):
    if (sha(row['sourceRealPath']) != row['sha256'] or
            sha(row['destinationRealPath']) != row['sha256'] or
            any(row[k] != row['sha256'] for k in ('sourceSHA256Before',
                'destinationSHA256Before', 'sourceSHA256After', 'destinationSHA256After'))):
        raise ValueError('source/destination copy binding drift')


def render_texts(profile):
    targets = [m['module'] for m in profile['modules']]
    lines = ['import Collector', 'namespace C34Native',
             'def targets : Array Lean.Name := #[' + ', '.join('`' + m for m in targets) + ']',
             'def roots : Array RootSpec := #[']
    for root in profile['roots']:
        module, name, kind = root['module'], root['sourceUserName'], root['sourceKind']
        if any(not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_.]*', x) for x in (module, name)):
            raise ValueError('nonliteral source identifier')
        if kind not in ('def', 'theorem'):
            raise ValueError('unsupported C34 source kind')
        lines.append('  { targetModule := `' + module + ', userName := `' + name +
                     ', privateRoot := ' + str(root['sourcePrivate']).lower() +
                     ', sourceKind := ' + json.dumps(kind) + ' },')
    lines += [']', 'end C34Native']
    probe = ['import ' + m for m in targets] + ['import Profile']
    for option in ('pp.deepTerms', 'pp.proofs', 'pp.explicit', 'pp.universes', 'pp.fullNames',
                   'pp.privateNames', 'pp.funBinderTypes', 'pp.piBinderTypes'):
        probe.append('set_option ' + option + ' true')
    probe += ['set_option pp.notation false', 'set_option pp.maxSteps 2000000',
              'set_option maxRecDepth 10000', 'set_option maxHeartbeats 20000000',
              'run_cmd C34Native.collect C34Native.targets C34Native.roots']
    return {'Profile.lean': '\n'.join(lines) + '\n', 'Probe.lean': '\n'.join(probe) + '\n'}


def bind_drivers(package, driver, profile, files):
    """Exact collector AND rendered/frozen driver source/destination receipts."""
    rows = []
    rows.append(copy_bound(child(package, 'Collector.lean'), child(driver, 'Collector.lean'),
                           files['Collector.lean']))
    for name, text in render_texts(profile).items():
        frozen = child(package, 'pending-drivers/' + name)
        expected = files['pending-drivers/' + name]
        if sha(frozen) != expected or frozen.read_bytes() != text.encode('utf-8'):
            raise ValueError('own frozen driver rendering differs')
        rows.append(copy_bound(frozen, child(driver, name), expected))
    return rows


def copy_providers(project, fresh, modules, target_modules):
    if len(modules) != len(set(modules)) or set(modules).intersection(target_modules):
        raise ValueError('duplicate/target inherited project provider')
    copies, missing = [], []
    for module in modules:
        if not re.fullmatch(r'QuantumBlockEncoding\.[A-Za-z_][A-Za-z0-9_.]*', module):
            raise ValueError('nonproject provider')
        stem = module.replace('.', '/')
        for suffix in SIDECARS:
            source = child(project, '.lake/build/lib/lean/' + stem + suffix)
            if not source.is_file():
                if suffix == '.olean':
                    raise FileNotFoundError('missing inherited project provider ' + module)
                missing.append(dict(module=module, suffix=suffix, absentPath=str(source.resolve())))
                continue
            copies.append(copy_bound(source, child(fresh, stem + suffix), sha(source)))
    return copies, missing


def recheck_missing(rows):
    if any(Path(row['absentPath']).exists() for row in rows):
        raise ValueError('previously absent provider sidecar appeared')


def reject_target_fallback(roots, modules):
    for root in roots:
        for module in modules:
            for suffix in SIDECARS:
                path = child(root, module.replace('.', '/') + suffix)
                if path.exists() or path.is_symlink():
                    raise ValueError('external target fallback artifact present')


class Deadline:
    def __init__(self, seconds=2100, clock=time.monotonic):
        self.clock, self.end = clock, clock() + seconds

    def remaining(self, stage_cap):
        remaining = int(self.end - self.clock())
        if remaining <= 0:
            raise TimeoutError('whole-job deadline reached; no retry/escalation')
        return min(stage_cap, remaining)


def check_envelope(profile):
    expected = dict(host='linux-github-hosted', threads=1, memoryMiB=5120,
        targetTimeoutSeconds=600, driverTimeoutSeconds=120, observeTimeoutSeconds=300,
        parserCompileTimeoutSeconds=120, parserObserveTimeoutSeconds=30,
        discoveryTimeoutSeconds=30, wholeJobTimeoutSeconds=2100, automaticRetries=0,
        automaticBudgetEscalation=False, authorization='PROPOSAL_ONLY_PARENT_REVIEW_REQUIRED',
        version='C34_CI5_FINITE_GATED_5120_V1', reserveMiB=2048, requiredHeadroomMiB=7168,
        resourceSchema='C31_CI4_RESOURCE_SELF_NAMESPACE_V1', namespacePolicy='SELF_ONLY_RESERVED_INIT_V1')
    if profile.get('envelope') != expected:
        raise ValueError('finite CI proposal envelope differs')
    return expected
