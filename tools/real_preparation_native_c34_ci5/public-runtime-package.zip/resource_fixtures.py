"""Synthetic procfs bytes only; never capacity evidence for an actual job."""
CONTEXT = dict(platform='linux', CI='true', GITHUB_ACTIONS='true', RUNNER_OS='Linux',
    GITHUB_RUN_ID='123456', GITHUB_JOB='SYNTHETIC_C34_CI5_NOT_HARDWARE', GITHUB_SHA='a'*40)
MOUNT = '/sys/fs/cgroup'


def files(mib=1024**2):
    rows = {'/proc/meminfo': 'MemAvailable: 12582912 kB\n', '/proc/self/cgroup': '0::/parent/job\n',
        '/proc/self/mountinfo': '31 20 0:27 / /sys/fs/cgroup rw - cgroup2 cgroup rw\n',
        MOUNT+'/cgroup.controllers': 'cpuset cpu io memory pids\n', MOUNT+'/cgroup.procs': '1\n2\n'}
    for name in ('/parent/job', '/parent'):
        rows[MOUNT+name+'/memory.max'] = 'max\n'
        rows[MOUNT+name+'/memory.current'] = str(1024*mib)+'\n'
        rows[MOUNT+name+'/memory.events'] = 'low 0\nhigh 0\nmax 0\noom 0\noom_kill 0\n'
    return {k: v.encode('ascii') for k, v in rows.items()}


def snapshot(gate, data=None, namespace=None, context=None):
    data = files() if data is None else data
    def link(path):
        if path != '/proc/self/ns/cgroup':
            raise AssertionError('PID1 or other namespace read forbidden')
        return 'cgroup:[4026531835]' if namespace is None else namespace
    return gate.sample(context=CONTEXT if context is None else context,
                       read_bytes=lambda path: data[path], read_link=link)
