"""C34 v2 future hosted-CI runner. No local native execution authorization."""
import argparse
import hashlib
import importlib.util
import json
import os
import re
import shutil
from pathlib import Path
import sys
import uuid

READY_FOR_CI = True
OUT_REL = '_out/real-preparation-native-c34-implement-v2'


def digest(path):
    with Path(path).open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def read_unique(path):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('duplicate JSON key')
            result[key] = value
        return result
    def bad_constant(value):
        raise ValueError('nonfinite JSON ' + value)
    return json.loads(Path(path).read_text(encoding='utf-8'), object_pairs_hook=pairs,
                      parse_constant=bad_constant)


def bootstrap(package, actual_entry=None, argv_entry=None, approved_files=None):
    """Verify actual entry and every package file BEFORE task-specific imports."""
    package = Path(package).resolve()
    manifest_path = package / 'package-bindings.json'
    manifest = read_unique(manifest_path)
    if approved_files is not None and digest(manifest_path) != approved_files.get('package-bindings.json'):
        raise ValueError('bootstrap manifest differs from externally approved packet')
    files = manifest['files']
    actual = Path(actual_entry or __file__).resolve()
    argv = Path(argv_entry if argv_entry is not None else sys.argv[0]).resolve()
    if actual != package / 'runner.py' or argv != actual:
        raise ValueError('actual entry/argv file differs from frozen entry')
    if digest(actual) != files.get('runner.py'):
        raise ValueError('executing entry digest drift')
    for relative, expected in files.items():
        if ('\\' in relative or ':' in relative or relative.startswith('/') or
                any(p in ('', '..') for p in relative.split('/'))):
            raise ValueError('unsafe package binding path')
        path = (package / relative).resolve()
        if not path.is_relative_to(package) or digest(path) != expected:
            raise ValueError('package file changed before executable import')
        if approved_files is not None and expected != approved_files.get(relative):
            raise ValueError('executable/package source differs from approved seal')
    required = {'runner.py', 'bindings.py', 'validator.py', 'Collector.lean', 'profile.json',
                'pending-drivers/Profile.lean', 'pending-drivers/Probe.lean',
                'discovery.py', 'Parser.lean', 'candidate-sources.json'}
    if not required.issubset(files):
        raise ValueError('required executable/driver binding missing')
    def load(name):
        path = package / (name + '.py')
        spec = importlib.util.spec_from_file_location('c34_' + name, path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        if Path(module.__file__).resolve() != path or digest(path) != files[name + '.py']:
            raise ValueError('executed module identity drift')
        return module
    bindings, validator, discovery = load('bindings'), load('validator'), load('discovery')
    bindings.verify_files(package, files)
    profile = read_unique(package / 'profile.json')
    validator.validate_profile(profile)
    bindings.check_envelope(profile)
    receipt = dict(actualEntryRealPath=str(actual), argvEntryRealPath=str(argv),
        actualEntrySHA256=digest(actual), wrapperPID=os.getpid(), argv=list(sys.argv),
        cwd=str(Path.cwd().resolve()), pythonExecutable=str(Path(sys.executable).resolve()),
        pythonExecutableSHA256=digest(sys.executable), packageManifestSHA256=digest(manifest_path),
        loadedModules=[dict(path=str(package / (n + '.py')), sha256=files[n + '.py'])
                       for n in ('bindings', 'validator', 'discovery')])
    return profile, manifest, bindings, validator, discovery, receipt


def require_future_ci(package, approved_sha, ci):
    """Check hosted CI and externally reviewed full packet BEFORE executable imports."""
    if not ci or sys.platform != 'linux' or os.environ.get('GITHUB_ACTIONS') != 'true' or \
            os.environ.get('RUNNER_ENVIRONMENT') != 'github-hosted':
        raise RuntimeError('native entry requires explicitly selected future Linux hosted CI')
    if not isinstance(approved_sha, str) or not re.fullmatch('[0-9a-f]{64}', approved_sha):
        raise ValueError('externally approved immutable packet seal SHA256 required')
    package = Path(package).resolve()
    seal = package / 'packet-seal.json'
    if digest(seal) != approved_sha:
        raise ValueError('reviewed packet seal differs')
    for row in read_unique(seal)['files']:
        relative = row['path']
        if ('\\' in relative or ':' in relative or relative.startswith('/') or
                any(p in ('', '..') for p in relative.split('/'))):
            raise ValueError('unsafe packet seal path')
        path = (package / relative).resolve()
        if not path.is_relative_to(package) or path.stat().st_size != row['bytes'] or \
                digest(path) != row['sha256']:
            raise ValueError('reviewed packet payload drift')
    return {row['path']: row['sha256'] for row in read_unique(seal)['files']}


class Runtime:
    def __init__(self, project, package, profile, manifest, b, v, d, entry, api, shared):
        self.project, self.package = Path(project).resolve(), Path(package).resolve()
        self.profile, self.manifest, self.b, self.v, self.d = profile, manifest, b, v, d
        self.entry, self.api, self.shared = entry, api, shared
        self.profile_sha = b.sha(self.package / 'profile.json')
        self.manifest_sha = b.sha(self.package / 'package-bindings.json')
        self.run_id = uuid.uuid4().hex
        self.deadline = b.Deadline(profile['envelope']['wholeJobTimeoutSeconds'])
        self.source_pins = dict(profile['projectInputs'])
        self.copies, self.artifacts, self.missing, self.absent = [], [], [], []
        self.stage_receipts, self.external, self.candidate = {}, [], None
        self.env = dict(os.environ)
        self.out = api.safe_child(self.project, OUT_REL)
        self.out.mkdir(parents=True, exist_ok=False)
        self.private = self.out / 'private'; self.private.mkdir(mode=0o700)
        self.public = self.out / 'public'; self.public.mkdir()
        self.logical = {str(self.project): '$PROJECT', str(self.package): '$PROFILE_PACKAGE'}
        self.lean = None

    def bind_artifact(self, path):
        path = Path(path).absolute()
        row = dict(path=str(path), realPath=str(path.resolve()), sha256=self.b.sha(path))
        previous = next((r for r in self.artifacts if r['path'] == row['path']), None)
        if previous is not None:
            if previous != row:
                raise ValueError('previously bound runtime artifact changed')
            return previous
        self.artifacts.append(row)
        return row

    def write(self, name, value):
        path = self.b.child(self.private, name)
        self.api.write_json(path, value)
        self.bind_artifact(path)
        return path

    def revalidate(self):
        self.deadline.remaining(1)
        self.b.verify_files(self.package, self.manifest['files'])
        if self.b.sha(self.package / 'package-bindings.json') != self.manifest_sha:
            raise ValueError('package manifest drift')
        self.api.verify_pins(self.project, self.source_pins)
        if self.b.sha(self.shared['path']) != self.shared['sha256']:
            raise ValueError('executed shared process helper drift')
        if self.candidate is not None:
            self.d.check_candidates(self.project, self.candidate, self.profile, self.b)
        for row in self.copies:
            self.b.recheck_copy(row)
        self.b.recheck_missing(self.missing)
        for row in self.artifacts:
            path = Path(row['path'])
            if str(path.resolve()) != row['realPath'] or self.b.sha(path) != row['sha256']:
                raise ValueError('runtime entry/provider/receipt/cohort artifact drift')
        if any(p.exists() for p in self.absent):
            raise ValueError('previously absent search root appeared')
        if self.external:
            self.b.reject_target_fallback(self.external, [m['module'] for m in self.profile['modules']])

    def call(self, label, argv, cwd, cap, env=None):
        self.revalidate()
        selected_env = self.env if env is None else env
        timeout = self.deadline.remaining(cap)
        self.write(label + '-invocation.json', dict(argv=list(map(str, argv)), cwd=str(Path(cwd).resolve()),
            selectedEnvironment={k: value for k, value in selected_env.items()
                if k == 'LEAN_PATH' or k.startswith('C34_')},
            timeoutSeconds=timeout, requestedStageCapSeconds=cap, wrapperPID=os.getpid(),
            profileSHA256=self.profile_sha, runID=self.run_id, **self.v.NO_ACCEPT))
        try:
            result = self.api.native_call(self.private, label, argv, cwd, selected_env, timeout=timeout)
        finally:
            rows = []
            for suffix in ('.setup.json', '.started.json', '.result.json', '.stdout.raw', '.stderr.raw'):
                path = self.private / (label + suffix)
                if path.is_file():
                    rows.append(self.bind_artifact(path))
            self.stage_receipts[label] = rows
        self.revalidate()
        return result

    def prepare_toolchain_and_providers(self):
        self.write('entry-bindings.json', dict(entry=self.entry, sharedInstrumentation=self.shared,
                                             **self.v.NO_ACCEPT))
        bootstrap_path = shutil.which('lean', path=self.env.get('PATH'))
        if not bootstrap_path:
            raise FileNotFoundError('Lean bootstrap absent from explicit CI PATH')
        bootstrap_binding = self.bind_artifact(bootstrap_path)
        self.call('01-prefix', [bootstrap_path, '--print-prefix'], self.project, 30)
        text = (self.private / '01-prefix.stdout.raw').read_text(encoding='utf-8', errors='strict')
        if len(text.strip().splitlines()) != 1 or not Path(text.strip()).is_absolute():
            raise ValueError('actual Lean prefix output not a single absolute path')
        prefix = Path(text.strip()).resolve()
        self.lean = prefix / 'bin' / 'lean'
        lean_binding = self.bind_artifact(self.lean)
        self.logical[str(prefix)] = '$TOOLCHAIN'
        self.call('02-help', [str(self.lean), '--help'], self.project, 30)
        self.api.verify_lean_help((self.private / '02-help.stdout.raw').read_text(encoding='utf-8'))
        raw = self.env.get('LEAN_PATH', '').split(os.pathsep)
        if not raw or any(not value for value in raw):
            raise ValueError('explicit nonempty inherited CI LEAN_PATH required')
        original = [(Path(p) if Path(p).is_absolute() else self.project / p).resolve() for p in raw]
        removed = {self.project, (self.project / '.lake/build/lib/lean').resolve()}
        self.external = list(dict.fromkeys([p for p in original if p not in removed] + [prefix / 'lib/lean']))
        for root in self.external:
            if root.is_relative_to(self.project) and not root.is_relative_to(self.project / '.lake/packages'):
                raise ValueError('alternate project-local fallback search root')
        self.b.reject_target_fallback(self.external, [m['module'] for m in self.profile['modules']])
        native_roots = list(dict.fromkeys(self.external + [prefix / 'lib']))
        present, self.absent = self.api.partition_search_roots(native_roots)
        provider_rows = self.api.inventory_providers(present, self.out)
        for row in provider_rows:
            bound = self.bind_artifact(row['path'])
            if bound['sha256'] != row['sha256']:
                raise ValueError('provider inventory changed while binding')
        for ordinal, root in enumerate(native_roots):
            self.logical.setdefault(str(root), '$SEARCH_ROOT_' + str(ordinal))
        self.write('provider-inventory.json', dict(mode='POTENTIAL_ARTIFACTS_NOT_ACTUAL_LOAD_TRACE',
            roots=list(map(str, native_roots)), absentConfiguredRoots=list(map(str, self.absent)),
            artifacts=provider_rows, bootstrap=bootstrap_binding, actualLean=lean_binding,
            cleanTransitive=False, nativeTCBReviewed=False, **self.v.NO_ACCEPT))
        self.revalidate()


def execute_fresh_observation(rt):
    b, v, api = rt.b, rt.v, rt.api
    discovery = rt.d.confirmed_runtime_discovery(rt)
    v.require(discovery.get('method') == 'LEAN_ELAB_PARSE_IMPORTS_COMPLETE_PROJECT_CLOSURE' and
              discovery.get('closureComplete') is True, 'compiler project closure missing')
    v.require(discovery['runID'] == rt.run_id and discovery['candidateSetSHA256'] ==
              b.sha(rt.package / 'candidate-sources.json'), 'discovery run/candidate binding drift')
    v.require(discovery['parserReceiptSHA256'] == b.sha(rt.private / 'parser-provenance.json') and
              discovery['parserStdoutSHA256'] == b.sha(rt.private / '04-parser-observe.stdout.raw'),
              'actual compiler discovery receipt drift')
    targets = [m['module'] for m in rt.profile['modules']]
    v.require(not set(targets).intersection(discovery['providers']), 'target inherited')
    fresh = rt.out / 'cohort'; fresh.mkdir()
    sources = rt.out / 'source'; sources.mkdir()
    driver = rt.out / 'driver'; driver.mkdir()
    inherited, absent = b.copy_providers(rt.project, fresh, discovery['providers'], targets)
    rt.copies.extend(inherited); rt.missing.extend(absent)
    rt.write('provider-copies.json', dict(files=inherited, absentSidecars=absent, **v.NO_ACCEPT))
    rt.env['LEAN_PATH'] = os.pathsep.join(map(str, [fresh, driver] + rt.external))
    rt.env.update(C34_FRESH_ROOT=str(fresh.resolve()), C34_PROFILE_SHA256=rt.profile_sha,
                  C34_COHORT_ID=rt.run_id)
    rt.env.pop('QBE_EXPECT_FRESH_OLEAN', None)
    rt.write('runtime-environment.json', dict(LEAN_PATH=rt.env['LEAN_PATH'],
        C34_FRESH_ROOT=rt.env['C34_FRESH_ROOT'], C34_PROFILE_SHA256=rt.profile_sha,
        C34_COHORT_ID=rt.run_id, envelope=rt.profile['envelope'], **v.NO_ACCEPT))
    flags = [str(rt.lean), '--threads=1', '--memory=3072']
    expected_oleans, receipts = {}, []
    for ordinal, target in enumerate(rt.profile['modules'], 1):
        relative = target['module'].replace('.', '/')
        rt.copies.append(b.copy_bound(b.child(rt.project, relative + '.lean'),
                                     b.child(sources, relative + '.lean'), target['rawSHA256']))
        output = b.child(fresh, relative + '.olean')
        output.parent.mkdir(parents=True, exist_ok=True)
        if any(b.child(fresh, relative + suffix).exists() for suffix in b.SIDECARS):
            raise FileExistsError('target artifact inherited/reused before fresh compile')
        result = rt.call('1' + str(ordinal) + '-target', flags + ['-DElab.async=false', '-o', str(output), relative + '.lean'],
                         sources, rt.profile['envelope']['targetTimeoutSeconds'])
        if not output.is_file():
            raise ValueError('target exit without fresh olean')
        artifacts = [rt.bind_artifact(b.child(fresh, relative + suffix)) for suffix in b.SIDECARS
                     if b.child(fresh, relative + suffix).is_file()]
        expected_oleans[target['module']] = str(output.resolve())
        receipts.append(dict(module=target['module'], nativeResult=result, artifacts=artifacts))
    rt.write('target-cohort.json', dict(cohortID=rt.run_id, targets=receipts, **v.NO_ACCEPT))
    driver_copies = b.bind_drivers(rt.package, driver, rt.profile, rt.manifest['files'])
    rt.copies.extend(driver_copies)
    rt.write('driver-source-copy-bindings.json', dict(files=driver_copies, **v.NO_ACCEPT))
    for ordinal, name in enumerate(('Collector', 'Profile'), 1):
        rt.call('2' + str(ordinal) + '-driver', flags + ['-o', str(driver / (name + '.olean')),
            name + '.lean'], driver, rt.profile['envelope']['driverTimeoutSeconds'])
        if not (driver / (name + '.olean')).is_file():
            raise ValueError('driver exit without fresh olean')
        for path in sorted(driver.iterdir()):
            if path.is_file():
                rt.bind_artifact(path)
    rt.write('driver-artifacts.json', dict(files=[row for row in rt.artifacts
             if Path(row['path']).is_relative_to(driver)], **v.NO_ACCEPT))
    result = rt.call('30-observe', flags + ['Probe.lean'], driver,
                     rt.profile['envelope']['observeTimeoutSeconds'])
    checked = v.validate(rt.profile, (rt.private / '30-observe.stdout.raw').read_text(
        encoding='utf-8', errors='strict'), result['exitCode'], timed_out=result['timedOut'],
        profile_sha=rt.profile_sha, cohort_id=rt.run_id, expected_oleans=expected_oleans)
    rt.revalidate()
    rt.write('completeness.json', checked)
    return checked


def run(project, package, *, ci=False, approved_seal_sha256=None):
    approved = require_future_ci(package, approved_seal_sha256, ci)
    profile, manifest, b, v, d, entry = bootstrap(package, approved_files=approved)
    if not READY_FOR_CI or profile.get('readyForCI') is not True:
        raise RuntimeError('implementation not ready for future CI')
    api, shared = b.load_shared(project, profile)
    rt = Runtime(project, package, profile, manifest, b, v, d, entry, api, shared)
    status = dict(status='NOT_RUN', cleanTransitive=False, actualLoadTrace=False,
                  nativeTCBReviewed=False, **v.NO_ACCEPT)
    code = 1
    try:
        rt.prepare_toolchain_and_providers()
        d.discover_project_providers(rt)
        checked = execute_fresh_observation(rt)
        rt.revalidate()
        status.update(status=checked['status'], roots=checked['roots'], privateRoots=checked['private'],
                      generated=checked['generated'], cohortID=rt.run_id)
        code = 0
    except Exception as error:
        status.update(status='DIAGNOSTIC_FAILED_NOT_MATHEMATICAL_REFUTATION',
                      failureType=type(error).__name__, failure=str(error))
    finally:
        rt.api.write_json(rt.private / 'result.json', status)
        rt.api.export_public(rt.private, rt.public, rt.logical)
    print(json.dumps(rt.api.redact_tree(status, rt.logical)))
    return code


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, required=True)
    parser.add_argument('--ci', action='store_true')
    parser.add_argument('--approved-seal-sha256', required=True)
    args = parser.parse_args()
    try:
        code = run(args.project, Path(__file__).parent, ci=args.ci,
                   approved_seal_sha256=args.approved_seal_sha256)
    except Exception as error:
        print(json.dumps(dict(status='WRAPPER_FAILED_CLOSED_NOT_NATIVE_EVIDENCE',
            failureType=type(error).__name__, scientificAcceptance=False, nativeAccepted=False,
            trustClosure=False, sourceAgreement=None, axiomPolicyPass=None, publicationBinding=None)))
        code = 1
    sys.exit(code)
