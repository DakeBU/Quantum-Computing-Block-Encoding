"""Same-cap target-only scheduling fixtures; no native execution or success prediction."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import runner
import discovery
import test_discovery as old

HERE = Path(__file__).resolve().parent
TARGETS = {'11-target', '12-target', '13-target'}
FLAG = '-DElab.async=false'


def check_argv(label, argv):
    if argv.count(FLAG) != (1 if label in TARGETS else 0):
        raise ValueError('target-only scheduling flag partition changed')
    if label in TARGETS:
        if argv[1:5] != ['--threads=1', '--memory=3072', FLAG, '-o']:
            raise ValueError('fresh target fixed resource/argument ordering changed')


class SerialPolicyTests(unittest.TestCase):
    def test_only_one_runner_expression_changed(self):
        source = (HERE / 'runner.py').read_bytes()
        current = b"flags + ['-DElab.async=false', '-o', str(output), relative + '.lean']"
        previous = b"flags + ['-o', str(output), relative + '.lean']"
        self.assertEqual(source.count(current), 1)
        restored = source.replace(current, previous)
        self.assertEqual(hashlib.sha256(restored).hexdigest(),
            'd14d8cc8254f90e384f27610e02d2bbaee8f364e5146d3c204a37986c8805634')
        for name, digest in {
            'profile.json': '6feca13d6692f5f7bedc887469c8216f62a250046c4440c61ea75ae2f93eb54c',
            'candidate-sources.json': 'ab18ce50206601436fdc5b2e8bbff2450375333894f37b4129c7a63c724eaa22',
            'Parser.lean': 'bb90c62c9eef47065f6e36814a35a1b89392aeb7b0b8cf273a81500bca06467c',
            'Collector.lean': 'ff56db30a919f2eef47e97146daf5f10833f553d591f35a8d29c3868feff2860',
            'validator.py': '43c06a01ec75ed113326e2fc262fd83bf50b10e5ec820053c2b977f91247ff87',
            'discovery.py': 'f26982a316c66910421a841cfb24b1ae7f03af23d7ad6c7baeeb080475e9d7ec'
        }.items():
            self.assertEqual(hashlib.sha256((HERE / name).read_bytes()).hexdigest(), digest)

    def test_full_synthetic_flow_has_target_only_exact_argv(self):
        setup = old.SyntheticPipelineTests()
        with tempfile.TemporaryDirectory(prefix='SYNTHETIC-ci4-', dir=HERE) as directory:
            rt, api, prefix = setup.setup_pipeline(directory)
            with patch.object(runner.shutil, 'which', return_value=str(prefix / 'bin/lean')):
                rt.prepare_toolchain_and_providers()
                discovery.discover_project_providers(rt)
                result = runner.execute_fresh_observation(rt)
            self.assertEqual(result['roots'], 57)
            self.assertFalse(result['nativeAccepted'])
            for label, timeout in api.calls:
                record = json.loads((rt.private / (label + '.setup.json')).read_text())
                argv = record['argv']
                check_argv(label, argv)
                if label in TARGETS:
                    self.assertEqual(timeout, 600)
                    index = int(label[1]) - 1
                    stem = rt.profile['modules'][index]['module'].replace('.', '/')
                    self.assertEqual(argv, [str(rt.lean), '--threads=1', '--memory=3072', FLAG,
                        '-o', str(rt.out / 'cohort' / (stem + '.olean')), stem + '.lean'])
                    self.assertEqual(record['cwd'], str(rt.out / 'source'))
            self.assertEqual(rt.profile['envelope']['wholeJobTimeoutSeconds'], 2100)

    def test_budget_and_wrong_stage_negative_cases(self):
        target = ['lean', '--threads=1', '--memory=3072', FLAG, '-o', 'fresh.olean', 'source.lean']
        check_argv('11-target', target)
        for label, argv in [('11-target', [a for a in target if a != FLAG]),
                            ('11-target', [a.replace('3072', '6144') for a in target]),
                            ('11-target', [a.replace('threads=1', 'threads=2') for a in target]),
                            ('21-driver', target), ('30-observe', target),
                            ('03-parser-compile', target), ('04-parser-observe', target)]:
            with self.subTest(label=label), self.assertRaises(ValueError):
                check_argv(label, argv)


if __name__ == '__main__':
    unittest.main()
