# Future hosted CI integration

Do not run this package locally. Parent review and installation are separate
from this handoff. No workflow was written into the production repository.

The future Linux hosted job must provide Python 3.11 or newer, pinned Lean 4.33,
the exact project checkout/configuration/candidate bytes, inherited non-target
project provider artifacts and package caches. It must expose an explicit,
nonempty Lean search path through the existing `lake env` environment. It must
not pre-populate this package's exclusive `_out/real-preparation-native-c34-implement-v2`.
The package manifest and packet seal travel together with all payloads.

After review, the installer pins the packet-seal SHA256 supplied in this handoff
outside the packet, sets the whole hosted job timeout to 35 minutes and invokes:

```sh
lake env python3 -B /absolute/reviewed/package/runner.py \
  --project /absolute/pinned/project \
  --ci --approved-seal-sha256 REVIEWED_PACKET_SEAL_SHA256
```

The placeholder is deliberately not an executable approval. The installed
workflow must use the actual reviewed digest, and must run on a GitHub-hosted
Linux runner whose GITHUB_ACTIONS and RUNNER_ENVIRONMENT markers match the
entry checks. The operator chooses no providers: the compiler discovers them
from frozen source candidates during this run. Parser compile/observe are
included in the common deadline, followed by the same fresh-cohort 57-name
expectation flow.

All native calls have PID/exit/timeout/raw stdout/stderr receipts. On failure,
inspect the private/raw evidence with appropriate local access; sanitized public
exports are raw-derived and do not replace it. Never publish the private tree,
candidate snapshots, provider copies or oleans. Success means only complete
formal diagnostic binding/coverage, not axiom policy, source agreement, trust
closure, publication or root acceptance.

For Python tests after relocation:

```sh
C34_TEST_PROJECT=/absolute/pinned/project \
  python3 -B -m unittest -v test_adapter test_discovery
```

Run those from the package directory. They use synthetic streams and no Lean
subprocess; they do not supply an actual compiler-discovery result.
