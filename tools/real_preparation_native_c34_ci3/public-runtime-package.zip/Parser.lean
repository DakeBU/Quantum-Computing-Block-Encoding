import Lean

open Lean

namespace C34Imports

def checked {α : Type} (value : Except String α) : IO α :=
  match value with
  | .ok x => pure x
  | .error message => throw (IO.userError message)

def strField (row : Json) (key : String) : IO String := do
  let value ← checked (row.getObjVal? key)
  checked value.getStr?

def natField (row : Json) (key : String) : IO Nat := do
  let value ← checked (row.getObjVal? key)
  checked value.getNat?

def noAccept : List (String × Json) := [
  ("sourceAgreement", .null), ("axiomPolicyPass", .null),
  ("publicationBinding", .null), ("scientificAcceptance", .bool false),
  ("nativeAccepted", .bool false), ("trustClosure", .bool false)]

def emit (tag : String) (fields : List (String × Json)) : IO Unit :=
  IO.println (tag ++ " " ++ (Json.mkObj (fields ++ noAccept)).compress)

def importJson (imp : Import) : Json := Json.mkObj [
  ("module", .str imp.module.toString), ("importAll", .bool imp.importAll),
  ("isExported", .bool imp.isExported), ("isMeta", .bool imp.isMeta)]

def run (manifestPath : String) : IO Unit := do
  let doc ← checked (Json.parse (← IO.FS.readFile (System.FilePath.mk manifestPath)))
  unless (← strField doc "schema") == "C34_PARSER_REQUEST_V2" do
    throw (IO.userError "C34 parser request schema mismatch")
  let candidateSHA ← strField doc "candidateSetSHA256"
  let profileSHA ← strField doc "profileSHA256"
  let runID ← strField doc "runID"
  let some requestSHA ← IO.getEnv "C34_PARSER_REQUEST_SHA256"
    | throw (IO.userError "C34 parser request digest binding absent")
  let entriesJson ← checked (doc.getObjVal? "candidates")
  let entries ← checked entriesJson.getArr?
  unless entries.size > 0 do throw (IO.userError "C34 empty candidate snapshot")
  let mut ordinal := 0
  for row in entries do
    ordinal := ordinal + 1
    let moduleName ← strField row "module"
    let relative ← strField row "relativePath"
    let snapshot ← strField row "snapshotPath"
    let digest ← strField row "sha256"
    let bytes ← natField row "bytes"
    let actualPath ← IO.FS.realPath (System.FilePath.mk snapshot)
    let input ← IO.FS.readFile actualPath
    unless input.toUTF8.size == bytes do
      throw (IO.userError s!"C34 full candidate byte count mismatch: {moduleName}")
    let (imports, _, messages) ← Lean.Elab.parseImports input (some actualPath.toString)
    unless messages.toArray.isEmpty do
      throw (IO.userError s!"C34 import parser diagnostic: {moduleName}")
    emit "C34_IMPORTS_JSON" [
      ("ordinal", toJson ordinal), ("module", .str moduleName),
      ("relativePath", .str relative), ("snapshotPath", .str actualPath.toString),
      ("sha256", .str digest), ("bytes", toJson bytes),
      ("requestSHA256", .str requestSHA), ("candidateSetSHA256", .str candidateSHA),
      ("profileSHA256", .str profileSHA), ("runID", .str runID),
      ("parserAPI", .str "Lean.Elab.parseImports"),
      ("parseMessages", toJson messages.toArray.size),
      ("hasParseErrors", .bool messages.hasErrors),
      ("imports", .arr (imports.map importJson))]
  emit "C34_IMPORTS_SUMMARY_JSON" [
    ("status", .str "COMPILER_IMPORT_HEADERS_OBSERVED_NOT_ACCEPTANCE"),
    ("candidateCount", toJson entries.size), ("requestSHA256", .str requestSHA),
    ("candidateSetSHA256", .str candidateSHA), ("profileSHA256", .str profileSHA),
    ("runID", .str runID), ("parserAPI", .str "Lean.Elab.parseImports"),
    ("importFields", toJson (["module", "importAll", "isExported", "isMeta"] : List String))]

end C34Imports

def main (args : List String) : IO UInt32 := do
  match args with
  | [manifest] => do
    C34Imports.run manifest
    pure 0
  | _ => throw (IO.userError "C34 parser expects exactly one frozen request path")
