"""Pure Python fixtures. These are NOT Lean observations or native API certification."""
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

import bindings as b
import runner
import validator as v

HERE = Path(__file__).resolve().parent
PROFILE = json.loads((HERE / 'profile.json').read_text(encoding='utf-8'))
PROFILE_SHA = b.sha(HERE / 'profile.json')
COHORT = 'SYNTHETIC_NOT_NATIVE'
OLEANS = {m['module']: '$COHORT/' + m['module'].replace('.', '/') + '.olean'
          for m in PROFILE['modules']}
PROJECT = Path(os.environ.get('C34_TEST_PROJECT', HERE.parents[1]))


def fixture(profile=None, generated=0):
    profile = profile or PROFILE
    stream = []
    total = 0
    for index, module in enumerate(profile['modules']):
        name = module['module']
        rows = []
        for ordinal, spec in enumerate((r for r in profile['roots'] if r['module'] == name), 1):
            user = spec['sourceUserName']
            actual = '_private.SYNTHETIC.0.' + user if spec['sourcePrivate'] else user
            kind = {'def': 'defnInfo', 'theorem': 'thmInfo'}[spec['sourceKind']]
            row = dict(module=name, actualName=actual, sourceUserName=user,
                sourcePrivate=spec['sourcePrivate'], sourceKind=spec['sourceKind'],
                moduleOrdinal=ordinal, userNameViaActualAPI=user, actualPrivate=spec['sourcePrivate'],
                actualKind=kind, kernelKind=kind, kernelRootPresent=True,
                kernelTypeAndUniversesAgree=True, observationSource='KERNEL_CONSTANT_INFO',
                ownerModuleIndex=index, ownershipMethod='ENVIRONMENT_MODULE_INDEX_NOT_NAME_PREFIX',
                elaborationKind=kind, elaborationIsUnsafe=False, elaborationHasValueAllowOpaque=True,
                kernelElaborationUnsafeAgree=True, kernelElaborationValueAvailabilityAgree=True,
                kernelElaborationValueExprAgree=True, typePrettyExplicit='SYNTHETIC_TYPE_NOT_LEAN',
                universeParameters=[], isUnsafe=False, actualHasValueAllowOpaque=True,
                valueTextRequested=False, valuePrettyExplicitAllowOpaque=None,
                valueObservation='NOT_REQUESTED_VALUE_AVAILABLE', actualOpaqueInfo=False,
                actualAxiomInfo=False, sourceOpaque=False, axioms=[], selfOccursInAxioms=False,
                axiomCollection='ACTUAL_LEAN_COLLECT_AXIOMS_IMPORTED_EXTENSION_AND_LOCAL_BODIES',
                typeTextScope='ACTUAL_META_PPEXPR_NOT_LOSSLESS_EXPR_SERIALIZATION', **v.NO_ACCEPT)
            rows.append(('C34_ROOT_JSON', row))
        for number in range(generated if index == 0 else 0):
            row = deepcopy(rows[0][1])
            for key in ('sourceUserName', 'sourcePrivate', 'sourceKind', 'moduleOrdinal'):
                row.pop(key)
            actual = 'outsideSourceNamespace.synthetic' + str(number)
            row.update(actualName=actual, userNameViaActualAPI=actual, actualPrivate=False,
                       includedInExplicitRootCount=False)
            rows.append(('C34_GENERATED_JSON', row))
        owned = [r['actualName'] for _, r in rows]
        binding = dict(module=name, profileSHA256=PROFILE_SHA, cohortID=COHORT,
            resolvedOleanPath=OLEANS.get(name, '$COHORT/' + name + '.olean'),
            freshOleanPathComparisonPassed=True,
            ownershipMethod='ENVIRONMENT_MODULE_INDEX_NOT_NAME_PREFIX', ownerModuleIndex=index,
            ownedNames=owned, ownedCount=len(owned), expectedRoots=module['sourceRoots'], structures=[],
            ppDeepTerms=True, ppMaxSteps=2000000, maxRecDepth=10000, **v.NO_ACCEPT)
        stream.append(('C34_BINDING_JSON', binding))
        stream.extend(rows)
        total += len(rows)
    stream.append(('C34_SUMMARY_JSON', dict(status='FORMAL_DIAGNOSTIC_COMPLETE_NOT_ACCEPTANCE',
        profileSHA256=PROFILE_SHA, cohortID=COHORT, modulesCompleted=len(profile['modules']),
        rootsCompleted=len(profile['roots']), privateCompleted=sum(r['sourcePrivate'] for r in profile['roots']),
        generatedCompleted=generated, ownedCompleted=total, allNamesResolvedUniquely=True, **v.NO_ACCEPT)))
    return stream


def dump(stream):
    return '\n'.join(tag + ' ' + json.dumps(row) for tag, row in stream) + '\n'


def validate(stream, profile=None, code=0, timeout=False):
    return v.validate(profile or PROFILE, dump(stream), code, timed_out=timeout,
        profile_sha=PROFILE_SHA, cohort_id=COHORT, expected_oleans=OLEANS)


def roots(stream):
    return [r for tag, r in stream if tag == 'C34_ROOT_JSON']


class ValidatorTests(unittest.TestCase):
    def test_57_complete_coverage_and_zero_generated(self):
        result = validate(fixture())
        self.assertEqual((result['roots'], result['private'], result['generated']), (57, 4, 0))
        self.assertIs(result['nativeAccepted'], False)

    def test_dynamic_generated_counts(self):
        for count in (1, 3, 7):
            with self.subTest(count=count):
                self.assertEqual(validate(fixture(generated=count))['generated'], count)

    def test_count_parameterization_not_an_old_task_vector(self):
        small = deepcopy(PROFILE)
        small['modules'] = small['modules'][:1]
        small['roots'] = small['roots'][:2]
        small['modules'][0].update(sourceRoots=2, privateRoots=0)
        self.assertEqual(validate(fixture(small), small)['roots'], 2)

    def test_observed_unsafe_axioms_and_ci_differences_are_not_policy(self):
        stream = fixture(generated=1)
        row = next(r for t, r in stream if t == 'C34_GENERATED_JSON')
        row.update(actualKind='axiomInfo', kernelKind='axiomInfo', elaborationKind='axiomInfo',
            actualHasValueAllowOpaque=False, elaborationHasValueAllowOpaque=False,
            valueObservation='NOT_REQUESTED_NO_VALUE_AVAILABLE', actualAxiomInfo=True,
            isUnsafe=True, elaborationIsUnsafe=False, kernelElaborationUnsafeAgree=False,
            axioms=[row['actualName']], selfOccursInAxioms=True)
        result = validate(stream)
        self.assertEqual(result['observedUnsafe'], 1)
        self.assertEqual(result['observedKernelElaborationUnsafeDifferences'], 1)
        self.assertEqual(result['observedAxiomUnion'], [row['actualName']])
        self.assertIsNone(result['axiomPolicyPass'])

    def test_root_and_kernel_negative_mutations(self):
        mutations = [lambda s: roots(s)[0].update(actualKind='opaqueInfo'),
            lambda s: roots(s)[0].update(observationSource='ELAB_ONLY'),
            lambda s: roots(s)[0].update(typePrettyExplicit='partial ⋯'),
            lambda s: roots(s)[0].update(typePrettyExplicit='partial …'),
            lambda s: roots(s)[0].pop('isUnsafe'),
            lambda s: roots(s)[0].update(isUnsafe=1),
            lambda s: roots(s)[0].update(ownerModuleIndex=99),
            lambda s: roots(s)[0].update(kernelElaborationUnsafeAgree=False),
            lambda s: roots(s)[9].update(userNameViaActualAPI='wrongPrivate'),
            lambda s: roots(s)[0].update(nativeAccepted=True),
            lambda s: roots(s)[0].update(valuePrettyExplicitAllowOpaque='fabricated'),
            lambda s: s[0][1].update(resolvedOleanPath='$OLD_STALE.olean'),
            lambda s: s[0][1]['ownedNames'].pop(),
            lambda s: s[-1][1].update(rootsCompleted=56)]
        for index, mutate in enumerate(mutations):
            with self.subTest(index=index), self.assertRaises(ValueError):
                stream = fixture(); mutate(stream); validate(stream)

    def test_private_ambiguity_even_when_disguised_as_generated(self):
        stream = fixture(generated=1)
        private = roots(stream)[9]
        extra = next(r for tag, r in stream if tag == 'C34_GENERATED_JSON')
        old = extra['actualName']
        extra.update(actualName='_private.SYNTHETIC.1.' + private['sourceUserName'],
                     actualPrivate=True, userNameViaActualAPI=private['sourceUserName'])
        owned = stream[0][1]['ownedNames']
        owned[owned.index(old)] = extra['actualName']
        with self.assertRaises(ValueError):
            validate(stream)

    def test_stream_order_terminal_duplicate_keys_and_native_exit(self):
        stream = fixture()
        reordered = deepcopy(stream)
        reordered[0], reordered[1] = reordered[1], reordered[0]
        with self.assertRaises(ValueError): validate(reordered)
        with self.assertRaises(ValueError): validate(stream[:-1])
        with self.assertRaises(ValueError): validate(stream + [stream[-1]])
        with self.assertRaises(ValueError): v.parse(dump(stream) + 'warning unexpected\n')
        with self.assertRaises(ValueError): v.parse('C34_SUMMARY_JSON {"a":1,"a":2}\n')
        with self.assertRaises(ValueError): v.loads('{"a":NaN}')
        with self.assertRaises(ValueError): validate(stream, code=1)
        with self.assertRaises(ValueError): validate(stream, timeout=True)
        with self.assertRaises(ValueError): validate(stream, code=True)

    def test_profile_counts_and_baselines_fail_closed(self):
        for mutation in ({'generatedCountBaseline': 5}, {'roots': PROFILE['roots'][:-1]}):
            candidate = deepcopy(PROFILE); candidate.update(mutation)
            with self.assertRaises(ValueError): v.validate_profile(candidate)


class BindingTests(unittest.TestCase):
    def test_frozen_own_driver_renderings(self):
        for name, text in b.render_texts(PROFILE).items():
            self.assertEqual((HERE / 'pending-drivers' / name).read_bytes(), text.encode('utf-8'))

    def test_all_57_source_anchors_remain_exact(self):
        project = PROJECT
        for root in PROFILE['roots']:
            with self.subTest(root=root['sourceUserName']):
                source = project / (root['module'].replace('.', '/') + '.lean')
                self.assertEqual(b.sha(source), root['sourceSHA256'])
                lines = source.read_text(encoding='utf-8').splitlines()
                self.assertEqual(lines[root['startLine'] - 1], root['declarationLine'])
                self.assertEqual(lines.count('namespace ' + root['module']), 1)
                self.assertEqual(root['sourcePrivate'], root['declarationLine'].startswith('private '))
        for path, expected in PROFILE['projectInputs'].items():
            self.assertEqual(b.sha(project / path), expected)

    def test_entry_and_module_digest_binding(self):
        profile, manifest, _, _, _, receipt = runner.bootstrap(HERE, HERE / 'runner.py', HERE / 'runner.py')
        self.assertEqual(receipt['actualEntrySHA256'], manifest['files']['runner.py'])
        self.assertEqual(len(profile['roots']), 57)
        with self.assertRaises(ValueError):
            runner.bootstrap(HERE, HERE / 'runner.py', HERE / 'test_adapter.py')
        with tempfile.TemporaryDirectory(prefix='c34-test-', dir=HERE) as name:
            target = Path(name) / 'unit.py'
            target.write_text('SYNTHETIC_VALUE = 1\n', encoding='utf-8')
            expected = b.sha(target)
            module, receipt = b.load_pinned(target, expected, 'c34_synthetic_module')
            self.assertEqual(module.SYNTHETIC_VALUE, 1)
            target.write_text('SYNTHETIC_VALUE = 2\n', encoding='utf-8')
            with self.assertRaises(ValueError): b.load_pinned(target, expected, 'c34_synthetic_module')

    def test_collector_source_and_copied_destination_drift(self):
        manifest = runner.read_unique(HERE / 'package-bindings.json')
        with tempfile.TemporaryDirectory(prefix='c34-test-', dir=HERE) as name:
            driver = Path(name)
            rows = b.bind_drivers(HERE, driver, PROFILE, manifest['files'])
            self.assertEqual(len(rows), 3)
            self.assertEqual(rows[0]['sourceSHA256Before'], manifest['files']['Collector.lean'])
            for row in rows: b.recheck_copy(row)
            (driver / 'Collector.lean').write_bytes(b'CHANGED_SYNTHETIC_COPY')
            with self.assertRaises(ValueError): b.recheck_copy(rows[0])
            with self.assertRaises(FileExistsError): b.bind_drivers(HERE, driver, PROFILE, manifest['files'])
        with tempfile.TemporaryDirectory(prefix='c34-test-', dir=HERE) as name:
            source, dest = Path(name) / 'source', Path(name) / 'dest'
            source.write_bytes(b'one')
            row = b.copy_bound(source, dest, b.sha(source))
            source.write_bytes(b'two')
            with self.assertRaises(ValueError): b.recheck_copy(row)

    def test_target_fallback_and_provider_target_reuse_denied(self):
        modules = [m['module'] for m in PROFILE['modules']]
        with tempfile.TemporaryDirectory(prefix='c34-test-', dir=HERE) as name:
            root = Path(name)
            b.reject_target_fallback([root], modules)
            stale = root / (modules[0].replace('.', '/') + '.olean.private')
            stale.parent.mkdir(parents=True); stale.write_bytes(b'STALE_SYNTHETIC')
            with self.assertRaises(ValueError): b.reject_target_fallback([root], modules)
            with self.assertRaises(ValueError): b.copy_providers(root, root, [modules[0]], modules)
            for relative in ('../escape', 'C:/escape', '/escape', 'a//b'):
                with self.assertRaises(ValueError): b.child(root, relative)

    def test_finite_envelope_and_whole_job_cap(self):
        self.assertEqual(b.check_envelope(PROFILE)['wholeJobTimeoutSeconds'], 2100)
        profile = deepcopy(PROFILE); profile['envelope']['targetTimeoutSeconds'] = 601
        with self.assertRaises(ValueError): b.check_envelope(profile)
        now = [0]
        deadline = b.Deadline(2100, clock=lambda: now[0])
        self.assertEqual(deadline.remaining(600), 600)
        now[0] = 2050
        self.assertEqual(deadline.remaining(300), 50)
        now[0] = 2100
        with self.assertRaises(TimeoutError): deadline.remaining(30)

    def test_ci_entry_denies_local_and_unapproved_execution(self):
        with self.assertRaises(RuntimeError):
            runner.run(PROJECT, HERE)
        with self.assertRaises(RuntimeError):
            runner.require_future_ci(HERE, None, False)
        self.assertIs(runner.READY_FOR_CI, True)
        self.assertIs(PROFILE['readyForCI'], True)

    def test_shared_helper_pin_and_provenance(self):
        project = PROJECT
        api, receipt = b.load_shared(project, PROFILE)
        self.assertEqual(receipt['sha256'], PROFILE['sharedInstrumentation']['sha256'])
        self.assertTrue(callable(api.native_call))  # Never called in these tests.
        profile = deepcopy(PROFILE); profile['sharedInstrumentation']['path'] = 'unexpected.py'
        with self.assertRaises(ValueError): b.load_shared(project, profile)


if __name__ == '__main__':
    unittest.main(verbosity=2)
