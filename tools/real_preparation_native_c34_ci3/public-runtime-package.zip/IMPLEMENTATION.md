# Compiler import discovery and finite native observation package

Status: runnable implementation for future hosted Linux CI, not installed or
executed. The import-discovery stub from v1 is removed. Both previous packets
remain immutable. This package makes no source, publication, axiom-policy,
acceptance, trust-closure or root conclusion.

## Actual compiler discovery producer

`discovery.discover_project_providers(rt)` now implements the producer. The
input runtime carries the bound project/package/profile/manifest, actual entry
and shared-helper identities, a common 35-minute deadline and process receipts.
There is no caller-supplied provider list, discovery JSON path or override flag.

`candidate-sources.json` freezes exact paths, module names, raw SHA256 and byte
sizes for 220 project-owned `.lean` files (8,927,534 bytes). Its scopes match the
local libraries and executable roots in the pinned lakefile: QuantumBlockEncoding,
ABEISBlueprint and ABEISTests directories, plus the four named root modules.
Package caches, scratch files, run outputs and lakefile configuration itself are
not candidate modules. The three configuration files remain separately pinned.
This entire candidate set is a source snapshot, NOT an import closure.

Before the parser runs, the producer verifies exact candidate membership and
digests and copies every complete source file into a fresh snapshot, binding
both source and destination. Added, removed, renamed, linked or modified source
entries fail closed. The parser request pins every actual snapshot path and its
original byte binding. Every process rechecks package, helper, toolchain,
candidate membership, originals, copies and previously bound artifacts.

`Parser.lean` imports only `Lean`. It reads each complete frozen file and calls
`Lean.Elab.parseImports`, with strict JSON rows and a terminal summary. Every
Import field known in Lean 4.33 is retained: module, importAll, isExported and
isMeta. The implicit Init runtime/meta imports are retained, including their
repeated module identities; imports are never collapsed to a name-only set.
Any parser diagnostic, unexpected output, malformed JSON, duplicate key, wrong
flag type, path/digest/count mismatch or partial stream fails closed.

The parser compile stage creates a fresh `.olean` and binds it. The observation
uses `lean --run Parser.lean <bound-request>`: Lean re-elaborates the same pinned
driver source and invokes main. It does NOT execute the earlier Parser.olean
as though it were a standalone executable. Both source copies and the earlier
compile artifact are recorded with that distinction.

Python traverses only the compiler-observed import arrays to obtain the three
targets' complete project-owned closure. Cycles, unresolved project-owned
imports and invalid target ordering fail closed. It freezes exact providers
(closure minus the three targets), sourcePins, target dependencies, complete
compiler rows and external import edges with their flags. External package
closure is not reconstructed or represented as freshly checked mathematics.

The producer binds request, candidate set, actual parser driver, native stage
PID/exit/timeout/raw stream receipts and a parser-provenance JSON digest.
`confirmed_runtime_discovery(rt)` revalidates those immutable files and
re-derives the closure from the same raw parser stream before cohort execution.
`execute_fresh_observation(rt)` accepts no provider dictionary argument.

## Fresh cohort and complete owned constant observations

The targets compile in the frozen order RealAmplitudePreparation,
RealIsometryCompletion, ConstructiveIsometryLocal. Only compiler-observed
non-target project providers are inherited and copied, with exact sidecar
presence/absence and source/destination receipts. The original project build
root is removed from LEAN_PATH. Any old target artifact under an allowed external
root is rejected. Target artifacts cannot be inherited into the fresh cohort.

The v1 kernel collector and parameterized strict stream validator remain.
All 57 explicit source names are expected coverage, not a successful-run
prediction. Every exact module-owned constant is observed, including dynamically
enumerated owned-minus-explicit generated constants; zero generated is allowed.
Private names are resolved by actual Lean APIs, not guessed mangling. Kernel
type/universes/value availability/unsafe fields come from ki and ci comparisons
remain explicit. Source signatures never replace missing kernel type text.
`collectAxioms` retains its imported-extension/local-body boundary.

The actual entry and argv entry, Python executable, loaded executable modules,
profile, own driver renderings and collector source/destination are hash-bound.
Module loads occur only after the externally reviewed packet and package
bindings are verified. Runtime rechecks include all candidate source bytes,
parser evidence, provider artifacts, copied sources and fresh outputs.

Raw/private evidence and public/sanitized text remain separate. The pinned
existing shared process/receipt/inventory/redaction helpers are reused, not their
task-specific runner or math profiles. Public files carry raw-to-sanitized
derivation receipts; source copies and oleans are not exported. These checks
are not an adversarial OS attestation, clean-transitive rebuild, actual native
load trace or native-TCB review. External providers remain inherited artifacts.

## Finite future CI envelope

The exact profile envelope is one thread with no automatic retries/escalation:

| Process | Memory | Timeout |
| --- | --- | --- |
| Prefix and actual binary help | no compilation | 30 seconds each |
| Parser compile | 3072 MiB | 120 seconds |
| Single parser observation | 3072 MiB | 30 seconds |
| Three target compiles | 3072 MiB | 600 seconds each |
| Collector and Profile compiles | 3072 MiB | 120 seconds each |
| Single constant observation | 3072 MiB | 300 seconds |

The common deadline is 2100 seconds including discovery. Remaining time caps
every native child; later stage caps are shortened rather than enlarged.
Individual maxima sum beyond the total, so the future hosted job must also have
a 35-minute timeout covering non-child inventory and preparation work. There
is no automatic larger-resource rescue path.

## Entry and parent review

`readyForCI=true` means the implementation has no stub, NOT that it is installed,
authorized to run locally or known to compile. `installationAuthorized=false`
records the current installation state. The runnable entry requires `--ci`,
Linux, GITHUB_ACTIONS=true, RUNNER_ENVIRONMENT=github-hosted and an externally
reviewed exact packet-seal SHA256. This approval binds the package, not a hand-
written provider list. Providers are computed in the same bounded future run.

The parent must review the final sealed package before installing or running it.
See CI-INTEGRATION.md for the finite command and expected inherited-provider
environment. No workflow, deployment or production file was installed here.

## Verification and remaining risk

Python tests cover strict positive/negative parser streams, every Import flag,
implicit Init, graph closure/cycles/missing providers/order, exact candidate
membership and bytes, source/destination drift, entry approval, kernel stream
partition, no provider JSON bypass and a synthetic end-to-end controller flow.
The synthetic API never calls Lean or subprocesses; those fixtures do not count
as parser or kernel observations. The 57 source anchors are independently checked.

No local Lean/lake, Git, network, deployment or subagent was used. Parser and
collector syntax/API compatibility, actual inherited-provider resolution, native
process behavior and genuine 57-root observations remain untested until the
future CI. The implementation does not wait for a local Lean run to manufacture
a provider list or lift the execution gate. Failures remain typed environment,
API or implementation failures, not mathematical refutations.

Technical delta: a real bounded producer and complete runnable controller,
replacing the v1 stub. Mathematical/root effect: none. Purification/Exposition
Seal is not asserted. STOP after Python verification, immutable sealing and
parent handoff.
