# C298: literal primitive representation, uncompiled author freeze

Objective: exactly C280 primitiveRepresentation : PrimitiveRepresentationSpec.
The separate C298 assignment authorizes this third root, not primitiveWidth.
No changed operation, pair, extra public premise or producer/Sites claim.

Private witnessReduction takes an arbitrary raw pair w with positive natural
denominator D, and interprets it by the ORIGINAL witnessValue. Convert that
ordinary Rat quotient to Rat.divInt N D. Rat.den_dvd gives canonical den | D;
Rat.num_dvd gives canonical num | N. For N!=0,
Int.natAbs_le_of_dvd_ne_zero gives canonical numerator magnitude <= abs(N).
N=0 is handled separately by canonical value0 and num0, so no invalid bound
from arbitrary divisibility into zero is used. D>0 plus den|D gives den<=D.
Nat.size monotonicity and two max_le_max applications yield height<=raw width.
This is a private proved bridge, not a caller correctness promise.

The PUBLIC proof then handles literal rawWitness and operationValue by cases.
Add/sub/mul denominators are x.den*y.den>0 from canonical denominator positivity.
Addition uses Rat.add_num_den, matching the two actual cross-products by
integer commutativity. Subtraction uses the same identity with -y and the
canonical negated numerator/unchanged denominator. Multiplication uses the
actual Rat.mul_eq_mkRat and mkRat_eq_divInt identities.

Division keeps the original y.num=0 branch: y=0 and raw pair(0,1), so value0
and denominator1. When y.num!=0 its magnitude is positive, so D=x.den*abs(y.num)
is positive. Split the ACTUAL y.num<0 guard. If negative, cast(abs(y.num))
is -y.num; numerator and signed denominator are both negated, and
Rat.divInt_neg cancels that common sign. If nonnegative, abs(y.num)=y.num.
Both branches then match Rat.div_def' exactly. No x!=0 or positive y premise.

Apply the private bridge to this SAME literal rawWitness with its discharged
positivity, rewrite by its actual value identity, and return all five conjuncts
in sealed order: positive den, same value, canonical denominator divisibility,
canonical numerator magnitude bound, canonical height <= witnessWidth.

Hand sign/zero checks (not run): (1/2)/(-1/3) raw(-3,2); (-1/2)/(-1/3)
raw(3,2). x/0 including0/0 raw(0,1). 1/2-1/2 raw(0,4) has canonical0/1;
the zero-numerator helper branch is necessary. (7/6)+(7/6) raw(84,36) gives
canonical7/3. No claim this raw pair is a native GCD scratch trace or bit bound.

Source graph: canonical normalization divisibility -> magnitude/den bounds ->
height monotonicity; actual four operation identities -> actual pair-value bridge
-> five-conjunct representation result. Lean graph mirrors this with one private
helper and one public theorem, importing unchanged Definitions and ordinary
Mathlib; it does not import C293 or reconstruct its proof. Existing scientific
kernel, left, captured setup, native/evaluator/GCD/physical-sharing/finite-SP and
scientific ROOT gaps remain open. No primitiveWidth/whole producer inference.

Raw read scope: C280 seal/signatures/definitions whole; Rat.Lemmas1-174 and
198-241; Rat.Defs retained whole intake, reread64-133 and233-249; Int.Basic1-105
(whole file ends at92); Order.Ring.Int1-61; Order.MinMax1-66; Nat.Size94-104,
retaining prior whole intake. Narrow exact-name searches limited to Rat/Int and
order APIs; source pins include these complete files, not a claim every file
was wholly reread. No independent review, other author root, value or runtime
packet opened. C293 pass was parent notification only, not new proof evidence.

Evidence: candidate proof and exact CLOSED expanded consumer (inline actual
witness/result matches, casts and height formulas), root and consumer type/axiom
queries. Parent must compile source, select its NEW own output for ExactChecks,
check --deps, exact type and axioms. No compiler/axiom/accepted-root claim here.
Primary uncertainty: uncompiled rewrite/cast/API elaboration, especially signed
division and zero branch normalization. No known mathematical counterexample.

qbe-substantive-worker: C280_THIRD_LITERAL_REPRESENTATION_ONLY; full protocol
intake retained, LOW-TOKEN-CONTROL-PLANE and VERIFIER-SEMANTIC-LEVEL consulted.
No parallel or competing route; direct canonical divisibility is the default
route. Failure class NONE at mathematical layer; parent compiler gate pending.
Salvage: complete bounded candidate, no weakened/discarded target fragment.
Purification/Exposition-Seal NOT_STARTED; no publication or root acceptance.
Files are new proof, exact consumer, derivation, input manifest, author freeze;
all predecessor/sealed/production bodies preserved. No compiler/lake/scripts/
Python/Git/network/subagent or numeric evaluation. Freeze and STOP.
