"""Private C346-only orchestration under the parent's explicit compiler slot.
Authored sources/plans are never written by this runner. Generated records only.
No project scripts, lake, Git, network, source edits or broad discovery.
"""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent
PIN_LEAN = "dd86e9b24990b1da425ea4af910f016e4db8f9a25c9ddad27bc6bee3690e677f"
PIN_DEFS = "f7e5fc3d6a455e81a30b2413f7f9581bd470dd5317ceccc30e49cf6152040ea4"
PIN_CACHE = "0e13b422be8c059aca7b4664239ae7bf9cdfb7100ee895369d4253416f20aaa6"
PIN_SEAL = "361d4a9b46579951146f74d1c91f1977f9ea39f7a6a264a535d45fbde64be476"
ORDINARY = {"propext", "Classical.choice", "Quot.sound"}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class Memory(ctypes.Structure):
    _fields_ = [("length", ctypes.c_ulong), ("load", ctypes.c_ulong)] + [
        (name, ctypes.c_ulonglong) for name in (
            "totalPhys", "availPhys", "totalPage", "availPage",
            "totalVirtual", "availVirtual", "availExtended")]


def available_mib():
    mem = Memory()
    mem.length = ctypes.sizeof(mem)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(mem)):
        raise RuntimeError("memory query failed")
    return mem.availPhys // (1024 * 1024)


def axiom_set(stdout, name):
    match = re.search(r"'" + re.escape(name) + r"' depends on axioms:\s*\[([^]]*)\]", stdout)
    return set(x.strip() for x in match.group(1).split(",")) if match else None


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in {"attempt-01", "attempt-02", "attempt-03"}:
        raise RuntimeError("one of the three bounded attempt names required")
    attempt = ROOT / sys.argv[1]
    plan_path = attempt / "pre-execution-plan.json"
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    module = plan["module"]
    if module not in {"SourceSuffixBindingProof", "ExactChecks"}:
        raise RuntimeError("module outside C346 slot")
    if any(attempt.glob("PRIVATE-receipt-*.json")):
        raise RuntimeError("attempt already executed; preserve it")
    if len(list(ROOT.glob("attempt-*/PRIVATE-receipt-*.json"))) >= 3:
        raise RuntimeError("three compile-invocation bound exhausted")
    source = attempt / (module + ".lean")
    if sha(source) != plan["source_sha256"]:
        raise RuntimeError("source differs from pre-execution plan")
    seal = WORK / "hermite-c345-source-suffix-preproof-seal" / "STATEMENT_SEAL.json"
    if sha(seal) != PIN_SEAL:
        raise RuntimeError("preproof seal pin changed")
    c344 = WORK / "hermite-c344-source-suffix-type-probe"
    with zipfile.ZipFile(c344 / "PRIVATE-runtime-records.zip") as archive:
        inherited_path = archive.read("requested-LEAN_PATH.txt").decode("utf-8").strip()
        prefix = archive.read("prefix.stdout").decode("utf-8").strip()
    lean = Path(prefix) / "bin" / "lean.exe"
    if sha(lean) != PIN_LEAN:
        raise RuntimeError("Lean executable pin mismatch")
    path_prefix = [str(attempt)]
    proof_hash = None
    if module == "ExactChecks":
        provider = (ROOT / plan["proof_provider_relative"]).resolve()
        if provider.parent.parent != ROOT or provider.name != "SourceSuffixBindingProof.olean":
            raise RuntimeError("consumer provider outside C346 bounded source attempt")
        provider_receipt = provider.parent / "PRIVATE-receipt-SourceSuffixBindingProof.json"
        receipt = json.loads(provider_receipt.read_text(encoding="utf-8"))
        if receipt["compile"]["exit_code"] != 0 or not receipt["ordinary_axioms"]:
            raise RuntimeError("failed/recovered proof output must never be imported")
        proof_hash = sha(provider)
        if proof_hash != plan["proof_provider_sha256"] or proof_hash != receipt["own_sha256"]:
            raise RuntimeError("successful own-output proof pin mismatch")
        path_prefix.append(str(provider.parent))
    lean_path = ";".join(path_prefix + [inherited_path])
    env = dict(os.environ, LEAN_PATH=lean_path)
    selected = {}
    for name, pin in (("SourceSuffixDefinitions", PIN_DEFS), ("ChargedSourceCache", PIN_CACHE)):
        candidates = [Path(p) / (name + ".olean") for p in lean_path.split(";")]
        chosen = next((p for p in candidates if p.is_file()), None)
        if chosen is None or sha(chosen) != pin:
            raise RuntimeError("direct provider selection pin mismatch: " + name)
        selected[name] = {"path": str(chosen), "sha256": pin}
    records = {}

    def run(args, label):
        avail = available_mib()
        if avail < 5120:
            raise RuntimeError("available physical memory below required 5120 MiB")
        start = time.monotonic()
        timed_out = False
        try:
            proc = subprocess.run(args, cwd=attempt, env=env, capture_output=True,
                                  timeout=120, creationflags=subprocess.CREATE_NO_WINDOW)
            out, err, code = proc.stdout, proc.stderr, proc.returncode
        except subprocess.TimeoutExpired as exc:
            out, err, code = exc.stdout or b"", exc.stderr or b"", None
            timed_out = True
        elapsed = time.monotonic() - start
        # Persist the FULL raw bytes before any bounded display/summary.
        (attempt / ("PRIVATE-" + label + ".stdout")).write_bytes(out)
        (attempt / ("PRIVATE-" + label + ".stderr")).write_bytes(err)
        info = {"command": [str(a) for a in args], "cwd": str(attempt),
                "available_before_MiB": avail, "exit_code": code,
                "timed_out": timed_out, "seconds": elapsed}
        records[label] = info
        return out.decode("utf-8", errors="replace"), info

    (attempt / "PRIVATE-requested-LEAN_PATH.txt").write_text(lean_path, encoding="utf-8")
    (attempt / "PRIVATE-inherited-prefix.txt").write_text(prefix, encoding="utf-8")
    dep_text, dep_result = run([lean, "-M3072", "-j1", "--deps", source.name], "deps")
    if dep_result["exit_code"] != 0:
        raise RuntimeError("dependency query failed; full raw record preserved")
    dep_paths = [line.strip().strip('"') for line in dep_text.splitlines() if line.strip()]
    expected = selected["SourceSuffixDefinitions"]["path"] if module == "SourceSuffixBindingProof" else str(provider)
    deps_matched = any(Path(p).resolve() == Path(expected).resolve() for p in dep_paths)
    if not deps_matched:
        raise RuntimeError("actual --deps did not select required own provider")
    output = attempt / (module + ".olean")
    stdout, compiled = run([lean, "-M3072", "-j1", "-o", output.name, source.name], "compile")
    roots = ["HermiteSourceSuffix.actualSuffix"]
    if module == "ExactChecks":
        roots.append("HermiteSourceSuffix.actualSuffix_expanded")
    axioms = {name: axiom_set(stdout, name) for name in roots}
    ordinary = all(value == ORDINARY for value in axioms.values())
    own_hash = sha(output) if output.is_file() else None
    receipt = {"module": module, "plan_sha256": sha(plan_path),
               "source_sha256": sha(source), "lean_sha256": PIN_LEAN,
               "selected_providers": selected, "proof_provider_sha256": proof_hash,
               "deps": dep_result, "deps_required_provider_matched": deps_matched,
               "compile": compiled, "own_sha256": own_hash,
               "ordinary_axioms": ordinary,
               "axioms": {k: sorted(v) if v is not None else None for k, v in axioms.items()},
               "accepted_roots": 0,
               "author_candidate_pass": module == "ExactChecks" and
                 compiled["exit_code"] == 0 and ordinary and deps_matched and own_hash is not None}
    receipt_path = attempt / ("PRIVATE-receipt-" + module + ".json")
    receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
    archive_path = attempt / ("PRIVATE-runtime-records-" + module + ".zip")
    with zipfile.ZipFile(archive_path, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for raw in sorted(attempt.glob("PRIVATE-*")):
            if raw.is_file() and raw.suffix != ".zip":
                archive.write(raw, raw.name)
    summary = {"attempt": attempt.name, "module": module,
               "source_sha256": receipt["source_sha256"],
               "exit_code": compiled["exit_code"], "timed_out": compiled["timed_out"],
               "seconds": compiled["seconds"], "available_before_MiB": compiled["available_before_MiB"],
               "own_sha256": own_hash, "ordinary_axioms": ordinary,
               "deps_required_provider_matched": deps_matched,
               "author_candidate_pass": receipt["author_candidate_pass"], "accepted_roots": 0,
               "raw_zip_sha256": sha(archive_path)}
    (attempt / "result.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
