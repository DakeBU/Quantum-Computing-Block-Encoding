# C321: exact empty-list endpoint repair only

C318 source exit1/20.328s, no accepted own output; consumer NOT run. Every
error is the last list membership disjunction z=den OR z in []. The original
simp-only set expands the last cons before mem_singleton can apply, leaving
the empty-list alternative. Actual Lean4.33 primary List.Lemmas:442 gives
mem_nil_iff; add it and or_false to the FOUR exact lists. All actual retained
integers, carry1/0, signed/zero branches, helper/public types and arithmetic
proofs remain byte-identical outside these four lists. Consumer is unchanged.

Original C310/C318 files and failures remain immutable. This is no change of
mathematical target or resource model; no new theorem premise, axiom, sorry,
unsafe/native computation, trust/linter/cap change. Original six-helper width
derivation still applies. Complete raw primitive Sites/actual-producer bit
coverage, native GCD/scratch/CPU/evaluator, quantum gates/cleanup/export and
scientific ROOT remain OPEN. Candidate uncompiled pending exact source and
new own-output expanded consumer gate. No success inferred from this repair.
