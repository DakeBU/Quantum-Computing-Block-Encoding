# C271: final bounded concrete inverse rewrite candidate

AUTHOR CANDIDATE, UNCOMPILED. Only decode_value's proof body changes.
All numerical definitions, scientific signatures, hypotheses, counters,
resource caps, type conventions and producer dataflow remain fixed.
All C268/C270 and earlier proof/failure/seal bytes remain immutable.

## Full released failure and diagnosis

The whole own C270 scalar feedback and proof-result.json were read.
Actual exit1 after28.015s, no timeout, no accepted own output and zero
actual-own consumed public roots. Source is exactly frozen C268:
c346448d9b7ada54251b2cdc6c6283ba54eb526472fc53bd6d160575265f0d9d.
The new c268_sumInverse helper prints ordinary propext/Quot.sound.
Only decode_value remains unsolved. Compiler recovery sorryAx is rejected;
other ordinary printed rows do not turn this failed module into a supplier.

The left goal is the complete four-level match on finSumFinEquiv.symm,
with component inverse leaves in original order0,d,2*k+1,0,d.
The right goal is the same original fullEquiv inverse application: four
nested sumCongr.trans finSumFinEquiv layers. The warning explicitly says
c268_sumInverse was unused in the old simp list. Thus the helper proof
did not fail; automated application to the concrete layered term failed.
It is NOT evidence of a false target or a compiler bug.

The raw helper signature quantifies implicit m/n and equivalence carriers.
The target's outer input is Fin(assemblySize k delta), while each nested
codomain uses a concrete component-size sum. The log establishes lack of
automatic matching, but does not isolate whether implicit dimension/carrier
inference or another simp matching detail caused it. An opaque assemblySize
explanation is therefore a hypothesis, not an established compiler diagnosis.
Repeating a larger generic simp list would not identify that cause.

## Exact, different strategy

Local PROOF-only lets fix d=sourceDegree delta, m=2*k+1, then the three
actual tail equivalences e4, e3, e2 with their complete Fin codomains.
These are literal suffixes of original fullEquiv, not new numerical data.

Each c268_sumInverse application supplies BOTH m/n widths, both actual
equivalences and the current exact Fin argument explicitly. The first
concrete equality hOuter is changed to have the syntactic left side
(fullEquiv k delta).symm a. Its proof is the fully instantiated helper
by definitional equality of the three suffix lets, with no theorem search.

The existing explicit outer split rewrite remains. The small existing
split/unpack normalization is used only on the decoder's literal value;
the inverse helper is no longer a simp argument. rw[hOuter] rewrites the
exact whole original inverse application. Cases on its first sum has two
branches: the left closes by rfl; the right explicitly constructs hSecond,
rw's it, and cases its sum. The same process uses hThird and hFourth.
The resulting five leaves close by rfl. This is four explicit layers,
not recursive automation or an expanded normalization search.

The helper, its audit queries, all other scalar proofs, and all public
statements are unchanged. Chain/checks/signatures are byte-identical to
C268/C261/C252. scalar-only.diff is an exact unified proof-body delta.
Reversing that body replacement reconstructs the C268 scalar text.

## If the parent gate still fails: STOP rather than iterate blindly

This is the final authorized bounded normalization candidate, not a claim
of acceptance. If it fails, preserve the exact source and diagnostic.
No automatic same-kind successor is authorized by this packet.

The minimal next probe plan, for separate parent authorization/execution,
is an isolated consumer of the already typed definitions and helper:
1. Check the explicit hOuter assignment with all widths/carriers as here.
2. Check its change to fullEquiv's exact inverse application, separately.
3. Check the exact rw[hOuter] before any sum cases.
4. Then check only the first cases equation and concrete hSecond.
Stop at the first mismatch and print that one elaborated type/body using
full explicit arguments. Distinguish defeq assignment, rw occurrence and
dependent cases failures; do not infer mathematical impossibility or
change the scientific target. No probe was executed by this author.

## Preserved evidence and boundaries

All63 previous raw input hashes were freshly recomputed and match. Original
C21 fullEquiv/componentEquiv/assemblySize and actual sumCongr/trans inverse
API bodies were inspected. Mandatory whole skill/protocol intake is retained
with matching pins. No cost/review outputs were opened. This author has
prior producer/proof/failure exposure, not independent-review or fresh
universal-decoder status.

Only new C271 files were written through apply_patch. No compiler, Python,
script, lake, Git, network or subagent; no source/target/premise/counter/
budget/trust/linter override, axioms, sorry/admit, native_decide or unsafe.

Seven VALUE roots remain unaccepted candidates; the cost root is not
authored here. This is not clean transitive TCB/source-to-binary closure,
scientific/publication ROOT, native bit/GCD/index/evaluator/runtime,
physical sharing/gates/angles/depth/cleanup/export, or global source-error/
normalization integration. Parent owns the next actual gate.
Freeze and STOP.
