# C275: separately authorized constructor-iota probe and successor

AUTHOR CANDIDATES, UNCOMPILED. This packet is separately authorized after
C272; it does not resume an unbounded generic rewrite loop. Freeze and STOP.
All old source/failure/seal packets remain immutable.

## Exact released blocker

The complete C272 own scalar feedback and proof-result.json were read.
Gate exit1 after29.859s, no timeout, no accepted own output, zero actual-own
consumed public roots. The recorded source is frozen C271:
925e09d9bc1bc5e9d9096d268132938f13e2c6251e0b0097e122f2113ff077cb.
Helper axiom rows are ordinary; decode recovery sorryAx is rejected.
No acceptance follows from the failed module or its other printed rows.

The actual diagnostic is at rw[hSecond], line81. The context has the exact
hSecond : e2.symm rest = match finSumFinEquiv.symm rest with ...
but the target RIGHT side is still
match Sum.inr rest with
| Sum.inl x => Sum.inl((componentEquiv 0).symm x)
| Sum.inr y => Sum.inr(e2.symm y).
The left side likewise retains its outer match on Sum.inr rest.
Thus e2.symm rest does not yet occur syntactically: e2.symm y is beneath
the branch binder. Constructor-iota must substitute rest for y first.

The compiler reached this first inr branch after explicit hOuter assignment,
change, rw and cases. This is prefix progress in a failed module, not an
independently accepted theorem. The remaining blocker is now concrete;
the prior generic matching ambiguity is not the operative failure here.

## Probe: small closed interface proposition, NOT scientific root

Probe.lean imports ONLY already typed ExplicitFiveBlockDefinitions. It does
not import any failed scalar module or rely on its generated output.
Its private c268_sumInverse text is exactly the existing helper proof.
The closed forall k,delta,rest proposition uses the actual first remaining
Fin width and original component/equivalence layout, for all parameters.

It isolates the first-inr constructor target and the second-layer inverse
rewrite. The lower suffix is retained as its literal actual e3 equivalence;
it does NOT assert or assume that the complete lower decoder is correct.
There is no arbitrary F, source oracle, callback correctness/cost promise,
or other probe hypothesis. The unchosen inl component is also the actual
componentEquiv0 inverse, not an arbitrary branch function.

First change rebinds the literal original e4/e3/e2 suffixes to proof-local
names. The second change explicitly performs only the outer constructor-iota
reduction on both sides, yielding Sum.inr(next match) = Sum.inr(e2.symm rest).
Then rw[hSecond] rewrites the exact actual application and closes equality.
Using explicit change here keeps this minimal probe's rewrite visible; it
does not depend on a simp list or accidentally demand later decoder steps.

Both the helper and the named probe theorem have exact #check/#print axioms
queries. The probe is an interface test, not a C250 VALUE/cost/scientific root.

## Conditional successor

ExplicitScalarValueProof.lean differs from C271 by exactly THREE lines:
simp only [] immediately before rw[hSecond], rw[hThird], rw[hFourth].
Empty simp performs constructor-iota reduction after each inr cases branch;
no additional generic theorem is passed to simp. All explicit width/carrier
instantiations and helper equalities are unchanged. Each following rw can
then see the current rest argument instead of a hidden match binder.

No other scalar proof, declaration statement, audit query, import or option
changes. Chain/checks/signatures are byte-identical to C271/C268/C252.
The exact three-line unified delta is scalar-only.diff. Reversing those
three insertions reconstructs C271 scalar text. This remains a candidate;
a successful interface probe alone does not establish the full scalar,
whole QData, Window, refines or source-action value claims.

Parent execution order is STRICT: gate Probe first in own output with its
exact proposition and ordinary axiom checks. If Probe fails, STOP and do
not run scalar. Only after actual accepted probe may parent gate scalar,
then unchanged chain and consumer. Bind every phase to its own exact hashes.
No gate was run by this author, and no successful result is presumed.

## Provenance and boundaries

All71 previous raw input hashes were freshly recomputed and match.
Mandatory whole skill/protocol intake and raw definition/API intake are
retained with matching pins. C272 whole feedback/result are explicitly
bound. Source inspection is not a clean loader/transitive-TCB/source-to-
binary closure. Author has earlier producer/proof/failure exposure; not
an independent reviewer or fresh universal decoder.

Only new C275 files via apply_patch. No compiler, Python, scripts, lake, Git,
network, subagents, cost/review outputs, trust/budget/linter overrides,
new axioms, sorry/admit, native_decide or unsafe shortcuts.

All original scientific signatures, producer numerical bodies, masks/order,
source conventions, hypotheses, counters and resource caps remain unchanged.
Seven C250 VALUE roots remain candidates; eighth same-run cost root is not
authored here. No finitebit/GCD/native index/evaluator/runtime, physical
sharing/angle/gate/depth/export, global normalization/source-error, publication,
clean TCB, main/reader, full SP or scientific ROOT credit is claimed.
Freeze and STOP; a failed probe requires a separate decision, not blind retry.
