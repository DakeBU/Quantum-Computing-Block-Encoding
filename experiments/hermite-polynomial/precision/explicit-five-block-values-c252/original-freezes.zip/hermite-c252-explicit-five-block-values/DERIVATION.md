# C252: exact explicit five-block values

AUTHOR PROOF CANDIDATE, UNCOMPILED. C250 StatementSeal was issued before this
proof search. Seven sealed VALUE declarations are authored; the eighth sealed
same-run COST declaration is deliberately not authored here. There are no new
source, definition, counter, target or hypothesis changes. Parent owns execution.

## Frozen statement and evidence layer

The input seal is the original C250 STATEMENT_SEAL.json, SHA256
`1ee0a43d79faf7dbaeb86141894013c385b248b9e980d27c5d2ce07f9f60832a`.
The local sealed-signatures.txt is an exact byte copy of its eight-signature
file, SHA256 `af97ff68d6da6545abc9a7ee1abeaa755923dc22c4ac8b287d19f9fbc5b6acb0`.
Only the seven value names below are claimed as authored proof text, not as
accepted Lean results. Definition source is the immutable C248 module SHA256
`bbdca858e3254f47f65a9dfc2752ded85a8afa48409c41d004c0c1848fe4ed7f`.

The parent's C249 type gate and C250 seal establish proposition formation,
not these proofs. This author did not run a compiler, evaluator or simulator.
No ordinary-axiom result, own olean or independent review is claimed for C252.

## Mathematical argument

### 1. Decode the exact original index, not another bond space

A sum index i:Fin(m+n) is split at m. Its two branches are precisely the
inverse finSumFinEquiv, proved by the Fin.addCases eliminator on castAdd and
natAdd inputs. Within each component, unpackComponent applies the exact two
inverse product equivalences that componentEquiv used in the forward direction.
Their composition is definitionally the inverse of the nested product map.
Replacing the four literal splits and five component decodes with these inverse
maps gives the inverse of the exact fullEquiv. Specializing d=sourceDegree(delta)
and m=2k+1 therefore gives sealed decode_value. No cardinality choice or changed
sum order is used, and neither d nor the rank is replaced with 2k+6.

### 2. Comparison entries

For digit=(cut/2^q)%2, the generated next relation is 0 if bit<digit, 2 if
digit<bit, and the previous relation otherwise. The final equality test with
the requested output state returns rational one or zero. These are exactly
finish and comparisonEntry, in that priority order, for all natural cuts/q.
The proof splits the two comparisons and retains the original q LSB convention.
It does not need the cut to be an interior point or require a positive radius.

### 3. Translation consumes the actual generated factorials

On row<=column, actual chooseFrom reads three entries of the returned factorial
table and computes the column-choose-row coefficient. Its value dependency is
the existing C23 factorials_value/chooseFrom_value pair, instantiated with the
actual factorials(L), not an arbitrary caller's correctness promise. The
typing bound r<=L ensures all three reads are legal. Existing powQ_value
converts both multiplication recurrences to the corresponding rational powers.
The charged bit conversion is exactly the rational cast of its Fin2 value.
The result is choose(j,i)*(step*2^q*bit)^(j-i), with the original multiplication
order and truncated natural subtraction.

On column<row, the literal producer returns zero. Nat.choose_eq_zero_of_lt
makes the original translationCoreQ zero as well. This does not reinterpret
0^0 or discard the lower triangle by assumption. For degree zero both indices
are zero and the original constant-component value is retained. Zero and
negative steps are allowed; no division by a step occurs in this adapter.

### 4. All five kernel and left components

The actual C168 rightSetup_values supplies all four original cuts on the full
rational parameter carrier. Substituting those actual cuts into the two
comparison factors, and the translation identity into the third factor, gives
each diagonal component of actualBlocksQ. Off-component entries are literally
zero in both constructions. The proof enumerates the five row and five column
tags without changing their order or masks. Products are first*(second*scalar).

For left boundaries, two tests of relation state=1 multiply the actual origin
power. The five origins are 0,-R,-R,0,R; forward/middle steps are h and the
reflected tail step is -h. There are no mask flips in either kernel or left;
the old actual charged rightEntry retains its original flip flags. The two
constant components keep exponent zero, hence the original 0^0=1 semantics.

### 5. Same returned RationalData

A narrow collection bridge uses entrywise equality to identify the actual
collectIndexed output with the actual collect output. It is applied three
times to the table shape and once to each boundary vector. Vector extensionality
uses explicit Fin indices and the existing collection entry facts. It does not
transport an auto-generated GetElem witness through a congrArg callback.

The right boundary requires no new coefficient computation or correctness
premise: both sides call the same original charged rightEntry with the same
actual setup, midpoint, source cache and middle vector. The new decoder_value
supplies exactly the original structured index; the explicit type-family cast
reduces at the reflexive degree equality in the prepared-value lemma.

The whole producer's second charged cutoff computes the same d as sourceDegree
definitionally. Actual gridStepRun_value and the two literal charged subtractions
give h,-R,-h. Choosing L=d+2k+1 supplies the two index bounds internally. The
remaining carrier transport only changes the presentation of Fin/vector sizes.
Thus the actual returned QData equals the old cached QData, not merely a scalar
table envelope or a few amplitudes. The producer body itself remains unchanged
and does not evaluate the old semantic callbacks to obtain those values.

### 6. Cast and canonical chain on those same values

Actual castData applied to equal returned RationalData gives the same RealData.
The existing C193 cached Window theorem therefore supplies the sealed new
Window. Applying canonical ofTable to the identical returned RealData gives
the same stored-chain value; the existing C193 cached refines theorem then
identifies its denotation with actualChain. Finally the original C21
actualChain_contract supplies the exact physical source action, with its
original sole 0<R premise. No normalization, success or positivity fact is
silently added to the other six value interfaces.

## Reuse and literal source dependencies

| provider | actual role |
| --- | --- |
| immutable C248 ExplicitFiveBlockDefinitions | numerical producer, literal dispatch/casts and all unchanged annotations |
| C159 CachedPrimitivesProof | actual powQ_value and gridStepRun_value; other imported cost facts not claimed as C252 conclusions |
| C23 ChargedSourceCache | generated factorial values and chooseFrom identity, not a supplied factorial oracle |
| C168 CachedSetupProof | four actual cut equalities, without radius/delta sign restrictions |
| C174 CachedMiddleValueProof | inherited actual-cache/middle dependency of C193; not reimplemented |
| C193 CachedChainValueProof | same cached data Window and stored refines interface, with actual setup/cache/middle/right values |
| C22 RationalBlocks/StoredProducer | literal BlockQ/actualBlocksQ/actualEntryQ/actualLeftQ specs and actual castData |
| canonical StoredBinaryCoordinates/StoredGivens | collectIndexed/collect values and the inherited run records |
| C21 ActualAssembly | fullEquiv, actualChain and original positive-radius physical action theorem |
| Lean Init Fin.addCases and Mathlib Fin equivalences | exact sum/product inverse adapters, not new quantum foundations |
| Mathlib Nat.choose_eq_zero_of_lt | the actual lower-triangular zero identity |

The proof source imports the two actual module names ExplicitFiveBlockDefinitions
and CachedChainValueProof; the latter supplies C159/C168/C174 transitively.
Parent must route exact admitted providers plus C249's own definitions output.
Raw hashes do not independently establish complete loader selection or source
to binary equality. Inherited/dirty context and clean-transitive-TCB boundaries
remain visible; no new global build or publication gate is claimed.

## Acceptance and residual risk

New modules: ExplicitScalarValueProof (three sealed roots and three private
adapters), ExplicitChainValueProof (four sealed roots and nine private value
bridges). Every private adapter has #check/#print axioms in its owning module;
ValueProofChecks casts all seven roots to their exact C250 types, prints their
actual axioms, and prints the imported numerical definitions. Those commands
are authored consumers, NOT actual output yet.

Most delicate untested Lean points: simplification of fullEquiv's inverse,
dependent let/degree/carrier transport in produceExplicitQData_value, unfolding
the 25 kernel tag branches, and exact collection/structure congruence. These are
implementation risks, not a claim of impossible mathematics or a compiler bug.
No known mathematical gap is being replaced by a hypothesis or placeholder.
If a gate fails, preserve the failed source/output and use a versioned successor.

No cost root is included. Equality of returned values does NOT imply equality
of producer ledgers: the new kernel/left dataflow must be costed from its actual
body by the separate worker. In particular this packet cannot rewrite new costs
to the old cached partial ledger. Native index/floor/ceil/clog/power/cast costs,
rational bitlength/GCD, allocation/evaluator behavior, physical sharing,
normalization/error integration, finite angles/gates and full scientific ROOT
remain outside this value proof packet even if its seven roots later compile.

Failure class: NONE for authored candidate delivery; no C252 gate run.
Salvage: cohesive scalar layer can be compiled before the dependent chain layer.
Process-memory IDs: none. No subagents or new parallel delegation.
Exposure: author of C237/C243/C248 and earlier cached value/setup proposals;
parent-reported type/provider gate facts known. Not a fresh universal decoder,
independent reviewer, ProofSeal, PublicationSeal or PURIFIED completion.
All old sources, failures, seals and production files are unchanged.
Freeze and STOP; parent owns all compilation, review and later integration.
