# C261: scalar decoder normalization repair only

AUTHOR CANDIDATE, UNCOMPILED. This additive successor retains C250's exact
pre-proof seal and C248 numerical definitions. It changes only the scalar
split-index and decoder proof normalization. No source, counter, model, target,
root hypothesis, cost-budget or linter/trust setting is changed.

## Actual predecessor failure

The complete C260 scalar feedback and proof-result.json were read. C260's
parent-owned gate exited1 after28.078s with PROOF_OR_AXIOM_FAILED, no timeout,
no accepted own output, and zero actual-own consumed public roots. The source
hash was the frozen C252 scalar hash. Two diagnostics were present:

1. At line17, rewriting dif_pos a.isLt did not match the unreduced guard
   `↑(Fin.castAdd n a)<m`.
2. At line36, the decoder simpa left its outermost splitIndex unreduced on
   the assemblySize-indexed argument, with nested inverse equivalences on the
   right. Inner split rewrites had already normalized.

Compiler recovery reported sorryAx in the failed split and decode declarations.
That failed module/output was REJECTED, not accepted or consumed. The raw
author source contains no written hole; this observation does not excuse the
failed proof or turn compiler recovery into trusted evidence. Other scalar
declarations printed ordinary axiom rows, but module failure means there is
still no accepted scalar supplier from C260. C252/C260 remain unchanged.

Failure class: IMPLEMENTATION_FAILED (proof normalization), not REFUTED and
not a claim that the compiler or mathematical target is wrong.

## Exact repair, unchanged mathematical argument

First normalize the castAdd value using the actual Lean API Fin.val_castAdd;
then the existing strict-bound proof matches the dependent conditional. This
does not replace the guard, modify splitIndex, or change its zero/end branches.
The right natAdd branch is unchanged.

For decode_value, expose the literal decoder, then instantiate the outer split
identity with BOTH concrete component-size parameters and the exact argument a.
This avoids asking the simplifier to infer an additive carrier through the
opaque assemblySize spelling. The remaining splits and component product
inverses use the same identities as before. Explicit Equiv.symm_trans_apply
normalizes inverse composition; the actual Equiv.sumCongr, Sum.map and Sum.elim
bodies normalize nested sum inverse actions to the same literal match tree.

This remains the inverse of the original fullEquiv, preserving all five tags,
product state order, degree-dependent rank and numerical indexing. It adds no
arithmetic/cost/value hypothesis. The actual decoder, comparison, translation,
kernel, left/right entries, arrays, castData and canonical ofTable are immutable.
There is no new generic source or factorial correctness promise.

Only two scalar proof regions differ, recorded in scalar-only.diff. Chain,
exact public consumer and eight sealed signatures are byte-identical to C252.
In particular comparisonQ_value, translationQ_actual_factorials, all four higher
value proof texts, source hR, and the excluded same-run cost target are unchanged.
The old C252 derivation remains the full value argument; this note records the
bounded normalization mechanism that the actual failure showed was missing.

## Raw APIs inspected

- Lean Init/Data/Fin/Basic: actual castAdd and natAdd definitions.
- Lean Init/Data/Fin/Lemmas: Fin.val_castAdd, Fin.val_natAdd, Fin.addCases.
- Mathlib Logic/Equiv/Fin/Basic: actual sum equivalence and its inverse lemmas.
- Mathlib Logic/Equiv/Defs: exact symm_trans_apply type/body.
- Mathlib Logic/Equiv/Sum: actual sumCongr and inverse definition.
- Lean Init/Data/Sum/Basic: actual Sum.map and Sum.elim definitions.

Source/API inspection is not a complete source-to-binary or loader audit. All
prior source/protocol bindings are retained and rehashed; new narrow API pins
are recorded separately. No extra imports or numerical definitions were added.

## Pending acceptance and preserved boundaries

No C261 compiler/consumer/axiom gate was run. These normalization steps may
still need implementation repair after the parent actual gate; their success
is not assumed here. No native decisions, axioms, sorry/admit shortcuts or
blanket option/linter overrides are present. Seven public value signatures
remain the exact C250 signatures; no same-run cost proof is included.

The C253/C258/other review outputs were not opened. No independent review,
source publication, accepted proof seal, clean transitive TCB, native bit/GCD/
index/evaluator/allocation runtime, physical sharing/gates/angles, normalization
or full SP/scientific ROOT conclusion follows. Values alone do not equate the
new producer's ledger with the old cached partial ledger.

No compiler, Python, provided/new script, lake, Git, network or subagent work.
Only new C261 files were written via apply_patch. Old proof/failure/seal bytes
are preserved. Parent owns the next actual scalar/chain/consumer gate; any
failure must remain bound to this source and receive an additive successor.
Freeze and STOP.
