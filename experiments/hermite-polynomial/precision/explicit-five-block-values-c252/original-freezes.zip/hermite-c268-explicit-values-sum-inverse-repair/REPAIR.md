# C268: bounded inverse-application normalization repair

AUTHOR CANDIDATE, UNCOMPILED. Only the decoder proof normalization changes.
C250's pre-proof seal, exact eight signatures, C248 numerical definitions,
all root hypotheses, operation counters, resource bounds and conventions
remain unchanged. C261/C266 and all earlier packets remain immutable.

## Actual C266 failure and remaining goal

The complete own C266 scalar feedback and proof-result.json were read.
Actual scalar gate exit1 after28.672s; no timeout, no own accepted output,
zero actual-own consumed public roots. Its source hash is exactly C261's
a785fe4c71da8614c1a022b0984d27997c85a5846d24735dbbeda6b0bb0aa5fa.
The splitIndex helper now prints only propext and Quot.sound; unpack, bit,
comparison and translation print ordinary rows. The only diagnostic is
decode_value line41. Its recovery sorryAx is REJECTED. Module failure still
means no accepted scalar supplier, irrespective of other printed rows.

The complete remaining goal was inspected before choosing this repair.
Its left side is the four-level match on finSumFinEquiv.symm, applying the
componentEquiv inverses in order0,d,2*k+1,0,d. Its right side is still
(fullEquiv k delta).symm a, represented after old simp expansion as nested
Equiv structure literals, trans, symm and function coercions. The outer
split is no longer the problem; only the inverse application tree remains.

For precise structural reconstruction, let d=sourceDegree delta, m=2*k+1,
C(r)=componentEquiv r, and S(e,f)=(Equiv.sumCongr e f).trans finSumFinEquiv.
The literal original right-hand inverse is
S(C(0),S(C(d),S(C(m),S(C(0),C(d))))).symm a.
The normalized literal left-hand value is:
- outer left: inl(C(0).symm x);
- outer right, second left: inr(inl(C(d).symm x));
- two rights, third left: inr(inr(inl(C(m).symm x)));
- three rights, fourth left: inr(inr(inr(inl(C(0).symm x))));
- four rights: inr(inr(inr(inr(C(d).symm x)))).
Every choice is the corresponding actual finSumFinEquiv.symm branch on its
remaining Fin index. This restates the released goal, not a new decoder.

## Different normalization mechanism

One new private theorem c268_sumInverse exposes the pointwise inverse of
S(e,f) directly as the two-branch match on finSumFinEquiv.symm i.
Its proof changes only to the actual Sum.map inverse function, cases on
that sum, and closes each branch by rfl. This uses the raw sumCongr inverse
and trans definitions, not a guessed normalization lemma or callback premise.
The theorem is Type-valued and private; its quantified e/f are not hypotheses
of any public value theorem.

The decoder proof retains C261's explicit concrete outer split rewrite.
It then uses only the already established split/unpack identities, the
actual fullEquiv definition, and this one pointwise inverse theorem.
Four applications produce exactly the original five-tag match tree.
It no longer unfolds sumCongr structure records through a broad simp list.
No numerical body, array/index convention, carrier or theorem target changes.

The helper's full type and axiom query are included in the owning source.
Existing public checks and all other scalar proof regions are unchanged.
Chain, exact consumer and sealed signatures are byte-identical to C261/C252.
scalar-only.diff records precisely the helper, decoder normalization change
and helper audit queries; reversing those changes reconstructs C261 source.

## Inputs and acceptance boundary

All55 C261 raw input hashes were freshly recomputed and match. Actual C21
fullEquiv/componentEquiv/assemblySize and C248 decoder definitions were read;
the narrow raw Equiv sumCongr and inverse/trans APIs were inspected again.
Mandatory whole protocol intake is retained with unchanged matching pins.
This is not independent review, a fresh universal decoder, or a complete
source-to-binary/loader/clean-transitive-TCB audit. The author has prior
producer/proof/failure exposure. No cost/review outputs were opened.

No C268 compiler, consumer or axiom gate was run. The new helper and selected
rewrites remain an implementation candidate, not an accepted proof. There
is no demonstrated mathematical/interface impossibility: the remaining goal
has the same literal branch structure on both sides; actual elaboration and
normalization must still be tested by the parent. If this bounded repair fails,
preserve that actual failure rather than assuming successful normalization.

No compiler, Python, script, lake, Git, network or subagent was used. Only new
C268 files were written via apply_patch. No trust, budget or linter override,
axiom, sorry/admit, native_decide, or unsafe shortcut was introduced.

Seven VALUE roots remain candidates; no same-run cost proof is authored here.
No native index/floor/ceil/clog/bit/GCD/evaluator/allocation runtime, physical
sharing, angle/gate/depth/cleanup/export, normalization/source-error global
integration, source publication, accepted proof seal, main/reader/scientific
ROOT closure follows. Parent owns the next actual proof/axiom/consumer gate.
Freeze and STOP.
