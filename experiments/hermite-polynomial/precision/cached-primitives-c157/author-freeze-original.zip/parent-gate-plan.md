# Parent-only focused gate plan (not executed)

Use the C156-pinned Lean 4.33.0 executable and the exact inherited provider
environment that passed C155. Verify the seal/signature/C150 file hashes before
and after. Keep C145/C150/C155/C156 read-only. Create a fresh parent-owned output
directory; do not reuse an existing CachedPrimitivesProof.olean.

Below, the working directory is this C157 packet. `parent-output` is a new
parent-owned gate output directory inside its fresh gate scope; the parent may
choose its physical location and must record the actual resolved arguments.
The following command argument lists are the proposed exact operations, not
claims of execution:

```text
lean --deps CachedPrimitivesProof.lean
lean -o parent-output/CachedPrimitivesProof.olean CachedPrimitivesProof.lean
lean --deps PrimitiveProofChecks.lean
lean -o parent-output/PrimitiveProofChecks.olean PrimitiveProofChecks.lean
```

The inherited source/provider environment is bound in the complete C156 seal,
not recreated from guessed system caches. Add the fresh parent-output first
for the consumer; resolve CachedRightSetup/CachedMiddle from C155's exact
type-probe outputs (module hashes recorded in input-manifest.json), followed by
the unchanged sealed dependency providers. Keep current C157 source separately
visible as needed. Inspect --deps output rather than inferring selection from
LEAN_PATH text. The dependent signature formation/type checks must come from
the exact newly compiled own-output proof module, never a prior cache.

The proof source already prints axioms of all seven roots. The consumer repeats
exact type ascriptions and axiom expansion against the fresh output. Retain
ordinary axioms exactly as reported; reject sorryAx, new custom axioms, unsafe
or native-decision trust additions. No changed gate rules, counter semantics,
score or validation shortcut is proposed. Source/definition/axiom audit remains
distinct from independent mathematical/value/cost review.

Compile failure does not authorize changing executable bodies or sealed theorem
types. Preserve raw output, failed candidate and exact provider selection before
a bounded proof-only successor. Full repository Lean/Tests and any production
publication/site/root gates are later parent-owned requirements.
