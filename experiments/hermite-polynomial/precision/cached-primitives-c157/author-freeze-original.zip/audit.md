# C157 bounded primitive/right proof freeze

Status: PROOF_SOURCE_CANDIDATE / NOT_COMPILED / NOT_ACCEPTED. Parent-issued
C156 exact-body/signature seal was read completely before proof authoring.
No C145/C150/C155/C156 or production file was edited. No compiler, lake,
network, Git, subagent, provided script or finite computation was executed.

## Exact objective and seal boundary

Direction: `C145_ACTUAL_C23_CACHE_CONSUMPTION_IN_C22_SAME_CHAIN`.
The original `SP-HERMITE-POLY-002` normalized little-endian state and all its
scientific acceptance requirements are unchanged. Phase-3A is only the bounded
seven-root primitive/right subpackage authorized by the parent, not complete
middle/setup/chain integration.

The C156 seal is bound by SHA256
`e4be7acce67f288b8b70755da16c4f0c40bba589cd40454b45111547b2c5ee5a`;
its complete signatures file is
`55c9becf19da0fde666a7c3d01e7fd72f6a027e9dd34db39bf2058b7860480b1`.
Its four C150 definition/proposition input hashes were reread mechanically and
all matched. C155's successful type probe is inherited parent evidence, not a
C157 proof or a compiler run by this author.

Public candidate theorem names in namespace HermiteCachedPiecewiseStored:

- powQ_value and powQ_cost;
- cutoffQ_value and gridStepRun_value;
- acceptRun_value and acceptRun_total_le;
- rightEntry_total_le.

Their full types match the selected C156 propositions verbatim up to whitespace.
PrimitiveProofChecks is an author-authored fresh-output consumer with exact
type ascriptions and axiom reports for these seven roots. It is not independent
review and has not run.

## Own mathematical derivation and proof plan embodied in source

For powQ, the zero case returns literal one with zero counters. Each successor
multiplies the previous returned rational by x through qMul and adds exactly
one field tick. Induction on m therefore gives x^m and m*tick.field in every
counter. No positivity, nonzero, precision or termination promise is needed.

cutoffQ's returned value unfolds definitionally to exactly the original
tailCutoff formula, including delta=0 and delta<0. This value equality does
not certify any cost of the native ceil/log portion. gridStepRun's numerator
is 2*R and its denominator is the actually returned powQ 2 width value;
the pow theorem identifies it with the old gridStepQ. R=0 is not excluded.

For acceptRun, enumerate the two flip cases and the three exact dispatch tests:
cut=0, cut=2^width and a=0. The values agree with the old acceptQ, including
empty/full/interior cases. The counter is at most three comparisons and one
subtraction, hence at most four in the eight-category total. The proof candidate
uses symbolic case splits and ordinary simplification; no native verifier,
finite instance, conditional cost promise or callback replacement is used.

For rightProduct, unfold the actual Run.bind composition. It returns the two
acceptors' counters plus the actual supplied coefficient Run's entire counter,
plus the two actual multiplication ticks. The private exact-cost lemma retains
that arbitrary coefficient cost; it never declares an arbitrary coefficient
supplier free. Two concrete helper lemmas then discharge coefficient work for
the actual allowed call sites: pure fixed scalar projection has zero added
annotation, and a real StoredGivens.read has one read tick. These helpers have
no caller-supplied correctness or upper-bound hypotheses.

Finally split the actual FullIndex sum into all five branches in their original
order. Clipped branches use the concrete pure-scalar helper; both tail branches
and the signed-middle branch use the concrete stored-read helper. Each has at
most 4+4+1+2=11. This covers arbitrary stored values and cuts, including all
zero/full/interior cuts and k=n=0. Correctness of those values is not needed for
this scalar annotation bound and is not falsely asserted by it.

## Expanded binders and definitions

Public binders x,R,delta:Rat; k,n,width,cut,m:Nat; finite indices and words; and
Op are TYPING/carrier or original construction inputs. No logical premise was
added to any of the seven sealed types. No `cache correct`, `right correct`,
Window, positivity, denominator nonzero, resource upper bound or desired-output
premise appears. EXCESS binders: none proposed.

RightSetup is the sealed data-only structure: four Nat cuts, one tail vector,
two rational scalars. Its phantom n/R parameters and dependent delta dimension
do not carry assumptions. FullIndex is the original five-way nested Sum of
two Fin3 comparison states and one finite polynomial index. Run is returned
data plus the eight-counter function. Counter inequalities are conclusions,
not a hypothesis smuggled through these structures.

Private helpers are cost algebra for this exact operation model: total-add,
one field tick, one real stored read, exact right-product total, and the two
concrete coefficient forms. They contain no cost oracle or assumed source
property. The source does not define a new quantum representation, executable
body, state, native-cost schema, or desired-output stub.

## Important captured-block correction and cost frontier

Captured actualBlocksQ construction/setup is UNACCOUNTED, in addition to
kernel/left scalar evaluation. Merely binding the block once does not prove
that compiled eager/lazy evaluation eliminates old threshold/clippedValue
construction or that no setup work is duplicated. C150's phrase “one actual
midpoint/setup” describes the explicit named producer dataflow only. It must
not be read as a certified runtime one-evaluation claim. This correction is
now explicit in the proof module header and this handoff; all frozen files
remain unchanged.

The proofs address existing Run.cost annotations only. Native integers,
casts, floor/ceil/clog, rational bitlength and GCD, allocator/compiler/evaluator
behavior, counter evaluation and compiled sharing remain unproved. The future
full-chain partial bound must retain actual rightSetup.cost and this captured
setup caveat. No finite-bit, full preprocessing, physical gate, synthesis,
runtime or ROOT conclusion is made.

## Dependency/source graph and verification requirements

The raw source construction remains source coefficient + finite exponential
supplier -> signed middle -> five exact masks/polynomials -> physical-grid
chain -> normalized original target. The present source-level proof graph only
supplies primitive power/grid values and the charged right-entry bound; it
does not discharge midpoint/setup, middle coefficient equality or the chain.
The Lean graph is still a proposed proof source until the parent's exact fresh
compile. A source call graph or import is not an elaborated theorem graph.

The only import is CachedRightSetup, bound by C156/C150. Its direct new-provider
parent is CachedMiddle; the raw rational and canonical operations remain the
sealed C23/C22/production imports. The selected C155 CachedRightSetup/CachedMiddle
compiled outputs are inherited provider pins, not freshly rebuilt by C157.
No independent C157 reviewer or its output was exposed to this author.

`parent-gate-plan.md` lists the exact planned command arguments and required
environment/provider checks. None was executed. The parent must compile actual
own source into new output, then type-check PrimitiveProofChecks with that new
output first in resolution. Record dependencies, before/after input/output
hashes and all seven axiom expansions. A stale imported theorem cannot accept
the candidate. Full lake/Tests and applicable publication/root gates remain
the parent integration requirements, not replaced by this focused packet.

## Uncertainty and explicit repair obligations

No compiler failure is available to classify as mathematical evidence. The
candidate may require a proof-only simp/normalization repair, especially for
monadic instance unfolding in powQ_cost/rightProduct, Boolean dispatch or
dependent Sum elimination. If the parent compile finds one, preserve this
exact candidate and feedback and repair only the proof in a new successor
scope. Do not edit C150, weaken C156, or append a helpful hypothesis.

Concrete setup values/midpoint lemmas were not attempted in this first bounded
freeze. Their next dependency-ready task is literal cut/midpoint/factorial
array correctness, followed by rightSetup_values. This is a residual goal, not
an API obstruction or a claim the source is false. The seven requested roots
are all supplied as complete proof candidates, with no placeholders.

## Required substantive-worker handoff

Objective/frontier: seven sealed primitive/right roots needed by actual cached
C22 supplier integration. Delta: complete symbolic proof candidates and exact
type/axiom consumer; no accepted Lean delta before the parent gate.

Named evidence: CachedPrimitivesProof.lean, PrimitiveProofChecks.lean, this own
derivation, parent-gate-plan.md and input-manifest.json. No tests or finite
witnesses were executed. Input seal and C150 source hashes are preserved.

Files changed: only new C157 files; no production or frozen/predecessor change.
Reusable insight: coefficient Run costs must stay in the exact composition
identity, and only the actual fixed-scalar/stored-read cases can discharge them
without new public premises. All five branches remain reachable.

Failure class: NONE for authoring; candidate uncompiled, no claim proved.
Salvage: preserve all source candidates; existing C22 baseline and C150 bodies
remain unchanged. No discarded route or cleaned artifact. If a focused gate
fails, its output is implementation/API evidence until independently analyzed.

Process-memory IDs: QBE-PM-LOW-TOKEN-CONTROL-PLANE and
QBE-PM-VERIFIER-SEMANTIC-LEVEL. The already-read substantive-worker protocols
govern this bounded packet. Raw source and the parent seal, not a reviewer
verdict, supplied the proof inputs. Seal intake's long initial output was
truncated; the missing provider-pin region was reread before proof authoring.

Parallel admission/common-blind-spot: parent-authorized distinct integration
work; no child agents. Independent value/cost/semantic review is pending.
Default verified route: unchanged inherited C22 baseline, not this uncompiled
candidate. No speed or verified-route comparator claim.

Purification/Exposition Seal: NOT_STARTED. These private composition helpers
should be retained only if the compiled right-entry root genuinely consumes
them. All register/order/phase/ancilla/normalization/error contracts are unchanged
and outside this primitive proof; their preservation still requires the later
same-data/chain bridges and original root gates.

Recommended next action: parent serialized fresh source compile and exact
consumer/axiom audit; preserve failures before proof-only repair. Stop after
this bounded author freeze. Middle/fullchain and complete setup are not silently
claimed finished or replaced by wrapper results.
