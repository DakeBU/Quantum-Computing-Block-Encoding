import PiecewiseSourceBudget

#print HermiteFiniteExp.tailCutoff
#print HermiteFiniteExpDegree.degree
#print HermiteFiniteExpDegree.sourceDegree
#print HermitePiecewiseSourceBudget.sourceDelta
#print HermiteFiniteMiddleSource.amplificationQ
#check HermiteFiniteExpDegree.degree_formula
#check Nat.clog_le_iff_le_pow
#check Nat.le_pow_clog

#check (∀ (k n : ℕ) (epsilon : ℚ), 0 < epsilon →
    HermiteFiniteExpDegree.sourceDegree
      (HermitePiecewiseSourceBudget.sourceDelta k n epsilon) ≤
    4 * (n + 1 + 2*k + HermiteFiniteExp.tailCutoff
      (epsilon / (4 * ((k+1 : ℕ) : ℚ)^2)))^2 +
    2 * (n + 1 + 2*k + HermiteFiniteExp.tailCutoff
      (epsilon / (4 * ((k+1 : ℕ) : ℚ)^2))) + 1)
