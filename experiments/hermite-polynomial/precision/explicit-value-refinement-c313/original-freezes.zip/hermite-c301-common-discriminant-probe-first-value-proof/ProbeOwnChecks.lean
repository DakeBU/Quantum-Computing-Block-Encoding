import Probe

/-! C275 interface probe only. No failed scalar import; no scientific root. -/

namespace HermiteExplicitCachedStored.C275Probe

open QuantumBlockEncoding QuantumBlockEncoding.StoredGivens
open QuantumBlockEncoding.StoredBinaryCoordinates
open HermitePiecewiseAssembly HermitePiecewiseUniform

example (k : ℕ) (delta : ℚ)
    (rest : Fin (componentSize (HermiteFiniteExpDegree.sourceDegree delta) + (componentSize (2*k+1) +
        (componentSize 0 + componentSize (HermiteFiniteExpDegree.sourceDegree delta))))) :
    ((match (Sum.inr rest : Fin (componentSize 0) ⊕ Fin (componentSize (HermiteFiniteExpDegree.sourceDegree delta) + (componentSize (2*k+1) +
        (componentSize 0 + componentSize (HermiteFiniteExpDegree.sourceDegree delta))))) with
      | .inl x => .inl ((componentEquiv 0).symm x)
      | .inr y => .inr (match finSumFinEquiv.symm y with
        | .inl x => .inl ((componentEquiv (HermiteFiniteExpDegree.sourceDegree delta)).symm x)
        | .inr z => .inr (((Equiv.sumCongr (componentEquiv (2*k+1)) ((Equiv.sumCongr (componentEquiv 0) (componentEquiv (HermiteFiniteExpDegree.sourceDegree delta))).trans finSumFinEquiv)).trans finSumFinEquiv).symm z))) : FullIndex k delta) =
    ((match (Sum.inr rest : Fin (componentSize 0) ⊕ Fin (componentSize (HermiteFiniteExpDegree.sourceDegree delta) + (componentSize (2*k+1) +
        (componentSize 0 + componentSize (HermiteFiniteExpDegree.sourceDegree delta))))) with
      | .inl x => .inl ((componentEquiv 0).symm x)
      | .inr y => .inr (((Equiv.sumCongr (componentEquiv (HermiteFiniteExpDegree.sourceDegree delta)) ((Equiv.sumCongr (componentEquiv (2*k+1)) ((Equiv.sumCongr (componentEquiv 0) (componentEquiv (HermiteFiniteExpDegree.sourceDegree delta))).trans finSumFinEquiv)).trans finSumFinEquiv)).trans finSumFinEquiv).symm y)) : FullIndex k delta) :=
  firstInr_constructor_iota_hSecond k delta rest

#check HermiteExplicitCachedStored.C275Probe.firstInr_constructor_iota_hSecond
#print axioms HermiteExplicitCachedStored.C275Probe.firstInr_constructor_iota_hSecond
end HermiteExplicitCachedStored.C275Probe
