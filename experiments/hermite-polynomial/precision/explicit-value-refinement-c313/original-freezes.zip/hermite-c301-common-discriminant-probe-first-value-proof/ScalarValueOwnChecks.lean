import ExplicitScalarValueProof

/-! Exact C250 VALUE signatures and actual dependency-axiom queries.
This consumer is authored, not run by the author. Cost root is intentionally
absent: it belongs to a separately authorized worker/composition phase. -/

open QuantumBlockEncoding QuantumBlockEncoding.StoredGivens
open QuantumBlockEncoding.StoredTensorTrain
open HermitePiecewiseAssembly HermitePiecewiseStored
open HermiteExplicitCachedStored

#check (HermiteExplicitCachedStored.decode_value :
  ∀ (k : ℕ) (delta : ℚ) (a : Fin (assemblySize k delta)),
  (HermiteExplicitCachedStored.decode (HermiteFiniteExpDegree.sourceDegree delta)
    (2*k+1) a).run.value = (fullEquiv k delta).symm a)
#print axioms HermiteExplicitCachedStored.decode_value

#check (HermiteExplicitCachedStored.comparisonQ_value :
  ∀ (cut q : ℕ) (bit : Fin 2) (a b : Fin 3),
  (comparisonQ cut q bit a b).run.value =
    HermitePiecewiseUniform.comparisonEntry cut q bit a b)
#print axioms HermiteExplicitCachedStored.comparisonQ_value

#check (HermiteExplicitCachedStored.translationQ_actual_factorials :
  ∀ (L r q : ℕ) (hr : r ≤ L) (step : ℚ) (bit : Fin 2)
    (i j : Fin (r+1)),
  (translationQ L r q (HermiteChargedSourceCache.factorials L).value.values
    hr step bit i j).value =
    HermitePiecewiseUniform.translationCoreQ r (step*2^q*(bit.val : ℚ)) i j)
#print axioms HermiteExplicitCachedStored.translationQ_actual_factorials

