# C297: common-discriminant cases probe successor

AUTHOR CANDIDATE, UNCOMPILED. Separate authorization after C294 forensics.
Only the final failed rfl in frozen C281 Probe is replaced by one cases hs
on the actual common discriminant, with rfl in each constructor branch.
No uniform Sum.elim rewrite or other proof-search change is included.

The exact term comes from the complete C292 instantiated raw context:
M=componentSize(sourceDegree delta),
N=componentSize(2*k+1)+(componentSize0+componentSize(sourceDegree delta)).
rest has Fin(M+N), so (@finSumFinEquiv M N).symm rest has Fin M ⊕ Fin N.
C294 identified this same explicit discriminant in both residual matcher
applications after hSecond rw. These exact dimensions are supplied in
Probe.lean; cases retains its equation hs rather than introducing a new
public hypothesis. The split is exhaustive on the original Sum type.

The intended test is whether the two different generated matcher wrappers
both iota-reduce after that shared discriminant is a constructor. Each
resulting branch requests rfl once. Source reasoning justifies the exact
term and finite case split, NOT successful reduction or accepted proof.
The wrapper bodies/reducibility behavior were not established by C294,
so neither branch closure nor full-producer correctness is assumed here.

The C281 proposition, namespace, helper, context up to hSecond rw, and exact
type/axiom queries remain unchanged. probe-only.diff records only this last
tactic replacement; reversing it reconstructs C281 Probe text.
Scalar, chain, ValueProofChecks and sealed signatures are copied C281 bytes.
All scientific targets/hypotheses, numerical producer definitions, masks,
source conventions, counters, resource caps and trust/linter settings stay fixed.

Exposure: same producer/value/probe author with the released failures and
whole C292 forensic material previously read in C294. The earlier erroneous
alpha-equivalence assertion was corrected there; it is NOT repeated here.
This is not independent review, fresh universal decoding, or an independent
runtime rerun. C294's report/manifest/seal are bound unchanged.
Mandatory whole skill/protocol/source intake is retained;88 prior manifest
raw input hashes were freshly recomputed and match. These historical/direct
bindings are not a complete loader or source-to-binary/clean TCB closure.

Parent order remains STRICT: actual Probe module AND exact own consumer
must pass ordinary axiom checks before scalar can run. If either fails,
STOP without scalar; preserve its exact source/output. Only after both pass
may the unchanged scalar, chain and scientific exact consumer run.
A successful small probe alone grants no C250 scientific VALUE/cost root.

No compiler, scripts, Python, lake, Git, network, subagents, cost/review
outputs, old edits, new axioms, sorry/admit, native_decide, unsafe or overrides.
Only new C297 files via apply_patch. No accepted probe/own-consumer/root
claim, no nativebit/GCD/index/evaluator/runtime, physical sharing/gates/angles,
normalization/source-error/global SP, publication/main/reader/scientific ROOT.
Freeze and STOP; no unbounded successor authorization.
