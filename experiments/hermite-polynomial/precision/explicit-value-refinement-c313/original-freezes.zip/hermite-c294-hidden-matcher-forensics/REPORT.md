# C294: hidden matcher forensics (internal, no repair)

Outcome: the failed residual terms are NOT merely alpha-renamings.
The concrete visible difference is two generated matcher applications.
Their external type/motive/discriminant/branch arguments align, but their
definition bodies are absent from this diagnostic. Cause beyond that is unknown.

## Evidence and correction

Whole logical member C292/private-live/Probe-stdout was streamed in memory,
without extraction:268527 bytes, SHA256
564933f5435b75af1129114616a5df598a8d4e66f6d44051b4cb69125169789c.
It matches C292's result record. The6000-character text feedback was NOT used.
All3583 captured text lines were examined through exact repeated-parenthesis
sharing (68 explicit aliases); expanding them reconstructs the entire
whitespace-canonical text exactly. No printed ellipsis or truncated tool result.
C292 and frozen C281 Probe have identical5289-byte length and SHA256
53442283dc1172944b8c6249921df2c36bc3311a3a53cba50146dc2460d7871d.

Actual C292 record: Probe exit1/29.141s, no timeout/accepted own output,
zero roots, interface_probe_own_consumed=false. Scalar was not run.
Only supported printing flags changed; this is not a new mathematical target.
C286 option failure/C289 persistence failure are parent-reported history,
not independently opened here or used as mathematical failures.
I authored C281 and previously asserted alpha-equivalence too strongly.
C292's rfl failure and explicit heads refute that source-only explanation.
This is same-author forensic work, not independent review or a fresh decoder.

## Exact visible comparison

Abbreviate d=sourceDegree delta, t=2*k+1, C(r)=componentSize r,
M=C(d), N=C(t)+(C(0)+C(d)), A=ComponentIndex d,
B=ComponentIndex t ⊕ (ComponentIndex0 ⊕ ComponentIndex d).
The failing equality is Sum.inr(L)=Sum.inr(R), with common outer summand
ComponentIndex0 and common result A⊕B. Raw error L:lines2-402;
R:404-815; context/hSecond:816-1596; full residual Eq:1597-2448.

| Field | Left / right finding |
|---|---|
| Matcher head | firstInr_constructor_iota_hSecond.match_1 / private c268_sumInverse.match_1 |
| Head parameters | specialized k,delta / generic M,N instantiated exactly as above |
| Motive | identical constant lambda x:Sum(Fin M)(Fin N) => A⊕B |
| Discriminant | identical explicit DFunLike coercion of (@finSumFinEquiv M N).symm rest |
| Inl branch | identical componentEquiv(d).symm with the same explicit coercion instances |
| Inr branch | identical e3.symm coercion/application; only bound variable z/y differs |
| Universes | matcher .{1}, Sum .{0,0}, Equiv .{1,1}, DFunLike .{1,1,1}, Eq .{1} on both |
| Casts/proofs | no visible Eq.rec/ndrec/mp/mpr, HEq, Fin.cast or extra proof argument in either application |

Exact full heads: HermiteExplicitCachedStored.C275Probe.firstInr_constructor_iota_hSecond.match_1
and _private.Probe.0.HermiteExplicitCachedStored.C275Probe.c268_sumInverse.match_1.
After replacing ONLY the head/its parameterization and alpha-renaming the
inr binder, every other external argument is textually identical under
shared whitespace-canonical subterms; no arithmetic normalization was used.
Implicit Nat additions/multiplications/OfNat instances also align exactly.
The separate match_3 appears in the printed original theorem type, not this
residual equality; it is not identified as the immediate blocker.

## Unknown and minimal next probe (NOT executed or authored)

Different generated names alone do NOT establish different mathematical
branches, a compiler bug, opacity, or a kernel inconsistency.
Identical external motives do not reveal either matcher's internal motive,
eliminator, reducibility attributes or hidden body casts. No body was printed.
The supported diagnostic locates a wrapper/reduction interface discrepancy;
it does not identify its underlying implementation cause.

Next separately authorized probe: keep this same exact proposition/context,
and at the post-hSecond residual equality cases the actual COMMON
s=(@finSumFinEquiv M N).symm rest : Fin M ⊕ Fin N, retaining its equation.
Check each of the two constructor branches with rfl once. This tests whether
both different wrappers iota-reduce on the shared concrete discriminant.
If either fails, STOP and print both named matcher definition bodies plus
that single full branch goal; do not modify source semantics or hypotheses.
Only if separately authorized afterward consider one uniform nondependent
Sum.elim formulation. No implementation or anticipated success is asserted.

No compiler/proof repair, scripts, Git, cost/review material or old edits.
Only this report/manifest/freeze. No accepted root, own-consumer, clean TCB,
source publication, native-bit/GCD/runtime/gate or scientific ROOT credit.
Freeze and STOP.
