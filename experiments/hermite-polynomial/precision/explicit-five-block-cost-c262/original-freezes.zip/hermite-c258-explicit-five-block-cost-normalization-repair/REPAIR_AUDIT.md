# C258 proof-normalization successor

AUTHOR-UNCOMPILED. Original C253 candidate and C256 terminal failure are
preserved. C256 exited1 in41.656 parent-subprocess seconds, with no own output
or accepted root. Whole authorized feedback and receipt were read; this is
implementation evidence, not a mathematical refutation or independent review.

Exactly four proof-only edits, losslessly recorded in proof-only.diff:

1. Remove decode_total's trailing omega: the preceding simp already closed it.
2. In qdata's exact cost identity, use the existing cutoffQ_value and unfold
   sourceDegree, so both sides contain the actual degree(tailCutoff)(tailCutoff).
   This changes proof normalization, not which charged cutoff is evaluated.
3. In selected-counter composition, use the same cutoff normalization and
   unfold fiveSize/assemblySize, which have the identical literal five-sum
   carrier. No alternate dimensions, Fin decoder or enumeration is introduced.
4. Unfold passContainers in BOTH hq and the final goal before nlinarith.

The root remains HermiteExplicitCachedStored.produceExplicitStored_cost_counters,
the exact three-conjunct C250 cost/counter tail on the actual returned producer.
Its public forall k,n,R,delta signature, scalar frontierBudget, selected
quotient/remainder bounds, all private mathematical bounds and all C248
definitions are unchanged. Consumer bytes are identical to C253 (SHA256
c628185332bf6147157ec2f5cfd6c7bd2b38dab401a5c85478cf0cb6c4cc4bfd).
No new correctness/value/cost premise, no C252 source, no new primitive or
producer, no counter/cap/acceptance change. Source-construction graph unchanged;
the proposed Lean graph is only a proof-normalization successor.

Input scope: current C256 feedback+result WHOLE; original C253 source/consumer
were read for exact mechanical copying, with the prior full raw provider
analysis retained. Relevant additional raw excerpts were ActualAssembly186-201,
FiniteExpDegree1-24 and FiniteExp1-29. Current C250/C248/provider pins are checked
through the inherited manifest arrays. New changed regions and the entire
exact diff were read back. No C252, other review or diagnostic packet opened.
All historic warnings remain; no linter, trust, heartbeat or recursion option
was changed. No compiler/Python/project script/lake/Git/network/subagent run.
All new writes use apply_patch; original files are untouched.

Parent gate: same pinned own providers, NEW output directory, actual source
compile then unchanged exact-type/#print axioms consumer against that own
output; retain --deps selection and ordinary3 audit. No compiler success,
accepted theorem, clean transitive TCB or publication status is claimed here.
The inherited C23/C22 caches are not fresh rebuilds of this turn. If dependent
rewrite/elaboration still fails, preserve exact failure and repair only that
obligation; never weaken body, statement or budget.

Scope remains eight-counter scalar/word partial ledger plus two selected index
counts, NOT native Rat/bit/GCD/evaluator/allocation/physical-sharing or complete
integer runtime. Value/source refinement, normalization, finite angles,
synthesis, gates/depth, cleanup/export and scientific ROOT remain separate.
C244 is preserved and no numerical scan is requested or run.

Failure class: inherited IMPLEMENTATION_FAILED, successor acceptance pending;
not REFUTED or SOURCE_INVALID. Salvage: same entry/materialization derivation,
entire original failure evidence and unchanged consumer retained. Direction
EXPLICIT_FIVE_BLOCK_NORMALIZATION_C258 targets only the four observed errors.
Process-memory QBE-PM-LOW-TOKEN-CONTROL-PLANE and
QBE-PM-VERIFIER-SEMANTIC-LEVEL retained; qbe-substantive-worker complete intake
and C250 preproof seal remain governing. No parallel workers, route winner or
independent self-review. Purification/Exposition-Seal NOT_STARTED. Freeze/STOP.
