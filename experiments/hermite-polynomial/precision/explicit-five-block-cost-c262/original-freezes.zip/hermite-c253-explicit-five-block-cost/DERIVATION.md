# C253 actual five-block cost/counter candidate

AUTHOR-UNCOMPILED. C250 seal and C248 bodies unchanged. This is the exact
cost/counter tail of the sealed same-result conclusion, not a value proof or
the complete same-run theorem. No C252 author output has been opened/imported.

## Frozen interface and accounting

Only public root here: HermiteExplicitCachedStored.produceExplicitStored_cost_counters.
It quantifies k,n:Nat and R,delta:Rat, binds the ACTUAL produceExplicitStored
result, and states its eight-counter total<=frontierBudget AND both selected
counter bounds 14*(n+1)*D^2+4*D, where D=assemblySize k delta. There is no
positivity, cache/table correctness, Window, value, cost or evaluator premise.
All parameters R=0, delta<=0, k=0 and n=0 remain included. This is an internal
supplier dependency, not a new source Anchor or revised scientific target.

Write d=sourceDegree delta, L=d+2*k+1, and
P=passContainers n D=(n+1)*(2*D^2+D+1)+2*D. Reconstructing the ACTUAL code:

| actual step | eight-counter total | selected quotients/remainders, each |
| --- | --- | --- |
| decode | 4 | 2 |
| comparisonQ | 3 | 1 |
| translation, i<=j | <=q+r+10 | 0 (a lifted Run) |
| translation, i>j | 1 for the guard | 0 |
| componentKernel | <=q+r+18 | 2 |
| kernelAt, same tag | <=q+L+26 | <=2 |
| kernelAt, other tags | 8 | 0 |
| kernelEntry, q:Fin(n+1) | <=n+L+34 | <=7 |
| componentLeft / leftAt / leftEntry | <=r+4 / L+8 / L+12 | 0 / 0 / 2 |
| actual rightEntry plus decode/dispatch | <=11+4+4=19 | 2 |

Translation uses three factorial reads and two field operations (chooseFrom=5),
q dyadic multiplications, one charged bit test, three more multiplications,
at most r exponent multiplications, and its one guard. Hence q+r+10.
It never assumes factorial correctness for COST: arbitrary F has the same
primitive counts. The actual producer still generates F and pays for it.
ComponentKernel adds two comparison triples and two product operations.
KernelAt adds eight tag ticks; kernelEntry adds two four-tick decodes. Selected
kernel counts are one flattened output decode + two row decodes + two column
decodes + two comparator digit quotient/remainder pairs =7. Off-diagonal
branches are kept and may cost less, never an assumed zero whole kernel.

Each collectIndexed pays sum of actual entry costs PLUS4*m traffic, while its
two selected counters are precisely the sums of stored entry metadata.
The triple kernel collection, left and right collections therefore cost

    <= 2*(n+1)*D^2*(n+L+34)+D*(L+31)+4*P,

and each selected counter is <=14*(n+1)*D^2+4*D. The same returned records
are projected; the proof does not call a callback again to fetch metadata.
This source-level same-object fact is NOT physical evaluation sharing.

Prefix costs are the ACTUAL cache<=416*(k+1)^2 and middle<=400*(k+1)^2,
rightSetup<=81*(d+1)^2+8*(d+1)+n+tailCutoff(delta)+22, regenerated cutoff=1,
regenerated gridStep=n+3, two qSub calls=2, and regenerated factorials at L
<=80*(L+1)^2. Thus qdata adds n+6 beyond setup to the materialization pass.
The cast is5*P, canonical ofTable is<=20*D^2+30*D+5*n^2+7*n+31. Combining:

    416+400 -> 816 coefficient factor;
    D*(L+31)+30*D -> D*(L+61);
    4*P+5*P -> 9*P;
    (n+22)+(n+6)+(5*n^2+7*n+31)
      ->5*n^2+9*n+59, plus tailCutoff(delta).

These are exactly the sealed frontierBudget terms, not a changed budget or
proposed constants treated as proofs. The code attempts each supplier proof
and this algebra. C237 was consulted only for its reuse obligations; no
unverified numerical proposal is imported as a theorem.

## Providers, graph, and audit boundary

Imports: C249 own ExplicitFiveBlockDefinitions from C248 source; C189 own
CachedMiddleCostProof; C223 own SetupCostProof; approved C23 CacheConsumerChecks
and C22 AccountedTraffic. Primitive powQ_cost and rightEntry_total_le arrive
through C159 CachedPrimitivesProof. Raw source was read for all of these.
Canonical StoredBinaryCoordinates collectIndexed and ofTable_total_cost_le
remain the existing interfaces; no second producer/arithmetic foundation.
Existing C23 factorials_cost_le is totaled over all eight operations locally
because its earlier totalization helper is private. Local add/tick/collect
facts are proof bookkeeping, not new runtime models.

Binder audit: k,n,R,delta are SOURCE/TYPING parameters of the sealed supplier.
Internal r<=L, d<=L and 2*k+1<=L only ensure safe Fin addressing; all are
discharged for L=d+2*k+1. Arbitrary internal F correctness is never assumed,
and actual cache/setup/middle costs are supplied by exact existing theorems.
No EXCESS public binder, stronger access oracle or supplied value proof.
Definitions are literal C248 unchanged, not characterized/quotient objects.

Source construction graph: actual scalar primitives -> guarded translation,
comparison and boundaries -> exact five-way dispatch/materialization -> cast
and canonical assembly. The NEW candidate Lean graph supplies only the
cost/counter projection. Value/window/source-action are separate dependencies;
this packet cannot close them by importing a value premise. No quantum spine
or Functor transport is added, and scientific SP-HERMITE-POLY-002 stays open.

Scalar model omissions: Rat representation/GCD/operand bitlength, native index
arithmetic/powers/ceil/floor/clog, casts, loop/counter metadata, allocation,
evaluation strategy and physical sharing are NOT bounded. The two selected
index counts are not all integer operations and have no bit-cost theorem.
Finite normalized SP, angles/synthesis, gates/depth, quantum cleanup/export and
the full scientific root are absent. Old kernel/left callback costs are not
claimed here: this actual successor has explicit charged scalar bodies, but
no claim extends that annotation to native runtime or existing old producers.

## Parent gate and uncertainty

No compiler, lake, Python, provided script, Git, network or subagent was run.
Only source reads, metadata hashes and NEW apply_patch writes. One requested
provider filename CachedSetupCostProof.lean was absent; exact directory listing
identified SetupCostProof.lean, which was then read whole. This is path/API
handling, not a mathematical mismatch. Initial large seal output truncated;
all seal lines were subsequently read in disjoint bounded chunks. No C252,
independent review, setup/middle diagnostic or runtime-verdict file opened.

Next gate must select the pinned own provider outputs, compile this source to
a NEW output directory, then compile ExplicitFiveBlockCostChecks against that
actual output. Run --deps under the same search path and retain selected paths
and hashes; check the exact typed projection and #print axioms ordinary3.
Suggested invocations, parent supplies its already serialized pinned toolchain:

    lean --deps ExplicitFiveBlockCostProof.lean
    lean -o NEW_OUTPUT/ExplicitFiveBlockCostProof.olean ExplicitFiveBlockCostProof.lean
    lean -o NEW_OUTPUT/ExplicitFiveBlockCostChecks.olean ExplicitFiveBlockCostChecks.lean

No cached own output exists yet. Dependencies inherit the C250/C249 environment;
this is NOT a clean transitive-TCB rebuild. C23 fresh-v3 and C22 caches must not
be represented as fresh results of this author turn. C252 is not a provider.
If any source/proof/normalization gate fails, preserve candidate+feedback and
return IMPLEMENTATION_FAILED/API_BLOCKED, not a budget or hypothesis change.
Specific uncompiled risks: nested Sum case elaboration, collected metadata
Vector simplification, and the dependent cutoff-degree/Fin transport in the
qdata cost identity. No maxHeartbeats/maxRecDepth or trust option was altered.
No mathematical counterexample is known; no compile/type/axiom success claimed.

Handoff: cohesive full cost/counter candidate with exact consumer and raw input
pins; failure class NONE before compiler gate, all proof acceptance pending.
Salvage entries/materialization remain independently meaningful if prefix
elaboration needs repair. Direction EXPLICIT_FIVE_BLOCK_ACTUAL_COST_C253;
expected gain is closing the actual producer's partial-accounting dependency.
Process memory QBE-PM-LOW-TOKEN-CONTROL-PLANE and
QBE-PM-VERIFIER-SEMANTIC-LEVEL; protocol intake unchanged from complete C244
reading and current hashes rechecked. No subagents or route winner claimed;
common-blind-spot review remains parent-controlled. Purification and Exposition
Seal NOT_STARTED. Only parent may advance compile/review/publication status.
Freeze and STOP.
