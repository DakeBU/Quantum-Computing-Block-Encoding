# C251: source-only transport successor comparison

Classification: INTERNAL SOURCE-ONLY STATIC SUCCESSOR REVIEW. The single explicit transport preserves the intended index/model reviewed in C245/C247. I found no additional source change. This is not acceptance of either Lean module, a type/axiom receipt, runtime association or a proof of the proposed budget.

## Exact source comparison

The permitted C248 source has 12675 bytes and SHA256 `bbdca858e3254f47f65a9dfc2752ded85a8afa48409c41d004c0c1848fe4ed7f`; its definitions seal has SHA256 `10d1ded598cb034512e1ac258db83cd8d59105f3437c0639cd5acb1fc70e1aaf`. I read all four released files whole: source, intended checks, transport-only diff and definitions seal. The three released payload hashes agree with that seal. I did not open its REPAIR or input-manifest files.

The predecessor source is the exact C243 input of immutable C247. A strict UTF-8/read-only byte comparison established that replacing the one old source line below by the one new line reproduces the ENTIRE C248 source byte-for-byte. The old line occurs once; only line 170 differs. Both files contain 243 LF bytes and zero CR bytes. The common byte prefix is 8645 bytes, the common suffix 3980 bytes, and the minimal differing spans are 6 old bytes versus 50 new bytes, a net increase of 44. This is not a normalized-only diff that could hide unrelated whitespace or line-ending edits.

```lean
-- C243
  let original : FullIndex k delta := hd ▸ index.run.value
-- C248
  let original : FullIndex k delta := Eq.mp (congrArg (fun e => FiveIndex e (2*k+1)) hd) index.run.value
```

The supplied 11-line transport-only diff agrees with that independently checked one-line change. C248 `IntendedRootTypeChecks.lean` is byte-identical to C243 (2773 bytes, SHA256 `a2eb22bc8684024f0c0cb6d53b8c0c9f6d72efb49c9706538d34f21870b92e41`). All 40 raw inputs bound by C247 were rehashed unchanged; C245/C247 original payloads and seals were also checked unchanged. This does not turn those inputs into a complete loader/TCB or Git-history audit.

## Meaning of the explicit transport

The unchanged helper binders provide `hd : d = sourceDegree delta`. The unchanged decoder returns `index.run.value : FiveIndex d (2*k+1)`. The explicit type family is

```text
F(e) = FiveIndex e (2*k+1).
```

Consequently `congrArg F hd` has the forward type equality `FiveIndex d (2*k+1) = FiveIndex (sourceDegree delta) (2*k+1)`. `Eq.mp` transports the existing decoded value in that direction. Its target unfolds to the original `FullIndex k delta`: the same five right-associated summands and the same inner products/Fin coordinates. It neither invokes fullEquiv a second time nor constructs a new permutation, branch tag, monomial exponent or integer address.

Under equality elimination at hd=refl this is the identity transport. Thus the explicit motive expresses the original intended carrier conversion rather than a different mathematical operation. This is a source-level equality-elimination argument; I have not written a new lemma, run a tactic, or checked whether this candidate elaborates in the selected environment. In particular, there are not two accepted Lean implementations here whose compiled equivalence has been established.

The hd premise itself is unchanged, and the actual root still supplies its original definitional degree equality from the second charged cutoff result. No new correctness/cost premise, source-degree redefinition, oracle or positivity assumption was added. The separate final rational-record hsize transport at line 218 remains unchanged; this repair does not claim to replace or validate every implicit dependent transport in the file.

## What remains unchanged and what follows only conditionally

Because all other source bytes and the intended checks are identical, the C247 body-level comparison remains the relevant static baseline: exact fiveSize/decode order and bit-column layout; literal comparison and factorial translation; all five kernel/left/right branches and cross-component zeros; actual cache/setup/middle and regenerated cutoff/step/factorials; charged returned-data materialization; same castData and same ofTable; n=0 terminal-then-initial closure; proposed frontierBudget and selected quotient/remainder formulas. The repaired line only changes how the existing decoded right-boundary index is presented to the original charged C150 rightEntry.

No general assertion about arbitrary F/setup/minusStep inputs is strengthened. The internal generated-factorial and actual returned-setup dependencies described in C247 are still required. Local ledger deductions remain static arithmetic only; the whole budget is still proposed, not proved. Equality/index proofs are outside the declared selected operation ledger; unchanged annotations do not certify native execution or free/effective physical sharing. Natural index/ceil/floor/clog work, Rat bitlength/GCD, evaluator/administration/allocation, casts, finite-bit realization, quantum gates/phase/cleanup/export and scientific ROOT remain outside this repair's credit.

The byte-identical checks still request name checks and eight intended proposition formations, not proofs. Their eventual formation can depend on the changed imported module and selected outputs, so text identity does NOT establish type acceptance. No runtime result, selected new own output, dependency association or actual axiom list was inspected.

## Exposure, provenance and handoff

C245's source-first seal preceded C243 exposure; C247's comparison seal preceded this C248 release. Both originals remain immutable. Prior Hermite source/runtime and separate Gaussian/governance exposure are retained as disclosed in those packets. This is a new task-specific source-only successor review, not a fresh universal/source-publication decoder.

The permitted C248 seal mentions a historical C246 elaboration failure at the implicit transport, supplies result/feedback hashes and describes zero accepted outputs. I observed those author metadata assertions, including the claimed exit/time, but did NOT open the actual C246 records or adopt their diagnosis/status as independently checked runtime evidence. Nor did I read C249 outputs, C250/C252/C253, author repair prose, parent current numerical reviews or other reviews. This exposure is explicitly later than the preserved C247 static freeze.

The retained worker skill and unchanged mandatory protocols impose the source/assumption/evidence-layer and immutable-handoff boundary used here. No compiler, Python, script, lake, Git, network, subagent, finite diagnostic or proof search was used. Read-only PowerShell/.NET performed file reads, byte/text comparison, JSON parsing and SHA256; only this new packet was written with apply_patch. There were no tooling failures or discarded drafts in this stage.

Objective/frontier delta: independently isolate the precise transport-only successor and its correct type-family direction. Named evidence: exact raw source/checks/diff/seal bindings and byte comparison, not a new Lean theorem. Assumptions: unchanged hd index equality, internally supplied at the root; no excess scientific or cost premise. Failure class: no concrete static semantic defect identified; actual elaboration/acceptance remains PENDING. Salvage: preserve all old sources/freezes and historical failure metadata without rewriting them. Process memory: own C245/C247 and retained protocols only. Direction fingerprint/common-blind-spot audit: bounded source-only type-transport comparison, no delegation and no runtime-success anchoring. Default route: parent serial actual type gate, exact StatementSeal, then separately authorized proof/association work. Purification/Exposition: none. Residual risk: untested elaboration, dependent transports and imported-output routing; all C247 whole-budget/native/root limits persist. Files changed: only this new review, input manifest and static seal. Recommended action: parent whole-read/hash check and decide the next separately authorized gate. FREEZE AND STOP before runtime association.
