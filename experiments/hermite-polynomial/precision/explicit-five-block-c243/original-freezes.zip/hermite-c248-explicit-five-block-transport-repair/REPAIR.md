# C248: dependent-index transport only

Status: TYPE-ONLY AUTHOR SUCCESSOR, UNCOMPILED. No new semantic/cost proof
search, scalar/dataflow change, target change, or budget change.

C246's actual parent-owned probe failed at source line170 column38 in 28.671s,
exit1, ELABORATION_FAILED. The diagnostic rejects `hd ▸ index.run.value`
because the expected result is FullIndex k delta, while hd equates naturals.
The record has no accepted own output, zero proposition formations, zero proof
roots and no StatementSeal. Both complete feedback and result were read; they
remain immutable in C246. This is an implementation/elaboration failure, not a
mathematical refutation or a changed source target.

The single changed Lean line is:

```lean
  let original : FullIndex k delta := Eq.mp (congrArg (fun e => FiveIndex e (2*k+1)) hd) index.run.value
```

It supplies the actual type-family equality explicitly. The codomain
FiveIndex (sourceDegree delta) (2*k+1) is definitionally the original FullIndex.
This is an index/carrier cast only, not a theorem about returned scalars or
cost. Its elaboration/kernel acceptance still requires the next parent probe.

`transport-only.diff` records the exact one-line source delta. The second Lean
payload, IntendedRootTypeChecks.lean, is byte-identical to C243. The original
module name/imports, namespace, numerical bodies, all eight proposition
formation candidates, conservative annotations and candidate B are unchanged.
The inherited C243 header is intentionally unchanged to keep the source delta
strictly limited to the transport expression; this note identifies C248.

All 30 source/protocol/historical-input pins from C243 were recomputed and
matched. In particular the correct UniformTranslation 64-character digest is
retained; C237's historical 65-character transcription defect is NOT silently
repaired. The C243 source/checks/manifest/seal and C246 feedback/result are
separately bound by this packet. These are scoped raw-input hashes, not a
complete loader or transitive TCB audit.

No compiler, lake, Python, provided/new script, Git, network, subagent, finite
diagnostic or independent review was run. C247's still source-only static
comparison was not opened or messaged. C246's selected-provider metadata was
read as historical evidence, not independently rerun or promoted to success.

All existing boundaries remain: native floor/ceil/clog/address/power/cast work,
rational bitlength/GCD, evaluator/allocation administration, physical sharing,
real implementation, kernel/left gates, angles, normalization and full SP
scientific resources are not certified. No ProofSeal/PublicationSeal/ROOT.

Failure class of C246: IMPLEMENTATION_FAILED (elaboration), not REFUTED.
Salvage: the complete definitions candidate and exact intended targets are
preserved; only the explicit type equality application is changed.
Process-memory IDs: none; no delegation/comparator/purification/reader claim.
Next: parent type-probes this fresh source and unchanged proposition consumer,
then issues a genuine StatementSeal before authorizing any new proofs.
Freeze and STOP. Do not mutate C243, C246, C237 or any production source.
