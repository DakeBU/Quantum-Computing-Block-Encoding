# C237: explicit five-component kernel/left producer proposal

Status: INTERNAL AUTHOR DESIGN, before new StatementSeal. No Lean proof search,
compiler, finite evaluator, runtime gate, or independent review was performed.
This is a concrete producer specification and candidate budget, not a theorem.
The scientific target remains SP-HERMITE-POLY-002 and the exact C21/C22 value.
C150 and every historical packet remain unchanged.

## 1. What changes, and what does not

Replace the body of a NEW successor producer, not C150 itself. Its numerical
body never constructs, captures, calls, or projects `actualBlocksQ`, `actualBlocks`,
`actualEntryQ`, `actualLeftQ`, `actualRightQ`, or `produceQData`. Those objects
appear only in proposed refinement statements. In particular no source callback
is relabelled as `pure` or a stored read.

Reuse the actual C23 source cache, actual C150 rightSetup, middleFromCache and
rightEntry, C22 castData, and canonical StoredMatrixProductChain.ofTable on the
very returned data. The new work is an explicit rational comparison adapter,
guarded binomial translation, five-way kernel/left dispatch, and charged index
decode. No new quantum foundation or different low-rank source is introduced.

Write K=k+1, T=tailCutoff delta, d=sourceDegree delta=4T^2+2T+1,
L=d+2k+1, D=assemblySize k delta=18(d+1)+9(2k+2)+18,
N=2(n+1)D^2 and P=(n+1)(2D^2+D+1)+2D.
All are naturals; L dominates d and 2k+1. Physical width is n+1, not n.

## 2. Explicit preparation, including formerly hidden eager work

Operational order, each arrow consuming the preceding returned value:

1. Produce C23 cache(k), C150 rightSetup(n,R,delta), then middleFromCache(k,
   setup.midpoint,cache), exactly as C150. Their ledgers are included, once each.
2. Execute a SECOND cutoffQ(delta), charged one rational division. Its returned
   T' determines the native dimension d'=degree T' T' and L'=d'+2k+1. Transport
   the resulting dimensions to d,L with the existing cutoff value identity;
   proof casts are not numerical evaluation. This deliberately redundant cutoff
   is counted: RightSetup does not return its cutoff or factorial table.
   Do NOT regenerate sourceDegree(delta) as an uncharged runtime size callback.
3. Execute gridStepRun(n+1,R), qSub(0,R), qSub(0,step), returning h,-R,-h.
   Total for steps 2--3 is n+6. Execute C23 factorials(L') once, including its
   full-copy extensions. Its returned values F supply every translation choose.
4. Keep four cuts from actual setup and these already produced scalar values.
   Fixed record projections follow the inherited model; vector entries are read
   with charged reads. No full semantic block object is eagerly captured.

The extra factorials are intentional, not an unused cache: every active
translation below reads F three times through actual chooseFrom. Existing C150
setup/middle private factorials cannot be borrowed without changing those APIs.

For clarity, the reused setup is an actual algorithm, not a new scalar oracle:
cutoffQ produces T; gridStepRun produces h=2R/2^(n+1); strictCutFrom at -1
and T executes qAdd(s,R), qDiv by h, then charged min with the cap; inclusive
cuts at 0 and -T execute those fields plus the negative-quotient test and
original floor-plus-one/min rule. The -T is produced by qSub. Its factorials
produce tail reciprocals by actual read/qDiv, clippedRun executes powQ 2 T
and two divisions, and midpointFrom executes its T<=1 test followed either by
the clipped scalar or the full alternating-power/factorial sum including each
final add-to-zero. The proposal does not replace those signed/zero branches.

## 3. Decode and index ledger

Use a new executable decoder with the exact inverse layout of fullEquiv: compare
against the first component size 9, then subtract it and compare against
9(d+1), then 9(2k+2), then 9; the residual is the final 9(d+1) component.
There are at most four natural bound tests. Inside a selected component of
degree r, use the two inverse finProdFinEquiv operations to obtain
(a,(b,j)): first divide/remainder by 3(r+1), then by r+1. The last component
does not require an additional test; index validity follows from Fin D.
Reserve exactly four .compare ticks per decoder, even on shorter paths.
It returns FullIndex k delta, not an arbitrarily reordered tag record.

The intended value equation is decode.run.value=(fullEquiv k delta).symm i.
This is an UNPROVED adapter obligation, not a supplier hypothesis. The Mathlib
source explicitly implements inverse finSumFinEquiv with Fin.addCases and
inverse finProdFinEquiv with divNat/modNat; a new literal decoder makes the
charged comparisons visible rather than trusting an opaque equivalence call.

Each core callback also splits its Fin(2D) output into (bit,column) with one
quotient/remainder. Row and column decoding add two each: five quotient calls
and five remainder calls before the numerical branch. Each boundary decoder
adds two each. Reserve eight .compare ticks for paired five-tag kernel dispatch,
four for single five-tag left/right dispatch, in addition to decoder charges.
These are conservative explicit annotation reserves (as in canonical
StoredHermiteKernelTable), not assertions about native instruction counts.

Reuse generic StoredBinaryCoordinates.IndexedRun and collectIndexed. Compose
already returned run.cost / quotientCalls / remainderCalls, without rerunning
callbacks to sum metadata. collectIndexed has exactly the same 4-per-slot
container allowance as collect. No new cost model is needed.

## 4. Scalar callbacks, completely specified

### Rational comparison adapter

For cut,q,bit,a,b, compute native digit=(cut/2^q)%2 and separately record one
quotient and one remainder. Charge .compare for bit.val<digit, .compare for
digit<bit.val, select next=0/2/a in that order, then charge .compare for next=b.
Return the literal rational 0 or 1. This is exactly UniformComparison's
generatedEntry algorithm with Q literals instead of R literals: cost 3, no
uncosted comparisonEntry evaluation. Existing finish/comparisonEntry remain the
specification. The LSB-first stage index q is unchanged; no n-q reversal occurs.

### Translation adapter

Given actual F of length L+1, degree r<=L, step s, indices i,j:Fin(r+1):
charge one comparison for i.val<=j.val. On false return pure 0. On true:
read chooseFrom F j.val i.val (using the guard and j<=r<=L), call powQ 2 q,
charge one comparison to convert bit to the Q literal (if bit=1 then 1 else 0),
call qMul s dyadic, then qMul that bit, call powQ w (j.val-i.val), then qMul
binomial power. Thus the returned value is exactly
(j.val.choose i.val:Q)*(s*2^q*(bit.val:Q))^(j.val-i.val).

The true branch costs q+(j-i)+10: one guard, five choose operations (three
reads and two fields), q dyadic multiplications, one bit comparison, two
step multiplications, j-i power multiplications, and one final multiplication.
False costs one. The value bridge on the false branch uses choose=0 for j<i;
truncated subtraction and 0^0 are not silently replaced. This also handles s=0
and negative s. For r=0 both indices are zero; the adapter returns 1, including
s=0. We intentionally still execute/count its literal arithmetic.

### Five components

Let A=setup.cutMinusOne, B=setup.cutZero, C=setup.cutMinusT,
E=setup.cutT. In each row the structured index is (a,(b,j)).

| exact summand order | cuts used by kernel | degree | left origin | translation step | right flips |
| --- | --- | --- | --- | --- | --- |
| inl | A,C | 0 | 0 | 0 | false,false |
| inr/inl | A,C | d | -R | h | false,true |
| inr/inr/inl | A,B | 2k+1 | -R | h | true,false |
| inr/inr/inr/inl | B,E | 0 | 0 | 0 | true,true |
| inr/inr/inr/inr | B,E | d | R | -h | true,false |

Kernel: after charged decode/dispatch, unequal summand tags return literal 0.
For equal tags call the two rational comparison adapters, the translation
adapter for that row, then qMul(secondComparison,translation), followed by
qMul(firstComparison,inner). No zero-mask shortcut or reordered product.
Flip flags NEVER enter the kernel. Per scalar callback total is at most
8 decoder + 8 dispatch + 6 comparisons + (q+L+10) translation + 2 products
= q+L+34 <= n+L+34. Cross-component callbacks cost only 16, already covered.

Left: after charged decode/dispatch, charge two comparisons for a=1 and b=1,
returning Q literals; call powQ with that row's already produced origin and j;
use qMul(secondMask,power), qMul(firstMask,inner). Bound L+12, including
four decoder and four dispatch ticks. Fin 1 forces j=0 in constant summands,
so 0^0=1 is retained; there is no invented zero endpoint.

Right: charged decode and four dispatch ticks, then EXACT actual C150
rightEntry using the actual setup and middle. The extra decoding/dispatch is
not hidden in the old 11-per-entry result: the new bound is 19 per entry.
Middle coefficients, reflected signs, masks and clipped constants are unchanged.

## 5. One returned chain and its candidate polynomial

Use nested collectIndexed for n+1 cores, D rows and 2D columns; then the two
boundary collects. The very RationalData returned is passed to C22 castData;
the very RealData returned is passed to canonical ofTable. Lifting ordinary
Run values into IndexedRun adds zero selected index counters, not zero cost.
The whole operation ledger is all executed prefix costs + callbacks + traffic
+ actual cast + actual ofTable. No call to old produceQData supplies the output.

| phase | eight-counter TOTAL upper-bound candidate |
| --- | --- |
| C23 source cache | 416K^2 |
| actual C150 middle | 400K^2 |
| actual C150 setup | S=total(rightSetup n R delta).cost |
| additional cutoff, step and two negations | n+6 |
| actual factorials L | 80(L+1)^2 (8 times existing per-counter bound) |
| all dense kernel callbacks | N(n+L+34) |
| left callbacks | D(L+12) |
| right callbacks including new decode/dispatch | 19D |
| three nested table / two boundary materializations | 4P |
| actual castData | 5P |
| canonical ofTable | 20D^2+30D+5n^2+7n+31 |

Thus the first compositional candidate is

    Bpartial = 816K^2 + S + n+6 + 80(L+1)^2
             + N(n+L+34) + D(L+31) + 9P
             + 20D^2+30D+5n^2+7n+31.

If the separately frozen C202 setup target is established as a DEPENDENCY,
S<=81(d+1)^2+8(d+1)+n+T+22, the fully explicit candidate becomes

    B = 816K^2 + 81(d+1)^2 + 8(d+1) + 80(L+1)^2
      + 2(n+1)D^2(n+L+34) + D(L+61) + 9P
      + 20D^2 + 5n^2 + 9n + T + 59.

This displayed B is an exact proposed polynomial upper bound, NOT an exact
cost equality and NOT Lean-proved. It is a polynomial in n,k,T after the
displayed definitions of d,L,D,P. It is not an efficiency winner claim.
Do not substitute setup validation status for the missing theorem dependency.
The source-derived middle 400 bound is likewise a provider requirement for
this future composition, not a newly certified result in this packet.

Selected native ledger candidates: whole-producer quotientCalls and
remainderCalls are each <=7N+4D. Five per kernel entry arise from output split
and two decodes; at most two more from its actual comparison adapters. Each
boundary contributes two per entry. These named operations are NOT all integer
divisions inside rational normalization, nor a complete native operation model.

## 6. Whole-carrier and endpoint audit

No sign or positivity premise is needed for QData equality or the total-cost
candidate: all n,k,R,delta, including n=k=0 and R,delta<=0. rational division
has the original totalized zero behavior. For delta<=0, tailCutoff=0 and d=1;
large positive delta may also give this branch. Actual setup retains T<=1
midpoint dispatch; the successor simply consumes its returned midpoint.
For R=0, strict cuts are 0 and inclusive cuts are min(2^(n+1),1), with the
original zero-division convention. R<0 keeps inclusiveCutFrom's negative
quotient branch and floor-plus-one; no positive-step interpretation is used.
All cuts 0 or cap are handled by original acceptRun for the right boundary.
For n=0, there is one core q=0, powQ 2 0 is 1, and the canonical ofTable
single-site endpoint still contracts both boundaries. No empty-chain rewrite.

The physical source-action theorem still has ONLY its original 0<R premise.
Neither normalization, error budgets, phase, physical word order, masks nor
register/source conventions are changed. Equality is to actualChain itself,
not merely to a few sampled amplitudes or an alternative rank 2k+6 source.

## 7. Remaining frontier and handoff

Required next action: parent materializes/probes the definitions in this design,
then seals their exact bodies and proposed signatures BEFORE proof authoring.
Pending adapters are literal decode inverse, rational comparison, guarded
translation/choose zero branch, five-component kernel/left equality, actual
setup/cache/middle/right value consumption, and same-run aggregation. None is
a new public correctness/cost/oracle premise. No mathematical impossibility or
counterexample is asserted. The interface issue is concrete: C150 RightSetup
does not return cutoff/step/factorials, so this design honestly pays regeneration
rather than pretending it can read those discarded intermediates.

This eliminates the identified semantic kernel/left callbacks at design level,
not yet at accepted Lean level. It still does NOT certify native ceil/floor/
clog/powers/index arithmetic, rational bitlength/GCD, evaluator allocations,
physical sharing, rational-to-real implementation, angles, TT compiler costs,
normalization, kernel/left physical gates, coherent input access, or full
scientific ROOT resources. Parent sealing and checked symbolic composition are
necessary before promoting even this eight-counter frontier.

Exposure: the author previously authored cached-value and setup-cost candidates,
and performed middle-cost and same-run source reviews. Known parent-reported
gate/finite statuses are not proof evidence used here. This is neither a fresh
universal decoder nor an independent review. No C199/C208 proof, C207/C211
output, C218 package, C192 public cost metadata, or other reviewer packet was
opened for C237. No new finite diagnostics were run.

Direction fingerprint: C237_EXPLICIT_LITERAL_FIVE_SUM_KERNEL_LEFT_Q_DATAFLOW.
Expected delta: replace the last opaque scalar callbacks in the exact cached
chain with a sealable end-to-end producer and polynomial charged-work contract.
Failure class: NONE for proposal delivery; implementation/proofs remain pending.
Salvage: canonical primitives reused; incompatible 2k+6 layout not substituted.
No curated process-memory IDs used; no parallel workers or comparator invoked.
No ProofSeal, PublicationSeal, ExpositionSeal, purification or root acceptance.
Freeze and STOP; parent owns statement probe/seal and all subsequent execution.
