# C237 actual-source reuse and proof obligations

All arrows below are proposed mathematical consumption, not a newly extracted
Lean dependency graph. No C237 theorem or definition has been compiled.

| existing input | literal role / proposed use | missing C237 obligation |
| --- | --- | --- |
| C21 IndexedKernel productKernel, sumKernel, reindexKernel | exact nested product, block zeros, fixed layout semantics | five-way callback equality, not a new tensor semantics |
| C21 ActualAssembly FullIndex/componentEquiv/fullEquiv/actualChain | unchanged five labels and Fin ordering; target chain | charged decoder equals actual fullEquiv.symm |
| C21 ActualCoefficients sourceCoefficientQ/middleCoeffQ | exact signed polynomial coefficients | consume already generated C23 cache and C150 middle; no coefficient callback in kernel |
| C22 RationalBlocks BlockQ.prod/sum, polyQ, thresholdQ, actualBlocksQ | exact rational target, not producer evaluation | five-way kernel/left entry bridge over full carrier |
| C20 UniformComparison generatedEntry/finish/comparisonEntry | three comparisons and one named quotient/remainder | narrow Q-literal adapter, not a second comparator foundation |
| C20 UniformTranslation translationCoreQ | column-choose-row, exponent column-row | guarded chooseFrom equality, including row>column zero |
| C20 UniformThresholds gridStepQ, strictCut, inclusiveCut | literal caps, signed/zero rational divisions, floor/ceil convention | consume actual setup cuts; positivity only for physical interpretation |
| C23 qAdd/qMul/qDiv, factorials, factorials_value, chooseFrom_value/chooseFrom_cost | actual reusable rational primitive/factorial/binomial implementation | generate F once at L and instantiate correctness internally |
| C23 produceSourceCache_entry / produceSourceCache_cost_le | actual source-cache producer, per-counter 52K^2 | totalize across eight counters and include actual prefix bind |
| C150 CachedMiddle qSub/powQ/middleFromCache | actual signed middle, including guarded terms and final additions | consume returned midpoint/cache, not a fresh callback |
| C159 CachedPrimitivesProof powQ_value/powQ_cost/gridStepRun_value/rightEntry_total_le | existing bounded primitive interfaces; actual raw source read | use in internal scalar/whole-pass proof after sealing |
| C150 CachedRightSetup cutoffQ/gridStepRun/rightSetup/rightEntry | actual all-domain cuts, tail coefficients and right masks | value facts on actual returned setup, not arbitrary supplied promises |
| frozen C202 rightSetup_total_le target | proposed removal of actual S from partial budget | separately establish/use this dependency; current gate status NOT assumed |
| C22 StoredProducer RationalData/castData and cast entry facts | same rational values cast to real stored values | same-returned-data transport, original Window |
| C22 AccountedTraffic castData_traffic/passContainers | exact 5P cast traffic, container inventory | new producer output collects contribute 4P plus real scalar work |
| StoredGivens Run/charge/read/collect, StoredRectangularGivens.total | inherited eight-counter annotations and scalar-word storage | no new primitive semantics/cost model |
| StoredBinaryCoordinates IndexedRun/collectIndexed | actual metadata-preserving materialization | bind/lift helpers add all existing costs and selected counters, callbacks once |
| StoredMatrixProductChain ofTable/refines/window_of_entries/ofTable_total_cost_le | canonical stored-chain assembly on returned data | internally supply Window; retain actual assembly cost |

## Local alternatives inspected before selecting this design

StoredHermiteKernelTable (whole raw source): storedBlock/entry/assemble already
charge fixed tag dispatch, bond decoding and stored fields. It uses
HermiteFiniteBond and rank 2k+6, whereas the exact C21 target uses two comparison
state factors times polynomial degrees in a five-way direct sum. Its seven
SourceCorrect fields are supplier obligations for a DIFFERENT kernel, not
evidence that the current source has been produced. Reuse the accounting pattern,
not that kernel or its assumptions.

StoredHermiteSharedTables (whole raw source): factorial reuse, chooseFrom,
inverse powers and guarded entries are useful shared patterns, but its real
Bernstein sharedCore entries are not the rational translationCoreQ target.
Direct substitution would change basis/layout. C23 is the existing rational
factorial/choose adapter to reuse, rather than duplicate it in C237.

StoredHermiteRawSource (whole raw source): explicitly composes cache, stage,
boundaries and canonical ofTable, with exponential and selected integer ledgers.
It is a distinct exact-real raw-source route requiring positive L, not a drop-in
for the frozen rational piecewise value on all R,delta. Its record collection
pattern confirms why counters must project stored results rather than rerun f.

Mathlib finSumFinEquiv/finProdFinEquiv source was inspected at the two definitions.
No new finite-set equivalence foundation is needed. The only adapter is the
explicit charged execution of the same nested index layout.

## Parent sealing sequence, without leaf sprawl

1. Materialize all literal producer definitions as ONE end-to-end successor
   module from the operational specification; probe their types and freeze the
   numerical bodies. Do not launch unrelated microlemma authoring first.
2. Seal the exact all-carrier QData equality and same-run polynomial target,
   plus original source-action theorem with hR. PROPOSED_SIGNATURES.txt is only
   the proposed interface; it is not itself an accepted StatementSeal.
3. Author/prove grouped internal adapters, then whole returned-data equality,
   then same-run composition using actual prefix/setup/middle providers. Keep
   primitive/F-correctness proofs as dependencies, never source-root premises.
4. Check actual module, exact typed consumer and ordinary axioms, then do the
   independently scoped semantic/source review. No current producer proposal
   can self-approve those phases.

Acceptance discriminator: inspect the producer body for any actualBlocksQ,
actualEntryQ, actualLeftQ, actualRightQ, Nat.choose, rational exponentiation,
or original semantic source callbacks used to evaluate an output scalar. There
must be none; only specs/theorem statements may mention them. The sole new
scalar power engine is actual powQ, and factorial binomials use actual F reads.
Also inspect repeated cutoff/step/F construction and all collect/bind costs;
do not infer physical evaluation sharing merely from a mathematical let.

No typed impossibility is found. Pending risk is implementation of dependent
degree/index transport and proof of the literal decoder, not an excuse to add
oracle or cost hypotheses. End-to-end producer proof, finite-bit realization,
normalization and full ROOT resource integration remain open.
