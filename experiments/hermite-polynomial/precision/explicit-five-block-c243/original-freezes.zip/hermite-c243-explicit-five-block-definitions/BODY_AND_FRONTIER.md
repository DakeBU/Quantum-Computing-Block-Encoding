# C243 definitions-only successor: body and typed frontier

Status: AUTHORED, UNCOMPILED, BEFORE NEW STATEMENT SEAL. No new semantic or
cost proposition has been proved or searched for. All new `by` terms form
Fin bounds, degree bounds, or carrier equalities only. Parent owns the actual
type probe, body/signature seal, later proof authorization and execution.

## Materialized dataflow

`ExplicitFiveBlockDefinitions.lean`, namespace `HermiteExplicitCachedStored`,
contains one end-to-end producer. `IntendedRootTypeChecks.lean` contains only
declaration checks and eight proposition-formation candidates, not proofs.

1. Actual C23 `produceSourceCache k` returns the source cache.
2. Actual C150 `rightSetup n R delta` returns cuts, tail coefficients, clipped
   scalar and midpoint. Actual `middleFromCache` consumes that midpoint/cache.
3. A SECOND actual `cutoffQ delta` returns T. Its value computes native d and
   L=d+2k+1. Native `fiveSize d (2k+1)` controls all new numerical loops.
4. Actual `gridStepRun (n+1) R`, `qSub 0 R`, `qSub 0 step`, and C23 `factorials L`
   produce every new scalar/vector input. Their ledgers are included in full.
5. Nested canonical `collectIndexed` materializes the actual kernel table.
   Both boundary vectors use that same materializer. Numeric loops and
   callbacks receive stored degree/cut/step inputs, not a precision callback.
6. The returned RationalData is carrier-transported once to the original D,
   then the actual C22 `castData` consumes it. The very RealData returned is
   passed to canonical `StoredMatrixProductChain.ofTable`.

`indexedBind` stores `let y := f x.run.value` and adds BOTH actual run.cost
fields and BOTH selected index counters. `liftRun` preserves the entire
ordinary ledger and adds zero selected index calls only. Source/cache/setup/
middle/cutoff prefix costs are explicitly added to the resulting record.
Metadata is projected from returned records, not from recomputation of f.
This is annotated mathematical dataflow, not a machine sharing certificate.

## Versioned refinement relative to C237

The proposed `decode (k,delta)` interface is replaced by the degree-parameterized
`decode (d,m)` on `FiveIndex d m`. This is the same nested five-component type
and layout; `FiveIndex (sourceDegree delta) (2k+1)` is definitionally FullIndex.
The exact-layout check specializes the generic decoder to the original indices.

Reason: a callback computing sourceDegree(delta) for its dimensions could
re-execute a rational reciprocal/cutoff while pretending it was index-only.
The materialized body instead threads the numerical d from the charged cutoff
into all decoders, loop sizes and factorial bounds. The original rightEntry
accepts a proof-transported index; only the final RationalData carrier is cast
back. Parent explicitly approved this scoped API refinement before freezing.
No scientific target, cost coefficient, mask, sign or source layout was changed.

New `FiveIndex` is a transparent parameterized type abbreviation, not a new
quantum semantic foundation. `fiveSize` uses the exact original componentSize
sum. `splitIndex` exposes four possible literal sum-bound tests; the two
component products reuse actual finProdFinEquiv inverse division/remainder.
No opaque fullEquiv call supplies an output index in a producer body.

## Scalar callback inventory and annotation candidates

The numbers here are a raw-body accounting reconciliation, NOT Lean theorems.
They are upper bounds for conservative annotations, not native step counts.

| body | actual operations / intended bound |
| --- | --- |
| decode | at most four literal sum tests; 4 compare ticks reserved; selected 2 quotient and 2 remainder calls |
| comparisonQ | actual digit quotient/remainder; three charged comparisons; rational 0/1 literals |
| translationQ false branch | one reserved guard comparison, literal zero |
| translationQ true branch | chooseFrom (3 reads + 2 fields), powQ(2,q), charged bit comparison, 2 qMul, powQ(w,j-i), final qMul; plus guard: q+(j-i)+10 |
| componentKernel | two comparisonQ calls, translationQ and two nested qMul |
| kernelAt | literal five-by-five block dispatch, cross-tag zero, 8 compare reserve |
| kernelEntry | output split, two actual decoders, actual kernelAt; <=q+L+34 and selected counters <=7 each |
| componentLeft | two mask comparisons, powQ(origin,j), two nested qMul |
| leftAt/leftEntry | original five origins, 4 dispatch + 4 decode; <=L+12, selected counters 2 each |
| rightEntry | actual original C150 rightEntry; 4 dispatch + 4 decode; <=19, selected counters 2 each |
| extra preparation | second cutoff division + grid step n+3 + two negations = n+6; actual F construction charged separately |

The five rows remain exactly:

| summand | cuts | polynomial degree | origin | step | right flips |
| --- | --- | --- | --- | --- | --- |
| 1 | minusOne,minusT | 0 | 0 | 0 | false,false |
| 2 | minusOne,minusT | d | -R | h | false,true |
| 3 | minusOne,zero | 2k+1 | -R | h | true,false |
| 4 | zero,T | 0 | 0 | 0 | true,true |
| 5 | zero,T | d | R | -h | true,false |

Kernel/left do NOT flip masks. The last column is implemented by the original
rightEntry, not by a new approximation. Products retain first*(second*scalar).
Translation has choose(column,row), not choose(row,column), and checks row<=col
before actual factorial reads. All scalar powers use actual powQ; the only `^`
in the definitions module is natural arithmetic in digit addresses and the
specification-side budget. No Nat.choose or rational power is executed here.

For K=k+1, T=tailCutoff(delta), d=sourceDegree(delta), L=d+2k+1,
D=assemblySize(k,delta), P=(n+1)(2D^2+D+1)+2D, the C237 candidate is unchanged:

    B = 816K^2 + 81(d+1)^2 + 8(d+1) + 80(L+1)^2
      + 2(n+1)D^2(n+L+34) + D(L+61) + 9P
      + 20D^2 + 5n^2 + 9n + T + 59.

The candidate same-run target also bounds each SELECTED index counter by
14(n+1)D^2+4D. Bounds for actual source/middle/setup are required dependencies,
not accepted from parent-reported gate status and not new root hypotheses.
Actual source total 416K^2, middle 400K^2 and frozen C202 setup bound still
need correctly scoped theorem consumption in any future proof. The new source
contains no claim establishing B or these inequalities.

## Whole carrier and scientific boundary

All producer definitions take arbitrary n,k and rational R,delta. There is no
new positivity, normalization, generic F-correctness or cost promise on them.
The generic internal translation has r<=L only to form safe factorial indices;
the actual root supplies it from L=d+2k+1. The whole producer generates its own
factorial F, rather than receiving a source/cost oracle as public input.

No positive-step interpretation is used for R<=0. The original setup's total
rational division, strict/inclusive cuts, negative quotient branch, floor/
ceil cap rule and T<=1 midpoint branch remain literally executed upstream.
The constant components keep j=0 and powQ(0,0)=1. For n=0 there is one q=0
table, and canonical ofTable still closes both boundaries on that table.
The source-action proposition alone retains the original 0<R assumption.
Physical width, LSB-first stage q, signs, source error and register conventions
remain unchanged. There is no conversion to a different 2k+6 bond kernel.

The full source target is NOT certified by this packet. Native floor/ceil/clog,
natural casts/powers/address arithmetic, proof/counter administration, vector
allocation/evaluator behavior, rational bitlength/GCD, actual sharing, physical
gates/angles, normalization and full SP resource closure remain outside the
eight-counter/scoped-index model. No native constant-time claim is made.

## Provenance defect explicitly preserved

Parent detected that frozen C237 input-manifest recorded a 65-character
UniformTranslation SHA with an extra `d`:

    f346bb7bf6b313695519c3d6d86e6adecbeddadb1a1be475c853d36cf06a4b48e

The actual file was read completely and rebound in C243 to the correct SHA256:

    f346bb7bf6b313695519c3d6d86e6adecbedadb1a1be475c853d36cf06a4b48e

Parent reports actual raw bytes equal its HEAD Git blob; this worker did NOT
run Git or independently establish that relation. C237 is unchanged. This is
a historical transcription defect, not evidence of source change or mathematical
refutation; C243 does not claim that C237 had 35 matching input digests.

## Typed frontier and handoff

Type risks not yet tested: definition elaboration of nested Sum patterns,
dependent hd/hsize transport, generic Fin carriers, and original imported
namespace resolution. The type-check candidate module is not actual output.
No #check/#print result or own olean is claimed. No blanket linter option is set.

After parent type-probe: freeze the exact numerical definitions and final
propositions, issue StatementSeal, THEN authorize proof work. Value and cost
ingredients stay dependency edges; no generic setup/cache/F correctness promise
may be added to the final public roots. Required frontier is the complete
returned QData/value/cost chain, not isolated leaves unrelated to it.

Objective: materialize the explicit same-value kernel/left producer design.
Mathematical delta: a concrete executable-definition candidate replacing the
identified opaque scalar callbacks with actual primitive dataflow.
Named evidence: raw definitions and proposition-formation candidates only.
Failure class: NONE for definitions authoring; type/proof gates NOT RUN.
Salvage: reuse canonical C23/C150/C22/indexed/canonical-chain APIs; no duplication
of quantum foundations. Process-memory IDs: none. Parallel work: none.
Independent review / comparator / purification / exposition: not performed.
Exposure: same author as C237 and earlier cached-value/setup proposals and
middle/same-run audits; not a fresh universal decoder or independent reviewer.
Only a new C243 directory was written. No old source or frozen packet edited.
Freeze and STOP; all compiler/StatementSeal/proof decisions remain parent-owned.
