# C167 bounded signed-middle VALUE proof freeze

Status: COMPLETE_PROOF_CANDIDATE / NOT_COMPILED / NOT_ACCEPTED. This packet
addresses exactly the C156 `middleFromCache_entry` and `actual_cache_middle`
VALUE conclusions. No cost400, right-value, chain or resource theorem is added.
All executable bodies, signatures, predecessors and production remain unchanged.

## Source-first intake and exact interfaces

Before authoring, reread completely: C156 sealed-signatures.txt, the actual
C150 CachedMiddle.lean, C21 ActualCoefficients.lean and C23 ChargedSourceCache.lean.
The C156 seal/body hashes were rechecked. Exact C157 powQ_value source was
reread and the C159 own-output primitive provider hash checked. Raw StoredGivens
definitions and collect_value were also reread. No independent C161/C164
review, C165 failure artifact or C166 repair source was opened.

The two public types are exactly the selected C156 signatures, with arbitrary
k:Nat, e:Rat, a:Vector Rat(k+1), j:Fin(2k+2), and arbitrary delta:Rat for the
actual source specialization. They have no correctness/cost/positivity premise.

API retrieval was from actual local source, not guessed names:

```
Nat.choose_eq_zero_of_lt : forall {n k : Nat}, n < k -> Nat.choose n k = 0

Fin.sum_univ_eq_sum_range [AddCommMonoid alpha]
  (f : Nat -> alpha) (n : Nat) :
  (sum i : Fin n, f i.val) = sum i in Finset.range n, f i

HermiteChargedSourceCache.chooseFrom_value {N : Nat}
  (F : Vector Rat (N+1))
  (correct : forall i : Fin (N+1), F[i.val]=(i.val.factorial : Rat))
  (n r : Nat) (hr : r<=n) (hn : n<=N) :
  (chooseFrom F n r hr hn).value = (Nat.choose n r : Rat)

HermiteChargedSourceCache.factorials_value (n : Nat) (i : Fin (n+1)) :
  (factorials n).value.values[i.val] = (i.val.factorial : Rat)

HermiteChargedSourceCache.produceSourceCache_entry (k : Nat) (i : Fin (k+1)) :
  (produceSourceCache k).value[i.val] = HermitePiecewiseAssembly.sourceCoefficientQ k i.val

HermiteChargedSourceCache.sumEntries_value {n : Nat}
  (f : Fin n -> Run Rat) : (sumEntries f).value = sum i, (f i).value
```

The natural zero-binomial theorem was read in Mathlib/Data/Nat/Choose/Basic.lean.
The Fin sum theorem is the to_additive declaration generated directly from the
read Fin.prod_univ_eq_prod_range in Data/Fintype/BigOperators.lean. Its additive
name/use is also present in the actual C21/C23 source. No new mathematical
axiom or native operation is introduced by this API reuse.

## Own derivation and same-returned-object proof graph

Set W=k+1. The actual weightedSources run first obtains sigma=(-1)^W from
powQ. Its first returned scalar vector reads a_i, multiplies e*a_i and then
multiplies sigma. Its second returned vector reads a_i, computes (-1)^i from
powQ, and multiplies. Two private lemmas identify these actual array entries
with e*a_i*(-1)^W and a_i*(-1)^i. They do not replace the arrays with callbacks
or assume that a is positive/source-correct.

The actual factorial table for the two middle sums is factorials(2k+1).
The generated-binomial helper instantiates the existing chooseFrom_value with
the actual factorials_value theorem. It never accepts an arbitrary table's
correctness as a public premise. Its hr/hn arguments only form the existing
bounded accesses and are supplied by the original guards/finite index facts.

First summand: if W<=j and j-W<=i, the actual read/binomial/product returns
u_i*choose(i,j-W). If W<=j but j-W>i, the executable zero branch equals that
same expression because choose(i,j-W)=0. If j<W, the original outer condition
returns zero. Natural subtraction would give j-W=0 in that last case, so one
must NOT justify it by an out-of-range-binomial argument. The original outer
condition is retained explicitly.

Second summand: if i<=j and j-i<=W, the actual read/binomial/product returns
v_i*choose(W,j-i). If i<=j but j-i>W, the zero-binomial theorem justifies the
executable zero branch. If j<i, the original outer condition returns zero;
again natural subtraction truncates to zero, and the choose value is not
generally zero. The proof separates these cases.

With both exact summand lemmas, actual sumEntries_value and collect_value
identify each returned middle entry with middleExpr. Weighted-vector values
supply the signed coefficients. The generic theorem retains every j in
Fin(2k+2), including j=0,k,k+1,2k+1, and all k including zero. e and every a_i
remain arbitrary signed rationals; no Bernstein/nonnegative substitution.

Finally instantiate that generic theorem with the actual C23 returned vector
and e=expMidpoint delta. produceSourceCache_entry rewrites the full finite
cache range to the actual C21 sourceCoefficientQ. The two explicit Fin-to-range
sum identities give exactly the two sums in the raw middleCoeffQ definition.
No cache-correctness premise, off-range coefficient bridge, extra source
producer or desired-output equality is assumed.

This is a source-level proposed Lean dependency path: actual weighted values +
actual generated-binomial value + two guarded term equalities -> generic
returned middle entry -> actual C23 substitution -> C21 signed middle. It is
not a compiled theorem graph until the parent's gate. The source construction
graph remains finite rational exponential/source coefficients -> signed middle
-> five masks -> physical-grid chain -> normalized original target. This packet
does not close those downstream AND-tails.

## Expanded binder/definition and resource boundary

Public k,e,a,j,delta are TYPING/original construction data. No logical premise
was added to either C156 public type. Private generated_choose has only the
range witnesses required by the existing chooseFrom API; factorial correctness
is proved from the actual returned table, not exposed to the caller. EXCESS:
none proposed. No denominator-nonzero, coefficient-sign, delta positivity,
normalization, cost bound or correctness oracle is introduced.

WeightedSources is the same two stored scalar vectors; Run is value plus
eight-counter function; no proof or correctness bundle hides inside them.
All new declarations are proofs, not executable definitions, quotient/choice
objects, new state semantics, native-cost schema or desired-output stubs.

Only VALUE claims are addressed. Existing charged scalar operations remain in
the unchanged producer. The proposed 400 bound is not proved or accepted here.
Actual rightSetup.cost stays in the future partial ledger. Kernel/left scalar
work AND captured actualBlocksQ construction/setup remain UNACCOUNTED. Source
capture does not certify compiled sharing, eager/lazy elimination or one-time
evaluation. Native index/conversion/ceil/floor/clog, Rat bitlength/GCD,
allocation/evaluator/counter runtime, complete extraction and scientific ROOT
remain open. No physical or finite-bit resource claim follows.

The original SP-HERMITE-POLY-002 normalized little-endian state, scalar/radius/
degree/cut definitions, all signed coefficients and all boundary cases remain
unchanged. No new quantum representation or altered phase/register/ancilla/
normalization/error convention is introduced. This scalar bridge alone is not
a certified state-preparation circuit.

## Gate, uncertainty and precise repair obligations

Only import: CachedPrimitivesProof, with C159 own-output hash recorded in the
manifest. The actual CachedMiddle/C23/C21 providers stay bound to C156. The
additional local Mathlib source hashes/read extents are recorded; complete
Mathlib/provider rebuild or TCB cleanliness is not claimed. No independent
review was consumed by this author.

Parent-only planned commands (cwd=this new packet, new parent-owned output):

```text
lean --deps CachedMiddleValueProof.lean
lean -o parent-output/CachedMiddleValueProof.olean CachedMiddleValueProof.lean
lean --deps MiddleValueProofChecks.lean
lean -o parent-output/MiddleValueProofChecks.olean MiddleValueProofChecks.lean
```

None was executed. Reuse the exact approved C159/C155 environment, select the
actual pinned CachedPrimitivesProof and unchanged producer outputs, and put
fresh own proof output first for the consumer. Inspect actual --deps results,
hash inputs/outputs before/after and inspect both actual root axiom expansions.
MiddleValueProofChecks is an author exact-type/axiom consumer, not independent
review. Full repository and applicable publication/root gates remain separate.

Uncompiled risks: simp specialization of generated_choose after dependent guard
elimination; matching two weighted vector projections under collect/sumEntries;
and Fin-to-range sum unification in the final specialization. The precise
proof-only repair, if needed, is to expose the same value projections, use
explicit guard-conjunction witnesses or instantiate the retrieved Fin sum
theorem with the displayed functions. Do not alter C150, weaken C156, replace
the original primary guards or add public correctness premises. No local API
failure or semantic counterexample has been observed because no compiler ran.

## Required substantive-worker handoff

Objective/frontier: the two actual signed-middle value bridges needed by the
same-chain cached C22 supplier. Delta: two complete sealed proof candidates,
five private weighted/generated-binomial/guarded-term lemmas, exact-type/axiom
consumer and own source-first derivation. No accepted theorem delta yet.

Named evidence/files changed: CachedMiddleValueProof.lean,
MiddleValueProofChecks.lean, this audit and input-manifest.json; new C167 files
only. No predecessor, production, gate, score or scientific target edit. No
finite diagnostic, compiler/lake/script/Git/network/subagent run occurred.

Failure class: NONE for authoring. Parent's reported C165 inclusive-cut proof
API failure belongs to preserved earlier scope; this packet does not edit that
attempt or treat it as negative mathematics. Salvage: preserve this complete
C167 source and any later diagnostics before proof-only repair.

Reusable insight: primary truncation guards and secondary binomial-zero guards
are logically different; conflating them changes the polynomial. The actual
cache theorem applies on the precise finite range, not the false unrestricted
coefficient bridge outside i<=k.

Process-memory IDs: QBE-PM-LOW-TOKEN-CONTROL-PLANE and
QBE-PM-VERIFIER-SEMANTIC-LEVEL from the retained repository skill/protocol pack.
Parent-authorized distinct bounded value uncertainty, no child workers and no
independent C161/C164 review exposure. Common-blind-spot/independent value/cost
review remains pending. Default verified baseline remains inherited C22 plus
parent-compiled primitive prerequisites, not this uncompiled candidate.

Purification/Exposition Seal: NOT_STARTED. Private helpers have actual proposed
consumers, but dead/wrapper/duplicate/import audits remain after compilation.
Source/Lean expansion nodes and remaining scientific/resource boundary are
explicit above; no root closure or verified physical arrow is advertised.

Recommended next action: parent's serialized own-source/fresh-output consumer
gate; preserve any failure and repair proof only. Worker stops after this
bounded middle-value freeze; cost400/full right/chain are intentionally untouched.
