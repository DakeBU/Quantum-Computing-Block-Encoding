import CachedPrimitivesProof

open QuantumBlockEncoding QuantumBlockEncoding.StoredGivens
open HermiteCachedPiecewiseStored

/-! Type formation only: no proof, axiom, or acceptance claim.
The actual rightSetup definition and its total rational parameter domain stay
unchanged. Only the literal eight-counter annotation is in scope. -/
#check (∀ (n : ℕ) (R delta : ℚ),
  StoredRectangularGivens.total (rightSetup n R delta).cost ≤
    81*(HermiteFiniteExpDegree.sourceDegree delta+1)^2 +
    8*(HermiteFiniteExpDegree.sourceDegree delta+1) + n +
    HermiteFiniteExp.tailCutoff delta + 22)
