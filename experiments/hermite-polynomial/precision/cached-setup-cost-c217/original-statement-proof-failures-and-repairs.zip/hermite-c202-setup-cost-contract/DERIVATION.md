# Actual right-setup partial-counter contract, before proof search

Classification: internal cost provider for SP-HERMITE-POLY-002, not a new
external Source Anchor, new scientific target or complete runtime claim.
The three typing parameters n:Nat, R/delta:Rat remain unrestricted. No logical
premise is added. The literal C150 rightSetup and eight-counter total are fixed.

Let T=tailCutoff(delta), d=sourceDegree(delta), q=d+1. The same generated cutoff
sets the factorial/tail/midpoint size. Value-index transport must use its actual
equality; a caller is not asked to supply a cutoff/degree/table correctness fact.

The proposed bound is derived from these actual phases, in order:

| Actual phase | Partial total upper bound |
| --- | ---: |
| cutoffQ, rational division only | 1 |
| gridStepRun at physical width n+1 | n+3 |
| two strictCutFrom calls | 6 |
| two inclusiveCutFrom calls | 8 |
| minusT qSub | 1 |
| actual factorials(d), eight per-counter bounds summed | 80q^2 |
| stored reciprocal-factorial tail, read/divide plus collect traffic | 6q |
| clippedRun(T), actual power and two divisions | T+2 |
| midpointFrom, compare and optional full sum | 1+q(d+3) |

The optional midpoint sum has q entries, each with at most d multiplications,
one read and one division; sumEntries additionally performs q additions,
including its final addition to zero. For T<=1 the sum is skipped, but the
comparison tick is retained. No positive delta/radius or T>=2 restriction is
needed to upper bound either branch. Canonical collect traffic is retained.

Adding these terms gives exactly

    81q^2 + 8q + n + T + 22.

This is a candidate derivation, not a proved theorem. Parent actual type probe
passed before authoring, exit0/24.516 subprocess seconds, at pinned Lean4.33.0.
Its exact source, output, receipt and private dependency transcript are retained.

Boundary: cutoff ceil/clog, floors, natural-index/cap arithmetic, Rat integer
bitlength/GCD and casts, allocation, evaluator/counter runtime and compiled
sharing are NOT costed by these eight annotations. Neither kernel/left nor
captured actualBlocksQ setup is covered here. A later same-run bound still owes
those native/finite-bit/quantum synthesis/cleanup/export obligations. This
contract cannot close the original scientific ROOT or certify poly(n_p) gates.
The purpose is to remove the currently symbolic rightSetup.cost term from the
partial ledger without pretending it was zero or an oracle.

Proof author must freeze exact sources/providers and prove the unchanged public
signature with no caller promises. Parent owns actual fresh-source/own-output
type/axiom gates; independent review, integration and purification are separate.
