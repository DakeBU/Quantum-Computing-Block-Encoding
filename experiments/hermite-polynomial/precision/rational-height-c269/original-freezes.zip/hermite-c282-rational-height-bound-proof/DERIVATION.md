# C282: heightBound only, uncompiled author freeze

Objective: prove precisely C280's first root,
HermiteRationalHeight.heightBound : HeightBoundSpec. Other three roots remain
unproved and outside this assignment. No producer or Sites conclusion follows.

For canonical q and any natural B, expand h(q) to
max(1,max(size(abs(q.num)),size(q.den))). The two max_le_iff instances give
1<=B AND size(abs(q.num))<=B AND size(q.den)<=B. Apply Nat.size_le to each
size bound: each is exactly a STRICT inequality against 2^B. The resulting
conjunction has exactly the sealed order and association. No arithmetic search,
Rat normalization, denominator property, positivity or nonzero premise is used.

Boundary audit (hand analysis, not executed tests): B=0 makes both sides false
because h>=1 and 1<=0 is false; q=0 has numerator size0, denominator size1 and
h=1. The same holds for +/-1. For +/-1/2, h=2; for a canonical power 2^t or
its reciprocal, h=t+1. Equality at 2^B is excluded, not rounded into B bits.
Magnitude bits do not include an integer sign bit.

Source graph: maximum-bound equivalence plus size/power equivalence -> field
height equivalence. Lean graph: unchanged Definitions, ordinary Mathlib
Order.MinMax/Data.Nat.Size -> heightBound -> closed expanded type consumer.
These are representation semantics, not an operational integer trace.

Input audit: C280 seal, complete signatures and definitions read whole; C269
definitions hash matches. Nat.Size read whole; Order.MinMax lines1-85 read,
including the generated max_le_iff declaration at le_min_iff. Narrow API-name
search also found only an older installed core tree; it was not used as API
authority or imported. No other root proof, review packet or runtime read.

Evidence: HeightBoundProof.lean is one candidate proof; ExactChecks.lean assigns
the exact CLOSED expanded signature and queries actual root/consumer axioms.
Parent must select the new own author output for this consumer, inspect --deps,
and compile both. No author compiler/test output exists; no accepted root or
ordinary-axiom inventory is asserted here. Current uncertainty is elaboration
and selected import/API verification, not a known mathematical counterexample.

Skill handoff: qbe-substantive-worker; inherited full protocol intake and
LOW-TOKEN-CONTROL-PLANE / VERIFIER-SEMANTIC-LEVEL. Direction: C280_FIRST_HEIGHT_ONLY.
No parallel lane or comparator needed for this direct equivalence; source/math
boundary audit covers zero, signed magnitude and strict power endpoints.
Failure class: ENV_BLOCKED for author compile by task authority, not API failure.
Salvage: complete candidate pending parent gate; nothing discarded or weakened.
Files: new proof, exact consumer, this derivation, manifest and author freeze.
Purification/Exposition-Seal NOT_STARTED; this is not publication acceptance.
Native bit/GCD/scratch/evaluator/physical sharing/full producer/finite SP and
scientific ROOT claims remain open. Actual C248/C150/C23 bodies are untouched.
No compiler/scripts/Python/lake/Git/network/subagent or forbidden proof exposure.
Recommended next step: parent serialized exact source and own-output consumer
gate; only after success decide separately whether to authorize the next root.
Freeze and STOP; no whole-producer claim and no claim all four are proved.
