# C276: allocated partial-operation polynomial interface candidate

AUTHOR-UNTYPED formations, not proved or Statement-Sealed. New interface-author
role, not an independent decoder. C264/C273 remain immutable. No compiler,
proof search, scripts/Python, Git, network, subagents or finite check ran.

## Literal parameters and dependency cut

Let np=n+1, K=k+1, delta=sourceDelta k n epsilon, epsilon>0, and
B=tailCutoff(epsilon/(4*K^2)), M=np+2k+B (exact operationScale definition).
The actual source has amplificationQ k=K^2*2^(2k), hence C147 gives
delta=(epsilon/(4*K^2))/2^(np+2k), T=tailCutoff(delta)<=M.
No radius replacement, desired-degree redefinition, cutoff premise or new
normalization/error hypothesis is inserted. R remains any rational.
The underlying degree is d=sourceDegree(delta)=4T^2+2T+1.
Its five-block size is D=18d+18k+54, not a new rank theorem.
Write L=d+2k+1 and P=np*(2D^2+D+1)+2D.

Since M>=1, np<=M, K<=M and 2k+1<=M, independently:

```text
d <= 4M^2+2M+1 <= 7M^2;       d+1 <= 8M^2
L <= 7M^2+M <= 8M^2;          L+1 <= 9M^2
D = 18d+9(2k+1)+45 <= 126M^2+9M+45 <= 180M^2
P <= M*(64800M^4+180M^2+1)+360M^2 <= 65341M^5.
```

All inequalities are natural-number bounds; M>=1 justifies raising a smaller
power to M^7 or M^5, including k=n=0 and T=0. No epsilon<=1 is needed.

## Check the actual frontierBudget term by term

The following coefficients bound each literal summand by that coefficient*M^7:

| Actual term | Coefficient | Before promotion to M^7 |
| --- | ---: | --- |
| 816K^2 | 816 | 816M^2 |
| 81(d+1)^2 | 5184 | 5184M^4 |
| 8(d+1) | 64 | 64M^2 |
| 80(L+1)^2 | 6480 | 6480M^4 |
| 2np*D^2*(n+L+34) | 2786400 | 64800M^5*43M^2 |
| D*(L+61) | 12420 | 180M^2*69M^2 |
| 9P | 588069 | 588069M^5 |
| 20D^2 | 648000 | 648000M^4 |
| 5n^2 | 5 | 5M^2 |
| 9n | 9 | 9M |
| T | 1 | M |
| 59 | 59 | 59 |

Here n<=M<=M^2, n+L+34<=43M^2 and L+61<=69M^2.
The coefficient sum is 4047507, strictly below 5000000 (margin952493).
For either selected index-call envelope, the actual expression satisfies
14np*D^2+4D <=453600M^5+720M^2 <=454320M^5 <=500000M^5.
Thus the parent's proposed constants are retained after an independent manual
recalculation, not treated as accepted input evidence or optimized constants.

## Why this is genuinely polynomial in physical size and precision

Let b=tailCutoff(epsilon). By its literal max/ceil/clog definition,
1/epsilon<=2^b, even epsilon>=1 (then b=0).
K<=2^k follows by elementary induction; thus 4K^2/epsilon<=2^(2k+2+b).
Ceiling this positive rational is <=that integer; max1 stays <=it as well.
The defining dyadic cutoff is therefore B<=2k+2+b, so
M<=np+4k+2+b. This is intendedScaleDyadicBound, not an assumed premise.
For epsilon>0, b is the least natural j with 1/epsilon<=2^j; mathematically
it is max(0,ceil(log2(1/epsilon))). The natural formulation avoids negative
logarithms for large epsilon and does not require a real-log API in Lean.
Consequently the candidate implies total<=5000000*(np+4k+2+b)^7 and both
selected counts<=500000*(np+4k+2+b)^5, after monotonicity/composition proofs.

## Exactly three intended formations; no proofs supplied

1. intendedScaleDyadicBound: the literal M-to-dyadic-precision comparison.
2. intendedAllocatedBudgetEnvelope: actual frontierBudget and actual selected
   cap at sourceDelta, bounded by the two proposed polynomials.
3. intendedAllocatedSameRunPartialLedger: compose #2 with the existing exact
   produceExplicitStored_cost_counters supplier at that SAME delta/result.

Only operationScale is a new numerical definition; the three Prop-valued defs
are theorem targets, NOT proofs, axioms or executable producer replacements.
Parent must type them against pinned providers, expand the definitions into
exact signatures and finish a real pre-proof Statement Seal before proof work.
The dependency DAG is C147+degree/size algebra -> #2; literal cutoff -> #1;
#2+actual same-run cost supplier -> #3. No source-value theorem is needed.

Scope remains partial operation annotations plus selected quotient/remainder
calls: not all integer divisions, native Rat/bit/GCD/evaluation/allocation/
captured sharing, finite-real cast implementation, QR/synthesis/gates/depth/
cleanup/export, normalized state error/success or scientific SPBE ROOT. Neither
R's encoding height nor pi/L representations are silently certified. The
existing error budget and the positivity range epsilon>0 remain unchanged.

Input/exposure details, exact hashes, failed read-only command and old-neighbor
proof-fragment exposure are retained in INPUT_MANIFEST. No new value packet was
opened or used. Recommended next step is parent type formation only; no proof,
runtime or publication acceptance is claimed. Purification NOT_STARTED. STOP.
