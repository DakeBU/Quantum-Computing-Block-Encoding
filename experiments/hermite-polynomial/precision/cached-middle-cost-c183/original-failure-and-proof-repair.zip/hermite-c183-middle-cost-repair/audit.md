# C183 proof-only repair of the preserved C176 failure

## Objective and exact status

Only the unchanged C156 middleFromCache_total_le proposition is targeted:

```lean
∀ (k : ℕ) (e : ℚ) (a : Vector ℚ (k+1)),
  QuantumBlockEncoding.StoredRectangularGivens.total
    (HermiteCachedPiecewiseStored.middleFromCache k e a).cost ≤ 400*(k+1)^2
```

C176 remains immutable. The parent C182 compile actually failed, exit 1 in
27.797 seconds, with no own olean, no consumer run and no accepted root. This
successor is a complete but UNCOMPILED proof candidate. No success is inferred
from the absence of further author diagnostics. No theorem/body/premise,
counter model, coefficient producer or numeric budget is changed.

Direction fingerprint: C145_ACTUAL_C23_CACHE_CONSUMPTION_IN_C22_SAME_CHAIN.
Scientific root SP-HERMITE-POLY-002 remains OPEN at its full finite-bit/classical/
executable frontier. Original normalized little-endian representation and all
signed/degree/radius/cut/boundary conventions remain intact.

## Actual failure evidence, fully read before repair

The complete C182 feedback (188 lines) and result JSON (40 lines) were read.
Their immutable bindings are:

- CachedMiddleCostProof-feedback.txt SHA256
  d71f06ac4459ff83e4d4d05513cf158981eb7d9a5222e2b1eac7f5f43f1161ab.
- proof-result.json SHA256
  74904cc82093dac655d06512503ce364c2b8738a6e914449dcb06ddc71c94432.
- Original C176 source SHA256
  629e0b81ef7902ecd169659198c98777fa04af3c4bf1711bfc433027e695c542.
- Original C176 manifest SHA256
  c09c3bdb15d36223ecf05efeac3f57a719006df3eb09ce6301557570d97a2c9b.

These are implementation failures, not a mathematical refutation. The receipt
also preserves three linter warnings; this bounded repair does not edit them.
No independent reviewer result or finite-comparison packet was consumed.

## Three localized repairs and their own derivation

First term inactive guard: the hypothesis was
not(k+1<=j.val AND j.val-(k+1)<=i.val). Broad simp transformed the dependent
conditional to k<j.val AND j.val<=i.val+(k+1), so the original negation no
longer matched syntactically. C183 keeps the original by_cases and first runs
only [middleFirstTerm,dif_pos h] or [middleFirstTerm,dif_neg h]. This removes
the actual dependent conditional BEFORE broad arithmetic simplification. The
already selected branch is then costed exactly as before. No substitute guard,
new arithmetic hypothesis or alternative executable branch is introduced.

Second term inactive guard: the hypothesis was
not(i.val<=j.val AND j.val-i.val<=k+1), while broad simp created
i.val<=j.val AND j.val<=k+1+i.val. The same two-stage original-guard elimination
is used, with middleSecondTerm. The active branch remains three factorial reads
and two field operations plus one weighted read, one multiplication and two
reserved comparisons: at most 9. The inactive branch remains two comparisons.

Final cost matching: the failure context shows ht still expressed with a
monadic callback, while the goal's callback was already expanded to a Run record.
Although definitionally related, the arithmetic tactic treated these as distinct
atoms. C183 adds exactly `simp only [bind, Run.bind] at ht` before the existing
goal simplification. Both now use the SAME callback record normalization before
nlinarith. No additional cost assumption, weakened inequality or dummy ledger
is inserted.

All twelve private helper names remain c176_* to keep the repair minimal; they
are self-contained theorem declarations in this fresh module, NOT imported from
the failed C176 module. The sole direct import remains CachedPrimitivesProof.
The exact-type/axiom consumer imports only this module's fresh own output.

## Actual operation audit and unchanged mathematical composition

Let W=k+1>=1. Canonical total sums field, sqrt, angle, trig, compare, read,
write and emit. Each cost component is retained, including storage traffic.
The existing proof derivation is unchanged:

1. Actual factorials(2*k+1): all eight inherited per-counter bounds are added,
   giving 80*(2*k+2)^2=320*W^2. Persistent extensions and reads are not omitted.
2. Actual weightedSources: common sign costs W, first collect costs <=7*W,
   second collect costs <=W*(k+6), including every per-index sign power and
   charged source read. Total <=W^2+13*W<=14*W^2.
3. Each actual guarded term costs <=9, including both comparisons when zero.
   sumEntries adds n times, including the last addition to zero; it is NOT
   budgeted as n-1. Both length-W sums therefore cost <=10*W each. The final
   qAdd costs 1. Output collect has 2*W entries, each with four traffic ticks,
   so total <=40*W^2+10*W<=50*W^2.
4. Actual returned factorial values and actual returned WeightedSources are
   substituted into the literal table bound. Actual binds add their costs:
   <=384*W^2<=400*W^2. No caller budget or correctness premise is added.

The public k,e,a are original typing/construction data, not logical premises.
All k including 0 and arbitrary signed rational e/a remain covered. EXCESS:
none. Private generic collect/sum budget premises are discharged by actual
primitive/term proofs at every call site. The arbitrary stored F/weights bound
needs no value correctness for COST and is instantiated with actual outputs.
No denominator-nonzero or supplied-cache correctness assumption is hidden.

This is ONLY the eight-counter annotation. The outer source-cache cost and
actual rightSetup.cost remain future same-run dependencies. Kernel/left scalar
work AND captured actualBlocksQ construction/setup stay UNACCOUNTED. Source
bindings do not certify eager/lazy elimination, no duplicate setup, physical
sharing or one-evaluation. No native index/control/cast/floor/ceil/clog cost,
Rat bitlength/GCD, allocation/evaluator/counter runtime, full chain, synthesis
or scientific ROOT theorem is claimed.

## Inputs, source/Lean graphs, gate and residual uncertainty

C156 STATEMENT_SEAL.json and full sealed-signatures.txt remain unchanged.
The 35 repository context pins and all four C150 definition pins were rehashed
with zero mismatches. The whole original C176 proof was reread; its source
derivation, canonical Op/Cost/Run/read/collect/total definitions and actual C23
factorials/chooseFrom/sumEntries intake are retained from C176. No author result
or review is used as a replacement for those raw definitions.

Reused exact public APIs remain powQ_cost (C157 source, C159 own olean),
HermiteChargedSourceCache.factorials_cost_le, chooseFrom_cost,
QuantumBlockEncoding.StoredGivens.collect_cost, Run.bind, Run.pure, charge,
read, tick, Op, Cost, and StoredRectangularGivens.total. Finset.sum_le_sum,
Finset.sum_add_distrib and Fin.sum_univ_succ are unchanged finite-sum bridges.
No new provider, toolchain version or theorem interface is introduced.

Source/Construction NODEs remain charged sign/weighted vectors, explicit actual
factorial pass, both guarded binomial sums and stored output. Outer-cache/right/
captured-block/native lowering are excluded only from this bounded scope, not
from the root; their remaining bridges are SOURCE_GAPs. Lean graph retains the
C176 private composition with only branch elimination and matching normalization
repaired. Quantum spine and Functor Hypergraph are unchanged. Lean proof repair
alone does not close source/runtime obligations.

Parent-only planned commands, cwd this packet, using exact approved C159/C155/
C23/C21 providers and a NEW parent output directory:

```text
lean --deps CachedMiddleCostProof.lean
lean -o parent-output/CachedMiddleCostProof.olean CachedMiddleCostProof.lean
lean --deps MiddleCostProofChecks.lean
lean -o parent-output/MiddleCostProofChecks.olean MiddleCostProofChecks.lean
```

None was run by this author. The consumer must resolve the fresh C183 own
output first, never a failed/stale C176 same-named output. Inspect actual deps,
hashes and printed axioms, rejecting unexpected axioms/sorryAx. An exact-type/
axiom consumer written by the author is NOT independent semantic review.

Remaining uncompiled uncertainty: whether staged simp eliminates both original
dependent guards as intended, and whether the two identically selected bind
normalizations make the arithmetic atom identical. If further API details fail,
preserve this packet and fresh diagnostics; proof-only repair is permitted only
under the same bodies, target, guard logic and public premise boundary.

## Required skill handoff

Objective/frontier: repair the three actual C182 proof failures on the sealed
middle annotation bound. Mathematical delta: three localized proof-only edits,
not a changed construction or accepted theorem. Effect on root: pending bounded
cost edge only. Named evidence/files: complete C182 failures above; new
CachedMiddleCostProof.lean, MiddleCostProofChecks.lean, audit.md and
input-manifest.json. No predecessor/production/gate/scoring edit.

Failure class: IMPLEMENTATION_FAILED for preserved C176/C182; C183 candidate
uncompiled, not yet promoted. Salvage: all C176 fragments retained, only three
repair locations changed, no discarded or silently overwritten failure.
Process-memory IDs: QBE-PM-LOW-TOKEN-CONTROL-PLANE and
QBE-PM-VERIFIER-SEMANTIC-LEVEL. Expected information gain: test whether exact
branch selection and common callback normalization discharge the demonstrated
elaboration failures with unchanged actual-operation accounting.

Parallel/common-blind-spot audit: no subagents; parent serializes compilation;
no independent review exposed. Default verified route uses the unchanged actual
producer and existing primitive provider; no alternate representation or free
callback route. Purification/Exposition-Seal: NOT_STARTED. No publication, clean
transitive TCB or full-root success. Reusable cross-layer insight: normalize
dependent branch selection before arithmetic, and normalize the SAME returned
callback on both sides before treating its total as an arithmetic atom.

Recommended merge/next forks: parent fresh gate first, then independent review
and any broader same-chain proof only under separate authorization. No fork is
launched here. Context digest: C156 governs; C150/C157/C159 unchanged; C176 and
C182 preserved; parent safe-fetch contribution ba2afcc1827f76284aefd038396007058eae009e,
main af585d9cbbb299c1c8c48647627a2cb820ef536a (no worker Git assertion). Freeze
this additive C183 packet and STOP.
