import CachedMiddleCostProof

/-! Same-author exact-type/axiom consumer, not independent review. The parent
must compile this only against its fresh own CachedMiddleCostProof output. -/

open QuantumBlockEncoding

#check (HermiteCachedPiecewiseStored.middleFromCache_total_le :
  ∀ (k : ℕ) (e : ℚ) (a : Vector ℚ (k+1)),
  StoredRectangularGivens.total
    (HermiteCachedPiecewiseStored.middleFromCache k e a).cost ≤ 400*(k+1)^2)

#print axioms HermiteCachedPiecewiseStored.middleFromCache_total_le
