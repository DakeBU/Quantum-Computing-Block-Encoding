# C176: bounded actual middle cost candidate

## Frozen objective and status

The sole public target is the unchanged C156 proposition:

```lean
HermiteCachedPiecewiseStored.middleFromCache_total_le :
  ∀ (k : ℕ) (e : ℚ) (a : Vector ℚ (k+1)),
  QuantumBlockEncoding.StoredRectangularGivens.total
    (HermiteCachedPiecewiseStored.middleFromCache k e a).cost ≤ 400*(k+1)^2
```

This packet supplies a complete proof candidate, not an accepted theorem. Its
author has run no Lean compiler, lake, provided script, finite discriminator,
Git, network or subagent. The parent owns the fresh serialized compilation and
exact-type/axiom gate. No independent review packet has been read. C156 bodies,
types and hypotheses are unchanged. Only new C176 files were written.

Direction: C145_ACTUAL_C23_CACHE_CONSUMPTION_IN_C22_SAME_CHAIN.
Scientific root: SP-HERMITE-POLY-002. Original normalized little-endian state,
signed coefficients, scalar/degree/radius/cut choices and boundary conventions
remain unchanged. This intermediate scalar/word cost bridge cannot close the
full finite-bit/classical/executable root.

## Own derivation from the actual bodies

Write W=k+1, so W>=1. The sum of the eight counters is field+sqrt+angle+trig+
compare+read+write+emit, in exactly the canonical total definition's order.
Linearity is proved by expanding that definition, not assuming a cost oracle.

1. Actual powQ performs m charged multiplications. The imported exact
   powQ_cost gives total m, including the m=0 case.
2. Actual collect has total sum_i total(f i).cost + 4*n: its stored traffic is
   two reads and two writes per entry. The callback costs are retained. The
   internal bound helper requires and receives actual callback cost proofs.
3. Actual sumEntries has total sum_i total(f i).cost + n. This is n additions,
   NOT n-1: its last value is added to the recursively returned zero. The
   proof follows its actual zero/successor equations, including n=0.
4. Actual factorials n satisfies the inherited bound 10*(n+1)^2 separately for
   each of the eight counters. Adding all eight gives 80*(n+1)^2. With
   n=2*k+1 this is 320*W^2. This intentionally loose bound includes the
   charged persistent extensions/full-copy traffic; the pass is not free.
5. WeightedSources computes its common sign with W multiplications. A first
   entry reads a and performs two multiplications: total 3, hence its collect
   costs at most 7*W. A second entry reads a, executes the actual i.val power
   recurrence, and multiplies: total i.val+2 <= k+2. Its collect costs at most
   W*(k+6). Thus the actual weighted run costs at most W^2+13*W <= 14*W^2.
6. In either active guarded term, two reserved comparisons + one weighted
   vector read + chooseFrom's three reads and two field operations + the
   final multiplication total 9. An inactive term still costs 2 comparisons.
   Both original conjunction guards are split without replacing them. No
   denominator-nonzero or factorial-correctness premise is needed for COST:
   qDiv charges one field operation even when its mathematical input is zero.
7. Each of the TWO full length-W sums costs at most 10*W. Their actual qAdd
   costs another 1. Each output coefficient therefore costs at most 20*W+1.
   The output collect has exactly 2*W entries and charges four traffic words
   per entry: at most 40*W^2+10*W <= 50*W^2.
8. The public proof unfolds the actual middleFromCache binds and instantiates
   the table bound with precisely the returned factorial table and returned
   WeightedSources. Total <= (320+14+50)*W^2 = 384*W^2 <= 400*W^2.

The suggested 384 constant was independently reconstructed above from actual
source definitions; it is not an imported assertion. The proof exposes all
three contributions before arithmetic composition. No theorem assumes the
desired final bound, a caller callback budget or correctness of the cache.

## Exact reused interfaces and providers

Only new direct import: CachedPrimitivesProof, from the author's frozen C157
source and the parent-compiled C159 own output. Used public root:
HermiteCachedPiecewiseStored.powQ_cost, with binders x:Q, m:N, op:Op and exact
result (powQ x m).cost op = m*tick.field op.

The transitive unchanged C150 CachedMiddle provider supplies powQ,
WeightedSources, weightedSources, middleFirstTerm, middleSecondTerm and
middleFromCache. Its actual bodies, not desired-output specifications, are
used. CachedRightSetup is a transitive import but no setup/right proof root is
used. C167/C174 value outputs are not needed by this COST proof.

HermiteChargedSourceCache.factorials_cost_le has inputs n:N and op:Op and
conclusion (factorials n).cost op <= 10*(n+1)^2. Its actual source includes the
recursive factorial table and charged extend. This is reused once per counter.
HermiteChargedSourceCache.chooseFrom_cost has binders {N}, F:Vector Q(N+1),
n,r:N, hr:r<=n, hn:n<=N, op:Op and result 3*tick.read op+2*tick.field op.
The existing term guards/Fin witnesses already provide its range proofs.
Neither API supplies or requires a public cache-correctness premise here.
The actual qAdd, qMul, sumEntries, factorials and chooseFrom definitions are
the C23 source, not new substitute producers.

Canonical Run.bind, Run.pure, charge, read, collect, collect_cost, Cost, Op,
tick are QuantumBlockEncoding.StoredGivens declarations. Canonical total is
QuantumBlockEncoding.StoredRectangularGivens.total. Finset.sum_le_sum,
Finset.sum_add_distrib and Fin.sum_univ_succ retain the actual finite sums;
the latter also appears in C23's source sumEntries proof. Generic helpers in
this packet are private, named c176_*, and do not expose new caller promises.

## Binder, definition and actual-operation audit

Public k, e and a are original construction data, with k any natural and
e/a arbitrary signed rational carriers. No positivity, nonzero coefficient,
delta, normalization, cache-value, lookup-budget or correctness premise was
added. Public EXCESS binders: none. All k including k=0 remain covered.

Private collect_le and sum_le quantify B and a bound for the actual f; every
use discharges that bound from read/multiplication/pow/guard/sum bodies. The
private table bound quantifies arbitrary stored F and weights because COST
does not require value correctness; it is instantiated by the actual returned
objects. These are not supplied-cache correctness or cost axioms. No new
executable definition, cost schema, desired-output stub, axiom, sorry, admit,
unsafe declaration or native_decide proof is introduced.

This theorem bounds middleFromCache after a has been supplied. It includes
the explicitly repeated factorial pass because C23 does not return its private
factorials; it does not duplicate the source-coefficient producer. The outer
actual produceSourceCache cost must still be added by the later same-run
integration proof, not erased. Actual rightSetup.cost must likewise remain in
the future partial chain ledger.

The model is ONLY the eight-counter scalar/word annotation, not the runtime
of evaluating the producer or evaluating its annotation. Natural indices,
control arithmetic, casts, floor/ceil/clog, Rat numerator/denominator/GCD,
allocation, proof checking and counter metadata/evaluation are not native
costed. Kernel/left scalar work AND captured actualBlocksQ construction/setup
remain unaccounted. A source let-binding does not prove compiled eager/lazy
elimination, physical sharing, no duplicated setup, or one-time evaluation.
No finite-bit, GCD, synthesis, full runtime or scientific ROOT success follows.

## Source graph versus Lean graph

Source/Construction NODEs: supplied actual scalar cache; charged weighted
vectors and sign powers; explicit factorial pass; two correctly guarded
binomial convolutions; two real sums and final addition; stored output collect.
This package addresses their annotated work, while C167 separately addresses
their values. EXCLUDED(scope): tail/right setup, captured blocks, stored-real
chain, circuit lowering and native extraction. They are not excluded from the
scientific root. Remaining source-to-runtime and full-chain obligations remain
SOURCE_GAPs, not solved by private arithmetic lemmas.

Lean graph: powQ_cost -> pow_total; collect_cost + eight-counter linearity ->
collect_total/collect_le; actual sumEntries recursion -> sum_total/sum_le;
factorials_cost_le at eight Ops -> factorials_total; literal weighted bodies ->
weighted_total; original guards + chooseFrom_cost -> two term bounds; both
sum bounds + qAdd + collect -> table_total; actual bind -> sole public root.
The compressed quantum spine and Functor Hypergraph are unchanged. A local
Lean graph edge cannot substitute for the missing source/runtime edges.

## Planned parent-only gate and repair obligations

Reuse the precise approved C159/C155/C23/C21 provider environment and canonical
Lean 4.33 toolchain. Put a NEW parent-owned output directory first for the
consumer, never a stale same-named proof output. Planned commands, not executed:

```text
lean --deps CachedMiddleCostProof.lean
lean -o parent-output/CachedMiddleCostProof.olean CachedMiddleCostProof.lean
lean --deps MiddleCostProofChecks.lean
lean -o parent-output/MiddleCostProofChecks.olean MiddleCostProofChecks.lean
```

Check actual dependency resolution and input/output hashes before and after.
The consumer checks the exact sealed public type and prints actual axioms.
Reject any unexpected axiom or sorryAx; expected ordinary background axioms
require the parent's actual inspection, not this author's prediction. Both
files are same-author artifacts, not independent semantic review. Full CI,
publication admission, purification and scientific-root gates remain separate.

Uncompiled local risks: total-of-collect finite-sum normalization; successor
specialization of the sumEntries induction; dependent-if normalization of
chooseFrom_cost; total simplification across monadic weighted aliases; final
nonlinear arithmetic normalization. No semantic counterexample has emerged
from the source derivation. If a proof API fails, preserve this exact candidate
and diagnostics, repair only the same proof expansion in a successor, and do
not alter producer bodies, guards, sealed targets or public assumptions.

## Required substantive-worker handoff

Objective/frontier: actual cached middle cost <=400*(k+1)^2, dependency-ready
bridge toward same-chain C22 consumption. Mathematical delta: one complete
sealed proof candidate with actual-operation composition and author consumer;
not yet proved_locally or accepted. Root effect: potential closure of this
bounded cost edge only, not full classical supplier/runtime closure.

Named evidence/files changed: CachedMiddleCostProof.lean,
MiddleCostProofChecks.lean, this audit, input-manifest.json; new C176 only.
Reusable insight: sumEntries pays n additions, and collect pays 4*n in the
sum-of-eight-counters model; a per-counter factorial bound must be summed
across all eight counters before composing total costs.

Failure class: NONE for source authoring; compiler/consumer unexecuted by
scope, not silently passed. Salvage: all complete candidate fragments pending
parent gate; none discarded or promoted. Older attempts remain preserved.
Process-memory IDs: QBE-PM-LOW-TOKEN-CONTROL-PLANE,
QBE-PM-VERIFIER-SEMANTIC-LEVEL. Expected information gain: determine whether
the actual bounded middle producer meets its sealed total annotation without
cost promises, while keeping setup/outer-cache costs visible downstream.

Parallel admission/common-blind-spot audit: no delegated work here; parent
serializes heavy gates. Same-author checking is not independent review. Default
verified route is the unchanged original producer plus parent-verified primitive
cost API; no alternate representation/comparator or free callback is used.
Purification: NOT_STARTED. Exposition-Seal: NOT_STARTED. No publication or
clean transitive TCB assertion. Independent review and remaining same-run
integration are parent decisions after the bounded gate, not launched here.

Context digest: C156 governs; C150 unchanged; sole import C157 source/C159
own output; 35 C156 repository pins and all four definition pins rehashed with
zero mismatches. Parent reports contribution 3c986948891f3127f4eec84eaa6ccc8958741748
and main af585d9; this worker made no Git assertion. Freeze this four-file
packet and STOP before further proof scope.
