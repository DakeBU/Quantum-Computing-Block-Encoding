# C199: actual same-returned-run value and partial cost composition

## Objective, seal and current status

Sole public root: HermiteCachedPiecewiseStored.produceCachedStored_same_run,
with the EXACT final C156 signature, including both lets and the original 816
bound. The proof candidate and its exact-type/axiom consumer are complete but
UNCOMPILED by their author. No new result is called proved, accepted, published,
independently reviewed or scientific-root-complete.

The existing C156 StatementSeal governs. C150 executable bodies, all constants,
all public premises and the scientific target are unchanged. The full sealed
signatures, actual CachedStoredProducer/CachedRightSetup bodies, selected C189/
C193 proof sources, C157 primitive/right proof and original C22/C23 accounting
sources were read before authoring. All 35 C156 repository context pins and all
four C150 definition pins were rehashed, with zero mismatches. Exact provider
hashes were fixed before proof authoring; the manifest records them.

Direction fingerprint: C145_ACTUAL_C23_CACHE_CONSUMPTION_IN_C22_SAME_CHAIN.
Scientific root: SP-HERMITE-POLY-002, original normalized little-endian state.
The inherited exact-real circuit result is not reopened. Full finite-bit,
classical executable and native runtime/root gaps are not closed by this packet.

## Actual returned dataflow and own derivation

The original producer does not call old produceQData to obtain its output.
Its actual bind chain is:

```text
produceSourceCache k -> actual cache value
rightSetup n R delta -> actual setup value and setup.cost
middleFromCache k setup.midpoint cache -> actual middle vector
same actualBlocksQ kernel/left + charged rightEntry(setup,middle)
  -> collected RationalData
castData(that RationalData) -> collected RealData
ofTable(that RealData.tables,left,right) -> the returned StoredChain
```

No execution of actualBlocksQ.right or second source-coefficient producer is
inserted. The old producer remains only in an already established VALUE bridge.
The actual middle's extra factorial pass is included in the C189 bound, not
erased by this composition. Actual setup.cost remains a symbolic term exactly
as sealed; it is neither estimated away nor replaced by a free callback.

Write W=k+1 and D=assemblySize k delta. Let
P=passContainers n D=(n+1)*(2*D^2+D+1)+2*D.
The source-facing cost derivation is:

1. The actual C23 returned cache run costs <=416*W^2 (eight counters).
2. The actual middleFromCache run receives that returned cache and actual
   setup.midpoint; it costs <=400*W^2 for any signed rational inputs.
3. Nested table collects charge four stored-word ticks per scalar/row/core
   container. The two boundary collects add their own traffic. Their exact
   traffic is 4*P. The actual right-entry costs are RETAINED as a finite sum,
   not replaced by pure values. The full Fin D sum is <=11*D by the actual
   rightEntry_total_le theorem, with fullEquiv.symm selecting the exact carrier.
4. Thus actual produceCachedQData costs <=816*W^2 + actual setup.cost +
   11*D +4*P. The proof displays an exact cost equality for the actual outer
   three binds before using inequalities; all table/left/right collect costs
   occur in the literal final pass, on the returned setup/middle values.
5. Original castData_traffic charges 3 reads+2 writes per container, total5*P,
   for the actual returned rational object. Hence actual produceCachedData
   costs <=816*W^2 +actual setup.cost +11*D +9*P.
6. Existing ofTable_total_cost_le applies to that very RealData's tables and
   two boundaries, giving 20*D^2+30*D+5*n^2+7*n+31. Bind adds that actual cost.
7. The public theorem pairs the resulting inequality with the C193 refinement
   of precisely produceCachedStored k n R delta, under one let result. No cost
   from one run is paired with a different returned object or specification.

The generic internal pass lemma is an EXACT annotated-cost identity, not a
new executable producer or an assumption about scalar evaluation time. Its
kernel/left callbacks occur under the literal pure constructors already present
in C150, whose scalar evaluation is UNACCOUNTED. Every right Run's cost is kept
in the sum. The only bound on those entries is derived internally from the
actual 11-tick theorem, not supplied by a caller.

## Exact reused interfaces and selected providers

Direct imports are CachedChainValueProof (C193 own output),
CachedMiddleCostProof (C189 own output), CacheConsumerChecks (inherited C23
fresh-v3 cache), AccountedTraffic (inherited C22 cache). No failed C176/C182
module or reviewer-provided artifact is imported. C193 and C189 source reuse
does not erase their preserved earlier failures or constitute author recompilation.

The exact public interfaces used are:

```lean
produceCachedStored_refines : ∀ (k n : ℕ) (R delta : ℚ),
  denoteChain (produceCachedStored k n R delta).value = actualChain k n R delta

middleFromCache_total_le : ∀ (k : ℕ) (e : ℚ) (a : Vector ℚ (k+1)),
  StoredRectangularGivens.total (middleFromCache k e a).cost ≤ 400*(k+1)^2

rightEntry_total_le : ∀ (k n : ℕ) (R delta : ℚ) (s : RightSetup n R delta)
  (middle : Vector ℚ (2*k+2)) (z : FullIndex k delta),
  StoredRectangularGivens.total (rightEntry k n R delta s middle z).cost ≤ 11

HermiteChargedSourceCache.produceSourceCache_total_le (k : ℕ) :
  StoredRectangularGivens.total
    (HermiteChargedSourceCache.produceSourceCache k).cost ≤ 416*(k+1)^2

HermitePiecewiseStored.castData_traffic {n D : ℕ} (data : RationalData n D)
  (op : Op) : (castData data).cost op =
    passContainers n D*(3*tick .read op+2*tick .write op)

StoredMatrixProductChain.ofTable_total_cost_le {n D : ℕ}
  (tables : Vector (StoredCore D D) (n+1)) (left right : Vector ℝ D) :
  StoredRectangularGivens.total
    (StoredMatrixProductChain.ofTable tables left right).cost ≤
      20*D^2+30*D+5*n^2+7*n+31
```

Canonical collect_cost, Run.bind, Run.pure, Cost, Op, tick and total are
unchanged. collect_cost retains the actual finite sum of callback counters plus
n*(2*tick.read+2*tick.write); total expands all eight counters, in its original
order. Finset.sum_le_sum and Finset.sum_add_distrib handle the genuine finite
right-entry sum. The five new private helpers are linearity, literal pass
accounting, actual rational-data total, actual cast total, and actual real-data
total. They are theorem statements, not new primitives or desired-output stubs.

C23 .cache/fresh-v3/CacheConsumerChecks.olean and C22 .cache/AccountedTraffic.olean
are explicitly inherited C155/C156 environment artifacts. Their hashes were
checked, but this author did NOT freshly rebuild either provider or its complete
transitive dependency graph. The parent must verify actual --deps selection;
no clean whole-TCB claim is made. Supporting native_decide examples in the old
CacheConsumerChecks source were read, not executed or used as parametric proof
evidence in C199. No new native_decide/axiom/unsafe/sorry/admit appears here.

## Expanded binder and scope audit

Public k,n:Nat and R,delta:Rat are unchanged construction data. There is NO
logical premise in the final theorem. In particular no R>0, delta>0, nonzero,
cache correctness, cost budget, scalar-function purity, polynomial coefficient,
normalization or oracle assumption is added. EXCESS binders: none. R=0,
delta<=0, n=0, k=0 and T=0/1 are not removed from the generic theorem. The
already checked refinement, not the source-contraction theorem requiring R>0,
is used for the public value conjunct.

Private pass n,D and stored entry functions are typing/data parameters for an
exact literal ledger identity. The right Run sum remains explicit. Its bound
is proved for the actual setup/middle/fullEquiv inputs. No public or private
promise simply assumes the final desired cost, table correctness or arbitrary
callback budget. RationalData/RealData/Run are unchanged concrete structures,
not hidden correctness bundles. The result.value and result.cost projections
are from exactly the same original Run definition.

The operation model is ONLY the eight-counter partial scalar/word annotation.
Kernel scalar work, left scalar work AND captured actualBlocksQ construction/
setup remain UNACCOUNTED. Source capture does not certify eager/lazy elimination,
compiled sharing, no duplicated setup or physical one-evaluation. Natural
index/control arithmetic, casts, floor/ceil/clog, big-integer/Rat bitlength/GCD,
allocation, proof checking and evaluator/counter-metadata runtime remain outside
native accounting. The symbolic setup.cost is retained, not a new finite-bit
setup theorem. same_run is NOT a native one-evaluation theorem. No synthesis,
full classical polynomial runtime or scientific ROOT success follows.

## Source/Construction and Lean dependency graphs

Source NODEs: original returned C23 source cache; actual setup; signed cached
middle; original local kernels and left boundary; charged five-branch right
boundary; stored rational arrays; explicit casts; canonical ofTable assembly.
The returned-data path is preserved, including degree/radius/cuts and sum order.
Native costs of kernel/left/captured setup and finite-bit lowering remain
SOURCE_GAPs. They are not removed from the scientific source graph merely
because they are outside this ledger. No alternate quantum route is introduced.

Lean graph: C23 416 + C189 400 + C159 11 + exact actual collection identity ->
c199_qdata_total; C22 castData_traffic -> c199_cast_total; actual bind ->
c199_data_total; canonical ofTable bound + actual bind -> final cost conjunct;
C193 produceCachedStored_refines -> same result's value conjunct. Existing value
bridges carry setup/middle/cut correctness; this proof does not replace them
with hypotheses. The compressed quantum spine and Functor Hypergraph are
unchanged. Partial annotation completion is not whole source/runtime closure.

## Parent-only gate, failure preservation and uncertainty

Planned commands, cwd this packet, a NEW parent output directory, with exact
C193/C189/C159/C155 providers plus inherited C23 fresh-v3 and C22 caches:

```text
lean --deps CachedSameRunProof.lean
lean -o parent-output/CachedSameRunProof.olean CachedSameRunProof.lean
lean --deps SameRunProofChecks.lean
lean -o parent-output/SameRunProofChecks.olean SameRunProofChecks.lean
```

The consumer must resolve the fresh own output first. Inspect actual deps,
before/after hashes, exact type and actual printed axioms. Reject unexpected
axioms or sorryAx. Author-written checks are not independent review. No command
above was executed; no lake/compiler/provided-script/Git/network/subagent or
review packet was used. One read-only metadata command had an unmatched closing
parenthesis and was rejected by PowerShell before execution; it was corrected
and rerun. An initial additive audit patch had a malformed hunk and was rejected
without writing a file, then corrected. Neither event is a Lean gate or affects
the proof source. Historical C176/C182 and other failed attempts stay immutable.

Uncompiled obligations: finite-sum normalization of the exact pass total;
definitional matching of the actual pass aliases and outer bind cost identity;
matching cast/assembly instantiated cost atoms during omega. The C183 lesson is
respected: outer binds are exposed by an explicit equality while the pass cost
is kept as the same local object until its exact identity is rewritten. If a
local API fails, preserve this packet/diagnostics, repair only the proof and do
not change C150/C156, callback semantics, public assumptions or numeric bounds.

## Required substantive-worker handoff

Objective/frontier: exact same returned stored chain's refinement AND original
816 partial bound. Mathematical delta: one complete sealed conjunction proof
candidate, five internal composition helpers and author exact consumer. Root
effect: potential closure of this partial same-object integration edge only;
native/fullbit/scientific root gaps remain.

Named evidence/files: CachedSameRunProof.lean, SameRunProofChecks.lean,
audit.md and input-manifest.json, new C199 only. All predecessors, failures,
production/gates and scoring targets remain unchanged. Assumptions/conventions:
original signed coefficients and full boundary cases; no new public premise.
Reusable insight: compose actual returned value and counter fields through
bind; container traffic remains 4P+5P while actual right arithmetic is a separate
finite sum, and actual setup cannot be lost in the polynomial bookkeeping.

Failure class: NONE for authoring; no new compile or accepted result. Salvage:
complete candidate pending gate, no discarded fragments, prior failures remain
immutable. Process-memory IDs: QBE-PM-LOW-TOKEN-CONTROL-PLANE and
QBE-PM-VERIFIER-SEMANTIC-LEVEL. Expected information gain: test exact same-run
composition without a new scalar primitive or caller cost promise.

Parallel/common-blind-spot audit: bounded single worker; parent serializes heavy
gates; no subagents or independent-review exposure. Default verified route is
the unchanged producer and supplied checked interfaces; no comparator or new
representation is substituted. Purification/Exposition-Seal: NOT_STARTED. No
publication or clean transitive TCB assertion. Recommended next step: parent
fresh exact gate, then independent semantic review under separate authority.

Context digest: C156 exact final target; C150 unchanged; C189/C193/C159 and
inherited C23/C22 provider pins recorded. Parent reports contribution
c9138c25fa1e4ee73008910cb363b0e200dc771b and main af585d9 (no worker Git
assertion). Freeze this bounded packet and STOP.
