# C162 bounded actual setup-value proof freeze

Status: COMPLETE_PROOF_CANDIDATE / NOT_COMPILED / NOT_ACCEPTED. Only the exact
C156 public target `HermiteCachedPiecewiseStored.rightSetup_values` is addressed.
No middle, fullchain, setup-cost or other resource result is added. C150 bodies
and all C145/C155/C156/C157/C159 predecessor files remain unchanged.

## Statement and source intake

The complete C156 signature file was reread and the unchanged seal/body pins
inspected before authoring. Seal SHA256:
`e4be7acce67f288b8b70755da16c4f0c40bba589cd40454b45111547b2c5ee5a`;
signature SHA256:
`55c9becf19da0fde666a7c3d01e7fd72f6a027e9dd34db39bf2058b7860480b1`.
The full seal was already read in the preceding proof phase; this phase reuses
that unchanged authority rather than claiming a new seal or weakening it.

Before writing the proof, raw source was reread for: FiniteExp.poly/radius/
tailRadius/bounds/tailCutoff; finite-middle expMidpoint; kernel-producer
clippedValue; and gridStepQ plus strictCut/inclusiveCut. The entire unchanged
CachedRightSetup executable body and the author's exact C157 primitive proofs
were reread. No independent C161 review or C158/C160 report was accessed.

The new public type is exactly the sealed conjunction: four actual returned
cuts, all returned reciprocal-factorial tail entries, clipped scalar and
midpoint. Inputs are only n:Nat and R,delta:Rat. There is no positive-radius,
positive-delta, arbitrary-factorial correctness, desired-output or cost premise.
The author-authored SetupProofChecks ascribes this entire type and prints its
axioms from the parent's fresh proof output; it is not independent review.

## Own derivation, in actual dataflow order

Let T=tailCutoff delta, d=sourceDegree delta. Unfolding the actual returned
Run.value exposes the same step/cuts/factorials/tail/clipped/midpoint bindings.
The proof's local abbreviations name those returned subexpressions; they do
not define a replacement producer. The dependent vector transport uses the
existing definitionally equal degree, not a new dimension assumption.

The strict cut helper literally returns min(cap,ceil((s+R)/step)). The inclusive
helper preserves both branches of the quotient sign test and literally returns
min(cap, if quotient<0 then 0 else floor(quotient)+1). The already compiled
primitive gridStepRun_value identifies the actual step with the old gridStepQ.
Applying these two identities at -1,0,-T,T gives the four original cuts.
The negative-T scalar is obtained from the actual qSub value using 0-T=-T.

No division cancellation or positive-step hypothesis is used. Thus R=0 and
negative R retain the same literal Lean rational division and natural
floor/ceil behavior as the original formulas. These are generic literal-value
identities, not the positive-radius physical-grid threshold interpretation.

The tail table is a full actual collect over Fin(d+1). Each coefficient reads
the returned `HermiteChargedSourceCache.factorials d` table and divides one by
that entry. Existing factorials_value identifies each actual denominator with
i!. It is not a claim about arbitrary factorial arrays or an out-of-range
coefficient. The full index range, including d=0 in the internal helper, stays.

The clipped producer uses powQ_value to return tailRadius T/2, exactly the old
clippedValue delta. No true exponential primitive or real-number replacement
is introduced.

The midpoint guard is essential. Over rational scalars,
`-1 <= -(T:Rat)` iff `T<=1`. For T=0 and T=1 the literal bounds is therefore
(0,tailRadius T), and its midpoint is exactly the already returned clipped
scalar. The proof does not silently send either case to the active polynomial.

For T>1, the executable midpoint sums the actual stored signed terms
(-1)^i/i!, with powers supplied by powQ and denominators by the same generated
factorial table. The Fin-to-range sum identity identifies this with literal
FiniteExp.poly (-1) d. Separately, the literal bounds average is
((poly-radius)+(poly+radius))/2=poly. Only these two radius terms cancel in the
average; no source error, tolerance or precision budget is discarded. Combining
the two statements yields exactly expMidpoint delta on both branches.

The final proof changes the goal only to the actual value normal form, then
supplies each of the seven conjuncts from these private helpers. No callback,
alternate state or rerun of an old producer is inserted.

## Binder/definition audit and scientific boundary

Public n,R,delta are TYPING/original construction inputs. All signed/zero cases
remain in their carriers. Private cap,step,s,T,d and finite indices are
internal carrier data; helper conclusions are proved directly from literal
definitions and actual generated tables. No private helper accepts a table-
correctness/cost/desired-output hypothesis. EXCESS binders: none proposed.

RightSetup remains the sealed data-only record: four natural cuts, one tail
vector, clipped and midpoint scalars. Run is data plus counters. Their exact
stored values, not a proof bundle with assumed properties, are what the public
conjunction describes. New files contain theorem proofs and a type consumer
only, not new executable definitions, choice objects, axioms or stubs.

This is a value proof, not a runtime result. Actual rightSetup.cost stays in
the future partial ledger. Kernel/left scalar evaluation AND captured
actualBlocksQ construction/setup remain UNACCOUNTED. Source-level capture
does not prove compiled eager/lazy elimination, absence of repeated setup,
physical one-evaluation or sharing. Native integers, conversions, ceil/floor/
clog, Rat bitlength/GCD, allocation/evaluator/counter evaluation and complete
classical extraction remain open. No finite-bit, synthesis or ROOT claim.

The original scientific target SP-HERMITE-POLY-002, normalized little-endian
state, degree, physical grid and source function are unchanged. No new quantum
representation, register/basis/phase convention, ancilla, normalizer or error
promise is introduced. Their downstream proofs and root gates are not replaced
by this initialization identity.

## Inputs, gate plan and precise uncertainties

The only module import is CachedPrimitivesProof, using the parent-owned C159
own-output binary bound by
`77547431cc9e4759adcd8c25f6a3e57622da492bdb31ac36f2061ab06e50d473`.
The C157 raw proof text is reused exactly. C159's reported successful focused
compile/consumer and ordinary axiom results are parent evidence, not a new
compiler run by this author. Source/raw provider pins remain those in C156;
all 35 repository source-context pins were mechanically rechecked with zero
mismatches before this freeze.

Parent-only planned commands, with cwd=this new packet and a new output scope:

```text
lean --deps CachedSetupProof.lean
lean -o parent-output/CachedSetupProof.olean CachedSetupProof.lean
lean --deps SetupProofChecks.lean
lean -o parent-output/SetupProofChecks.olean SetupProofChecks.lean
```

None was executed. Reuse the exact approved C159/C155 inherited environment;
resolve CachedPrimitivesProof from C159, CachedRightSetup/CachedMiddle from C155,
and place the new own output first for SetupProofChecks. Record actual resolved
dependencies and hashes before/after; never accept a stale theorem provider.
Preserve diagnostics and inspect the actual rightSetup_values axiom expansion.

Uncompiled proof risks are explicit: simplification of the monadic sum/table
value, the existing Fin.sum_univ_eq_sum_range orientation, and definitional
normalization of rightSetup's dependent tail transport in `change`. If the
parent encounters an elaboration issue, the precise repair is to expose the
same actual Run.value normal form/transport with proof-only rewrites or adjust
the local simp proof. Do not alter executable definitions, add a hypothesis,
weaken the full-carrier target or change the midpoint guard. No local API or
semantic counterexample has been observed, because no compiler was run.

## Full substantive-worker handoff

Objective/frontier: exact actual classical setup supplier value bridge required
by the same-chain cached C22 integration. Delta: one complete sealed public
proof candidate, eight private literal/table/midpoint lemmas, own derivation
and exact-type/axiom consumer. No accepted proof delta before the parent gate.

Named evidence: CachedSetupProof.lean, SetupProofChecks.lean, this audit and
input-manifest.json. No finite numerical tests were run. All proof work is
symbolic and ordinary; no compiler/lake/scripts/Git/network/subagents used.

Files changed: only this new C162 packet. Predecessors and production remain
unchanged. Reusable insight: midpoint dispatch and average cancellation must
be proved separately, and the literal cut identities need no artificial
positive-step premise. Actual generated factorial values supply all table facts.

Failure class: NONE for authoring. Salvage: preserve this full candidate and all
future failure output before proof-only repair. No historic failure/artifact
was discarded. Uncompiled uncertainty is not mathematical refutation.

Process-memory IDs: QBE-PM-LOW-TOKEN-CONTROL-PLANE and
QBE-PM-VERIFIER-SEMANTIC-LEVEL from the already-read repository skill/protocol
pack. Parent-authorized distinct setup uncertainty; no child workers. No
independent review exposure or self-review substitution. Common-blind-spot
audit and later independent value/cost/source review remain pending.

Default verified route: unchanged inherited baseline plus parent-compiled
primitive prerequisite, not this uncompiled setup candidate. Purification and
Exposition Seal: NOT_STARTED. Source construction remains finite rational
supplier -> actual signed middle -> five masks -> physical chain -> normalized
target. C162 supplies only a proposed classical setup edge; no checked new Lean
edge, fullchain implication, physical circuit arrow or complete ROOT is asserted.

Recommended next action: parent serialized exact source and fresh-output
consumer/axiom gate, then independent review as appropriate. Stop after this
bounded setup freeze. Middle/fullchain/cost work is intentionally untouched.
