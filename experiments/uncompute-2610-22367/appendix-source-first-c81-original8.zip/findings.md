# Findings and bounded handoff

Evidence: SOURCE_ONLY, independent source-first extraction; no Lean or author implementation inspected. Anchors refer to arXiv:2610.22367v1.

1. A.3's 590-step result is explicitly external to the local proof. Wuille [36] is a dependency and the appendix does not reproduce its exact argument. A faithful integration must check the half-delta, >=0 test, initial value, signed recurrence, input bounds and active-step count against that external result. Primality of 2^256-2^32-977 is separately used without proof. Status: SOURCE_GAP / external verification pending, not a refutation.
2. A.2 proves scale preservation and inverse correctness conditional on termination and gcd(p,w)=1. It does not by itself establish termination for arbitrary odd p. A.3 supplies a special-modulus bound, not a premise for the general decoder.
3. The literal (A2) even case would act at g=0; source prose overrides it with freezing. A literal formal transition must include that override, and active t must not increment under identity steps. This is a source interpretation supported explicitly by the paragraph after (A2), not an allegation of error.
4. A.4 and A.6 require reachable active transitions. A.4(3) fails if silently extended to frozen identity steps with g'=0 and b=0. A.5 is what excludes F=0 from the negative-counter domain. v_2(0)=infinity must not become a finite j by default.
5. Negative f,g,F,G,q are allowed. Bit extraction is a residue operation; no absolute-value substitution, truncated unsigned arithmetic, rational inverse, or positivity assumption is justified. Exact integer halving follows from parity.
6. The A.6 first expression depends on G',q; the second on fixed p,f',q. Both local routes need the window argument, with determinant/parity supplying their bridge. A.7's 2j is an information bound at given j, not a gate bound, not a cost-free depth computation and not a claim about a contiguous low-bit slice of the entire state.
7. A.8 is independent of the special prime; a specialized formula reading f' instead of G' must separately use p mod4 and the determinant. SI II.1's depth-two f'/q formula and A14 are different interfaces, not a contradiction.
8. No confirmed source error was found. Source equations and proofs were visually checked on all three Appendix pages and cross-checked against PDF text. No computation/simulation, Lean compilation, network lookup, or implementation review was performed.

Objective/frontier: freeze the complete Appendix A source mathematics and topology before implementation can anchor it.

Mathematical delta: full induction derivations for determinant/parity, scale, gcd, window and decoder; complete separation of the external worst-case bound from exact local recovery; explicit guarded coverage of all active branch decisions.

Source/Lean expansion: source nodes are in source-graph.json; no Lean nodes or compilation evidence exist in this packet. All exact source hypotheses are retained. Other finite-bit/coherent/resource obligations stay outside this closure.

Failure class: NONE for extraction; external bound and primality admission remain unverified dependencies. No route is retired as REFUTED or SOURCE_INVALID. Initial missing pdftotext utility was an ENV observation, bypassed by PDF text extraction and rendered-page inspection; it has no mathematical consequence.

Salvage: no failed route; source-derived invariant proofs remain candidate reusable mathematics, not admitted Lean library nodes.

Process-memory consulted: none (task imposed source-only anti-anchoring). Direction fingerprint: c81/appendix-A/raw-source/integer-invariant-topology. Expected information gain: preserve an implementation-independent derivation and expose external versus local tails.

Parallel/common-blind-spot status: this worker spawned no subagents; no cross-route comparison or independent approval claimed. Default verified implementation route: none. Purification and Exposition Seal: not applicable/pending future integration. Source topology review: pending a distinct reviewer.

Recommended next action: retain this immutable source-only packet; only after separate authorization compare it with a decoder's independent implementation reconstruction. Separately verify [36] plus primality and the exact recurrence bridge. Do not promote this packet as source-fidelity approval or root closure.
