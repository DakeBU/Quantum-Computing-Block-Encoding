# Appendix A source-first mathematical freeze

Evidence class: SOURCE_ONLY, independently derived from arXiv:2610.22367v1, Appendix A (PDF pages 44-46, printed pages 27-29). This is neither a Lean review nor source-fidelity approval, and is not MAIN, ROOT, PROOF_SEALED, SOURCE_TOPOLOGY_REVIEWED, or PURIFIED. No implementation was read. Formula anchors below always mean this pinned version. The paper's reference [16] credits A. Gu, *uncompute* (2026); this credit is retained without consulting its implementation.

## 1. Contract and definitions

The source assumes an odd positive integer p and 0 <= w < p. States are integer tuples (z,f,g,F,G), where F=f_v and G=g_v. Initially

    (z,f,g,F,G)=(0,p,w,0,1).                         (A1)

A reachable state is obtained by finitely many prescribed transitions from this initial state, including identity transitions once g=0. A transition with incoming g != 0 is active. The recurrence displayed as (A2) is applied only while active; the subsequent prose freezes the walk at its first g=0. Without this prose the displayed even case would keep updating zero-g states. Frozen transitions do not increment the active-step count t.

For an active state define b=1 if g is odd, b=0 otherwise, and s=1 if z>=0 and g is odd. Then

    s=1: (z',f',g',F',G')=(-z,g,(g-f)/2,2G,G-F),
    s=0: (z',f',g',F',G')=(z+1,f,(g+bf)/2,2F,G+bF). (A2)

The latter combines the source's odd-negative-counter and even cases. These are literal definitions, not chosen objects. Reachable f is odd; the numerator g+bf is even and the swap numerator g-f is even, so every displayed division is exact integer division, including for negative numerators. There is no rounding convention to add.

For any integer u and k>=0, u[k] is bit k of the nonnegative residue u mod 2^(k+1). This fixes negative inputs by infinite two's-complement digits, not the binary digits of |u|. bit_k(u)=u[k]. v_2(u) is the 2-adic valuation for nonzero u, with v_2(0)=infinity. Thus divisibility of zero is legitimate but the odd-part quotient u/2^v_2(u) is not defined at zero. The source introduces j and q only when F != 0. For nonzero F, j=v_2(F)>=0 and F=2^j q with odd signed integer q. No positivity of q is assumed. Modular inverses modulo 2^j below mean inverse residue classes of odd integers, represented through nonnegative residues as needed.

Binder audit: p,w, odd(p), p>0, 0<=w<p are SOURCE; integer carriers and nonnegative step/bit indices are TYPING. Being a reachable state or a specified active transition is the source's domain restriction, not an arbitrary-state claim. Coprimality is SOURCE only for the final-inverse part of A.2. The special value of p is SOURCE only for A.3. Determinant, parity, valuation, window, gcd preservation, and existence of the relevant inverse residues are dependency conclusions, not extra assumptions to add to the eventual public anchors. No Lean signature is asserted or sealed here.

## 2. Lemma A.1: determinant and parity

For every reachable state,

    fG-gF=p; f and G are odd; F is even.              (A3)

At initialization fG-gF=p*1-w*0=p, and parity follows from odd p. On a nonswap,

    f(G+bF) - ((g+bf)/2)(2F) = fG-gF.

On a swap,

    g(G-F) - ((g-f)/2)(2G) = fG-gF.                  (A4)

The cancellations use exact division already justified by the case predicates and odd f. Nonswap keeps f odd, doubles F, and adds even bF to odd G. Swap makes f'=g odd, F'=2G even, and G'=G-F odd. Frozen identity transitions preserve everything. This proves the simultaneous invariant by induction. It covers F=0 and negative coefficients; neither determinant positivity nor oddness means the coefficients themselves are positive.

## 3. Proposition A.2: scale and conditional terminal inverse

After t active steps,

    Fw == 2^t f (mod p), Gw == 2^t g (mod p).        (A5)

Initially 0 == p and w == w modulo p. For a nonswap the first updated congruence follows from (2F)w == 2^(t+1)f. The second is (G+bF)w == 2^t(g+bf)=2^(t+1)g'. For a swap, (2G)w == 2^(t+1)g=2^(t+1)f' and (G-F)w == 2^t(g-f)=2^(t+1)g'. These give t+1. A frozen step leaves both t and the state unchanged. Thus the scale is tied to active time, not an external fixed circuit schedule.

Every active step preserves gcd(|f|,|g|). For nonswap let h=(g+bf)/2. Since f is odd, any divisor of f is odd. Common divisors of f,g divide h because they divide 2h and are coprime to 2; conversely a common divisor of f,h divides g=2h-bf. For swap apply the same argument to the odd retained operand g and h=(g-f)/2, using f=g-2h. This is a dependency derivation, not an extra gcd-preservation premise.

If gcd(p,w)=1 and the walk reaches g=0, gcd invariance gives |f|=1, hence f=+/-1. Equation (A3) then says fG=p and so G=fp. Multiplying the first relation in (A5) by f gives fFw == 2^t because f^2=1. Since p is odd, 2^t has an inverse modulo p; since gcd(p,w)=1, w is a unit modulo p. Therefore

    w^(-1) == fF 2^(-t) (mod p).                   (A6)

This is conditional terminal correctness, not an internally proved termination theorem for all odd p. In the degenerate allowed p=1,w=0 case all congruences are modulo 1 and the walk is initially frozen; an inverse symbol must be read with the chosen unit-ring convention, not as an ordinary rational inverse of zero. The substantive nonzero-input inversion application is A.3's prime modulus.

## 4. Proposition A.3: special-prime external bound

For p=2^256-2^32-977 the source states that every 0<=w<p reaches g=0 within 590 active steps. For w=0, g is already zero and the walk starts frozen. For 0<w<p, the proof invokes P. Wuille [36], *safegcd-bounds: bounds on divsteps iterations in safegcd* (2021), described in the bibliography as exact hull-threshold computation for divstep iteration bounds. The source also uses primality of this p to obtain gcd(p,w)=1 and then applies A.2 for (A6).

The appendix does not reproduce Wuille's bound, establish its exact counter/initialization convention, or prove primality. These are explicit external obligations, not locally established theorems in this packet. In particular an eventual import must match z=0, the sign test z>=0, the swap counter update -z, exact signed arithmetic, input interval, stopping predicate, and the count of active rather than scheduled steps. The source reports this match; it is not independently verified here. No network or external source was consulted.

A.3 is not an ancestor of A.4, A.5, A.6, A.7, or A.8. Recovering one reachable active branch is independent of ever proving a universal stopping bound. Conversely, decoding does not prove the 590-step guarantee.

## 5. Lemma A.4: visible decisions and active-step restriction

For every reachable active transition,

    s=1 iff F' == 2 (mod 4) iff v_2(F')=1.          (A7)

A swap has F'=2G with odd G. A nonswap has F'=2F divisible by 4. These cases are exclusive and exhaustive, including F'=0 on a nonswap (valuation infinity, not one). A swap also implies b=1.

If s=0 and z'>=1, then z=z'-1>=0. Odd incoming g would have triggered the swap, hence g was even and b=0. If g'=0 on an active step then b=1: it is automatic on swap, whereas nonswap with b=0 would give g'=g/2=0 and therefore g=0, contradicting active. The latter reasoning is invalid on a frozen transition; this restriction must not be omitted.

After swap detection, terminal detection, and the nonnegative-incoming-counter test, the remaining branches are nonswaps entered with z<0 (equivalently s=0,z'<=0), apart from their terminal instances. The source calls their undecided nonterminal decisions ambiguous. A.6 itself covers every active negative-counter nonswap, including a terminal one if present. These nested domains must not be conflated.

An excursion is a swap followed by a run of ambiguous/negative-counter nonswaps. The swap counts as depth 1; j on an updated nonzero coefficient is v_2(F'). The window is the low j bits of G q^(-1), namely Gq^(-1) mod 2^j. This is not the unbounded integer product with a rational reciprocal.

## 6. Lemma A.5: the stronger window invariant

For every reachable state:

    z>=0 implies 2^(z+1) divides F;
    z<0 implies F!=0 and, for j=v_2(F),q=F/2^j,
      there exists integer c, 0<=c<2^j,
      G == q c (mod 2^(j-z)).                      (A8)

The modulus is stronger than merely 2^j: because z<0, the extra -z bits above position j-1 vanish after multiplying by q's inverse. Existence and the bound on c are proved; c is not a free input assumption. It is uniquely represented in [0,2^j) once the modular relation holds, since the larger modulus is >=2^j and q is odd. The source only needs existence.

Induction has the following complete cases. Initial z=0,F=0 satisfies 2|0; the negative branch is vacuous. Frozen transitions are identity. A nonswap starting z>=0 has z'=z+1,F'=2F, so 2^(z'+1)=2^(z+2) divides F'. A swap starting z=D>=0 has z'=-D and F'=2G with j'=1,q'=G. The incoming positive-counter invariant gives 2^(D+1)|F, hence

    G'=G-F == G (mod 2^(D+1)).                     (A9)

If D>0, choose c'=1 in [0,2) and the required modulus is 2^(1+D). If D=0, z'=0 and the positive-counter requirement is just 2|F'. This explicitly separates the zero-counter swap.

For nonswap starting z<0, write F=2^j q with the supplied witness c. Then F'=2^(j+1)q is nonzero, v_2(F')=j+1, z'=z+1 and

    G'=G+bF == q(c+b2^j) (mod 2^(j-z)),
    0<=c+b2^j<2^(j+1).                             (A10)

The exponent after the step is (j+1)-z'=j-z, so the modulus is unchanged. If z'<0 this gives the negative invariant with c'=c+b2^j; if z'=0 only 2|F' is required. Every negative state has a nonzero F because it first arises from a D>0 swap, and later negative nonswaps double a nonzero integer. This is already contained in the induction, not an extra promise.

## 7. Theorem A.6: exact branch decoding

Let the updated state be that of a reachable active negative-counter nonswap, with incoming z<0. Put j=v_2(F') and q=F'/2^j. From A.5 incoming F!=0; from A.1 it is even. Since F'=2F, j>=2, incoming valuation is j-1, and q is the same odd part before and after the step.

A.5 supplies 0<=c<2^(j-1) and G==qc modulo 2^((j-1)-z). Since z<=-1, (j-1)-z>=j, so reduce to modulus 2^j. The update gives

    G' == q(c+b2^(j-1)) (mod 2^j).                 (A12)

The representative c+b2^(j-1) lies in [0,2^j), and its bit j-1 is exactly b. Odd q is invertible modulo 2^j. Thus

    b = bit_(j-1)(G' q^(-1) mod 2^j)
      = bit_(j-1)(p (f'q)^(-1) mod 2^j).            (A11)

For the second equality, reduce f'G'-g'F'=p modulo 2^j. Since 2^j|F' and f' is odd, G'==p(f')^(-1) modulo 2^j. Multiply by q^(-1); the product of the two inverse classes is (f'q)^(-1). This route uses the determinant and parity but no termination, no primality, and no assumption gcd(p,w)=1. It is valid for signed q and signed f'.

The two expressions in (A11) are alternative evaluation interfaces connected by a proved determinant bridge, not two unrelated hypotheses. The first reads G' and q; the second reads the known p, f', and q. For fixed p and depth j, residues f' mod 2^j and q mod 2^j suffice.

## 8. Accumulated history and Corollary A.7

Immediately after a swap, the depth-1 window is 1: F'=2G, q'=G, and G'=G-F is congruent to G modulo 2 because F is even. For a swap at D>0, (A9) supplies the stronger modulus that protects later bits during the excursion. At each subsequent negative-counter nonswap, (A10)/(A12) appends the current b at the next higher bit without carry into or from the lower witness. Induction gives at depth j

    window = 1 + sum_(k=1)^(j-1) b_k 2^k,           (A13)

where b_k is the kth negative-counter nonswap after the initiating swap. This is an equality of the chosen j-bit residue, not an equality G/q as integers. It is only asserted along that excursion; do not continue appending after leaving the negative-counter run or after freezing.

Corollary A.7: for fixed odd p and given depth j, b depends on at most 2j bits of the updated state, via two j-bit residues f' mod 2^j and q mod 2^j. This is an information-dependence bound with j supplied, not a theorem that finding j is free, that all needed bits are the lowest 2j physical register bits, or that the decoder has O(j) gates. Since both residues are odd, their bit zero is fixed and at most 2(j-1) independent variable bits remain; this refinement is stated in SI II.1, not a replacement for A.7. The bits of q are F'[j+i], so they require positions through 2j-1 of F', with the signed-bit convention above.

## 9. Corollary A.8: depth-two XOR

At j=2 the first expression of (A11) gives b=bit_1(G' q^(-1) mod 4), q=F'/4 odd. Every odd q has q^2==1 mod4, hence q^(-1)==q. Write odd u==1+2u[1], v==1+2v[1] modulo4. Their product is 1+2(u[1]+v[1]) modulo4, whose bit one is u[1] XOR v[1]. Using odd G' from A.1 and q[1]=F'[3] (exact signed division by four) yields

    b=G'[1] XOR F'[3].                             (A14)

This proof does not require specializing p to the secp256k1 prime; it works on the stated reachable active negative-counter nonswap domain for every allowed odd p. It also does not prove a Toffoli count or a gate-level phase/cleanup theorem.

## 10. Complete recovery and implementation boundary

For an arbitrary reachable active step, one can recover s by (A7). For b, use swap=>1; otherwise terminal g'=0=>1; otherwise z'>=1=>0; otherwise apply A.6 (the incoming counter is z'-1<0). These guarded alternatives cover all active steps. A full all-active recovery theorem needs the partition and all branch lemmas together, not an OR pretending that one branch formula handles all states. Frozen identity transitions carry no active branch decision to recover; recovering the time of freezing requires separate data as SI II.1 explains.

The appendix works over unbounded exact integers with modular observations. It does not establish bounded signed-register overflow safety, counter width, extraction of a variable valuation in a circuit, truth-table synthesis complexity, clean ancilla or garbage restoration, measurement-based uncomputation phases, a coherent permutation/unitary extension off reachable states, fault tolerance, scheduling with 533 steps, supported stopping windows, stack-overflow bounds, or physical cost. SI II.1 describes those additional mechanisms but they are not consequences of (A11) alone. A source-first future formalization must keep separate (a) exact arithmetic decoder, (b) imported termination evidence and its convention bridge, (c) finite-width representation/overflow proof, and (d) reversible circuit/phase/resource realization.

No mathematical falsehood is concluded in this freeze. External-bound/primality obligations are unverified dependencies, not negative mathematics. A distinct raw-source topology review is still required before any topology-review acceptance.
