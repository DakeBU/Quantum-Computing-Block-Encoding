# C244 Gaussian error-reference SOURCE-FIRST freeze

Status: source audit and proposed acceptance interface ONLY. No new Lean proof,
numeric scan, compiler result, error bound or circuit acceptance. Original
snapshot is uncompute-2610-22367-64b5a13, parent-pinned HEAD
64b5a13aa249f1360846657392e6c66817b26d0f. All constants stay literal and fixed.

## 1. The actual target is an operational expression

Write N=2^39, S=2^32, M=2^35. Inputs are X,k in [0,N), signed
xs=decode39(X) in [-M,M). The exact source reference I_E(xs), in an as-yet
fully bound Python/runtime/libm environment E, executes in this order:

    x = xs / 4294967296.0
    v = math.exp(-(x * x)) * 4294967296.0
    f = math.floor(v)
    I_E(xs) = f+1 if v-f >= 0.5 else f

This is NOT Python round (ties-to-even), not NumPy exp, and not automatically
round(S*Real.exp(-(xs/S)^2)). The grader is authoritative; reference.py agrees
on these expressions. Python integer k addition/masking uses exact integers.
Source hashes pin code, NOT a particular CPython/C-math binary or rounding mode.
The reference comment that C exp is faithful to well under 2 binary64 ULP is
an assertion, not an implementation identification or uniform error proof.

Let C_N(z) be r if r<=N/2, otherwise r-N, where r=z mod N. This convention
has interval (-N/2,N/2], including the positive half-modulus tie. The target is

    X_out=X AND |C_N(k_out - ((k+I_E(xs)) mod N))| <= 429.

It is pointwise and inclusive, not a mean/RMS or allowed-failure criterion.
The grader draws 72,192 patterns and skips out-of-domain ones; sampled shots
are not an exhaustive certificate. expected_phase=False also does not certify
coherent phases, measurement cleanup or arbitrary-superposition behavior.

## 2. Fixed integer side and exact negative partners

Use the independent C213 packed-word/signed-row model G(v): fold
v=xs for xs>=0, v=-xs-1 otherwise; j=v div 2^25, D=v mod 2^25;
G(v)=128*A_j-P_j(D), with the ACTUAL six signed mid rows, modular stored
slope and nine individually truncated/bias-bearing final rows. No full-product
floor replacement. Packed word zero suffix decodes to A=S_j=C_j=0; it is NOT
an extrapolated E=0 correction. The following literal seam rows were reread:

| j | A | initial slope | E array | packed word |
| --- | ---: | ---: | ---: | --- |
| 0 | 33554431 | 20 | 523776 | 0x7fffffdff00005 |
| 100 | 18225422 | 1779892 | 228608 | 0x458643bbeeca2d |
| 454 | 115 | 52 | 262144 | 0x1cc000000d |
| 455 | 106 | 0 | 262144 | 0x1a80000000 |
| 513 | 6 | 0 | 262144 | 0x180000000 |
| 514..1023 | 0 | 0 | not extended | zero words |

The C229 signature read, without its diagnostics or a proof implementation:

    theorem localIncrement_block128_constancy :
      ∀ (j D : Nat), j < 1024 → D < 2^25 →
        localIncrement j D = localIncrement j (128*(D/128))

Parent reports C240 supplies that exact integer dependency. This packet does
not recheck its proof or convert it to an error theorem. Source explanation:
U=D>>14 is constant on aligned 128-code blocks. Each final truncated term
has period divisible by 128; the minimum shift+drop exponent is 7. Digit
coefficients and active biases are then constant too, including modular slope
wrap. This is construction analysis, NOT a newly accepted Lean proof.

For b<2^28 put a=128*b, c_b=G(a). Its two actual signed-input sets are

    xs in [a,a+127]              (positive),
    xs in [-a-128,-a-1]         (negative).

Their magnitudes cover ALL integer q in [a,a+128]. In particular the final
endpoint q=M means xs=-M, which is valid; do NOT call ideal_gauss(+M), whose
assertion rejects it. Define J_E(q)=I_E(-q), 0<=q<=M. The positive branch also
uses J_E only after discharging operational evenness I_E(q)=I_E(-q) for q<M.
IEEE binary64 sign-symmetric division and squaring establish that bridge in
the proposed machine model, including zero; the original sparse shape tests
do not establish it universally. No assumption G(v)=G(v+1) across a block or
segment seam is made.

Arbitrary k cancels EXACTLY in the centered residue once the model implements
(k+G(v)) mod N. It needs no k enumeration. This algebra is separate from the
unproved circuit-to-model map, X preservation and phase/ancilla cleanup.

## 3. The sufficient endpoint/envelope interface

The exact per-block target (after evenness) is

    forall integer q in [a,a+128], |C_N(c_b-J_E(q))| <= 429.

If a genuine dependency proves J_E nonincreasing, it suffices to check

    J_E(a)-429 <= c_b <= J_E(a+128)+429.             [ENDPOINT]

This implies the ordinary signed difference is within the band, hence the
centered difference is too. Endpoint failure alone is a centered counterexample
only after evaluating its actual centered residue (or proving no half-modulus
wrap); do not replace the source test by an unproved raw-error equivalence.

More generally supply integer L_b,U_b with

    forall q in [a,a+128], L_b <= J_E(q) <= U_b.

Then U_b-429 <= c_b <= L_b+429 is sufficient. No monotonicity of libm is
needed for this envelope route. An inconclusive enclosure is UNKNOWN, not a
counterexample. A generic envelope lemma may accept such a supplier internally;
the ACTUAL error root must discharge it for the fixed E/table, not expose it
as a convenient new public premise.

A no-wrap bridge is cheap but still a dependency: disjoint Booth selectors
give |P|<=9*(D+64)<2^29; 0<=128*A<2^32 from the 25-bit literal field. Together
with 0<=I_E<=2^32 this implies |G-I_E|<2^33<N/2, making centered and raw errors
equal. The I_E range is itself an operational/libm obligation, not justified
by sparse anchors. The bound on P uses each row, not floor(F*D/2^21).

## 4. What a rigorous floating-point supplier would owe

The original source supplies the expression and constants, NOT the following
uniform machine/transcendental bridge. Two honest possible suppliers are:

* Operational monotonic route: bind the actual interpreter, math extension,
  loaded exp implementation/dispatch, hardware mode and floating environment;
  prove the actual I_E even and nonincreasing on all required integer codes.
  Integer-to-double conversion is exact up to M; division by S is exact under
  binary64. Correctly rounded binary64 multiplication is monotone on nonnegative
  inputs, but a platform exp routine must have its own monotonicity proof. A
  small uniform ULP error does NOT imply monotonicity at near-flat points.
* Operational enclosure route: for every rounded square t actually possible
  in each block, supply a certified bound on the SELECTED libm result around
  real exp(-t). This need not assert monotonic libm. With RN64 square values
  t_a,t_z at q=a,z=a+128 and a uniform absolute exp-error eta_b on [t_a,t_z],
  real monotonicity yields an exp-result interval
  [exp(-t_z)-eta_b, exp(-t_a)+eta_b]. Multiply outward by S and apply exact
  monotone H(v)=floor(v+1/2) to outward endpoints to obtain L_b,U_b. Negative
  lower enclosures may be clipped to zero only with a proved positive-result
  property. Directed rational endpoints handle half-ties conservatively; never
  round a numerical enclosure inward. Verified rational exponential bounds
  supply the REAL exp values but do not alone certify the platform libm eta_b.

Both routes must justify binary64 RN-even and no extended/reassociated
intermediates, exact negation/sign handling, finite positive exp results,
absence of exceptional/flush/overflow effects, and exact power-of-two scaling.
Under that model x lies in [-8,8], its nonzero square is >=2^-64, square<=64,
and exp(-64)>0 is normal with huge overflow/underflow margin; these magnitude
facts remove range hazards only AFTER machine/libm behavior is bound. The
floor and v-f comparison then implement mathematical half-away for v>=0;
the source comment is not a floating-point library certificate. Half-tie
separation is unnecessary for safe enclosures, but necessary if claiming one
unique rounded integer from an interval that otherwise straddles a half-tie.

Real exp monotonicity and range/calculus are ordinary mathematical dependencies.
NumPy exp equality to math.exp, libm correct rounding, universal monotonicity,
and a chosen ULP limit are NOT supplied by the original source. No Mathlib
float-to-selected-libm bridge was retrieved or assumed in this packet.

## 5. Why the generator is not already this certificate

gen_constants.py exact_scan (394-446) derives gbits=7 for the fixed knobs,
evaluates integer P on aligned starts, then uses adjacent boundary values from
np.exp(-yy*yy)*S, NOT operational half-away I_E. The inclusive right boundary
is conservative for real monotone g and would naturally cover negative partner
endpoints, but that must be checked with the SAME emitted c_b. Its non-modular
F table also needs final 0<=F<2^21 and packing equivalence to the actual packed
words; intermediate modular wrap must not be assumed absent. NumPy int64
matrix sums need proved nonoverflow, not a declaration that they are exact.
The nine terms are bounded by about 2^29 in total, while middle terms admit
small bounds from signed 11-bit correction; a verifier should use unbounded
integers, or discharge every typed intermediate bound explicitly.

search (482-517) calls build_tables again and selects/recenters A0n using
np.round (ties-to-even), then rebuilds words. Executing that pipeline would
refit/recenter/research, violating this fixed-data task. We do NOT execute it.
The literal table must instead be read and evaluated as-is.

No numeric README supremum is taken as evidence. Even an independently known
unrounded real-error E0 plus a fold Lipschitz charge L and rounding yields only
|integer error|<=E0+L+1/2 (+a separately proved operational-reference charge).
To infer radius 429 by integrality, this total must be STRICTLY below 430.
Thus the generator's surrogate gate 428.98 plus the advertised 0.858 fold
charge plus 1/2 does not alone imply the negative-input acceptance. This is a
missing implication, NOT a counterexample to the fixed table. Checking its
operational partner endpoints avoids this ledger substitution entirely.

A physically different real target H(S*Real.exp(-(xs/S)^2)) may be worthwhile,
but is a separately sealed target. Replacing E's exp by it is not acceptance
of the operational grader. Likewise scalar additive error is not SP/BE error,
rotation-synthesis accuracy, normalization or coherent cleanup.

## 6. Fixed-data route, actual scale and next bounded action

Recommended route: preserve C213/C229 exact integer supplier, first pin E and
decide whether a proved operational envelope provider is available. In parallel
only after parent seal, a small independent scalar-math.exp diagnostic can
screen fixed literals, never accept uniform error. NEXT_TEST_CONTRACT.json
freezes such a bounded, non-refitting preflight. This packet authorizes no run.
The smallest suggested first discriminator is just two fixed blocks: b=0 and
b=2^28-1, with actual signed shots xs=0,-128,M-128,-M (four reference calls).
Compare their literal-model centered errors at k=0 and N-1; this exercises the
origin bias and included negative endpoint without any global libm theorem.
Passing it is ONLY a four-point diagnostic, not a block or uniform acceptance.
If no operational supplier is available, mark the endpoint uniform route
ENV/API_BLOCKED and retain a finite diagnostic; do not call math impossible.

With the envelope/monotonicity bridge discharged, a streaming complete pass
needs 455*2^18=119,275,520 quadratic block values. Its shared boundary grid has
119,275,521 magnitudes. Checking all 59 literal constant segments separately
and the single zero suffix adds 60 distinct right boundaries: total
119,275,581 reference boundary locations. Constant segments use c=128*A_j,
and the zero suffix c=0. No 22-run merge is needed for this conservative count.
At every seam both adjacent constants must be tested against their shared
reference boundary. Full uncompressed domain: 2^28 blocks and 2^28+1 boundaries.

Integer work is still roughly nine final rows per quadratic block (up to
1,073,479,680 row evaluations); cache each slope for 455*2048=931,840 cells
(six mid rows per cell, 5,591,040 row evaluations). Nontrivial reference calls
or certified interval constructions number about 119 million, not 455 or
9,024. No wall-time estimate is measured. A per-segment slope cache costs
16 KiB int64; storing all quadratic slopes costs about 7.11 MiB. One full
segment block vector costs 2 MiB PER array; many temporaries multiply this.
Storing the quadratic boundary vector alone costs 910 MiB+8 bytes. Stream
small chunks with a fixed memory cap; count rational/transcendental certificate
work and verification, not just endpoint cardinality. Original CHs=8 creates
16-MiB-per-eight-segment arrays repeatedly; its peak is not measured here.

Without a monotonic/enclosure supplier, the honest fully exhaustive operational
alternative evaluates all 2^35+1=34,359,738,369 magnitudes (after evenness), or
all 2^36 signed inputs without that bridge. A full int64 magnitude array alone
would cost 256 GiB+8 bytes; streaming removes storage, not the exp-call work.
This is finite and potentially expensive, not a mathematical impossibility or
an already authorized compute budget. No NumPy substitution may silently
reduce that cost. Certificate files/checker costs and failures remain charged.

## 7. Handoff and source graph

Objective/delta: isolate the exact operational error-reference supplier and
negative-partner endpoint contract; no error root is closed. Direction:
GAUSSIAN_OPERATIONAL_REFERENCE_ENVELOPE_C244. Information gain: distinguishes
valid complete endpoint acceptance from a source-mismatched NumPy/real scan.
Literal definitions only; domain/k/source tolerance are SOURCE binders,
environment/provider data are unresolved bindings, and supplier correctness is
a dependency edge, never a new caller promise. No new quantum representation.

Source graph: contract/reference -> fixed integer block data AND operational
reference bridge AND complete block certificate -> scalar centered-band model.
Separate AND tails still require literal circuit refinement, exact X, phases,
measurement cleanup, resource extraction and any later SP/BE transport. The
Lean graph in this packet gains NO theorem. C229's integer signature is the
only new formal interface read; no C240 proof/diagnostic or numeric author
result was consumed. Source regions for task references/exact_scan/selection
are NODE or SOURCE_GAP above; baseline applications/resource claims and phase
code beyond the arithmetic region are EXCLUDED from this error-reference audit.

Failure class: NONE for this source/design deliverable; uniform operational
certification has explicit ENV/API provenance and supplier gaps, not REFUTED.
Salvage: fixed integer model, partner lemma design and fixed-table test contract
retained; search/recenter and unbridged NumPy certificates rejected as substitutes.
Process memory: QBE-PM-LOW-TOKEN-CONTROL-PLANE and
QBE-PM-VERIFIER-SEMANTIC-LEVEL. No parallel agents; no route-comparison winner
or common-blind-spot acceptance. Default verified Gaussian error route: NONE.
Purification/Exposition-Seal NOT_STARTED. Prior C213/C221/C231 packets unchanged.
Residual confidence: high in source-expression/partner distinction, conditional
in proposed machine interfaces; no numeric pass assumed. Parent should review
this source-first seal and freeze a precise next statement/environment before
any proof search or bounded execution. STOP.
