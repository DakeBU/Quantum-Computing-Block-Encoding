param([Parameter(Mandatory=$true)][string]$WorkRoot)
$ErrorActionPreference='Stop'
$utf8=[System.Text.UTF8Encoding]::new($false)
function HashText([string]$v) {
  $sha=[System.Security.Cryptography.SHA256]::Create()
  try { [Convert]::ToHexString($sha.ComputeHash($utf8.GetBytes($v))).ToLowerInvariant() }
  finally { $sha.Dispose() }
}
function ReadJson([string]$relative) { Get-Content -Raw -LiteralPath (Join-Path $WorkRoot $relative) | ConvertFrom-Json }
function HashFile([string]$relative) { (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $WorkRoot $relative)).Hash.ToLowerInvariant() }
function CheckPosition([string]$text,$pos) {
  $o=[int]$pos.char_offset_0
  if($o -lt 0 -or $o -gt $text.Length){return $false}
  $pre=$text.Substring(0,$o)
  $line=1; foreach($ch in $pre.ToCharArray()){if($ch -eq "`n"){$line++}}
  ($pos.byte_offset_0 -eq $utf8.GetByteCount($pre)) -and ($pos.line_1 -eq $line) -and ($pos.column_1 -eq $o-$pre.LastIndexOf("`n"))
}
function SignatureParts([string]$header) {
  $stack=[System.Collections.Generic.Stack[char]]::new()
  $groups=[System.Collections.Generic.List[string]]::new()
  $colon=-1; $begin=-1
  for($k=0;$k -lt $header.Length;$k++){
    $ch=$header[$k]
    if($ch -in @('(','{','[')){
      if($stack.Count -eq 0){$begin=$k}; $stack.Push($ch)
    } elseif($ch -in @(')','}',']')){
      if($stack.Count -eq 0){throw 'Unbalanced supplied header'}
      $open=$stack.Pop()
      if(($open -eq '(' -and $ch -ne ')') -or ($open -eq '{' -and $ch -ne '}') -or ($open -eq '[' -and $ch -ne ']')){throw 'Mismatched header delimiters'}
      if($stack.Count -eq 0 -and $begin -ge 0){$groups.Add($header.Substring($begin,$k-$begin+1));$begin=-1}
    } elseif($ch -eq ':' -and $stack.Count -eq 0 -and ($k+1 -ge $header.Length -or $header[$k+1] -ne '=')){
      $colon=$k; break
    }
  }
  [pscustomobject]@{colon=$colon;groups=@($groups.ToArray());prefix=if($colon -ge 0){$header.Substring(0,$colon)}else{$header};result=if($colon -ge 0){$header.Substring($colon+1)}else{$null}}
}
$inv=ReadJson 'uncompute-c84-formal-decoder/inventory.json'
$target=[IO.File]::ReadAllText((Join-Path $WorkRoot 'uncompute-c84-formal-input/Hddivsteps590/Recovery.lean'),$utf8)
$own=ReadJson 'uncompute-c81-own-formal-first/formal-inventory.json'
$ownPins=ReadJson 'uncompute-c81-own-formal-first/pins.json'
$inputChecks=@()
foreach($f in @($ownPins.formal_input_files)+@($ownPins.requested_definition_files)+@($ownPins.requested_units_file)){
  $p=$f.path -replace '^F/','uncompute-c84-formal-input/' -replace '^L/','uncompute-c85-formal-definitions/' -replace '^U/','uncompute-c86-units-definition/'
  $h=HashFile $p
  $inputChecks+=[ordered]@{path=$f.path;expected_sha256=$f.observed_formal_sha256;actual_sha256=$h;match=($h -eq $f.observed_formal_sha256)}
}
$bad=[System.Collections.Generic.List[string]]::new()
$manifestChecks=@()
foreach($item in @(
  @('uncompute-c81-appendix-source-first','manifest.json','seal.json'),
  @('uncompute-c81-own-formal-first','manifest.json','seal.json'),
  @('uncompute-c84-formal-decoder','manifest.json','seal.json')
)){
  $dir=$item[0];$m=ReadJson ($dir+'/'+$item[1]);$seal=ReadJson ($dir+'/'+$item[2])
  $files=if($m.payload_files){$m.payload_files}else{$m.files}
  $mBad=@()
  foreach($f in $files){$p=$f.path -replace '^W/','';if((HashFile $p) -ne $f.sha256){$mBad+=$f.path}}
  $expected=if($seal.manifest_sha256){$seal.manifest_sha256}else{$seal.manifest.sha256}
  if((HashFile ($dir+'/manifest.json')) -ne $expected){$mBad+='manifest binding'}
  $manifestChecks+=[ordered]@{root='W/'+$dir;payload_and_manifest_mismatches=$mBad;manifest_sha256=(HashFile ($dir+'/manifest.json'));seal_sha256=(HashFile ($dir+'/seal.json'))}
}
$prefix=$inv.preamble.literal
if((HashText $prefix) -ne $inv.preamble.sha256_utf8){$bad.Add('preamble hash')}
if(-not (CheckPosition $target $inv.preamble.start) -or -not (CheckPosition $target $inv.preamble.end)){$bad.Add('preamble offsets')}
$joined=[System.Text.StringBuilder]::new();[void]$joined.Append($prefix)
$rows=@();$expectedOffset=$prefix.Length;$ns=''
foreach($c in $inv.commands){
  $localBad=@();$start=[int]$c.extent_half_open.start.char_offset_0;$end=[int]$c.extent_half_open.end.char_offset_0
  if($start -ne $expectedOffset){$localBad+='noncontiguous extent'}
  if($target.Substring($start,$end-$start) -cne $c.literal_command){$localBad+='literal command'}
  if((HashText $c.literal_command) -ne $c.command_sha256_utf8){$localBad+='command hash'}
  if((HashText $c.literal_header) -ne $c.header_sha256_utf8){$localBad+='header hash'}
  if(-not $c.literal_command.StartsWith($c.literal_header,[StringComparison]::Ordinal)){$localBad+='header prefix'}
  if(-not (CheckPosition $target $c.extent_half_open.start) -or -not (CheckPosition $target $c.extent_half_open.end)){$localBad+='command positions'}
  $sig=SignatureParts $c.literal_header
  $actualColon=if($null -eq $c.result_colon_char_offset_in_header){-1}else{[int]$c.result_colon_char_offset_in_header}
  if($sig.colon -ne $actualColon){$localBad+='result colon'}
  if($sig.prefix -cne $c.literal_pre_result_binder_region -or $sig.result -cne $c.literal_result_after_top_level_colon){$localBad+='signature split'}
  if($c.kind -in @('def','structure','theorem')){
    if((@($sig.groups) -join "`0") -cne (@($c.explicit_header_binder_groups) -join "`0")){$localBad+='header binder groups'}
  }
  if($c.proof_or_definition_body){
    $b=$c.proof_or_definition_body;$bs=[int]$b.start.char_offset_0;$be=[int]$b.end.char_offset_0
    if($target.Substring($bs,$be-$bs) -cne $b.literal){$localBad+='body literal'}
    if((HashText $b.literal) -ne $b.sha256_utf8){$localBad+='body hash'}
    if(-not (CheckPosition $target $b.start) -or -not (CheckPosition $target $b.end)){$localBad+='body positions'}
    $expectedBody=if($c.kind -eq 'structure'){$c.literal_command.IndexOf('where')+5}elseif($c.name -eq 'zWalk'){$c.literal_command.IndexOf('  | 0 =>')}else{$c.literal_command.IndexOf(':=')}
    if($bs -ne $start+$expectedBody -or $bs -ne $start+$c.literal_header.Length){$localBad+='body boundary'}
  }
  $contextMismatch=($c.namespace -ne $ns)
  $rows+=[ordered]@{ordinal=$c.ordinal_1;name=$c.name;kind=$c.kind;line=$c.extent_half_open.start.line_1;exact_literal_header_body_position_errors=$localBad;reported_namespace=$c.namespace;actual_namespace_before_command=$ns;namespace_context_mismatch=$contextMismatch;header_groups=@($c.explicit_header_binder_groups).Count}
  foreach($e in $localBad){$bad.Add(('{0}:{1}' -f $c.ordinal_1,$e))}
  [void]$joined.Append($c.literal_command);$expectedOffset=$end
  if($c.kind -eq 'namespace'){$ns='Hddivsteps'}
}
$commandNames=@($inv.commands | Where-Object {$_.kind -eq 'theorem'} | ForEach-Object {$_.name})
$ownNames=@($own.theorems.name)
$ambientDifferences=@()
foreach($c in $inv.commands | Where-Object {$_.kind -eq 'theorem'}){
  $o=$own.theorems | Where-Object {$_.name -eq $c.name}
  $expectedAmbient=@($o.implicit | ForEach-Object {($_ -split ':',2)[0]} | Where-Object {$_ -in @('p','x','s')} | Sort-Object)
  $actualAmbient=@($c.ambient_variables_used_text_read | Sort-Object)
  if(($expectedAmbient -join ',') -cne ($actualAmbient -join ',')){$ambientDifferences+=[ordered]@{name=$c.name;expected=$expectedAmbient;actual=$actualAmbient}}
}
$public=@($inv.commands | Where-Object {$_.visibility -eq 'public-source-declaration'} | ForEach-Object {$_.qualified_source_name})
$private=@($inv.commands | Where-Object {$_.visibility -eq 'private-source-name'} | ForEach-Object {$_.qualified_source_name})
$allow=ReadJson 'uncompute-c84-formal-decoder/public-allowlist.json'
$fileNames=@('build-packet.ps1','reconstruction.md','inventory.json','pins.json','chronology.json','packet.json','public-allowlist.json','manifest.json','seal.json')
$allowFiles=@($allow.paths | ForEach-Object {Split-Path $_ -Leaf})
$result=[ordered]@{
  schema='INDEPENDENT_DECODER_LITERAL_AUDIT_V1';method='Read-only comparison; decoder generator never executed. Not an elaborated Lean parser.'
  target_sha256=(HashText $target);target_bytes=$utf8.GetByteCount($target);literal_reassembly_exact=($joined.ToString() -ceq $target);final_extent_reaches_eof=($expectedOffset -eq $target.Length)
  command_count=@($inv.commands).Count;theorem_count=$commandNames.Count;public_source_declarations=$public.Count;private_source_declarations=$private.Count
  errors=@($bad.ToArray());manifest_checks=$manifestChecks;formal_and_requested_library_input_checks=$inputChecks
  inventory_theorem_names_missing_from_frozen_own=@($commandNames | Where-Object {$_ -notin $ownNames});frozen_own_theorem_names_missing_from_decoder=@($ownNames | Where-Object {$_ -notin $commandNames})
  theorem_ambient_used_variable_differences_from_frozen_own=$ambientDifferences
  decoder_allowlist_files_difference=@(Compare-Object (@($fileNames)|Sort-Object) (@($allowFiles)|Sort-Object));decoder_public_names_difference=@(Compare-Object (@($public)|Sort-Object) (@($allow.public_source_declaration_allowlist)|Sort-Object));decoder_private_names_difference=@(Compare-Object (@($private)|Sort-Object) (@($allow.private_source_names)|Sort-Object))
  namespace_context_discrepancies=@($rows | Where-Object {$_.namespace_context_mismatch});per_command_checks=$rows
  honesty_or_historical_independence_verified=$false;compiled=$false
}
$result | ConvertTo-Json -Depth 12
