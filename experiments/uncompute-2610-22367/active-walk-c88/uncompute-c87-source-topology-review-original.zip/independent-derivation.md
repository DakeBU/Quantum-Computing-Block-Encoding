# Independent source-only derivation: Appendix A

Reviewer: `/root/uncompute_appendix_topology_c87`, identity `c87-source-topology-reviewer`.
Distinct from the source extractor `c81-appendix-source-first`; not a formalizer or formal decoder. Direction: `raw-appendix-topology-coverage-and-guarded-AND-vs-OR`.

## Scope and evidence discipline

I read the complete raw PDF pages 44-46 (printed 27-29), both extracted directly from the pinned PDF and visually through the three allowed page renders. I inspected bounded context in the same PDF: page 6 (main Eq7-9, excursion/decoder definition and surrounding resource boundary), pages 28-29 (SI II.1, including branch decoders, MBU/phase, stopping and scaling context), and reference 16 on PDF12 and reference 36 on PDF13. These are source text, not implementation files. Full outside-page coverage is not claimed.

The PDF SHA256 is `3607f457c3349db74e10b131abadef23a4a2dea0fefa0cf6ac6d0ed9f37fdfd9`. The proposed graph and coverage were read only after verifying the supplied source-only seal and manifest hashes. No implementation Lean, formal decoder, compiler outputs, previous review, private extractor rationale, or R/reader metadata was read. The extractor's natural-math and findings payloads were not read. Manifest entries naming those files were used only as byte-binding metadata, not mathematical evidence.

## A1-A2: carrier, active transitions and signed bits

Write F=f_v and G=g_v. The state is an integer tuple (z,f,g,F,G), initially (0,p,w,0,1), where p>0 is odd and 0<=w<p. For an active transition (incoming g!=0), swap iff z>=0 and g odd. The swap sends the tuple to (-z,g,(g-f)/2,2G,G-F). A nonswap sends it to (z+1,f,(g+b f)/2,2F,G+bF), where b is the incoming parity of g. There are exactly three cases: swap with b=1, negative-counter nonswap with b=1, or an even-g nonswap with b=0.

Once g=0 is first reached, the walk freezes. Continuing literal A2 at g=0 would double F and increment z; this is not the source's frozen walk. Thus reachability includes identity transitions, and t in A5/A6 counts active transitions only. A4(3), branch recovery and A6 decoding are claims about active transitions, not an arbitrary frozen identity transition.

For any signed integer u, bit k is bit k of the least nonnegative residue u mod 2^(k+1). Negative f,g,F,G,q are allowed. No unsigned-register positivity assumption can be inserted. v2(0)=infinity is a convention; a finite j and odd part q are used only after proving F nonzero. The bit convention makes all later shift identities valid for negative exact multiples as well.

## A.1 / A3-A4: determinant and parity

At the initial state fG-gF=p. For a nonswap the new determinant is

    f(G+bF) - ((g+bf)/2)(2F) = fG-gF.

For a swap it is

    g(G-F) - ((g-f)/2)(2G) = fG-gF.

These calculations use exact integer halving, justified by parity. The initial f,G are odd and F even. On a nonswap f remains odd, 2F is even and G+bF odd. On a swap incoming g is odd, f'=g is odd, F'=2G even, and G'=G-F odd. This simultaneous induction also establishes that each numerator g+bf or g-f being halved is even. Identity transitions preserve everything. The parity proof is not a consequence of the determinant alone.

## A.2 / A5-A6: scale and conditional inverse

Initially Fw=0=2^0 f mod p and Gw=w=2^0 g mod p. For a nonswap, F'w=2Fw=2^(t+1)f' and G'w=(G+bF)w=2^t(g+bf)=2^(t+1)g' mod p. For a swap, F'w=2Gw=2^(t+1)g=2^(t+1)f', and G'w=(G-F)w=2^t(g-f)=2^(t+1)g'. Frozen transitions do not increment t.

The gcd is invariant using the odd operand retained by each step. If a is odd and h even, gcd(a,h)=gcd(a,h/2). Subtracting or adding a multiple of the retained operand is gcd-neutral. The retained operand is f for nonswap and g for swap; both are odd in their respective cases. This also applies to negative values with nonnegative gcd convention.

At g=0 and gcd(p,w)=1 this gives |f|=1. A3 then gives fG=p and hence G=fp. Multiplying Fw=2^t f by f yields fFw=2^t; 2 is invertible mod odd p, so fF2^(-t) is the inverse. This is conditional on termination, not a proof that every odd-p walk terminates. No primality is needed for this conditional result. The degenerate p=1 is harmless at the congruence level, but w=0 then; it supplies no nontrivial active transition.

## A.3: separate worst-case tail

For p=2^256-2^32-977 the source invokes Wuille [36] for a 590-divstep bound on 0<w<p, then uses primality for gcd=1 and A.2 for final coefficients. The w=0 case starts frozen and needs zero active steps. I have not read the external Wuille proof or certified the exact match to this half-delta recurrence, its signs, start convention, stopping predicate or active count. Nor have I proved this modulus prime. Those are unresolved external inputs, not counterexamples to A.3. The local decoder proof has no dependence on them.

## A.4 / A7: visible branch decisions

On swap F'=2G is twice an odd integer, hence F'=2 mod4 and v2(F')=1. On nonswap F'=2F is divisible by4, including F'=0. This proves swap visibility and swap => b=1. For nonswap with z'>=1, incoming z=z'-1>=0; if incoming g were odd it would swap. Thus b=0. If an active transition has g'=0, then swap already has b=1; for nonswap, b=0 would imply g'=g/2=0 and incoming g=0, contradicting activity.

The remaining nonterminating nonswaps have z'<=0, hence incoming z=z'-1<0. These are the negative-counter cases. A.6 is slightly broader than the residual nonterminating branch: its derivation also applies if such a step terminates, although that step was already cheaply decodable. Tests need a branch priority (e.g. swap, then nonswap terminal, then nonswap z'>=1, then residual); they are not mutually independent sufficient routes to the full objective.

## A.5 / A8-A10: simultaneous window induction

The invariant has two guarded clauses: z>=0 gives 2^(z+1)|F; z<0 gives F!=0 and, writing F=2^j q with q odd, a witness 0<=c<2^j with G=qc mod 2^(j-z). Equivalently Gq^(-1) mod2^(j-z) is the bounded c, so the -z higher bits vanish.

At the initial state z=0,F=0 and 2|0. Frozen identity preserves the invariant. For positive-counter nonswap, F doubles and z increases by one, so the exponent in the positive clause increases by one. For swap at z=D>=0, F'=2G has valuation1 and odd part q'=G; the incoming positive clause gives 2^(D+1)|F. Therefore G'=G-F=G mod2^(D+1) (A9). If D>0 then z'=-D<0 and witness c'=1 meets 0<=1<2, giving A8. If D=0 only the positive clause 2|F' is required; no negative-counter witness is needed.

For nonswap entered at z<0, the incoming negative clause guarantees nonzero F. F'=2F has j'=j+1 and the same odd q. With c'=c+b2^j, one has 0<=c'<2^(j+1), and

    G'=q(c+b2^j) mod 2^(j-z).                    (A10)

The next negative-clause modulus is identical, since j'-z'=(j+1)-(z+1)=j-z. If z'<0 this proves that clause; if z'=0 only evenness is needed. These four induction cases must all be discharged. None is an alternative complete proof of A.5 by itself, and the induction hypotheses must not be turned into new public premises.

## A.6 / A11-A12: guarded decoder theorem

Let the incoming state be reachable and the active transition a nonswap entered at z<0. Write updated F'=2^j q. Incoming F is nonzero by A.5 and even by A.1, so j>=2; q is odd. Incoming depth is j-1. A.5 gives 0<=c<2^(j-1) and G=qc mod 2^((j-1)-z). Because z<=-1, this modulus is divisible by2^j. Reducing it and applying G'=G+bF gives

    G'=q(c+b2^(j-1)) mod2^j.                    (A12)

Odd q is invertible mod2^j, and 0<=c+b2^(j-1)<2^j. Thus the canonical residue G'q^(-1) mod2^j has bit j-1 equal to b. The range bound is indispensable: a generic congruence without it would not identify the bit.

To obtain the second A11 expression, use the UPDATED determinant f'G'-g'F'=p. Since 2^j|F' and f' is odd, G'=p(f')^(-1) mod2^j. Substitute into the first expression and compose inverses to obtain p(f'q)^(-1) mod2^j. This is a proof dependency from the first decoder plus determinant bridge to the second. They are not two independent proofs.

For evaluation after proof, either the G',q residue interface or fixed-p f',q residue interface is sufficient on the same guarded domain. These are an OR of read/evaluation interfaces. Selecting one evaluation interface does not discharge the missing proof prerequisites of the other theorem, and neither interface decodes arbitrary integer tuples lacking reachability and transition guards.

## A13 and A.7: history and finite dependence

At the initiating swap the depth-one window is1 mod2. Each successive negative-counter nonswap appends its decision at the new top bit without changing lower bits. At depth j the j-bit window is 1+sum(k=1..j-1) b_k 2^k (A13). This is an excursion-local history, not a representation of the entire walk across fresh swaps. The last negative-counter transition may exit to z'=0; the extraction formula still holds by its incoming negative-counter invariant.

For fixed p and GIVEN depth j, the second A11 expression uses two residues mod2^j, hence at most2j bits (A.7). This does not count bits to encode j, locate the trailing-zero depth, shift F' to obtain q, synthesize a circuit, or preserve coherent phase. q bits are bits j through 2j-1 of F' for known j, not necessarily its lowest j raw bits. As source context SI II.1 notes, oddness fixes the low bit and can reduce variable inputs; A.7 only asserts the looser upper bound.

## A.8 / A14: depth two

At j=2, q=F'/4 is odd. Mod4 every odd number is self-inverse. For odd u,v, bit1(uv mod4)=u[1] XOR v[1]. Apply u=G',v=q (G' is odd by A.1). Exact signed division F'/4=q gives q[1]=F'[3] under the residue-bit definition, including negative F'. Thus b=G'[1] XOR F'[3]. This uses parity, not just the first A11 expression in isolation.

## Whole-source topology and nonclaims

The full local branch objective combines an exhaustive partition with all conditional cases (AND). It is not the OR of three or four tests, each falsely asserted to solve every branch. Within the residual guarded case, there are two sufficient evaluation read interfaces (OR), while their source proof path remains decodeG AND determinant-bridge => decodeF.

The source arithmetic operates on unbounded signed integers. Appendix A establishes neither a reversible quantum gate implementation nor phase-correct MBU cleanup, ancilla/register reset, signed finite-width overflow handling, a 533-step schedule with tolerated failure, nor Toffoli/qubit or finite-bit cost bounds. SI II.1 describes these further matters, but reading that context does not verify their implementation. The 590 external bound and source modulus primality stay separate unclosed tails. This review is not a Lean proof, Proof Seal, formal release or Exposition Seal.
