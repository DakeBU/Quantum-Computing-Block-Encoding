# Chronology and input inventory

Identity: `c87-source-topology-reviewer`, actual agent `/root/uncompute_appendix_topology_c87`. Extractor identity: `c81-appendix-source-first`. This is a distinct assigned source-only reviewer, not a fabricated independent signature. No subagents were spawned.

## Ordered actions

1. Read G/AGENTS.md, G/HARNESS.md, G/docs/theorem-publication-protocol.md, G/docs/proof-digestion-protocol.md, G/docs/evidence-routed-memory-protocol.md, G/.agents/skills/qbe-substantive-worker/SKILL.md and the PDF skill completely. Where a combined tool output truncated HARNESS, re-read its relevant remainder to EOF before substantive task work. No production or Git action was taken; the assigned no-network/no-Git scope governs this bounded review.
2. Verified SHA256 of P/uncompute-2610.22367v1.pdf, the supplied source-only manifest and terminal seal against the assigned pins. Read only those binding records. They name disallowed payloads but their contents were not opened.
3. Visually read all of W/uncompute-appendix-44.png, -45.png and -46.png in order. Checked render hashes against the manifest. This occurred before reading the proposed graph or coverage.
4. Verified graph/coverage hashes against the manifest; then read only W/uncompute-c81-appendix-source-first/source-graph.json and source-coverage.json completely.
5. Extracted and read complete PDF44-46 directly from the pinned PDF with pypdf, checking the displayed source against render reading. The file has 46 pages. No PDF write or modification occurred.
6. Read bounded same-PDF context: complete extracted PDF6, PDF28-29, plus only bounded extracted bibliography snippets around references16 and36 on PDF12-13. Source nearby material on those pages was visible, including SI II.1 MBU/phase and stopping context; this is disclosed, not treated as implementation evidence or an extra complete-paper audit.
7. Independently reconstructed the mathematics, checked each formula A1-A14, numbered result A.1-A.8, substantive proof/connective paragraph, and all proposed 76 coverage dispositions. Checked dependency direction, induction guards, AND case closure, guarded evaluation OR, signed bits, stopping/counting, and circuit/resource boundaries. No natural-math.md or findings.md from the extractor was read.
8. An actual host clock check before packet writing returned 2026-10-18T01:32:38.1732110+08:00. Earlier per-step wall-clock timestamps were not collected and are not invented. The seal contains a later actual clock observation.
9. Wrote only a new packet under W/uncompute-c87-source-topology-review, checked JSON parsing, correspondence and hashes, then froze it with manifest and terminal seal. No source rewriting, production changes, Lean, build, simulator, network, Git commit/push or formal release.

## Mathematical inputs

- P/uncompute-2610.22367v1.pdf, SHA256 `3607f457c3349db74e10b131abadef23a4a2dea0fefa0cf6ac6d0ed9f37fdfd9`, 2380628 bytes.
- W/uncompute-appendix-44.png, SHA256 `f64474fced0c7761a8a90d72bfdc338dded3cdf825ead6107ce84b2e1bae5059`.
- W/uncompute-appendix-45.png, SHA256 `9080c2f3f3b3e59c454698bdef0078d8f092da85979242fe6e1d1b027d118065`.
- W/uncompute-appendix-46.png, SHA256 `d5317193fae05f19260ee6af8fbbcf77f0e93b2ddedb3ac3298f49d34d49a6dd`.
- W/uncompute-c81-appendix-source-first/source-graph.json, SHA256 `5200ae433e3b8c37e6f2c89da8281d97f61ed23ea631a7c3aef05f39dc447250`.
- W/uncompute-c81-appendix-source-first/source-coverage.json, SHA256 `0472cb9a3a85a6a2c92358874fcaefc810e4388d02e41c4088b32e6a290befc0`.

Binding-only inputs: W/uncompute-c81-appendix-source-first/manifest.json SHA256 `fe5a73def6d67a576775a83725e4b9463910c91679e32ff8df6cd52b0cd87473`; seal.json SHA256 `367e571fda612e8445d02c84bc2cb36ed3227fe7e66280dbde024733ca08cbad`.

Governance/skill inputs and hashes are enumerated in this packet's manifest. Logical roots: G is repository governance; W is the assigned local work-artifact root; P is the pinned source-reference root. The PDF skill input uses the logical inventory identity G/governance-inputs/pdf-skill/SKILL.md (an audit alias, not a claim that a repository file exists there). No host root map is public.

## Independence, residual and next action

No implementation Lean/formal decoder/compiler output, other review, parent mathematical conclusion, R/reader metadata or extractor private rationale was used. The assignment's direction fingerprint and source pins were routing instructions, not proof evidence. The reviewer did not self-approve extraction; it separately assessed raw source and proposed public graph records.

The source topology and coverage are acceptable as bounded source-only evidence. A3 is covered but has unverified external-bound transport and primality tails. Local arithmetic is not a gate/phase/resource certificate. Next action: parent may consume this packet as independent topology-review evidence while preserving those tails. Stop here before implementation inspection or formal release. Changes require a successor packet, not mutation of this freeze.
