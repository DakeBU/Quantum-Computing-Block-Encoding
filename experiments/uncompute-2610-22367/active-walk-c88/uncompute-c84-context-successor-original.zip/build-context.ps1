param([Parameter(Mandatory=$true)][string]$FormalInputRoot,[Parameter(Mandatory=$true)][string]$OriginalPacketRoot)
$ErrorActionPreference='Stop'
$out=$PSScriptRoot
$utf8=[Text.UTF8Encoding]::new($false)
function ContextTextHash([string]$t){$sha=[Security.Cryptography.SHA256]::Create();try{return [Convert]::ToHexString($sha.ComputeHash($utf8.GetBytes($t))).ToLowerInvariant()}finally{$sha.Dispose()}}
function HF([string]$p){return (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function J([string]$n,$o){[IO.File]::WriteAllText((Join-Path $out $n),(($o|ConvertTo-Json -Depth 100)-replace "`r`n","`n")+"`n",$utf8)}
function Check([bool]$ok,[string]$message){if(-not $ok){throw $message}}
function Pos([string]$t,[int]$i){$p=$t.Substring(0,$i);return [ordered]@{char_offset_0=$i;byte_offset_0=$utf8.GetByteCount($p);line_1=([regex]::Matches($p,"`n")).Count+1;column_1=$i-$p.LastIndexOf("`n")}}
function SamePos($a,$b){return $a.char_offset_0 -eq $b.char_offset_0 -and $a.byte_offset_0 -eq $b.byte_offset_0 -and $a.line_1 -eq $b.line_1 -and $a.column_1 -eq $b.column_1}
function Colon([string]$s){$d=0;for($i=0;$i -lt $s.Length;$i++){$c=[string]$s[$i];if('({['.Contains($c)){$d++}elseif(')}]'.Contains($c)){$d--}elseif($c -eq ':' -and $d -eq 0 -and ($i+1 -eq $s.Length -or $s[$i+1] -ne '=')){return $i}};return -1}
function Binders([string]$s){$r=@();$d=0;$start=-1;for($i=0;$i -lt $s.Length;$i++){$c=[string]$s[$i];if('({['.Contains($c)){if($d -eq 0){$start=$i};$d++}elseif(')}]'.Contains($c)){$d--;if($d -eq 0){$r+=$s.Substring($start,$i-$start+1)}}};return ,$r}
$started=[DateTime]::UtcNow.ToString('o')
$oldSealHash='acb7bd84b74f56882a806f631e4617f26346feb2c08a80b5e01d55edbc7d2d93'
$oldManifestHash='1ce70f722e28512a09ea3fbc41b069848643318f0415cf3062b8b4943c5b8f16'
$oldAllowHash='0edd8e6954c569d7063a3afdc0b942423698431d7ed66721e8aa75abb1a61a34'
Check ((HF (Join-Path $OriginalPacketRoot 'seal.json')) -eq $oldSealHash) 'Historical seal mismatch'
Check ((HF (Join-Path $OriginalPacketRoot 'manifest.json')) -eq $oldManifestHash) 'Historical manifest mismatch'
Check ((HF (Join-Path $OriginalPacketRoot 'public-allowlist.json')) -eq $oldAllowHash) 'Historical allowlist mismatch'
$oldManifest=Get-Content -Raw -LiteralPath (Join-Path $OriginalPacketRoot 'manifest.json')|ConvertFrom-Json
$oldPins=@()
foreach($f in $oldManifest.files){$n=($f.path -split '/')[-1];$p=Join-Path $OriginalPacketRoot $n;Check ((HF $p) -eq $f.sha256) ('Historical payload mismatch '+$n);Check ((Get-Item -LiteralPath $p).Length -eq $f.bytes) ('Historical byte count mismatch '+$n);$oldPins+=[ordered]@{path=$f.path;sha256=$f.sha256;bytes=$f.bytes}}
foreach($n in @('manifest.json','seal.json')){$p=Join-Path $OriginalPacketRoot $n;$oldPins+=[ordered]@{path=('W/uncompute-c84-formal-decoder/'+$n);sha256=(HF $p);bytes=(Get-Item -LiteralPath $p).Length}}
Check ($oldPins.Count -eq 9) 'Historical artifact count mismatch'
$inputManifestPath=Join-Path $FormalInputRoot 'formal-inputs.json'
$inputHash=HF $inputManifestPath
Check ($inputHash -eq 'ad146ba5675183393c5eef47f12d5a7d51754c6f250272908575dc0777f17ca6') 'Input manifest mismatch'
$inputManifest=Get-Content -Raw -LiteralPath $inputManifestPath|ConvertFrom-Json
foreach($f in $inputManifest.files){Check ((HF (Join-Path $FormalInputRoot $f.path)) -eq $f.formal_sha256) ('Formal input hash mismatch '+$f.path)}
$t=[IO.File]::ReadAllText((Join-Path $FormalInputRoot 'Hddivsteps590/Recovery.lean'),$utf8)
$inv=Get-Content -Raw -LiteralPath (Join-Path $OriginalPacketRoot 'inventory.json')|ConvertFrom-Json
Check ((ContextTextHash $t) -eq $inv.target_sha256) 'Target inventory binding mismatch'
$ms=[regex]::Matches($t,'(?m)^(?:import\b|namespace\b|variable\b|structure\b|def\b|theorem\b|private theorem\b|end\b)[^\r\n]*')
Check ($ms.Count -eq $inv.command_count -and $ms.Count -eq 59) 'Command count mismatch'
$ns=@();$ambient=@();$origins=@();$rows=@();$checks=@();$namespaceTransitions=@()
for($i=0;$i -lt $ms.Count;$i++){
  $e=$inv.commands[$i];$m=$ms[$i];$begin=$m.Index;$finish=if($i+1 -lt $ms.Count){$ms[$i+1].Index}else{$t.Length};$literal=$t.Substring($begin,$finish-$begin)
  Check ($e.ordinal_1 -eq $i+1) 'Ordinal mismatch'
  Check ($literal -ceq $e.literal_command) ('Literal mismatch '+$e.ordinal_1)
  Check ((ContextTextHash $literal) -eq $e.command_sha256_utf8) ('Command hash mismatch '+$e.ordinal_1)
  Check (SamePos (Pos $t $begin) $e.extent_half_open.start) 'Command start position mismatch'
  Check (SamePos (Pos $t $finish) $e.extent_half_open.end) 'Command end position mismatch'
  $kind=if($m.Value -match '^private theorem'){'theorem'}else{($m.Value -split '\s+')[0]}
  Check ($kind -ceq $e.kind) 'Kind mismatch'
  $bodyStart=-1
  if($kind -in @('def','theorem')){
    $bodyStart=if($e.name -eq 'zWalk'){$literal.IndexOf('  | 0 =>')}else{$literal.IndexOf(':=')}
    Check ($bodyStart -ge 0) 'Unrecognized body boundary'
  }elseif($kind -eq 'structure'){$w=[regex]::Match($literal,'\bwhere\b');Check $w.Success 'Missing where';$bodyStart=$w.Index+$w.Length}
  $header=if($bodyStart -ge 0){$literal.Substring(0,$bodyStart)}else{$literal.TrimEnd()}
  Check ($header -ceq $e.literal_header -and (ContextTextHash $header) -eq $e.header_sha256_utf8) 'Header mismatch'
  $colon=Colon $header
  if($colon -ge 0){Check ($colon -eq $e.result_colon_char_offset_in_header) 'Result colon mismatch';Check ($header.Substring($colon+1) -ceq $e.literal_result_after_top_level_colon) 'Result literal mismatch'}else{Check ($null -eq $e.result_colon_char_offset_in_header -and $null -eq $e.literal_result_after_top_level_colon) 'Unexpected result colon'}
  $prefix=if($colon -ge 0){$header.Substring(0,$colon)}else{$header}
  Check ($prefix -ceq $e.literal_pre_result_binder_region) 'Binder region mismatch'
  $groups=if($kind -in @('def','theorem','structure')){Binders $prefix}else{@()}
  Check (@($groups).Count -eq @($e.explicit_header_binder_groups).Count) 'Binder count mismatch'
  for($b=0;$b -lt @($groups).Count;$b++){Check ($groups[$b] -ceq $e.explicit_header_binder_groups[$b]) 'Binder literal mismatch'}
  if($bodyStart -ge 0){$body=$literal.Substring($bodyStart).TrimEnd();Check ($body -ceq $e.proof_or_definition_body.literal -and (ContextTextHash $body) -eq $e.proof_or_definition_body.sha256_utf8) 'Body mismatch';Check (SamePos (Pos $t ($begin+$bodyStart)) $e.proof_or_definition_body.start) 'Body start mismatch';Check (SamePos (Pos $t ($begin+$bodyStart+$body.Length)) $e.proof_or_definition_body.end) 'Body end mismatch'}else{Check ($null -eq $e.proof_or_definition_body) 'Unexpected body'}
  $nsBefore=if($ns.Count){$ns -join '.'}else{'_root_'};$ambientBefore=@($ambient)
  if($kind -eq 'namespace'){
    $nm=[regex]::Match($m.Value,'^namespace\s+(\S+)\s*$');Check $nm.Success 'Unrecognized namespace command';$ns+= $nm.Groups[1].Value
    $namespaceTransitions+=[ordered]@{ordinal_1=$e.ordinal_1;literal_command=$m.Value;origin=(Pos $t $begin)}
  }elseif($kind -eq 'variable'){
    $origins+=[ordered]@{ordinal_1=$e.ordinal_1;literal_command=$m.Value;origin=(Pos $t $begin);scope='Active after this command in the current local namespace scope; does not force inclusion in every later theorem.'}
    $ambient+=$e.ordinal_1
  }elseif($kind -eq 'end'){throw 'Unexpected namespace closer requires explicit stack-frame support'}
  $nsAfter=if($ns.Count){$ns -join '.'}else{'_root_'}
  $rows+=[ordered]@{
    ordinal_1=$e.ordinal_1;original_command_sha256=$e.command_sha256_utf8;
    legacy_references=[ordered]@{namespace_owner_label=$e.namespace;ambient_variable_command_reference=$e.ambient_variable_command};
    namespace_before_command=$nsBefore;namespace_after_command=$nsAfter;
    ambient_origin_ordinals_before_command=@($ambientBefore);ambient_origin_ordinals_after_command=@($ambient)
  }
  $checks+=[ordered]@{ordinal_1=$e.ordinal_1;original_command_sha256=$e.command_sha256_utf8;all_literal_hash_extent_header_binder_body_checks='PASS';historical_context_values_retained='PASS'}
}
$verified=[DateTime]::UtcNow.ToString('o')
J 'context-overlay.json' ([ordered]@{
  schema='ADDITIVE_EXACT_LOCAL_CONTEXT_OVERLAY_V1';status='FORMAL_CONTEXT_METADATA_ONLY';actor='/root/uncompute_formal_decoder_c84';
  original_inventory=[ordered]@{path='W/uncompute-c84-formal-decoder/inventory.json';sha256=(HF (Join-Path $OriginalPacketRoot 'inventory.json'))};
  target_sha256=(ContextTextHash $t);join_key='ordinal_1 plus original_command_sha256';
  legacy_field_interpretation=[ordered]@{namespace='Static owner-label reference, not actual lexical scope at every command.';ambient_variable_command='Static cross-reference to a later or active scoped declaration, not proof of scope before it is introduced.'};
  boundary_convention='before/after immediately surrounds processing of the command itself; excludes inter-command whitespace. _root_ denotes empty source-local namespace stack. Ambient arrays refer to origin ordinals, not automatically included binders.';
  scope_limit='Source-local commands only; imported module internal scopes and elaboration are not reconstructed.';
  namespace_transition_origins=$namespaceTransitions;ambient_origins=$origins;commands=$rows;
  unchanged='All original fields, literals, proof bodies, headers, binders, extents, hashes and reconstructed mathematics remain immutable.'
})
$oldAfter=@()
foreach($p in $oldPins){$n=($p.path -split '/')[-1];$observed=HF (Join-Path $OriginalPacketRoot $n);Check ($observed -eq $p.sha256) 'Historical artifact changed during generation';$oldAfter+=[ordered]@{path=$p.path;sha256=$observed;bytes=$p.bytes;before_after_equal=$true}}
J 'verification.json' ([ordered]@{
  schema='CONTEXT_SUCCESSOR_TEXT_VERIFICATION_V1';status='TEXT_VERIFIED_NOT_COMPILED';actor='/root/uncompute_formal_decoder_c84';
  input_manifest_sha256=$inputHash;all_six_original_formal_hashes_rechecked=$true;historical_nine_before_after=$oldAfter;
  command_count=$ms.Count;record_checks=$checks;
  method='Independently rescan complete pinned target command boundaries, compare all 59 existing command literals and hashes, reconstruct source header/body boundaries and depth-zero result colon, compare all binder/result/body literals and every recorded position component. Derive namespace and ambient state in command order. No original artifact is written.';
  limitations='File-specific textual scanner, not an elaborated Lean parser. No source-relative binder reclassification or mathematical revision.'
})
J 'chronology.json' ([ordered]@{
  schema='CONTEXT_SUCCESSOR_CHRONOLOGY_V1';actor='/root/uncompute_formal_decoder_c84';generation_started_utc=$started;verification_finished_utc=$verified;
  ordered_events=@(
    'Received request for additive owner-label versus lexical-context clarification; no mathematical reinterpretation requested.',
    'Read own original sealed inventory, manifest and seal; original nine hashes verified against historical seal chain.',
    'Rechecked original same six formal hashes and read pinned target for all command text and offsets; no extra formal provider or source read.',
    'Compared all 59 original records and derived before/after scope from the original namespace/variable command stream.',
    'Generated additive overlay and verification; rechecked all original nine hashes unchanged.',
    'Bound exact successor allowlist and payload manifest; froze successor seal; stopped.'
  );source_or_compiler_or_other_review_outcomes_received=$false;original_seal_preserved=$true
})
$names=@('build-context.ps1','erratum.md','context-overlay.json','verification.json','chronology.json','public-allowlist.json','manifest.json','seal.json')
J 'public-allowlist.json' ([ordered]@{schema='EXACT_PUBLIC_ALLOWLIST_V1';logical_directory='W/uncompute-c84-context-successor';paths=@($names|ForEach-Object{'W/uncompute-c84-context-successor/'+$_});additive_only=$true;original_nine_immutable=$true})
$payload=@()
foreach($n in $names|Where-Object{$_ -notin @('manifest.json','seal.json')}){$p=Join-Path $out $n;$payload+=[ordered]@{path=('W/uncompute-c84-context-successor/'+$n);bytes=(Get-Item -LiteralPath $p).Length;sha256=(HF $p)}}
J 'manifest.json' ([ordered]@{schema='CONTEXT_SUCCESSOR_MANIFEST_V1';actor='/root/uncompute_formal_decoder_c84';status='FORMAL_CONTEXT_METADATA_ONLY';original_seal_sha256=$oldSealHash;input_manifest_sha256=$inputHash;files=$payload;seal_rule='Manifest binds six payload files; seal binds manifest; seal own hash handed off externally.'})
J 'seal.json' ([ordered]@{
  schema='ADDITIVE_FORMAL_CONTEXT_SEAL_V1';actor='/root/uncompute_formal_decoder_c84';status='FORMAL_CONTEXT_METADATA_ONLY';sealed_utc=[DateTime]::UtcNow.ToString('o');
  original_seal_sha256=$oldSealHash;manifest_sha256=(HF (Join-Path $out 'manifest.json'));allowlist_sha256=(HF (Join-Path $out 'public-allowlist.json'));
  original_nine_immutable=$true;all_59_records_verified=$true;source_agreement_not_claimed=$true;compiled_not_claimed=$true;admission_not_claimed=$true;root_not_claimed=$true;purified_not_claimed=$true;
  stop_rule='Additive context clarification complete; stop without source release or modification of either sealed packet.'
})
[ordered]@{records_verified=$ms.Count;original_nine_unchanged=$true;manifest_sha256=(HF (Join-Path $out 'manifest.json'));allowlist_sha256=(HF (Join-Path $out 'public-allowlist.json'));seal_sha256=(HF (Join-Path $out 'seal.json'))}|ConvertTo-Json
