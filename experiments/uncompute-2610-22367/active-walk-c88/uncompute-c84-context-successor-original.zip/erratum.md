# Additive context-label clarification

Status: FORMAL_CONTEXT_METADATA_ONLY. Actor: `/root/uncompute_formal_decoder_c84`.

This overlay supplements, and does not replace or modify, the nine files sealed in `W/uncompute-c84-formal-decoder/`. It makes no mathematical, source-fidelity, compiler, admission, ROOT, or PURIFIED claim.

The old inventory's `namespace` field is a static module-owner label. It is not an assertion that an import preceding the namespace opener was executed inside that namespace. Its `ambient_variable_command` field is a static reference to the module's scoped-variable declaration, not an assertion that the declaration was already active at every earlier command. Those historical values are preserved verbatim as labelled `legacy_references` in each overlay record.

Use `namespace_before_command` and `namespace_after_command` for source-local namespace scope. `_root_` denotes the empty local namespace stack. Before/after is measured immediately before/after processing the named command, not the whitespace or masked comments between it and the next command. In particular, a namespace opener changes the after-state, not the before-state.

Use `ambient_origin_ordinals_before_command` and `ambient_origin_ordinals_after_command` for source-local active `variable` declarations. Each ordinal refers to `ambient_origins`, which preserves the literal declaration and its exact original location. An empty list means no locally introduced ambient variable command has yet occurred. A variable declaration affects the after-state. These are scoped declarations available to later commands, not a claim that every later theorem includes every declared variable or that explicit local binders cannot shadow a name. Existing per-declaration binder information is unchanged.

The overlay is derived by walking the complete original command stream in order. Imported modules' internal command scopes are not traversed or inferred. The original target contains one namespace opener and one variable command and no namespace closer; the overlay reports that literal fact without diagnosing elaboration.

All 59 records were compared to independently located command boundaries in the pinned original target. Command literals, headers, result-colon positions, pre-result binder regions and binder groups, result literals, body literals, character/UTF-8-byte/line/column positions, and their recorded hashes were verified without changing any old value. All nine historical artifact hashes were checked before and after generation. `verification.json` records these checks; they are deterministic text checks, not a Lean parser or compiler certificate.

No source, compiler result, other review, new mathematical provider, network, Git, or production file was consulted. The old mathematical reconstruction and all original residuals remain as sealed. The only new files are the exact allowlist in this successor directory.
