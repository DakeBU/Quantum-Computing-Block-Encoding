# Independent whole-target first reading

Evidence class: SOURCE_FIRST_FORMAL_FIRST_READING, uncompiled. The independently frozen SOURCE_ONLY baseline is unchanged: its manifest SHA256 is fe5a73def6d67a576775a83725e4b9463910c91679e32ff8df6cd52b0cd87473 and terminal seal SHA256 is 367e571fda612e8445d02c84bc2cb36ed3227fe7e66280dbde024733ca08cbad. The first-reading target is F/Hddivsteps590/Recovery.lean, masked SHA256 da1a987c401aabdeb58f8785bb6dc3928aedadae30fa0386efc778de727c770b. No decoder packet, raw author file, README, source PDF, other review, compiler output, Git, network, simulation, or subagent was used during this phase. Original source credit remains arXiv:2610.22367v1 and A. Gu's *uncompute* reference, not a claim that these re-derived proofs are new mathematics.

## 1. Whole-file environment and data semantics

The target has 819 lines: eleven imports at 41-51, namespace Hddivsteps at 53, structures ZState and Inv, five definitions, one ambient variable command and 39 theorems (27 public, 12 private). There are no additional target commands after j2_law's proof at line819; no explicit closing namespace command appears in the supplied target. This is a literal textual observation, not a parse/build failure claim. Masked comments are blank and convey no theorem provenance. Every executable command, header and proof body was read, including private arithmetic helpers.

The imports are integer congruence/gcd/parity, integer-ring basics, padic valuation, ZMod basics/units, three tactic modules and Hddivsteps590.NumberTheory. That provider imports Defs. Host lean-toolchain is Lean4.33.0; host lakefile names package aspbe, mathlib v4.33.0, VersoBlueprint v4.33.0 and libraries unrelated to this standalone module. The host manifest pins mathlib db584cd6d46c92f209a44c0f1c829460d327499d. This is a host context supplied by the parent, not evidence of the upstream author's configuration, target module inclusion in a build target, import resolution, or successful elaboration.

ZState is exactly five unrestricted Int fields z,f,g,fv,gv. Write F=s.fv and G=s.gv. No subtype stores oddness, bounds, positivity, reachability, activity or finite-width representation. The ambient declaration {p x : Int} {s : ZState} implicitly generalizes only variables appearing in an individual declaration's type; it does not add an unused x or p to every theorem. The theorems with explicit (x : Int) shadow/instantiate the ambient x in their local scope in the ordinary syntax. No hidden section hypotheses, instances or local axioms appear in the supplied target.

Define sigma(s)=(0<=z and g%2=1), with % the integer remainder operator and / integer division. zStep is an unrestricted arithmetic function:

    sigma: (-z,g,(g-f)/2,2G,G-F)
    otherwise: (z+1,f,(g+(g%2)f)/2,2F,G+(g%2)F).

It does NOT freeze on g=0. With odd f, both relevant numerators are even and integer halving is exact. Without odd f this remains a total integer function but is not the source's reachable exact-halving domain. The branch simplification theorems merely unfold this definition under sigma or its negation.

bbit(s) is if sigma(s) then f%2 else g%2. This is NOT literally the source definition b=g%2 on every unrestricted state. On every reachable source state f is odd, so swap gives f%2=1=g%2, while nonswap already reads g%2. The public bbit_of_swap explicitly assumes f%2=1. Off that domain this semantic difference is real and must not be erased in a source-facing definition claim.

zSeed(p,x)=(0,p,x,0,1). zWalk(p,x,0)=zSeed; at t+1 it returns the old state if g=0, else zStep of it. Thus t is a scheduled iteration index in this definition and may continue increasing while the state is frozen. To identify t with the source's number of active steps, scale_zWalk requires every earlier indexed state to have g!=0. At a first terminal time, this says all t transitions were active. It does not require the endpoint itself to be active.

## 2. The separate HD provider and its exact bridge

Defs also contains dyadic-number pairs, lexicographic ordering, orientation, chain hull, state merging, a hull-bound iteration and an integer Mstar. Their full bodies were read, but Recovery never calls the hull machinery or a termination certificate. A Bool certEmpty or a file/directory name containing 590 supplies no theorem that a source walk terminates within 590 steps.

The provider structure HDState has delta,f,g,d,e,modulus : Int. hdInit(f,g)=(1,f,g,0,1,f). div2M(M,a) halves a, first adding M if a is odd. hdStep first checks even g: delta'=delta+2, g'=g/2, e'=div2M(modulus,e); f,d,modulus unchanged. If g is odd and delta>0: delta'=2-delta,f'=g,g'=(g-f)/2,d'=e,e'=div2M(modulus,e-d). Otherwise odd: delta'=delta+2,g'=(g+f)/2,e'=div2M(modulus,e+d), other fields unchanged. hdRun is exactly N repetitions with no freezing. In particular, g=0 remains zero, f and d remain fixed, but delta/e can still change. These d/e are modularly halved coefficients, not the integer source F/G and not asserted equal to them.

zWalk_hdRun proves for every integer p,x and natural scheduled t:

    zWalk.f=hdRun.f, zWalk.g=hdRun.g,
    zWalk.g!=0 => hdRun.delta=2*zWalk.z+1.

At time0 this is immediate. If the frozen walk has g=0, the HD even case keeps f and g, so the first two equalities survive; the delta implication is vacuous. Otherwise the induction hypothesis supplies delta=2z+1. The even case increments z by1 and delta by2. For odd g, delta>0 is equivalent to z>=0; in that case 2-(2z+1)=2(-z)+1, while odd negative z takes the nonswap and advances both counters. No parity or primality hypothesis is needed for this syntactic f/g and counter relation. The bridge is intentionally partial on the counter after freezing and makes no F/G to d/e assertion.

NumberTheory proves gcd_hdRun_eq by preserving odd f and gcd in all three hdStep cases. Its gcd_half uses the fact that the fixed odd operand is coprime to2; addition/subtraction of the other operand does not change gcd, and dividing an even combined operand by2 is harmless. Recovery's private gcd_zWalk rewrites only f,g through zWalk_hdRun and imports that exact gcd theorem. Other provider results include conditional modular inverse_hdRun, d=0 when initial g=0, and prime_coprime. They are not used to smuggle a termination assumption into the target, and prime_coprime does not prove any particular large integer prime.

## 3. Inv is a proved bundle, not an unexplained correctness oracle

Inv(p,s) has exactly four fields:

    det: fG-gF=p;
    fodd: f%2=1;
    high: z>=0 => 2^(z.toNat+1) divides F;
    low: z<0 => exists j:Nat,q,r:Int,
      1<=j, q%2=1, F=2^j*q, 0<=r<2^j,
      2^(j+(-z).toNat) divides G-q*r.

There is no hidden Reachable, Active, G-odd field, supplied branch decoder, supplied valuation equation or terminating-run field. In the high branch z.toNat equals z; in the low branch (-z).toNat equals -z. No erroneous clamping occurs because the guards precede these interpretations. Low's finite odd factor guarantees nonzero F and fixes its genuine valuation, avoiding any choice of a finite valuation for zero.

Inv.fveven splits z<0 versus z>=0. In low, j>=1 makes 2|2^j q; in high, exponent z.toNat+1>=1 gives 2|F. Inv.gvodd additionally uses odd p: det modulo2 with f odd and F even forces G odd. Thus the parity fields omitted from Inv are proved, not assumed.

Inv.zStep proves every field of the output Inv from every field of the input Inv and odd p. The proof is not just a theorem-name wrapper. In the swap case, it extracts (g-f)=2k, proves exact division by k and verifies determinant algebra; f'=g is odd. If -z>=0 alongside z>=0 then z=0 and only 2|2G is required. If -z<0 it chooses j'=1,q'=G,r'=1. Incoming high gives 2^(z+1)|F, hence that power divides (G-F)-G*1=-F; G is odd by Inv.gvodd.

In the nonswap case it proves the high condition before splitting the parity of g. For z>=0 the exponent increases by1 and F doubles; if z<0 and z+1>=0, integer z must equal -1 and the output merely needs 2|2F. For even g it checks determinant with g=2k and chooses the old low witness r, exponent j'=j+1 and same odd q. For odd g it checks determinant with g+f=2k and chooses r'=r+2^j, again j'=j+1. Both witnesses satisfy the new range because r is in [0,2^j). Their modulus exponent is unchanged, (j+1)+(-(z+1)).toNat=j+(-z).toNat, and the updated witness difference reduces to G-qr. These are the source A.5 branch calculations in a representation using existential odd factors rather than the valuation function itself.

inv_zSeed constructs det by p*1-x*0=p, fodd from hp, high by divisibility of0, and low by contradiction z=0<0. invariant_zWalk inducts on scheduled time: frozen steps keep the existing Inv, otherwise Inv.zStep supplies the next. Consequently det_zWalk and parity_zWalk are unconditional-in-reachability consequences for every odd integer p, every integer x and every scheduled t. They require neither p>0 nor 0<=x<p. This is a genuine extension of the source's input domain, not a new source premise. A source-domain instantiation simply chooses the original positive p and bounded w=x.

## 4. Scale, endpoint and inverse statements

modEq_congr is an internal transport lemma for replacing the two sides of an integer congruence by equal expressions; its equality hypotheses are proof-glue inputs, not source assumptions.

scale_zWalk assumes odd p and hact: for every u<t, zWalk(p,x,u).g!=0. The induction on t uses hact at t to select the nonfrozen branch at the successor, and its restriction to earlier u for the induction hypothesis. It then checks exactly the source scale induction. Swap gives (2G)x congruent to 2^(t+1)g, and (G-F)x congruent to 2^t(g-f)=2^(t+1)g'. Nonswap gives (2F)x and either Gx or (G+F)x. The code extracts even numerators as 2m and rewrites exact division rather than relying on an unchecked field-style cancellation. This proves the two A5 congruences when t transitions were active. It does not assert scale 2^t at every later frozen scheduled index. No active counter distinct from scheduled t is defined in the target.

endpoint_zWalk assumes gcd(p,x)=1 and a selected endpoint g=0, but no hact. gcd_zWalk then gives |f|=1. The determinant reduces to fG=p and splitting f=+1/-1 yields G=fp. This holds at any later frozen time too because these fields stay unchanged. It does not prove an endpoint exists.

inverse_zWalk adds hact and proves fF*x congruent to2^t modulo p. It multiplies the first scale relation by f and uses f^2=1 from the endpoint theorem. It is the scaled inverse relation, not yet a chosen modular inverse value. inverse_zWalk_unscaled quantifies an integer a and assumes ha:2^t*a congruent to1 modulo p; multiplying the scaled relation by a yields F*a*f*x congruent to1. This accurately says any supplied inverse multiplier of2^t produces an inverse witness for x. The target does not construct a or prove existence of ha from odd p, and does not define w^(-1) modulo p. Thus this is a conditional helper for A6, not the literal unconditional source A6 formula by itself. If it is advertised as the final source anchor with free ha, that logical input is an extra proof ingredient that must instead be supplied internally by an odd-modulus inverse lemma. There is no need to add ha to the source contract, and no proof of A6 follows merely from this helper's name.

## 5. Locally visible decisions

swap_iff_fv uses Inv's derived G odd/F even: a swap has F'=2G congruent2 modulo4, nonswap F'=2F divisible4. sigma_class repackages this as congruence, valuation-equals1, and nonswap divisibility. Its valuation proof splits F=0 explicitly in the nonswap branch; the nonzero branch uses 4|2F to exclude valuation1. The source valuation convention is infinity at0, while the formal padic valuation is totalized by the library; exact library semantics are separately pinned in the additional-definition record, not silently identified with infinity.

bbit_of_swap assumes f odd and sigma, so bbit=1. bbit_of_ramp assumes nonswap and zStep.z>=1, hence incoming z>=0 and g must be even or sigma would have held; bbit=0. bbit_of_freeze assumes f odd, incoming g!=0 and outgoing raw zStep.g=0. The swap case is already1. In nonswap, if g%2=0 then exact even division g/2=0 forces g=0, a contradiction, so the remainder is1. The explicit incoming nonzero hypothesis is essential; this theorem concerns the active transition that reaches zero, not a later identity transition of zWalk. Its name alone must not be read as a theorem about every frozen state.

The target has these branch lemmas separately. It does not define one decoder returning both s and b on every reachable active transition, prove a single exhaustive partition theorem about actual zWalk successors, or prove an inverse update restoring the predecessor. These can be derived/implemented using the supplied arithmetic ingredients, but are not present as such in this target.

## 6. Canonical factors, unique residues and the ladder

padicValInt_of_odd_factor starts with n=2^j q and odd q, so n!=0. It proves valuation(n)=j by valuation multiplication, odd q valuation0 and the valuation of2^j, and proves n/2^j=q by exact integer cancellation. two_pow_mul_odd_inj compares two such decompositions by their valuations and then their exact quotients, yielding equality of both exponent and odd part. isCoprime_two_pow derives that odd q is coprime to2^k; pow_two_dvd_cancel removes odd q from divisibility by2^k. eq_of_sub_dvd_of_bounds says two representatives in [0,n) whose difference is divisible by n are equal. These helpers establish uniqueness rather than assume it.

ladder_witness takes an Inv state with incoming z<0, plus an arbitrary outgoing factorization F'=2^j q with q odd and arbitrary r in [0,2^j) satisfying 2^j|(G'-qr). These additional variables/facts characterize a candidate canonical output residue; they are NOT assumptions of the source theorem. The low field supplies incoming j0>=1,q0 odd,r0 in [0,2^j0) and its stronger congruence. Since F'=2F, odd-factor uniqueness proves j=j0+1 and q=q0. Incoming z<0 ensures j0+(-z).toNat>=j0+1, so its modulus reduces to2^(j0+1). The raw nonswap update gives another representative r0+(g%2)2^j0 for G'q0^(-1). Subtracting the two congruences and canceling q0 proves their difference divisible by2^(j0+1). Both lie in that interval, so uniqueness gives

    r=r0+(g%2)2^j0.

Dividing by2^j0 kills r0 and leaves g%2=bbit(s). The public ladder_witness is therefore a conditional residue-identification helper, not a source anchor allowed to assume its hfv/hq/r/hdvd inputs.

ladder_exists constructs exactly the needed outgoing witness from the input low field, choosing j'=j0+1>=2,q'=q0,r'=r0+(g%2)2^j0 and proving all bounds/divisibility. ladder_core sets j to the actual output valuation and q to the actual quotient; the canonical-factor lemma identifies these with the constructed j',q'. It returns the residue plus its oddness, factorization, bounds, congruence, and deciding bit. Because j>=2 was already derived, natural j-1 is genuine subtraction here, not a truncated-index bug. The core converts division by2^(j-1) into bitk using r<2^j.

bitk(u,k)=u%2^(k+1)/2^k is an Int-valued definition. With positive power-of-two modulus it takes the kth residue bit, including negative u; the codomain Int does not itself assert 0/1, but the bounds make it so mathematically. It is not a sign-magnitude or natAbs bit function. Casts such as (u : ZMod(2^j)), (.val : Int), and nested (zStep s) in result types are expression parameters, not theorem binders.

inv_val_eq_of_witness proves that the canonical .val of u*q^(-1) in ZMod(2^j) equals the supplied r. It explicitly creates NeZero(2^j), proves the cast of odd q is a unit using coprimality, casts the integer congruence, cancels using the unit-inverse theorem, and uses ZMod.val_intCast plus residue bounds. Thus cancellation is not performed on an arbitrary nonunit. Off the odd domain the underlying inverse operator may be total, but no theorem here relies on arbitrary nonunit inverse behavior.

ladder applies ladder_core then inv_val_eq_of_witness to obtain the first A11-style expression. It has Inv and z<0 as assumptions and hj/hq as aliases identifying the actual outgoing depth and quotient. The internal witness/range/congruence/oddness obligations are discharged, not remaining public hypotheses. It does not require odd p because this first form only uses the low part of Inv on a nonswap. It also does not require g!=0: it is a generalized statement about zStep on invariant states even if that raw step is not scheduled by the frozen walk. Specialization to the source active domain requires choosing s=zWalk(p,w,t), supplying Inv with invariant_zWalk, and using g!=0 to identify zWalk(t+1)=zStep(s).

ladder_det also assumes p odd, supplies Inv of the outgoing zStep, and proves f'q odd. It forms

    2^j | p-f'q r

by subtracting the output determinant relation from f' times the outgoing window congruence, with 2^j|F'. It then applies the SAME inverse-residue helper with u=p and multiplier f'q. This is a direct arithmetic implementation of the source determinant bridge. Its proof does not call ladder, but both depend on ladder_core. The source graph and these lexical proof-call routes should not be conflated: the source presents the second formula as substitution into the first, whereas the implementation proves both with a common canonical residue.

## 7. Finite dependence and depth-two identity

finite_dependence quantifies an arbitrary j:Nat and returns an explicit total function decode:ZMod(2^j)->ZMod(2^j)->Int, namely the bit of p*(fbar*qbar)^(-1). Its result universally quantifies s and conditionally requires Inv, z<0 and the correct output depth. Hence j=0/1 instances are vacuous on that domain: ladder_exists forces j>=2. The only header inputs are implicit p, hp and explicit j; the occurrence of `(zStep s)` and typed quotient casts are not new binders. The returned function is explicitly constructed, not chosen from an assumed existence theorem. The actual equality uses ladder_det with q definition reflexively. Two residues provide the source's at-most2j-bit information bound, but no explicit bit-vector cardinality theorem, optimal bit count, circuit size theorem, cost of finding j or supported finite register width is proved here.

j2_mod assumes the output coefficient residue modulo8 is4, hence F'=4q with odd q. It forms r=G'q mod4, proves q^2 congruent1 modulo4 by q=2k+1 and constructs divisibility G'-qr. ladder_witness identifies b with r/2. It then splits the two odd residues G'%4 and q%4 into1 or3 and checks the four concrete algebraic cases to yield

    b=(G'%4/2+F'%16/8)%2.

j2_law starts from actual valuation2, uses ladder_exists and canonical valuation to identify its factor exponent as2, obtains F'%8=4, invokes j2_mod, and unfolds bitk. Thus its modulo2 sum equals the XOR of the two residue bits in source A14. This does not require the special prime, merely odd p for G' odd, and remains over unbounded signed integers.

## 8. Exact source correspondence and non-closure

The source contract p odd positive and 0<=w<p is a subset of target's odd-integer p and arbitrary x domain. The missing positivity/range binders are generalization, not a weakening on the original source locus. Where a theorem takes Inv instead of literal reachability, invariant_zWalk explicitly supplies ALL four fields; no source result is assumed as an unexplained structure field. However those conditional theorem headers are not themselves literal source-anchor headers, and the direct all-active actual-walk source wrappers are not written in the target.

A1/A2 with prose freezing correspond to zSeed/zStep/zWalk as a combined interface, not to zStep alone. Equations A3/A4 determinant algebra, A5 scaling, A7 branch classification, A8-A10 window, A11-A12 decoder, Corollary A.7 finite dependence and A14 depth-two law have concrete arithmetic support as detailed above. Source Proposition A.3 (590 steps, special modulus prime, external Wuille result) is not established by this target or the two supplied providers. A13's indexed accumulated-history formula is also not explicitly formalized; the local witness update supplying its natural induction step is present. Source A6 needs the inverse-power existence/definition bridge described above. Source valuation infinity at0 differs from the library's finite valuation totalization; nonzero guards and the explicit zero branch protect the actual uses, as confirmed by the precisely supplied library definitions below.

There is no finite-bit register model, overflow theorem, coherent-circuit semantics, phase/MBU cleanup, global reversible extension, scheduled termination bound, 533-step success contract or resource theorem in this target. No compilation or source-fidelity acceptance is claimed by this first reading. Exact requested definition inputs and audit dispositions are recorded separately; unknowns are not inferred from theorem names.

## 9. Requested library-definition inspection

The supplied additional-definition manifest L/definitions.json is pinned at SHA256 6736c20b216fb71cc92cd3b1fd6fe01b9e33fa514d03b46f3879b97f447acd4d, with actual host Mathlib commit db584cd6d46c92f209a44c0f1c829460d327499d. Only requested definition regions and needed complete declarations were inspected; no whole-library audit or TCB completeness is asserted.

L/Mathlib/NumberTheory/Padics/PadicVal/Basic.lean:87-119 defines padicValInt(p,z)=padicValNat(p,z.natAbs) and explicitly proves its zero value is0. L/Mathlib/Data/Nat/MaxPowDiv.lean:35-115 defines maxPowDvdDiv returning (0,n) if p<=1 or n=0, and padicValNat as its first component; the zero-right theorem also states0. Thus use of natAbs is correct for valuation (not bits), and the difference from source v2(0)=infinity is real. The nonzero multiplicativity declaration at Basic:683 requires both factors nonzero, which the target's odd-factor proof supplies. The divisibility equivalence at Basic:670 has conclusion p^n|a iff a=0 OR n<=padicValInt p a. The target uses this exact disjunction plus a nonzero proof to exclude valuation1 on a multiple of4; it does not silently drop the zero disjunct.

L/Mathlib/Data/Int/ModEq.lean:30-34 defines a congruent b modulo n as a%n=b%n, and :109-111 states equivalence with n dividing b-a (that sign order matters in the casting bridges). L/Init/Data/Int/DivMod/Basic.lean:72-118 defines the actual / and % instances as Int.ediv and Int.emod. For a negative integer -(m+1) and positive divisor n+1, ediv is -(m/(n+1)+1), and emod is the nonnegative complementary residue n+1-(1+(m%(n+1))). Consequently for positive modulus these are Euclidean rather than truncation-toward-zero operations. Every source recurrence numerator is shown even on its intended domain, so either representation of the exact half agrees, while negative digit extraction specifically needs the Euclidean remainder. The arithmetic denominator powers of2 are nonzero and positive throughout actual bit/quotient use.

L/Mathlib/Data/ZMod/Defs.lean:142-144 defines ZMod0=Int and ZMod(n+1)=Fin(n+1); the commutative-ring instance supplies ordinary residue arithmetic and casts. L/Mathlib/Data/ZMod/Basic.lean:57-59 defines val at modulus0 as natAbs and at positive modulus as the Fin representative. Since every decoder modulus is2^j>0, the natAbs val-at-modulus0 branch is never used. The complete val_intCast declaration at :501-505, under NeZero n, states the Int cast of the natural val equals a%n, confirming signed input semantics. The integer-cast equality declaration at :516-517 identifies cast equality with divisibility of b-a.

Basic:712-717 defines a total inverse operator: at modulus0 it is Int.sign; at modulus n+1 it is the cast of Nat.gcdA(a.val,n+1), an extended-gcd coefficient. In particular nonunit values are not supplied with a true multiplicative inverse. The complete mul_inv_eq_gcd theorem at :725-740 states a*a^(-1) equals the cast of gcd(a.val,n), while mul_inv_of_unit at :845-847 requires IsUnit a and then gives1. The target's inv_val_eq_of_witness explicitly proves that unit condition from oddness before cancellation; no generalized nonunit cancellation is hidden in the notation. Expanding the full gcd algorithm is unnecessary for the on-unit theorem used here.

The final requested supplement U/definition.json is pinned at SHA256 5c57717128d4020e089dd57d6ce52163edf16d9d598c70102fe780a92fa45172. Its masked U/Mathlib/Data/ZMod/Units.lean is SHA256 62838d7e9cc4129826203ed63d0361b1c504fa5b2d07c12fd7fff86949d06853. Its actual complete declaration at lines156-167 is forall (n:Int)(m:Nat), IsUnit(n:ZMod m) iff IsCoprime(m:Int)n. The relevant namespace is ZMod with only implicit natural n,m ambient variables; preceding `open Nat in` and `set_option ... in` are individually scoped commands, not extra hypotheses. The constructor unitOfIsCoprime at140-145 builds a unit from the coprimality proof, and its two multiplication-equals-one suppliers are complete declarations at117-130. Hence the target's exact .mpr use with modulus2^j and odd q has the correct orientation and no hidden additional modulus/unit hypothesis. This closes the requested definition-identification uncertainty, without asserting that all transitive proof dependencies were audited or that the target compiles.
