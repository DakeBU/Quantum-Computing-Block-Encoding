# Formal-only reconstruction: signed transition and recovery identities

Status: FORMAL_RECONSTRUCTION_ONLY. This is an independent reading of the supplied, comment-masked Lean text. No source statement, intended conclusion, prior verdict, compilation result, simulator output, or other review was supplied or consulted. Statements below describe the declarations and proof arguments in that text, not a claim of kernel acceptance or source agreement. The exact literal headers and full command snapshots are in `inventory.json`.

## 1. Carrier, arithmetic and definitions

Work in the namespace `Hddivsteps`. Write a state as S=(z,f,g,F,G), where all five coordinates are unbounded signed integers; F and G denote the fields `fv` and `gv`. The ambient command is exactly `variable {p x : Int} {s : ZState}`. These are scoped variables, not three extra hypotheses automatically present in every theorem. Explicit and ambient binder information is recorded separately in the inventory.

Let b=g % 2 and sigma(S) mean z>=0 and b=1. The total, literal definition T=`zStep` is

* if sigma: T(S)=(-z,g,(g-f)/2,2G,G-F);
* otherwise: T(S)=(z+1,f,(g+b f)/2,2F,G+b F).

These definitions have no oddness, coprimality, positivity or nonzero precondition. Division and remainder are Lean integer Euclidean operations, not rational division. With positive divisor 2, negative inputs still have remainder 0 or 1. A quotient in the total definition need not be an exact halving for an arbitrary state. In invariant-controlled proofs, f is odd and each branch's numerator is proved divisible by 2 before cancellation. No truncation-error theorem for arbitrary states is being asserted.

The total literal function `bbit S` is f % 2 on the sigma branch and g % 2 otherwise. In particular, the definition itself does not replace its swap value by 1; `bbit_of_swap` needs f % 2=1 to conclude 1.

The seed is S_0(p,x)=(0,p,x,0,1). The walk W_t=`zWalk p x t` has W_0=S_0 and W_(t+1)=W_t if its g=0, otherwise T(W_t). It is a frozen walk. In contrast, T itself has no stopping guard and still changes z and F when g=0. Do not substitute T(W_t) for W_(t+1) after a zero has occurred.

The literal bit function is `bitk u k = u % 2^(k+1) / 2^k`, for integer u and natural k. Thus bits here are extracted from the bounded Euclidean residue, including for negative u. Natural subtraction j-1 saturates at zero; negative-state ladder witnesses force j>=2 internally, so that saturation does not affect their valid instances.

All target definitions and structures are literal formulas/records. There is no `noncomputable`, classical-choice definition, quotient state, global-phase representative, or unique-characterization construction in this target. ZMod's residue value is a library canonical representative used in formulas, not a project-defined choice of a state. The local inverse-value proof establishes its equality with a bounded integer witness under the stated hypotheses.

## 2. Exact invariant bundle and its scope

`Inv p S : Prop` contains precisely these four fields:

1. det: f G - g F = p.
2. fodd: f % 2 = 1.
3. high: if z>=0, then 2^(z.toNat+1) divides F.
4. low: if z<0, there exist j:Nat and q,r:Int with j>=1, q % 2=1, F=2^j q, 0<=r<2^j, and 2^(j+(-z).toNat) dividing G-q r.

There is no hidden fifth field: no x, walk index, reachability witness, nonnegative f/g promise, prime modulus, termination bound, modular scaling equation, circuit, amplitude, or resource bound. q may be negative; its oddness implies it is nonzero. `toNat` discards a negative integer's sign by returning zero on negative input, but each significant exponent is guarded: z.toNat is used in high for z>=0, and (-z).toNat in low for z<0.

The proofs first derive F even from either high's positive exponent or low's j>=1. With the separate assumption p % 2=1, the determinant then forces G odd because f is odd and gF is even.

`Inv.zStep` proves preservation assuming `Inv p S` and p odd. The determinant checks use exact halving of the branch numerator. The valuation-window portion is constructive at the witness level:

* Swap with z=0 supplies the new high divisibility by 2. Swap with z>0 enters the negative region and uses j'=1, q'=G, r'=1; its divisibility reduces to old high divisibility of F.
* Nonswap in the nonnegative region increases the required exponent by one along with F->2F. Crossing from z=-1 to z'=0 requires only divisibility of 2F by 2.
* Remaining negative nonswaps update old low witnesses as j'=j+1, q'=q, and r'=r for b=0 or r'=r+2^j for b=1. The combined exponent stays j+(-z).toNat, and G'-q r' equals G-q r.

`inv_zSeed` establishes the bundle for every x when p is odd: determinant p, odd f=p, high divides F=0, low premise impossible at z=0. Induction through the walk guard gives `invariant_zWalk` at every natural t, preserving the invariant unchanged on a frozen step. `det_zWalk`, `parity_zWalk`, and `window_zWalk` expose consequences without extra reachability premises.

For arbitrary S the public recovery lemmas take `Inv p S` as an external hypothesis. Reachability is not inferred from that bundle. For instantiated walk states, the module does supply Inv internally via `invariant_zWalk`; users can apply this producer. This distinction is substantive: the general invariant-domain statements are not merely statements about states actually visited from a seed.

## 3. Relation to the provider walk

The necessary provider carrier `HDState` has integer fields delta,f,g,d,e,modulus. `hdInit f g` sets (delta,f,g,d,e,modulus)=(1,f,g,0,1,f). `div2M M a` is `(if a % 2=1 then a+M else a)/2`. `hdStep` always steps:

* even g: delta->delta+2, g->g/2, e->div2M modulus e, retaining the other fields;
* odd g and delta>0: delta->2-delta, f->g, g->(g-f)/2, d->e, e->div2M modulus (e-d), retaining modulus;
* odd g and delta<=0: delta->delta+2, g->(g+f)/2, e->div2M modulus (e+d), retaining f,d,modulus.

`hdRun n f g` is n repetitions of hdStep from hdInit. `zWalk_hdRun p x t` has no mathematical premises and states exactly: W_t.f=(hdRun t p x).f, W_t.g=(hdRun t p x).g, and W_t.g!=0 implies (hdRun t p x).delta=2 W_t.z+1. The proof inducts on t, splits the frozen case, then even/odd g and signed z. It deliberately supplies the delta relation only when active. It does not identify F or G with HDState.d or e, and it does not identify the whole states. At zero, the always-stepping HDState still has zero g and unchanged f, which suffices for the two unconditional coordinates.

The private `gcd_zWalk` uses that f/g comparison and the provider theorem `gcd_hdRun_eq`. The provider proof preserves odd f and proves gcd preservation by cancelling a factor of 2 against odd f, using gcd invariance under adding/subtracting f and swapping arguments. Int.gcd has natural-number output, so the terminal comparison is with f.natAbs, not f itself.

Other dyadic/hull/certificate definitions present in the provider file do not occur in the target's displayed arguments. They are not evidence of a bound or computation for this target. In particular, the provider filename and constants do not add a fixed step count to any Recovery theorem.

## 4. Scaling, endpoints and exact terminal theorem types

Fix odd integer p and arbitrary integer x. No primality, p>0, p>1, or range 0<x<p is assumed in the target. Oddness excludes p=0 but allows negative p and p=+/-1. Coprimality is needed only for the endpoint/inverse chain. There is no stated termination theorem or existence of a terminal t.

`scale_zWalk` requires H_act(t): for every natural u<t, W_u.g!=0. It concludes both congruences

    W_t.F * x == 2^t * W_t.f (mod p),
    W_t.G * x == 2^t * W_t.g (mod p).

Initialization is (0*x == p) and (1*x == x). Each active transition doubles the f coefficient and combines the g coefficient according to the branch; exact numerator divisibility converts the right-hand side into the next 2-power. The activity premise is used at the current induction step to rule out the frozen guard. The statement is not a congruence invariant with exponent equal to wall-clock walk time after freezing.

`endpoint_zWalk` has implicit p,x:Int and explicit premises hp:p%2=1, hcop:Int.gcd p x=1, t:Nat, h0:W_t.g=0. It concludes

    W_t.f.natAbs = 1 AND W_t.G = W_t.f * p.

No H_act premise is needed for that theorem. Gcd gives abs(f)=1, and det with g=0 gives fG=p; checking f=+1 and f=-1 yields the second equality. The sign is retained, not silently normalized to f=1 or G=p.

`inverse_zWalk` has implicit p,x:Int and explicit hp, hcop, t, H_act(t), h0 as above. Its exact conclusion is

    W_t.f * W_t.F * x == 2^t (mod p).

The endpoint sign squares to 1. Multiplying the f scaling congruence by terminal f gives the result. This is a scaled inverse congruence, not an unscaled inverse coefficient by itself.

`inverse_zWalk_unscaled` has the same premises and additionally a:Int with ha:2^t*a == 1 (mod p). Its conclusion is

    W_t.F * a * W_t.f * x == 1 (mod p).

The proof multiplies the previous congruence by a and rearranges. The inverse-scaling witness a is external here; the module does not construct it in this theorem. The two activity-and-terminal premises identify a first zero time (possibly t=0) rather than an arbitrary late frozen time. At t=0 activity is vacuous; h0 means x=0, and hcop forces |p|=1. These degenerate congruence cases are not excluded.

These are the terminal theorems in the arithmetic sense. The final textual declarations are `finite_dependence` and `j2_law`; their exact types are given below and retained literally in the inventory. Neither claims termination.

## 5. Branch classification and elementary recovery cases

The private swap test proves, under Inv and odd p, sigma(S) iff T(S).F % 4=2: the swap coefficient is twice an odd G, while the nonswap coefficient is twice an even F. `sigma_class` packages three statements:

    (sigma iff T.F == 2 (mod 4)) AND
    (sigma iff padicValInt 2 T.F = 1) AND
    (not sigma -> 4 divides T.F).

The nonswap zero case is treated separately in its proof: at T.F=0 the library padicValInt expression simplifies to zero, so it must not be described as an infinite valuation. Otherwise divisibility by 4 rules out valuation 1. This zero convention matters.

`bbit_of_ramp` assumes not sigma and 1<=T.z, from which old z>=0; an odd g would then contradict not sigma, so bbit=0. `bbit_of_freeze` assumes f odd, old g!=0 and T.g=0. It concludes bbit=1: the swap case is immediate; nonswap with even g would give g/2=0 and hence g=0, a contradiction. This is a direct-step lemma, not a statement that every frozen walk update has bit 1.

## 6. Negative-region ladder: the actual mathematics of recovery

The private odd-factor lemma states that if n=2^j*q with q odd (signed), then padicValInt 2 n=j and n/2^j=q. It proves this by multiplicativity, odd q's zero valuation and the valuation of a power of two. Consequently two such factorizations have the same exponent and odd part. Another local lemma cancels an odd q from 2^k | q*m using coprimality. Bounded congruent representatives are equal by reducing both modulo n.

For Inv p S and z<0, sigma is false regardless of g. Let old low witnesses be j0>=1, odd q, r0 in [0,2^j0), with F=2^j0*q. The successor satisfies

    T.F=2^(j0+1)*q,
    T.G == q*(r0+b*2^j0) (mod 2^(j0+1)),
    0 <= r0+b*2^j0 < 2^(j0+1).

Old divisibility is strong enough because (-z).toNat>=1. Thus the successor bounded residue consists of the old residue with b as its new highest bit. This construction is `ladder_exists`, with j'=j0+1>=2. It needs Inv and z<0, not odd p as an extra premise.

`ladder_witness` accepts any factorization T.F=2^j*q with q odd and any bounded r in [0,2^j) satisfying 2^j | T.G-q*r. It concludes `r/2^(j-1) = bbit S`. Factorization uniqueness identifies j with j0+1 and q with the old odd part; cancellation and bounded representative uniqueness identify r with r0+b*2^j0. Division recovers b. A premise j>=2 is not missing: this is derived from the old low witness rather than added to the public header.

`ladder_core` specializes to j=padicValInt 2 T.F and q=T.F/2^j and produces the bounded r, factorization, oddness, divisibility and `bitk r (j-1)=bbit S`. `inv_val_eq_of_witness` identifies that r with the canonical integer value of `(T.G : ZMod(2^j))*(q : ZMod(2^j))^-1`. Odd q is shown a unit. No interpretation of inversion on a nonunit is needed on this valid domain.

Therefore `ladder` has implicit p,s,j,q, explicit h:Inv p s, hz:s.z<0, hj:j=padicValInt 2 (zStep s).fv, hq:q=(zStep s).fv/2^j, and concludes

    bbit S = bitk (val((T.G mod 2^j) * (q mod 2^j)^-1)) (j-1).

There is no separate p-odd hypothesis in `ladder`.

`ladder_det` adds p odd. Successor Inv gives T.f odd and T.f*T.G-T.g*T.F=p; since 2^j divides T.F, the same bounded r satisfies p == T.f*q*r (mod 2^j). The product T.f*q is odd and hence a unit. Its conclusion is

    bbit S = bitk (val((p mod 2^j) * ((T.f*q) mod 2^j)^-1)) (j-1).

The modular inverse is multiplication by an odd unit's inverse in a finite residue ring. This is a mathematical formula, not a proved low-cost implementation of that inverse.

`finite_dependence` has only implicit p:Int, explicit hp:p%2=1 and j:Nat before the result colon. Its result contains the existential decoder and the state quantifiers:

    exists decode : ZMod(2^j) -> ZMod(2^j) -> Int,
      for every S:ZState, Inv p S -> S.z<0 ->
        j=padicValInt 2 T(S).F ->
        bbit S = decode (T(S).f mod 2^j) ((T(S).F/2^j) mod 2^j).

The displayed lambda witness is explicitly

    decode(fbar,qbar) = bitk (val((p mod 2^j)*(fbar*qbar)^-1)) (j-1).

The decoder is allowed to depend on p and j and is total as a Lean function on all pairs of residue classes; its correctness is only asserted on the image of states satisfying those three conditions. It is not asserted that every pair is attainable or that Inv implies reachability. For j=0 or 1 there are no qualifying negative-state successor instances, by the internal j>=2 witness argument. The theorem does not provide a circuit, a lookup table, memory bound, uniform bit complexity, or constant-depth construction.

Finally `j2_law`, under h:Inv p S, odd p, z<0 and padicValInt 2 T.F=2, concludes exactly

    bbit S = (bitk T.G 1 + bitk T.F 3) % 2.

The proof obtains T.F=4q with q odd, hence T.F % 8=4. The private `j2_mod` uses r=(T.G*q)%4; an odd q satisfies q^2==1 mod 4, so this r meets the ladder congruence. It checks the four combinations of odd q and odd T.G modulo 4, yielding bbit=(T.G%4/2 + T.F%16/8)%2. Expanding bitk gives the final two-bit formula. This is a specialized valuation-two identity, not a replacement of the general ladder formula for all j.

## 7. Internal producers versus external conditions

Internally supplied: seed construction; Inv from odd p for all walk times; F even; G odd with odd p; branch classification; f/g agreement with hdRun; gcd preservation through that provider; low-region nonzero F and its unique odd factor; ladder bounded residue, successor j>=2, and unit conditions; explicit existential decoder formula.

Externally supplied where their headers require them: arbitrary-state Inv; odd p where stated; coprimality for endpoint/inverse; selected terminal time and g=0; activity before t for scaled congruences; inverse-scaling witness a for the unscaled endpoint; negative z; valuation-index equality and odd-part equality when exposed as j,q; valuation-two hypothesis for j2_law. The explicit j,q equalities are parameter identifications, not free oddness assumptions—the proof derives the latter.

Source-relative binder labels SOURCE/STANDING/RULED/EXCESS cannot be assigned honestly without source release. All mathematical conditions are therefore recorded as FORMAL_CONDITION_UNCOMPARED; carrier data are TYPING. No absence of a source mismatch is claimed.

## 8. Architecture and remaining boundary

The implementation's conceptual chain is literal signed transition -> invariant preservation from seed -> arithmetic projections and provider walk comparison -> gcd/terminal scaled inverse; and, separately, invariant windows -> bounded successor residue -> unique odd factor -> modular inverse representation -> bit recovery -> determinant-eliminated finite dependence -> valuation-two specialization. These are text-read proof roles, not an elaborated dependency graph. The inventory preserves every public/private command and exact body so the chain can be checked without trusting a theorem-name list.

No vector space, Hilbert space, basis action, unitary, gate list, ancilla register, coherent control, phase relation, probability, operator equality, reversible embedding, cleanup theorem, or gate/query/finite-bit cost model occurs in the target. The arithmetic reconstruction cannot by itself establish any physical operation or resource claim. The distinct uncertainty fingerprint remains `exact-formal-signed-state-and-invariant-vs-physical-action`.

External Mathlib definition bodies were not made available within the six-file scope. This reconstruction relies on standard typed arithmetic notation and on the concrete restricted-domain consequences proved by the local helper bodies; it does not invent off-domain inverse semantics or a complete external API contract. No missing external definition is needed to state the formal formulas exactly. If later review requires an off-domain or global library interpretation, request that exact pinned definition before extending these claims.

The supplied Recovery snapshot has 819 logical lines, begins with comment-masked whitespace, enters `namespace Hddivsteps` at line 53, and ends after the body of `j2_law` with `norm_num` at line 819. There is no visible closing `end Hddivsteps` command in that snapshot. This is recorded as literal text, not a compiler diagnosis. The configured Lean version is 4.33.0 and the manifest pins Mathlib revision `db584cd6d46c92f209a44c0f1c829460d327499d`; these are supplied host-context pins, not evidence that this target was built with them.

Residuals: independent source comparison withheld; compilation and dependency elaboration not performed; full imported-library definition audit not performed; supplied comment masker is not independently certified as a Lean lexer/noninterference proof; generated structure projections/recursors and private-name mangling are not compiler-inventoried. No local admission, ROOT, or PURIFIED claim is made.
