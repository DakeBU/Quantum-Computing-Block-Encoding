param([Parameter(Mandatory=$true)][string]$InputRoot)
$ErrorActionPreference = 'Stop'
$outputRoot = $PSScriptRoot
$utf8 = [System.Text.UTF8Encoding]::new($false)
function Hash-Text([string]$text) {
  $sha = [System.Security.Cryptography.SHA256]::Create()
  try { return [Convert]::ToHexString($sha.ComputeHash($utf8.GetBytes($text))).ToLowerInvariant() }
  finally { $sha.Dispose() }
}
function Hash-File([string]$path) { return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Write-Json([string]$name, $value) {
  $json = ($value | ConvertTo-Json -Depth 100) -replace "`r`n", "`n"
  [IO.File]::WriteAllText((Join-Path $outputRoot $name), $json + "`n", $utf8)
}
function Position([string]$text,[int]$offset) {
  $prefix = $text.Substring(0,$offset)
  $line = ([regex]::Matches($prefix,"`n")).Count + 1
  $last = $prefix.LastIndexOf("`n")
  return [ordered]@{char_offset_0=$offset;byte_offset_0=$utf8.GetByteCount($prefix);line_1=$line;column_1=$offset-$last}
}
function Result-Colon([string]$header) {
  $depth = 0
  for ($i=0;$i -lt $header.Length;$i++) {
    $c = $header[$i]
    if ('({['.Contains([string]$c)) { $depth++ }
    elseif (')}]'.Contains([string]$c)) { $depth-- }
    elseif ($c -eq ':' -and $depth -eq 0 -and ($i+1 -eq $header.Length -or $header[$i+1] -ne '=')) { return $i }
  }
  return -1
}
function Header-Binders([string]$prefix) {
  $binders = @()
  $depth=0; $begin=-1
  for ($i=0;$i -lt $prefix.Length;$i++) {
    $c=$prefix[$i]
    if ('({['.Contains([string]$c)) { if ($depth -eq 0) { $begin=$i }; $depth++ }
    elseif (')}]'.Contains([string]$c)) {
      $depth--
      if ($depth -eq 0 -and $begin -ge 0) { $binders += $prefix.Substring($begin,$i-$begin+1); $begin=-1 }
    }
  }
  return ,$binders
}
$manifestPath=Join-Path $InputRoot 'formal-inputs.json'
$inputDigest=Hash-File $manifestPath
if ($inputDigest -ne 'ad146ba5675183393c5eef47f12d5a7d51754c6f250272908575dc0777f17ca6') { throw 'Input manifest digest mismatch' }
$inputManifest=Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json
$pinRecords=@()
foreach ($f in $inputManifest.files) {
  $fp=Join-Path $InputRoot $f.path
  $actual=Hash-File $fp
  $length=(Get-Item -LiteralPath $fp).Length
  if ($actual -ne $f.formal_sha256 -or $length -ne $f.bytes) { throw ('Input pin mismatch: '+$f.path) }
  $pinRecords += [ordered]@{path=('W/uncompute-c84-formal-input/'+$f.path);scope=$f.scope;observed_sha256=$actual;formal_sha256=$f.formal_sha256;original_raw_sha256_declared_only=$f.raw_sha256;original_raw_available=$false;bytes=$length}
}
$targetPath=Join-Path $InputRoot 'Hddivsteps590/Recovery.lean'
$target=[IO.File]::ReadAllText($targetPath,$utf8)
$commands=[regex]::Matches($target,'(?m)^(?:import\b|namespace\b|variable\b|structure\b|def\b|theorem\b|private theorem\b|end\b)[^\r\n]*')
$ambient=@{
  zStep_swap=@('s');zStep_nonswap=@('s');bbit_of_nonswap=@('s');zWalk_succ=@('p','x');
  'Inv.fveven'=@('p','s');'Inv.gvodd'=@('p','s');'Inv.zStep'=@('p','s');inv_zSeed=@('p','x');
  invariant_zWalk=@('p');det_zWalk=@('p');parity_zWalk=@('p');scale_zWalk=@('p');gcd_zWalk=@('p');
  endpoint_zWalk=@('p','x');inverse_zWalk=@('p','x');inverse_zWalk_unscaled=@('p','x');swap_iff_fv=@('p','s');
  bbit_of_swap=@('s');bbit_of_ramp=@('s');bbit_of_freeze=@('s');ladder_witness=@('p','s');
  ladder_exists=@('p','s');j2_mod=@('p','s');sigma_class=@('p','s');window_low=@('p','s');
  window_zWalk=@('p');ladder_core=@('p','s');ladder=@('p','s');ladder_det=@('p','s');
  finite_dependence=@('p');j2_law=@('p','s')
}
$roles=@{
  ZState='Literal five-integer carrier; no validity or reachability fields.';
  zStep='Literal total signed transition; unguarded by terminal g=0.';
  bbit='Literal old-state branch-associated parity, not a physical bit register.';
  zStep_swap='Unfolds the positive branch using supplied branch predicate.';
  zStep_nonswap='Unfolds the other branch using negated predicate.';
  bbit_of_nonswap='Unfolds bbit in nonswap case.';
  zSeed='Literal initialization (0,p,x,0,1).';
  zWalk='Primitive recursion with frozen g=0 guard.';
  zWalk_succ='Definitional equation for guarded successor.';
  zWalk_hdRun='Induction aligns f/g with provider hdRun; delta alignment only while g nonzero, splitting frozen/even/odd/signed-z cases.';
  Inv='Literal four-field Prop: determinant, odd f, high divisibility, conditional low existential witness.';
  'Inv.fveven'='High exponent or low positive j supplies divisibility by two.';
  'Inv.gvodd'='Determinant and f odd with F even force G odd when p odd.';
  'Inv.zStep'='Exact halving preserves determinant; swap introduces low witness (1,G,1); negative nonswap shifts j and optionally adds 2^j to r; high boundary z=-1 handled separately.';
  inv_zSeed='Seed determinant and parity; high divides zero; low antecedent impossible.';
  invariant_zWalk='Induction preserving Inv on active steps and retaining it under freeze.';
  det_zWalk='Projection from internally produced walk invariant.';
  parity_zWalk='Projects odd f, odd G and even F from walk invariant.';
  modEq_congr='Private equality transport of integer modular equivalence.';
  scale_zWalk='Active-prefix induction; branchwise modular linear combinations and exact-halving identities give both scaled coefficients. No post-freeze extension.';
  gcd_zWalk='Private transport through f/g walk comparison into provider gcd preservation.';
  endpoint_zWalk='At g=0 use gcd for |f|=1, then determinant to infer signed G=f*p.';
  inverse_zWalk='Multiply first scale congruence by terminal f; endpoint gives f^2=1.';
  inverse_zWalk_unscaled='Multiply scaled inverse congruence by externally supplied inverse-scaling witness a.';
  swap_iff_fv='Twice odd G is 2 mod4; twice even F is not.';
  bbit_of_swap='Swap bbit equals odd f remainder.';
  bbit_of_ramp='Nonswap with new z>=1 implies old z>=0, ruling out odd g.';
  bbit_of_freeze='Direct step from nonzero g to zero requires parity one; even nonswap would contradict old g nonzero.';
  padicValInt_of_odd_factor='Valuation multiplicativity and odd-factor zero valuation; exact power-of-two quotient.';
  two_pow_mul_odd_inj='Uniqueness of exponent and signed odd part using preceding valuation and quotient facts.';
  isCoprime_two_pow='Odd q is coprime to every power of two.';
  pow_two_dvd_cancel='Coprimality cancels odd multiplier from power-of-two divisibility.';
  eq_of_sub_dvd_of_bounds='Equal bounded residues modulo n are equal integers.';
  ladder_witness='Identify successor factorization with old j0+1; cancel odd factor and use bounded representatives to get r=r0+b*2^j0; top quotient gives bbit.';
  ladder_exists='Explicit successor low-residue witness j0+1>=2,q0,r0+b*2^j0 from negative old z.';
  j2_mod='Choose q=Fprime/4 and r=Gprime*q mod4, justify q^2=1 mod4, then four odd-residue cases yield two-bit parity law.';
  bitk='Literal Euclidean residue bit extraction for integer input and natural position.';
  inv_val_eq_of_witness='Odd q gives a unit in ZMod(2^j); congruence and boundedness identify modular inverse-product value with r.';
  sigma_class='Packages modulo-four and valuation-one branch tests; treats zero F separately in nonswap valuation case.';
  window_low='Convert low odd factor into valuation and exact quotient; establish F nonzero and larger-modulus congruence.';
  window_zWalk='High projection and window_low from internally produced walk invariant.';
  ladder_core='Specialize explicit low witness to actual valuation/odd part; package modular residue and top-bit identity.';
  ladder='Replace ladder_core residue by ZMod inverse-product canonical value.';
  ladder_det='Successor determinant replaces G by p and denominator q by fprime*q; oddness supplies unit.';
  finite_dependence='Explicit lambda decoder parameterized by p,j, using determinant ladder; correctness only on Inv/negative-z/valuation-index locus.';
  j2_law='Valuation-two factorization implies Fprime mod8=4; apply private j2_mod and expand bitk.'
}
$entries=@()
for ($index=0;$index -lt $commands.Count;$index++) {
  $match=$commands[$index]
  $start=$match.Index
  $finish=if($index+1 -lt $commands.Count){$commands[$index+1].Index}else{$target.Length}
  $literal=$target.Substring($start,$finish-$start)
  $first=$match.Value
  $kind=if($first -match '^private theorem'){'theorem'}else{($first -split '\s+')[0]}
  $private=$first.StartsWith('private theorem ')
  $name=$null
  if ($first -match '^(?:private )?(?:structure|def|theorem)\s+(\S+)') { $name=$Matches[1] }
  $bodyStart=-1
  if ($kind -in @('def','theorem')) {
    if ($name -eq 'zWalk') { $bodyStart=$literal.IndexOf('  | 0 =>') }
    else { $bodyStart=$literal.IndexOf(':=') }
    if ($bodyStart -lt 0) { throw ('Unsupported body boundary '+$name) }
  } elseif ($kind -eq 'structure') {
    $where=[regex]::Match($literal,'\bwhere\b')
    if(-not $where.Success){throw 'Missing structure where'}
    $bodyStart=$where.Index+$where.Length
  }
  $header=if($bodyStart -ge 0){$literal.Substring(0,$bodyStart)}else{$literal.TrimEnd()}
  $colon=Result-Colon $header
  $binderPrefix=if($colon -ge 0){$header.Substring(0,$colon)}else{$header}
  $binderLiterals=if($kind -in @('def','theorem','structure')){Header-Binders $binderPrefix}else{@()}
  $body=if($bodyStart -ge 0){$literal.Substring($bodyStart).TrimEnd()}else{$null}
  $used=if($name -and $ambient.ContainsKey($name)){$ambient[$name]}else{@()}
  $entry=[ordered]@{
    ordinal_1=$index+1;kind=$kind;visibility=if($private){'private-source-name'}elseif($name){'public-source-declaration'}else{'ambient-command'};
    name=$name;namespace='Hddivsteps';qualified_source_name=if($name){'Hddivsteps.'+$name}else{$null};
    extent_half_open=[ordered]@{start=(Position $target $start);end=(Position $target $finish)};
    command_sha256_utf8=(Hash-Text $literal);literal_command=$literal;
    literal_header=$header;header_sha256_utf8=(Hash-Text $header);
    result_colon_char_offset_in_header=if($colon -ge 0){$colon}else{$null};
    literal_pre_result_binder_region=$binderPrefix;
    explicit_header_binder_groups=@($binderLiterals);
    literal_result_after_top_level_colon=if($colon -ge 0){$header.Substring($colon+1)}else{$null};
    ambient_variable_command='variable {p x : Int} {s : ZState}';ambient_variables_used_text_read=@($used);
    binder_audit='Carrier inputs TYPING; logical inputs FORMAL_CONDITION_UNCOMPARED; source-relative labels withheld. Parentheses inside result are never classified as header binders.';
    proof_or_definition_body=if($bodyStart -ge 0){[ordered]@{start=(Position $target ($start+$bodyStart));end=(Position $target ($start+$bodyStart+$body.Length));sha256_utf8=(Hash-Text $body);literal=$body}}else{$null};
    text_read_mathematical_role=if($name){$roles[$name]}else{if($kind -eq 'import'){'Import context, not per-theorem dependency certification.'}elseif($kind -eq 'namespace'){'Opens namespace; supplied target has no visible closing end command.'}else{'Scoped implicit variable declaration; only actually used variables enter declaration types.'}};
    definition_kind=if($kind -in @('def','structure')){'literal'}else{$null}
  }
  if($name -and -not $roles.ContainsKey($name)){throw ('Unreviewed named command '+$name)}
  $entries += $entry
}
$publicNames=@($entries | Where-Object {$_.name -and $_.visibility -eq 'public-source-declaration'} | ForEach-Object {$_.qualified_source_name})
$privateNames=@($entries | Where-Object {$_.visibility -eq 'private-source-name'} | ForEach-Object {$_.qualified_source_name})
$preamble=$target.Substring(0,$commands[0].Index)
$logicalLineCount=([regex]::Matches($target,"`n")).Count
if(-not $target.EndsWith("`n")){$logicalLineCount++}
Write-Json 'inventory.json' ([ordered]@{
  schema='TEXT_READ_WHOLE_COMMAND_INVENTORY_V1';status='FORMAL_RECONSTRUCTION_ONLY';target='W/uncompute-c84-formal-input/Hddivsteps590/Recovery.lean';
  target_sha256=(Hash-Text $target);logical_lines=$logicalLineCount;command_count=$entries.Count;
  method='Full target read by decoder; bounded file-specific lexical snapshots are an audit aid, not an elaborated Lean parser or theorem dependency extractor. Header binders stop at actual depth-zero result colon. zWalk uses equation-compiler body boundary. Full command literals preserve all uncertainty.';
  preamble=[ordered]@{start=(Position $target 0);end=(Position $target $commands[0].Index);sha256_utf8=(Hash-Text $preamble);literal=$preamble};
  closing_namespace_command_present=$false;generated_structure_declarations='Not elaborated or enumerated; public-source list is source declarations only.';
  public_source_declaration_allowlist=$publicNames;private_source_names=$privateNames;commands=$entries
})
Write-Json 'pins.json' ([ordered]@{
  schema='FORMAL_ONLY_PINS_V1';input_manifest=[ordered]@{path='W/uncompute-c84-formal-input/formal-inputs.json';sha256=$inputDigest;bytes=(Get-Item -LiteralPath $manifestPath).Length};
  files=$pinRecords;toolchain='leanprover/lean4:v4.33.0';mathlib_revision='db584cd6d46c92f209a44c0f1c829460d327499d';
  config_scope='Actual host context supplied, not claimed upstream configuration or a compiler run.';
  governance_allowlist=@('R/AGENTS.md','R/HARNESS.md','R/docs/theorem-publication-protocol.md','R/docs/proof-digestion-protocol.md','R/docs/evidence-routed-memory-protocol.md','R/.agents/skills/qbe-substantive-worker/SKILL.md');
  R='Repository governance root; host path deliberately omitted';W='Logical workspace root; host path deliberately omitted';
  masking_caveat=$inputManifest.mask_boundary
})
$now=[DateTime]::UtcNow.ToString('o')
Write-Json 'chronology.json' ([ordered]@{
  schema='FORMAL_ONLY_CHRONOLOGY_V1';timestamp_policy='Ordered observed actions; exact past timestamps unavailable and not reconstructed. Only packet-generation timestamp is measured here.';packet_generated_utc=$now;
  ordered_events=@(
    [ordered]@{sequence=1;event='Received formal-only task with supplied manifest hash; source and prior outcomes withheld.'},
    [ordered]@{sequence=2;event='Read exactly six named governance documents, with individual rereads after aggregate output truncation; no linked metadata followed.'},
    [ordered]@{sequence=3;event='Read formal-inputs.json and verified its supplied SHA256.'},
    [ordered]@{sequence=4;event='Read Recovery in sequential chunks through literal EOF, including all private helpers, proof bodies and ambient commands.'},
    [ordered]@{sequence=5;event='Combined provider/config read returned all NumberTheory and Defs provider text plus three config files. Broader than minimal provider retrieval; still inside six-file mathematical allowlist. This scope overshoot was disclosed to parent before sealing.'},
    [ordered]@{sequence=6;event='Confirmed target line count/tail and all six formal hashes; no Lean/Git/native/simulator/web/child-agent execution.'},
    [ordered]@{sequence=7;event='Authored mathematical reconstruction and per-command proof roles; generated exact command/header/body inventory from pinned bytes.'},
    [ordered]@{sequence=8;event='Bound public output allowlist and payload hashes; sealed formal reconstruction before any source release.'}
  );source_released=$false;prior_review_or_compiler_result_received=$false
})
Write-Json 'packet.json' ([ordered]@{
  schema='INDEPENDENT_FORMAL_DECODER_PACKET_V1';decoder_identity='/root/uncompute_formal_decoder_c84';status='FORMAL_RECONSTRUCTION_ONLY';
  input_manifest_sha256=$inputDigest;direction_fingerprint='exact-formal-signed-state-and-invariant-vs-physical-action';
  expected_information_gain='Faithful full signed-state formal semantics and expanded invariant conditions before independent source comparison.';
  reconstruction='W/uncompute-c84-formal-decoder/reconstruction.md';inventory='W/uncompute-c84-formal-decoder/inventory.json';pins='W/uncompute-c84-formal-decoder/pins.json';chronology='W/uncompute-c84-formal-decoder/chronology.json';
  semantic_summary='Signed integer transition, guarded frozen walk, determinant/parity/divisibility-window invariant, conditional endpoint scaled inverse, negative-region modular bit recovery, existential two-residue decoder, valuation-two specialization. No physical action or resource semantics.';
  theorem_surface='Exact source headers and full bodies, including all private commands, retained in inventory; no result-expression parentheses miscounted as declaration binders.';
  source_relative_binder_verdict='UNASSESSED: source withheld';source_agreement=$false;compiled=$false;local_admission=$false;root_claim=$false;purified=$false;
  failure_class='NONE';failure_class_explanation='Formal reconstruction task completed; withheld source and forbidden compilation are scope boundaries, not mathematical failure evidence.';
  external_definitions='No imported Mathlib body consulted. Exact formulas retained; local helper proofs provide restricted odd-factor/unit/zero consequences. Request exact missing pinned definition before stronger off-domain interpretation.';
  residuals=@('Source comparison withheld','Compilation and elaborated dependencies untested','Mask noninterference not independently proved','Generated declarations/private mangling not elaborated','Provider read broader than minimally necessary; disclosed');
  salvage_audit='No failed construction to salvage; no production files changed.';process_memory_ids_consulted=@();
  parallel_work='Independent decoder delegated by parent; no child agents spawned.';common_blind_spot_review='Not performed here; source unavailable.';
  route_comparator='Not applicable: one formal text read, no competing verified constructions.';purification_state='Not asserted; this is a decoder artifact, not reader-facing theorem admission.';
  next_action='STOP after seal. Parent may independently compare this packet only after its pre-release hash is recorded.'
})
$names=@('build-packet.ps1','reconstruction.md','inventory.json','pins.json','chronology.json','packet.json','public-allowlist.json','manifest.json','seal.json')
Write-Json 'public-allowlist.json' ([ordered]@{
  schema='EXACT_PUBLIC_ALLOWLIST_V1';logical_directory='W/uncompute-c84-formal-decoder';paths=@($names | ForEach-Object {'W/uncompute-c84-formal-decoder/'+$_});
  declaration_allowlist_scope='Source-level declared target names, not generated recursors/projections or elaborated private mangling.';
  public_source_declaration_allowlist=$publicNames;private_source_names=$privateNames;no_other_output_paths_authorized=$true
})
$payload=@()
foreach($name in $names | Where-Object {$_ -notin @('manifest.json','seal.json')}){
  $fp=Join-Path $outputRoot $name
  $payload += [ordered]@{path=('W/uncompute-c84-formal-decoder/'+$name);bytes=(Get-Item -LiteralPath $fp).Length;sha256=(Hash-File $fp)}
}
Write-Json 'manifest.json' ([ordered]@{schema='FORMAL_DECODER_MANIFEST_V1';status='FORMAL_RECONSTRUCTION_ONLY';input_manifest_sha256=$inputDigest;files=$payload;seal_rule='Manifest binds all seven payload artifacts; seal binds manifest; seal own hash is handed off externally, avoiding self-reference.'})
Write-Json 'seal.json' ([ordered]@{
  schema='FORMAL_RECONSTRUCTION_SEAL_V1';status='FORMAL_RECONSTRUCTION_ONLY';sealed_utc=[DateTime]::UtcNow.ToString('o');decoder_identity='/root/uncompute_formal_decoder_c84';
  input_manifest_sha256=$inputDigest;manifest=[ordered]@{path='W/uncompute-c84-formal-decoder/manifest.json';sha256=(Hash-File (Join-Path $outputRoot 'manifest.json'))};
  public_allowlist=[ordered]@{path='W/uncompute-c84-formal-decoder/public-allowlist.json';sha256=(Hash-File (Join-Path $outputRoot 'public-allowlist.json'))};
  source_withheld_at_seal=$true;compiler_outcome_withheld_at_seal=$true;source_agreement_not_claimed=$true;compiled_not_claimed=$true;local_admission_not_claimed=$true;root_not_claimed=$true;purified_not_claimed=$true;
  post_seal_rule='Stop before source release; no revision of this sealed reconstruction in response to source.'
})
[ordered]@{command_count=$entries.Count;public_declarations=$publicNames.Count;private_declarations=$privateNames.Count;logical_lines=$logicalLineCount;seal_sha256=(Hash-File (Join-Path $outputRoot 'seal.json'));manifest_sha256=(Hash-File (Join-Path $outputRoot 'manifest.json'));allowlist_sha256=(Hash-File (Join-Path $outputRoot 'public-allowlist.json'))} | ConvertTo-Json
