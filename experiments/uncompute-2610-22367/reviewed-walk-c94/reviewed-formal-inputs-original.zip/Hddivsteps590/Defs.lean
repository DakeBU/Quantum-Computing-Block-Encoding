  
                                 

                                                                     

                                                                       
                                                                        
                                          
                                                                        
                               

                                                                       
                                                                      
                                                               

                                                                    
                                                                  
  

namespace Hddivsteps

                                          

                                                                              
structure D where
  m : Int
  e : Int
deriving BEq

                                                                         
def oddPart (n : Nat) : Nat × Nat :=
  if _h : n = 0 ∨ n % 2 = 1 then (n, 0)
  else
    let (m, k) := oddPart (n / 2)
    (m, k + 1)
termination_by n
decreasing_by omega

                                                                            
def D.red (m e : Int) : D :=
  if m = 0 then ⟨0, 0⟩
  else
    let (om, k) := oddPart m.natAbs
    ⟨if m < 0 then -(om : Int) else (om : Int), e + (k : Int)⟩

                                                            
def D.cmp (a b : D) : Ordering :=
  if a.e ≥ b.e then compare (a.m * 2 ^ (a.e - b.e).toNat) b.m
  else compare a.m (b.m * 2 ^ (b.e - a.e).toNat)

def D.add (a b : D) : D :=
  if a.e ≥ b.e then .red (a.m * 2 ^ (a.e - b.e).toNat + b.m) b.e
  else .red (a.m + b.m * 2 ^ (b.e - a.e).toNat) a.e

def D.sub (a b : D) : D :=
  if a.e ≥ b.e then .red (a.m * 2 ^ (a.e - b.e).toNat - b.m) b.e
  else .red (a.m - b.m * 2 ^ (b.e - a.e).toNat) a.e

def D.mul (a b : D) : D := .red (a.m * b.m) (a.e + b.e)

                                                
def D.half (a : D) : D := if a.m = 0 then ⟨0, 0⟩ else ⟨a.m, a.e - 1⟩

                                                                             

                                                                                 
abbrev DD := D × D

def ddCmp (p q : DD) : Ordering := (D.cmp p.1 q.1).then (D.cmp p.2 q.2)

                                                                          
def orientation (p1 p2 p3 : DD) : Ordering :=
  D.cmp (D.mul (D.sub p1.1 p3.1) (D.sub p2.2 p3.2))
        (D.mul (D.sub p1.2 p3.2) (D.sub p2.1 p3.1))

                                                                          
                                                                    
                                                         
def addPoint (keep : Ordering) (p : DD) : List DD → List DD
  | [] => [p]
  | [q] => if ddCmp p q == .eq then [p] else [p, q]
  | q :: r :: l =>
    if orientation p q r == keep then p :: q :: r :: l
    else addPoint keep p (r :: l)

                                                                    
abbrev DSet := List DD

                                                   
def dedupAdj : List DD → List DD
  | a :: b :: t => if a == b then dedupAdj (b :: t) else a :: dedupAdj (b :: t)
  | l => l

                                                                       
def DSet.ofList (l : List DD) : DSet :=
  dedupAdj (l.mergeSort (fun a b => ddCmp a b != .gt))

                                          
def DSet.union : DSet → DSet → DSet
  | [], l => l
  | l, [] => l
  | a :: t₁, b :: t₂ =>
    match ddCmp a b with
    | .lt => a :: DSet.union t₁ (b :: t₂)
    | .gt => b :: DSet.union (a :: t₁) t₂
    | .eq => a :: DSet.union t₁ t₂
termination_by s₁ s₂ => s₁.length + s₂.length

                                                                         
                                                                    
                                                        
def chainHull (s : DSet) : DSet :=
  DSet.ofList (s.foldl (fun acc p => addPoint .gt p acc) [] ++
               s.foldl (fun acc p => addPoint .lt p acc) [])

                                                       

def oddPosTrans (p : DD) : DD := (D.half (D.sub p.1 p.2), p.1)
def oddNonposTrans (p : DD) : DD := (D.half (D.add p.1 p.2), p.2)
def evenTrans (p : DD) : DD := (D.half p.1, p.2)

                                                               
                                                                
def narrow (M : Int) (s : DSet) : Bool :=
  match s.head?, s.getLast? with
  | some lo, some hi =>
    (D.cmp ⟨-1, 0⟩ (D.mul (.red M 0) lo.1) == .lt) &&
    (D.cmp (D.mul (.red M 0) hi.1) ⟨1, 0⟩ == .lt)
  | _, _ => true

                                                                          
                                     
abbrev State := List (Int × DSet)

                                                             
def joinState (k : Int) (v : DSet) : State → State
  | [] => [(k, v)]
  | (k', v') :: t =>
    if k < k' then (k, v) :: (k', v') :: t
    else if k = k' then (k', v.union v') :: t
    else (k', v') :: joinState k v t

                                                                          
                                                                       
                                                                       
                                                                    
def processDivstep (M : Int) (s : State) : State :=
  let s1 : State := s.foldl (init := []) fun acc (k, v) =>
    let acc := joinState (2 + k) (DSet.ofList (v.map evenTrans)) acc
    if 0 < k then joinState (2 - k) (DSet.ofList (v.map oddPosTrans)) acc
    else joinState (2 + k) (DSet.ofList (v.map oddNonposTrans)) acc
  s1.filterMap fun (k, v) => if narrow M v then none else some (k, chainHull v)

                                                                   
def state0 : State := [(1, [(⟨0, 0⟩, ⟨1, 0⟩), (⟨1, 0⟩, ⟨1, 0⟩)])]

                                                                               
def certEmpty (M : Int) (n : Nat) : Bool :=
  (Nat.repeat (processDivstep M) n state0).isEmpty

                                                                               
def Mstar : Int :=
  0x101c840faed222b9ef3bfe933011b277f84ee3d3f6dc8b496d8cd75b8315afec2

                                                                          

                                                                       
                                                                        
                                                                        
                                                                

structure HDState where
  delta : Int
  f : Int
  g : Int
  d : Int
  e : Int
  modulus : Int

def hdInit (f g : Int) : HDState :=
  { delta := 1, f := f, g := g, d := 0, e := 1, modulus := f }

def div2M (M x : Int) : Int := (if x % 2 = 1 then x + M else x) / 2

                                          
def hdStep (s : HDState) : HDState :=
  if s.g % 2 = 0 then
    { s with delta := 2 + s.delta
           , g := s.g / 2
           , e := div2M s.modulus s.e }
  else if 0 < s.delta then
    { delta := 2 - s.delta
    , f := s.g
    , g := (s.g - s.f) / 2
    , d := s.e
    , e := div2M s.modulus (s.e - s.d)
    , modulus := s.modulus }
  else
    { s with delta := 2 + s.delta
           , g := (s.g + s.f) / 2
           , e := div2M s.modulus (s.e + s.d) }

                                  
def hdRun (n : Nat) (f g : Int) : HDState := Nat.repeat hdStep n (hdInit f g)

end Hddivsteps
