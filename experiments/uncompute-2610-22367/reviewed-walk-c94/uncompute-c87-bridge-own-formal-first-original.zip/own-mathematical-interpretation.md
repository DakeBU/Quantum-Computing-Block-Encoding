# C87 independent source-first interpretation of the small bridge

Reviewer identity: `c87-small-composition-source-first`; actual agent `/root/uncompute_appendix_topology_c87`. This is a NEW bounded review, separate from frozen W/uncompute-c87-source-topology-review. The reviewer is not the formalizer or the independently working decoder. No decoder reconstruction or verdict was released to this reviewer before this freeze.

## Exact object being reviewed

Target: the COMPLETE W/uncompute-c89-formal-input/WalkRecovery.lean, formal SHA256 `924d4b151a644f9b490529c68f0349e188fddd400959b4b0ebe065a62715cf1e`, 2850 bytes. It has three declarations: a total noncomputable mathematical decoder (line9), one private invariant-state helper (line19), and one public actual-walk theorem (line51). Its trailing #check and #print axioms commands are present as text; their outputs were neither supplied nor read. This review does not infer successful compilation from them.

I read the complete permitted Recovery.lean (819 lines), NumberTheory.lean and Defs.lean providers, and all three supplied build-context files. Only the dependency closure relevant to this small target is assessed. Reading whole providers does not independently source-review or admit all their declarations. No raw author source outside this masked formal packet was read. The actual masked-file hashes, not supplied/raw hashes, bind this interpretation.

C88 names an upstream commit and raw Recovery hash `e1a1340f3c105874e06eae73fb21210ce18491aa103755e2bfa0b29ba764fa9d`; C89 binds its permitted masked Recovery bytes as `da1a987c401aabdeb58f8785bb6dc3928aedadae30fa0386efc778de727c770b`. These are different evidence objects. I verify the latter input and its mathematics as read, not the raw-to-masked transform or provenance to that upstream commit. This is an explicit provenance boundary, not evidence of semantic disagreement. The packet's bounded nested-comment mask is not independently certified as full lexical noninterference.

## Mathematical expansion

ZState is the full integer tuple (z,f,g,F,G). Define Step(s) by swapping when z>=0 AND g mod2=1; this gives (-z,g,(g-f)/2,2G,G-F). Otherwise it gives (z+1,f,(g+(g mod2)f)/2,2F,G+(g mod2)F). Seed(p,x)=(0,p,x,0,1). Walk(0)=Seed and Walk(t+1)=Walk(t) if its g=0, otherwise Step(Walk(t)). Thus t is a scheduled index; freezing is explicit and absorbing. This is the Appendix recurrence with freezing, not the nonfreezing hdRun algorithm in Defs. The latter appears in other provider theorems but is not needed by this target's proof route.

For arbitrary integer p and tuple u, define R(p,u)=(S(u),B(p,u)). S(u)=1 when F(u) mod4=2, else0. B tests in this order:

1. F(u) mod4=2: return1.
2. Otherwise g(u)=0: return1.
3. Otherwise z(u)>=1: return0.
4. Otherwise set j=padicValInt(2,F(u)), q=F(u)/2^j and return bit(j-1) of the canonical representative of p*(f(u)*q)^(-1) in ZMod(2^j).

Here j is a natural number and j-1 is truncated natural subtraction. bitk(v,k) is (v mod2^(k+1))/2^k as an integer, so signed integers use Euclidean residue bits. The function has no x, t, prior state, decision oracle or supplied decoder argument. Although declared noncomputable, its mathematical body is fixed, not an arbitrary choice function.

The public theorem says: for EVERY odd integer p, EVERY integer x, EVERY natural scheduled t with Walk(p,x,t).g !=0,

    R(p,Walk(p,x,t+1)) =
      (indicator(Walk(t).z>=0 AND Walk(t).g mod2=1), Walk(t).g mod2).

It recovers both the swap bit and the actual incoming parity from p and the actual successor alone. The outputs have type Int times Int, not Bool; the theorem's right side identifies both as bits because a remainder modulo positive2 is0 or1. It says nothing about R's correctness on arbitrary non-walk tuples or frozen transitions.

## Expanded invariant and who supplies it

Inv(p,s) is a Prop structure with exactly four fields:

- det: fG-gF=p.
- fodd: f mod2=1.
- high: z>=0 implies 2^(z.toNat+1) divides F.
- low: z<0 implies there exist natural j and integer q,r with j>=1, q mod2=1, F=2^j q, 0<=r<2^j, and 2^(j+(-z).toNat) divides G-qr.

There is no hidden typeclass/record field supplying branch recovery. On z<0, the low witness implies F!=0, and its odd q identifies j as the exact finite valuation. On z>=0, high implies F even. Thus Inv.fveven is derived. Together with fodd, det and p odd, Inv.gvodd derives G odd. These match the source determinant/parity/window package, expressed with an existential odd-factor witness instead of using an infinite-valued v2 at zero.

inv_zSeed proves this structure directly: determinant by p*1-x*0=p, fodd from p odd, high from divisibility of zero, low vacuous at z=0. Inv.zStep proves all four fields by split cases with exact halving and witness updates. invariant_zWalk then inducts along scheduled steps, retaining the same invariant in the frozen case and using Inv.zStep otherwise. The public bridge applies this producer to its actual Walk(p,x,t); Inv is NOT a final theorem assumption.

## Private helper and complete branch proof

The private helper assumes odd p, Inv(p,s), and incoming g!=0. This is an internal provider interface, not a restatement of the public source Anchor with excess hypotheses. It recovers the two bits from Step(s).

sigma_class yields swap iff updated F mod4=2. The helper normalizes the source congruence's right-hand residue 2 mod4 to2. On swap the decoder returns (1,1) and incoming g mod2=1 by the swap guard itself.

On nonswap, the equivalence makes updated F mod4!=2. If updated g=0, bbit_of_freeze uses incoming f odd and incoming g!=0 to prove bbit=1. bbit_of_nonswap converts bbit to incoming g mod2. If updated g!=0 and updated z>=1, bbit_of_ramp plus nonswap gives incoming parity0. Finally if neither test applies, zStep_nonswap gives updated z=s.z+1; failure of updated z>=1 implies incoming z<0. Thus ladder_det's negative-counter guard is proved, not assumed.

Important intermediate naming distinction: provider bbit(s) is defined to be incoming f mod2 on swap and incoming g mod2 on nonswap. It is not definitionally the paper's b on arbitrary states. The public bridge never silently identifies it on arbitrary states: swap uses g odd directly, and all other branches explicitly use bbit_of_nonswap. On invariant states both coincide, but that is a consequence of parity, not a literal definition equality.

The four cases are jointly necessary for this decoder's full theorem: they form an AND of guarded case proofs, not independent OR-routes for recovering every step. The mathematical source admits the two A11 evaluation interfaces; this new decoder intentionally chooses the determinant interface. It neither assumes the other interface as input nor claims a second independent source proof.

## Is fallback really licensed?

Yes, at the level of the inspected dependency proof text. The helper supplies h=Inv(p,s), hp and hz:s.z<0 to ladder_det; its two reflexivity arguments instantiate j and q to their exact displayed definitions rather than assuming independent oddness/unit claims.

The actual closure is:

    Inv.low + hz
      -> incoming j0>=1, q0 odd, F=2^j0 q0, bounded r0,
         and modulus2^(j0+(-z).toNat)
      -> ladder_exists: outgoing j'=j0+1>=2, same odd q0,
         outgoing bounded r=r0+(g mod2)2^j0,
         outgoing F'=2^j' q0 and 2^j' | G'-q0 r.

padicValInt_of_odd_factor identifies this exponent/odd factor with the decoder's j,q. ladder_witness isolates the highest bit by bounded residue uniqueness and the same append identity. ladder_core packages odd q, exact factorization, the bounded representative r, its congruence and bit identity.

ladder_det obtains updated Inv using Inv.zStep hp. Hence updated f' is odd. Together with q odd this proves f'q odd. Multiplying the G'-qr congruence by f' and using updated determinant f'G'-g'F'=p gives 2^j | p-f'q r. inv_val_eq_of_witness derives IsCoprime(2^j,f'q), obtains IsUnit of its ZMod cast and uses the inverse-on-units lemma, then the canonical residue range to identify val(p*(f'q)^(-1))=r. Therefore the chosen fallback is a genuine inverse calculation on the selected domain. No inverse oracle, odd-factor existence, normalized residue or ladder-correctness premise is smuggled into the public theorem.

The implementation proof shares ladder_core between ladder and ladder_det. The source narrative derives the second formula by substitution into the first. These are aligned mathematics but not identical theorem-call graphs; no compiler-backed theorem-dependency graph is claimed here.

## Total definitions versus source definitions

The exact requested imported definitions show padicValInt(2,0)=0, through padicValNat(2,natAbs(0)) and maxPowDvdDiv's zero case. The paper instead declares v2(0)=infinity. This is NOT a literal whole-carrier source definition. The bridge avoids the difference on every theorem-relevant fallback because its producer proves nonzero F' and j>=2. The private helper also avoids the mismatch under Inv and hz.

ZMod n is Int when n=0 and Fin n when n>0. val is natAbs at n=0 and the Fin representative when n>0. ZMod inverse is a total operation: at n=0 it uses integer sign, and at n>0 it casts the Bezout coefficient Nat.gcdA of the representative and modulus. In particular it is NOT a genuine inverse for arbitrary nonunits, and one must not describe its whole off-domain behavior as 'inverse, with zero fallback'. Here n=2^j>0 for every j, and in the theorem-relevant fallback j>=2 and f'q is odd. The exact unit-producing proof above supplies the needed inverse semantics. No dependence on the n=0 branch exists in recoverStepBits.

Thus recoverStepBits is an explicitly total INTERNAL mathematical extension, source-correct only on the guarded reachable active-successor locus proved by the theorem. It is not characterized by a new unique-source-object assertion, does not choose representatives modulo global phase, and is not a source-literal definition on arbitrary ZState. Its public Lean visibility does not change that mathematical classification. The pre-proof contract already discloses this total extension, so no silent correction or definition drift is needed.

## Comparison to sealed contract and raw source

The complete public theorem text matches the planned C88 signature: the same p,x,t, hp and hactive; the same actual successor; and the same swap/parity pair. The function's tested order and determinant fallback match its stated decoder. The contract's permissive domain is actually implemented: arbitrary odd integer p and arbitrary integer x; no positivity or input-range binder appears inside Inv or the producer proof. This is an honest generalization of the Appendix opening p>0,0<=x<p, not an exact source-domain equality. Restriction to that source locus is immediate and requires no extra proof premise.

Frozen transitions are excluded by the current active hypothesis, which also converts actual scheduled successor to Step. No all-earlier-active or eventual-termination assumption is needed for this local recovery theorem; invariants survive freeze independently. A.3's 590-step external bound, special-modulus primality, gcd(p,x)=1 and inverse extraction are not dependencies. The source graph allactive/partition/swapvisible/terminalvisible/countervisible/decodeF nodes are supplied by the inspected chain; high/low invariant preservation is an implementation organization of the source induction, not a fresh source assumption.

## Split conclusion before decoder release

Semantic reading and recursive binder/definition audit of this COMPLETE small target: acceptable with disclosed generalization and internal total-definition boundary. No missing producer/active/branch/unit premise was found. No blocking source-contract mismatch was found. Whole-upstream source fidelity, actual Lean elaboration/axioms, imported-library correctness, source-blind round trip, quantum coherent realization/relative phase/ancillas, arithmetic overflow, resource tiers and final admission remain outside this finding. Requested imported-definition regions were read only to resolve operation semantics; no whole-library/TCB review is asserted.

This own interpretation is frozen before any independent decoder release. Stop here; this packet is not formal release, Proof Seal or admission.
