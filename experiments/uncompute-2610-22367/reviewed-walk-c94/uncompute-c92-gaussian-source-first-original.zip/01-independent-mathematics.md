# Independent mathematics and exact boundary

## 1. Carriers and target (source G01-G03, G09, G20)

Write B=2^39 and H=2^32. A 39-bit input word u has two's-complement interpretation

\[
 s(u)=\begin{cases}u&0\le u<2^{38},\\u-B&2^{38}\le u<B.\end{cases}
\]

The whole word carrier represents [-64,64) in units H^-1. The paper promises only

\[
 -2^{35}\le s(u)<2^{35},\qquad x=s(u)/H\in[-8,8).
\]

Thus the promised set has 2^36 words, sign-extended into 39 bits. This finite range is a deduction, not a source assertion of an arbitrary-width theorem. Off-promise behavior is unrestricted by reference [63]. No zero/default extension is introduced.

Let R be nearest-integer rounding, with half-integer ties away from zero. The literal reference function is

\[
 F(u)=R\left(H\exp(-(s(u)/H)^2)\right).
\]

Since its argument is positive, R(z)=floor(z+1/2) here. On the promised domain, 0<=F(u)<=H, so the reference value fits the accumulator. The accumulator k is an arbitrary residue modulo B, not necessarily zero and not an amplitude. The paper's numerical section uses addition, not the generic introductory XOR embedding:

\[
 |u\rangle|k\rangle\longmapsto
 |u\rangle|k+A(u)\pmod B\rangle.
\]

A is the realized integer increment; it must not be silently identified with F, because approximation is allowed. For any fixed integer A(u), this ideal basis translation is a permutation for all k. Its logical inverse subtracts A(u). That algebraic fact does not construct an inverse of the paper's adaptive measurement-based circuit or establish its resource count.

## 2. Error, rounding and coherent semantics (source G02-G08, G20)

Reference [63] specifies circular distance for an n-bit accumulator. For n=39 define

\[
 d_B(a,b)=\inf_{z\in\mathbb Z}|a-b+zB|.
\]

The numerical tolerance is reported as absolute Gaussian error <10^-7, with worst case 9.99*10^-8. In output-value units, the natural rounded-reference reading is d_B(A(u),F(u))/H<10^-7; equivalently, integer circular discrepancy <429.4967296. Requiring integer discrepancy <10^-7 would instead demand exact integer equality and is not the intended fixed-point numerical reading.

There is a narrow remaining precision-seal question: the prose does not give the actual checker expression distinguishing discrepancy from rounded F/H versus discrepancy from the unrounded exp(-x^2). The two differ by at most 1/(2H)=2^-33, but strict inequalities at the final margin are not identical. This packet does not silently spend that half-ulp twice or claim either reading is implementation-verified. A final exact Anchor must resolve this source-to-checker boundary without changing the source tolerance. Circular rather than ordinary signed subtraction must remain explicit under either reading.

For every allowed input and every nonzero-probability measurement record m, coherent correctness requires the same logical permutation, no extra logical sign, unchanged u, and all temporary qubits zero. The generic kickmix model permits X/CNOT/Toffoli/swap; Z/CZ/CCZ/global sign; destructive X measurement. Measurement outcomes may control diagonal corrections but not basis-changing operations. It is insufficient that output bits alone agree or that signs average away. Exact cleanup and phase are required even when the numerical increment is approximate.

The source's Methods validation has 9,000 Gaussian tests in Extended Data Table 1, not exhaustive enumeration of all 2^36 input words, arbitrary k, and measurement records. The separate SI full-domain maximum is a reported numerical assertion; the PDF supplies no complete certificate for it. Methods equations (17)-(21) give distribution-dependent statistical bounds for trajectory failures. They do not turn 9,000 samples into a uniform Gaussian approximation theorem, and the Gaussian numerical tolerance is not a license for rare dirty-ancilla or phase failures.

## 3. Fold without the carry chain (source G21; deductions D01-D02)

Set the conceptual folded integer

\[
 m(u)=\begin{cases}s(u)&s(u)\ge0,\\-s(u)-1&s(u)<0.\end{cases}
 \qquad y=m(u)/H.
\]

For negative s, the unsigned complement of its complete 39-bit word equals B-1-u=-s-1. On the promise, 0<=m<2^35 and 0<=y<8. Positive inputs use y=x. Negative inputs use y=|x|-H^-1, not |x|. In particular s=-1 and s=0 fold to the same m=0, and s=-2^35 folds to 2^35-1. Folded data alone cannot retain the original input: some sign/original-input information must survive and be restored. The PDF does not give the literal gate/wire transcript for that restoration, so the formula is a value-level reconstruction, not a claimed gate circuit.

For g(t)=exp(-t^2), |g'(t)|=2t exp(-t^2) on t>=0. Differentiating shows its maximum is sqrt(2/e)<1 at t=1/sqrt(2). The mean-value theorem consequently bounds the fold-only change by sqrt(2/e)/H <2^-32. This explains why omitting a unit increment can fit a 10^-7 budget; it does not bound approximation, truncation, or rounding errors of the whole evaluator. Source G21 says the offset lies in its combined budget.

## 4. Dyadic selection and polynomial arithmetic (source G18-G19, G22-G25)

Because interval width is 2^-7 and the input spacing is 2^-32, the full exact local-coordinate decomposition is

\[
 j=\lfloor m/2^{25}\rfloor\in\{0,\ldots,1023\},\qquad
 r=m-j2^{25}\in\{0,\ldots,2^{25}-1\},
 \quad y=j2^{-7}+r2^{-32}.
\]

This derives ten interval bits and 25 remaining coordinate bits. It does NOT assert that all 25 are retained by the multiplier; the paper does not specify that multiplier width or which columns it drops.

The source lists 455 quadratic intervals, then 59 constants, then 510 zeros. Reading these as consecutive increasing interval indices gives j=0..454, 455..513, and 514..1023. The count sums to 1024. The zero-region threshold is 514/128; monotonic Gaussian decay gives a value-level tail bound exp(-(514/128)^2). This observation alone does not certify the constants or any quadratic fits.

The reported pipeline folds; selects coefficients with a pruned variable-spaced QROM; updates a slope register by a truncated product; adds an intercept and the final product into k; removes consumed coefficients by measurement plus phase correction; reuses released coefficient qubits as later carry workspace; and restores the preserved input/cleans workspace as demanded by the interface. This is a partial order of semantic obligations, not a total schedule: coefficient erasure and carry reuse can interleave with arithmetic. The PDF gives no exact Gaussian coefficient tuple, signed coefficient format, width, shift, omitted column list, rounding sites, or interleaving schedule.

Equations (63)-(64) display the HHL kernel g0-d(g1-g2*d), including its signs. They are useful context for the shared method but are not a literal Gaussian integer kernel specification. We do not transplant HHL's 15-bit coordinate, 16-bit slope, cyclic shift, 345 leaves, or signed subtraction convention into the Gaussian circuit. Its Gaussian prose specifies the three coefficient roles and direct accumulation only. The offline fitting must target its actual quantized/truncated integer computation, not an ideal real polynomial rounded afterward.

## 5. Resource scope (source G10-G13, G17, G23-G26)

T counts Toffoli and CCZ equally. Q is peak simultaneously allocated logical qubits. TQ weights those two resources equally, omitting distinct depth/connectivity/physical error-correction/measurement-latency and preprocessing costs. Gaussian reported point: T=1583, Q=139, product 220037 (printed as approximately 220000). Reported tuned HRS baseline: approximately T=24000, Q=362, product 8688000; printed ratio 39, about 15 times fewer Toffolis and 2.6 times fewer qubits. Baseline rounds limit exact ratio interpretation.

The baseline first squares x and uses cubics on 32 intervals with general 40-bit arithmetic. The discovered design never materializes x^2, y^2, complete products, or a separate finished Gaussian register. Pruned coefficient lookup is reported as 495 Toffolis rather than 1022 for a conventional lookup. This component comparison is not a complete decomposition of 1583. Table input/output 39/39 and the total Q=139 do not specify all scratch-register widths or lifetimes. No claim of optimality, lower-bound matching, asymptotic scaling in precision, Clifford+T synthesis cost, or SP/BE improvement follows.
