# Source inventory and coverage

This is an author inventory, not independently approved exhaustive topology. Complete relevant pages were inspected, including margins/captions/table notes. All Gaussian text-search hits in P were PDF 7,11,16,17,18,33,34,36, matching the supplied hit list. Full PDF text was machine-scanned only for that term; unrelated pages were not read as evidence. No source implementation shaped this inventory.

| Complete page/region inspected | Disposition | Reason / exact in-scope content |
|---|---|---|
| PDF1 title/version and introductory function paragraphs | NODE G01 | Source identity and generic basis-action embedding; numerical addition is more specific. |
| PDF1 abstract/general discovery narrative | EXCLUDED | Broad multi-task headline does not certify Gaussian or SP/BE resources. |
| PDF2 Figure1, caption, framework prose | EXCLUDED | Generic discovery/control/history/rare-event examples, not literal Gaussian wiring. |
| PDF3 design principles and Eq1 | EXCLUDED | Conditional routing motivation; no Gaussian-controlled-swap gate transcript inferred. |
| PDF3 Eqs2 and rare-event paragraphs | EXCLUDED | History decoding and probabilistic failure mechanism do not relax Gaussian's uniform numerical contract. |
| PDF3 DQI opening, PDF4 full text read | EXCLUDED | Unrelated decoding and inversion constructions; no supplier dependency. |
| PDF7 Figure3/caption | EXCLUDED | Divstep walk and rare-event data, not Gaussian validation. |
| PDF7 TableI caption + Gaussian row | NODE G11 | Matched T,Q comparison, tuned baseline, printed gain. Other rows/footnotes inspected, excluded as other tasks. |
| PDF7 discussion and PDF8 continuation | NODE G10 boundary / EXCLUDED rest | Objective and fixed computational-basis scope relevant; broad future-work and acknowledgments excluded. |
| PDF9 Methods introduction | NODE G01,G02,G10 | Reversible embedding, logical resource proxies, task-specific specification. Search-LLM motivation excluded. |
| PDF9 circuit model Eq10 and numerical paragraph | NODE G02 | Exact phase, preserved interface and workspace despite approximate numerical value; distinct failure budget. |
| PDF9 allowed gates and basis trajectory explanation | NODE G03 | Full three operation classes, not merely Toffoli count. |
| PDF9 Eqs11-13 and surrounding paragraphs | NODE G04 | Both ordinary inverse-Toffoli and measurement cleanup routes; cited[29] is source-reproduced AND example, not external lookup proof. |
| PDF10 Eq14 and correction paragraph | NODE G04,G05 | Conditional phase removal. |
| PDF10 Eqs15-16 and all surrounding trajectory restrictions | NODE G05 | Same basis permutation for records, exact phase per record, no measurement-controlled basis changes. |
| PDF10 validation first two paragraphs | NODE G06 | Preserved inputs, clean ancillas, exact phase, all-pair versus sampled distinction. |
| PDF10 Eqs17-19 and explanatory paragraphs | NODE G07 | Deferred measurement plus weighted bad trajectories; not a Gaussian supremum proof. |
| PDF10 Eqs20-21 and fixed-candidate condition | NODE G08 | Independent random test assumption and bounded failures; no selected confidence level is supplied for Gaussian. |
| PDF11 cost section including Eq22 | NODE G10 | Toffoli/CCZ equality, peak Q, hardware/time-depth/storage caveats and alternative objectives. |
| PDF11 evolutionary-search section | NODE G13 for final Gaussian-lineage paragraph; EXCLUDED other paragraphs | Experimental process, not mathematical Gaussian coefficient construction. Complete section read, not used as a proof premise. |
| PDF12 relevant bibliography entries [2],[8],[12],[29] | NODE G14/G03/C12/G04 citation records | [2] chemistry application; [8] kickmix provenance; [12] HRS; [29] temporary-AND MBU. Other bibliography entries excluded as unrelated. External contents not consulted. |
| PDF13 reference[57] and [58]-[62] | NODE G14,G15 citation records | Numerical-library/context/other-function sources, not imported theorem proofs. |
| PDF13 reference[63] entire note | NODE G09 | Rounding ties, circular metric, off-domain freedom. No footnote portion omitted. |
| PDF13 references[64],[65],[66] | NODE C64,C65,C66 | Specialized lookup erasure, SP application citation, pruned-QROM provenance; no external contents read. |
| PDF13 other references and PDF14 reference continuation | EXCLUDED | Unrelated tasks/bibliography; PDF14 complete text was inspected during reference lookup. |
| PDF16 Extended Data Figure2 complete plot and caption | NODE G13 | Parent-child arrows, iteration colours, constant-TQ contours, final point. It is an experimental lineage, not circuit semantics. No figure redistributed. |
| PDF17 Extended Data Table1 caption, Gaussian row, all notes | NODE G12 | Input39/output39, tolerance,9000tests and counts. Other rows/footnotes excluded as task-specific context. |
| PDF18 SI table of contents | NODE source locator only | SI III.3 at SI19/PDF36. |
| PDF18 SI I text and Eqs23-24 | EXCLUDED | DQI-specific state preparation/phase correction; not Gaussian SP. |
| PDF33 pre-III continuation | EXCLUDED | Point-addition failure statistics; not Gaussian. |
| PDF33 SI III paragraph1 | NODE G14 | Classical functions, algorithmic uses and all context citations[57],[12],[58]-[60],[4]. |
| PDF33 SI III paragraph2 | NODE G15 | Reversible/coherent control and long intermediates; citations[61],[62],[12]. |
| PDF33 SI III paragraph3 including map | NODE G16,G09 | Three functions, additive numerical map, uniform promised-domain bound, ordinary/gradient accumulator, cited convention[63]. |
| PDF33 SI III paragraph4 | NODE G17,C12 | Full HRS pipeline, four cost sources, tuning degree/format/recomputation/intervals and selecting lowest TQ implementation. |
| PDF33 SI III paragraph5 | NODE G18 | Bit-identifiable partitions, lower degree/narrower operands, shared-kernel rationale, direct accumulation, MBU. Unequal HHL routing is not copied into Gaussian. |
| PDF33 SI III paragraph6 | NODE G19 | Offline fit against quantization, omitted columns, shifts, truncation, rounding; combined error budget. |
| PDF33 final paragraph plus PDF34 opening | NODE G18 | HHL described fully; Gaussian fold/prune/reuse distinction. |
| PDF34 SI III.1 complete, Eqs61-64 | EXCLUDED Gaussian literal semantics; NODE context G18,G19 | HHL-only widths, cyclic shifts, coordinates, coefficients and resource estimates cannot define the Gaussian kernel. |
| PDF35 FigureS3 complete/caption | EXCLUDED Gaussian gate evidence | HHL circuit, not an unlabelled Gaussian diagram. Used to distinguish complete HHL exposition from missing Gaussian gate transcript. |
| PDF35 SI III.2 complete and PDF36 continuation Eq66 | EXCLUDED Gaussian semantics | Coulomb-only normalization,128lines,6-bit operands,17-Toffoli erase cost. Its MBU analogy is context, not Gaussian component counts. |
| PDF36 SI III.3 paragraph1 including Eq67 | NODE G20,C65,G17 | Application cites[2],[65],39-bit input/output,domain,scaled-round formula,tolerance and full Gaussian baseline specification. |
| PDF36 SI III.3 paragraph2 | NODE G21 | Nonnegative fold, omitted carry chain, negative one-ulp shift, error-budget assertion. Missing register transcript S01. |
| PDF36 Pruned coefficient lookup complete paragraph | NODE G22,G23,C66 | Every interval count, index-bit property, subtree-pruning criterion and1022->495 comparison. Data/structure certificate absent S02/S05. |
| PDF36 Direct quadratic accumulation complete paragraph | NODE G24,G19 | Intercept/slope/curvature, overwritten slope, final accumulator products, absent full products/value register, integer fitting. Exact coefficients/arithmetic absent S02. |
| PDF36 MBU/reuse complete paragraph | NODE G25,C64 | Freed coefficient qubits are later carries; direct accumulation/reuse and139 peak. Exact correction and lifetime details absent S03/S05. |
| PDF36 final Gaussian paragraph | NODE G26 | Full-domain reported error,exact1583/139,roundedTQ and comparison factors; certificate absent S04/S05. |
| PDF36 closing SI III sentence | NODE G26 comparison context |9.9-39TQ range over three distinct tasks; no new Gaussian theorem. |
| PDF36 SI IV opening Eq68 | EXCLUDED | Pauli Hamiltonian/alias-SELECT route belongs to a different benchmark, not Gaussian block encoding. |

No Gaussian theorem is numbered as such; Eq67, SI III.3 paragraphs, general Methods and reference[63] jointly specify its source-facing contract. Missing internal circuit proofs and external cited methods are kept distinct. Source-gap means the PDF lacks enough detail to certify a requested interface here, not that its reported implementation is false. A distinct raw-source topology review remains pending.
