# Candidate source Anchors / interface map

These are mathematical signatures, not Lean declarations and not proof-bearing bundles. No exact Lean signature was elaborated, so repository STATEMENT_SEALED is NOT claimed. SOURCE_ONLY_FROZEN pins the candidate contract and open slots before any implementation exposure.

## A. Literal reference definition

Carrier: 39-bit words u, signed decode s(u), promised subset -2^35<=s(u)<2^35. Definition body F(u)=R(2^32 exp(-(s(u)/2^32)^2)). Declaration kind: literal. Its body is meaningful on the whole word carrier, but the source realization guarantee is only promised-subset; a wider reference formula is not an off-domain implementation promise. Accumulator arithmetic is Z/(2^39); rounding convention is source-wide[63]. No classical choice or default value is needed.

## B. Source construction Anchor candidate

Under the source's kickmix model, the specific discovered Gaussian construction realizes an additive fixed-point increment A on the promised input subset. For every promised u, every k modulo2^39 and every nonzero-probability measurement record, the logical output is exactly |u>|k+A(u)> with zero extra phase and clean temporary qubits; A satisfies the source numerical relation at tolerance10^-7. The actual increment may be identified by concrete finite arithmetic only when that arithmetic is supplied; it cannot be chosen arbitrarily from the many functions satisfying the error bound.

Unsealed slots: exact rounded-versus-unrounded normalized error expression; actual circuit/producer; physical wire order/endianness adapter; coefficient encodings, widths, shifts, truncation; exact measurement/correction and restoration schedule. The source specifies numerical two's-complement meaning, not a complete register-wire layout.

Do not replace this Anchor with: given a function/circuit already satisfying all desired semantics, conclude it is an oracle. That wrapper moves proof ingredients into binders and proves no construction. Similarly, a family accepting arbitrary n or epsilon is a new generalization, not this paper's fixed-instance statement.

## C. Resource Anchor candidate

The SAME constructed realization has T=1583 and peak Q=139 under source Eq22, including the task's input/target conventions. The coefficient lookup reports495 rather than1022 Toffolis. These are separate obligations, not assumptions on a convenient chosen circuit. TQ=220037 is a deduction from the reported exact pair; printed220000 is rounded. The tuned HRS baseline reports24000,362 and comparison39, not an optimality theorem. The concrete gate list and allocation timeline are not present in P.

## Binder audit (fully expanded conceptual inputs)

| Input or candidate extra premise | Class | Treatment |
|---|---|---|
| u a39-bit word; k a residue modulo2^39 | TYPING | Carrier data only. |
| promised signed u range [-2^35,2^35) | SOURCE | Explicit domain assumption; not strengthened to convenient nonnegative or interior-only range. |
| two's-complement scale2^-32; output39bits; nearest ties-away; modular arithmetic/circular metric | STANDING | Source G09/G20, all expanded in01. |
| scalar exp interpreted over reals, computational basis | TYPING / STANDING | Literal formula/source fixed-basis model, not amplitude interpretation. |
| ancillas initially zero | STANDING | Source Eq10; no dirty-ancilla resource assumption added. |
| arbitrary initial k, input unchanged | SOURCE | Additive map and table's read-only input/target convention. Must not weaken to k=0. |
| any record of nonzero probability | STANDING quantified output criterion | Every-record phase/cleanup requirement, not a sampled correctness premise. |
| supplied correct coefficient table, QROM theorem, arithmetic semantics, MBU phase theorem, fold restoration, uniform bound | EXCESS if public binders | Must be produced by proof dependencies for the source construction Anchor. An internal conditional interface may be useful but is not the source Anchor. |
| given a normalized Gaussian state, PREPARE/SELECT, controlled inverse | EXCESS | Not assumptions or outputs of the Gaussian function benchmark. |
| x>=0, no wraparound, k=0, particular measurement outcome, no sign correction needed | EXCESS | Unauthorized weakening/strengthening or dropped source obligation. |
| external source[64]/[66] complete semantics | Dependency, not SOURCE binder | P cites techniques but does not present their full theorem. Record exact required contracts before conditional theorem work. |
| approved mathematical correction | RULED: none | No repairs made or approved. |

Definition audit: reference F and circular distance are literal; the folded value and dyadic coordinates are independently derived literal expressions. The phrase "an approximation satisfying the tolerance" defines a nonunique relation, NOT a uniquely characterized function. No uniqueness/choice theorem is fabricated. A physical circuit/channel is not defined merely by its acceptable basis values. Measurement implementations can realize the same logical action via nonunique environments; quotient/representative or channel equivalence would require an explicit later formalization. No quotient uniqueness is claimed.

No source-blind decoder or distinct independent reviewer has approved these interfaces. No local API inventory was consulted because implementation exposure was prohibited. Candidate names A01/A02 refer to graph nodes only; they are not claimed Lean constants.
