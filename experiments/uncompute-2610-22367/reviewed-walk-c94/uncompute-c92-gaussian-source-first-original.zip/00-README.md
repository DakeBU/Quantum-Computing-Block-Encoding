# Gaussian finite-function supplier: SOURCE_ONLY

Status: source-only frozen analysis; no Lean statement/proof seal, implementation certification, independent topology approval, or SP/BE closure.

Primary source: Gu et al., *Discovering state-of-the-art quantum circuits with large language models*, arXiv:2610.22367v1, supplied PDF P. SHA256: `3607f457c3349db74e10b131abadef23a4a2dea0fefa0cf6ac6d0ed9f37fdfd9`; 46 PDF pages. All page numbers below are one-based PDF positions; PDF 33-36 are supplementary pages 16-19.

The reusable source-facing object is a fixed-instance, approximate modular-addition evaluator for the Gaussian on a promised signed fixed-point domain. It preserves the input and arbitrary accumulator's initial content, and requires exact phase and workspace cleanup. It is not an amplitude loader, normalized Gaussian state, diagonal block encoding, arbitrary-precision family, or proof that reported resource savings transfer to those tasks.

Read 01 for the independent mathematics; 02 and 03 for graph and coverage; 04 for candidate interfaces and binder/definition audit; 05 for gaps and consumer boundaries; 06 for chronology/input restrictions; 07 for the bounded worker handoff. The graph is source topology, not a Lean dependency graph. Source assertions and our deductions are separately labelled.

Source coverage includes all detected Gaussian mentions on PDF 7, 11, 16, 17, 18, 33, 34, 36. Complete relevant pages were read; additional standing definitions were read on PDF 1, 9, 10, 12, 13, and the HHL comparison/circuit on PDF 34-35. PDF 2, 3, 8 were read as context. Every in-scope substantive region has a NODE or EXCLUDED disposition in 03. No claim is made to have audited the unrelated seven constructions or the entire 46-page paper.

The packet contains new explanatory prose and mathematics, not copied paper figures, extracted full pages, source code, or numerical coefficients. Private PDF inspection renders are outside this packet and outside the publication allowlist. The paper's CC-BY-NC-SA licensing description is supplied by the task; no relicensing of its material is asserted here.

Only files explicitly listed in PUBLICSAFE_ALLOWLIST.txt are payload. Paths inside payload use the task's logical aliases W, G, P. MANIFEST.json hashes content files and the allowlist; SEAL.json binds the manifest and documents its non-circular seal design. These hashes bind this author's source-only packet, not its mathematical correctness or independent review.
