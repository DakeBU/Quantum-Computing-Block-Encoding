# Findings, gaps, and SP/BE consumer boundary

## Source-layer classification

| Finding | Evidence class | Consequence |
|---|---|---|
| Fixed39-bit signed promised-domain additive evaluator | Explicit source contract G09/G16/G20 | Potential finite-function supplier, not yet certified. |
| Formula/domain/rounding/circular metric | Source definitions plus independent expansions | A source-faithful target can be stated without inventing arbitrary-width behavior. |
| Negative fold omits+1 | Explicit source construction G21 | Must fit the shifted argument, preserve original input, and retain the offset in the error budget. |
|1024 dyadic intervals;455quadratic/59constant/510zero;pruned lookup | Explicit source descriptions G22/G23 | Useful construction topology, insufficient exact integer kernel. |
| Direct slope overwrite, destination accumulation, MBU/carry reuse | Explicit source descriptions G24/G25 | Must prove arithmetic, garbage/phase semantics and lifetime accounting together. |
| Worst-case9.99e-8;1583/139;gain39 | Reported source results G26 | Not independently checked theorems, universal error certificates, or SP/BE measurements. |
|9000 tests and Figure2 lineage | Reported experimental validation | Not exhaustive correctness nor a proof of optimality/global search convergence. |
| Full coefficient/gate/phase/allocation witnesses absent | SOURCE_GAP S01-S05 | Prevents certification from P alone; does not refute paper claims. |
| Error-scale/reference expression not written as formal checker | Precision-seal SOURCE_GAP S04 | Keep half-ulp distinction until resolved; do not strengthen or weaken advertised tolerance. |

Failure class for the bounded audit is NONE: the source-only reconstruction is complete within its declared scope. S01-S05 are typed unproved source-detail obligations. They are NOT independently reviewed SOURCE_INVALID verdicts. No mathematical route is retired. Exact circuit reconstruction would currently be source-detail blocked, not disproven or API_BLOCKED. No Lean/runtime implementation was attempted, so IMPLEMENTATION_FAILED would be inaccurate.

## A genuine SP consumer would additionally need

Choose the actual label set J, reversible map j->u_j in the promise, desired amplitudes a_j, basis/endianness, normalizer and state norm tolerance. Decide whether the Gaussian is an amplitude exp(-x^2), a probability whose square root is needed, a density with a quadrature measure, or a scaled/shifted sampled family. These are different targets; this source does not pick one. Continuous tails/discretization/normalization and parameter-access costs are not part of the fixed function benchmark.

One possible BUT UNPROVED AND-tail is: certified evaluator + input-label superposition and reversible index conversion + amplitude transduction with a proved range/rotation convention + value/workspace cleanup preserving relative phases + nonzero accepted norm + success/postselection/amplification analysis + complete error/resource composition. None of these single tails is sufficient alone. For example, a reversible circuit computing values does not turn basis digits into amplitudes. Preparing |j>|A(u_j)> generally leaves garbage correlated with j until the value/workspace is coherently removed.

If amplitudes are approximated, normalized-state error must depend explicitly on both vector error and the target norm: a pointwise value tolerance alone is not the final normalized-state tolerance. The number of labels can multiply unnormalized l2 error by its square root, and postselection probability depends on the target vector and chosen scaling. No success lower bound or amplification cost appears in SI III.3. Relative phase correctness for all labels and measurement records is essential.

## A genuine diagonal BE consumer would additionally need

First fix D=diag(d_j) with d_j specified, label dimension/order, normalizer alpha>0, block-projection ancillas and operator-norm tolerance. For a value-controlled rotation route, an explicit candidate AND-tail is: certified label-to-promised-input map + certified evaluator and an ordinary-value lift resolving circular representatives + bound |d_j/alpha|<=1 + clean controlled dilation/rotation with the exact top-left entry d_j/alpha + uncompute/value cleanup compatible with the full dilation + proof that all label-relative phases and auxiliary sectors meet the chosen BE definition + uniform block error/resource analysis.

A circularly accurate 39-bit value alone is not a range certificate for a real controlled rotation. A wraparound-close negative residue can be close on the circle while grossly wrong if interpreted as a large unsigned number. Choosing a real representative or clipping it is new consumer work and its error must be proved; it must not silently alter the source evaluator. Even near G(0)=1, approximation does not by itself guarantee a supplied real value stays <=1. Normalizer/range handling is necessary.

The source's measurement-based implementation realizes a logical reversible action only when its exact correction/cleanup contract holds. A conventional BE definition asks for a unitary/dilation and its coherent use; physically reversing destructive measurements is not a free inverse. One must supply a coherent dilation/deferred-measurement semantics or an appropriately certified logical-channel composition theorem and account for controls, environment decoupling, inverse implementation and resources. The existence of the ideal modular-translation inverse is not that construction.

Phase-gradient addition is a different OR consumer route: prepare a specified Fourier/gradient accumulator, derive the translation eigenphase with the chosen Fourier sign and scale, and account for its preparation/error. This implements phase use, not automatically a real diagonal amplitude block. A Gaussian-dependent phase oracle and a block encoding of Gaussian values are different operators.

No LCU shortcut is inferred. A PREPARE-based LCU route would require its full coefficient phases, normalization, SELECT, inverse/unprepare and ancilla contracts, none of which are supplied by this numerical evaluator alone. The separate chemistry alias-SELECT benchmark starting at PDF36/SI IV is not part of this Gaussian construction.

## Resource comparison boundary

Any future SP/BE comparison must match target, labels, promise, precision, scalar/phase convention, success, normalizer and logical gate/measurement model, then charge input preparation, all evaluator calls, lookup/rotation synthesis, cleanup, controls, postselection/amplification and classical fitting/preprocessing. The 39-fold TQ comparison concerns one tuned fixed-point numerical benchmark versus one HRS baseline. It is neither an SP/BE speedup nor a transferable asymptotic SOTA theorem. This audit supports no positive or negative general feasibility conclusion for SP/BE.

## Dependency-ready next work, not performed

1. Independent raw-source topology review of02-03 and precision-reference reading in01.
2. Obtain source-authorized exact coefficients/arithmetic/gate/cleanup/allocation witnesses, preserving this sealed pre-exposure packet unchanged.
3. Admit the finite-function construction only after exact statement/definition/binder audit, implementation-to-source bridge and required Lean/resource gates.
4. Open a separate explicitly chosen SP or diagonal-BE consumer contract, with the complete AND-tail above; compare resources only after that construction exists.
