# Source-blind formal reconstruction: c89

Status: FROZEN BEFORE SOURCE RELEASE. This is a reading of formal syntax and its mathematical argument, not a compiler result, source comparison, admission decision, or elaborated dependency extraction.

## Evidence boundary

Only the authorized governance files, the c89 formal-only packet and the explicitly authorized c85/c86 formal-definition supplements were consulted. No author exposition, intended target, prior review, source document, production implementation, Git state, compiler log, olean, network, compilation or simulation was consulted. The supplement directory labels are identifiers, not prior-review evidence.

The c89 input manifest SHA256 is `ce0d1664580ecc43b8a6a77c550c5219c53346b209d19f8acbae1894c89509b3`. The actual target bytes hash to `924d4b151a644f9b490529c68f0349e188fddd400959b4b0ebe065a62715cf1e`, exactly its `formal_sha256`. The different `supplied_sha256` in that manifest refers to pre-mask input and is not the actual masked target hash. The six other original files match their listed hashes. The c85 supplement manifest hash is `6736c20b216fb71cc92cd3b1fd6fe01b9e33fa514d03b46f3879b97f447acd4d`; all seven supplied formal hashes match. The c86 manifest hash is `5c57717128d4020e089dd57d6ce52163edf16d9d598c70102fe780a92fa45172`; its Units file matches `62838d7e9cc4129826203ed63d0361b1c504fa5b2d07c12fd7fff86949d06853`.

Public path aliases: `INPUT` means the c89 formal-only packet; `DEFINITIONS` means the authorized c85 supplement; `UNITS` means the authorized c86 supplement; `GOVERNANCE` means the six authorized governance files; `OUTPUT` means this decoder packet. All paths in this report are logical, not host paths.

## Entire target: scope, declarations and boundaries

`OUTPUT/target-inventory.lean` transcribes every nonblank formal line of `INPUT/WalkRecovery.lean`, including complete declaration headers and complete bodies. Only blank lines and comment-mask whitespace are normalized; this transcription is not represented as the byte-identical input. The actual input digest above binds the original bytes.

The sole import is `Hddivsteps590.Recovery`. The namespace is `ASPBE.Uncompute`; `open Hddivsteps` resolves unqualified provider names. There are no target-level `variable`, `section`, typeclass, notation, or option declarations. The namespace ends before the final two commands.

The entire target inventory is:

1. `ASPBE.Uncompute.recoverStepBits`: a `noncomputable def`, with explicit data arguments `(p : Int) (u : ZState)` and declared output `Int × Int`. It has no propositional premises.
2. `recoverStepBits_of_inv`: a private theorem in that namespace. Its implicit data binders are `{p : Int} {s : ZState}`. Its explicit propositional binders are `(hp : p % 2 = 1)`, `(h : Inv p s)` and `(hactive : s.g ≠ 0)`. Its result is the displayed equality of ordered integer pairs, not any of those three premises.
3. `ASPBE.Uncompute.recover_zWalk_active`: the public theorem. Its explicit binders, in order, are `(p x : Int)`, `(hp : p % 2 = 1)`, `(t : Nat)` and `(hactive : (Hddivsteps.zWalk p x t).g ≠ 0)`. Its result is the pair equality at time `t + 1` shown in the transcription. In particular, `Inv` is not a public binder; the proof supplies it using `invariant_zWalk`.

`#check ASPBE.Uncompute.recover_zWalk_active` and `#print axioms ASPBE.Uncompute.recover_zWalk_active` are literal trailing command directives. They were not executed, and their presence is not evidence about acceptance or axioms. Private-name mangling is not determined here.

## Objects and exact mathematical conventions

Write a state as `s = (z,f,g,a,b)` in the field order of `Hddivsteps.ZState`: `z`, `f`, `g`, `fv`, `gv`, all integers. The aliases `a` and `b` in this report mean `fv` and `gv`, not additional state fields. Put

\[
\epsilon(s)=g\bmod 2,\qquad
\sigma(s)\Longleftrightarrow (z\geq0\ \land\ \epsilon(s)=1).
\]

Integer division and remainder here are Lean's Euclidean `Int.ediv` and `Int.emod`. All divisors used in the target's arithmetic formulas are positive powers of two, so division is floor division, and remainders lie in the usual nonnegative interval. In particular `g % 2` is 0 or 1 even when `g` is negative. Natural subtraction `j - 1` is truncated at zero.

The exact step is

\[
T(z,f,g,a,b)=
\begin{cases}
(-z,\ g,\ (g-f)/2,\ 2b,\ b-a),&\sigma(s),\\
(z+1,\ f,\ (g+\epsilon(s)f)/2,\ 2a,\ b+\epsilon(s)a),&\neg\sigma(s).
\end{cases}
\]

The walk is `S_0 = (0,p,x,0,1)` and `S_(t+1) = S_t` if its `g` field is zero, otherwise `S_(t+1) = T(S_t)`. Thus the walk freezes, whereas `zStep` itself has no freeze branch. The provider's `bbit s` is `f % 2` in the swap branch and `g % 2` otherwise. This is not definitionally the target's second result expression on arbitrary states; the proof relates it to `g % 2` specifically in the nonswap cases.

For an integer `v`, `padicValInt 2 v` is `padicValNat 2 v.natAbs`. The latter is the first projection of `Nat.maxPowDvdDiv 2 v.natAbs`. At zero it is 0, not infinity. For nonzero `v` it is the exponent of two in its factorization. In particular the lower-branch witnesses used in the proof establish nonzero `fv` and identify that exponent rather than assuming an infinite valuation convention.

For natural `k`, the provider defines

\[
\operatorname{bit}_k(v)=\frac{v\bmod 2^{k+1}}{2^k}.
\]

This is an integer-valued bit, not a Boolean or a `Fin 2` term. `ZMod n` is definitionally `Int` at `n=0` and `Fin (n+1)` at positive modulus `n+1`. Here the modulus is always `2^j`, hence positive, including `j=0`, where it is 1. `ZMod.val` is the canonical natural representative for positive modulus. The target coerces that representative to `Int` before applying `bitk`.

The `ZMod` inverse operation is total: at modulus 0 it is integer sign; at modulus `n+1` it is the cast of `Nat.gcdA i.val (n+1)`. It is a genuine multiplicative inverse on units; it is not a partial operation restricted by a type-level unit premise. In the theorem's last branch, oddness of the relevant factor is proved internally and supplies the unit fact. No prime-modulus assumption appears. The precise algorithm of `Nat.gcdA` is outside the requested expansion; the supplied exact inverse definition and `mul_inv_eq_gcd`/unit laws specify the boundary used here. `Int.ModEq n a b` is literally `a % n = b % n`.

## The decoder definition on its whole carrier

Let `u=(Z,F,G,A,B)`. The first output of `recoverStepBits p u` is 1 exactly when `A % 4 = 2`, otherwise 0. The second output uses this ordered decision list:

| Condition reached, in order | Second integer output |
| --- | --- |
| `A % 4 = 2` | 1 |
| otherwise, `G = 0` | 1 |
| otherwise, `1 ≤ Z` | 0 |
| otherwise | formula below |

In the final branch, set `j = padicValInt 2 A` and `q = A / 2^j`; the output is

\[
\operatorname{bit}_{j-1}\!\left(
\operatorname{val}_{2^j}\bigl([p]\,[Fq]^{-1}\bigr)
\right).
\]

The definition reads `p`, `u.fv`, `u.g`, `u.z` and, in the last branch, `u.f`; it never reads `u.gv`. Its entire formula is specified even for non-invariant states and even `p`. The theorem does not certify the interpretation of those off-domain values. This is a direct piecewise definition, not a choice from a characterization and not a selected quotient representative. The modular term's representative is fixed by `ZMod.val`. Without source access, this is a formal definition-status description, not a judgment that its total formula matches some external definition.

## Exact theorem content in ordinary mathematics

For every odd integer `p`, every integer `x`, and every natural time `t` such that the `g` field of `S_t` is nonzero,

\[
\operatorname{recoverStepBits}(p,S_{t+1})
=\bigl(\mathbf1_{\sigma(S_t)},\ \epsilon(S_t)\bigr).
\]

The first component identifies which conditional branch the active step used; the second recovers the predecessor's parity remainder. The decoder knows `p` and the successor state, but the displayed formula does not require the successor's `gv` field. Both recovered quantities are encoded as integers. The equality is exact.

There is no positivity, size, primality, coprimality, termination-time or input-range hypothesis on `p` or `x` beyond odd `p`; `t` is unrestricted except for the active-state premise. The theorem is one-step branch-bit recovery along this particular frozen walk. It is not a theorem reconstructing the whole predecessor, nor does it cover a predecessor whose `g` is already zero.

## Invariant, expanded rather than hidden

The private theorem assumes the following exact project-owned proposition `Inv p s`:

\[
\begin{aligned}
f b-g a&=p,\\
f\bmod2&=1,\\
z\geq0&\Longrightarrow 2^{\operatorname{toNat}(z)+1}\mid a,\\
z<0&\Longrightarrow \exists j\in\mathbb N,\ q,r\in\mathbb Z\text{ such that}\\
 &1\leq j,\quad q\bmod2=1,\quad a=2^j q,\\
 &0\leq r<2^j,\quad 2^{j+\operatorname{toNat}(-z)}\mid b-qr.
\end{aligned}
\]

`Inv` is a Prop-valued structure with fields `det`, `fodd`, `high`, and `low`, not a data-producing routine. Its existential witnesses occur inside a conditional invariant field, not as public theorem binders. `Inv.fveven` obtains even `a` by splitting on the sign of `z`. `Inv.gvodd` combines that evenness and the determinant with odd `p` to obtain odd `b`. `Inv.zStep` proves preservation of all four fields by the step formulas. `inv_zSeed` produces the seed invariant from odd `p`; `invariant_zWalk` then inducts on time, retaining the old invariant in the freeze case and applying `Inv.zStep` otherwise. This is the actual visible producer chain for the public theorem's invariant, not an assumption silently added to its statement.

These are logical input/definition facts only. Source-relative classifications such as SOURCE or EXCESS are intentionally not assigned without a source contract.

## Proof reconstruction and roles

For the private theorem, take an invariant active state `s` and write `u=T(s)`.

First, the first projection of `sigma_class h hp` says `sigma(s)` is equivalent to `u.fv ≡ 2 [ZMOD 4]`. The target changes that congruence to equality of remainders and normalizes `2 % 4`. The local producer `swap_iff_fv` proves the equivalence because in the swap branch `u.fv=2*s.gv` with odd `s.gv`, while in the nonswap branch `u.fv=2*s.fv` with even `s.fv`. Thus the decoder's first component is correct in both branches.

If the step swaps, the first decoder condition holds, giving pair `(1,1)`. The branch hypothesis itself contains `s.g % 2 = 1`, so this pair equals the result. This target branch does not call `bbit_of_swap` directly.

If the step does not swap, the first decoder test fails. There are three subcases:

1. If `u.g=0`, `bbit_of_freeze h.fodd hactive hzero` yields `bbit s=1`. Here active `s.g≠0` is essential to its argument: in the nonswap even case a nonzero even integer cannot halve to zero. Combining with `bbit_of_nonswap` gives `s.g % 2 = 1`, matching the decoder's second test.
2. If `u.g≠0` and `u.z≥1`, nonswap implies `u.z=s.z+1`, so `s.z≥0`; an odd `s.g` would force the swap condition. `bbit_of_ramp` packages the resulting `bbit s=0`. Combined with `bbit_of_nonswap`, this matches the decoder's third test.
3. If neither subcase holds, nonswap still gives `u.z=s.z+1`; the failure of `1≤u.z` forces `s.z<0`. The target calls `ladder_det h hp hz rfl rfl` with the decoder's exact valuation and quotient, and combines it with `bbit_of_nonswap`. This proves that the final modular-bit formula equals `s.g % 2`.

The pair equalities in each branch use congruence under `b ↦ (1,b)` or `b ↦ (0,b)`; their reversed equalities explain the `.symm` in the code. There is no additional pair-valued hypothesis.

For the public theorem, `hactive` removes the walk's freeze branch from `zWalk_succ`, giving `S_(t+1)=T(S_t)`. After this rewrite, `recoverStepBits_of_inv hp (invariant_zWalk hp x t) hactive` supplies the desired equality. This is a composition of the actual active-step recurrence, internally produced invariant, and private recovery theorem.

### What `ladder_det` actually supplies

The lower invariant of `s` has witnesses `j0≥1`, odd `q0`, and `0≤r0<2^j0`. Because `s.z<0`, a nonswap step gives

\[
u.fv=2^{j0+1}q0,\quad
r=r0+(s.g\bmod2)2^{j0},\quad
2^{j0+1}\mid u.gv-q0r.
\]

`ladder_exists` constructs these witnesses, with `j=j0+1≥2`, using the extra power of two in the lower invariant. `padicValInt_of_odd_factor` identifies `j` with the valuation and `q0` with the decoder's quotient. `ladder_witness` compares any bounded witness to the constructed one: uniqueness of an odd-factor power-of-two decomposition fixes the exponent and odd factor, odd cancellation gives the difference of the two residues divisible by `2^j`, and their common bounds force equality. Dividing the constructed `r` by `2^(j-1)` therefore returns `s.g % 2`. `ladder_core` packages this as `bitk r (j-1)=bbit s` together with the witness bounds and congruence.

`ladder_det` also obtains `Inv p u` from `Inv.zStep`. Consequently `u.f` is odd, `q` is odd and `u.f*q` is a unit modulo `2^j`. The determinant and `2^j | u.fv` give

\[
p\equiv u.f\,u.gv\equiv u.f\,q\,r\pmod{2^j}.
\]

`inv_val_eq_of_witness` cancels the odd factor by the unit inverse and uses `0≤r<2^j` to identify the canonical representative of `[p][u.f*q]^-1` with exactly `r`. Its proof uses the actual `ZMod.coe_int_isUnit_iff_isCoprime`, `ZMod.mul_inv_of_unit`, and `ZMod.val_intCast` interfaces. Thus the predecessor parity is obtained without needing `u.gv` as decoder input; `u.gv` remains part of the proof of the determinant congruence.

## Textual provider routing, not elaborated proof dependencies

The target's visible calls route as follows. This is an account of the supplied proof text, not an exhaustive kernel dependency graph.

| Consumer / obligation | Visible named producer |
| --- | --- |
| Active walk recurrence | `Hddivsteps.zWalk_succ`, then `if_neg hactive` |
| Invariant at predecessor | `Hddivsteps.invariant_zWalk` |
| Invariant seed and propagation | `inv_zSeed`, `Inv.zStep` |
| Swap detected by successor `fv` | first conjunct of `sigma_class`; local `swap_iff_fv` |
| Nonswap parity identification | `bbit_of_nonswap` |
| Newly zero successor | `bbit_of_freeze`, with `h.fodd` and `hactive` |
| Positive successor counter | `bbit_of_ramp` |
| Negative predecessor counter | `zStep_nonswap` and integer arithmetic |
| Remaining modular bit | `ladder_det` |
| Lower modular-bit witnesses | `ladder_core`, `ladder_exists`, `ladder_witness` |
| Unique odd-factor decomposition | `padicValInt_of_odd_factor`, `two_pow_mul_odd_inj` |
| Odd cancellation / bounded residue equality | `isCoprime_two_pow`, `pow_two_dvd_cancel`, `eq_of_sub_dvd_of_bounds` |
| Canonical modular representative | `inv_val_eq_of_witness` and the ZMod interfaces above |

The target uses only the first projection of `sigma_class`; that provider's full proof also proves its valuation equivalence and divisibility conclusion. Their presence is neither an extra target premise nor evidence of a separate consumer use. The neighboring `ladder`, `finite_dependence`, and `j2_law` declarations are not explicit calls from the target. Similarly, no inference of a theorem-specific dependency on every declaration of `NumberTheory` or `Defs` is made merely from their module import.

Tactic and generic proof infrastructure visible in the target consists of local `have` bindings, `change`, `norm_num`, case splits, `simp only`, `rw`, `omega`, `congrArg`, equality symmetry/transitivity and iff projections. Provider proofs additionally use ring arithmetic, divisibility, parity, valuation, modular-cast and unit lemmas. These are proof mechanisms and imported interfaces, not new scientific assumptions.

## Read coverage

The six governance files were read completely. `INPUT/WalkRecovery.lean`, `INPUT/Hddivsteps590/Defs.lean`, `INPUT/Hddivsteps590/NumberTheory.lean`, `INPUT/lean-toolchain`, `INPUT/lakefile.lean`, and `INPUT/lake-manifest.json` were read completely. `INPUT/Hddivsteps590/Recovery.lean` was first searched for declaration/scope boundaries; complete relevant declarations and full bodies were read in line regions 53–118, 163–306, 433–694 and 727–EOF. The final region also disclosed neighboring `ladder`, `finite_dependence`, and `j2_law`; those are not promoted to target premises or claimed target consumers. The target's provider ambient syntax includes `namespace Hddivsteps` and `variable {p x : Int} {s : ZState}`; occurrence-dependent implicit parameters are respected. No source claim is inferred from the namespace or file names.

In `DEFINITIONS`, hashes of all exact files were checked, and declaration-boundary searches were confined to the allowed files. `Mathlib/NumberTheory/Padics/PadicVal/Defs.lean` was read completely. The semantic expansion reads were: `PadicVal/Basic.lean` lines 73–121 and 661–693 (valuation definition, zero behavior, relevant laws and ambient scopes); `Nat/MaxPowDiv.lean` lines 19–114 (complete recursive producer, projection and zero rules); `Int/ModEq.lean` lines 6–71 (imports, exposed section, exact definition and notation); `ZMod/Defs.lean` lines 142–232 (carrier and complete ring-instance body); `ZMod/Basic.lean` lines 40–66, 501–505, 712–740 and 840–850 (carrier equivalence context, representative, cast representative law, exact inverse/instance, gcd product and unit laws); and `Init/Data/Int/DivMod/Basic.lean` lines 66–121 (exact Euclidean operators and instances), with namespace boundaries checked. Incidental adjacent declaration starts were not treated as complete proof evidence. `UNITS/Mathlib/Data/ZMod/Units.lean` ambient lines 20–23 and complete declarations in lines 117–174 were read, including `coe_int_mul_inv_eq_one`, `unitOfIsCoprime` and `coe_int_isUnit_iff_isCoprime`; the preceding tail encountered in the read is not used as complete evidence for its enclosing theorem.

The build files pin Lean `leanprover/lean4:v4.33.0` and mathlib revision `db584cd6d46c92f209a44c0f1c829460d327499d`. Those are syntax/provenance observations, not evidence that this environment resolves imports or accepts the target.

## Claimed boundary and precise residuals

This packet reconstructs the target's entire written interface, the full proof's branch structure, the exact total decoder definition, the expanded invariant and its visible producer chain. It does not establish compiler acceptance, elaborated theorem dependencies, or axiom closure. No actual command output for the trailing Lean directives is supplied or inferred.

No whole-predecessor inverse, injective state map, circuit construction, reversible implementation, resource/runtime bound, finite-bit model, global algorithm endpoint, source equivalence, source proof coverage, source-relative binder verdict, admission, publication closure, or root-frontier closure follows from this target reading. Even complete branch-bit recovery is stated only for an active step with the specified invariant, and publicly only along the seeded frozen walk with odd `p`.

The imported finite-ring/integer/valuation interfaces have been expanded far enough to resolve the target's arithmetic conventions, including zero valuation and total inverse. Their full transitive implementation/trust bases remain unexpanded; `Nat.gcdA` is left as the exact named primitive appearing in the supplied inverse definition. This is a declared boundary, not a mathematical gap in the reconstructed argument. No execution or kernel dependency extraction has been performed.

Source comparison requires a later, distinct review after source release. The original packet's bounded comment mask is not a general lexical noninterference proof; this decoder cannot certify facts about concealed source metadata or comments. This report's independence is procedural evidence from the recorded access boundary, not a theorem established by file counts or hashes.

## Structured handoff

Objective / frontier node: independent small-formal-definition-and-composition reconstruction of the entire c89 target before source release.

Mathematical delta: an explicit account of the ordered decoder, invariant propagation, four proof cases and determinant-based final bit recovery; public invariant is internally produced rather than a result-shaped public hypothesis.

Effect on root frontier: no root assertion; decoder evidence only.

Named evidence: the sealed target and authorized formal providers, with complete target headers/bodies in the companion transcription. No tests or finite witnesses.

Assumptions and conventions: exactly as expanded above; no source-relative labels assigned.

Files changed: only the new `OUTPUT` allowlist. Inputs unchanged. No commit/push.

Reusable insight: successor `gv` can be eliminated from the decoder formula by determinant congruence, while remaining indispensable as a proof witness field.

Failure class: NONE for the bounded reading task. Required execution and source-comparison stages are intentionally withheld, not classified as environment or mathematics failures.

Salvage audit: not applicable; no rejected construction or implementation attempted.

Process-memory IDs consulted: none; restricted packet did not authorize broader process records.

Direction fingerprint: `small-formal-definition-and-composition-reconstruction`. Expected information gain: independent reconstruction of the whole small target without an intended source conclusion.

Parallel admission: assigned distinct source-blind decoder role; no subagents spawned. Common-blind-spot review is outside this packet.

Default verified route / comparator: none selected; no verified-construction comparison performed.

Purification / Exposition Seal: not asserted. Formal expansion nodes and preserved assumption/boundary are recorded above; source nodes unavailable.

Typed obstruction / residual confidence: no blocker to syntax-level mathematical reconstruction; compiler, source and full imported trust evidence remain separate residuals. High confidence in the displayed mathematical reading, not a checked-proof certification.

Recommended next stage: hold this frozen packet unchanged for an independently anti-anchored comparison after source release; seek separate execution evidence only under an authorized later stage.

Context digest: odd-parameter frozen integer walk; exact successor decoder for swap indicator and old parity; private invariant lemma plus walk composition; no source or execution evidence. STOP BEFORE SOURCE RELEASE.
