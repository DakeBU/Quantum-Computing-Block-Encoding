# C87 additive exact-input and observed-elaboration review

Reviewer: `c87-small-bridge-execution-binding`, actual agent `/root/uncompute_appendix_topology_c87`. This is a new stage after the source-only review, own-formal-first interpretation and actual-decoder comparison were sealed. Their judgments were not edited after raw/compiler release. This packet concerns the already reconstructed small active-walk bridge, not admission of whole upstream or production modules.

## Outcome

The narrow correspondence and observed-execution gap is closed for the four specified files: the three original providers match their exact allowed upstream Git blobs, the original bridge matches its exact allowed contribution Git blob, independent file-specific comment masking reproduces the reviewed C89 formal bytes and C91 staged bytes, and a new bounded root elaboration succeeds with the same precise type/ordinary-axiom stdout as the successful raw and C91 records, and the same root artifact as C91. No raw-build .olean comparison is claimed. The initial failed bridge attempt remains a failure. Historical cache-emptiness and transitive-library certification are separately qualified below.

## Exact source, mask and stage transport

The upstream repository was accessed only through the authorized read-only Git show operations at commit `64b5a13aa249f1360846657392e6c66817b26d0f`, for the three `lean/divsteps/Hddivsteps590` files. Their current raw input SHA256 values are Defs `ebdcfca0f61776c7fac2c025e7b39b89863892d3b38bcb351810ddf9e06e82c1`, NumberTheory `3508d41c0bc772aa1f8dfb3f2346c690f96de74444d57adc33314d9d051d0564` and Recovery `e1a1340f3c105874e06eae73fb21210ce18491aa103755e2bfa0b29ba764fa9d`. Each Git blob is byte-identical to its designated raw file.

The bridge Git operation was limited to G commit `5c7e2e0afef917c38feccd050c6188f01e4a17b0`, tree path `experiments/uncompute-2610-22367/active-walk-c88/WalkRecovery.lean`. That blob equals the allowed raw bridge, SHA256 `1ee1454e2328750fa730029553a7b186d1af46c4f50f6d1238d5deff70f4b1fb`. An initial sandboxed attempt could not enter G for this Git read. That was an access failure, not unequal source bytes; the explicitly authorized read-only check passed with normal escalation. No fetch, branch operation, unrelated manual Git query or network operation occurred. Ordinary package/cache queries performed internally by the authorized Lake environment commands are not treated as an independent Git metadata audit.

I read the bounded redactor, its nine tests, and the C91 runner as text. I did not merely reuse their success flags. A separately authored scanner independently classified all bytes of each actual raw file into code, quoted text or nested/line comments, retained noncomment text, replaced comment characters by their UTF-16-width spaces and normalized CRLF to LF. All four results equal both their exact C89 formal file and C91 staged file. The actual source files contain no string literals, quoted identifiers or UTF-8 BOMs under the scanner. Comment counts are27,23,73,1 respectively; NumberTheory has3 line comments and Recovery18, the remaining comments are blocks. Therefore the raw-to-mask review depends on a particularly small actual lexical subset, not just synthetic examples. The nine tests also pass, but are supporting diagnostics, not a Lean lexer theorem. A general lexical/macro noninterference proof is not issued.

This now resolves the specific earlier raw-Recovery-versus-masked-Recovery provenance boundary without changing the earlier review record. The two byte sequences remain different evidence objects. Mathematical reading and source faithfulness of every upstream theorem are still not established merely by their transport.

## Runtime context and original-input invariance

The only newly inspected G configuration files were lean-toolchain, lakefile.lean and lake-manifest.json. Toolchain and manifest are byte-identical to the formal context; the runtime lakefile is not byte-identical but its one line-comment mask exactly reproduces the formal lakefile while preserving its five strings. The actual compiler reports Lean4.33.0, commit `d8b18978322de05a8f3dba51ef03cf5461676c17`; the installed lean.exe SHA256 is `dd86e9b24990b1da425ea4af910f016e4db8f9a25c9ddad27bc6bee3690e677f`, matching the C91 record. The manifest's mathlib revision remains `db584cd6d46c92f209a44c0f1c829460d327499d` as read previously; its entire cache is not independently rebuilt.

A before/after snapshot covered29 designated original files: raw4, C89 formal4 and context3, C91 source4, runtime context3, the C91 aggregate and four individual records, the two earlier raw execution records and the four original C91 oleans. All29 hashes are unchanged. Previous C87 seals are also retained. No production source, configuration, old evidence or original compiled output was intentionally written. Commands did not request a full build or cache/config mutation. This is not a claim that every uninspected file in G or its .lake tree was globally snapshotted; ordinary Lake environment/package queries can read cached metadata.

## Recorded execution, with the negative retained

The allowed C91 aggregate matches assigned SHA256 `43ea790a9de1b389b2cf7a37357c05e34a455d779b861a6b9902418ec0b20f58`. Each of its four record objects equals the separate record file. Encoded stored stdout/stderr reproduce their supplied digests; all four existing .olean hashes match their records. Recorded exit codes are0,0,0,0. These are consistent bound execution records, not accepted merely because the aggregate says success.

C88 attempt1 instead has exit1, an unsolved goal and sorryAx in its axiom output. Its historical source hash is `7ef03ff18fa04d8f765fb2442398709993d51ac5164e9adf393ac4c1b9f98735`, not the successful source hash. It remains IMPLEMENTATION_FAILED, not a successful theorem or a mathematical counterexample. The separately named historical source snapshot was outside this stage's file allowlist and was NOT opened; its historical contents are known here only through the record's hash/output bindings.

C88 attempt2 has exit0, current raw bridge SHA `1ee1454e...`, and stdout hash `6a34470d7054cf2f4b6541e62ef3113764aaf9c069f088168555b1cd3f736177`. That stdout is byte-identical to the C91 masked root record and the new independent root observation. Printed theorem signatures alone would not have rescued attempt1; its failure and sorryAx are explicitly retained.

## Independent bounded root observation

I created a NEW private output directory, checked the output did not exist, measured6581MiB available (required minimum3584MiB) and ran the following normalized command with cwd G and LEAN_PATH set to W/uncompute-c91-masked-compilation before Lake adds its dependency paths:

    lake env lean -M 1536 -j 1 --root=W/uncompute-c91-masked-compilation -o W/uncompute-c87-bridge-execution-binding-private/run-v2/WalkRecovery.olean W/uncompute-c91-masked-compilation/WalkRecovery.lean

The memory cap is1536MiB, reserve2048MiB, one compiler thread. Exit0 after19.218s; a new output was emitted. Its SHA256 is `b6b9e25daaf23690623d3514b5e040ddb560964d21b01fe693859a6aeeea473f`, exactly the original C91 root artifact. Its stdout is the exact source-free type/axiom output reproduced in execution-evidence.json, byte hash `6a34470d...`. The printed axiom list is exactly `[propext, Classical.choice, Quot.sound]`; sorryAx is absent. This is an actual observation after the independent interpretations were frozen, not an inference from #check/#print text.

Independent `lake env lean --deps` calls for all four current staged .lean files verify the direct local chain: NumberTheory imports C91 Defs.olean, Recovery imports C91 NumberTheory.olean, and the root imports C91 Recovery.olean. No other work-stage path appears in those direct dependency outputs. The current original oleans match the recorded C91 hashes before and after the recheck. Cached Mathlib and Lean artifacts are still used; --deps is import-resolution evidence, not an elaborated theorem-call graph.

The C91 runner text asserts a new absent stage, no prior oleans, ordered provider builds and a root dependency check. The retained four successful records and matching artifacts support that recorded bounded construction. I did NOT independently witness that historical directory's initial emptiness. My own NEW root output was absent and freshly emitted, but I reused the now-bound C91 provider caches rather than independently rebuilding all providers or Mathlib. These are distinct freshness claims, and only the latter root event is directly observed by this reviewer's execution.

## Warnings, boundaries and stopping point

The nonfatal warning that the cached Verso repository has local changes remains in raw stderr; it is not suppressed or promoted to a clean-cache claim. The provider's style warning also remains recorded. Public command/path text is a logical-root derivative, not byte-identical raw logging. Digests attached to original stdout/stderr refer to original private bytes, not normalized text. Path-bearing logs and checker scripts stay outside the exact public allowlist.

Accepted now: file-specific original/Git/masked/stage correspondence, actual pinned-context/root type and ordinary-axiom output, current local import/cache binding, and original-file invariance. Not accepted by this packet: a general Lean lexer proof, arbitrary historical cache creation claims, full imported proof-term/TCB or whole-upstream source certification, production/full-library build gates or publication admission. The existing source-domain generalization and internal total-decoder extension labels remain; A.3 external590/primality, quantum coherent/phase/ancilla semantics, finite-word overflow and circuit/resources, ROOT/PURIFIED and Exposition Seal remain outside scope.

The governance distinction between source, mathematical reconstruction, observed elaboration, cache provenance and circuit/resource certification guided this separate additive stage. All prior freezes and negatives remain unchanged. Stop after this bounded verification; no final publication approval or formal release is issued.
