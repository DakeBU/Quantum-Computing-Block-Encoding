# Additive comparison of immutable C87 reading with fresh C89 decoder

Reviewer: `c87-small-bridge-decoder-comparison`, actual agent `/root/uncompute_appendix_topology_c87`. Roles are distinct: parent formalizer, `/root/formal_bridge_decoder_c89` source-blind decoder, and this source-first reviewer. This is a NEW packet. Neither earlier C87 packet nor any decoder input/output is modified.

## Bound evidence and chronology

My own interpretation was frozen in W/uncompute-c87-bridge-own-formal-first before this decoder release. Its manifest SHA256 is `fbba8e656ee7d1295e3b30f6fb34689f5d56bcad9da71364b5c449a693299673` and seal SHA256 `cc9036c272f42cde069567bd408657726a9268ee1f66832d525748a1bf10e4e7`. Both and every own-first payload binding were rechecked unchanged. I reread the immutable own-mathematical-interpretation alongside the decoder's complete reconstruction and complete target transcription.

The newly authorized actual decoder manifest hashes to `cb2f83373cdf68d0d09ed5422ed86b74de1fa7fa189d558c6bee87f919da04f9`; its seal hashes to `383c154b8a7f2921efd03f15e07293366809e787dc681b0caa2a05b969f0d07d`. Both payload hashes match. The decoder explicitly withholds source-relative SOURCE/EXCESS labels because its source was not supplied; that is appropriate, not a disagreement with the later source-first audit.

Only those four decoder files were read. No other review, raw author Lean, compiler/olean or execution result, R metadata, Git, network or simulator was read or run. Independence is supported by the distinct actual assignment identities and access chronology, not logically proved by hashes or identity strings. The decoder's own read-coverage record is its procedural evidence, not a whole-library certificate from this reviewer.

## Literal transcription: exact discrepancy, not byte identity

The original target is W/uncompute-c89-formal-input/WalkRecovery.lean, SHA256 `924d4b151a644f9b490529c68f0349e188fddd400959b4b0ebe065a62715cf1e`. The decoder's target-inventory.lean hashes to `e40c49cf6f751757f98f23bcf1b36ef5535dc1904cf0885d17efac70dc0d8bbd`. They are NOT byte-identical.

The exact observed difference is deletion of original target lines7 and8, containing respectively76 and81 ASCII spaces, each followed by LF. Original target:65 lines,56 nonblank lines. Decoder transcription:63 lines,56 nonblank lines. Every nonblank line, including indentation, matches exactly in order. A stronger separate check deleted exactly that one adjacent two-line whitespace block from the original UTF-8 text; the resulting UTF-8 hash is the inventory's actual hash and its complete text equals the inventory. Both original and inventory use LF, with zero CRLF occurrences. Thus for these exact bound files the normalized transcription retains all formal text; this is not a general lexer or comment-mask noninterference proof.

The import, namespace/open declaration, complete decoder definition, complete private theorem header/body, complete public theorem header/body, namespace end and trailing #check/#print axioms directives are retained. The directives are text, not observed compiler outputs.

## Mathematical agreement

Both independent readings reconstruct the same integer state, the same swap/nonswap recurrence and the same frozen scheduled walk. Both distinguish literal zStep (no freeze) from zWalk (hold state after g=0). Both recover an ordered Int pair, not a whole predecessor or a Boolean-typed pair, and both identify the public theorem's only propositional premises as odd p and CURRENT incoming g!=0. Neither introduces positivity, range, primality, gcd=1, termination bound, inverse extraction or an all-earlier-active premise.

The decoder's aliases a,b for fv,gv differ from my F,G notation, and it explicitly says its b is not an extra field. This notational difference does not change the source's decision bit: its epsilon is incoming g mod2. Both readings separately flag the provider bbit definition (f mod2 on swap, g mod2 otherwise) and the actual target's explicit nonswap adapter. The swap proof obtains incoming g odd directly from its guard and does not silently apply bbit globally.

Both reconstructions preserve the exact priority: F'%4=2 gives (1,1); otherwise first output0, with second output1 if g'=0, otherwise0 if z'>=1, otherwise the determinant-ladder bit. The decoder explicitly observes that the function never reads successor gv. This agrees with the displayed definition and with my proof account: gv remains essential to the determinant/window proof, not an extra runtime input to that expression.

The complete private helper has implicit data p,s and explicit hp, Inv, hactive. Both readings expand Inv into the same four fields: determinant, f odd, nonnegative-counter divisibility, and negative-counter existential bounded-window clause. Inv is valid as a private provider premise; the public theorem produces it from inv_zSeed, Inv.zStep and invariant_zWalk. No result-shaped or oracle premise has migrated into the public Anchor. No project-owned Prop/typeclass bundle remains unexpanded at that public boundary.

All four guarded branches have actual suppliers. sigma_class provides swap visibility. Newly zero nonswap uses f odd and incoming active in bbit_of_freeze; ramp uses nonswap and updated z>=1; the residual proves incoming z<0 from nonswap z'=z+1 and failed ramp. The final public rewrite uses hactive to establish the ACTUAL t+1 successor equals zStep. Neither reading treats arbitrary frozen identity transitions as active decoder claims.

In the fallback both readings follow the real chain: Inv.low -> incoming odd factor and bounded residue -> ladder_exists outgoing j>=2 and same odd factor -> valuation/quotient identification and ladder_core bounded bit witness -> updated invariant and determinant -> odd f'q -> unit and canonical representative cancellation -> ladder_det -> nonswap parity adapter. Reflexivity arguments instantiate exact j,q; they are not assumed unit facts. The actual formal organization shares ladder_core between two formulas; it need not duplicate the source narrative's theorem-call order.

## Definitions and source comparison

Both readings explicitly reconstruct Euclidean signed bits, natural truncated j-1, padicValInt(2,0)=0, positive modulus2^j, canonical val and total ZMod inverse via the named Bezout coefficient. Neither assumes inverse cancellation on arbitrary nonunits. My source-first qualification remains: the paper's zero valuation is infinity, so the total formal decoder is an INTERNAL extension, not a literal source definition on arbitrary tuples. Nonzero F', j>=2 and odd denominator are actually supplied at the theorem's fallback; hence this off-domain difference does not change the guarded source theorem.

The source-blind decoder correctly states arbitrary odd integer p and arbitrary integer x without claiming those are the source's hypotheses. Comparison with C88 and the independently reconstructed Appendix shows the same disclosed domain generalization: source p>0,0<=x<p is a specialization. The decoder's refusal to assign source-relative labels in isolation is not a missing binder audit; that audit was independently frozen earlier and now agrees with the literal reconstructed binders.

The complete source-local allactive objective is an AND of exhaustive guarded cases. The A11 alternatives are evaluation-interface OR-routes; the actual target selects the determinant expression. Agreement of these two readers does not make a single case sufficient for the whole theorem or prove that the source and Lean dependency graphs are identical.

## Split verdict and retained boundaries

- Actual decoder integrity and complete literal normalized transcription: PASS; exact two-whitespace-line discrepancy disclosed.
- Complete small target's mathematical reconstruction versus immutable own reading: AGREE; no material semantic discrepancy found.
- Actual public/private binders, definition extension and every producer/active/branch/unit guard: ACCEPT at the inspected mathematical proof-text level; no EXCESS public binder or missing supplier found.
- C88 and local Appendix fidelity: ACCEPT on the source locus, with the existing explicit generalization and internal-extension labels.
- Mandatory mathematical repair: none found in this bounded comparison.

The separate boundaries remain unchanged: raw upstream Recovery bytes versus masked provider bytes/commit transport; correctness of the masking procedure; actual elaboration, proof terms and axiom closure; whole-upstream source review and imported-library/TCB audit; source external590 bound and primality; quantum coherent/relative-phase/ancilla realization, finite-word overflow and resources; publication/admission/ROOT/PURIFIED. These are not closed by reader agreement. No formal release or final publication approval is issued.

Skills/governance influenced this work by forcing actual complete-target coverage, recursive premise expansion, and separate source/implementation/transcription/circuit evidence layers. New packet only; stop after sealing before raw/compiler release or publication approval.
