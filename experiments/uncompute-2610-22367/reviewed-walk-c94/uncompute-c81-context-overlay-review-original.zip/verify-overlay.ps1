param([Parameter(Mandatory=$true)][string]$WorkRoot)
$ErrorActionPreference='Stop'
$utf8=[Text.UTF8Encoding]::new($false)
function J([string]$p){Get-Content -Raw -LiteralPath (Join-Path $WorkRoot $p)|ConvertFrom-Json}
function QHash([string]$p){(Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $WorkRoot $p)).Hash.ToLowerInvariant()}
function HT([string]$t){$a=[Security.Cryptography.SHA256]::Create();try{[Convert]::ToHexString($a.ComputeHash($utf8.GetBytes($t))).ToLowerInvariant()}finally{$a.Dispose()}}
function P([string]$t,[int]$i){$pre=$t.Substring(0,$i);[ordered]@{char_offset_0=$i;byte_offset_0=$utf8.GetByteCount($pre);line_1=1+@($pre.ToCharArray()|Where-Object{$_ -eq "`n"}).Count;column_1=$i-$pre.LastIndexOf("`n")}}
function PosEqual($a,$b){$a.char_offset_0 -eq $b.char_offset_0 -and $a.byte_offset_0 -eq $b.byte_offset_0 -and $a.line_1 -eq $b.line_1 -and $a.column_1 -eq $b.column_1}
$errors=[Collections.Generic.List[string]]::new()
$chains=@()
foreach($dir in @('uncompute-c81-appendix-source-first','uncompute-c81-own-formal-first','uncompute-c81-decoder-comparison','uncompute-c84-formal-decoder','uncompute-c84-context-successor')){
  $m=J ($dir+'/manifest.json');$s=J ($dir+'/seal.json');$bad=@();$files=if($m.payload_files){$m.payload_files}else{$m.files}
  foreach($f in $files){$p=$f.path -replace '^W/','';if((QHash $p) -ne $f.sha256){$bad+=$p}}
  $mh=if($s.manifest_sha256){$s.manifest_sha256}else{$s.manifest.sha256}
  if((QHash ($dir+'/manifest.json')) -ne $mh){$bad+='manifest binding'}
  $chains+=[ordered]@{root='W/'+$dir;manifest_sha256=(QHash ($dir+'/manifest.json'));seal_sha256=(QHash ($dir+'/seal.json'));payload_or_binding_mismatches=$bad}
}
$d=J 'uncompute-c84-formal-decoder/inventory.json';$o=J 'uncompute-c84-context-successor/context-overlay.json';$v=J 'uncompute-c84-context-successor/verification.json';$pins=J 'uncompute-c84-formal-decoder/pins.json'
$formalBad=@();foreach($f in $pins.files){$p=$f.path -replace '^W/','';if((QHash $p) -ne $f.formal_sha256){$formalBad+=$p}}
$t=[IO.File]::ReadAllText((Join-Path $WorkRoot 'uncompute-c84-formal-input/Hddivsteps590/Recovery.lean'),$utf8)
$commandMatches=[regex]::Matches($t,'(?m)^(?:import\b|namespace\b|variable\b|structure\b|def\b|theorem\b|private theorem\b|end\b)[^\r\n]*')
if($commandMatches.Count -ne 59 -or $d.commands.Count -ne 59 -or $o.commands.Count -ne 59 -or $v.record_checks.Count -ne 59){$errors.Add('record count')}
if((HT $t) -ne $d.target_sha256 -or $o.target_sha256 -ne $d.target_sha256){$errors.Add('target binding')}
if($o.original_inventory.sha256 -ne (QHash 'uncompute-c84-formal-decoder/inventory.json')){$errors.Add('original inventory binding')}
$namespace='_root_';$active=@();$origins=@();$transitions=@();$rows=@()
for($i=0;$i -lt $commandMatches.Count;$i++){
  $a=$d.commands[$i];$b=$o.commands[$i];$c=$v.record_checks[$i];$m=$commandMatches[$i];$end=if($i+1 -lt $commandMatches.Count){$commandMatches[$i+1].Index}else{$t.Length};$literal=$t.Substring($m.Index,$end-$m.Index)
  $bad=@();$ordinal=$i+1
  if($a.ordinal_1 -ne $ordinal -or $b.ordinal_1 -ne $ordinal -or $c.ordinal_1 -ne $ordinal){$bad+='ordinal'}
  if($literal -cne $a.literal_command -or (HT $literal) -ne $a.command_sha256_utf8 -or $b.original_command_sha256 -ne $a.command_sha256_utf8 -or $c.original_command_sha256 -ne $a.command_sha256_utf8){$bad+='literal/join/hash'}
  if(-not(PosEqual (P $t $m.Index) $a.extent_half_open.start) -or -not(PosEqual (P $t $end) $a.extent_half_open.end)){$bad+='extent'}
  if($b.legacy_references.namespace_owner_label -cne $a.namespace -or $b.legacy_references.ambient_variable_command_reference -cne $a.ambient_variable_command){$bad+='legacy values'}
  if($b.namespace_before_command -cne $namespace -or (@($b.ambient_origin_ordinals_before_command)-join ',') -cne ($active-join ',')){$bad+='before context'}
  if($m.Value -match '^namespace\s+(\S+)\s*$'){
    if($namespace -ne '_root_'){throw 'Unexpected nested namespace outside bounded case'}
    $namespace=$Matches[1];$transitions+=$ordinal
    if($o.namespace_transition_origins.Count -ne 1 -or $o.namespace_transition_origins[0].ordinal_1 -ne $ordinal -or $o.namespace_transition_origins[0].literal_command -cne $m.Value -or -not(PosEqual (P $t $m.Index) $o.namespace_transition_origins[0].origin)){$bad+='namespace origin'}
  }elseif($m.Value -match '^variable\b'){
    $active+= $ordinal;$origins+=$ordinal
    if($o.ambient_origins.Count -ne 1 -or $o.ambient_origins[0].ordinal_1 -ne $ordinal -or $o.ambient_origins[0].literal_command -cne $m.Value -or -not(PosEqual (P $t $m.Index) $o.ambient_origins[0].origin)){$bad+='ambient origin'}
  }elseif($m.Value -match '^end\b'){throw 'Unexpected closer outside bounded case'}
  if($b.namespace_after_command -cne $namespace -or (@($b.ambient_origin_ordinals_after_command)-join ',') -cne ($active-join ',')){$bad+='after context'}
  if(@($b.PSObject.Properties.Name|Where-Object{$_ -notin @('ordinal_1','original_command_sha256','legacy_references','namespace_before_command','namespace_after_command','ambient_origin_ordinals_before_command','ambient_origin_ordinals_after_command')}).Count){$bad+='unexpected overlay field'}
  if($c.all_literal_hash_extent_header_binder_body_checks -ne 'PASS' -or $c.historical_context_values_retained -ne 'PASS'){$bad+='actor verification flag'}
  foreach($e in $bad){$errors.Add(('{0}:{1}'-f $ordinal,$e))}
  $rows+=[ordered]@{ordinal=$ordinal;errors=$bad}
}
if($rows.Count -ne 59){$errors.Add('verification did not reach all59records')}
$historicBad=@();foreach($f in $v.historical_nine_before_after){$p=$f.path-replace '^W/','';if((QHash $p) -ne $f.sha256 -or -not $f.before_after_equal){$historicBad+=$p}}
$allow=J 'uncompute-c84-context-successor/public-allowlist.json'
$expected=@('build-context.ps1','erratum.md','context-overlay.json','verification.json','chronology.json','public-allowlist.json','manifest.json','seal.json')
$allowDiff=@(Compare-Object (@($expected)|Sort-Object) (@($allow.paths|ForEach-Object{Split-Path $_ -Leaf})|Sort-Object))
[ordered]@{schema='INDEPENDENT_CONTEXT_OVERLAY_CHECK_V1';record_count=$rows.Count;context_and_join_errors=@($errors.ToArray());namespace_transition_ordinals=$transitions;ambient_origin_ordinals=$origins;packet_hash_chains=$chains;six_formal_hash_mismatches=$formalBad;historical_nine_current_hash_mismatches=$historicBad;successor_allowlist_differences=$allowDiff;old_decoder_current_inventory_sha256=(QHash 'uncompute-c84-formal-decoder/inventory.json');actor_builder_executed=$false;mathematics_or_compiler_reassessed=$false}|ConvertTo-Json -Depth 10
