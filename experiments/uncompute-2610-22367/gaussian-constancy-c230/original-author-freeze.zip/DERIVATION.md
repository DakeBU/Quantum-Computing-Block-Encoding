# C230: aligned-128 constancy of the fixed integer increment

Classification: INTERNAL AUTHOR PROOF CANDIDATE, NOT COMPILED. The candidate imports the exact C227 `GaussianIntegerCore` and does not replace any definition or table. The public statement is literally the C229 preproof-sealed statement; its raw signature was compared successfully after writing. This packet is not an independent source review or a runtime-association review.

## Exact objective and mathematics

In namespace `UncomputeGaussian206`, prove

```lean
theorem localIncrement_block128_constancy :
  ∀ (j D : Nat), j < 1024 → D < 2^25 →
    localIncrement j D = localIncrement j (128*(D/128))
```

Put `B = 128*(D/128)`. For every natural exponent `e >= 7`, factor
`2^e = 128*2^(e-7)`. Associativity of natural-number division by a product gives

```text
D / 2^e = (D/128) / 2^(e-7)
B / 2^e = (B/128) / 2^(e-7) = (D/128) / 2^(e-7).
```

The equality `B/128 = D/128` is exact natural arithmetic, including `D=0`; no real approximation, signed-division convention, positivity premise on `D`, or numerical table fact is used. The candidate factors the power using `Nat.pow_add`, rewrites the quotient using `Nat.div_div_eq_div_mul`, and closes constant-coefficient natural arithmetic with `omega`. `norm_num` is used only for fixed small powers and the final index-10 schedule, not the frozen words.

### Middle path: preserve the actual modular slope

`localU D = D/2^14`, so the quotient lemma preserves it. In `middleRow j D t`, all appearances of `D` occur through `digit (localU D) t`. Consequently the exact signed integer row is unchanged for every `t`, not just `t < 6`. The correction sign, both separate `truncSigned` terms, and all `Int` divisions remain the imported ones.

The two `slopeStored` folds have the same starting value `slopeInitialStored j` and equal entire transition functions

```text
(s,t) |-> modBits ((s : Int) + middleRow j D t / 4) 19.
```

Function extensionality plus row equality therefore preserves the actual six-step modular stored slope, and multiplying it by 4 preserves `slopeWord`. This does not substitute `slopeUnbounded`, commute a modulus with a division, or assume a no-overflow property.

### Final path: both truncated quotients in each retained row

For each actual index `i=2,...,10`, the imported natural definitions give:

| i | finalShift i | finalDrop i | first divisor exponent | second divisor exponent |
|---|---|---|---|---|
| 2 | 17 | 6 | 23 | 22 |
| 3 | 15 | 6 | 21 | 20 |
| 4 | 13 | 6 | 19 | 18 |
| 5 | 11 | 6 | 17 | 16 |
| 6 | 9 | 6 | 15 | 14 |
| 7 | 7 | 6 | 13 | 12 |
| 8 | 5 | 6 | 11 | 10 |
| 9 | 3 | 6 | 9 | 8 |
| 10 | 1 | 7 | 8 | 7 |

Here the first exponent is `finalShift i + finalDrop i`; the second is `finalShift i - 1 + finalDrop i`, with the source's natural truncated subtraction. For `i <= 9`, the proof uses `finalShift i >= 3` and `finalDrop i >= 6`; with `i <= 10`, the remaining case is exactly `i=10`, evaluated symbolically. Thus both exponents are at least 7, including the endpoint where the second exponent is exactly 7.

For arbitrary fixed `F`, the quotient lemma preserves each separate `D / 2^exponent`, hence each `t1` and `t2`. `digit F i`, the multiplication by `2^drop`, all Nat-to-Int casts, the sign, and the bias term `(one+two)*2^(drop-1)` are unchanged. No assertion replaces the sum of individually truncated Booth rows by `floor(full product)`.

`finalSum F D` is the exact left fold over `List.range 9`, using index `r+2`. Its membership condition supplies `r<9`, hence the two index bounds needed above. A private fold-congruence lemma proves equality only on list members. This avoids the invalid shortcut of asserting the same exponent bounds for every natural index. The fold proof preserves arbitrary accumulators and row order.

Finally preserve `slopeWord` first and then `finalSum` at that same fixed slope. The `128*(a0 j : Int)` term is identical on both sides. Subtraction gives the exact `localIncrement` equality.

## Binder, definition and boundary audit

The public binders remain `j D : Nat`, `j < 1024`, `D < 2^25`, in that order. There is no added premise, correctness oracle, value bound, normal-form hypothesis, or table-fit hypothesis. The two public domain bounds are not needed internally: this definitional constancy argument works for arbitrary natural `j,D`. They are nevertheless retained exactly, not exchanged for an off-domain scientific claim. The private final-row helper retains the actual `2 <= i <= 10` interface, even though the lower bound is not required by its arithmetic proof.

All zero/block-boundary/last-domain cases, including `D=0`, `D=127`, `D=128`, and `D=2^25-1`, are covered by the same quotient identity. No new case split on regimes `j<455`, `j<514`, or the table values is needed. This is not a claim that 128 is a minimal or optimal block size. No inference is made about Gaussian approximation between a block endpoint and another point.

The C227 constructive `Decidable (inDomain xs)` repair is unchanged and not used by this theorem. `foldSigned`, address extraction, the three regimes, signed 39-bit decoding, Option acceptance and modular `k` update remain outside the theorem's conclusion. Their imported definitions are not silently replaced.

## Proof topology and prospective gate

Seven private theorems: quotient constancy -> localU constancy -> middleRow constancy -> slopeWord constancy; quotient constancy plus actual final-index bounds -> finalRow constancy; list fold congruence plus finalRow -> finalSum constancy. The sole public root then composes slopeWord and finalSum constancy.

`ConstancyProofChecks.lean` imports the proposed proof module, checks its name and exact sealed type, applies it as a typed example, prints the actual imported theorem, and requests its actual axiom list. None of those commands has been run in this stage. A text scan found no `sorry`, `admit`, `unsafe`, `native_decide` or axiom declaration in the candidate. Text checks do not establish elaboration, kernel acceptance or axiom cleanliness.

The parent should select the exact C227 core output and unchanged C206 words output named in C229, compile this exact proof source to its own output, then run this exact consumer against that selected output. Actual feedback, dependency association and the actual root axiom list remain pending; no runtime success fields were consumed here. A tactic/API failure is an implementation failure to diagnose, not a mathematical counterexample. No clean-TCB or independent-rerun assertion is made.

## Exposure and scope

This worker authored C206 and has substantial prior Hermite static/runtime exposure. It is not a fresh universal decoder. C224 was a distinct governance review; it is not mathematical support for this theorem. C229's seal and actual C227 definitions were read before proof search. C229 metadata names C213 and C228; those named review/runtime packets were not opened. C213/C221 review outputs were not read or contacted, and no feedback was relayed to those reviewers. Parent-reported C228 success is inherited context only, not evidence generated or independently inspected here.

No compiler, lake, Git, network, Python, repository script, simulation, search over constant fits, finite arithmetic diagnostic or subagent was run. Read-only PowerShell supplied raw reads, hashes, API searches, file inventory and lexical/type-text checks. All new file writes used `apply_patch`; previous packets and production sources were preserved. API lookup misses and the old-toolchain signature-search boundary are retained in the manifest, not hidden as proof evidence.

## Skill handoff

- Objective/frontier node: the exact C229 integer block-constancy supplier.
- Mathematical delta: the complete symbolic route and a seven-helper Lean candidate for the sealed public root; runtime acceptance remains pending.
- Effect on root: potentially permits later blockwise integer envelopes; it supplies no envelope or Gaussian-error bound itself.
- Named evidence: the new public root and exact consumer are candidates; the C229 seal and C227/C206 raw hashes are checked. There are no new executed proof/test receipts.
- Assumptions/conventions: unchanged natural quotient/exponents, signed integer row floors, sequential 19-bit modular slope, nine retained rows and bias.
- Files changed: only this new packet; the manifest and freeze bind the exact payloads.
- Reusable insight: quotient invariance handles signed row expressions without expanding digit logic or fixed words, and fold congruence must be restricted to visited indices.
- Failure class: NONE observed at the mathematical level; elaboration/kernel/axiom and runtime association are PENDING, not certified.
- Salvage: complete candidate retained; no failed compiler drafts or rejected mathematical routes; minor retrieval misses retained.
- Process memory: retained repository protocols only; no additional process-memory entry or prior scientific review was consulted for C230.
- Direction/information gain: a symbolic invariant replaces table evaluation for this exact supplier, without relaxing its scope.
- Parallel/common-blind-spot audit: no delegation or concurrent gate; author work is not independent review. Table/model refinement and operational behavior remain separate dependencies.
- Default route/comparator: division-product identity plus compositional congruence; no native evaluation, full-product substitution or finite enumeration comparator.
- Purification/exposition: staged only, not integrated, not PURIFIED and not an Exposition Seal.
- Expansion boundary: one sealed public root, seven private helpers, no new model definitions or public assumptions.
- Typed obstruction: none identified statically; actual Lean API/tactic acceptance remains untested.
- Residual risk: uncompiled tactic elaboration and actual dependency/output association; inherited provider provenance unchanged.
- Recommended next action: parent serial exact-source compile and exact consumer/axiom gate; preserve this original packet before any successor repair.
- Context digest: this is only exact integer-model block constancy, not real-exp/f64 error, circuit/gadget refinement, phase/cleanup, native/bit cost, claimed author counts, coherent amplitude conversion, SP/BE ROOT, main merge or publication admission.
