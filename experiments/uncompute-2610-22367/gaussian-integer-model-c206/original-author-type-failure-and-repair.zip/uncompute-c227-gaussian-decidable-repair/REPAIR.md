# Type-formation-only successor

C225 accepted the514-literal/zero-suffix table, then rejected the original
GaussianIntegerCore at line85: no Decidable instance for the named domain
conjunction. No proof or core output was accepted. The exact old candidate
and compiler receipt remain immutable.

This successor adds only a local constructive Decidable(inDomain xs), inferred
from its literal two Int inequalities. It does not invoke classical choice,
change the scientific domain/Option rejection, add a hypothesis or alter the
integer scalar model. The decision procedure is not a correctness certificate.
No global public instance or quantum foundation is introduced. Full core/table
source is retained to permit a fresh own-output type probe.

C221 independently compares the original C206 without this failure/repair;
only after its own static freeze may this successor be released for comparison.
No proof search or Statement Seal has started. Type formation, source fidelity,
numeric error, phase/cleanup, resources and scientific ROOT remain distinct.
