import GaussianIntegerCore
open UncomputeGaussian206
#check ((∀ (j D : Nat), j < 1024 → D < 2^25 →
  localIncrement j D = localIncrement j (128*(D/128))) : Prop)
