# C213 independent Gaussian INTEGER source-first reconstruction

Frozen source snapshot only: uncompute-2610-22367-64b5a13, parent-provided HEAD
64b5a13aa249f1360846657392e6c66817b26d0f. No C206 file, diagnosis or explanation
was opened. This packet precedes any author-model STATIC comparison. It seals
an independently reconstructed integer comparator, not a Lean proof, executed
simulation, whole-circuit theorem, Gaussian/SPBE certification or1583/139 claim.

The complete canonical target is integer-model.txt, bound by the seal and
manifest. Its authority is the literal circuit/generator/word data, NOT the
README's schematic full-product equations. No script, Python, compiler/lake,
Git, network, subagent, prior reviewer packet or numerical search was run.
PowerShell was used only for read-only source/hash/JSON metadata access.

## Exact source-to-model alignment

| Stage | Actual circuit source | Generator source | Integer rule sealed |
|---|---|---|---|
| Contract/fold | circuit120-130,484-486 | model uses folded nonnegative coordinate | negative xs becomes -xs-1; low38 XOR sign, not absolute value |
| Address | circuit120-124 | build_tables cell width2^(25-M) | j10,D25,U11; U=D>>14 |
| Lookup | load_cfg43-61; leaf_main/pruned_walk; field split | rebuild_words215-224 | low19 slope, next11 signed correction, high25 constant |
| Constant add | circuit201-202 | A0SH7 and final table | k +=128*A_j mod2^39 |
| Middle | mid_row247-304, six rows306-308 | s_of241-261, base_of263 | separate floor shifts per magnitude selector, qlo2/last4, modulo stored21-bit slope |
| Final | booth_row313-351; loop353-363 | booth_psum164-212 | rows2..10 with drop6/top7 and signed active-row bias32/top64 |
| Restore | reverse middle366-368, final unfold484 | no emitted phase semantics | reverse modular slope updates; cleanup separate |
| Final table | load_cfg literal words | search506-511 and rebuild_words | use post-recenter constants.json, not an earlier fitted A0 table |

For the adder/row semantic link, narrowly read original snapshot gadgets:
arith57-217 defines modular in-place add and neg carry-in;522-570 defines
selected columns and their release; qrom263-328 defines content-pruned lookup.
The neg form expects operand XOR neg plus carry-in, including signed high-tail
extension. Circuit columns and bias wire satisfy that form. The middle instead
complements its target for the digit sign while explicitly sign-extending C.
This explains the two different signed-row mechanisms; they are not interchangeable.

## Concrete blind spots the later author model must pass

1. Fold is one below abs for negative inputs. Exact evenness is false for the
   integer approximation; its symmetry is between xs=n and xs=-n-1. Domain
   includes -8 and excludes +8. Borrowed X35..37 are zero only after this fold
   ON DOMAIN, not on arbitrary39-bit patterns.
2. Treat the packed correction as signed11-bit times256, not E itself or an
   unsigned coefficient. Negative arithmetic right shift is floor. The actual
   j100,U1 hand witness distinguishes both truncation-toward-zero and a single
   floor of the combined product from the row rule. base_of is identity: after
   using signed C, do not subtract an additional U<<3 offset.
3. Store slope modulo2^21 (physical19 bits with low2 zeros). Do not add a
   positivity/nonoverflow premise to avoid this. The generator's accepted final
   range can justify later equality to its unwrapped F, but has to be discharged
   for the frozen table/cells; its source assert is not a newly executed proof.
4. Final rows are not floor(FD/2^21). j0,D0 has F20 and P32, so the tempting
   replacement already fails at the origin. Signed inactive rows contribute0,
   including negative zero-digit patterns; bias is active=m1 OR m2, not always1.
5. Data cutoff6 still has a bias at bit5. The README sentence saying no touch
   below bit6 is not a literal description of K[drop-1:]. Top row uses drop7;
   never uniformly assign drop6, nor sign-extend F bit20 as a signed slope.
6. Arrays stop at514 but words extends to1024 with zeros. Zero word decodes C0;
   extending E with0 and computing E-2^18 invents a false negative correction.
   The constant region455..513 has C=S=0 but nonzero A, and j514 begins zero.
7. Exact scan recenters A0p BEFORE rebuild_words/render. The scanned temporary
   F is a generator artifact, not a field in constants.json. Freeze actual words
   and final A0p; do not recompute a fit or silently replace table provenance.
8. Accumulate into arbitrary k modulo2^39, not overwrite with G or compare
   ordinary integers across a modular seam. Complement-add-complement cancels
   both minus-one offsets. Restore input/value registers does not prove phases.

## Three distinct correctness frontiers

INTEGER: the sealed row formulas and modular function, with pending formal
row-gadget/lookup/value-restoration bridge and fixed-table packing/range checks.
All source derivations here are by inspection/algebra; the two witnesses are
hand calculations, not an exhaustive test, a prover result or a compiled gate.

GRADER/REAL: grader69-78 uses Python f64 x*x and math.exp, then floor plus
half-away increment. It accepts centered modular residue in (-2^38,2^38]
with inclusive radius429 and preserves X. Generator exact_scan uses np.float64
exp and monotone endpoint intervals; its "exact" covers discrete coordinate
stretches, not interval-certified real exponential error or equality of numpy
and platform libm rounding. Final Booth period is128 (minimum log-period7,
cell log-width14), so endpoint coverage can be reconstructed structurally;
numeric worst errors and real/f64 error budgets are not re-proved here. Its
right endpoints may lie at the next stretch boundary while P is held from
the previous stretch; that is a safe bounding interval, not pointwise equality.
Generator np.round for table fitting/recentering is ties-to-even, unlike grader
half-away. Do not unify these rules. No universal429 guarantee is claimed.

Machine overflow is separate from the specified slope/k modular wraps.
Generator s_of/booth_psum use np.int64, not arbitrary Z. Decoded field bounds
give |C|<=2^18 and S<2^21; six middle rows have a coarse sum below2^17 in
magnitude, and nine final rows give |P|<2^29. These algebraic bounds put the
row sums far inside int64, but connecting auxiliary array inputs to decoded
fields still needs fixed-table packing checks. No silent int64 wrap is allowed.

QUANTUM: expected_phase=False, restored X, zero ancillas, wire alias safety,
temporary-AND and batched phase repair need separate proofs. The qFw+qEw+qA0w
measurement order matches packed field order, but this observation is not a
proof of phase cancellation. Integer outputs alone cannot certify1583 Toffolis,
139 qubits, op-stream equivalence, global phase, uncomputation or SPBE.

## Seal and handoff

Source/Construction graph: contract -> fold/address -> packed lookup -> six
signed middle rows -> nine dropped/biased rows -> modular update -> reverse
middle/fold. Generator/table consistency and real/f64/quantum bridges remain
explicit dependency edges. Lean graph: NONE inspected/authored/executed here.
Quantum spine/functor graph are not replaced by an integer scalar function.
No new hypothesis is authorized to make a later circuit bridge easy.

Failure class NONE for bounded source reconstruction; wider proof obligations
OPEN. Initial combined terminal reads were truncated and re-read separately;
constants.json was parsed for metadata and selected literal entries, not claimed
individually exhaustively reviewed. Full byte hash fixes all table entries.
Required skill handoff: mathematical delta is the source-first comparator/seal
and two concrete anti-shortcut witnesses. All files NEW C213 only; no predecessor
or snapshot mutation. Reusable insight is row-level bias and signed truncation.
Process memory: QBE-PM-LOW-TOKEN-CONTROL-PLANE;
QBE-PM-VERIFIER-SEMANTIC-LEVEL. Independent author exposure: NONE. No delegated
work or review contamination. Purification/Exposition-Seal NOT_STARTED; no
scientific-root/publication admission. Parent must review this source-first
freeze before separately authorizing C206 STATIC comparison. STOP at freeze.
