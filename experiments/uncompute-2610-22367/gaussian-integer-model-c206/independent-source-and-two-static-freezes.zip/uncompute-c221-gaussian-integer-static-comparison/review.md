# C221 independent STATIC comparison: C206 versus frozen C213

Verdict: NO STATIC INTEGER-SEMANTICS MISMATCH FOUND on the original valid
39-bit domain. Literal table transport MATCHES. This is source/code inspection
and fixed-data comparison, NOT Lean compilation, a circuit/refinement theorem,
f64/real Gaussian error proof, phase/cleanup/resource certificate or SPBE result.
Parent source-publication admission is NOT self-approved here.

## Independence and exact exposure

C213's four files remain byte-identical, including source-first seal
873d9866fad5cb5fdecf05fa261ef31fc8e6f6824e7a4d9619e2cbe1eaee1deb.
Parent whole-read/hash verification and subsequent C221 authorization preceded
the first C206 definition read. Whole GaussianIntegerCore.lean95 lines and
GaussianFixedWords.lean526 lines were read. fixed_constants.json was used only
as literal data. INPUT_MANIFEST.json was filtered to source/table pins and
fixed-constants output hash; diagnostic/prose/execution values were NOT read.
Its key-name inventory was seen, not the corresponding diagnostic values.

No MODEL.md, integer_model.py, FINITE_DIAGNOSTIC.json, compiler output, author
explanation, reviewer report or parent C206 verdict was opened. Initial access
to the parent-requested lowercase input-manifest.json failed; parent corrected
the allowed name to uppercase INPUT_MANIFEST.json. This is a path observation,
not a mathematical/code defect. No alternative author file was searched for.

## Structural comparison against the independent target

Line numbers below are GaussianIntegerCore.lean.

| C213 construction | Actual C206 definitions | Static finding |
|---|---|---|
| signed low38 complement | foldSigned76-77, decode39 87-88 | negative xs maps to -xs-1, not abs; signed decode threshold is2^38 |
| original half-open domain | inDomain79, evaluateSigned84-85 | -2^35 included, +2^35 excluded; arbitrary k<2^39, not k=0 |
| j,D,U | address24,localD25,localU26 | extra address mod1024 is redundant on valid folded range, not a domain change |
| packed55-bit word | a0 27, slopeInitialStored28, correctionPattern29,correctionSigned30-32 | low19 stored slope, next11 two's-complement correction, high25 constant; correction scaled256 in middleRow |
| signed truncated middle | truncSigned34-35,midShift37,midLow38,middleRow40-44 | floor Int division by a positive power; six rows with qlo2,2,2,2,2,4; no extra offset subtraction |
| modular full slope21 | slopeStored52-55,slopeWord57 | equivalent stored19-bit update, justified below; no nonwrapping hypothesis |
| nine biased final rows | digit16-22,finalDrop58,finalShift59,finalRow61-68,finalSum70-71 | rows2..10 only, low biases32/top64, unsigned top recoding bit0; no full-product-floor substitution |
| output update | localIncrement73-74,evaluateSigned84-85 | 128*A-P followed by signed Euclidean mod2^39; no clipping or overwriting k |
| preserved pattern/invalid domain | evaluatePattern90-91 | returns(p,out) only when p<2^39 and decoded input/k valid; otherwise none |
| constant/zero regions | frozenWord literal prefix/default, regime93 | default zero suffix exact on514..1023; regime is descriptive, not a hidden alternate arithmetic branch |

Stored19 versus full21 is NOT a mismatch. Every middleRow R is divisible by4:
each truncated term contains2^q and q>=2. Let L=2^19, F=4*s. C206 updates
s'=(s+R/4) mod L, hence

```text
4*s' = (4*s+R) mod(4*L).
```

The initial value is4*(word mod L), so induction over List.range6 gives exactly
C213's six modulo2^21 updates, including negative rows and intermediate wrap.
Int division by4 here is exact, not a rounding shortcut. Auxiliary
slopeUnbounded48-50 is NOT consumed by localIncrement; no unproved equality to
that nonmodular diagnostic quantity is hidden in the output path.

digit.one is0/1; digit.two can be1 only when one=0. Consequently one+two in
the final bias equals OR/active, including negative zero-digit rows. slopeWord
is always<2^21, so bit21=0; localD(v)<2^25 and localU(localD(v))<2^11. Nat subtractions in
midShift/finalShift/finalDrop match the signed arithmetic schedules within the
ACTUAL list ranges. Generic helpers outside those ranges are mere totalizations,
not newly certified source behavior. No extra public correctness hypothesis
appears: these are definitions, not theorem statements with hidden premises.

For signed quotient semantics, narrowly checked local primary source
Mathlib.Data.Int.Init210-215: natCast_div and ediv_of_neg_of_pos expose the
positive-divisor floor convention. modBits' positive2^n modulus makes toNat
lossless. This source inspection is NOT a compilation of the candidate.

## Literal table and transport audit (static data only)

The source constants.json and C206 fixed_constants.json have different byte
hashes but EXACT equal text after CRLF->LF normalization. The latter preserves
all scalars, arrays and1024 hex words; this is not a refit or a numerical replay.
Own parsing of the Lean numeric match arms found exactly indices0..513 once
each, with every decimal literal equal to the corresponding original hex word.
Its default branch is0; all510 original words514..1023 are0. Thus the full
reachable1024-entry table agrees, not merely a few selected anchors.

Additional fixed-data shape checks:1024 words all<2^55; constant-tail455..513
has zero low30 bits; zero suffix has no nonzero payload. This inspects fixed
literal data ONLY. It runs no C206 definition, Python evaluator, diagnostic,
generator, circuit, simulator or compiler and proves no input-family theorem.
Unsigned64 parsing is exact for these55-bit literals; no floating conversion
was used. The manifest's fixed-constants hash matches the actual file, but no
author-reported literal-test result was consumed as evidence.

## Source/exposition defects versus code defects

The C213 original-source warnings remain distinct from this code verdict.
The discovered README's schematic floor(F*D/2^21) is not exact row arithmetic:
the C213 origin witness has P32 even at D0. Its no-touch-below-bit6 sentence
also omits the bit5 bias wire. C206 finalRow K arithmetic follows the actual
generator/circuit row formula rather than these schematic sentences. Those
SOURCE EXPOSITION inexactnesses are NOT new C206 implementation defects.

No static mismatch or counterexample to the intended C206 integer definitions
was found. No source target or C213 seal was edited to obtain this result.
All C213 open formal circuit/gadget/range/phase/error/resource obligations
remain OPEN; static table equality is not formal table/range proof admission.

## Handoff and next boundary

Current HARNESS including8a and its linked asynchronous policy were read whole.
Evidence strength, source-first release and scientific acceptance are unchanged;
this packet makes no efficiency/timing superiority claim. Only NEW C221 files
were written with apply_patch. No compiler/lake, project/diagnostic script,
Python, Git, network, subagent or unrelated reviewer was used. Inline read-only
PowerShell performed hashes, JSON/text and fixed numeric-literal comparisons,
not execution of either integer model.

Objective delta: the explicit stored19/full21 and active-bias equivalences plus
all reachable literal-table identity discharge STATIC ambiguity against the
independent source comparator. Failure class NONE for this layer; missing
lowercase manifest is PATH/API handling only. Salvage: retain all source/code
bindings and all wider gaps. Process memory: QBE-PM-LOW-TOKEN-CONTROL-PLANE;
QBE-PM-VERIFIER-SEMANTIC-LEVEL. Source graph remains original Gaussian stages;
Lean dependency graph is inspected definitions only, no accepted theorem edge.
Quantum spine/functor/phase/resource graph is not replaced by integer arithmetic.
Purification/Exposition-Seal NOT_STARTED. Recommended next step is parent review
of this STATIC packet, then separately authorized formal/runtime work. STOP.
